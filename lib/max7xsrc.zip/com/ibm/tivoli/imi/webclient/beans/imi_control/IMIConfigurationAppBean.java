/*     */ package com.ibm.tivoli.imi.webclient.beans.imi_control;
/*     */ 
/*     */ import com.ibm.tivoli.imi.controller.IMSessionHandler;
/*     */ import com.ibm.tivoli.imi.controller.MessageKey;
/*     */ import com.ibm.tivoli.imi.controller.Messages;
/*     */ import com.ibm.tivoli.imi.controller.SessionInfoHelper;
/*     */ import com.ibm.tivoli.imi.controller.TsdIMException;
/*     */ import com.ibm.tivoli.imi.controller.TsdIMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.webclient.beans.common.StatefulAppBean;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 

















/*     */ public class IMIConfigurationAppBean extends StatefulAppBean
/*     */ {
/*     */   public int APPLY()
/*     */   {
/*     */     try
/*     */     {
/*  45 */       MboRemote imProfile = getMbo();
/*     */ 
/*  47 */       if (imProfile == null) {
/*  48 */         this.clientSession.showMessageBox("instantmessaging", MessageKey.PROFILE_NOT_SELECTED.toString(), null);
/*     */ 
/*  50 */         return 1;
/*     */       }
/*     */ 
/*  53 */       String driver = imProfile.getString("DRIVER");
/*  54 */       String serverHostname = imProfile.getString("SERVERHOSTNAME");
/*  55 */       int serverPortInt = imProfile.getInt("SERVERPORT");
/*  56 */       String serverPort = String.valueOf(serverPortInt);
/*  57 */       if (serverPortInt == 0) {
/*  58 */         serverPort = "";
/*     */       }
/*  60 */       String service = imProfile.getString("SERVICE");
/*  61 */       String community = imProfile.getString("COMMUNITY");
/*  62 */       int connectionTimeoutInt = imProfile.getInt("CONNECTIONTIMEOUT");
/*  63 */       String connectionTimeout = String.valueOf(connectionTimeoutInt);
/*  64 */       if (connectionTimeoutInt == 0) {
/*  65 */         connectionTimeout = "";
/*     */       }
/*     */ 
/*  68 */       MXSession mxSession = this.clientSession.getMXSession();
/*  69 */       MboSetRemote imSystemProperties = mxSession.getMboSet("MAXPROPVALUE");
/*  70 */       imSystemProperties.setQbe("PROPNAME", "mxe.imi.%");
/*  71 */       imSystemProperties.reset();
/*     */ 
/*  73 */       MboRemote imSystemProperty = imSystemProperties.getMbo();
/*  74 */       if (imSystemProperty == null) {
/*  75 */         imSystemProperty = imSystemProperties.moveNext();
/*  76 */         if (imSystemProperty == null) {
/*  77 */           this.clientSession.showMessageBox("instantmessaging", MessageKey.EXCEPTION.toString(), new String[] { "Could not get IMI System Properties" });
/*     */ 
/*  79 */           return 1;
/*     */         }
/*     */       }
/*     */ 
/*  83 */       String propValue = "";
/*  84 */       while (imSystemProperty != null) {
/*  85 */         String propName = imSystemProperty.getString("PROPNAME");
/*  86 */         if (propName.equals("mxe.imi.driver"))
/*  87 */           propValue = driver;
/*  88 */         else if (propName.equals("mxe.imi.serverhostname"))
/*  89 */           propValue = serverHostname;
/*  90 */         else if (propName.equals("mxe.imi.serverport"))
/*  91 */           propValue = serverPort;
/*  92 */         else if (propName.equals("mxe.imi.service"))
/*  93 */           propValue = service;
/*  94 */         else if (propName.equals("mxe.imi.community"))
/*  95 */           propValue = community;
/*  96 */         else if (propName.equals("mxe.imi.connectiontimeout")) {
/*  97 */           propValue = connectionTimeout;
/*     */         }
/*  99 */         if (propValue == null) {
/* 100 */           propValue = "";
/*     */         }
/* 102 */         imSystemProperty.setValue("PROPVALUE", propValue, 2L);
/* 103 */         imSystemProperty = imSystemProperties.moveNext();
/*     */       }
/*     */ 
/* 106 */       imSystemProperties.save();
/* 107 */       imSystemProperties.reset();
/*     */ 
/* 109 */       DataBean propertiesBean = this.app.getDataBean("properties_table");





/*     */ 
/* 116 */       if (propertiesBean != null) {
/* 117 */         propertiesBean.reloadTable();
/*     */       }
/*     */ 
/* 120 */       this.clientSession.showMessageBox("instantmessaging", MessageKey.PROFILE_APPLIED.toString(), null);
/*     */     } catch (RemoteException e) {
/* 122 */       this.clientSession.showMessageBox("instantmessaging", MessageKey.EXCEPTION.toString(), new String[] { e.getMessage() });
/*     */ 
/* 124 */       IMSessionHandler.logError(e);
/*     */     } catch (MXException e) {
/* 126 */       this.clientSession.showMessageBox(e);
/* 127 */       IMSessionHandler.logError(e);
/*     */     }
/*     */ 
/* 130 */     return 1;
/*     */   }





/*     */   public int CLOSE_CON()
/*     */   {
/* 139 */     boolean alreadyClosed = false;
/* 140 */     String messageKey = MessageKey.CON_JUST_CLOSED.toString();
/* 141 */     String[] messageParams = null;
/*     */ 
/* 143 */     SessionInfoHelper.putWebClientSession(this.clientSession);
/* 144 */     HttpSession session = this.clientSession.getHttpSession();
/* 145 */     if (IMSessionHandler.hasIMSessionHandler(session)) {
/* 146 */       IMSessionHandler imSessionHandler = IMSessionHandler.getIMSessionHandler(session);
/* 147 */       if (imSessionHandler.isIMSessionOpened())
/*     */         try {
/* 149 */           imSessionHandler.closeIMSession(true, this.clientSession);


/*     */         }
/*     */         catch (IMException e)
/*     */         {
/* 155 */           messageKey = MessageKey.EXCEPTION.toString();
/* 156 */           messageParams = new String[] { Messages.getString(this.clientSession.getMXSession(), "EX_" + e.getCode().name()) };

/*     */         }
/*     */         catch (TsdIMException e)
/*     */         {
/* 161 */           messageKey = MessageKey.EXCEPTION.toString();
/* 162 */           messageParams = new String[] { Messages.getString(this.clientSession.getMXSession(), e.getCode().name()) };
/*     */         }
/*     */       else
/* 165 */         alreadyClosed = true;
/*     */     }
/*     */     else {
/* 168 */       alreadyClosed = true;
/*     */     }
/*     */ 
/* 171 */     if (alreadyClosed) {
/* 172 */       IMSessionHandler.logInfo("User requested to close IM session, but it was not opened");
/* 173 */       messageKey = MessageKey.CON_ALREADY_CLOSED.toString();
/*     */     }
/*     */ 
/* 176 */     this.clientSession.showMessageBox("instantmessaging", messageKey, messageParams);
/*     */ 
/* 178 */     return 1;
/*     */   }
/*     */ }
