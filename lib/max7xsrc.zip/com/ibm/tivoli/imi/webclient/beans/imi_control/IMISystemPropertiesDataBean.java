/*    */ package com.ibm.tivoli.imi.webclient.beans.imi_control;
/*    */ 
/*    */ import com.ibm.tivoli.imi.controller.IMSessionHandler;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ 















/*    */ public class IMISystemPropertiesDataBean extends DataBean
/*    */ {
/*    */   protected void initialize()
/*    */     throws MXException, RemoteException
/*    */   {
/* 29 */     MboSetRemote properties = getMboSet();
/* 30 */     properties.setQbe("PROPNAME", "mxe.imi.%");
/* 31 */     properties.reset();
/*    */ 
/* 33 */     super.initialize();
/*    */   }

/*    */   public void reloadTable()
/*    */   {
/*    */     try {
/* 39 */       MboSetRemote properties = getMboSet();
/* 40 */       properties.setQbe("PROPNAME", "mxe.imi.%");
/* 41 */       properties.reset();
/*    */     } catch (Exception e) {
/* 43 */       IMSessionHandler.logError(e);
/*    */     }
/*    */ 
/* 46 */     super.reloadTable();
/*    */   }
/*    */ }
