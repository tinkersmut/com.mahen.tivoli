/*     */ package com.ibm.tivoli.imi.webclient.beans.imi_control;
/*     */ 
/*     */ import com.ibm.tivoli.imi.controller.IMSessionHandler;
/*     */ import com.ibm.tivoli.imi.controller.MessageKey;
/*     */ import com.ibm.tivoli.imi.controller.Messages;
/*     */ import com.ibm.tivoli.imi.controller.SessionInfoHelper;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.app.person.PersonSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 
























/*     */ public class IMOpenConnectionDialog extends DataBean
/*     */ {
/*     */   protected void initialize()
/*     */     throws MXException, RemoteException
/*     */   {
/*  50 */     if (isIMServerHostnameBlank()) {
/*  51 */       return;
/*     */     }
/*  53 */     if (isIMSessionAlreadyOpened()) {
/*  54 */       return;
/*     */     }
/*     */ 
/*  57 */     setLoggedUserPerson();
/*  58 */     super.initialize();
/*     */   }


/*     */   private boolean isIMServerHostnameBlank()
/*     */     throws RemoteException, MXException
/*     */   {
/*  65 */     String imServerHostname = MXServer.getMXServer().getProperty("mxe.imi.serverhostname");
/*  66 */     if ((imServerHostname == null) || (imServerHostname.trim().equals(""))) {
/*  67 */       super.initialize();
/*  68 */       this.clientSession.handleEvent(new WebClientEvent("dialogcancel", this.app.getCurrentPageId(), "", this.clientSession));
/*  69 */       this.clientSession.showMessageBox("instantmessaging", MessageKey.EXCEPTION.toString(), new String[] { Messages.getString(getMXSession(), "EX_INVALID_IM_SERVER") });
/*     */ 
/*  71 */       return true;
/*     */     }
/*  73 */     return false;
/*     */   }


/*     */   private boolean isIMSessionAlreadyOpened()
/*     */     throws RemoteException, MXException
/*     */   {
/*  80 */     HttpSession session = this.clientSession.getHttpSession();
/*  81 */     if (IMSessionHandler.hasIMSessionHandler(session)) {
/*  82 */       IMSessionHandler imSessionHandler = IMSessionHandler.getIMSessionHandler(session);
/*  83 */       if (imSessionHandler.isIMSessionOpened()) {
/*  84 */         super.initialize();
/*  85 */         IMSessionHandler.logInfo("User requested to open an IMSessionHandler that was already opened");
/*  86 */         this.clientSession.handleEvent(new WebClientEvent("dialogcancel", this.app.getCurrentPageId(), "", this.clientSession));
/*     */ 
/*  88 */         this.clientSession.showMessageBox("instantmessaging", MessageKey.CON_ALREADY_OPENED.toString(), null);
/*     */ 
/*  90 */         return true;
/*     */       }
/*     */     }
/*  93 */     return false;
/*     */   }

/*     */   private void setLoggedUserPerson() throws RemoteException, MXException {
/*  97 */     psdi.security.UserInfo userInfo = this.clientSession.getMXSession().getUserInfo();
/*  98 */     String personId = userInfo.getPersonId();
/*  99 */     PersonSetRemote personMboSet = (PersonSetRemote)getMboSet();
/* 100 */     String sql = "PERSONID = :1";
/* 101 */     SqlFormat sqlFormat = new SqlFormat(userInfo, sql);
/* 102 */     sqlFormat.setObject(1, "PERSON", "PERSONID", String.valueOf(personId));
/* 103 */     personMboSet.setWhere(sqlFormat.format());
/* 104 */     personMboSet.reset();
/*     */   }

/*     */   public int openIMConnection() throws RemoteException, MXException {
/* 108 */     String imId = getString("IM_ID");
/* 109 */     String imPassword = getString("USER.IM_PASSWORD");
/*     */ 
/* 111 */     if (!(validate(imId, imPassword))) {
/* 112 */       return 1;
/*     */     }
/*     */ 
/* 115 */     SessionInfoHelper.putWebClientSession(this.clientSession);
/* 116 */     IMSessionHandler imSessionHandler = IMSessionHandler.getIMSessionHandler(this.clientSession.getHttpSession());
/*     */     try {
/* 118 */       com.ibm.tivoli.imi.controller.UserInfo userInfo = IMSessionHandler.getUserInfo(this.clientSession.getHttpSession());
/* 119 */       userInfo.setIMUserID(imId);
/* 120 */       userInfo.setIMUserPassword(imPassword);
/* 121 */       imSessionHandler.openIMSession(IMUser.IMUserStatus.DONT_DISTURB);
/* 122 */       this.clientSession.handleEvent(new WebClientEvent("dialogcancel", this.app.getCurrentPageId(), "", this.clientSession));
/* 123 */       this.clientSession.showMessageBox("instantmessaging", MessageKey.CON_JUST_OPENED.toString(), null);

/*     */     }
/*     */     catch (IMException e)
/*     */     {
/*     */       String errorMessage;
/* 129 */       switch (1.$SwitchMap$com$ibm$tivoli$imi$spi$IMException$Code[e.getCode().ordinal()])
/*     */       {/*     */       case 1:
/* 131 */         errorMessage = Messages.getString(getMXSession(), "EX_SERVER");
/* 132 */         IMSessionHandler.logError(e);
/* 133 */         break;
/*     */       case 2:
/* 135 */         errorMessage = Messages.getString(getMXSession(), "EX_INVALID_IM_SERVER_PORT");
/* 136 */         break;
/*     */       case 3:
/* 138 */         errorMessage = Messages.getString(getMXSession(), "EX_INVALID_IM_SERVICE_NAME");
/* 139 */         break;
/*     */       case 4:
/* 141 */         errorMessage = Messages.getString(getMXSession(), "EX_INVALID_IM_SERVER");
/* 142 */         break;
/*     */       case 5:
/* 144 */         errorMessage = Messages.getString(getMXSession(), "EX_INVALID_ACCOUNT");
/* 145 */         break;
/*     */       case 6:
/* 147 */         errorMessage = Messages.getString(getMXSession(), "EX_CONN_TIMEOUT");
/* 148 */         break;
/*     */       default:
/* 150 */         errorMessage = Messages.getString(getMXSession(), "EX_UNKNOW_ERROR");
/*     */       }
/*     */ 
/* 153 */       this.clientSession.showMessageBox("instantmessaging", MessageKey.EXCEPTION.toString(), new String[] { errorMessage });

/*     */     }
/*     */ 
/* 157 */     return 1;
/*     */   }








/*     */   private boolean validate(String imId, String imPassword)
/*     */   {
/* 169 */     if ((imId == null) || (imId.trim().equals(""))) {
/* 170 */       this.clientSession.showMessageBox("instantmessaging", MessageKey.CONFIG_VALIDATION_USER.toString(), null);
/*     */ 
/* 172 */       return false;
/*     */     }
/* 174 */     if ((imPassword == null) || (imPassword.trim().equals(""))) {
/* 175 */       this.clientSession.showMessageBox("instantmessaging", MessageKey.CONFIG_VALIDATION_PASSWORD.toString(), null);
/*     */ 
/* 177 */       return false;
/*     */     }
/* 179 */     return true;
/*     */   }
/*     */ }
