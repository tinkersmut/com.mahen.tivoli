/*     */ package com.ibm.tivoli.imi.app.imiconf;/*     */ /*     */ import java.lang.reflect.Method;/*     */ import java.rmi.Remote;/*     */ import java.rmi.RemoteException;/*     */ import java.rmi.UnexpectedException;/*     */ import java.rmi.server.RemoteObject;/*     */ import java.rmi.server.RemoteRef;/*     */ import java.rmi.server.RemoteStub;/*     */ import psdi.mbo.MboSetRemote;/*     */ import psdi.security.UserInfo;/*     */ import psdi.server.AppServiceRemote;/*     */ import psdi.server.ServiceRemote;/*     */ import psdi.util.MXException;/*     */ 
/*     */ public final class IMProfileService_Stub extends RemoteStub/*     */   implements IMProfileServiceRemote, AppServiceRemote, Remote/*     */ {/*     */   private static final long serialVersionUID = 2L;/*     */   private static Method $method_checkSecurity_0;/*     */   private static Method $method_getCriteria_1;/*     */   private static Method $method_getCurrentState_2;/*     */   private static Method $method_getLiveObjCount_3;/*     */   private static Method $method_getMboSet_4;/*     */   private static Method $method_getName_5;/*     */   private static Method $method_getSchemaOwner_6;/*     */   private static Method $method_getSetForRelationship_7;/*     */   private static Method $method_getSetFromKeys_8;/*     */   private static Method $method_getStateCmdList_9;/*     */   private static Method $method_getStateList_10;/*     */   private static Method $method_getURL_11;/*     */   private static Method $method_isAppService_12;/*     */   private static Method $method_isSingletonService_13;/*     */   private static Method $method_restart_14;/*     */   private static Method $method_verifyUser_15;/*     */   private static Method $method_verifyUser_16;/*     */   static Class array$Ljava$lang$String;/*     */   static Class array$$Ljava$lang$String;/*     */ /*     */   static/*     */   {/*     */     // Byte code:/*     */     //   0: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   3: ifnull +9 -> 12/*     */     //   6: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   9: goto +12 -> 21/*     */     //   12: ldc 19/*     */     //   14: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   17: dup/*     */     //   18: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   21: ldc 3/*     */     //   23: iconst_2/*     */     //   24: anewarray 29	java/lang/Class/*     */     //   27: dup/*     */     //   28: iconst_0/*     */     //   29: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   32: ifnull +9 -> 41/*     */     //   35: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   38: goto +12 -> 50/*     */     //   41: ldc 17/*     */     //   43: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   46: dup/*     */     //   47: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   50: aastore/*     */     //   51: dup/*     */     //   52: iconst_1/*     */     //   53: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   56: ifnull +9 -> 65/*     */     //   59: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   62: goto +12 -> 74/*     */     //   65: ldc 18/*     */     //   67: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   70: dup/*     */     //   71: putstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   74: aastore/*     */     //   75: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   78: putstatic 49	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_checkSecurity_0	Ljava/lang/reflect/Method;/*     */     //   81: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   84: ifnull +9 -> 93/*     */     //   87: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   90: goto +12 -> 102/*     */     //   93: ldc 19/*     */     //   95: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   98: dup/*     */     //   99: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   102: ldc 4/*     */     //   104: iconst_1/*     */     //   105: anewarray 29	java/lang/Class/*     */     //   108: dup/*     */     //   109: iconst_0/*     */     //   110: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   113: ifnull +9 -> 122/*     */     //   116: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   119: goto +12 -> 131/*     */     //   122: ldc 17/*     */     //   124: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   127: dup/*     */     //   128: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   131: aastore/*     */     //   132: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   135: putstatic 50	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getCriteria_1	Ljava/lang/reflect/Method;/*     */     //   138: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   141: ifnull +9 -> 150/*     */     //   144: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   147: goto +12 -> 159/*     */     //   150: ldc 19/*     */     //   152: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   155: dup/*     */     //   156: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   159: ldc 5/*     */     //   161: iconst_0/*     */     //   162: anewarray 29	java/lang/Class/*     */     //   165: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   168: putstatic 51	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getCurrentState_2	Ljava/lang/reflect/Method;/*     */     //   171: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   174: ifnull +9 -> 183/*     */     //   177: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   180: goto +12 -> 192/*     */     //   183: ldc 19/*     */     //   185: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   188: dup/*     */     //   189: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   192: ldc 6/*     */     //   194: iconst_0/*     */     //   195: anewarray 29	java/lang/Class/*     */     //   198: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   201: putstatic 52	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getLiveObjCount_3	Ljava/lang/reflect/Method;/*     */     //   204: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   207: ifnull +9 -> 216/*     */     //   210: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   213: goto +12 -> 225/*     */     //   216: ldc 19/*     */     //   218: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   221: dup/*     */     //   222: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   225: ldc 7/*     */     //   227: iconst_2/*     */     //   228: anewarray 29	java/lang/Class/*     */     //   231: dup/*     */     //   232: iconst_0/*     */     //   233: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   236: ifnull +9 -> 245/*     */     //   239: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   242: goto +12 -> 254/*     */     //   245: ldc 17/*     */     //   247: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   250: dup/*     */     //   251: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   254: aastore/*     */     //   255: dup/*     */     //   256: iconst_1/*     */     //   257: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   260: ifnull +9 -> 269/*     */     //   263: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   266: goto +12 -> 278/*     */     //   269: ldc 18/*     */     //   271: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   274: dup/*     */     //   275: putstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   278: aastore/*     */     //   279: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   282: putstatic 53	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getMboSet_4	Ljava/lang/reflect/Method;/*     */     //   285: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   288: ifnull +9 -> 297/*     */     //   291: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   294: goto +12 -> 306/*     */     //   297: ldc 20/*     */     //   299: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   302: dup/*     */     //   303: putstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   306: ldc 8/*     */     //   308: iconst_0/*     */     //   309: anewarray 29	java/lang/Class/*     */     //   312: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   315: putstatic 54	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getName_5	Ljava/lang/reflect/Method;/*     */     //   318: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   321: ifnull +9 -> 330/*     */     //   324: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   327: goto +12 -> 339/*     */     //   330: ldc 19/*     */     //   332: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   335: dup/*     */     //   336: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   339: ldc 9/*     */     //   341: iconst_0/*     */     //   342: anewarray 29	java/lang/Class/*     */     //   345: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   348: putstatic 55	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getSchemaOwner_6	Ljava/lang/reflect/Method;/*     */     //   351: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   354: ifnull +9 -> 363/*     */     //   357: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   360: goto +12 -> 372/*     */     //   363: ldc 19/*     */     //   365: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   368: dup/*     */     //   369: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   372: ldc 10/*     */     //   374: iconst_5/*     */     //   375: anewarray 29	java/lang/Class/*     */     //   378: dup/*     */     //   379: iconst_0/*     */     //   380: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   383: ifnull +9 -> 392/*     */     //   386: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   389: goto +12 -> 401/*     */     //   392: ldc 17/*     */     //   394: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   397: dup/*     */     //   398: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   401: aastore/*     */     //   402: dup/*     */     //   403: iconst_1/*     */     //   404: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   407: ifnull +9 -> 416/*     */     //   410: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   413: goto +12 -> 425/*     */     //   416: ldc 17/*     */     //   418: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   421: dup/*     */     //   422: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   425: aastore/*     */     //   426: dup/*     */     //   427: iconst_2/*     */     //   428: getstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   431: ifnull +9 -> 440/*     */     //   434: getstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   437: goto +12 -> 449/*     */     //   440: ldc 1/*     */     //   442: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   445: dup/*     */     //   446: putstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   449: aastore/*     */     //   450: dup/*     */     //   451: iconst_3/*     */     //   452: getstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   455: ifnull +9 -> 464/*     */     //   458: getstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   461: goto +12 -> 473/*     */     //   464: ldc 1/*     */     //   466: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   469: dup/*     */     //   470: putstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   473: aastore/*     */     //   474: dup/*     */     //   475: iconst_4/*     */     //   476: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   479: ifnull +9 -> 488/*     */     //   482: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   485: goto +12 -> 497/*     */     //   488: ldc 18/*     */     //   490: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   493: dup/*     */     //   494: putstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   497: aastore/*     */     //   498: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   501: putstatic 56	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getSetForRelationship_7	Ljava/lang/reflect/Method;/*     */     //   504: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   507: ifnull +9 -> 516/*     */     //   510: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   513: goto +12 -> 525/*     */     //   516: ldc 19/*     */     //   518: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   521: dup/*     */     //   522: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   525: ldc 11/*     */     //   527: iconst_4/*     */     //   528: anewarray 29	java/lang/Class/*     */     //   531: dup/*     */     //   532: iconst_0/*     */     //   533: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   536: ifnull +9 -> 545/*     */     //   539: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   542: goto +12 -> 554/*     */     //   545: ldc 17/*     */     //   547: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   550: dup/*     */     //   551: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   554: aastore/*     */     //   555: dup/*     */     //   556: iconst_1/*     */     //   557: getstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   560: ifnull +9 -> 569/*     */     //   563: getstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   566: goto +12 -> 578/*     */     //   569: ldc 1/*     */     //   571: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   574: dup/*     */     //   575: putstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*     */     //   578: aastore/*     */     //   579: dup/*     */     //   580: iconst_2/*     */     //   581: getstatic 70	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$$Ljava$lang$String	Ljava/lang/Class;/*     */     //   584: ifnull +9 -> 593/*     */     //   587: getstatic 70	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$$Ljava$lang$String	Ljava/lang/Class;/*     */     //   590: goto +12 -> 602/*     */     //   593: ldc 2/*     */     //   595: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   598: dup/*     */     //   599: putstatic 70	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$$Ljava$lang$String	Ljava/lang/Class;/*     */     //   602: aastore/*     */     //   603: dup/*     */     //   604: iconst_3/*     */     //   605: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   608: ifnull +9 -> 617/*     */     //   611: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   614: goto +12 -> 626/*     */     //   617: ldc 18/*     */     //   619: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   622: dup/*     */     //   623: putstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   626: aastore/*     */     //   627: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   630: putstatic 57	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getSetFromKeys_8	Ljava/lang/reflect/Method;/*     */     //   633: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   636: ifnull +9 -> 645/*     */     //   639: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   642: goto +12 -> 654/*     */     //   645: ldc 19/*     */     //   647: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   650: dup/*     */     //   651: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   654: ldc 12/*     */     //   656: iconst_0/*     */     //   657: anewarray 29	java/lang/Class/*     */     //   660: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   663: putstatic 58	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getStateCmdList_9	Ljava/lang/reflect/Method;/*     */     //   666: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   669: ifnull +9 -> 678/*     */     //   672: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   675: goto +12 -> 687/*     */     //   678: ldc 19/*     */     //   680: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   683: dup/*     */     //   684: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   687: ldc 13/*     */     //   689: iconst_0/*     */     //   690: anewarray 29	java/lang/Class/*     */     //   693: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   696: putstatic 59	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getStateList_10	Ljava/lang/reflect/Method;/*     */     //   699: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   702: ifnull +9 -> 711/*     */     //   705: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   708: goto +12 -> 720/*     */     //   711: ldc 20/*     */     //   713: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   716: dup/*     */     //   717: putstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   720: ldc 14/*     */     //   722: iconst_0/*     */     //   723: anewarray 29	java/lang/Class/*     */     //   726: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   729: putstatic 60	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_getURL_11	Ljava/lang/reflect/Method;/*     */     //   732: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   735: ifnull +9 -> 744/*     */     //   738: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   741: goto +12 -> 753/*     */     //   744: ldc 20/*     */     //   746: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   749: dup/*     */     //   750: putstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   753: ldc 15/*     */     //   755: iconst_0/*     */     //   756: anewarray 29	java/lang/Class/*     */     //   759: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   762: putstatic 61	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_isAppService_12	Ljava/lang/reflect/Method;/*     */     //   765: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   768: ifnull +9 -> 777/*     */     //   771: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   774: goto +12 -> 786/*     */     //   777: ldc 20/*     */     //   779: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   782: dup/*     */     //   783: putstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   786: ldc 16/*     */     //   788: iconst_0/*     */     //   789: anewarray 29	java/lang/Class/*     */     //   792: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   795: putstatic 62	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_isSingletonService_13	Ljava/lang/reflect/Method;/*     */     //   798: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   801: ifnull +9 -> 810/*     */     //   804: getstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   807: goto +12 -> 819/*     */     //   810: ldc 20/*     */     //   812: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   815: dup/*     */     //   816: putstatic 77	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$ServiceRemote	Ljava/lang/Class;/*     */     //   819: ldc 21/*     */     //   821: iconst_0/*     */     //   822: anewarray 29	java/lang/Class/*     */     //   825: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   828: putstatic 63	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_restart_14	Ljava/lang/reflect/Method;/*     */     //   831: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   834: ifnull +9 -> 843/*     */     //   837: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   840: goto +12 -> 852/*     */     //   843: ldc 19/*     */     //   845: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   848: dup/*     */     //   849: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   852: ldc 24/*     */     //   854: iconst_3/*     */     //   855: anewarray 29	java/lang/Class/*     */     //   858: dup/*     */     //   859: iconst_0/*     */     //   860: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   863: ifnull +9 -> 872/*     */     //   866: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   869: goto +12 -> 881/*     */     //   872: ldc 17/*     */     //   874: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   877: dup/*     */     //   878: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   881: aastore/*     */     //   882: dup/*     */     //   883: iconst_1/*     */     //   884: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   887: ifnull +9 -> 896/*     */     //   890: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   893: goto +12 -> 905/*     */     //   896: ldc 17/*     */     //   898: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   901: dup/*     */     //   902: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   905: aastore/*     */     //   906: dup/*     */     //   907: iconst_2/*     */     //   908: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   911: ifnull +9 -> 920/*     */     //   914: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   917: goto +12 -> 929/*     */     //   920: ldc 18/*     */     //   922: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   925: dup/*     */     //   926: putstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   929: aastore/*     */     //   930: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*     */     //   933: putstatic 64	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_verifyUser_15	Ljava/lang/reflect/Method;/*     */     //   936: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   939: ifnull +9 -> 948/*     */     //   942: getstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   945: goto +12 -> 957/*     */     //   948: ldc 19/*     */     //   950: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   953: dup/*     */     //   954: putstatic 76	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$server$AppServiceRemote	Ljava/lang/Class;/*     */     //   957: ldc 24/*     */     //   959: bipush 7/*     */     //   961: anewarray 29	java/lang/Class/*     */     //   964: dup/*     */     //   965: iconst_0/*     */     //   966: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   969: ifnull +9 -> 978/*     */     //   972: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   975: goto +12 -> 987/*     */     //   978: ldc 17/*     */     //   980: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   983: dup/*     */     //   984: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   987: aastore/*     */     //   988: dup/*     */     //   989: iconst_1/*     */     //   990: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   993: ifnull +9 -> 1002/*     */     //   996: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   999: goto +12 -> 1011/*     */     //   1002: ldc 17/*     */     //   1004: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   1007: dup/*     */     //   1008: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   1011: aastore/*     */     //   1012: dup/*     */     //   1013: iconst_2/*     */     //   1014: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   1017: ifnull +9 -> 1026/*     */     //   1020: getstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   1023: goto +12 -> 1035/*     */     //   1026: ldc 18/*     */     //   1028: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*     */     //   1031: dup/*     */     //   1032: putstatic 75	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$psdi$security$UserInfo	Ljava/lang/Class;/*     */     //   1035: aastore/*     */     //   1036: dup/*     */     //   1037: iconst_3/*     */     //   1038: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   1041: ifnull +9 -> 1050/*     */     //   1044: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;/*     */     //   1047: goto +12 -> 1059/*     */     //   1050: ldc 17/*     */     //   1052: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   1055: dup
/*     */     //   1056: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;
/*     */     //   1059: aastore
/*     */     //   1060: dup
/*     */     //   1061: iconst_4
/*     */     //   1062: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;
/*     */     //   1065: ifnull +9 -> 1074
/*     */     //   1068: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;
/*     */     //   1071: goto +12 -> 1083
/*     */     //   1074: ldc 17
/*     */     //   1076: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   1079: dup
/*     */     //   1080: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;
/*     */     //   1083: aastore
/*     */     //   1084: dup
/*     */     //   1085: iconst_5
/*     */     //   1086: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;
/*     */     //   1089: ifnull +9 -> 1098
/*     */     //   1092: getstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;
/*     */     //   1095: goto +12 -> 1107
/*     */     //   1098: ldc 17
/*     */     //   1100: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   1103: dup
/*     */     //   1104: putstatic 74	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$java$lang$String	Ljava/lang/Class;
/*     */     //   1107: aastore
/*     */     //   1108: dup
/*     */     //   1109: bipush 6
/*     */     //   1111: getstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;
/*     */     //   1114: ifnull +9 -> 1123
/*     */     //   1117: getstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;
/*     */     //   1120: goto +12 -> 1132
/*     */     //   1123: ldc 1
/*     */     //   1125: invokestatic 73	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   1128: dup
/*     */     //   1129: putstatic 71	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:array$Ljava$lang$String	Ljava/lang/Class;
/*     */     //   1132: aastore
/*     */     //   1133: invokevirtual 80	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   1136: putstatic 65	com/ibm/tivoli/imi/app/imiconf/IMProfileService_Stub:$method_verifyUser_16	Ljava/lang/reflect/Method;
/*     */     //   1139: goto +14 -> 1153
/*     */     //   1142: pop
/*     */     //   1143: new 34	java/lang/NoSuchMethodError
/*     */     //   1146: dup
/*     */     //   1147: ldc 22
/*     */     //   1149: invokespecial 67	java/lang/NoSuchMethodError:<init>	(Ljava/lang/String;)V
/*     */     //   1152: athrow
/*     */     //   1153: return
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	1139	1142	java/lang/NoSuchMethodException
/*     */   }
/*     */ 
/*     */   public IMProfileService_Stub(RemoteRef paramRemoteRef)
/*     */   {
/*  57 */     super(paramRemoteRef);
/*     */   }



/*     */   public boolean checkSecurity(String paramString, UserInfo paramUserInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/*  67 */       Object localObject = this.ref.invoke(this, $method_checkSecurity_0, new Object[] { paramString, paramUserInfo }, 8247709093644811655L);
/*  68 */       return ((Boolean)localObject).booleanValue();
/*     */     } catch (RuntimeException localRuntimeException) {
/*  70 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/*  72 */       throw localRemoteException;
/*     */     } catch (MXException localMXException) {
/*  74 */       throw localMXException;
/*     */     } catch (Exception localException) {
/*  76 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public String getCriteria(String paramString)
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/*  85 */       Object localObject = this.ref.invoke(this, $method_getCriteria_1, new Object[] { paramString }, -5989158361157245733L);
/*  86 */       return ((String)localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/*  88 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/*  90 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/*  92 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public String getCurrentState()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 101 */       Object localObject = this.ref.invoke(this, $method_getCurrentState_2, null, 5979834270575960167L);
/* 102 */       return ((String)localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 104 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 106 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 108 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public int getLiveObjCount()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       Object localObject = this.ref.invoke(this, $method_getLiveObjCount_3, null, -6537857020604813065L);
/* 118 */       return ((Integer)localObject).intValue();
/*     */     } catch (RuntimeException localRuntimeException) {
/* 120 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 122 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 124 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public MboSetRemote getMboSet(String paramString, UserInfo paramUserInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 133 */       Object localObject = this.ref.invoke(this, $method_getMboSet_4, new Object[] { paramString, paramUserInfo }, -5550711175416571367L);
/* 134 */       return ((MboSetRemote)localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 136 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 138 */       throw localRemoteException;
/*     */     } catch (MXException localMXException) {
/* 140 */       throw localMXException;
/*     */     } catch (Exception localException) {
/* 142 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public String getName()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 151 */       Object localObject = this.ref.invoke(this, $method_getName_5, null, 6317137956467216454L);
/* 152 */       return ((String)localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 154 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 156 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 158 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public String getSchemaOwner()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 167 */       Object localObject = this.ref.invoke(this, $method_getSchemaOwner_6, null, 8347097484602420354L);
/* 168 */       return ((String)localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 170 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 172 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 174 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public MboSetRemote getSetForRelationship(String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2, UserInfo paramUserInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 183 */       Object localObject = this.ref.invoke(this, $method_getSetForRelationship_7, new Object[] { paramString1, paramString2, paramArrayOfString1, paramArrayOfString2, paramUserInfo }, -4380067798835489152L);
/* 184 */       return ((MboSetRemote)localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 186 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 188 */       throw localRemoteException;
/*     */     } catch (MXException localMXException) {
/* 190 */       throw localMXException;
/*     */     } catch (Exception localException) {
/* 192 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public MboSetRemote getSetFromKeys(String paramString, String[] paramArrayOfString, String[][] paramArrayOfString1, UserInfo paramUserInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 201 */       Object localObject = this.ref.invoke(this, $method_getSetFromKeys_8, new Object[] { paramString, paramArrayOfString, paramArrayOfString1, paramUserInfo }, -5754231710637380731L);
/* 202 */       return ((MboSetRemote)localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 204 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 206 */       throw localRemoteException;
/*     */     } catch (MXException localMXException) {
/* 208 */       throw localMXException;
/*     */     } catch (Exception localException) {
/* 210 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public String[] getStateCmdList()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 219 */       Object localObject = this.ref.invoke(this, $method_getStateCmdList_9, null, -1872494375285609980L);
/* 220 */       return ((String[])localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 222 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 224 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 226 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public String[] getStateList()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 235 */       Object localObject = this.ref.invoke(this, $method_getStateList_10, null, -644299949192447009L);
/* 236 */       return ((String[])localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 238 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 240 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 242 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public String getURL()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 251 */       Object localObject = this.ref.invoke(this, $method_getURL_11, null, -1842225981409839707L);
/* 252 */       return ((String)localObject);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 254 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 256 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 258 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public boolean isAppService()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 267 */       Object localObject = this.ref.invoke(this, $method_isAppService_12, null, 6198315342968748672L);
/* 268 */       return ((Boolean)localObject).booleanValue();
/*     */     } catch (RuntimeException localRuntimeException) {
/* 270 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 272 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 274 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public boolean isSingletonService()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 283 */       Object localObject = this.ref.invoke(this, $method_isSingletonService_13, null, 1982340891497496779L);
/* 284 */       return ((Boolean)localObject).booleanValue();
/*     */     } catch (RuntimeException localRuntimeException) {
/* 286 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 288 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 290 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public void restart()
/*     */     throws RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 299 */       this.ref.invoke(this, $method_restart_14, null, -2563244869731757367L);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 301 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 303 */       throw localRemoteException;
/*     */     } catch (Exception localException) {
/* 305 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public void verifyUser(String paramString1, String paramString2, UserInfo paramUserInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 314 */       this.ref.invoke(this, $method_verifyUser_15, new Object[] { paramString1, paramString2, paramUserInfo }, -143553093032805425L);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 316 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 318 */       throw localRemoteException;
/*     */     } catch (MXException localMXException) {
/* 320 */       throw localMXException;
/*     */     } catch (Exception localException) {
/* 322 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }

/*     */   public boolean verifyUser(String paramString1, String paramString2, UserInfo paramUserInfo, String paramString3, String paramString4, String paramString5, String[] paramArrayOfString)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 331 */       Object localObject = this.ref.invoke(this, $method_verifyUser_16, new Object[] { paramString1, paramString2, paramUserInfo, paramString3, paramString4, paramString5, paramArrayOfString }, -2035776150235786348L);
/* 332 */       return ((Boolean)localObject).booleanValue();
/*     */     } catch (RuntimeException localRuntimeException) {
/* 334 */       throw localRuntimeException;
/*     */     } catch (RemoteException localRemoteException) {
/* 336 */       throw localRemoteException;
/*     */     } catch (MXException localMXException) {
/* 338 */       throw localMXException;
/*     */     } catch (Exception localException) {
/* 340 */       throw new UnexpectedException("undeclared checked exception", localException);
/*     */     }
/*     */   }
/*     */ }
