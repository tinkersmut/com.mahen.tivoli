/*    */ package com.ibm.tivoli.imi.app.imiconf;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboConstants;
/*    */ import psdi.server.AppService;
/*    */ import psdi.server.MXServer;
/*    */ 













/*    */ public class IMProfileService extends AppService
/*    */   implements IMProfileServiceRemote, MboConstants
/*    */ {
/*    */   private static final long serialVersionUID = -6933750595690827793L;
/*    */ 
/*    */   public IMProfileService()
/*    */     throws RemoteException
/*    */   {
/*    */   }
/*    */ 
/*    */   public IMProfileService(MXServer mxServer)
/*    */     throws RemoteException
/*    */   {
/* 34 */     super(mxServer);
/*    */   }
/*    */ }
