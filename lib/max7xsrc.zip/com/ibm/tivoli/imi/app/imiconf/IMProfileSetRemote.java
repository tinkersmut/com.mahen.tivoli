package com.ibm.tivoli.imi.app.imiconf;

import psdi.mbo.MboSetRemote;

public abstract interface IMProfileSetRemote extends MboSetRemote
{
}
