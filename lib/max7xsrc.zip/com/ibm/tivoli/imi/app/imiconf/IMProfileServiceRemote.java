package com.ibm.tivoli.imi.app.imiconf;

import psdi.server.AppServiceRemote;

public abstract interface IMProfileServiceRemote extends AppServiceRemote
{
}
