package com.ibm.tivoli.imi.app.imiconf;

import psdi.mbo.MboRemote;

public abstract interface IMProfileRemote extends MboRemote
{
}
