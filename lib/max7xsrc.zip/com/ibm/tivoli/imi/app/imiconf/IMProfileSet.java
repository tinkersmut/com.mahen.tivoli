/*    */ package com.ibm.tivoli.imi.app.imiconf;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.util.MXException;
/*    */ 














/*    */ public class IMProfileSet extends MboSet
/*    */   implements IMProfileSetRemote
/*    */ {
/*    */   private static final long serialVersionUID = -7429316567554373615L;
/*    */ 
/*    */   public IMProfileSet(MboServerInterface ms)
/*    */     throws RemoteException
/*    */   {
/* 31 */     super(ms);
/*    */   }

/*    */   protected Mbo getMboInstance(MboSet ms) throws MXException, RemoteException
/*    */   {
/* 36 */     return new IMProfile(ms);
/*    */   }
/*    */ }
