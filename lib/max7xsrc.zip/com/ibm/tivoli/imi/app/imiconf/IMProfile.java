/*    */ package com.ibm.tivoli.imi.app.imiconf;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboSet;
/*    */ 














/*    */ public class IMProfile extends Mbo
/*    */   implements IMProfileRemote
/*    */ {
/*    */   private static final long serialVersionUID = 997595151892380085L;
/*    */ 
/*    */   public IMProfile(MboSet ms)
/*    */     throws RemoteException
/*    */   {
/* 29 */     super(ms);
/*    */   }
/*    */ }
