/*    */ package com.ibm.tivoli.imi.drivers.moc2007;
/*    */ 
/*    */ import com.ibm.tivoli.imi.spi.IMDriver;
/*    */ import com.ibm.tivoli.imi.spi.IMDriverManager;
/*    */ import com.ibm.tivoli.imi.spi.IMException;
/*    */ import com.ibm.tivoli.imi.spi.IMSession;
/*    */ 











































/*    */ public class IMDriverMocImpl extends IMDriver
/*    */ {
/*    */   private String productName;
/*    */ 
/*    */   private IMDriverMocImpl(String productName)
/*    */   {
/* 57 */     this.productName = productName;
/*    */   }

/*    */   public String getIMProductName()
/*    */   {
/* 62 */     return this.productName;
/*    */   }

/*    */   public IMSession createSession()
/*    */   {
/* 67 */     return new IMSessionMocImpl();
/*    */   }

/*    */   public String[] getOptionalProperties()
/*    */   {
/* 72 */     String[] values = new String[OptionalProperties.values().length];
/* 73 */     int i = 0;
/* 74 */     for (OptionalProperties op : OptionalProperties.values()) {
/* 75 */       values[i] = op.name();
/* 76 */       ++i;
/*    */     }
/* 78 */     return values;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 49 */       IMDriver moc = new IMDriverMocImpl("ms_communicator");
/* 50 */       IMDriverManager.registerIMDriver(moc);
/*    */     } catch (IMException e) {
/* 52 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static enum OptionalProperties
/*    */   {
/* 34 */     SERVER_PORT, SERVICE_NAME;
/*    */   }
/*    */ }
