/*     */ package com.ibm.tivoli.imi.drivers.moc2007.util;
/*     */ 
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.IMSessionMocImpl;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import sun.misc.BASE64Encoder;
/*     */ 






















/*     */ public class HttpUtil
/*     */ {
/*     */   private static final String UNICODE = "UTF-8";
/*     */   private static final String POST_METHOD = "POST";
/*     */   private static final String GET_METHOD = "GET";
/*     */   private static final String CWA_TICKET = "CWA-Ticket";
/*     */   private static final String CONTENT_LENGTH = "Content-Length";
/*     */   private static final String CONTENT_TYPE = "Content-Type";
/*     */   private static final String CONTENT_TYPE_VALUE = "application/x-www-form-urlencoded";
/*     */   private static final String SSL_AUTHORIZATION = "Authorization";
/*     */   private static final String SSL_AUTHORIZATION_TYPE = "Basic";
/*     */ 
/*     */   public static String post(IMSessionMocImpl session, String data, String adress)
/*     */     throws IMException
/*     */   {
/*  51 */     return createHttpConnection("POST", session, data, adress);
/*     */   }







/*     */   public static String get(IMSessionMocImpl session, String data, String adress)
/*     */     throws IMException
/*     */   {
/*  63 */     return createHttpConnection("GET", session, data, adress);
/*     */   }








/*     */   public static String encode(String value)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  76 */     byte[] buf = value.getBytes("UTF-8");
/*  77 */     String result = new BASE64Encoder().encode(buf);
/*  78 */     return result;
/*     */   }











/*     */   public static String receive(HttpURLConnection conn)
/*     */     throws IOException
/*     */   {
/*  94 */     InputStreamReader in = new InputStreamReader(conn.getInputStream(), "UTF-8");
/*  95 */     StringWriter response = new StringWriter();
/*     */ 
/*  97 */     for (int i = in.read(); i != -1; i = in.read()) {
/*  98 */       response.append((char)i);
/*     */     }
/*     */ 
/* 101 */     return response.toString();
/*     */   }









/*     */   public static String createHttpConnection(String type, IMSessionMocImpl session, String data, String adress)
/*     */     throws IMException
/*     */   {
/* 115 */     URL url = null;
/* 116 */     HttpURLConnection conn = null;
/* 117 */     String response = null;

/*     */     try
/*     */     {
/* 121 */       String authHeader = new StringBuilder().append("Basic ").append(encode(new StringBuilder().append(session.getUserId()).append(":").append(session.getUserPassword()).toString())).toString();
/*     */ 
/* 123 */       url = new URL(new StringBuilder().append(session.getServerHostName()).append(adress).toString());
/*     */ 
/* 125 */       conn = (HttpURLConnection)url.openConnection();
/* 126 */       conn.setDoInput(true);
/* 127 */       conn.setDoOutput(true);
/* 128 */       conn.setRequestMethod(type);
/* 129 */       if (data != null)
/*     */       {
/* 131 */         conn.setRequestProperty("Content-Type", "UTF-8");
/*     */       }
/* 133 */       if (session.getTicket() != null) {
/* 134 */         conn.setRequestProperty("CWA-Ticket", session.getTicket());
/*     */       }
/* 136 */       conn.setRequestProperty("Authorization", authHeader);
/*     */ 
/* 138 */       OutputStream out = conn.getOutputStream();

/*     */ 
/* 141 */       if (data != null) {
/* 142 */         StringBuilder s = new StringBuilder();
/* 143 */         for (int i = 0; i < data.length(); ++i) {
/* 144 */           s.append(data.charAt(i));
/*     */         }
/* 146 */         out.write(s.toString().getBytes("UTF-8"));
/*     */       }
/*     */ 
/* 149 */       out.flush();

/*     */ 
/* 152 */       String ticket = conn.getHeaderField("CWA-Ticket");

/*     */ 
/* 155 */       if (((session.getTicket() == null) && (ticket != null)) || ((ticket != null) && (ticket != session.getTicket()))) {
/* 156 */         session.setTicket(ticket);
/*     */       }
/*     */ 
/* 159 */       response = receive(conn);
/* 160 */       conn.disconnect();
/*     */ 
/* 162 */       if (conn.getResponseCode() != 200) {
/* 163 */         throw new IMException(new StringBuilder().append("IM falil to send message ").append(conn.getResponseCode()).toString());
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 169 */       throw new IMException("Usuportable encoding Exception", e);
/*     */     }
/*     */     catch (IOException e) {
/* 172 */       throw new IMException(e);
/*     */     }
/* 174 */     return response;
/*     */   }
/*     */ }
