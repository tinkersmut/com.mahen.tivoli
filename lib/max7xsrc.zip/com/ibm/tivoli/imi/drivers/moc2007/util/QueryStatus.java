/*     */ package com.ibm.tivoli.imi.drivers.moc2007.util;
/*     */ 
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.IMSessionMocImpl;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 



















/*     */ public class QueryStatus
/*     */   implements Runnable
/*     */ {
/*  38 */   private long pollWaitTime = 1000L;
/*     */   private static final String LOGKEY = "maximo";
/*  41 */   private static MXLogger logger = MXLoggerFactory.getLogger("maximo");
/*     */ 
/*  43 */   private IMSessionMocImpl session = null;
/*  44 */   private boolean isactive = true;
/*     */ 
/*     */   public QueryStatus(IMSessionMocImpl session) {
/*  47 */     this.session = session;
/*     */   }

/*     */   public void run()
/*     */   {
/*  52 */     DocumentBuilderFactory dbf = null;
/*  53 */     DocumentBuilder docBuilder = null;
/*  54 */     Document doc = null;

/*     */ 
/*  57 */     Element cwaEventsTag = null;

/*     */ 
/*  60 */     while (this.isactive)

/*     */     {
/*     */       try
/*     */       {
/*  65 */         String response = MocUtil.queryPresence(this.session);
/*     */ 
/*  67 */         if (response != null) {
/*  68 */           if (logger.isDebugEnabled()) {
/*  69 */             logger.debug("Auery status response :" + response);
/*     */           }
/*     */ 
/*  72 */           InputSource inStream = new InputSource();
/*  73 */           inStream.setCharacterStream(new StringReader(response));
/*     */ 
/*  75 */           dbf = DocumentBuilderFactory.newInstance();
/*  76 */           docBuilder = dbf.newDocumentBuilder();
/*  77 */           doc = docBuilder.parse(inStream);

/*     */ 
/*  80 */           cwaEventsTag = doc.getDocumentElement();
/*     */ 
/*  82 */           String pollWaitTimeSt = cwaEventsTag.getAttribute("pollWaitTime").toString();
/*  83 */           if ((pollWaitTimeSt != null) && (pollWaitTimeSt != "")) {
/*  84 */             this.pollWaitTime = Long.parseLong(pollWaitTimeSt);
/*     */           }
/*     */         }
/*     */ 
/*  88 */         Thread.sleep(this.pollWaitTime);
/*     */       } catch (InterruptedException e) {
/*  90 */         logger.error("MOC Interrupted Exception", e);
/*     */       } catch (ParserConfigurationException e) {
/*  92 */         logger.error("Probleam parsin XML of MOC response", e);
/*     */       } catch (SAXException e) {
/*  94 */         logger.error("MOC SAX exception", e);
/*     */       } catch (IOException e) {
/*  96 */         logger.error("MOC IO Exception", e);
/*     */       } catch (IMException e) {
/*  98 */         logger.error("MOC IM Exception", e);
/*     */       }
/*     */     }
/*     */   }



/*     */   public boolean isIsactive()
/*     */   {
/* 107 */     return this.isactive;
/*     */   }

/*     */   public void setIsactive(boolean isactive)
/*     */   {
/* 112 */     this.isactive = isactive;
/*     */   }
/*     */ }
