/*     */ package com.ibm.tivoli.imi.drivers.moc2007;
/*     */ 
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.util.MocUtil;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMMessage;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageListener;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 























/*     */ public class IMMessageHandlerMocImpl
/*     */   implements IMMessageHandler
/*     */ {
/*     */   private static final String ERROR = "ERROR";
/*     */   private IMSessionMocImpl session;
/*     */   private IMUser imPartner;
/*     */   private Set<IMMessageListener> listeners;
/*     */   private static final int MAX_MESSAGE_BYTES_LENGTH = 32767;
/*  44 */   private boolean opened = false;
/*     */ 
/*     */   public IMMessageHandlerMocImpl(IMSessionMocImpl session, IMUser imPartner)
/*     */   {
/*  50 */     setSession(session);
/*  51 */     setIMPartner(imPartner);
/*  52 */     this.listeners = new HashSet();
/*  53 */     setOpened(true);
/*     */   }


/*     */   private void setSession(IMSessionMocImpl session)
/*     */   {
/*  59 */     if (session == null) {
/*  60 */       throw new IllegalArgumentException("Session must not be null");
/*     */     }
/*  62 */     this.session = session;
/*     */   }

/*     */   private void setIMPartner(IMUser imPartner) {
/*  66 */     if (imPartner == null) {
/*  67 */       throw new IllegalArgumentException("IM partner must not be null");
/*     */     }
/*  69 */     this.imPartner = imPartner;
/*     */   }

/*     */   public IMUser getIMPartner() {
/*  73 */     return this.imPartner;
/*     */   }

/*     */   public void addListener(IMMessageListener messageListener) throws IMException
/*     */   {
/*  78 */     this.listeners.add(messageListener);
/*     */   }

/*     */   public void closeConversation() throws IMException {
/*  82 */     for (IMMessageListener listener : this.listeners) {
/*  83 */       listener.conversationClosed("Person who initiated the chat closed it");
/*     */     }
/*  85 */     this.session.removePartnerConferenceId(this.imPartner.getUserId());
/*  86 */     this.session.removeMessageHandlerList(this.imPartner.getUserId());
/*     */   }

/*     */   public boolean isOpened()
/*     */   {
/*  91 */     return this.opened;
/*     */   }

/*     */   public void removeAllListeners() {
/*  95 */     this.listeners.clear();
/*     */   }

/*     */   public void removeListener(IMMessageListener messageListener) {
/*  99 */     this.listeners.remove(messageListener);
/*     */   }

/*     */   public Set<IMMessageListener> getListeners() {
/* 103 */     return this.listeners;
/*     */   }



/*     */   public String sendMessage(String message)
/*     */     throws IMException
/*     */   {
/* 111 */     if ((message != null) && (message.getBytes().length > 32767)) {
/* 112 */       throw new IMException(IMException.Code.MESSAGE_TOO_LONG, "The message to be sent must not have more than 32767 bytes");


/*     */     }
/*     */ 
/* 117 */     String messageReturned = MocUtil.sendMessage(message, this.session, this.imPartner);

/*     */ 
/* 120 */     for (IMMessageListener listener : this.listeners)

/*     */     {
/* 123 */       if (messageReturned.equals("ERROR"))
/* 124 */         listener.conversationClosed("Partner has closed the chat window.");
/*     */       else {
/* 126 */         listener.messageReceived(new IMMessageEvent(this, this.session, new IMMessage(new IMUserMocImpl(this.session.getUserId(), this.session.getUserId()), this.imPartner, messageReturned, new Date().getTime())));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 131 */     return IMMessage.getFormatedMessage(this.session.getUserId(), messageReturned);
/*     */   }





/*     */   public void setOpened(boolean opened)
/*     */   {
/* 140 */     this.opened = opened;
/*     */   }
/*     */ }
