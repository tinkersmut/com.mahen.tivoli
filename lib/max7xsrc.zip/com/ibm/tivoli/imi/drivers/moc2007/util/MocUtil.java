/*     */ package com.ibm.tivoli.imi.drivers.moc2007.util;
/*     */ 
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.IMSessionMocImpl;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import java.util.List;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 






















/*     */ public class MocUtil
/*     */ {
/*     */   private static final String LOGON_URL = "/forms/Logon.html";
/*     */   private static final String COMMUNICATION_URL = "/cwa/MainCommandHandler.ashx";
/*     */   private static final String SIGNIN_TEMPLATE = "/com/ibm/tivoli/imi/drivers/moc2007/util/signIn.xml.template";
/*     */   private static final String INITIATESESSION_TEMPLATE = "/com/ibm/tivoli/imi/drivers/moc2007/util/initiateSession.xml.template";
/*     */   private static final String TERMINATESESSION_TEMPLATE = "/com/ibm/tivoli/imi/drivers/moc2007/util/terminateSession.xml.template";
/*     */   private static final String CONFERENCE_TEMPLATE = "/com/ibm/tivoli/imi/drivers/moc2007/util/sendMessage.xml.template";
/*     */   private static final String MESSAGE_TEMPLATE = "/com/ibm/tivoli/imi/drivers/moc2007/util/message.xml.template";
/*     */   private static final String REQUEST_PRESENCE = "/com/ibm/tivoli/imi/drivers/moc2007/util/requestPresence.xml.template";
/*     */   private static final String ERROR = "ERROR";
/*     */   private static final String LOGKEY = "maximo";
/*  38 */   private static MXLogger logger = MXLoggerFactory.getLogger("maximo");
/*     */ 
/*     */   public static void signIn(IMSessionMocImpl session)
/*     */     throws IMException
/*     */   {
/*  49 */     TemplateLoader loader = new TemplateLoader("/com/ibm/tivoli/imi/drivers/moc2007/util/signIn.xml.template");
/*     */ 
/*  51 */     loader.setProperty("mos.user", session.getUserId());
/*  52 */     loader.setProperty("mos.password", session.getUserPassword());
/*     */ 
/*  54 */     String data = loader.toString();
/*  55 */     if (logger.isDebugEnabled()) {
/*  56 */       logger.debug("Sending Moc sign in information");
/*     */     }
/*     */ 
/*  59 */     String response = HttpUtil.post(session, data, "/forms/Logon.html");
/*  60 */     if (logger.isDebugEnabled()) {
/*  61 */       logger.debug("Moc sign in response: " + response);
/*     */     }
/*     */ 
/*  64 */     if (response.contains("requestFailed")) {
/*  65 */       if (logger.isDebugEnabled()) {
/*  66 */         logger.error("MOC Sign In error :" + response);
/*     */       }
/*  68 */       throw new IMException("Wrong IM user or password");
/*     */     }
/*     */   }







/*     */   public static void initiatingSession(IMSessionMocImpl session)
/*     */     throws IMException
/*     */   {
/*  81 */     TemplateLoader loader = new TemplateLoader("/com/ibm/tivoli/imi/drivers/moc2007/util/initiateSession.xml.template");
/*     */ 
/*  83 */     String data = loader.toString();
/*     */ 
/*  85 */     String response = HttpUtil.post(session, data, "/cwa/MainCommandHandler.ashx");

/*     */ 
/*  88 */     if (response.contains("requestRejected")) {
/*  89 */       logger.error("MOC initiating Session error:" + response);
/*  90 */       throw new IMException("IM falil to initiate Session");
/*     */     }
/*  92 */     if (logger.isDebugEnabled()) {
/*  93 */       logger.debug(response);
/*     */     }
/*     */ 
/*  96 */     int ini = response.indexOf("<sid>") + 5;
/*  97 */     int fim = response.indexOf("</sid>");
/*  98 */     session.setSid(response.substring(ini, fim));
/*     */   }








/*     */   public static void terminatingSession(IMSessionMocImpl session)
/*     */     throws IMException
/*     */   {
/* 111 */     TemplateLoader loader = new TemplateLoader("/com/ibm/tivoli/imi/drivers/moc2007/util/terminateSession.xml.template");
/* 112 */     loader.setProperty("mos.sid", session.getSid());
/*     */ 
/* 114 */     String data = loader.toString();
/*     */ 
/* 116 */     if (logger.isDebugEnabled()) {
/* 117 */       logger.debug("Sending Moc terminate session");
/*     */     }
/*     */ 
/* 120 */     String response = HttpUtil.post(session, data, "/cwa/MainCommandHandler.ashx");
/*     */ 
/* 122 */     if (response.contains("requestRejected")) {
/* 123 */       logger.error("MOC terminating Session error:" + response);
/* 124 */       throw new IMException("IM falil to terminate Session");
/*     */     }
/*     */ 
/* 127 */     if (logger.isDebugEnabled()) {
/* 128 */       logger.debug("Terminating session response: " + response);
/*     */     }
/* 130 */     session.setTicket(null);
/*     */   }










/*     */   public static String sendMessage(String message, IMSessionMocImpl session, IMUser partner)
/*     */     throws IMException
/*     */   {
/* 145 */     String data = null;
/* 146 */     TemplateLoader loader = null;
/* 147 */     String response = null;

/*     */     try
/*     */     {
/* 151 */       String confId = session.getPartnerConferenceId(partner.getUserId());
/* 152 */       if (confId == null)
/*     */       {
/* 154 */         if (logger.isDebugEnabled()) {
/* 155 */           logger.debug("Sending Moc first message to initiate session, message: " + message);
/*     */         }
/*     */ 
/* 158 */         loader = new TemplateLoader("/com/ibm/tivoli/imi/drivers/moc2007/util/sendMessage.xml.template");
/* 159 */         loader.setProperty("moc.sid", session.getSid());
/* 160 */         loader.setProperty("moc.rid", session.getRid());
/* 161 */         loader.setProperty("moc.user", partner.getUserId());
/* 162 */         loader.setProperty("moc.content", message);
/* 163 */         data = loader.toString();
/*     */ 
/* 165 */         if (logger.isDebugEnabled()) {
/* 166 */           logger.debug("MOC sending message: " + data);
/*     */         }
/*     */ 
/* 169 */         response = HttpUtil.post(session, data, "/cwa/MainCommandHandler.ashx");
/*     */ 
/* 171 */         if (logger.isDebugEnabled()) {
/* 172 */           logger.debug("Send message MOC response: " + response);
/*     */         }
/*     */ 
/* 175 */         if (response.contains("requestRejected")) {
/* 176 */           logger.error("MOC error initiate conference: " + response);
/* 177 */           throw new IMException("IM falil to send message");
/*     */         }
/*     */ 
/* 180 */         session.setRid(session.getRid() + 1);

/*     */       }
/*     */       else
/*     */       {
/* 185 */         if (logger.isDebugEnabled()) {
/* 186 */           logger.debug("Sending Moc Message: " + message);
/*     */         }
/*     */ 
/* 189 */         loader = new TemplateLoader("/com/ibm/tivoli/imi/drivers/moc2007/util/message.xml.template");
/* 190 */         loader.setProperty("moc.sid", session.getSid().toString());
/* 191 */         loader.setProperty("moc.confId", confId);
/* 192 */         loader.setProperty("moc.rid", session.getRid());
/* 193 */         loader.setProperty("moc.message", message);
/* 194 */         data = loader.toString();
/*     */ 
/* 196 */         if (logger.isDebugEnabled()) {
/* 197 */           logger.debug("Sending Moc message body: " + data);
/*     */         }
/*     */ 
/* 200 */         response = HttpUtil.post(session, data, "/cwa/MainCommandHandler.ashx");
/*     */ 
/* 202 */         if (logger.isDebugEnabled()) {
/* 203 */           logger.debug("MOC sending message response: " + response);
/*     */         }
/*     */ 
/* 206 */         if (response.contains("requestRejected")) {
/* 207 */           logger.error("MOC error sending message:" + response);

/*     */ 
/* 210 */           if (response.contains("code=\"18102\"")) {
/* 211 */             message = "ERROR";
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 216 */         session.setRid(session.getRid() + 1);
/* 217 */         Thread.sleep(3000L);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 223 */       throw new IMException(e);
/*     */     }
/* 225 */     return message;
/*     */   }







/*     */   public static String queryPresence(IMSessionMocImpl session)
/*     */     throws IMException
/*     */   {
/* 237 */     if (session.getListenedUsers().size() > 0) {
/* 238 */       String users = "";
/* 239 */       for (String value : session.getListenedUsers()) {
/* 240 */         users = users + "<uri>sip:" + value + "</uri>\n";
/*     */       }
/*     */ 
/* 243 */       TemplateLoader loader = new TemplateLoader("/com/ibm/tivoli/imi/drivers/moc2007/util/requestPresence.xml.template");
/*     */ 
/* 245 */       loader.setProperty("mos.sid", session.getSid().toString());
/* 246 */       loader.setProperty("mos.rid", session.getRid());
/* 247 */       loader.setProperty("mos.user", users);
/*     */ 
/* 249 */       session.setRid(session.getRid() + 1);
/*     */ 
/* 251 */       String data = loader.toString();
/*     */ 
/* 253 */       return HttpUtil.post(session, data, "/cwa/MainCommandHandler.ashx");
/*     */     }
/* 255 */     return null;
/*     */   }
/*     */ }
