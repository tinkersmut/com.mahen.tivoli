/*     */ package com.ibm.tivoli.imi.drivers.moc2007.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringWriter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 




























































































/*     */ public final class TemplateLoader
/*     */ {
/*     */   private final Map<String, String> props;
/*     */   private final String template;
/*     */ 
/*     */   private static String loadTemplate(String templateName)
/*     */   {
/* 109 */     InputStream in = TemplateLoader.class.getResourceAsStream(templateName);
/* 110 */     StringWriter sw = new StringWriter();
/*     */     try
/*     */     {
/* 113 */       for (int c = in.read(); c != -1; c = in.read())
/* 114 */         sw.append((char)c);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 118 */       e.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 121 */         in.close();
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*     */     }
/* 127 */     return sw.toString();
/*     */   }











/*     */   public TemplateLoader(String templateName)
/*     */   {
/* 142 */     this.template = loadTemplate(templateName);
/* 143 */     this.props = new HashMap();
/*     */   }







/*     */   public void setProperty(String token, long value)
/*     */   {
/* 154 */     this.props.put(new StringBuilder().append("{").append(token).append("}").toString(), String.valueOf(value));
/*     */   }







/*     */   public void setProperty(String token, String value)
/*     */   {
/* 165 */     this.props.put(new StringBuilder().append("{").append(token).append("}").toString(), value);
/*     */   }







/*     */   public String toString()
/*     */   {
/* 176 */     return replaceTokens();
/*     */   }

/*     */   private String replaceTokens()
/*     */   {
/* 181 */     StringBuilder sb = new StringBuilder(this.template);
/*     */ 
/* 183 */     for (Map.Entry e : this.props.entrySet()) {
/* 184 */       int i = sb.indexOf((String)e.getKey());
/* 185 */       while (i != -1) {
/* 186 */         sb.replace(i, i + ((String)e.getKey()).length(), (String)e.getValue());
/* 187 */         i = sb.indexOf((String)e.getKey(), i);
/*     */       }
/*     */     }
/*     */ 
/* 191 */     return sb.toString();
/*     */   }
/*     */ }
