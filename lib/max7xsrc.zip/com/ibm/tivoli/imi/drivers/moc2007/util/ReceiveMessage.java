/*     */ package com.ibm.tivoli.imi.drivers.moc2007.util;
/*     */ 
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.IMMessageHandlerMocImpl;
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.IMSessionMocImpl;
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.IMUserMocImpl;
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.IMUserStatusHandlerMocImpl;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMMessage;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageListener;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.net.MalformedURLException;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 


























/*     */ public class ReceiveMessage
/*     */   implements Runnable
/*     */ {
/*     */   private static final String POLLING_URL = "/cwa/AsyncDataChannel.ashx?Sid=";
/*     */   private static final String AckId = "&AckId=";
/*     */   private static final String UA = "&UA=true";
/*     */   private long pollWaitTime;
/*  60 */   private IMSessionMocImpl session = null;
/*  61 */   private boolean isactive = true;
/*     */   private static final String LOGKEY = "maximo";
/*  64 */   private static MXLogger logger = MXLoggerFactory.getLogger("maximo");
/*     */ 
/*     */   public ReceiveMessage(IMSessionMocImpl session)
/*     */   {
/*  68 */     this.session = session;
/*     */   }

/*     */   public void run()
/*     */   {
/*  73 */     DocumentBuilderFactory dbf = null;
/*  74 */     DocumentBuilder docBuilder = null;
/*  75 */     Document doc = null;

/*     */ 
/*  78 */     Element cwaEventsTag = null;



/*     */ 
/*  83 */     if (logger.isDebugEnabled()) {
/*  84 */       logger.debug("enter in pooling loop");
/*     */     }
/*     */ 
/*  87 */     while (this.isactive)

/*     */     {
/*     */       try
/*     */       {
/*  92 */         StringBuffer stPolling_url = new StringBuffer("/cwa/AsyncDataChannel.ashx?Sid=" + this.session.getSid() + "&AckId=" + String.valueOf(this.session.getAckId()) + "&UA=true");
/*  93 */         String response = HttpUtil.get(this.session, null, stPolling_url.toString());
/*  94 */         stPolling_url = null;
/*     */ 
/*  96 */         if (response.length() != 0)
/*     */         {
/*  98 */           if (logger.isDebugEnabled()) {
/*  99 */             logger.debug("Pooling Response: " + response);
/*     */           }
/*     */ 
/* 102 */           InputSource inStream = new InputSource();
/* 103 */           inStream.setCharacterStream(new StringReader(response));
/*     */ 
/* 105 */           dbf = DocumentBuilderFactory.newInstance();
/* 106 */           docBuilder = dbf.newDocumentBuilder();
/* 107 */           doc = docBuilder.parse(inStream);

/*     */ 
/* 110 */           cwaEventsTag = doc.getDocumentElement();

/*     */ 
/* 113 */           sessionSetUp(cwaEventsTag);

/*     */ 
/* 116 */           NodeList conferenceNode = cwaEventsTag.getElementsByTagName("conference");
/* 117 */           processConference(conferenceNode);


/*     */ 
/* 121 */           processMessage(cwaEventsTag);

/*     */ 
/* 124 */           verifyUserPresence(cwaEventsTag);

/*     */ 
/* 127 */           Thread.sleep(this.pollWaitTime);
/*     */         }
/*     */       } catch (MalformedURLException e) {
/* 130 */         logger.error("Problem to access URL", e);
/*     */       } catch (IOException e) {
/* 132 */         logger.error("MOC IO Exception", e);
/*     */       } catch (SAXException e) {
/* 134 */         logger.error("MOC SAX exception", e);
/*     */       } catch (ParserConfigurationException e) {
/* 136 */         logger.error("Probleam parsin XML of MOC response", e);
/*     */       } catch (InterruptedException e) {
/* 138 */         logger.error("MOC Interrupted Exception", e);
/*     */       } catch (IMException e) {
/* 140 */         logger.error("MOC IM Exception", e);
/*     */       }
/*     */     }
/*     */   }


/*     */   public boolean isIsactive()
/*     */   {
/* 148 */     return this.isactive;
/*     */   }

/*     */   public void setIsactive(boolean isactive)
/*     */   {
/* 153 */     this.isactive = isactive;
/*     */   }






/*     */   public void processConference(NodeList conferenceNode)
/*     */   {
/*     */     String confId;
/* 164 */     for (int i = 0; i < conferenceNode.getLength(); ++i) {
/* 165 */       Element conference = (Element)conferenceNode.item(i);
/* 166 */       Element participant = (Element)conference.getElementsByTagName("participant").item(0);
/* 167 */       if (participant != null) {
/* 168 */         String confId = conference.getAttribute("confId").toString();
/* 169 */         String partnerId = participant.getAttribute("uri").toString().substring(4);
/* 170 */         this.session.addPartnerConferenceId(partnerId, confId);
/* 171 */         if (logger.isDebugEnabled()) {
/* 172 */           logger.debug("geting MOC conferences partnerId = " + partnerId + " , confId = " + confId);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 177 */       Element imSessionState = (Element)conference.getElementsByTagName("imSessionState").item(0);
/* 178 */       if (imSessionState == null)
/*     */         continue;
/* 180 */       String conferenceState = imSessionState.getFirstChild().getNodeValue();
/* 181 */       confId = conference.getAttribute("confId").toString();
/*     */ 
/* 183 */       if (!(conferenceState.equals("terminated"))) {
/*     */         continue;
/*     */       }
/* 186 */       IMMessageHandlerMocImpl partnerHandler = this.session.getPartnerHandlerByConferenceId(confId);
/* 187 */       if (partnerHandler != null)
/* 188 */         for (IMMessageListener listener : partnerHandler.getListeners())
/*     */         {
/* 190 */           if (logger.isDebugEnabled()) {
/* 191 */             logger.debug("MOC Instante message Conference has " + confId + " terminated ");
/*     */           }
/*     */ 
/* 194 */           listener.conversationClosed("Partner has closed the chat window.");
/*     */         }
/*     */     }
/*     */   }











/*     */   public void sessionSetUp(Element cwaEventsTag)
/*     */   {
/* 211 */     String stAckId = cwaEventsTag.getAttribute("ackId").toString();
/*     */ 
/* 213 */     if ((stAckId != null) && (!(stAckId.equals("")))) {
/* 214 */       if (logger.isDebugEnabled()) {
/* 215 */         logger.debug("seting MOC session  AckId = " + stAckId);
/*     */       }
/* 217 */       this.session.setAckId(Integer.parseInt(stAckId));

/*     */     }
/*     */ 
/* 221 */     String pollWaitTimeSt = cwaEventsTag.getAttribute("pollWaitTime").toString();
/* 222 */     if ((pollWaitTimeSt != null) && (pollWaitTimeSt != "")) {
/* 223 */       this.pollWaitTime = Long.parseLong(pollWaitTimeSt);
/* 224 */       if (logger.isDebugEnabled()) {
/* 225 */         logger.debug("MOC Next pollWaitTime = " + pollWaitTimeSt);
/*     */       }
/*     */     }
/*     */ 
/* 229 */     String stSid = cwaEventsTag.getAttribute("sid").toString();
/* 230 */     if ((stSid != null) && (stSid != "")) {
/* 231 */       if (logger.isDebugEnabled()) {
/* 232 */         logger.debug("MOC Session Sid = " + stSid);
/*     */       }
/* 234 */       this.session.setSid(stSid);
/*     */     }
/*     */   }





/*     */   public void processMessage(Element cwaEventsTag)
/*     */   {
/* 244 */     Element messageTag = (Element)cwaEventsTag.getElementsByTagName("message").item(0);
/* 245 */     String mensagem = null;
/*     */     IMMessageHandlerMocImpl partnerHandler;/*     */     IMUser receiver;/*     */     IMMessageEvent messageEvent;
/* 247 */     if (messageTag != null) {
/* 248 */       mensagem = messageTag.getElementsByTagName("content").item(0).getFirstChild().getTextContent();
/* 249 */       long timestamp = System.currentTimeMillis();
/*     */ 
/* 251 */       String partner = ((Element)cwaEventsTag.getElementsByTagName("messageReceived").item(0)).getAttribute("sender").substring(4);

/*     */ 
/* 254 */       partnerHandler = this.session.getMessageHandler(partner);
/* 255 */       if (partnerHandler != null) {
/* 256 */         receiver = this.session.getIMUser();
/* 257 */         IMMessage imMessage = new IMMessage(partnerHandler.getIMPartner(), receiver, mensagem, timestamp);
/* 258 */         messageEvent = new IMMessageEvent(partnerHandler, this.session, imMessage);
/* 259 */         for (IMMessageListener listener : partnerHandler.getListeners()) {
/* 260 */           if (logger.isDebugEnabled()) {
/* 261 */             logger.debug("IMI MOC Message received from " + partnerHandler.getIMPartner().getUserId() + " to " + receiver.getUserId());
/*     */           }
/* 263 */           listener.messageReceived(messageEvent);
/*     */         }
/*     */       }
/*     */     }
/*     */   }




/*     */   public void verifyUserPresence(Element cwaEventsTag)
/*     */   {
/* 274 */     Element userPresenceTag = (Element)cwaEventsTag.getElementsByTagName("userPresence").item(0);
/*     */ 
/* 276 */     NodeList userPresenceTags = cwaEventsTag.getElementsByTagName("user");
/*     */ 
/* 278 */     for (int i = 0; i < userPresenceTags.getLength(); ++i) {
/* 279 */       userPresenceTag = (Element)userPresenceTags.item(i);
/* 280 */       Node availability = userPresenceTag.getElementsByTagName("availability").item(0);
/* 281 */       if (availability == null)
/*     */         continue;
/* 283 */       IMUser.IMUserStatus iMUserStatus = setStatus(userPresenceTag.getElementsByTagName("availability").item(0).getFirstChild().getTextContent());
/* 284 */       IMUser imUser = new IMUserMocImpl(userPresenceTag.getAttribute("uri").substring(4), userPresenceTag.getAttribute("uri").substring(4));
/* 285 */       ((IMUserStatusHandlerMocImpl)this.session.getUserStatusHandler()).userStatusChange(imUser, iMUserStatus);
/*     */ 
/* 287 */       if (logger.isDebugEnabled())
/* 288 */         logger.debug("IMI MOC user: " + imUser.getUserId() + " status is: \"" + iMUserStatus + "\"");
/*     */     }
/*     */   }








/*     */   public IMUser.IMUserStatus setStatus(String status)
/*     */   {
/* 301 */     int statusUser = Integer.parseInt(status);
/* 302 */     IMUser.IMUserStatus iMUserStatus = IMUser.IMUserStatus.UNKNOW;
/*     */ 
/* 304 */     switch (statusUser)
/*     */     {/*     */     case 3500:
/* 306 */       iMUserStatus = IMUser.IMUserStatus.AVAILABLE;
/* 307 */       break;

/*     */     case 6500:
/* 310 */       iMUserStatus = IMUser.IMUserStatus.IN_A_MEETING;
/* 311 */       break;

/*     */     case 9500:
/* 314 */       iMUserStatus = IMUser.IMUserStatus.DONT_DISTURB;
/* 315 */       break;

/*     */     case 12500:
/* 318 */       iMUserStatus = IMUser.IMUserStatus.UNKNOW;
/* 319 */       break;
/*     */     case 15500:
/* 321 */       iMUserStatus = IMUser.IMUserStatus.AWAY;
/* 322 */       break;

/*     */     case 18000:
/* 325 */       iMUserStatus = IMUser.IMUserStatus.OFFLINE;
/* 326 */       break;

/*     */     case 5000:
/* 329 */       iMUserStatus = IMUser.IMUserStatus.AWAY;


/*     */     }
/*     */ 
/* 334 */     return iMUserStatus;
/*     */   }
/*     */ }
