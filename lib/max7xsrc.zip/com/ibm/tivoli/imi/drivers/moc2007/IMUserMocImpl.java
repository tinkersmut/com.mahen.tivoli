/*    */ package com.ibm.tivoli.imi.drivers.moc2007;
/*    */ 
/*    */ import com.ibm.tivoli.imi.spi.IMUser;
/*    */ 

















/*    */ public class IMUserMocImpl
/*    */   implements IMUser
/*    */ {
/*    */   private String displayName;
/*    */   private String userId;
/*    */   private String ticketId;
/*    */   private String confId;
/*    */   private boolean conferenStarted;
/*    */ 
/*    */   public boolean isConferenStarted()
/*    */   {
/* 33 */     return this.conferenStarted;
/*    */   }

/*    */   public void setConferenStarted(boolean conferenStarted) {
/* 37 */     this.conferenStarted = conferenStarted;
/*    */   }

/*    */   public String getConfId() {
/* 41 */     return this.confId;
/*    */   }

/*    */   public void setConfId(String confId) {
/* 45 */     this.confId = confId;
/*    */   }

/*    */   public String getTicketId() {
/* 49 */     return this.ticketId;
/*    */   }

/*    */   public void setTicketId(String ticketId) {
/* 53 */     this.ticketId = ticketId;
/*    */   }

/*    */   public IMUserMocImpl(String userId, String displayName) {
/* 57 */     setUserId(userId);
/* 58 */     setDisplayName(displayName);
/*    */   }

/*    */   private void setDisplayName(String displayName) {
/* 62 */     if ((displayName == null) || (displayName.trim().equals(""))) {
/* 63 */       displayName = this.userId;
/*    */     }
/* 65 */     this.displayName = displayName;
/*    */   }

/*    */   private void setUserId(String userId) {
/* 69 */     if ((userId == null) || (userId.trim().equals(""))) {
/* 70 */       throw new IllegalArgumentException("User id must not be null");
/*    */     }
/* 72 */     this.userId = userId;
/*    */   }

/*    */   public String getDisplayName() {
/* 76 */     return this.displayName;
/*    */   }

/*    */   public String getUserId() {
/* 80 */     return this.userId;
/*    */   }

/*    */   static IMUser createIMUser(String userId, String displayName) {
/* 84 */     IMUser imUser = new IMUserMocImpl(userId, displayName);
/* 85 */     return imUser;
/*    */   }
/*    */ }
