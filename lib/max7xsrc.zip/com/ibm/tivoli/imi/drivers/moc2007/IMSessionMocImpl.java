/*     */ package com.ibm.tivoli.imi.drivers.moc2007;
/*     */ 
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.util.MocUtil;
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.util.QueryStatus;
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.util.ReceiveMessage;
/*     */ import com.ibm.tivoli.imi.spi.IMDriver.RequiredProperties;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveEvent.ResultType;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMSession;
/*     */ import com.ibm.tivoli.imi.spi.IMSingleListener;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ 













/*     */ public class IMSessionMocImpl
/*     */   implements IMSession
/*     */ {
/*     */   private static final long DEFAULT_CONNECTION_TIMEOUT = 20000L;
/*     */   private static final long DEFAULT_RESOLVE_TIMEOUT = 10000L;
/*     */   private static final long MIN_CONNECTION_TIMEOUT = 10000L;
/*     */   private static final long MIN_RESOLVE_TIMEOUT = 10000L;
/*     */   private static final int DEFAULT_PORT = 80;
/*     */   private static final int MIN_SERVER_PORT = 0;
/*     */   private static final int MAX_SERVER_PORT = 65535;
/*  52 */   private int serverPort = 80;
/*     */   private String serverHostName;
/*     */   private String serviceName;
/*     */   private String userId;
/*     */   private String userPassword;
/*  54 */   private IMUser imUser = null;
/*     */ 
/*  56 */   private long connectionTimeout = 20000L;
/*  57 */   private long resolveTimeout = 10000L;
/*  58 */   private boolean isOpened = false;
/*     */   private List<IMMessageHandlerMocImpl> messageHandlerList;
/*     */   private IMUserStatusHandler userStatusHandler;
/*     */   private HashMap partnerConferenceId;
/*  62 */   private String ticket = null;
/*  63 */   private String sid = null;
/*  64 */   private int rid = 2;
/*     */   private QueryStatus query;
/*  66 */   private int ackId = 0;
/*  67 */   private ReceiveMessage receiveMessage = null;
/*     */   private List<String> listenedUsers;
/*     */ 
/*     */   public IMSessionMocImpl()
/*     */   {
/*  71 */     this.listenedUsers = new ArrayList();
/*  72 */     this.partnerConferenceId = new HashMap();
/*     */   }

/*     */   public List<String> getListenedUsers() {
/*  76 */     return this.listenedUsers;
/*     */   }

/*     */   public void setListenedUsers(List<String> listenedUsers) {
/*  80 */     this.listenedUsers = listenedUsers;
/*     */   }

/*     */   public ReceiveMessage getReceiveMessage() {
/*  84 */     return this.receiveMessage;
/*     */   }

/*     */   public void setReceiveMessage(ReceiveMessage receiveMessage) {
/*  88 */     this.receiveMessage = receiveMessage;
/*     */   }

/*     */   public int getRid() {
/*  92 */     return this.rid;
/*     */   }

/*     */   public void setRid(int rid) {
/*  96 */     this.rid = rid;
/*     */   }

/*     */   public String getTicket() {
/* 100 */     return this.ticket;
/*     */   }

/*     */   public void setTicket(String ticket) {
/* 104 */     this.ticket = ticket;
/*     */   }

/*     */   public String getSid() {
/* 108 */     return this.sid;
/*     */   }

/*     */   public void setSid(String sid) {
/* 112 */     this.sid = sid;
/*     */   }

/*     */   public void changeUserStatus(IMUser.IMUserStatus imUserStatus) throws IMException
/*     */   {
/* 117 */     if (!(this.isOpened)) {
/* 118 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 120 */     if (imUserStatus == null) {
/* 121 */       throw new IllegalArgumentException("Invalid IM user status");
/*     */     }
/*     */ 
/* 124 */     setNewStatus(imUserStatus);
/*     */   }


/*     */   private void setNewStatus(IMUser.IMUserStatus newStatus)
/*     */   {
/* 130 */     short _newStatus = 0;
/* 131 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$spi$IMUser$IMUserStatus[newStatus.ordinal()])
/*     */     {
/*     */     case 1:
/* 134 */       break;

/*     */     case 2:
/* 137 */       break;

/*     */     case 3:
/* 140 */       break;

/*     */     case 4:
/* 143 */       break;

/*     */     case 5:
/* 146 */       break;
/*     */     case 6:
/*     */     case 7:
/*     */     }
/*     */   }






/*     */   public void open()
/*     */     throws IMException
/*     */   {
/* 160 */     MocUtil.signIn(this);
/* 161 */     MocUtil.initiatingSession(this);
/*     */ 
/* 163 */     this.isOpened = true;


/*     */ 
/* 167 */     this.receiveMessage = new ReceiveMessage(this);
/* 168 */     Thread tr = new Thread(this.receiveMessage);
/* 169 */     tr.start();
/*     */ 
/* 171 */     this.query = new QueryStatus(this);
/* 172 */     Thread tq = new Thread(this.query);
/* 173 */     tq.start();
/* 174 */     createIMUser();
/*     */   }

/*     */   private void createIMUser()
/*     */     throws IMException
/*     */   {
/* 180 */     IMUser imUser = IMUserMocImpl.createIMUser(this.userId, this.userId);
/* 181 */     setIMUser(imUser);
/*     */   }

/*     */   public void close() throws IMException {
/* 185 */     if (this.isOpened) {
/* 186 */       if (this.messageHandlerList != null)
/*     */       {
/* 188 */         for (int i = this.messageHandlerList.size() - 1; i >= 0; --i) {
/* 189 */           IMMessageHandlerMocImpl messageHandler = (IMMessageHandlerMocImpl)this.messageHandlerList.remove(i);
/* 190 */           if (messageHandler.isOpened()) {
/* 191 */             messageHandler.closeConversation();
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 196 */       MocUtil.terminatingSession(this);
/* 197 */       this.isOpened = false;
/* 198 */       this.query.setIsactive(false);
/* 199 */       this.receiveMessage.setIsactive(false);
/*     */     }
/*     */   }

/*     */   public void removeMessageHandlerList(String userId) throws IMException {
/* 204 */     if (this.messageHandlerList == null)
/*     */       return;
/* 206 */     for (int i = this.messageHandlerList.size() - 1; i >= 0; --i) {
/* 207 */       IMMessageHandlerMocImpl messageHandler = (IMMessageHandlerMocImpl)this.messageHandlerList.get(i);
/* 208 */       if (!(messageHandler.getIMPartner().getUserId().equals(userId)))
/*     */         continue;
/* 210 */       this.messageHandlerList.remove(i);
/*     */     }
/*     */   }



/*     */   public void configure(Properties properties)
/*     */     throws IMException
/*     */   {
/* 219 */     String _serverHostName = properties.getProperty(IMDriver.RequiredProperties.SERVER_HOSTNAME.toString());

/*     */ 
/* 222 */     String _userId = properties.getProperty(IMDriver.RequiredProperties.USER_ID.toString());
/*     */ 
/* 224 */     String _userPassword = properties.getProperty(IMDriver.RequiredProperties.USER_PASSWORD.toString());

/*     */ 
/* 227 */     String _connectionTimeout = properties.getProperty(IMDriver.RequiredProperties.CONNECTION_TIMEOUT.toString());

/*     */ 
/* 230 */     String _resolveTimeout = properties.getProperty(IMDriver.RequiredProperties.RESOLVE_TIMEOUT.toString());


/*     */ 
/* 234 */     setServerHostName(_serverHostName);
/* 235 */     setUserId(_userId);
/* 236 */     setUserPassword(_userPassword);
/* 237 */     setConnectionTimeout(_connectionTimeout);
/* 238 */     setResolveTimeout(_resolveTimeout);
/*     */   }

/*     */   private void setServerHostName(String serverHostName) throws IMException
/*     */   {
/* 243 */     if ((serverHostName == null) || (serverHostName.trim().equals(""))) {
/* 244 */       throw new IMException(IMException.Code.INVALID_IM_SERVER);
/*     */     }
/* 246 */     this.serverHostName = serverHostName;
/*     */   }

/*     */   private void setServerPort(String serverPort) throws IMException {
/* 250 */     if (serverPort.trim().equals("")) {
/* 251 */       serverPort = null;
/*     */     }
/* 253 */     if (serverPort == null) return;
/*     */     int _serverPort;
/*     */     try {
/* 256 */       _serverPort = Integer.parseInt(serverPort);
/*     */     } catch (NumberFormatException e) {
/* 258 */       throw new IMException(IMException.Code.INVALID_IM_SERVER_PORT);
/*     */     }
/* 260 */     if ((_serverPort < 0) || (_serverPort > 65535)) {
/* 261 */       throw new IMException(IMException.Code.INVALID_IM_SERVER_PORT);
/*     */     }
/* 263 */     this.serverPort = _serverPort;
/*     */   }

/*     */   private void setServiceName(String serviceName)
/*     */   {
/* 268 */     if ((serviceName != null) && (serviceName.trim().equals(""))) {
/* 269 */       serviceName = null;
/*     */     }
/* 271 */     this.serviceName = serviceName;
/*     */   }

/*     */   private void setUserId(String userId) throws IMException {
/* 275 */     if ((userId == null) || (userId.trim().equals(""))) {
/* 276 */       throw new IMException(IMException.Code.INVALID_ACCOUNT);
/*     */     }
/* 278 */     this.userId = userId;
/*     */   }

/*     */   private void setUserPassword(String userPassword) throws IMException
/*     */   {
/* 283 */     if (userPassword == null) {
/* 284 */       throw new IMException(IMException.Code.INVALID_ACCOUNT);
/*     */     }
/* 286 */     this.userPassword = userPassword;
/*     */   }

/*     */   private void setConnectionTimeout(String connectionTimeout) throws IMException
/*     */   {
/* 291 */     if ((connectionTimeout == null) || (connectionTimeout.trim().equals("")))
/* 292 */       return;
/*     */     try
/*     */     {
/* 295 */       long timeout = Long.parseLong(connectionTimeout);
/* 296 */       setConnectionTimeout(timeout);
/*     */     } catch (NumberFormatException e) {
/* 298 */       throw new IMException(IMException.Code.INVALID_CON_TIMEOUT, "Invalid " + IMDriver.RequiredProperties.CONNECTION_TIMEOUT + " property");
/*     */     }
/*     */   }

/*     */   private void setResolveTimeout(String resolveTimeout)
/*     */     throws IMException
/*     */   {
/* 305 */     if ((resolveTimeout == null) || (resolveTimeout.trim().equals("")))
/* 306 */       return;
/*     */     try
/*     */     {
/* 309 */       long timeout = Long.parseLong(resolveTimeout);
/* 310 */       setResolveTimeout(timeout);
/*     */     } catch (NumberFormatException e) {
/* 312 */       throw new IMException(IMException.Code.INVALID_RESOLVE_TIMEOUT, "Invalid " + IMDriver.RequiredProperties.RESOLVE_TIMEOUT + " property");
/*     */     }
/*     */   }

/*     */   private void setIMUser(IMUser imUser)
/*     */     throws IMException
/*     */   {
/* 319 */     if (imUser == null) {
/* 320 */       throw new IMException(IMException.Code.INVALID_ACCOUNT, "IM user must not be null");
/*     */     }
/*     */ 
/* 323 */     this.imUser = imUser;
/*     */   }

/*     */   public String getServerHostName() {
/* 327 */     return this.serverHostName;
/*     */   }

/*     */   public int getServerPort() {
/* 331 */     return this.serverPort;
/*     */   }

/*     */   public String getServiceName() {
/* 335 */     return this.serviceName;
/*     */   }

/*     */   public String getSessionName() {
/* 339 */     return null;
/*     */   }

/*     */   public String getUserId() {
/* 343 */     return this.userId;
/*     */   }

/*     */   public String getUserPassword() {
/* 347 */     return this.userPassword;
/*     */   }

/*     */   public IMUser getIMUser() {
/* 351 */     return this.imUser;
/*     */   }

/*     */   public IMMessageHandler createMessageHandler(IMUser partner) throws IMException
/*     */   {
/* 356 */     if (!(this.isOpened)) {
/* 357 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/*     */ 
/* 360 */     IMMessageHandler messageHandler = new IMMessageHandlerMocImpl(this, partner);
/* 361 */     if (this.messageHandlerList == null) {
/* 362 */       this.messageHandlerList = new ArrayList();
/*     */     }
/* 364 */     this.messageHandlerList.add((IMMessageHandlerMocImpl)messageHandler);
/* 365 */     return messageHandler;
/*     */   }


/*     */   public IMResolveHandler createResolveHandler(boolean onlyUnique, boolean exhaustiveLookup)
/*     */     throws IMException
/*     */   {
/* 372 */     return null; }

/*     */   public IMMessageHandlerMocImpl getMessageHandler(String userId) {
/* 375 */     IMMessageHandlerMocImpl messageHandler = null;
/* 376 */     for (int i = 0; i < this.messageHandlerList.size(); ++i) {
/* 377 */       messageHandler = (IMMessageHandlerMocImpl)this.messageHandlerList.get(i);
/* 378 */       if (messageHandler.getIMPartner().getUserId().equals(userId)) {
/* 379 */         return messageHandler;
/*     */       }
/*     */     }
/* 382 */     return null;
/*     */   }

/*     */   public IMUserStatusHandler createUserStatusHandler() throws IMException {
/* 386 */     if (!(this.isOpened)) {
/* 387 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 389 */     this.userStatusHandler = new IMUserStatusHandlerMocImpl(this);
/* 390 */     return this.userStatusHandler;
/*     */   }

/*     */   public long getConnectionTimeout()
/*     */   {
/* 395 */     return this.connectionTimeout;
/*     */   }

/*     */   public long getDefaultConnectionTimeout()
/*     */   {
/* 400 */     return 20000L;
/*     */   }

/*     */   public long getDefaultResolveTimeout()
/*     */   {
/* 405 */     return 10000L;
/*     */   }

/*     */   public long getResolveTimeout()
/*     */   {
/* 410 */     return this.resolveTimeout;
/*     */   }

/*     */   public boolean isOpened() {
/* 414 */     return (getTicket() != null);
/*     */   }

/*     */   public IMResolveEvent resolve(String userDisplayName, boolean onlyUnique, boolean exhaustiveLookup)
/*     */     throws IMException
/*     */   {
/* 420 */     if (!(this.isOpened)) {
/* 421 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 423 */     if ((userDisplayName == null) || (userDisplayName.trim().equals(""))) {
/* 424 */       return new IMResolveEvent(this, this, userDisplayName, IMResolveEvent.ResultType.NOT_RESOLVED, null);

/*     */     }
/*     */ 
/* 428 */     List imUsers = null;
/* 429 */     IMResolveEvent.ResultType resultType = IMResolveEvent.ResultType.RESOLVED;
/*     */ 
/* 431 */     IMUser imUser = IMUserMocImpl.createIMUser(userDisplayName, userDisplayName);
/* 432 */     imUsers = new ArrayList();
/* 433 */     imUsers.add(imUser);
/*     */ 
/* 435 */     IMResolveEvent imResolveEvent = new IMResolveEvent(this, this, userDisplayName, resultType, imUsers);
/*     */ 
/* 437 */     return imResolveEvent;
/*     */   }

/*     */   public IMUser resolve(String userDisplayName) throws IMException {
/*     */     IMResolveEvent imResolveEvent;
/*     */     try {
/* 443 */       imResolveEvent = resolve(userDisplayName, true, false);
/*     */     } catch (IMException e) {
/* 445 */       return null;
/*     */     }
/* 447 */     IMUser imUser = imResolveEvent.getResolvedUser();
/* 448 */     if ((!(this.listenedUsers.contains(userDisplayName))) && (userDisplayName != "")) {
/* 449 */       this.listenedUsers.add(userDisplayName);
/*     */     }
/* 451 */     return imUser;
/*     */   }

/*     */   public void setConnectionTimeout(long timeout) {
/* 455 */     this.connectionTimeout = timeout;
/*     */   }

/*     */   public void setResolveTimeout(long timeout) {
/* 459 */     this.resolveTimeout = timeout;
/*     */   }

/*     */   public IMUserStatusHandler getUserStatusHandler()
/*     */   {
/* 464 */     return this.userStatusHandler;
/*     */   }

/*     */   public void setUserStatusHandler(IMUserStatusHandler userStatusHandler) {
/* 468 */     this.userStatusHandler = userStatusHandler;
/*     */   }

/*     */   public int getAckId() {
/* 472 */     return this.ackId;
/*     */   }

/*     */   public void setAckId(int ackId) {
/* 476 */     this.ackId = ackId;
/*     */   }



















/*     */   public String getPartnerConferenceId(String partnerId)
/*     */   {
/* 499 */     return ((String)this.partnerConferenceId.get(partnerId));
/*     */   }




/*     */   public void removePartnerConferenceId(String partnerId)
/*     */   {
/* 507 */     this.partnerConferenceId.remove(partnerId);
/*     */   }





/*     */   public void addPartnerConferenceId(String partnerId, String confId)
/*     */   {
/* 516 */     this.partnerConferenceId.put(partnerId, confId);
/*     */   }





/*     */   public IMMessageHandlerMocImpl getPartnerHandlerByConferenceId(String confId)
/*     */   {
/* 525 */     Set partnerConferenceId = this.partnerConferenceId.keySet();
/* 526 */     Iterator It = partnerConferenceId.iterator();
/* 527 */     while (It.hasNext())
/*     */     {
/* 529 */       String partner = (String)It.next();
/* 530 */       String conferenceId = this.partnerConferenceId.get(partner).toString();
/* 531 */       IMMessageHandlerMocImpl messageHandler = null;
/* 532 */       if (conferenceId.equals(confId)) {
/* 533 */         for (int i = 0; i < this.messageHandlerList.size(); ++i) {
/* 534 */           messageHandler = (IMMessageHandlerMocImpl)this.messageHandlerList.get(i);
/*     */ 
/* 536 */           if (messageHandler.getIMPartner().getUserId().equals(partner)) {
/* 537 */             return messageHandler;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 543 */     return null;
/*     */   }
/*     */ }
