/*    */ package com.ibm.tivoli.imi.drivers.moc2007;
/*    */ 
/*    */ import com.ibm.tivoli.imi.spi.IMException;
/*    */ import com.ibm.tivoli.imi.spi.IMUser;
/*    */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*    */ import com.ibm.tivoli.imi.spi.IMUserStatusEvent;
/*    */ import com.ibm.tivoli.imi.spi.IMUserStatusHandler;
/*    */ import com.ibm.tivoli.imi.spi.IMUserStatusListener;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 


















/*    */ public class IMUserStatusHandlerMocImpl
/*    */   implements IMUserStatusHandler
/*    */ {
/*    */   private Set<IMUserStatusListener> listeners;
/*    */   private IMSessionMocImpl session;
/*    */ 
/*    */   public IMUserStatusHandlerMocImpl(IMSessionMocImpl session)
/*    */   {
/* 38 */     setSession(session);
/* 39 */     this.listeners = new HashSet();
/*    */   }

/*    */   private void setSession(IMSessionMocImpl session)
/*    */   {
/* 44 */     if (session == null) {
/* 45 */       throw new IllegalArgumentException("Session must not be null");
/*    */     }
/* 47 */     this.session = session;
/*    */   }






/*    */   public void addListener(IMUserStatusListener userStatusListener) throws IMException
/*    */   {
/* 57 */     this.listeners.add(userStatusListener);
/*    */   }

/*    */   public boolean hasListenedUser(IMUser imuser) throws IMException
/*    */   {
/* 62 */     return false;
/*    */   }





/*    */   public void removeAllListeners()
/*    */   {
/* 71 */     this.listeners.clear();
/*    */   }






/*    */   public void removeListener(IMUserStatusListener userStatusListener)
/*    */   {
/* 81 */     this.listeners.remove(userStatusListener);
/*    */   }


/*    */   public void userStatusChange(IMUser imUser, IMUser.IMUserStatus status)
/*    */   {
/* 87 */     IMUserStatusEvent userStatusEvent = new IMUserStatusEvent(this, this.session, imUser, status);
/* 88 */     for (IMUserStatusListener listener : this.listeners)
/* 89 */       listener.userStatusChanged(userStatusEvent);
/*    */   }
/*    */ }
