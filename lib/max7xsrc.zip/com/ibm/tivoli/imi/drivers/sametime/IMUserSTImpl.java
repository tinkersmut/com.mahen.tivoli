/*     */ package com.ibm.tivoli.imi.drivers.sametime;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import com.lotus.sametime.core.types.STUser;
/*     */ import com.lotus.sametime.core.types.STUserStatus;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 















/*     */ public class IMUserSTImpl
/*     */   implements IMUser
/*     */ {
/*     */   private String displayName;
/*     */   private String userId;
/*     */ 
/*     */   IMUserSTImpl(String userId, String displayName)
/*     */   {
/*  33 */     setUserId(userId);
/*  34 */     setDisplayName(displayName);
/*     */   }

/*     */   private void setDisplayName(String displayName) {
/*  38 */     if ((displayName == null) || (displayName.trim().equals(""))) {
/*  39 */       throw new IllegalArgumentException("Display name must not be null");
/*     */     }
/*  41 */     this.displayName = displayName;
/*     */   }

/*     */   private void setUserId(String userId) {
/*  45 */     if ((userId == null) || (userId.trim().equals(""))) {
/*  46 */       throw new IllegalArgumentException("User id must not be null");
/*     */     }
/*  48 */     this.userId = userId;
/*     */   }

/*     */   public String getDisplayName() {
/*  52 */     return this.displayName;
/*     */   }

/*     */   public String getUserId() {
/*  56 */     return this.userId;
/*     */   }

/*     */   static IMUser createIMUser(STUser stUser) {
/*  60 */     String userId = stUser.getName();
/*  61 */     String displayName = stUser.getDisplayName();
/*  62 */     IMUser imUser = new IMUserSTImpl(userId, displayName);
/*  63 */     return imUser;
/*     */   }

/*     */   static List<IMUser> createIMUser(STUser[] stUsers) {
/*  67 */     List imUsers = new ArrayList();

/*     */ 
/*  70 */     for (STUser stUser : stUsers) {
/*  71 */       String userId = stUser.getName();
/*  72 */       String displayName = stUser.getDisplayName();
/*  73 */       IMUser imUser = new IMUserSTImpl(userId, displayName);
/*  74 */       imUsers.add(imUser);
/*     */     }
/*  76 */     return imUsers;
/*     */   }

/*     */   public static IMUser.IMUserStatus getIMStatus(STUserStatus status) {
/*  80 */     IMUser.IMUserStatus imUserStatus = null;
/*  81 */     switch (status.getStatusType())
/*     */     {/*     */     case 32:
/*  83 */       imUserStatus = IMUser.IMUserStatus.AVAILABLE;
/*  84 */       break;
/*     */     case 544:
/*  86 */       imUserStatus = IMUser.IMUserStatus.MOBILE;
/*  87 */       break;
/*     */     case 96:
/*  89 */       imUserStatus = IMUser.IMUserStatus.AWAY;
/*  90 */       break;
/*     */     case 128:
/*  92 */       imUserStatus = IMUser.IMUserStatus.DONT_DISTURB;
/*  93 */       break;
/*     */     case 8:
/*  95 */       imUserStatus = IMUser.IMUserStatus.IN_A_MEETING;
/*  96 */       break;
/*     */     case 0:
/*  98 */       imUserStatus = IMUser.IMUserStatus.OFFLINE;
/*  99 */       break;
/*     */     default:
/* 101 */       imUserStatus = IMUser.IMUserStatus.UNKNOW;
/*     */     }
/*     */ 
/* 104 */     return imUserStatus;
/*     */   }
/*     */ }
