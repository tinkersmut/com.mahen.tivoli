/*     */ package com.ibm.tivoli.imi.drivers.sametime;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusListener;
/*     */ import com.lotus.sametime.awareness.AwarenessService;
/*     */ import com.lotus.sametime.awareness.STWatchedUser;
/*     */ import com.lotus.sametime.awareness.StatusEvent;
/*     */ import com.lotus.sametime.awareness.StatusListener;
/*     */ import com.lotus.sametime.awareness.WatchList;
/*     */ import com.lotus.sametime.core.types.STUser;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 

















/*     */ public class IMUserStatusHandlerSTImpl
/*     */   implements IMUserStatusHandler, StatusListener
/*     */ {
/*     */   private Map<String, STUser> listenedUsers;
/*     */   private Set<IMUserStatusListener> listeners;
/*     */   private IMSessionSTImpl session;
/*     */   private WatchList watchList;
/*     */ 
/*     */   public IMUserStatusHandlerSTImpl(IMSessionSTImpl session, AwarenessService awarenessService)
/*     */   {
/*  47 */     setSession(session);
/*  48 */     createWatchList(awarenessService);
/*  49 */     this.listenedUsers = new HashMap();
/*  50 */     this.listeners = new HashSet();
/*     */   }

/*     */   private void setSession(IMSessionSTImpl session) {
/*  54 */     if (session == null) {
/*  55 */       throw new IllegalArgumentException("Session must not be null");
/*     */     }
/*  57 */     this.session = session;
/*     */   }

/*     */   private void createWatchList(AwarenessService awarenessService) {
/*  61 */     if (awarenessService == null) {
/*  62 */       throw new IllegalArgumentException("Awareness service must not be null");
/*     */     }
/*  64 */     this.watchList = awarenessService.createWatchList();
/*  65 */     this.watchList.addStatusListener(this);
/*     */   }

/*     */   public void addListener(IMUserStatusListener userStatusListener) throws IMException {
/*  69 */     verifyAwarenessService();
/*  70 */     this.listeners.add(userStatusListener);
/*     */   }

/*     */   public void removeListener(IMUserStatusListener userStatusListener) {
/*  74 */     this.listeners.remove(userStatusListener);
/*     */   }

/*     */   public void removeAllListeners() {
/*  78 */     this.listeners.clear();
/*     */   }

/*     */   public synchronized boolean hasListenedUser(IMUser imUser) throws IMException {
/*  82 */     return this.listenedUsers.containsKey(imUser.getDisplayName());
/*     */   }

/*     */   public synchronized void addListenedUser(IMUser imUser) throws IMException {
/*  86 */     verifyAwarenessService();
/*  87 */     if (this.listenedUsers.containsKey(imUser.getDisplayName())) {
/*  88 */       return;
/*     */     }
/*  90 */     STUser stUser = this.session.resolveSTUser(imUser.getDisplayName());
/*  91 */     this.watchList.addItem(stUser);
/*  92 */     this.listenedUsers.put(stUser.getDisplayName(), stUser);
/*     */   }

/*     */   public synchronized void removeListenedUser(IMUser imUser) {
/*  96 */     STUser stUser = (STUser)this.listenedUsers.remove(imUser.getDisplayName());
/*  97 */     if (stUser != null)
/*  98 */       this.watchList.removeItem(stUser);
/*     */   }

/*     */   public synchronized void removeAllListenedUsers()
/*     */   {
/* 103 */     this.watchList.reset();
/* 104 */     this.listenedUsers.clear();
/*     */   }





/*     */   public void userStatusChanged(StatusEvent event) {
/* 112 */     STWatchedUser[] users = event.getWatchedUsers();
/*     */     IMUserStatusEvent userStatusEvent;/* 113 */     for (STWatchedUser user : users) {
/* 114 */       userStatusEvent = createIMUserStatusEvent(user);
/* 115 */       for (IMUserStatusListener listener : this.listeners)
/* 116 */         listener.userStatusChanged(userStatusEvent);
/*     */     }
/*     */   }

/*     */   private IMUserStatusEvent createIMUserStatusEvent(STWatchedUser user)
/*     */   {
/* 122 */     IMUser imUser = new IMUserSTImpl(user.getName(), user.getDisplayName());
/* 123 */     IMUser.IMUserStatus imUserStatus = IMUserSTImpl.getIMStatus(user.getStatus());
/* 124 */     IMUserStatusEvent userStatusEvent = new IMUserStatusEvent(this, this.session, imUser, imUserStatus);
/* 125 */     return userStatusEvent;
/*     */   }

/*     */   private void verifyAwarenessService() throws IMException {
/* 129 */     if (this.watchList == null)
/* 130 */       throw new IMException("IM awareness service not available");
/*     */   }

/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/* 136 */     super.finalize();
/* 137 */     if (this.watchList != null)
/* 138 */       this.watchList.close();
/*     */   }
/*     */ }
