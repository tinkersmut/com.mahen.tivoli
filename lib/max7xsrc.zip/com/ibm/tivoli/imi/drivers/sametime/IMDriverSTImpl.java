/*    */ package com.ibm.tivoli.imi.drivers.sametime;
/*    */ 
/*    */ import com.ibm.tivoli.imi.spi.IMDriver;
/*    */ import com.ibm.tivoli.imi.spi.IMDriverManager;
/*    */ import com.ibm.tivoli.imi.spi.IMException;
/*    */ import com.ibm.tivoli.imi.spi.IMSession;
/*    */ 





























/*    */ public class IMDriverSTImpl extends IMDriver
/*    */ {
/*    */   private static final String IM_PRODUCT_NAME = "ibm_sametime";
/*    */ 
/*    */   public String getIMProductName()
/*    */   {
/* 43 */     return "ibm_sametime";
/*    */   }

/*    */   public IMSession createSession() {
/* 47 */     return new IMSessionSTImpl();
/*    */   }

/*    */   public String[] getOptionalProperties() {
/* 51 */     String[] values = new String[OptionalProperties.values().length];
/* 52 */     int i = 0;
/* 53 */     for (OptionalProperties op : OptionalProperties.values()) {
/* 54 */       values[i] = op.name();
/* 55 */       ++i;
/*    */     }
/* 57 */     return values;
/*    */   }
/*    */ 
/*    */   static {
/*    */     try {
/* 62 */       IMDriverManager.registerIMDriver(new IMDriverSTImpl());
/*    */     } catch (IMException e) {
/* 64 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static enum OptionalProperties
/*    */   {
/* 31 */     COMMUNITY;
/*    */   }
/*    */ }
