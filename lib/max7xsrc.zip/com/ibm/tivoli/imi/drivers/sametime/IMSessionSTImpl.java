/*     */ package com.ibm.tivoli.imi.drivers.sametime;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMDriver.RequiredProperties;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveEvent.ResultType;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMSession;
/*     */ import com.ibm.tivoli.imi.spi.IMSingleListener;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusHandler;
/*     */ import com.lotus.sametime.awareness.AwarenessService;
/*     */ import com.lotus.sametime.community.CommunityService;
/*     */ import com.lotus.sametime.community.Login;
/*     */ import com.lotus.sametime.community.LoginEvent;
/*     */ import com.lotus.sametime.community.LoginListener;
/*     */ import com.lotus.sametime.core.comparch.DuplicateObjectException;
/*     */ import com.lotus.sametime.core.comparch.STSession;
/*     */ import com.lotus.sametime.core.types.STUser;
/*     */ import com.lotus.sametime.core.types.STUserStatus;
/*     */ import com.lotus.sametime.im.InstantMessagingService;
/*     */ import com.lotus.sametime.lookup.LookupService;
/*     */ import com.lotus.sametime.lookup.ResolveEvent;
/*     */ import com.lotus.sametime.lookup.Resolver;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 



















/*     */ public class IMSessionSTImpl
/*     */   implements IMSession, LoginListener
/*     */ {
/*     */   private String serverHostName;
/*     */   private String userId;
/*     */   private String userPassword;
/*     */   private String community;
/*  54 */   private IMUser imUser = null;
/*  55 */   private long connectionTimeout = 20000L;
/*  56 */   private long resolveTimeout = 10000L;
/*  57 */   private boolean isOpened = false;
/*     */   private STSession stSession;
/*     */   private CommunityService commService;
/*     */   private InstantMessagingService imService;
/*     */   private AwarenessService awarenessService;
/*     */   private LookupService lookupService;
/*  64 */   private Object openLock = new Object();
/*     */   private int connectionFailureCode;
/*     */   private List<IMMessageHandlerSTImpl> messageHandlerList;
/*     */   private static final long DEFAULT_CONNECTION_TIMEOUT = 20000L;
/*     */   private static final long DEFAULT_RESOLVE_TIMEOUT = 10000L;
/*     */   private static final long MIN_CONNECTION_TIMEOUT = 10000L;
/*     */   private static final long MIN_RESOLVE_TIMEOUT = 10000L;
/*     */   private static final int DEFAULT_SAMETIME_SERVER_TCP_PORT = 1533;
/*     */ 
/*     */   public void configure(Properties properties)
/*     */     throws IMException
/*     */   {
/*  79 */     String serverHostName = properties.getProperty(IMDriver.RequiredProperties.SERVER_HOSTNAME.toString());
/*     */ 
/*  81 */     String userId = properties.getProperty(IMDriver.RequiredProperties.USER_ID.toString());
/*  82 */     String userPassword = properties.getProperty(IMDriver.RequiredProperties.USER_PASSWORD.toString());
/*     */ 
/*  84 */     String community = properties.getProperty(IMDriverSTImpl.OptionalProperties.COMMUNITY.toString());
/*  85 */     String connectionTimeout = properties.getProperty(IMDriver.RequiredProperties.CONNECTION_TIMEOUT.toString());
/*     */ 
/*  87 */     String resolveTimeout = properties.getProperty(IMDriver.RequiredProperties.RESOLVE_TIMEOUT.toString());

/*     */ 
/*  90 */     setServerHostName(serverHostName);
/*  91 */     setUserId(userId);
/*  92 */     setUserPassword(userPassword);
/*  93 */     setCommunity(community);
/*  94 */     setConnectionTimeout(connectionTimeout);
/*  95 */     setResolveTimeout(resolveTimeout);
/*     */     try {
/*  97 */       this.stSession = new STSession();
/*     */     } catch (DuplicateObjectException e) {
/*  99 */       throw new IMException("It was not possible to create a new Sametime IM session (duplicated session name)", e);
/*     */     }
/*     */ 
/* 102 */     this.stSession.loadSemanticComponents();
/*     */   }

/*     */   private void setServerHostName(String serverHostName) throws IMException {
/* 106 */     if ((serverHostName == null) || (serverHostName.trim().equals(""))) {
/* 107 */       throw new IMException(IMException.Code.INVALID_IM_SERVER);
/*     */     }
/* 109 */     this.serverHostName = serverHostName;
/*     */   }

/*     */   private void setUserId(String userId) throws IMException {
/* 113 */     if ((userId == null) || (userId.trim().equals(""))) {
/* 114 */       throw new IMException(IMException.Code.INVALID_ACCOUNT);
/*     */     }
/* 116 */     this.userId = userId;
/*     */   }

/*     */   private void setUserPassword(String userPassword) throws IMException {
/* 120 */     if (userPassword == null) {
/* 121 */       throw new IMException(IMException.Code.INVALID_ACCOUNT);
/*     */     }
/* 123 */     this.userPassword = userPassword;
/*     */   }

/*     */   private void setCommunity(String community) {
/* 127 */     if ((community != null) && (community.trim().equals(""))) {
/* 128 */       community = null;
/*     */     }
/* 130 */     this.community = community;
/*     */   }

/*     */   private void setConnectionTimeout(String connectionTimeout) throws IMException {
/* 134 */     if ((connectionTimeout == null) || (connectionTimeout.trim().equals("")))
/* 135 */       return;
/*     */     try
/*     */     {
/* 138 */       long timeout = Long.parseLong(connectionTimeout);
/* 139 */       setConnectionTimeout(timeout);
/*     */     } catch (NumberFormatException e) {
/* 141 */       throw new IMException(IMException.Code.INVALID_CON_TIMEOUT, "Invalid " + IMDriver.RequiredProperties.CONNECTION_TIMEOUT + " Sametime property");
/*     */     }
/*     */   }

/*     */   private void setResolveTimeout(String resolveTimeout)
/*     */     throws IMException
/*     */   {
/* 148 */     if ((resolveTimeout == null) || (resolveTimeout.trim().equals("")))
/* 149 */       return;
/*     */     try
/*     */     {
/* 152 */       long timeout = Long.parseLong(resolveTimeout);
/* 153 */       setResolveTimeout(timeout);
/*     */     } catch (NumberFormatException e) {
/* 155 */       throw new IMException(IMException.Code.INVALID_RESOLVE_TIMEOUT, "Invalid " + IMDriver.RequiredProperties.RESOLVE_TIMEOUT + " Sametime property");
/*     */     }
/*     */   }

/*     */   private void setIMUser(IMUser imUser)
/*     */     throws IMException
/*     */   {
/* 162 */     if (imUser == null) {
/* 163 */       throw new IMException(IMException.Code.INVALID_ACCOUNT, "IM user must not be null");
/*     */     }
/* 165 */     this.imUser = imUser;
/*     */   }

/*     */   public String getServerHostName() {
/* 169 */     return this.serverHostName;
/*     */   }

/*     */   public int getServerPort() {
/* 173 */     return 1533;
/*     */   }






/*     */   public String getSessionName()
/*     */   {
/* 183 */     return this.stSession.toString();
/*     */   }

/*     */   public String getUserId() {
/* 187 */     return this.userId;
/*     */   }

/*     */   public String getUserPassword() {
/* 191 */     return this.userPassword;
/*     */   }

/*     */   public String getCommunity() {
/* 195 */     return this.community;
/*     */   }

/*     */   public IMUser getIMUser() {
/* 199 */     return this.imUser;
/*     */   }

/*     */   public void open() throws IMException {
/* 203 */     this.stSession.start();
/*     */ 
/* 205 */     this.commService = ((CommunityService)this.stSession.getCompApi("com.lotus.sametime.community.STBase"));
/* 206 */     this.commService.addLoginListener(this);
/* 207 */     this.commService.loginByPassword(this.serverHostName, this.userId, this.userPassword, this.community);
/* 208 */     this.lookupService = ((LookupService)this.stSession.getCompApi("com.lotus.sametime.lookup.LookupComp"));
/* 209 */     this.awarenessService = ((AwarenessService)this.stSession.getCompApi("com.lotus.sametime.awareness.AwarenessComp"));
/* 210 */     this.imService = ((InstantMessagingService)this.stSession.getCompApi("com.lotus.sametime.im.ImComp"));
/* 211 */     this.imService.registerImType(1);
/*     */ 
/* 213 */     synchronized (this.openLock) {
/*     */       try {
/* 215 */         this.openLock.wait(this.connectionTimeout);
/*     */       } catch (InterruptedException e) {
/* 217 */         throw new IMException("It was not possible to connect to Sametime server due to a internal error", e);
/*     */       }
/*     */     }
/* 220 */     if (this.isOpened)

/*     */       return;
/*     */     IMException.Code code;
/* 224 */     switch (this.connectionFailureCode)
/*     */     {/*     */     case -2147483129:
/* 226 */       code = IMException.Code.INVALID_IM_SERVER;
/* 227 */       break;
/*     */     case -2147483119:
/* 229 */       code = IMException.Code.INVALID_ACCOUNT;
/* 230 */       break;
/*     */     default:
/* 232 */       code = IMException.Code.CONNECTION_TIMEOUT;
/*     */     }
/*     */ 
/* 235 */     throw new IMException(code);
/*     */   }

/*     */   public void changeUserStatus(IMUser.IMUserStatus imUserStatus) throws IMException
/*     */   {
/* 240 */     if (!(this.isOpened)) {
/* 241 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 243 */     if (imUserStatus == null) {
/* 244 */       throw new IllegalArgumentException("Invalid IM user status");
/*     */     }
/* 246 */     Login login = this.commService.getLogin();
/* 247 */     STUserStatus stUserStatus = login.getMyStatus();
/* 248 */     setNewStatus(stUserStatus, imUserStatus);
/* 249 */     login.changeMyStatus(stUserStatus);
/*     */   }

/*     */   private void setNewStatus(STUserStatus currentStatus, IMUser.IMUserStatus newStatus) {
/* 253 */     short _newStatus = 0;
/* 254 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$spi$IMUser$IMUserStatus[newStatus.ordinal()])
/*     */     {/*     */     case 1:
/* 256 */       _newStatus = 32;
/* 257 */       break;
/*     */     case 2:
/* 259 */       _newStatus = 96;
/* 260 */       break;
/*     */     case 3:
/* 262 */       _newStatus = 128;
/* 263 */       break;
/*     */     case 4:
/* 265 */       _newStatus = 8;
/* 266 */       break;
/*     */     case 5:
/* 268 */       _newStatus = 512;
/* 269 */       break;
/*     */     case 6:
/* 271 */       _newStatus = 0;
/* 272 */       break;
/*     */     case 7:
/* 274 */       _newStatus = -32768;
/*     */     }
/*     */ 
/* 277 */     currentStatus.setStatusType(_newStatus);
/*     */   }

/*     */   public void close() throws IMException {
/* 281 */     if (this.isOpened) {
/* 282 */       if (this.messageHandlerList != null)
/*     */       {
/* 284 */         for (int i = this.messageHandlerList.size() - 1; i >= 0; --i) {
/* 285 */           IMMessageHandlerSTImpl messageHandler = (IMMessageHandlerSTImpl)this.messageHandlerList.remove(i);
/* 286 */           if (messageHandler.isOpened()) {
/* 287 */             messageHandler.closeConversation();
/*     */           }
/*     */         }
/*     */       }
/* 291 */       this.commService.logout();
/* 292 */       this.stSession.stop();
/* 293 */       this.stSession.unloadSession();
/* 294 */       this.isOpened = false;
/*     */     }
/*     */   }

/*     */   public void loggedIn(LoginEvent stEvent) {
/* 299 */     this.isOpened = true;
/* 300 */     createIMUser(stEvent);
/* 301 */     synchronized (this.openLock) {
/* 302 */       this.openLock.notify();
/*     */     }
/*     */   }

/*     */   public void loggedOut(LoginEvent stEvent) {
/* 307 */     this.isOpened = false;
/* 308 */     this.connectionFailureCode = stEvent.getReason();
/* 309 */     synchronized (this.openLock) {
/* 310 */       this.openLock.notify();
/*     */     }
/*     */   }

/*     */   private void createIMUser(LoginEvent stEvent) {
/* 315 */     if (this.imUser != null) return;
/*     */     try {
/* 317 */       STUser stUser = stEvent.getLogin().getMyUserInstance();
/* 318 */       IMUser imUser = IMUserSTImpl.createIMUser(stUser);
/* 319 */       setIMUser(imUser);
/*     */     } catch (IMException e) {
/* 321 */       e.printStackTrace();
/*     */     }
/*     */   }

/*     */   public boolean isOpened()
/*     */   {
/* 327 */     return this.isOpened;
/*     */   }

/*     */   public IMResolveHandler createResolveHandler(boolean onlyUnique, boolean exhaustiveLookup) throws IMException {
/* 331 */     if (!(this.isOpened)) {
/* 332 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 334 */     Resolver resolver = this.lookupService.createResolver(onlyUnique, exhaustiveLookup, true, false);
/* 335 */     IMResolveHandler resolverHandler = new IMResolveHandlerSTImpl(this, resolver);
/* 336 */     return resolverHandler;
/*     */   }

/*     */   public IMUserStatusHandler createUserStatusHandler() throws IMException {
/* 340 */     if (!(this.isOpened)) {
/* 341 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 343 */     IMUserStatusHandler userStatusHandler = new IMUserStatusHandlerSTImpl(this, this.awarenessService);
/* 344 */     return userStatusHandler;
/*     */   }

/*     */   public IMMessageHandler createMessageHandler(IMUser partner) throws IMException {
/* 348 */     if (!(this.isOpened)) {
/* 349 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 351 */     STUser stPartner = resolveSTUser(partner.getDisplayName());
/* 352 */     IMMessageHandler messageHandler = new IMMessageHandlerSTImpl(this, this.imService, partner, stPartner);
/* 353 */     if (this.messageHandlerList == null) {
/* 354 */       this.messageHandlerList = new ArrayList();
/*     */     }
/* 356 */     this.messageHandlerList.add((IMMessageHandlerSTImpl)messageHandler);
/* 357 */     return messageHandler;
/*     */   }

/*     */   public IMResolveEvent resolve(String userDisplayName, boolean onlyUnique, boolean exhaustiveLookup) throws IMException
/*     */   {
/* 362 */     if (!(this.isOpened)) {
/* 363 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 365 */     if ((userDisplayName == null) || (userDisplayName.trim().equals(""))) {
/* 366 */       return new IMResolveEvent(this, this, userDisplayName, IMResolveEvent.ResultType.NOT_RESOLVED, null);
/*     */     }
/* 368 */     ResolveEvent resolveEvent = resolveSTUser(userDisplayName, onlyUnique, exhaustiveLookup);
/* 369 */     IMResolveEvent.ResultType resultType = IMResolveEvent.ResultType.NOT_RESOLVED;
/* 370 */     List imUsers = null;
/* 371 */     if (resolveEvent.getResolvedList() != null) {
/* 372 */       resultType = IMResolveEvent.ResultType.RESOLVE_CONFLICT;
/* 373 */       STUser[] stUsers = (STUser[])(STUser[])resolveEvent.getResolvedList();
/* 374 */       imUsers = IMUserSTImpl.createIMUser(stUsers);
/* 375 */     } else if (resolveEvent.getResolved() != null) {
/* 376 */       resultType = IMResolveEvent.ResultType.RESOLVED;
/* 377 */       STUser stUser = (STUser)resolveEvent.getResolved();
/* 378 */       IMUser imUser = IMUserSTImpl.createIMUser(stUser);
/* 379 */       imUsers = new ArrayList();
/* 380 */       imUsers.add(imUser);
/*     */     }
/* 382 */     IMResolveEvent imResolveEvent = new IMResolveEvent(this, this, userDisplayName, resultType, imUsers);
/* 383 */     return imResolveEvent;
/*     */   }

/*     */   public IMUser resolve(String userDisplayName) throws IMException, IMException {
/*     */     IMResolveEvent imResolveEvent;
/*     */     try {
/* 389 */       imResolveEvent = resolve(userDisplayName, true, false);
/*     */     } catch (IMException e) {
/* 391 */       return null;
/*     */     }
/* 393 */     IMUser imUser = imResolveEvent.getResolvedUser();
/* 394 */     return imUser;
/*     */   }

/*     */   synchronized STUser resolveSTUser(String userDisplayName) throws IMException {
/* 398 */     ResolveEvent resolveEvent = resolveSTUser(userDisplayName, true, false);
/* 399 */     STUser stUser = (STUser)resolveEvent.getResolved();
/* 400 */     if (stUser == null) {
/* 401 */       throw new IMException(IMException.Code.RESOLVE_EXCEPTION, userDisplayName);
/*     */     }
/* 403 */     return stUser;
/*     */   }

/*     */   private synchronized ResolveEvent resolveSTUser(String userDisplayName, boolean onlyUnique, boolean exhaustiveLookup) throws IMException
/*     */   {
/* 408 */     if (!(this.isOpened)) {
/* 409 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 411 */     Resolver resolver = this.lookupService.createResolver(onlyUnique, exhaustiveLookup, true, false);
/* 412 */     Object resolveLock = new Object();
/* 413 */     STUserGetter stUserGetter = new STUserGetter(resolveLock, resolver, userDisplayName);
/* 414 */     Thread thread = new Thread(stUserGetter);
/* 415 */     thread.start();
/*     */ 
/* 417 */     synchronized (resolveLock) {
/*     */       try {
/* 419 */         resolveLock.wait(this.resolveTimeout);
/*     */       } catch (InterruptedException e) {
/* 421 */         throw new IMException("It was not possible to connect to Sametime server due to a internal error", e);
/*     */       }
/*     */     }
/*     */ 
/* 425 */     ResolveEvent resolveEvent = stUserGetter.getResolveEvent();
/* 426 */     if (resolveEvent == null) {
/* 427 */       throw new IMException(IMException.Code.RESOLVE_EXCEPTION, "Resolve timeout for user " + userDisplayName + " is over");
/*     */     }
/*     */ 
/* 430 */     return resolveEvent;
/*     */   }

/*     */   public long getDefaultConnectionTimeout() {
/* 434 */     return 20000L;
/*     */   }

/*     */   public void setConnectionTimeout(long timeout) {
/* 438 */     if (timeout < 10000L) {
/* 439 */       throw new IllegalArgumentException("Connection timeout must not be less than 10000");
/*     */     }
/* 441 */     this.connectionTimeout = timeout;
/*     */   }

/*     */   public long getConnectionTimeout() {
/* 445 */     return this.connectionTimeout;
/*     */   }

/*     */   public long getDefaultResolveTimeout() {
/* 449 */     return 10000L;
/*     */   }

/*     */   public synchronized void setResolveTimeout(long timeout) {
/* 453 */     if (timeout < 10000L) {
/* 454 */       throw new IllegalArgumentException("Resolve timeout must not be less than 10000");
/*     */     }
/* 456 */     this.resolveTimeout = timeout;
/*     */   }

/*     */   public long getResolveTimeout() {
/* 460 */     return this.resolveTimeout;
/*     */   }
/*     */ 
/*     */   public void registerIMSingleListener(IMSingleListener listener)
/*     */     throws IMException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void removeIMSingleListener(IMSingleListener listener)
/*     */     throws IMException
/*     */   {
/*     */   }
/*     */ }
