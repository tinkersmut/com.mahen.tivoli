/*     */ package com.ibm.tivoli.imi.drivers.sametime;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMResolveEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveEvent.ResultType;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveListener;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.lotus.sametime.core.types.STUser;
/*     */ import com.lotus.sametime.lookup.ResolveEvent;
/*     */ import com.lotus.sametime.lookup.ResolveListener;
/*     */ import com.lotus.sametime.lookup.Resolver;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
















/*     */ public class IMResolveHandlerSTImpl
/*     */   implements IMResolveHandler, ResolveListener
/*     */ {
/*     */   private IMSessionSTImpl session;
/*     */   private Resolver resolver;
/*     */   private Set<IMResolveListener> listeners;
/*     */ 
/*     */   public IMResolveHandlerSTImpl(IMSessionSTImpl session, Resolver resolver)
/*     */   {
/*  42 */     setSession(session);
/*  43 */     setResolver(resolver);
/*  44 */     this.listeners = new HashSet();
/*     */   }

/*     */   private void setSession(IMSessionSTImpl session) {
/*  48 */     if (session == null) {
/*  49 */       throw new IllegalArgumentException("Session must not be null");
/*     */     }
/*  51 */     this.session = session;
/*     */   }

/*     */   private void setResolver(Resolver resolver) {
/*  55 */     if (resolver == null) {
/*  56 */       throw new IllegalArgumentException("Resolver must not be null");
/*     */     }
/*  58 */     resolver.addResolveListener(this);
/*  59 */     this.resolver = resolver;
/*     */   }

/*     */   public void addListener(IMResolveListener resolveListener) {
/*  63 */     this.listeners.add(resolveListener);
/*     */   }

/*     */   public void removeAllListeners() {
/*  67 */     this.listeners.clear();
/*     */   }

/*     */   public void removeListener(IMResolveListener resolveListener) {
/*  71 */     this.listeners.remove(resolveListener);
/*     */   }

/*     */   public void removeIMResolveListener(IMResolveListener resolveListener) {
/*  75 */     this.listeners.remove(resolveListener);
/*     */   }

/*     */   public void resolve(String userDisplayName) {
/*  79 */     this.resolver.resolve(userDisplayName);
/*     */   }

/*     */   public void resolveConflict(ResolveEvent stEvent) {
/*  83 */     IMResolveEvent imEvent = createIMResolveEvent(stEvent, IMResolveEvent.ResultType.RESOLVE_CONFLICT);
/*     */ 
/*  85 */     for (IMResolveListener listener : this.listeners)
/*  86 */       listener.resolved(imEvent);
/*     */   }

/*     */   public void resolveFailed(ResolveEvent stEvent)
/*     */   {
/*  91 */     IMResolveEvent imEvent = createIMResolveEvent(stEvent, IMResolveEvent.ResultType.NOT_RESOLVED);
/*     */ 
/*  93 */     for (IMResolveListener listener : this.listeners)
/*  94 */       listener.resolved(imEvent);
/*     */   }

/*     */   public void resolved(ResolveEvent stEvent)
/*     */   {
/*  99 */     IMResolveEvent imEvent = createIMResolveEvent(stEvent, IMResolveEvent.ResultType.RESOLVED);
/*     */ 
/* 101 */     for (IMResolveListener listener : this.listeners)
/* 102 */       listener.resolved(imEvent);
/*     */   }


/*     */   private IMResolveEvent createIMResolveEvent(ResolveEvent stEvent, IMResolveEvent.ResultType type)
/*     */   {
/* 108 */     IMResolveEvent imEvent = null;
/* 109 */     List imUsers = new ArrayList();
/* 110 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$spi$IMResolveEvent$ResultType[type.ordinal()])
/*     */     {/*     */     case 1:
/* 112 */       imEvent = new IMResolveEvent(this.session, this.session, stEvent.getName(), type, null);
/*     */ 
/* 114 */       break;
/*     */     case 2:
/* 116 */       STUser[] stUsers = (STUser[])(STUser[])stEvent.getResolvedList();
/* 117 */       imUsers = IMUserSTImpl.createIMUser(stUsers);
/* 118 */       imEvent = new IMResolveEvent(this.session, this.session, stEvent.getName(), type, imUsers);
/*     */ 
/* 120 */       break;
/*     */     case 3:
/* 122 */       STUser stUser = (STUser)stEvent.getResolved();
/* 123 */       IMUser imUser = IMUserSTImpl.createIMUser(stUser);
/* 124 */       imUsers.add(imUser);
/* 125 */       imEvent = new IMResolveEvent(this.session, this.session, stEvent.getName(), type, imUsers);

/*     */     }
/*     */ 
/* 129 */     return imEvent;
/*     */   }
/*     */ }
