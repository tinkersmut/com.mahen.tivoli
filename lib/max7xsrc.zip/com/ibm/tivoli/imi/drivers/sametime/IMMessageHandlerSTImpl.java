/*     */ package com.ibm.tivoli.imi.drivers.sametime;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMMessage;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageListener;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.lotus.sametime.core.constants.EncLevel;
/*     */ import com.lotus.sametime.core.constants.STError;
/*     */ import com.lotus.sametime.core.types.STUser;
/*     */ import com.lotus.sametime.im.Im;
/*     */ import com.lotus.sametime.im.ImEvent;
/*     */ import com.lotus.sametime.im.ImListener;
/*     */ import com.lotus.sametime.im.ImServiceListener;
/*     */ import com.lotus.sametime.im.InstantMessagingService;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 


















/*     */ public class IMMessageHandlerSTImpl
/*     */   implements IMMessageHandler, ImServiceListener, ImListener
/*     */ {
/*     */   private IMSessionSTImpl session;
/*     */   private InstantMessagingService imService;
/*     */   private IMUser imPartner;
/*     */   private STUser stPartner;
/*     */   private Im im;
/*     */   private boolean imFailed;
/*     */   private boolean imOpen;
/*     */   private Set<IMMessageListener> listeners;
/*     */   private Object imOpeningLock;
/*     */   private String imFailedReason;
/*     */   private static final boolean DEBUG = 0;
/*     */   private static final int MAX_MESSAGE_BYTES_LENGTH = 32767;
/*     */ 
/*     */   public IMMessageHandlerSTImpl(IMSessionSTImpl session, InstantMessagingService imService, IMUser imPartner, STUser stPartner)
/*     */   {
/*  58 */     this.im = null;
/*  59 */     this.imFailed = false;
/*  60 */     this.imOpeningLock = new Object();
/*  61 */     setSession(session);
/*  62 */     setImService(imService);
/*  63 */     setIMPartner(imPartner);
/*  64 */     setSTPartner(stPartner);
/*  65 */     imService.addImServiceListener(this);
/*  66 */     this.listeners = new HashSet();
/*     */   }

/*     */   private void setSession(IMSessionSTImpl session) {
/*  70 */     if (session == null) {
/*  71 */       throw new IllegalArgumentException("Session must not be null");
/*     */     }
/*  73 */     this.session = session;
/*     */   }

/*     */   private void setImService(InstantMessagingService imService) {
/*  77 */     if (imService == null) {
/*  78 */       throw new IllegalArgumentException("IM service must not be null");
/*     */     }
/*  80 */     this.imService = imService;
/*     */   }

/*     */   private void setIMPartner(IMUser imPartner) {
/*  84 */     if (imPartner == null) {
/*  85 */       throw new IllegalArgumentException("IM partner must not be null");
/*     */     }
/*  87 */     this.imPartner = imPartner;
/*     */   }

/*     */   private void setSTPartner(STUser stPartner) {
/*  91 */     if (stPartner == null) {
/*  92 */       throw new IllegalArgumentException("ST partner must not be null");
/*     */     }
/*  94 */     this.stPartner = stPartner;
/*     */   }









/*     */   private void setIm(Im im)
/*     */   {
/* 107 */     if ((im == null) || (!(im.isOpen()))) {
/* 108 */       throw new IllegalArgumentException("IM must not be neither null nor closed");
/*     */     }
/* 110 */     this.im = im;
/* 111 */     im.addImListener(this);
/*     */   }

/*     */   public void addListener(IMMessageListener messageListener) throws IMException {
/* 115 */     this.listeners.add(messageListener);
/*     */   }

/*     */   public void removeListener(IMMessageListener messageListener) {
/* 119 */     this.listeners.remove(messageListener);
/*     */   }

/*     */   public void removeAllListeners() {
/* 123 */     this.listeners.clear();
/*     */   }

/*     */   public void imReceived(ImEvent evt) {
/* 127 */     Im im = evt.getIm();
/* 128 */     setIm(im);
/*     */   }

/*     */   private boolean openIM() throws IMException {
/* 132 */     if (!(this.session.isOpened())) {
/* 133 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 135 */     if (this.im == null) {
/* 136 */       synchronized (this.imOpeningLock) {
/* 137 */         openConversation();
/*     */         try {
/* 139 */           this.imOpeningLock.wait();
/*     */         } catch (InterruptedException e) {
/* 141 */           throw new IMException("The IM session with the other partner could not be established");
/*     */         }
/*     */       }
/* 144 */       if (this.im == null) {
/* 145 */         if (!(this.imFailed)) {
/* 146 */           this.imFailedReason = "IM service inconsistent";
/*     */         }
/*     */ 
/* 149 */         for (IMMessageListener listener : this.listeners) {
/* 150 */           listener.conversationClosed("The IM session with the other partner could not be established. Reason: " + this.imFailedReason);
/*     */         }
/*     */ 
/* 153 */         return false;
/*     */       }
/*     */     }
/* 156 */     return true;
/*     */   }

/*     */   public String sendMessage(String message) throws IMException {
/* 160 */     if ((message != null) && (message.getBytes().length > 32767)) {
/* 161 */       throw new IMException(IMException.Code.MESSAGE_TOO_LONG, "The message to be sent must not have more than 32767 bytes");

/*     */     }
/*     */ 
/* 165 */     this.imOpen = openIM();
/* 166 */     if (this.imOpen) {
/* 167 */       this.im.sendText(true, message);











/*     */ 
/* 180 */       for (IMMessageListener listener : this.listeners) {
/* 181 */         listener.messageReceived(new IMMessageEvent(this, this.session, new IMMessage(this.session.getIMUser(), this.imPartner, message, new Date().getTime())));











/*     */       }
/*     */ 
/* 195 */       return IMMessage.getFormatedMessage(this.session.getIMUser().getDisplayName(), message);
/*     */     }
/* 197 */     return IMMessage.getFormatedMessage(this.session.getIMUser().getDisplayName(), "");
/*     */   }








/*     */   private void openConversation()
/*     */   {
/* 209 */     this.im = this.imService.createIm(this.stPartner, EncLevel.ENC_LEVEL_ALL, 1, true);
/* 210 */     this.im.addImListener(this);
/* 211 */     this.im.open();
/*     */   }

/*     */   public void imOpened(ImEvent evt) {
/* 215 */     this.imFailed = false;
/* 216 */     synchronized (this.imOpeningLock) {
/* 217 */       this.imOpeningLock.notify();
/*     */     }
/*     */   }

/*     */   public void openImFailed(ImEvent evt) {
/* 222 */     this.imFailed = true;
/* 223 */     this.im = null;
/* 224 */     this.imFailedReason = STError.getMessageString(evt.getReason());
/* 225 */     synchronized (this.imOpeningLock) {
/* 226 */       this.imOpeningLock.notify();
/*     */     }
/*     */   }

/*     */   public void textReceived(ImEvent evt) {
/* 231 */     String message = evt.getText();





/*     */ 
/* 238 */     long timestamp = System.currentTimeMillis();
/* 239 */     IMUser receiver = this.session.getIMUser();
/* 240 */     IMMessage imMessage = new IMMessage(this.imPartner, receiver, message, timestamp);
/* 241 */     IMMessageEvent messageEvent = new IMMessageEvent(this.session, this.session, imMessage);
/* 242 */     for (IMMessageListener listener : this.listeners)
/* 243 */       listener.messageReceived(messageEvent);
/*     */   }






/*     */   public void closeConversation()
/*     */     throws IMException
/*     */   {
/* 254 */     if ((this.im == null) || (!(this.im.isOpen()))) {
/* 255 */       throw new IMException("The IM session with the other partner could not be established to be closed");
/*     */     }
/* 257 */     this.im.close(-2147483100);
/* 258 */     this.im = null;
/*     */   }

/*     */   public void imClosed(ImEvent evt) {
/* 262 */     this.im = null;
/* 263 */     if (this.imOpen)
/* 264 */       for (IMMessageListener listener : this.listeners)
/* 265 */         listener.conversationClosed(STError.getMessageString(evt.getReason()));
/*     */   }


/*     */   public boolean isOpened()
/*     */   {
/* 271 */     return ((this.im == null) ? false : this.im.isOpen());
/*     */   }
/*     */ }
