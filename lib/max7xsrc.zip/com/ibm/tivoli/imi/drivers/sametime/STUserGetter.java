/*    */ package com.ibm.tivoli.imi.drivers.sametime;
/*    */ 
/*    */ import com.lotus.sametime.lookup.ResolveEvent;
/*    */ import com.lotus.sametime.lookup.ResolveListener;
/*    */ import com.lotus.sametime.lookup.Resolver;
/*    */ 
















/*    */ class STUserGetter
/*    */   implements Runnable, ResolveListener
/*    */ {
/*    */   private Resolver resolver;
/*    */   private String userDisplayName;
/* 29 */   private ResolveEvent resolveEvent = null;
/*    */   private Object lock;
/*    */ 
/*    */   public STUserGetter(Object lock, Resolver resolver, String userDisplayName)
/*    */   {
/* 33 */     setLock(lock);
/* 34 */     setResolver(resolver);
/* 35 */     setUserDisplayName(userDisplayName);
/*    */   }

/*    */   private void setLock(Object lock) {
/* 39 */     this.lock = lock;
/*    */   }

/*    */   private void setResolver(Resolver resolver) {
/* 43 */     if (resolver == null) {
/* 44 */       throw new IllegalArgumentException("IM resolver must not be null");
/*    */     }
/* 46 */     this.resolver = resolver;
/* 47 */     resolver.addResolveListener(this);
/*    */   }

/*    */   private void setUserDisplayName(String userDisplayName) {
/* 51 */     if (userDisplayName == null) {
/* 52 */       throw new IllegalArgumentException("IM user must not be null");
/*    */     }
/* 54 */     this.userDisplayName = userDisplayName;
/*    */   }





/*    */   public void run()
/*    */   {
/* 63 */     this.resolver.resolve(this.userDisplayName);
/*    */   }

/*    */   public void resolveConflict(ResolveEvent event) {
/* 67 */     this.resolveEvent = event;
/* 68 */     synchronized (this.lock) {
/* 69 */       this.lock.notify();
/*    */     }
/*    */   }

/*    */   public void resolveFailed(ResolveEvent event) {
/* 74 */     this.resolveEvent = event;
/* 75 */     synchronized (this.lock) {
/* 76 */       this.lock.notify();
/*    */     }
/*    */   }

/*    */   public void resolved(ResolveEvent event) {
/* 81 */     this.resolveEvent = event;
/* 82 */     synchronized (this.lock) {
/* 83 */       this.lock.notify();
/*    */     }
/*    */   }

/*    */   ResolveEvent getResolveEvent() {
/* 88 */     return this.resolveEvent;
/*    */   }
/*    */ }
