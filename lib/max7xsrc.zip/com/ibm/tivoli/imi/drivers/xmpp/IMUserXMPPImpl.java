/*     */ package com.ibm.tivoli.imi.drivers.xmpp;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import org.jivesoftware.smack.packet.Presence;
/*     */ import org.jivesoftware.smack.packet.Presence.Mode;
/*     */ import org.jivesoftware.smack.packet.Presence.Type;
/*     */ import org.jivesoftware.smack.util.StringUtils;
/*     */ 













/*     */ public class IMUserXMPPImpl
/*     */   implements IMUser
/*     */ {
/*     */   private String displayName;
/*     */   private String userId;
/*     */ 
/*     */   IMUserXMPPImpl(String userId, String displayName)
/*     */   {
/*  31 */     setUserId(userId);
/*  32 */     setDisplayName(displayName);
/*     */   }

/*     */   private void setDisplayName(String displayName) {
/*  36 */     if ((displayName == null) || (displayName.trim().equals(""))) {
/*  37 */       displayName = this.userId;
/*     */     }
/*  39 */     this.displayName = displayName;
/*     */   }

/*     */   private void setUserId(String userId) {
/*  43 */     if ((userId == null) || (userId.trim().equals(""))) {
/*  44 */       throw new IllegalArgumentException("User id must not be null");
/*     */     }
/*  46 */     this.userId = userId;
/*     */   }

/*     */   public String getDisplayName() {
/*  50 */     return this.displayName;
/*     */   }

/*     */   public String getUserId() {
/*  54 */     return this.userId;
/*     */   }

/*     */   static IMUser createIMUser(String xmppUser) {
/*  58 */     String userId = StringUtils.parseBareAddress(xmppUser);
/*  59 */     String displayName = StringUtils.parseName(xmppUser);
/*  60 */     IMUser imUser = new IMUserXMPPImpl(userId, displayName);
/*  61 */     return imUser;
/*     */   }

/*     */   public static IMUser.IMUserStatus getIMStatus(Presence presence) {
/*  65 */     IMUser.IMUserStatus imUserStatus = IMUser.IMUserStatus.UNKNOW;
/*  66 */     if (presence != null) {
/*  67 */       if (presence.getMode() != null) {
/*  68 */         switch (1.$SwitchMap$org$jivesoftware$smack$packet$Presence$Mode[presence.getMode().ordinal()])
/*     */         {/*     */         case 1:
/*     */         case 2:
/*  71 */           imUserStatus = IMUser.IMUserStatus.AVAILABLE;
/*  72 */           break;
/*     */         case 3:
/*  74 */           imUserStatus = IMUser.IMUserStatus.AWAY;
/*  75 */           break;
/*     */         case 4:
/*  77 */           imUserStatus = IMUser.IMUserStatus.DONT_DISTURB;
/*  78 */           break;
/*     */         case 5:
/*  80 */           imUserStatus = IMUser.IMUserStatus.OFFLINE;
/*     */         }
/*     */       }
/*     */ 
/*  84 */       if ((imUserStatus.equals(IMUser.IMUserStatus.UNKNOW)) && (presence.getType() != null))
/*     */       {
/*  86 */         switch (1.$SwitchMap$org$jivesoftware$smack$packet$Presence$Type[presence.getType().ordinal()])
/*     */         {/*     */         case 1:
/*  88 */           imUserStatus = IMUser.IMUserStatus.AVAILABLE;
/*  89 */           break;
/*     */         case 2:
/*  91 */           imUserStatus = IMUser.IMUserStatus.OFFLINE;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  96 */     return imUserStatus;
/*     */   }

/*     */   static Presence getXmppIMStatus(IMUser.IMUserStatus imUserStatus) {
/* 100 */     Presence presence = new Presence(Presence.Type.available);
/* 101 */     Presence.Mode mode = Presence.Mode.available;
/* 102 */     String status = imUserStatus.name();
/*     */ 
/* 104 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$spi$IMUser$IMUserStatus[imUserStatus.ordinal()])
/*     */     {/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/* 108 */       mode = Presence.Mode.available;
/* 109 */       break;
/*     */     case 4:
/* 111 */       mode = Presence.Mode.away;
/* 112 */       break;
/*     */     case 5:
/* 114 */       mode = Presence.Mode.dnd;
/* 115 */       break;
/*     */     case 6:
/*     */     case 7:
/* 118 */       mode = Presence.Mode.xa;
/*     */     }
/*     */ 
/* 121 */     presence.setMode(mode);
/* 122 */     presence.setStatus(status);
/*     */ 
/* 124 */     return presence;
/*     */   }
/*     */ }
