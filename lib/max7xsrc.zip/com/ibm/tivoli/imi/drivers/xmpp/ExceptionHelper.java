/*     */ package com.ibm.tivoli.imi.drivers.xmpp;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import org.jivesoftware.smack.XMPPException;
/*     */ import org.jivesoftware.smack.packet.XMPPError;
/*     */ 









































































/*     */ abstract class ExceptionHelper
/*     */ {
/*     */   static void throwIMException(XMPPException e)
/*     */     throws IMException
/*     */   {
/*  86 */     throw getIMException(e);
/*     */   }

/*     */   static void throwUnexpectedIMException(Exception e) throws IMException {
/*  90 */     throw getUnexpectedIMException(e);
/*     */   }






























/*     */   private static IMException getIMException(XMPPException e)
/*     */   {
/* 124 */     IMException.Code code = IMException.Code.IM_EXCEPTION;
/* 125 */     XMPPError error = e.getXMPPError();
/* 126 */     if (error != null);
/* 127 */     switch (error.getCode())
/*     */     {/*     */     case 404:
/*     */     case 504:
/* 130 */       code = IMException.Code.INVALID_IM_SERVER;
/* 131 */       break;
/*     */     case 401:
/* 133 */       code = IMException.Code.INVALID_ACCOUNT;
/* 134 */       break;
/*     */     case 408:
/* 136 */       code = IMException.Code.CONNECTION_TIMEOUT;
/* 137 */       break;
/*     */     case 502:
/* 139 */       code = IMException.Code.INVALID_IM_SERVER_PORT;
/* 140 */       break;
/*     */     default:
/* 142 */       code = handleGoogleTalkErrorMessage(e.getMessage());
/* 143 */       break label115:

/*     */ 
/* 146 */       code = handleGoogleTalkErrorMessage(e.getMessage());
/*     */     }
/* 148 */     label115: return new IMException(code, e);
/*     */   }

/*     */   private static IMException getUnexpectedIMException(Exception e) {
/* 152 */     IMException.Code code = IMException.Code.IM_EXCEPTION;
/* 153 */     if (e instanceof IllegalStateException) {
/* 154 */       code = handleJabberErrorMessage(e.getMessage());
/*     */     }
/* 156 */     return new IMException(code, e);
/*     */   }

/*     */   private static IMException.Code handleJabberErrorMessage(String errorMessage) {
/* 160 */     for (JabberErrorMessage jem : JabberErrorMessage.values()) {
/* 161 */       if (jem.equals(errorMessage)) {
/* 162 */         return jem.getIMExceptionCode();
/*     */       }
/*     */     }
/* 165 */     return IMException.Code.SERVER_EXCEPTION;
/*     */   }

/*     */   private static IMException.Code handleGoogleTalkErrorMessage(String errorMessage) {
/* 169 */     for (GoogleTalkErrorMessage gtem : GoogleTalkErrorMessage.values()) {
/* 170 */       if (gtem.equals(errorMessage)) {
/* 171 */         return gtem.getIMExceptionCode();
/*     */       }
/*     */     }
/* 174 */     return IMException.Code.SERVER_EXCEPTION;
/*     */   }
/*     */ 
/*     */   private static enum GoogleTalkErrorMessage
/*     */   {
/*  54 */     AUTHENTICATION, PORT, SERVICE_NAME;
/*     */ 
/*     */     private IMException.Code imExceptionCode;
/*     */     private String stringRepresentation;
/*     */ 
/*     */     IMException.Code getIMExceptionCode()
/*     */     {
/*  69 */       return this.imExceptionCode;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/*  74 */       return this.stringRepresentation;
/*     */     }
/*     */ 
/*     */     boolean equals(String errorMessage) {
/*  78 */       if (errorMessage == null) {
/*  79 */         return false;
/*     */       }
/*  81 */       return errorMessage.toLowerCase().trim().startsWith(this.stringRepresentation);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum JabberErrorMessage
/*     */   {
/*  25 */     AUTHENTICATION;
/*     */ 
/*     */     private IMException.Code imExceptionCode;
/*     */     private String stringRepresentation;
/*     */ 
/*     */     IMException.Code getIMExceptionCode()
/*     */     {
/*  38 */       return this.imExceptionCode;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/*  43 */       return this.stringRepresentation;
/*     */     }
/*     */ 
/*     */     boolean equals(String errorMessage) {
/*  47 */       if (errorMessage == null) {
/*  48 */         return false;
/*     */       }
/*  50 */       return errorMessage.toLowerCase().trim().startsWith(this.stringRepresentation);
/*     */     }
/*     */   }
/*     */ }
