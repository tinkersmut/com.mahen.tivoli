/*     */ package com.ibm.tivoli.imi.drivers.xmpp;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusListener;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jivesoftware.smack.Roster;
/*     */ import org.jivesoftware.smack.RosterEntry;
/*     */ import org.jivesoftware.smack.RosterListener;
/*     */ import org.jivesoftware.smack.XMPPException;
/*     */ import org.jivesoftware.smack.packet.Presence;
/*     */ import org.jivesoftware.smack.util.StringUtils;
/*     */ 



















/*     */ public class IMUserStatusHandlerXMPPImpl
/*     */   implements IMUserStatusHandler, RosterListener
/*     */ {
/*     */   private Map<String, RosterEntry> listenedUsers;
/*     */   private Set<IMUserStatusListener> listeners;
/*     */   private IMSessionXMPPImpl session;
/*     */   private Roster roster;
/*     */ 
/*     */   public IMUserStatusHandlerXMPPImpl(IMSessionXMPPImpl session, Roster roster)
/*     */   {
/*  50 */     setSession(session);
/*  51 */     setRoster(roster);
/*  52 */     this.listenedUsers = new HashMap();
/*  53 */     this.listeners = new HashSet();
/*     */   }

/*     */   private void setSession(IMSessionXMPPImpl session) {
/*  57 */     if (session == null) {
/*  58 */       throw new IllegalArgumentException("Session must not be null");
/*     */     }
/*  60 */     this.session = session;
/*     */   }

/*     */   private void setRoster(Roster roster) {
/*  64 */     if (roster == null) {
/*  65 */       throw new IllegalArgumentException("Roster must not be null");
/*     */     }
/*  67 */     this.roster = roster;
/*  68 */     roster.addRosterListener(this);
/*     */   }

/*     */   public void addListener(IMUserStatusListener userStatusListener) throws IMException
/*     */   {
/*  73 */     this.listeners.add(userStatusListener);
/*     */   }

/*     */   public void removeListener(IMUserStatusListener userStatusListener) {
/*  77 */     this.listeners.remove(userStatusListener);
/*     */   }

/*     */   public void removeAllListeners() {
/*  81 */     this.listeners.clear();
/*     */   }

/*     */   public synchronized boolean hasListenedUser(IMUser imUser) throws IMException {
/*  85 */     return this.listenedUsers.containsKey(imUser.getDisplayName());
/*     */   }

/*     */   public synchronized void addListenedUser(IMUser imUser) throws IMException {
/*  89 */     String userId = imUser.getUserId();
/*  90 */     if (this.listenedUsers.containsKey(userId))
/*  91 */       return;
/*     */     try
/*     */     {
/*  94 */       this.roster.createEntry(userId, imUser.getDisplayName(), null);
/*  95 */       RosterEntry entry = this.roster.getEntry(userId);
/*  96 */       this.listenedUsers.put(userId, entry);
/*     */     } catch (XMPPException e) {
/*  98 */       ExceptionHelper.throwIMException(e);
/*     */     }
/*     */   }

/*     */   public synchronized void removeListenedUser(IMUser imUser) {
/* 103 */     RosterEntry entry = (RosterEntry)this.listenedUsers.remove(imUser.getUserId());
/* 104 */     if (entry == null) return;
/*     */     try {
/* 106 */       this.roster.removeEntry(entry);
/*     */     } catch (XMPPException e) {
/* 108 */       e.printStackTrace();
/*     */     }
/*     */   }

/*     */   public synchronized void removeAllListenedUsers()
/*     */   {
/* 114 */     for (RosterEntry entry : this.roster.getEntries()) {
/*     */       try {
/* 116 */         this.roster.removeEntry(entry);
/*     */       } catch (XMPPException e) {
/* 118 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 121 */     this.listenedUsers.clear();
/*     */   }










/*     */   public void presenceChanged(Presence presence) {
/* 134 */     String xmppUser = StringUtils.parseBareAddress(presence.getFrom());
/* 135 */     IMUser imUser = IMUserXMPPImpl.createIMUser(xmppUser);
/* 136 */     IMUser.IMUserStatus imUserStatus = IMUserXMPPImpl.getIMStatus(presence);
/* 137 */     IMUserStatusEvent userStatusEvent = new IMUserStatusEvent(this, this.session, imUser, imUserStatus);
/*     */ 
/* 139 */     for (IMUserStatusListener listener : this.listeners)
/* 140 */       listener.userStatusChanged(userStatusEvent);
/*     */   }
/*     */ }
