/*    */ package com.ibm.tivoli.imi.drivers.xmpp;
/*    */ 
/*    */ import com.ibm.tivoli.imi.spi.IMDriver;
/*    */ import com.ibm.tivoli.imi.spi.IMDriverManager;
/*    */ import com.ibm.tivoli.imi.spi.IMException;
/*    */ import com.ibm.tivoli.imi.spi.IMSession;
/*    */ 










































/*    */ public class IMDriverXMPPImpl extends IMDriver
/*    */ {
/*    */   private String productName;
/*    */ 
/*    */   private IMDriverXMPPImpl(String productName)
/*    */   {
/* 56 */     this.productName = productName;
/*    */   }

/*    */   public String getIMProductName()
/*    */   {
/* 61 */     return this.productName;
/*    */   }

/*    */   public IMSession createSession()
/*    */   {
/* 66 */     return new IMSessionXMPPImpl();
/*    */   }

/*    */   public String[] getOptionalProperties()
/*    */   {
/* 71 */     String[] values = new String[OptionalProperties.values().length];
/* 72 */     int i = 0;
/* 73 */     for (OptionalProperties op : OptionalProperties.values()) {
/* 74 */       values[i] = op.name();
/* 75 */       ++i;
/*    */     }
/* 77 */     return values;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 45 */       IMDriver jabberDriver = new IMDriverXMPPImpl("jabber");
/* 46 */       IMDriver gtalkDriver = new IMDriverXMPPImpl("google_talk");
/*    */ 
/* 48 */       IMDriverManager.registerIMDriver(jabberDriver);
/* 49 */       IMDriverManager.registerIMDriver(gtalkDriver);
/*    */     } catch (IMException e) {
/* 51 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static enum OptionalProperties
/*    */   {
/* 30 */     SERVER_PORT, SERVICE_NAME;
/*    */   }
/*    */ }
