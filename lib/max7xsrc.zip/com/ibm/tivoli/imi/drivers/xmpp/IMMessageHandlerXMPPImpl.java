/*     */ package com.ibm.tivoli.imi.drivers.xmpp;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMMessage;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageListener;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.jivesoftware.smack.Chat;
/*     */ import org.jivesoftware.smack.ChatManager;
/*     */ import org.jivesoftware.smack.MessageListener;
/*     */ import org.jivesoftware.smack.XMPPException;
/*     */ import org.jivesoftware.smack.packet.Message;
/*     */ 


















/*     */ public class IMMessageHandlerXMPPImpl
/*     */   implements IMMessageHandler, MessageListener
/*     */ {
/*     */   private IMSessionXMPPImpl session;
/*     */   private Chat chat;
/*     */   private IMUser imPartner;
/*     */   private Set<IMMessageListener> listeners;
/*     */   private static final boolean DEBUG = 0;
/*     */   private static final int MAX_MESSAGE_BYTES_LENGTH = 32767;
/*     */ 
/*     */   public IMMessageHandlerXMPPImpl(IMSessionXMPPImpl session, ChatManager chatManager, IMUser imPartner)
/*     */   {
/*  49 */     setSession(session);
/*  50 */     setIMPartner(imPartner);
/*  51 */     setChat(chatManager);
/*  52 */     this.listeners = new HashSet();
/*     */   }

/*     */   private void setSession(IMSessionXMPPImpl session) {
/*  56 */     if (session == null) {
/*  57 */       throw new IllegalArgumentException("Session must not be null");
/*     */     }
/*  59 */     this.session = session;
/*     */   }

/*     */   private void setChat(ChatManager chatManager) {
/*  63 */     if (chatManager == null) {
/*  64 */       throw new IllegalArgumentException("Chat manager must not be null");
/*     */     }
/*  66 */     this.chat = chatManager.createChat(this.imPartner.getUserId(), this);
/*     */   }

/*     */   private void setIMPartner(IMUser imPartner) {
/*  70 */     if (imPartner == null) {
/*  71 */       throw new IllegalArgumentException("IM partner must not be null");
/*     */     }
/*  73 */     this.imPartner = imPartner;
/*     */   }

/*     */   public void addListener(IMMessageListener messageListener) throws IMException {
/*  77 */     this.listeners.add(messageListener);
/*     */   }

/*     */   public void removeListener(IMMessageListener messageListener) {
/*  81 */     this.listeners.remove(messageListener);
/*     */   }

/*     */   public void removeAllListeners() {
/*  85 */     this.listeners.clear();
/*     */   }

/*     */   public String sendMessage(String message) throws IMException {
/*  89 */     if ((message != null) && (message.getBytes().length > 32767)) {
/*  90 */       throw new IMException(IMException.Code.MESSAGE_TOO_LONG, "The message to be sent must not have more than 32767 bytes");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  95 */       this.chat.sendMessage(message);
/*     */     } catch (XMPPException e) {
/*  97 */       ExceptionHelper.throwIMException(e);











/*     */     }
/*     */ 
/* 111 */     for (IMMessageListener listener : this.listeners) {
/* 112 */       listener.messageReceived(new IMMessageEvent(this, this.session, new IMMessage(this.session.getIMUser(), this.imPartner, message, new Date().getTime())));










/*     */     }
/*     */ 
/* 125 */     return IMMessage.getFormatedMessage(this.session.getIMUser().getDisplayName(), message);
/*     */   }



/*     */   public void processMessage(Chat chat, Message message)
/*     */   {
/* 132 */     String messageText = message.getBody();





/*     */ 
/* 139 */     long timestamp = System.currentTimeMillis();
/* 140 */     IMUser receiver = this.session.getIMUser();
/* 141 */     IMMessage imMessage = new IMMessage(this.imPartner, receiver, messageText, timestamp);
/* 142 */     IMMessageEvent messageEvent = new IMMessageEvent(this.session, this.session, imMessage);
/* 143 */     for (IMMessageListener listener : this.listeners)
/* 144 */       listener.messageReceived(messageEvent);
/*     */   }

/*     */   public void closeConversation() throws IMException
/*     */   {
/* 149 */     for (IMMessageListener listener : this.listeners)
/* 150 */       listener.conversationClosed("Person who initiated the chat closed it");
/*     */   }

/*     */   public boolean isOpened()
/*     */   {
/* 155 */     return (this.chat != null);
/*     */   }
/*     */ }
