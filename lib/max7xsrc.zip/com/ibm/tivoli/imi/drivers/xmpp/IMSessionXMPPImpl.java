/*     */ package com.ibm.tivoli.imi.drivers.xmpp;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMDriver.RequiredProperties;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveEvent.ResultType;
/*     */ import com.ibm.tivoli.imi.spi.IMResolveHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMSession;
/*     */ import com.ibm.tivoli.imi.spi.IMSingleListener;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.jivesoftware.smack.ChatManager;
/*     */ import org.jivesoftware.smack.ChatManagerListener;
/*     */ import org.jivesoftware.smack.ConnectionConfiguration;
/*     */ import org.jivesoftware.smack.Roster;
/*     */ import org.jivesoftware.smack.Roster.SubscriptionMode;
/*     */ import org.jivesoftware.smack.SASLAuthentication;
/*     */ import org.jivesoftware.smack.XMPPConnection;
/*     */ import org.jivesoftware.smack.XMPPException;
/*     */ import org.jivesoftware.smack.packet.Presence;
/*     */ 

















/*     */ public class IMSessionXMPPImpl
/*     */   implements IMSession
/*     */ {
/*  47 */   private int serverPort = 5222;
/*     */   private String serverHostName;
/*     */   private String serviceName;
/*     */   private String userId;
/*     */   private String userPassword;
/*     */   private ConnectionConfiguration connConfig;
/*     */   private ChatManager chatManager;
/*  51 */   private IMUser imUser = null;
/*  52 */   private long connectionTimeout = 20000L;
/*  53 */   private long resolveTimeout = 10000L;
/*  54 */   private boolean isOpened = false;
/*     */   private XMPPException connectionException;
/*     */   private Exception unexpectedException;
/*     */   private XMPPConnection xmppConnection;
/*     */   private List<IMMessageHandlerXMPPImpl> messageHandlerList;
/*     */   private static final long DEFAULT_CONNECTION_TIMEOUT = 20000L;
/*     */   private static final long DEFAULT_RESOLVE_TIMEOUT = 10000L;
/*     */   private static final long MIN_CONNECTION_TIMEOUT = 10000L;
/*     */   private static final long MIN_RESOLVE_TIMEOUT = 10000L;
/*     */   private static final int XMPP_DEFAULT_PORT = 5222;
/*     */   private static final int MIN_SERVER_PORT = 0;
/*     */   private static final int MAX_SERVER_PORT = 65535;
/*     */ 
/*     */   public void configure(Properties properties)
/*     */     throws IMException
/*     */   {
/*  74 */     String _serverHostName = properties.getProperty(IMDriver.RequiredProperties.SERVER_HOSTNAME.toString());
/*  75 */     String _userId = properties.getProperty(IMDriver.RequiredProperties.USER_ID.toString());
/*  76 */     String _userPassword = properties.getProperty(IMDriver.RequiredProperties.USER_PASSWORD.toString());
/*  77 */     String _connectionTimeout = properties.getProperty(IMDriver.RequiredProperties.CONNECTION_TIMEOUT.toString());
/*  78 */     String _resolveTimeout = properties.getProperty(IMDriver.RequiredProperties.RESOLVE_TIMEOUT.toString());
/*  79 */     String _serverPort = properties.getProperty(IMDriverXMPPImpl.OptionalProperties.SERVER_PORT.toString());
/*  80 */     String _serviceName = properties.getProperty(IMDriverXMPPImpl.OptionalProperties.SERVICE_NAME.toString());
/*     */ 
/*  82 */     setServerHostName(_serverHostName);
/*  83 */     setServerPort(_serverPort);
/*  84 */     setServiceName(_serviceName);
/*  85 */     setUserId(_userId);
/*  86 */     setUserPassword(_userPassword);
/*  87 */     setConnectionTimeout(_connectionTimeout);
/*  88 */     setResolveTimeout(_resolveTimeout);
/*     */ 
/*  90 */     if (this.serviceName == null)
/*  91 */       this.connConfig = new ConnectionConfiguration(this.serverHostName, this.serverPort);
/*     */     else
/*  93 */       this.connConfig = new ConnectionConfiguration(this.serverHostName, this.serverPort, this.serviceName);
/*     */   }

/*     */   private void setServerHostName(String serverHostName) throws IMException
/*     */   {
/*  98 */     if ((serverHostName == null) || (serverHostName.trim().equals(""))) {
/*  99 */       throw new IMException(IMException.Code.INVALID_IM_SERVER);
/*     */     }
/* 101 */     this.serverHostName = serverHostName;
/*     */   }

/*     */   private void setServerPort(String serverPort) throws IMException {
/* 105 */     if (serverPort.trim().equals("")) {
/* 106 */       serverPort = null;
/*     */     }
/* 108 */     if (serverPort == null) return;
/*     */     int _serverPort;
/*     */     try {
/* 111 */       _serverPort = Integer.parseInt(serverPort);
/*     */     } catch (NumberFormatException e) {
/* 113 */       throw new IMException(IMException.Code.INVALID_IM_SERVER_PORT);
/*     */     }
/* 115 */     if ((_serverPort < 0) || (_serverPort > 65535)) {
/* 116 */       throw new IMException(IMException.Code.INVALID_IM_SERVER_PORT);
/*     */     }
/* 118 */     this.serverPort = _serverPort;
/*     */   }

/*     */   private void setServiceName(String serviceName)
/*     */   {
/* 123 */     if ((serviceName != null) && (serviceName.trim().equals(""))) {
/* 124 */       serviceName = null;
/*     */     }
/* 126 */     this.serviceName = serviceName;
/*     */   }

/*     */   private void setUserId(String userId) throws IMException {
/* 130 */     if ((userId == null) || (userId.trim().equals(""))) {
/* 131 */       throw new IMException(IMException.Code.INVALID_ACCOUNT);





/*     */     }
/*     */ 
/* 139 */     this.userId = userId;
/*     */   }

/*     */   private void setUserPassword(String userPassword) throws IMException {
/* 143 */     if (userPassword == null) {
/* 144 */       throw new IMException(IMException.Code.INVALID_ACCOUNT);
/*     */     }
/* 146 */     this.userPassword = userPassword;
/*     */   }

/*     */   private void setConnectionTimeout(String connectionTimeout) throws IMException {
/* 150 */     if ((connectionTimeout == null) || (connectionTimeout.trim().equals("")))
/* 151 */       return;
/*     */     try
/*     */     {
/* 154 */       long timeout = Long.parseLong(connectionTimeout);
/* 155 */       setConnectionTimeout(timeout);
/*     */     } catch (NumberFormatException e) {
/* 157 */       throw new IMException(IMException.Code.INVALID_CON_TIMEOUT, "Invalid " + IMDriver.RequiredProperties.CONNECTION_TIMEOUT + " property");
/*     */     }
/*     */   }

/*     */   private void setResolveTimeout(String resolveTimeout) throws IMException
/*     */   {
/* 163 */     if ((resolveTimeout == null) || (resolveTimeout.trim().equals("")))
/* 164 */       return;
/*     */     try
/*     */     {
/* 167 */       long timeout = Long.parseLong(resolveTimeout);
/* 168 */       setResolveTimeout(timeout);
/*     */     } catch (NumberFormatException e) {
/* 170 */       throw new IMException(IMException.Code.INVALID_RESOLVE_TIMEOUT, "Invalid " + IMDriver.RequiredProperties.RESOLVE_TIMEOUT + " property");
/*     */     }
/*     */   }

/*     */   private void setIMUser(IMUser imUser) throws IMException
/*     */   {
/* 176 */     if (imUser == null) {
/* 177 */       throw new IMException(IMException.Code.INVALID_ACCOUNT, "IM user must not be null");
/*     */     }
/* 179 */     this.imUser = imUser;
/*     */   }

/*     */   public String getServerHostName() {
/* 183 */     return this.serverHostName;
/*     */   }

/*     */   public int getServerPort() {
/* 187 */     return this.serverPort;
/*     */   }

/*     */   public String getServiceName() {
/* 191 */     return this.serviceName;
/*     */   }

/*     */   public String getSessionName() {
/* 195 */     return this.xmppConnection.getConnectionID();
/*     */   }

/*     */   public String getUserId() {
/* 199 */     return this.userId;
/*     */   }

/*     */   public String getUserPassword() {
/* 203 */     return this.userPassword;
/*     */   }

/*     */   public IMUser getIMUser() {
/* 207 */     return this.imUser;
/*     */   }
/*     */   private class OpenConnectionHelper extends Thread
/*     */   {
/*     */     public void run()
/*     */     {
/* 213 */       synchronized (IMSessionXMPPImpl.this) {
/*     */         try {
/* 215 */           IMSessionXMPPImpl.this.xmppConnection.connect();
/* 216 */           SASLAuthentication.supportSASLMechanism("PLAIN", 0);
/* 217 */           IMSessionXMPPImpl.this.xmppConnection.login(IMSessionXMPPImpl.this.userId, IMSessionXMPPImpl.this.userPassword);
/*     */         }
/*     */         catch (XMPPException e) {
/* 220 */           IMSessionXMPPImpl.access$302(IMSessionXMPPImpl.this, e);
/*     */         }
/*     */         catch (Exception e) {
/* 223 */           IMSessionXMPPImpl.access$402(IMSessionXMPPImpl.this, e);
/*     */         }
/*     */         finally {
/* 226 */           IMSessionXMPPImpl.this.notify();
/*     */         }
/*     */       }/*     */     }/*     */   }
/*     */   public void open()
/*     */     throws IMException
/*     */   {
/*     */     try
/*     */     {
/* 234 */       this.xmppConnection = new XMPPConnection(this.connConfig);
/* 235 */       OpenConnectionHelper och = new OpenConnectionHelper(null);
/*     */ 
/* 237 */       synchronized (this) {
/* 238 */         this.connectionException = null;
/* 239 */         this.unexpectedException = null;
/* 240 */         och.start();
/* 241 */         super.wait(this.connectionTimeout);
/*     */       }
/* 243 */       if (this.connectionException != null) {
/* 244 */         ExceptionHelper.throwIMException(this.connectionException);
/*     */       }
/* 246 */       if (this.unexpectedException != null) {
/* 247 */         ExceptionHelper.throwUnexpectedIMException(this.unexpectedException);
/*     */       }
/* 249 */       if ((!(this.xmppConnection.isConnected())) || (!(this.xmppConnection.isAuthenticated()))) {
/* 250 */         throw new IMException(IMException.Code.CONNECTION_TIMEOUT);
/*     */       }
/*     */ 
/* 253 */       this.chatManager = this.xmppConnection.getChatManager();
/* 254 */       this.isOpened = true;
/* 255 */       createIMUser();
/*     */     } catch (InterruptedException e) {
/* 257 */       throw new IMException(e);
/*     */     }
/*     */   }

/*     */   private void createIMUser() throws IMException {
/* 262 */     String xmppUser = this.xmppConnection.getUser();
/* 263 */     IMUser imUser = IMUserXMPPImpl.createIMUser(xmppUser);
/* 264 */     setIMUser(imUser);
/*     */   }

/*     */   public void changeUserStatus(IMUser.IMUserStatus imUserStatus) throws IMException {
/* 268 */     if (!(this.isOpened)) {
/* 269 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 271 */     if (imUserStatus == null) {
/* 272 */       throw new IllegalArgumentException("Invalid IM user status");
/*     */     }
/* 274 */     Presence presence = IMUserXMPPImpl.getXmppIMStatus(imUserStatus);
/* 275 */     this.xmppConnection.sendPacket(presence);
/*     */   }

/*     */   public void close() throws IMException {
/* 279 */     if (this.isOpened) {
/* 280 */       if (this.messageHandlerList != null)
/*     */       {
/* 282 */         for (int i = this.messageHandlerList.size() - 1; i >= 0; --i) {
/* 283 */           IMMessageHandlerXMPPImpl messageHandler = (IMMessageHandlerXMPPImpl)this.messageHandlerList.remove(i);
/* 284 */           if (messageHandler.isOpened()) {
/* 285 */             messageHandler.closeConversation();
/*     */           }
/*     */         }
/*     */       }
/* 289 */       this.xmppConnection.disconnect();
/* 290 */       this.isOpened = false;
/*     */     }
/*     */   }

/*     */   public boolean isOpened() {
/* 295 */     return this.isOpened;
/*     */   }

/*     */   public IMResolveHandler createResolveHandler(boolean onlyUnique, boolean exhaustiveLookup)
/*     */     throws IMException
/*     */   {
/* 301 */     throw new IMException(IMException.Code.NOT_IMPLEMENTED_YET);
/*     */   }

/*     */   public IMUserStatusHandler createUserStatusHandler() throws IMException {
/* 305 */     if (!(this.isOpened)) {
/* 306 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 308 */     Roster roster = this.xmppConnection.getRoster();
/* 309 */     IMUserStatusHandler userStatusHandler = new IMUserStatusHandlerXMPPImpl(this, roster);
/* 310 */     return userStatusHandler;
/*     */   }

/*     */   public IMMessageHandler createMessageHandler(IMUser partner) throws IMException {
/* 314 */     if (!(this.isOpened)) {
/* 315 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 317 */     IMMessageHandler messageHandler = new IMMessageHandlerXMPPImpl(this, this.chatManager, partner);
/* 318 */     if (this.messageHandlerList == null) {
/* 319 */       this.messageHandlerList = new ArrayList();
/*     */     }
/* 321 */     this.messageHandlerList.add((IMMessageHandlerXMPPImpl)messageHandler);
/* 322 */     return messageHandler;
/*     */   }

/*     */   public IMResolveEvent resolve(String userDisplayName, boolean onlyUnique, boolean exhaustiveLookup) throws IMException
/*     */   {
/* 327 */     if (!(this.isOpened)) {
/* 328 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 330 */     if ((userDisplayName == null) || (userDisplayName.trim().equals(""))) {
/* 331 */       return new IMResolveEvent(this, this, userDisplayName, IMResolveEvent.ResultType.NOT_RESOLVED, null);
/*     */     }
/* 333 */     IMUser imUser = IMUserXMPPImpl.createIMUser(userDisplayName);
/* 334 */     List imUsers = new ArrayList();
/* 335 */     imUsers.add(imUser);
/* 336 */     return new IMResolveEvent(this, this, imUser.getDisplayName(), IMResolveEvent.ResultType.RESOLVED, imUsers);
/*     */   }

/*     */   public IMUser resolve(String userDisplayName) throws IMException, IMException {
/*     */     IMUser imUser;
/*     */     try {
/* 342 */       IMResolveEvent imResolveEvent = resolve(userDisplayName, true, false);
/* 343 */       imUser = imResolveEvent.getResolvedUser();
/*     */     } catch (IMException e) {
/* 345 */       if (e.getCode().equals(IMException.Code.NOT_IMPLEMENTED_YET)) {
/* 346 */         throw e;
/*     */       }
/* 348 */       return null;
/*     */     }
/*     */ 
/* 351 */     return imUser;
/*     */   }

/*     */   public long getDefaultConnectionTimeout() {
/* 355 */     return 20000L;
/*     */   }

/*     */   public void setConnectionTimeout(long timeout) {
/* 359 */     if (timeout < 10000L) {
/* 360 */       throw new IllegalArgumentException("Connection timeout must not be less than 10000");
/*     */     }
/* 362 */     this.connectionTimeout = timeout;
/*     */   }

/*     */   public long getConnectionTimeout() {
/* 366 */     return this.connectionTimeout;
/*     */   }

/*     */   public long getDefaultResolveTimeout() {
/* 370 */     return 10000L;
/*     */   }

/*     */   public synchronized void setResolveTimeout(long timeout) {
/* 374 */     if (timeout < 10000L) {
/* 375 */       throw new IllegalArgumentException("Resolve timeout must not be less than 10000");
/*     */     }
/* 377 */     this.resolveTimeout = timeout;
/*     */   }

/*     */   public long getResolveTimeout() {
/* 381 */     return this.resolveTimeout;
/*     */   }

/*     */   public void registerIMSingleListener(IMSingleListener listener) throws IMException
/*     */   {
/* 386 */     if (listener instanceof ChatManagerListener) {
/* 387 */       if (!(this.isOpened)) {
/* 388 */         throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */       }
/* 390 */       this.xmppConnection.getRoster().setSubscriptionMode(Roster.SubscriptionMode.accept_all);
/* 391 */       this.chatManager.addChatListener((ChatManagerListener)listener);
/*     */     }
/*     */   }

/*     */   public void removeIMSingleListener(IMSingleListener listener) throws IMException {
/* 396 */     if (!(this.isOpened)) {
/* 397 */       throw new IMException(IMException.Code.IM_SESSION_CLOSED);
/*     */     }
/* 399 */     this.chatManager.removeChatListener((ChatManagerListener)listener);
/*     */   }
/*     */ }
