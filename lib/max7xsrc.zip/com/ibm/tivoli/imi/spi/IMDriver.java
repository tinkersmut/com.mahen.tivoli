/*    */ package com.ibm.tivoli.imi.spi;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ 
















































/*    */ public abstract class IMDriver
/*    */ {
/*    */   public abstract String[] getOptionalProperties();
/*    */ 
/*    */   public abstract String getIMProductName();
/*    */ 
/*    */   public abstract IMSession createSession();
/*    */ 
/*    */   public boolean validateProperties(Properties properties)
/*    */   {
/* 64 */     Set allProperties = properties.keySet();
/* 65 */     for (RequiredProperties property : RequiredProperties.values()) {
/* 66 */       if (!(allProperties.remove(property.toString()))) {
/* 67 */         return false;
/*    */       }
/*    */     }
/* 70 */     for (String property : getOptionalProperties()) {
/* 71 */       allProperties.remove(property);
/*    */     }
/*    */ 
/* 74 */     return (allProperties.size() == 0);
/*    */   }
/*    */ 
/*    */   public static enum RequiredProperties
/*    */   {
/* 26 */     SERVER_HOSTNAME, USER_ID, USER_PASSWORD, CONNECTION_TIMEOUT, RESOLVE_TIMEOUT;
/*    */   }
/*    */ }
