/*     */ package com.ibm.tivoli.imi.spi;
/*     */ 







































































































/*     */ public class IMException extends Exception
/*     */ {
/*     */   private Code code;
/*     */   private static final long serialVersionUID = 3889801076372714242L;
/*     */ 
/*     */   public IMException()
/*     */   {
/* 113 */     setCode(Code.IM_EXCEPTION);
/*     */   }

/*     */   public IMException(String message) {
/* 117 */     super(message);
/* 118 */     setCode(Code.IM_EXCEPTION);
/*     */   }

/*     */   public IMException(Throwable throwable) {
/* 122 */     super(throwable);
/* 123 */     setCode(Code.IM_EXCEPTION);
/*     */   }

/*     */   public IMException(String message, Throwable throwable) {
/* 127 */     super(message, throwable);
/* 128 */     setCode(Code.IM_EXCEPTION);
/*     */   }

/*     */   public IMException(Code code) {
/* 132 */     setCode(code);
/*     */   }

/*     */   public IMException(Code code, String message) {
/* 136 */     super(message);
/* 137 */     setCode(code);
/*     */   }

/*     */   public IMException(Code code, Throwable throwable) {
/* 141 */     super(throwable);
/* 142 */     setCode(code);
/*     */   }

/*     */   public IMException(Code code, String message, Throwable throwable) {
/* 146 */     super(message, throwable);
/* 147 */     setCode(code);
/*     */   }

/*     */   private void setCode(Code code) {
/* 151 */     if (code == null) {
/* 152 */       throw new IllegalArgumentException("Invalid IMException code");
/*     */     }
/* 154 */     this.code = code;
/*     */   }

/*     */   public Code getCode() {
/* 158 */     return this.code;
/*     */   }

/*     */   public String getMessage() {
/* 162 */     String message = super.getMessage();
/* 163 */     if (this.code.equals(Code.IM_EXCEPTION)) {
/* 164 */       return message;
/*     */     }
/* 166 */     String result = this.code.toString();
/* 167 */     if ((message != null) && (!(message.trim().equals("")))) {
/* 168 */       result = result + " (" + message + ")";
/*     */     }
/* 170 */     return result;
/*     */   }
/*     */ 
/*     */   public static enum Code
/*     */   {
/*  35 */     IM_EXCEPTION, INVALID_DRIVER, IM_SESSION_CLOSED, RESOLVE_EXCEPTION, INVALID_IM_SERVER, CONNECTION_TIMEOUT, INVALID_ACCOUNT, INVALID_CON_TIMEOUT, INVALID_RESOLVE_TIMEOUT, MESSAGE_TOO_LONG, INVALID_IM_SERVER_PORT, INVALID_IM_SERVICE_NAME, NOT_IMPLEMENTED_YET, SERVER_EXCEPTION;
/*     */   }
/*     */ }
