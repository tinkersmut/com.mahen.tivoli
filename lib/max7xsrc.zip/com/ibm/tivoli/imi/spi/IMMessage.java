/*     */ package com.ibm.tivoli.imi.spi;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 

















/*     */ public class IMMessage
/*     */ {
/*     */   private IMUser sender;
/*     */   private IMUser receiver;
/*     */   private String message;
/*     */   private long timestamp;
/*     */ 
/*     */   public IMMessage(IMUser sender, IMUser receiver, String message, long timestamp)
/*     */   {
/*  32 */     setSender(sender);
/*  33 */     setReceiver(receiver);
/*  34 */     setMessage(message);
/*  35 */     setTimestamp(timestamp);
/*     */   }

/*     */   private void setSender(IMUser sender) {
/*  39 */     if (sender == null) {
/*  40 */       throw new IllegalArgumentException("Sender user object must not be null");
/*     */     }
/*  42 */     this.sender = sender;
/*     */   }


/*     */   private void setReceiver(IMUser receiver)
/*     */   {
/*  48 */     if (receiver == null) {
/*  49 */       throw new IllegalArgumentException("Receiver user object must not be null");
/*     */     }
/*  51 */     this.receiver = receiver;
/*     */   }


/*     */   private void setMessage(String message)
/*     */   {
/*  57 */     if (message == null)
/*  58 */       message = "";
/*  59 */     this.message = message;
/*     */   }

/*     */   private void setTimestamp(long timestamp) {
/*  63 */     this.timestamp = timestamp;
/*     */   }




/*     */   public String getMessage()
/*     */   {
/*  71 */     return this.message;
/*     */   }

/*     */   public IMUser getReceiver() {
/*  75 */     return this.receiver;
/*     */   }

/*     */   public IMUser getSender() {
/*  79 */     return this.sender;
/*     */   }

/*     */   public long getTimestamp() {
/*  83 */     return this.timestamp;
/*     */   }




/*     */   public String getFormatedMessage()
/*     */   {
/*  91 */     return getHourStamp(this.timestamp) + this.sender.getDisplayName() + ": " + this.message;
/*     */   }

/*     */   public static String getFormatedMessage(String senderDisplayName, String message)
/*     */   {
/*  96 */     long timestamp = System.currentTimeMillis();
/*  97 */     String formatedMessage = getHourStamp(timestamp) + senderDisplayName + ": " + message;
/*     */ 
/*  99 */     return formatedMessage;
/*     */   }

/*     */   private static String getHourStamp(long timestamp) {
/* 103 */     Date timestampDate = new Date(timestamp);
/* 104 */     SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss ");
/* 105 */     return sdf.format(timestampDate);
/*     */   }

/*     */   public String toString() {
/* 109 */     return getFormatedMessage();
/*     */   }
/*     */ }
