package com.ibm.tivoli.imi.spi;

public abstract interface IMUserStatusListener
{
  public abstract void userStatusChanged(IMUserStatusEvent paramIMUserStatusEvent);
}
