/*     */ package com.ibm.tivoli.imi.spi;
/*     */ 
/*     */ import java.util.List;
/*     */ 





























/*     */ public class IMResolveEvent extends IMEvent<IMUser>
/*     */ {
/*     */   private String userDisplayName;
/*     */   private ResultType resultType;
/*  27 */   private IMUser resolvedUser = null;
/*  28 */   private List<IMUser> resolveConflictUsers = null;
/*     */   private static final long serialVersionUID = 5576986256997786440L;
/*     */ 
/*     */   public IMResolveEvent(Object source, IMSession session, String userDisplayName, ResultType resultType, List<IMUser> imUsers)
/*     */   {
/*  44 */     super(source, session, IMEvent.IMEventType.RESOLVE);
/*  45 */     setUserDisplayName(userDisplayName);
/*  46 */     setResultType(resultType);
/*  47 */     setImUsers(imUsers);
/*     */   }

/*     */   private void setUserDisplayName(String userDisplayName) {
/*  51 */     if (userDisplayName == null) {
/*  52 */       throw new IllegalArgumentException("User info must not be null");
/*     */     }
/*  54 */     this.userDisplayName = userDisplayName;
/*     */   }

/*     */   private void setResultType(ResultType resultType) {
/*  58 */     if (resultType == null) {
/*  59 */       throw new IllegalArgumentException("Result type must not be null");
/*     */     }
/*  61 */     this.resultType = resultType;
/*     */   }

/*     */   private void setImUsers(List<IMUser> imUsers) {
/*  65 */     IllegalArgumentException ex = new IllegalArgumentException("Incompatible IM resolve result");
/*     */ 
/*  67 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$spi$IMResolveEvent$ResultType[this.resultType.ordinal()])
/*     */     {/*     */     case 1:
/*  69 */       if (imUsers == null) return;
/*  70 */       throw ex;


/*     */     case 2:
/*  74 */       if ((imUsers == null) || (imUsers.size() < 2)) {
/*  75 */         throw ex;
/*     */       }
/*  77 */       this.resolveConflictUsers = imUsers;
/*  78 */       break;
/*     */     case 3:
/*  80 */       if ((imUsers == null) || (imUsers.size() != 1)) {
/*  81 */         throw ex;
/*     */       }
/*  83 */       this.resolvedUser = ((IMUser)imUsers.get(0));
/*     */     }
/*     */   }

/*     */   public String getUserDisplayName()
/*     */   {
/*  89 */     return this.userDisplayName;
/*     */   }

/*     */   public ResultType getResultType() {
/*  93 */     return this.resultType;
/*     */   }






/*     */   public IMUser getContent()
/*     */   {
/* 103 */     return getResolvedUser();
/*     */   }

/*     */   public IMUser getResolvedUser() {
/* 107 */     return this.resolvedUser;
/*     */   }

/*     */   public List<IMUser> getResolveconflictUsers() {
/* 111 */     return this.resolveConflictUsers;
/*     */   }
/*     */ 
/*     */   public static enum ResultType
/*     */   {
/*  32 */     RESOLVED, NOT_RESOLVED, RESOLVE_CONFLICT;
/*     */   }
/*     */ }
