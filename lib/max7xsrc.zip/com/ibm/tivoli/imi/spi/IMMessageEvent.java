/*    */ package com.ibm.tivoli.imi.spi;
/*    */ 



















/*    */ public class IMMessageEvent extends IMEvent<IMMessage>
/*    */ {
/*    */   private IMMessage message;
/*    */   private static final long serialVersionUID = -6554714428611659454L;
/*    */ 
/*    */   public IMMessageEvent(Object source, IMSession session, IMMessage message)
/*    */   {
/* 29 */     super(source, session, IMEvent.IMEventType.MESSAGE);
/* 30 */     setMessage(message);
/*    */   }

/*    */   private void setMessage(IMMessage message) {
/* 34 */     if (message == null) {
/* 35 */       throw new IllegalArgumentException("Message must not be null");
/*    */     }
/* 37 */     this.message = message;
/*    */   }

/*    */   public IMMessage getContent()
/*    */   {
/* 42 */     return this.message;
/*    */   }

/*    */   public String getFormatedMessage() {
/* 46 */     return this.message.getFormatedMessage();
/*    */   }

/*    */   public IMUser getSender() {
/* 50 */     return this.message.getSender();
/*    */   }

/*    */   public IMUser getReceiver() {
/* 54 */     return this.message.getReceiver();
/*    */   }
/*    */ }
