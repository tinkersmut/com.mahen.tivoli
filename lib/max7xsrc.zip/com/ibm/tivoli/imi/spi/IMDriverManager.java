/*    */ package com.ibm.tivoli.imi.spi;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 

















/*    */ public class IMDriverManager
/*    */ {
/* 25 */   private static Map<String, IMDriver> imDrivers = new HashMap();
/*    */ 
/*    */   public static synchronized void registerIMDriver(IMDriver imDriver) throws IMException
/*    */   {
/* 29 */     if (imDriver == null) {
/* 30 */       throw new IMException(IMException.Code.INVALID_DRIVER, "Invalid IM driver class");
/*    */     }
/* 32 */     String imProductName = imDriver.getIMProductName();
/* 33 */     if ((imProductName == null) || (imProductName.trim().equals(""))) {
/* 34 */       throw new IMException(IMException.Code.INVALID_DRIVER, "Invalid IM driver product name");
/*    */     }
/* 36 */     imDrivers.put(imProductName, imDriver);
/*    */   }

/*    */   public static synchronized void deRegister(String imProductName) {
/* 40 */     imDrivers.remove(imProductName);
/*    */   }

/*    */   public static IMSession createChatSession(String productName) throws IMException
/*    */   {
/* 45 */     IMDriver imDriver = (IMDriver)imDrivers.get(productName);
/* 46 */     if (imDriver == null) {
/* 47 */       throw new IMException(IMException.Code.INVALID_DRIVER, "There is not an IM driver registered with this product name");
/*    */     }
/*    */ 
/* 50 */     return imDriver.createSession();
/*    */   }
/*    */ }
