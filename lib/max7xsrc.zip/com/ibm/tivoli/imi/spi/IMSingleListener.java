package com.ibm.tivoli.imi.spi;

public abstract interface IMSingleListener
{
}
