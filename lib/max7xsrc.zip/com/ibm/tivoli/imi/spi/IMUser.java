/*    */ package com.ibm.tivoli.imi.spi;
/*    */ 
/*    */ public abstract interface IMUser
/*    */ {
/*    */   public abstract String getDisplayName();
/*    */ 
/*    */   public abstract String getUserId();
/*    */ 
/*    */   public static enum IMUserStatus
/*    */   {
/* 22 */     OFFLINE, AVAILABLE, AWAY, DONT_DISTURB, IN_A_MEETING, MOBILE, UNKNOW;
/*    */   }
/*    */ }
