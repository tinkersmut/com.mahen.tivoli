/*    */ package com.ibm.tivoli.imi.spi;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 





















/*    */ public abstract class IMEvent<CT> extends EventObject
/*    */ {
/*    */   protected IMSession session;
/*    */   private IMEventType type;
/*    */   private static final long serialVersionUID = -3633472351371133896L;
/*    */ 
/*    */   IMEvent(Object source, IMSession session, IMEventType type)
/*    */   {
/* 34 */     super(source);
/* 35 */     if (source == null) {
/* 36 */       throw new IllegalArgumentException("The event source object can not be null");
/*    */     }
/*    */ 
/* 39 */     setSession(session);
/* 40 */     setType(type);
/*    */   }

/*    */   private void setSession(IMSession session) {
/* 44 */     if (session == null) {
/* 45 */       throw new IllegalArgumentException("Session must not be null");
/*    */     }
/* 47 */     this.session = session;
/*    */   }

/*    */   private void setType(IMEventType type) {
/* 51 */     if (type == null) {
/* 52 */       throw new IllegalArgumentException("Type must not be null");
/*    */     }
/* 54 */     this.type = type;
/*    */   }

/*    */   public IMSession getSession() {
/* 58 */     return this.session;
/*    */   }

/*    */   public IMEventType getType() {
/* 62 */     return this.type;
/*    */   }
/*    */ 
/*    */   public abstract CT getContent();
/*    */ 
/*    */   public static enum IMEventType
/*    */   {
/* 29 */     MESSAGE, USER_STATUS, RESOLVE;
/*    */   }
/*    */ }
