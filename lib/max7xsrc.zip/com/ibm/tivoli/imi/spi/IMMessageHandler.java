package com.ibm.tivoli.imi.spi;

public abstract interface IMMessageHandler
{
  public abstract void addListener(IMMessageListener paramIMMessageListener)
    throws IMException;

  public abstract void removeListener(IMMessageListener paramIMMessageListener);

  public abstract void removeAllListeners();

  public abstract String sendMessage(String paramString)
    throws IMException;

  public abstract void closeConversation()
    throws IMException;

  public abstract boolean isOpened();
}
