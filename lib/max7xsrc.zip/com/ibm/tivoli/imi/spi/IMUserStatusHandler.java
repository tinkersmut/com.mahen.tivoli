package com.ibm.tivoli.imi.spi;

public abstract interface IMUserStatusHandler
{
  public abstract void addListener(IMUserStatusListener paramIMUserStatusListener)
    throws IMException;

  public abstract void removeListener(IMUserStatusListener paramIMUserStatusListener);

  public abstract void removeAllListeners();

  public abstract boolean hasListenedUser(IMUser paramIMUser)
    throws IMException;

  public abstract void addListenedUser(IMUser paramIMUser)
    throws IMException;

  public abstract void removeListenedUser(IMUser paramIMUser);

  public abstract void removeAllListenedUsers();
}
