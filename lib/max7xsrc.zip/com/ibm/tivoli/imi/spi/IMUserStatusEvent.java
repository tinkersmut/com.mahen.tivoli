/*    */ package com.ibm.tivoli.imi.spi;
/*    */ 





















/*    */ public class IMUserStatusEvent extends IMEvent<IMUser>
/*    */ {
/*    */   private IMUser imUser;
/*    */   private IMUser.IMUserStatus userStatus;
/*    */   private static final long serialVersionUID = 1385637254017350903L;
/*    */ 
/*    */   public IMUserStatusEvent(Object source, IMSession session, IMUser imUser, IMUser.IMUserStatus userStatus)
/*    */   {
/* 32 */     super(source, session, IMEvent.IMEventType.USER_STATUS);
/* 33 */     setIMUser(imUser);
/* 34 */     setUserStatus(userStatus);
/*    */   }

/*    */   private void setIMUser(IMUser imUser) {
/* 38 */     if (imUser == null) {
/* 39 */       throw new IllegalArgumentException("IM user must not be null");
/*    */     }
/* 41 */     this.imUser = imUser;
/*    */   }

/*    */   private void setUserStatus(IMUser.IMUserStatus userStatus) {
/* 45 */     if (userStatus == null) {
/* 46 */       throw new IllegalArgumentException("User status must not be null");
/*    */     }
/* 48 */     this.userStatus = userStatus;
/*    */   }

/*    */   public IMUser getContent()
/*    */   {
/* 53 */     return this.imUser;
/*    */   }

/*    */   public IMUser.IMUserStatus getUserStatus() {
/* 57 */     return this.userStatus;
/*    */   }
/*    */ }
