package com.ibm.tivoli.imi.spi;

public abstract interface IMMessageListener
{
  public abstract void messageReceived(IMMessageEvent paramIMMessageEvent);

  public abstract void conversationClosed(String paramString);
}
