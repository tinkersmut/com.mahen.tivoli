package com.ibm.tivoli.imi.spi;

public abstract interface IMResolveListener
{
  public abstract void resolved(IMResolveEvent paramIMResolveEvent);

  public abstract void resolveConflict(IMResolveEvent paramIMResolveEvent);

  public abstract void resolveFailed(IMResolveEvent paramIMResolveEvent);
}
