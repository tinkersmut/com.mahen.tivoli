package com.ibm.tivoli.imi.spi;

public abstract interface IMResolveHandler
{
  public abstract void addListener(IMResolveListener paramIMResolveListener);

  public abstract void removeListener(IMResolveListener paramIMResolveListener);

  public abstract void removeAllListeners();

  public abstract void resolve(String paramString);
}
