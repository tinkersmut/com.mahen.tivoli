package com.ibm.tivoli.imi.spi;

import java.util.Properties;

public abstract interface IMSession
{
  public abstract void configure(Properties paramProperties)
    throws IMException;

  public abstract String getServerHostName();

  public abstract String getSessionName();

  public abstract String getUserId();

  public abstract String getUserPassword();

  public abstract IMUser getIMUser();

  public abstract void open()
    throws IMException;

  public abstract void changeUserStatus(IMUser.IMUserStatus paramIMUserStatus)
    throws IMException;

  public abstract long getDefaultConnectionTimeout();

  public abstract long getConnectionTimeout();

  public abstract void setConnectionTimeout(long paramLong);

  public abstract boolean isOpened();

  public abstract void close()
    throws IMException;

  public abstract long getDefaultResolveTimeout();

  public abstract long getResolveTimeout();

  public abstract void setResolveTimeout(long paramLong);

  public abstract IMResolveEvent resolve(String paramString, boolean paramBoolean1, boolean paramBoolean2)
    throws IMException;

  public abstract IMUser resolve(String paramString)
    throws IMException;

  public abstract IMResolveHandler createResolveHandler(boolean paramBoolean1, boolean paramBoolean2)
    throws IMException;

  public abstract IMUserStatusHandler createUserStatusHandler()
    throws IMException;

  public abstract IMMessageHandler createMessageHandler(IMUser paramIMUser)
    throws IMException;

  public abstract void registerIMSingleListener(IMSingleListener paramIMSingleListener)
    throws IMException;

  public abstract void removeIMSingleListener(IMSingleListener paramIMSingleListener)
    throws IMException;
}
