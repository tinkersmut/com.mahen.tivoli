/*    */ package com.ibm.tivoli.imi.controller;
/*    */ 





















/*    */ public class SessionInfoException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -2759894189371837293L;
/*    */ 
/*    */   public SessionInfoException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SessionInfoException(String message)
/*    */   {
/* 34 */     super(message);
/*    */   }
/*    */ }
