/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 
/*     */ import com.ibm.tivoli.imi.drivers.moc2007.IMDriverMocImpl;
/*     */ import com.ibm.tivoli.imi.drivers.sametime.IMDriverSTImpl;
/*     */ import com.ibm.tivoli.imi.drivers.sametime.IMDriverSTImpl.OptionalProperties;
/*     */ import com.ibm.tivoli.imi.drivers.xmpp.IMDriverXMPPImpl;
/*     */ import com.ibm.tivoli.imi.drivers.xmpp.IMDriverXMPPImpl.OptionalProperties;
/*     */ import com.ibm.tivoli.imi.spi.IMDriver.RequiredProperties;
/*     */ import com.ibm.tivoli.imi.spi.IMDriverManager;
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMSession;
/*     */ import com.ibm.tivoli.imi.spi.IMUser;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMUserStatusListener;
/*     */ import java.rmi.RemoteException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXEvent;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.util.MXSessionListener;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 






































/*     */ public class IMSessionHandler
/*     */   implements IMUserStatusListener, HttpSessionBindingListener, MXSessionListener
/*     */ {
/*     */   public static final String MESSAGE_GROUP = "instantmessaging";
/*  65 */   private static Map<String, Boolean> abortedChatHelpers = new HashMap();
/*     */   private static final String LOGKEY = "maximo";
/*  70 */   private static MXLogger logger = MXLoggerFactory.getLogger("maximo");
/*     */   static final long MX_ALIVE_TICKER = 4000L;
/*     */   static final long IM_ALIVE_TICKER = 300000L;
/*     */   private static final String DEFAULT_CONN_TIMEOUT = "20000";
/*     */   private static final String HTTP_SESSION_ATTRIBUTE = "im_session_handler";
/*     */   private static final String USER_INFO_ATTRIBUTE = "im_user_info";
/*     */   private static final String IM_DRIVER_MX_PROPERTY = "mxe.imi.driver";
/*     */   public static final String IM_SERVER_HOST_MX_PROPERTY = "mxe.imi.serverhostname";
/*     */   private static final String IM_SERVER_PORT_MX_PROPERTY = "mxe.imi.serverport";
/*     */   private static final String IM_COMMUNITY_MX_PROPERTY = "mxe.imi.community";
/*     */   private static final String IM_SERVICE_NAME_MX_PROPERTY = "mxe.imi.service";
/*     */   private static final String IM_SERVER_CONN_TIMEOUT = "mxe.imi.connectiontimeout";
/*     */   private static final boolean DEBUG = 0;
/*     */   private HttpSession httpSession;
/*     */   private MxSessionAliveVerifier mxSessionAliveVerifier;
/*     */   private String imDriverName;
/*  98 */   private IMVendor imVendor = IMVendor.none;
/*     */   private String imServerHostname;
/*     */   private String imServerPort;
/*     */   private String imCommunity;
/*     */   private String imServiceName;
/*     */   private long imConnTimeout;
/*     */   private IMSession imSession;
/* 105 */   private Map<String, PartnerInfo> knownPartners = new HashMap();
/* 106 */   private Map<String, IMUser.IMUserStatus> knownPartnersStatus = new HashMap();
/* 107 */   private Map<String, String> userIdByEmail = new HashMap();
/*     */   private Map<String, ChatHelper> openedChatHelpers;
/*     */   private Map<String, String> openedChatPartners;
/*     */   private IMUserStatusHandler imUserStatusHandler;
/* 111 */   private boolean alreadyClosed = false;
/* 112 */   private boolean activityFlag = true;
/*     */ 
/*     */   private IMSessionHandler(HttpSession httpSession) throws Exception {
/* 115 */     setHttpSession(httpSession);
/* 116 */     setAliveVerifiers();
/* 117 */     setIMSession();
/* 118 */     setIMServerHostname();
/* 119 */     setIMServerPort();
/* 120 */     setIMCommunity();
/* 121 */     setIMServiceName();
/* 122 */     setIMConnectionTimeout();
/* 123 */     this.knownPartners = new HashMap();
/* 124 */     this.openedChatHelpers = new HashMap();
/* 125 */     this.openedChatPartners = new HashMap();
/*     */   }

/*     */   private void setHttpSession(HttpSession httpSession) {
/* 129 */     if (httpSession == null) {
/* 130 */       throw new IllegalArgumentException("HttpSession invalid");
/*     */     }
/* 132 */     this.httpSession = httpSession;
/*     */   }

/*     */   private void setAliveVerifiers() throws Exception {
/*     */     try {
/* 137 */       MXSession mxSession = SessionInfoHelper.getMXSession(this.httpSession);
/* 138 */       mxSession.addMXSessionListener(this);
/*     */ 
/* 140 */       this.mxSessionAliveVerifier = MxSessionAliveVerifier.getAliveVerifier(this);
/* 141 */       IMSessionHandlerAliveVerifier.startAliveVerifier(this);
/*     */     } catch (NullPointerException e) {
/* 143 */       logDebug(new StringBuilder().append("Could not create IMSessionHandler because could not get Maximo user information. Reason: there is no Maximo session related to HttpSession ").append(this.httpSession.getId()).append(" (user is not logged in)").toString());
/*     */ 
/* 145 */       throw new Exception("Could not create IMSessionHandler because could not get Maximo user information");
/*     */     }
/*     */   }









/*     */   public static synchronized IMSessionHandler getIMSessionHandler(HttpSession httpSession)
/*     */   {
/* 159 */     IMSessionHandler imSessionHandler = (IMSessionHandler)httpSession.getAttribute("im_session_handler");
/* 160 */     if (imSessionHandler == null) {
/*     */       try {
/* 162 */         imSessionHandler = new IMSessionHandler(httpSession);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 166 */         return null;
/*     */       }
/* 168 */       httpSession.setAttribute("im_session_handler", imSessionHandler);
/*     */     }
/* 170 */     return imSessionHandler;
/*     */   }








/*     */   public static synchronized boolean hasIMSessionHandler(HttpSession session)
/*     */   {
/* 182 */     return (session.getAttribute("im_session_handler") != null);
/*     */   }



/*     */   private void setIMDriverName()
/*     */     throws RemoteException
/*     */   {
/* 190 */     this.imDriverName = MXServer.getMXServer().getProperty("mxe.imi.driver");
/*     */     try {
/* 192 */       this.imVendor = IMVendor.valueOf(this.imDriverName);
/*     */     } catch (IllegalArgumentException e) {
/* 194 */       this.imDriverName = "";
/* 195 */       this.imVendor = IMVendor.none;
/* 196 */       logDebug("An empty IM driver was set in Maximo System Properties application. So that the IM session will not be able to be opened");
/*     */     }
/*     */   }


/*     */   private void setIMServerHostname()
/*     */     throws RemoteException
/*     */   {
/* 204 */     this.imServerHostname = MXServer.getMXServer().getProperty("mxe.imi.serverhostname");
/* 205 */     if ((this.imServerHostname == null) || (this.imServerHostname.trim().equals(""))) {
/* 206 */       this.imServerHostname = "";
/* 207 */       logDebug("An empty IM server hostname was set in Maximo System Properties application. So that the IM session will not be able to be opened");
/*     */     }
/*     */   }


/*     */   private void setIMServerPort()
/*     */     throws RemoteException
/*     */   {
/* 215 */     this.imServerPort = MXServer.getMXServer().getProperty("mxe.imi.serverport");
/* 216 */     if ((this.imServerPort == null) || (this.imServerPort.trim().equals(""))) {
/* 217 */       this.imServerPort = "";
/* 218 */       logDebug("An empty IM server port was set in Maximo System Properties application. So that IM driver will use the default server port");
/*     */     }
/*     */   }


/*     */   private void setIMCommunity()
/*     */     throws RemoteException
/*     */   {
/* 226 */     this.imCommunity = MXServer.getMXServer().getProperty("mxe.imi.community");
/* 227 */     if ((this.imCommunity == null) || (this.imCommunity.trim().equals(""))) {
/* 228 */       this.imCommunity = "";
/* 229 */       logDebug("An empty IM community was set in Maximo System Properties application. So that IM driver will use the default community");
/*     */     }
/*     */   }


/*     */   private void setIMServiceName()
/*     */     throws RemoteException
/*     */   {
/* 237 */     this.imServiceName = MXServer.getMXServer().getProperty("mxe.imi.service");
/* 238 */     if ((this.imServiceName == null) || (this.imServiceName.trim().equals(""))) {
/* 239 */       this.imServiceName = "";
/* 240 */       logDebug("An empty IM service name was set in Maximo System Properties application. So that IM driver will use the default service name");
/*     */     }
/*     */   }









/*     */   private String getConnTimeout()
/*     */   {
/* 254 */     if (this.imSession == null) {
/* 255 */       return "20000";
/*     */     }
/* 257 */     return String.valueOf(this.imSession.getDefaultConnectionTimeout());
/*     */   }



/*     */   private void setIMConnectionTimeout()
/*     */     throws RemoteException
/*     */   {
/* 265 */     String default_connTimeout = getConnTimeout();
/* 266 */     String connTimeout = MXServer.getMXServer().getProperty("mxe.imi.connectiontimeout");
/* 267 */     if ((connTimeout == null) || (connTimeout.trim().equals(""))) {
/* 268 */       logDebug(new StringBuilder().append("An empty connection timeout was set in Maximo System Properties application. So that the default value (").append(default_connTimeout).append(") will be used").toString());
/*     */ 
/* 270 */       connTimeout = default_connTimeout;
/*     */     }
/*     */     try {
/* 273 */       this.imConnTimeout = Long.parseLong(connTimeout);
/*     */     } catch (NumberFormatException e) {
/* 275 */       logDebug(new StringBuilder().append("An invalid connection timeout (").append(connTimeout).append(") was set in Maximo System Properties application. So that the default value will be used (").append(default_connTimeout).append(")").toString());

/*     */ 
/* 278 */       this.imConnTimeout = Long.parseLong(default_connTimeout);
/*     */     }
/*     */   }

/*     */   private void setIMSession() throws IMException, RemoteException {
/* 283 */     setIMDriverName();
/*     */     try {
/* 285 */       switch (1.$SwitchMap$com$ibm$tivoli$imi$controller$IMSessionHandler$IMVendor[this.imVendor.ordinal()])
/*     */       {/*     */       case 1:
/* 287 */         Class.forName(IMDriverSTImpl.class.getName());
/* 288 */         break;
/*     */       case 2:
/*     */       case 3:
/* 291 */         Class.forName(IMDriverXMPPImpl.class.getName());
/* 292 */         break;
/*     */       case 4:
/* 294 */         Class.forName(IMDriverMocImpl.class.getName());
/* 295 */         break;


/*     */       case 5:
/* 299 */         this.imSession = null;
/* 300 */         return;
/*     */       }
/*     */     } catch (ClassNotFoundException e) {
/* 303 */       throw new IMException(IMException.Code.INVALID_DRIVER, new StringBuilder().append("IM driver class not found in classpath for driver ").append(this.imDriverName).toString(), e);
/*     */     }
/*     */ 
/* 306 */     this.imSession = IMDriverManager.createChatSession(this.imDriverName);
/*     */   }







/*     */   public synchronized boolean validate()
/*     */     throws RemoteException
/*     */   {
/* 318 */     recordActivity("validate");
/* 319 */     refreshIMServerHostname();
/* 320 */     refreshIMConnectionTimeout();
/* 321 */     if ((this.imServerHostname == null) || (this.imServerHostname.trim().equals(""))) {
/* 322 */       return false;
/*     */     }
/* 324 */     UserInfo userInfo = getUserInfo();
/* 325 */     if ((userInfo.getIMUserID() == null) || (userInfo.getIMUserID().trim().equals(""))) {
/* 326 */       return false;
/*     */     }
/*     */ 
/* 329 */     return ((userInfo.getIMUserPassword() != null) && (!(userInfo.getIMUserPassword().trim().equals(""))));
/*     */   }











/*     */   public synchronized boolean refreshIMServerHostname()
/*     */     throws RemoteException
/*     */   {
/* 345 */     recordActivity("refresh server hostname");
/* 346 */     String current_imServerHostname = this.imServerHostname;
/* 347 */     String new_imServerHostname = MXServer.getMXServer().getProperty("mxe.imi.serverhostname");
/* 348 */     if (current_imServerHostname.equals(new_imServerHostname)) {
/* 349 */       return false;
/*     */     }
/* 351 */     if ((new_imServerHostname == null) || (new_imServerHostname.trim().equals(""))) {
/* 352 */       logDebug("Warning: An empty IM server hostname was set in Maximo System Properties application. So that IM connection will not be able to be opened anymore.");
/* 353 */       new_imServerHostname = "";
/*     */     }
/* 355 */     this.imServerHostname = new_imServerHostname;
/* 356 */     logDebug(new StringBuilder().append("Refreshing IM server hostname with the new value '").append(this.imServerHostname).append("'").toString());
/* 357 */     return true;
/*     */   }




/*     */   public synchronized boolean refreshIMConnectionTimeout()
/*     */     throws RemoteException
/*     */   {
/* 366 */     recordActivity("refresh connection timeout");
/* 367 */     String new_imConnTimeout = MXServer.getMXServer().getProperty("mxe.imi.connectiontimeout");
/* 368 */     if ((new_imConnTimeout == null) || (new_imConnTimeout.trim().equals(""))) {
/* 369 */       return false;
/*     */     }
/* 371 */     String current_imConnTimeout = String.valueOf(this.imConnTimeout);
/* 372 */     if (current_imConnTimeout.equals(new_imConnTimeout))
/* 373 */       return false;
/*     */     Long long_new_imConnTimeout;
/*     */     try
/*     */     {
/* 377 */       long_new_imConnTimeout = Long.valueOf(Long.parseLong(new_imConnTimeout));
/*     */     } catch (NumberFormatException e) {
/* 379 */       logDebug(new StringBuilder().append("An invalid connection timeout was set in Maximo System Properties application (").append(new_imConnTimeout).append("). So that the current value will be kept (").append(this.imConnTimeout).append(")").toString());
/*     */ 
/* 381 */       return false;
/*     */     }
/* 383 */     this.imConnTimeout = long_new_imConnTimeout.longValue();
/* 384 */     logDebug(new StringBuilder().append("Refreshing IM server connection timeout with the new value ").append(this.imConnTimeout).toString());
/* 385 */     return true;
/*     */   }







/*     */   private void verifyIMSession()
/*     */     throws IMException
/*     */   {
/* 397 */     if (this.imSession == null)
/* 398 */       throw new IMException("It is not possible to use IM session because IM driver has not been set yet");
/*     */   }











/*     */   public synchronized boolean openIMSession()
/*     */     throws IMException, RemoteException
/*     */   {
/* 414 */     setIMSession();
/* 415 */     verifyIMSession();
/* 416 */     abortedChatHelpers.clear();
/* 417 */     recordActivity("open IM session");
/*     */ 
/* 419 */     if (this.imSession.isOpened()) {
/* 420 */       logInfo("Attempt to open IM session that is already opened");
/* 421 */       return false;
/*     */     }
/*     */ 
/* 424 */     refreshIMServerHostname();
/* 425 */     setIMServerPort();
/* 426 */     setIMCommunity();
/* 427 */     setIMServiceName();
/* 428 */     refreshIMConnectionTimeout();
/* 429 */     UserInfo userInfo = getUserInfo();
/*     */ 
/* 431 */     Properties properties = new Properties();
/* 432 */     properties.put(IMDriver.RequiredProperties.SERVER_HOSTNAME.toString(), this.imServerHostname);
/* 433 */     properties.put(IMDriver.RequiredProperties.USER_ID.toString(), userInfo.getIMUserID());
/* 434 */     properties.put(IMDriver.RequiredProperties.USER_PASSWORD.toString(), userInfo.getIMUserPassword());
/* 435 */     properties.put(IMDriver.RequiredProperties.CONNECTION_TIMEOUT.toString(), Long.valueOf(this.imConnTimeout));
/*     */ 
/* 437 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$controller$IMSessionHandler$IMVendor[this.imVendor.ordinal()])
/*     */     {/*     */     case 1:
/* 439 */       properties.put(IMDriverSTImpl.OptionalProperties.COMMUNITY.toString(), this.imCommunity);
/* 440 */       break;
/*     */     case 2:
/*     */     case 3:
/* 443 */       properties.put(IMDriverXMPPImpl.OptionalProperties.SERVER_PORT.toString(), this.imServerPort);
/* 444 */       properties.put(IMDriverXMPPImpl.OptionalProperties.SERVICE_NAME.toString(), this.imServiceName);




/*     */     case 4:
/*     */     }
/*     */ 
/* 452 */     this.imSession.configure(properties);
/*     */     try
/*     */     {
/* 455 */       this.imSession.open();
/* 456 */       this.imUserStatusHandler = this.imSession.createUserStatusHandler();
/* 457 */       this.imUserStatusHandler.addListener(this);
/*     */     } catch (IMException e) {
/* 459 */       userInfo.refresh();
/* 460 */       throw e;
/*     */     }
/*     */ 
/* 463 */     logInfo("IM session opened");
/* 464 */     return true;
/*     */   }










/*     */   public synchronized boolean openIMSession(IMUser.IMUserStatus imUserStatus)
/*     */     throws IMException, RemoteException
/*     */   {
/* 479 */     boolean result = openIMSession();
/* 480 */     changeUserStatus(imUserStatus);
/* 481 */     return result;
/*     */   }













/*     */   public synchronized boolean closeIMSession(boolean saveFlag, WebClientSession webClientSession)
/*     */     throws IMException, TsdIMException
/*     */   {
/* 499 */     recordActivity("close IM session");
/* 500 */     if ((this.imSession == null) || (!(this.imSession.isOpened()))) {
/* 501 */       logInfo("Attempt to close IM session that is not opened");
/* 502 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 506 */       closeAllOpenedChatSessions(saveFlag, webClientSession);
/*     */     } catch (Exception e) {
/* 508 */       if (saveFlag) {
/* 509 */         throw new TsdIMException(TsdIMException.Code.CHAT_ABORTED_NOT_SAVED);
/*     */       }
/* 511 */       throw new TsdIMException(TsdIMException.Code.CHAT_ABORTION_EXCEPTION);
/*     */     }
/*     */ 
/* 514 */     this.imSession.close();
/*     */ 
/* 516 */     this.knownPartnersStatus.clear();
/* 517 */     this.userIdByEmail.clear();
/* 518 */     this.knownPartners.clear();
/*     */ 
/* 520 */     logInfo("IM session closed");
/* 521 */     return true;
/*     */   }

/*     */   public synchronized boolean closeIMSession(boolean saveFlag, HttpServletRequest request) throws IMException, TsdIMException
/*     */   {
/* 526 */     WebClientSession webClientSession = WebClientRuntime.getWebClientRuntime().getWebClientSession(request);
/* 527 */     return closeIMSession(saveFlag, webClientSession);
/*     */   }

/*     */   private void closeAllOpenedChatSessions(boolean saveFlag, WebClientSession webClientSession) throws Exception {
/* 531 */     if (this.openedChatHelpers.size() == 0) {
/* 532 */       return;
/*     */     }
/* 534 */     for (ChatHelper openedChatHelper : this.openedChatHelpers.values()) {
/* 535 */       this.openedChatPartners.remove(openedChatHelper.getSessionId());
/* 536 */       abortedChatHelpers.put(openedChatHelper.getSessionId(), Boolean.valueOf(saveFlag));
/* 537 */       openedChatHelper.abortConversation(saveFlag, webClientSession);
/*     */     }
/* 539 */     logInfo("The chat sessions still opened were closed");
/*     */   }

/*     */   public void changeUserStatus(IMUser.IMUserStatus imUserStatus) throws IMException {
/* 543 */     verifyIMSession();
/* 544 */     this.imSession.changeUserStatus(imUserStatus);
/*     */   }

/*     */   HttpSession getHttpSession() {
/* 548 */     return this.httpSession;
/*     */   }

/*     */   private UserInfo getUserInfo() {
/* 552 */     return getUserInfo(this.httpSession);
/*     */   }







/*     */   public static UserInfo getUserInfo(HttpSession httpSession)
/*     */   {
/* 563 */     UserInfo userInfo = (UserInfo)httpSession.getAttribute("im_user_info");
/* 564 */     if (userInfo == null) {
/*     */       try {
/* 566 */         userInfo = new UserInfo(httpSession);
/* 567 */         httpSession.setAttribute("im_user_info", userInfo);
/*     */       } catch (IllegalArgumentException e) {
/*     */       }
/*     */       catch (SessionInfoException e) {
/* 571 */         logError(e);
/*     */       }
/*     */     }
/* 574 */     return userInfo;
/*     */   }

/*     */   public String getImDriverName() {
/* 578 */     recordActivity("get driver name");
/* 579 */     return this.imDriverName;
/*     */   }



/*     */   public String getIMServerHostname()
/*     */   {
/* 586 */     recordActivity("get server hostname");
/* 587 */     return this.imServerHostname;
/*     */   }



/*     */   public String getIMConnectionTimeout()
/*     */   {
/* 594 */     recordActivity("get connection timeout");
/* 595 */     return String.valueOf(this.imConnTimeout);
/*     */   }









/*     */   public PartnerInfo getPartnerInfo(HttpServletRequest httpRequest)
/*     */     throws RemoteException, NoSuchAlgorithmException, MXException, IMException
/*     */   {
/* 609 */     recordActivity("get partner info");
/* 610 */     if (httpRequest == null)
/* 611 */       throw new IllegalArgumentException("Invalid request");
/*     */     try
/*     */     {
/* 614 */       String sessionId = SessionInfoHelper.getSessionId(httpRequest);
/* 615 */       PartnerInfo partnerInfo = (PartnerInfo)this.knownPartners.get(sessionId);
/* 616 */       if ((partnerInfo != null) && (!(partnerInfo.isValid(httpRequest)))) {
/* 617 */         logDebug(new StringBuilder().append("Partner IM Id ('").append(partnerInfo.getIMPartnerID()).append("') is no longer valid so it is going to be updated").toString());
/*     */ 
/* 619 */         partnerInfo = null;
/*     */       }
/* 621 */       if (partnerInfo == null) {
/*     */         try {
/* 623 */           partnerInfo = new PartnerInfo(httpRequest);
/*     */         } catch (IllegalArgumentException e) {
/* 625 */           logDebug("Partner info is null");
/* 626 */           return null;
/*     */         }
/* 628 */         this.knownPartners.put(sessionId, partnerInfo);
/*     */       } else {
/* 630 */         partnerInfo.refreshIMID(httpRequest);
/*     */       }
/* 632 */       if (isIMSessionOpened())

/*     */       {
/* 635 */         IMUser imUser = this.imSession.resolve(partnerInfo.getIMPartnerID());
/*     */ 
/* 637 */         if ((imUser != null) && (((partnerInfo.isFreshIMID()) || (!(this.imUserStatusHandler.hasListenedUser(imUser)))))) {
/* 638 */           logDebug(new StringBuilder().append("Partner resolved: ").append(imUser.getUserId()).toString());
/* 639 */           if (!(partnerInfo.getIMPartnerID().equalsIgnoreCase(imUser.getUserId()))) {
/* 640 */             this.userIdByEmail.put(partnerInfo.getIMPartnerID(), imUser.getUserId());
/* 641 */             logDebug(new StringBuilder().append("userIdByEmail (").append(partnerInfo.getIMPartnerID()).append(", ").append(imUser.getUserId()).append(")").toString());
/*     */           }
/* 643 */           this.imUserStatusHandler.addListenedUser(imUser);
/*     */         }
/* 645 */         if (partnerInfo.isFreshIMID()) {
/* 646 */           partnerInfo.registeredIMID();
/*     */         }
/*     */       }
/* 649 */       return partnerInfo;
/*     */     } catch (SessionInfoException e) {
/* 651 */       logDebug(new StringBuilder().append("Could not get partner info because could not get session id: ").append(e.getMessage()).toString()); }
/* 652 */     return null;
/*     */   }








/*     */   public synchronized boolean isIMSessionOpened()
/*     */   {
/* 664 */     recordActivity("is opened");
/* 665 */     if (this.imSession == null) {
/* 666 */       return false;
/*     */     }
/* 668 */     return this.imSession.isOpened();
/*     */   }

/*     */   public void userStatusChanged(IMUserStatusEvent userStatusEvent) {
/* 672 */     String imPartnerId = userStatusEvent.getContent().getUserId();
/* 673 */     IMUser.IMUserStatus userStatus = userStatusEvent.getUserStatus();
/* 674 */     if (this.knownPartnersStatus != null) {
/* 675 */       this.knownPartnersStatus.put(imPartnerId, userStatus);
/* 676 */       logDebug(new StringBuilder().append("Partner '").append(imPartnerId).append("' is ").append(userStatus.toString()).toString());
/*     */     }
/*     */   }






/*     */   public IMUser.IMUserStatus getUserStatus(String userIdOrEmail)
/*     */   {
/* 687 */     recordActivity("get user status");
/* 688 */     IMUser.IMUserStatus userStatus = null;
/*     */ 
/* 690 */     String userId = (String)this.userIdByEmail.get(userIdOrEmail);
/* 691 */     if (userId == null)
/*     */     {
/* 693 */       userId = userIdOrEmail;
/*     */     }
/* 695 */     if (this.knownPartnersStatus != null) {
/* 696 */       userStatus = (IMUser.IMUserStatus)this.knownPartnersStatus.get(userId);
/*     */     }
/* 698 */     if (userStatus == null) {
/* 699 */       userStatus = IMUser.IMUserStatus.UNKNOW;
/*     */     }
/* 701 */     return userStatus;
/*     */   }

/*     */   IMMessageHandler createMessageHandler(String partnerId) throws IMException {
/* 705 */     verifyIMSession();
/*     */ 
/* 707 */     recordActivity("create message handler");
/* 708 */     IMUser imUser = this.imSession.resolve(partnerId);
/* 709 */     if (imUser == null) {
/* 710 */       throw new IMException(IMException.Code.RESOLVE_EXCEPTION, new StringBuilder().append("User ").append(partnerId).append(" could not be resolved").toString());
/*     */     }
/* 712 */     return this.imSession.createMessageHandler(imUser);
/*     */   }

/*     */   public IMUser resolve(String userDisplayName) throws IMException {
/* 716 */     verifyIMSession();
/*     */ 
/* 718 */     recordActivity("resolve");
/* 719 */     if ((userDisplayName == null) || (userDisplayName.trim().equals(""))) {
/* 720 */       return null;
/*     */     }
/* 722 */     return this.imSession.resolve(userDisplayName);
/*     */   }

/*     */   public boolean isUserAvailable(String userId) {
/* 726 */     recordActivity("is available");
/* 727 */     return DynamicIcon.isAvailable(getUserStatus(userId));
/*     */   }

/*     */   public synchronized ChatHelper getChatHelper(HttpServletRequest httpRequest, String sessionId, long chatIdentifier, String partnerIMId) throws Exception
/*     */   {
/* 732 */     ChatHelper chatHelper = (ChatHelper)this.openedChatHelpers.get(sessionId);
/* 733 */     if (chatHelper == null) {
/* 734 */       if (this.openedChatPartners.containsValue(partnerIMId)) {
/* 735 */         throw new TsdIMException(TsdIMException.Code.INVALID_CHAT_IDENTIFIER);
/*     */       }
/* 737 */       chatHelper = new ChatHelper(httpRequest, sessionId, this, chatIdentifier);
/* 738 */       this.openedChatHelpers.put(sessionId, chatHelper);
/* 739 */       this.openedChatPartners.put(sessionId, partnerIMId);
/* 740 */       logDebug(new StringBuilder().append("New chat helper created for sessionid: ").append(sessionId).toString());
/*     */     } else {
/* 742 */       chatHelper.validate(chatIdentifier);
/*     */     }
/* 744 */     return chatHelper;
/*     */   }

/*     */   public synchronized boolean isPartnerChatting(String partnerIMId) {
/* 748 */     return this.openedChatPartners.containsValue(partnerIMId);
/*     */   }

/*     */   public void chatClosed(String sessionId) {
/* 752 */     recordActivity("chat closed");
/* 753 */     this.openedChatHelpers.remove(sessionId);
/* 754 */     this.openedChatPartners.remove(sessionId);
/* 755 */     logDebug(new StringBuilder().append("Chat helper closed for sessionid: ").append(sessionId).toString());
/*     */   }

/*     */   protected void finalize() throws Throwable
/*     */   {
/* 760 */     if ((this.imSession != null) && (this.imSession.isOpened())) {
/* 761 */       this.imSession.close();
/* 762 */       logInfo("IM session closed");
/*     */     }
/*     */   }

/*     */   public void valueBound(HttpSessionBindingEvent arg0) {
/* 767 */     logInfo("IM session handler created");
/*     */   }

/*     */   public void valueUnbound(HttpSessionBindingEvent arg0) {
/* 771 */     closeIMSessionHandler("Http session was closed");
/*     */   }




/*     */   public void serverConnectionError(MXEvent evt) {
/* 778 */     closeIMSessionHandler("MX serverConnectionError");
/*     */   }

/*     */   public void serverDisconnected(MXEvent evt) {
/* 782 */     closeIMSessionHandler("MXSession closed");
/*     */   }












/*     */   synchronized void closeIMSessionHandler(String reason, boolean saveFlag, WebClientSession webClientSession)
/*     */   {
/* 798 */     if (this.alreadyClosed) {
/* 799 */       return;
/*     */     }
/* 801 */     this.alreadyClosed = true;
/*     */     try {
/* 803 */       closeIMSession(saveFlag, webClientSession);
/*     */     } catch (Exception e) {
/* 805 */       logDebug(new StringBuilder().append("The following exception occurred when attempting to abort conversations: ").append(e.getMessage()).toString());
/*     */     }
/* 807 */     if (this.mxSessionAliveVerifier != null)
/* 808 */       this.mxSessionAliveVerifier.closeVerifier();
/*     */     else {
/* 810 */       logDebug("The mxSessionAliveVerifier was null");
/*     */     }
/* 812 */     if (this.httpSession != null) {
/*     */       try {
/* 814 */         MXSession mxSession = SessionInfoHelper.getMXSession(this.httpSession);
/* 815 */         if (mxSession != null) {
/* 816 */           mxSession.removeMXSessionListener(this);
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/* 824 */     if (this.httpSession != null) {
/* 825 */       this.httpSession.removeAttribute("im_session_handler");
/*     */     }
/* 827 */     logInfo(new StringBuilder().append("IM session handler closed. Reason: ").append(reason).toString());
/*     */   }











/*     */   synchronized void closeIMSessionHandler(String reason)
/*     */   {
/* 842 */     closeIMSessionHandler(reason, false, null);
/*     */   }

/*     */   public static synchronized boolean wasChatHelperAborted(String sessionId) {
/* 846 */     return abortedChatHelpers.containsKey(sessionId);
/*     */   }











/*     */   public static synchronized boolean wasChatTranscriptSavedBeforeAbortion(String sessionId)
/*     */   {
/* 861 */     Boolean result = (Boolean)abortedChatHelpers.get(sessionId);
/* 862 */     return ((result == null) ? false : result.booleanValue());
/*     */   }


/*     */   synchronized void recordActivity(String activity)
/*     */   {
/* 868 */     this.activityFlag = true;
/*     */   }

/*     */   boolean isActive() {
/* 872 */     if ((this.openedChatHelpers != null) && (this.openedChatHelpers.size() != 0)) {
/* 873 */       logDebug("IM session handler is active because there are chat windows opened");
/* 874 */       return true;
/*     */     }
/* 876 */     logDebug(new StringBuilder().append("IM session handler is").append((this.activityFlag) ? "" : " not").append(" active").toString());
/* 877 */     return this.activityFlag;
/*     */   }

/*     */   public void resetActivityFlag() {
/* 881 */     logDebug("IM session handler activity flag has been reset");
/* 882 */     this.activityFlag = false;
/*     */   }

/*     */   public static void logInfo(String logMessage) {
/* 886 */     if (logger != null)
/* 887 */       logger.info(logMessage);
/*     */   }







/*     */   public static void logError(Throwable throwable)
/*     */   {
/* 898 */     if (logger != null)
/* 899 */       logger.error(throwable);
/*     */   }

/*     */   public static void logError(String logMessage, Throwable throwable)
/*     */   {
/* 904 */     if (logger != null)
/* 905 */       logger.error(logMessage, throwable);
/*     */   }
/*     */ 
/*     */   private static enum IMVendor
/*     */   {
/* 185 */     ibm_sametime, jabber, google_talk, ms_communicator, none;
/*     */   }
/*     */ }
