/*    */ package com.ibm.tivoli.imi.controller;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 












/*    */ public class IMIconRefreshHelper
/*    */ {
/*    */   public static void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 23 */     String imIconCode = DynamicIcon.getCodeForLookupError();
/*    */     try
/*    */     {
/* 26 */       DynamicIcon icon = new DynamicIcon(request);
/* 27 */       imIconCode = icon.getCode();
/*    */     } catch (Exception e) {
/* 29 */       IMSessionHandler.logError(e);
/*    */     }
/*    */ 
/* 32 */     response.setHeader("Pragma", "no-cache");
/* 33 */     response.setDateHeader("Expires", 0L);
/* 34 */     response.setHeader("Cache-Control", "no-cache");
/* 35 */     response.setStatus(200);
/* 36 */     response.resetBuffer();
/*    */     try
/*    */     {
/* 39 */       response.getWriter().print(imIconCode);
/* 40 */       response.getWriter().close();
/*    */     } catch (Exception e) {
/* 42 */       IMSessionHandler.logError(e);
/*    */     }
/*    */   }
/*    */ }
