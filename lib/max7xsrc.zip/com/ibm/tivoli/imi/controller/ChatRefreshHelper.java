/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.PrintWriter;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 













/*     */ public class ChatRefreshHelper
/*     */ {
/*     */   static void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  28 */     HttpSession session = request.getSession();
/*     */ 
/*  30 */     String sessionId = request.getParameter("sessionid");
/*  31 */     boolean wasAborted = IMSessionHandler.wasChatHelperAborted(sessionId);
/*     */ 
/*  33 */     String result = "";
/*     */ 
/*  35 */     if (wasAborted) {
/*  36 */       boolean wasSaved = IMSessionHandler.wasChatTranscriptSavedBeforeAbortion(sessionId);
/*     */       try {
/*  38 */         String alterMessage = (wasSaved) ? Messages.getString(session, "ALERT_CHAT_ABORTED_saved") : Messages.getString(session, "ALERT_CHAT_ABORTED_notSaved");
/*     */ 
/*  40 */         response.addHeader("alert", alterMessage);
/*     */       }
/*     */       catch (SessionInfoException e) {
/*  43 */         response.addHeader("alert", "null alert message");
/*  44 */         IMSessionHandler.logError(e);
/*     */       }
/*  46 */       response.addHeader("aborted", "true");
/*  47 */       IMSessionHandler.logInfo("This chat conversation was aborted! Chat transcript saved: " + wasSaved);
/*     */     } else {
/*  49 */       boolean stop = Boolean.parseBoolean(request.getHeader("stop"));
/*  50 */       long chatIdentifier = Long.parseLong(request.getHeader("chatIdentifier"));
/*  51 */       String partnerIMId = request.getHeader("partner");
/*     */ 
/*  53 */       IMSessionHandler imSessionHandler = IMSessionHandler.getIMSessionHandler(session);
/*  54 */       ChatHelper chatHelper = null;
/*     */       try {
/*  56 */         chatHelper = imSessionHandler.getChatHelper(request, sessionId, chatIdentifier, partnerIMId);
/*     */ 
/*  58 */         if ((chatHelper.isNewChatHelper()) && (chatHelper.isNewRecord())) {
/*  59 */           response.addHeader("willSave", "false");
/*  60 */           response.addHeader("alert", Messages.getString(session, "ALERT_NEW_RECORD"));
/*     */         }
/*  62 */         result = chatHelper.popMessageBuffer();
/*  63 */         if ((result == null) || (result.trim().equals(""))) {
/*  64 */           result = "";
/*     */         }
/*     */ 
/*  67 */         if (stop) {
/*  68 */           boolean saved = chatHelper.closeConversation(request);
/*  69 */           if (saved)
/*  70 */             response.addHeader("alert", Messages.getString(session, "ALERT_TRANSCRIPT_NOT_SAVED"));
/*     */         }
/*     */         else {
/*  73 */           BufferedReader br = request.getReader();
/*  74 */           StringBuffer buff = new StringBuffer();
/*  75 */           int i = br.read();
/*     */ 
/*  77 */           while (i != -1) {
/*  78 */             char c = (char)i;
/*  79 */             if ((c != '\r') && (c != '\f') && (c != '\n')) {
/*  80 */               buff.append(c);
/*     */             }
/*  82 */             i = br.read();
/*     */           }
/*  84 */           br.close();
/*  85 */           String message = buff.toString();
/*     */ 
/*  87 */           if ((message != null) && (!(message.trim().equals(""))))
/*     */             try {
/*  89 */               chatHelper.sendMessage(message);
/*     */             } catch (IMException e) {
/*  91 */               if (e.getCode().equals(IMException.Code.MESSAGE_TOO_LONG))
/*  92 */                 response.addHeader("alert", Messages.getString(session, "ALERT_MESSAGE_TOO_LONG"));
/*     */               else
/*  94 */                 throw e;
/*     */             }
/*     */         }
/*     */       }
/*     */       catch (TsdIMException e)
/*     */       {
/* 100 */         if (!(e.getCode().equals(TsdIMException.Code.INVALID_CHAT_IDENTIFIER))) {
/* 101 */           handleException(request, response, chatHelper, result, e);
/*     */         }
/* 103 */         result = "";
/*     */         try {
/* 105 */           response.addHeader("alert", Messages.getString(session, "ALERT_INVALID_CHAT_WINDOW"));
/*     */         }
/*     */         catch (SessionInfoException sie) {
/* 108 */           response.addHeader("alert", "null alert message");
/* 109 */           IMSessionHandler.logError(sie);
/*     */         }
/* 111 */         response.addHeader("aborted", "true");
/* 112 */         IMSessionHandler.logInfo("An invalid (probably duplicated) chat window attempted to establish connection");
/*     */       }
/*     */       catch (Exception e) {
/* 115 */         handleException(request, response, chatHelper, result, e);
/*     */       }
/*     */     }
/*     */ 
/* 119 */     response.setContentType("text/html;charset=UTF-8");
/* 120 */     response.setStatus(200);
/* 121 */     response.resetBuffer();
/*     */     try
/*     */     {
/* 124 */       response.getWriter().print(result);
/* 125 */       response.getWriter().close();
/*     */     } catch (Exception e) {
/* 127 */       IMSessionHandler.logError(e);
/*     */     }
/*     */   }

/*     */   private static void handleException(HttpServletRequest request, HttpServletResponse response, ChatHelper chatHelper, String result, Exception ex)
/*     */   {
/* 133 */     HttpSession session = request.getSession();
/*     */ 
/* 135 */     if ((chatHelper != null) && (chatHelper.isOpened())) {
/*     */       try {
/* 137 */         chatHelper.abortConversation(false, request);
/*     */       } catch (Exception e1) {
/* 139 */         IMSessionHandler.logError(e1);
/*     */       }
/*     */     }
/* 142 */     result = "";
/*     */     try {
/* 144 */       response.addHeader("alert", Messages.getString(session, "ALERT_CHAT_ABORTED_notSaved"));
/*     */     }
/*     */     catch (SessionInfoException sie) {
/* 147 */       response.addHeader("alert", "null alert message");
/* 148 */       IMSessionHandler.logError(sie);
/*     */     }
/* 150 */     response.addHeader("aborted", "true");
/* 151 */     IMSessionHandler.logInfo("This chat conversation was aborted (Reason: " + ex.getMessage() + "). Chat transcript saved: false");
/*     */   }
/*     */ }
