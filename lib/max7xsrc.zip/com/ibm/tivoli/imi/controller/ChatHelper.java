/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMException.Code;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageEvent;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageHandler;
/*     */ import com.ibm.tivoli.imi.spi.IMMessageListener;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 















/*     */ public class ChatHelper
/*     */   implements IMMessageListener
/*     */ {
/*     */   private HttpSession httpSession;
/*     */   private String sessionId;
/*     */   private IMSessionHandler imSessionHandler;
/*     */   private IMMessageHandler imMessageHandler;
/*     */   private PartnerInfo partnerInfo;
/*  42 */   private StringBuffer chatHistory = new StringBuffer();
/*  43 */   private StringBuffer existingMessage = new StringBuffer();
/*     */   private MboRemote mbo;
/*  45 */   private boolean isOpened = false;
/*  46 */   private boolean isNew = true;
/*     */   private long chatIdentifier;
/*     */   private static final String LINE_FEED = "\r\n";
/*     */   private static final String CHAT_CLOSED_DELIMITER = " *** ";
/*     */ 
/*     */   ChatHelper(HttpServletRequest httpRequest, String sessionId, IMSessionHandler imSessionHandler, long chatIdentifier)
/*     */     throws Exception
/*     */   {
/*  54 */     setHttpSession(httpRequest.getSession());
/*  55 */     setMbo(httpRequest);
/*  56 */     setIMSessionHandler(imSessionHandler);
/*  57 */     setSessionId(sessionId);
/*  58 */     setPartnerInfo(httpRequest);
/*  59 */     setMessageHandler();
/*  60 */     setChatIdentifier(chatIdentifier);
/*     */   }

/*     */   private void setHttpSession(HttpSession httpSession) {
/*  64 */     if (httpSession == null) {
/*  65 */       throw new IllegalArgumentException("Invalid session");
/*     */     }
/*  67 */     this.httpSession = httpSession;
/*     */   }

/*     */   private void setMbo(HttpServletRequest request) throws Exception {
/*  71 */     this.mbo = SessionInfoHelper.getMbo(request);
/*  72 */     if (this.mbo != null)
/*     */       return;
/*  74 */     throw new Exception("Null MBO");
/*     */   }

/*     */   private void setIMSessionHandler(IMSessionHandler imSessionHandler)
/*     */   {
/*  79 */     if (imSessionHandler == null) {
/*  80 */       throw new IllegalArgumentException("Invalid IM session handler");
/*     */     }
/*  82 */     this.imSessionHandler = imSessionHandler;
/*     */   }

/*     */   private void setSessionId(String sessionId) {
/*  86 */     if ((sessionId == null) || (sessionId.trim().equals(""))) {
/*  87 */       throw new IllegalArgumentException("Invalid Session Id");
/*     */     }
/*  89 */     this.sessionId = sessionId;
/*     */   }

/*     */   private void setPartnerInfo(HttpServletRequest httpRequest) throws RemoteException, NoSuchAlgorithmException, MXException, IMException
/*     */   {
/*  94 */     this.partnerInfo = this.imSessionHandler.getPartnerInfo(httpRequest);
/*  95 */     if (this.partnerInfo == null)
/*  96 */       throw new IllegalArgumentException("Partner information must not be null");
/*     */   }

/*     */   private void setMessageHandler() throws IMException
/*     */   {
/* 101 */     if ((this.imSessionHandler == null) || (!(this.imSessionHandler.isIMSessionOpened()))) {
/* 102 */       throw new IllegalArgumentException("Invalid IM session handler");
/*     */     }
/* 104 */     this.imMessageHandler = this.imSessionHandler.createMessageHandler(this.partnerInfo.getIMPartnerID());
/* 105 */     this.imMessageHandler.addListener(this);
/* 106 */     this.isOpened = true;
/*     */   }

/*     */   private void setChatIdentifier(long chatIdentifier) {
/* 110 */     this.chatIdentifier = chatIdentifier;
/*     */   }

/*     */   public void validate(long chatIdentifier) throws TsdIMException {
/* 114 */     if (this.chatIdentifier != chatIdentifier)
/* 115 */       throw new TsdIMException(TsdIMException.Code.INVALID_CHAT_IDENTIFIER);
/*     */   }

/*     */   String getSessionId()
/*     */   {
/* 120 */     return this.sessionId;
/*     */   }

/*     */   public synchronized boolean isNewChatHelper() {
/* 124 */     boolean result = this.isNew;
/* 125 */     this.isNew = false;
/* 126 */     return result;
/*     */   }

/*     */   public boolean isNewRecord() throws RemoteException {
/* 130 */     return this.mbo.isNew();
/*     */   }


/*     */   public synchronized void sendMessage(String message)
/*     */     throws IMException
/*     */   {
/* 137 */     if (this.imMessageHandler == null) {
/* 138 */       throw new IMException(IMException.Code.IM_EXCEPTION, "IM message handler was not set");
/*     */     }
/* 140 */     this.imSessionHandler.recordActivity("message sent");
/* 141 */     this.imMessageHandler.sendMessage(message);
/*     */   }



/*     */   public synchronized String popMessageBuffer()
/*     */   {
/* 148 */     if (this.existingMessage.length() == 0) {
/* 149 */       return null;
/*     */     }
/* 151 */     String result = this.existingMessage.toString();
/* 152 */     this.existingMessage = new StringBuffer();
/* 153 */     return result;
/*     */   }



/*     */   public synchronized void messageReceived(IMMessageEvent messageEvent)
/*     */   {
/* 160 */     this.imSessionHandler.recordActivity("message received");
/* 161 */     String message = messageEvent.getFormatedMessage();
/*     */     try {
/* 163 */       appendMessage(message);
/*     */     } catch (UnsupportedEncodingException e) {
/* 165 */       IMSessionHandler.logError(e);
/*     */     }
/*     */   }





/*     */   private void appendMessage(String message)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 176 */     if (this.existingMessage.length() != 0) {
/* 177 */       this.existingMessage.append("\r\n");
/*     */     }
/* 179 */     if (this.chatHistory.length() != 0) {
/* 180 */       appendMessageInHistory("\r\n");
/*     */     }
/* 182 */     this.existingMessage.append(message);
/* 183 */     appendMessageInHistory(message);
/*     */   }

/*     */   private void appendMessageInHistory(String message) throws UnsupportedEncodingException {
/* 187 */     this.chatHistory.append(message);
/*     */   }






/*     */   public synchronized void conversationClosed(String reason)
/*     */   {
/* 197 */     if (!(this.isOpened))
/* 198 */       return;
/*     */     try
/*     */     {
/* 201 */       String message = " *** " + Messages.getString(this.httpSession, "CHAT_CLOSED_MESSAGE") + " *** ";
/*     */ 
/* 203 */       appendMessage(message);
/*     */     } catch (Exception e) {
/* 205 */       IMSessionHandler.logError(e);
/*     */     }
/*     */   }







/*     */   public synchronized boolean closeConversation(WebClientSession webClientSession)
/*     */     throws Exception
/*     */   {
/* 218 */     return close(true, webClientSession);
/*     */   }

/*     */   public synchronized boolean closeConversation(HttpServletRequest request) throws Exception {
/* 222 */     WebClientSession webClientSession = WebClientRuntime.getWebClientRuntime().getWebClientSession(request);
/* 223 */     return closeConversation(webClientSession);
/*     */   }











/*     */   public synchronized boolean abortConversation(boolean saveFlag, WebClientSession webClientSession)
/*     */     throws Exception
/*     */   {
/* 239 */     String message = " *** " + Messages.getString(this.httpSession, "CHAT_ABORTED_MESSAGE") + " *** ";
/*     */ 
/* 241 */     appendMessage(message);
/* 242 */     return close(saveFlag, webClientSession);
/*     */   }

/*     */   public synchronized boolean abortConversation(boolean saveFlag, HttpServletRequest request) throws Exception {
/* 246 */     WebClientSession webClientSession = WebClientRuntime.getWebClientRuntime().getWebClientSession(request);
/* 247 */     return abortConversation(saveFlag, webClientSession);
/*     */   }








/*     */   private synchronized boolean close(boolean saveFlag, WebClientSession webClientSession)
/*     */     throws Exception, IOException
/*     */   {
/* 260 */     if (this.isOpened) {
/* 261 */       this.isOpened = false;
/* 262 */       if ((this.imMessageHandler != null) && (this.imMessageHandler.isOpened())) {
/* 263 */         this.imMessageHandler.closeConversation();
/*     */       }
/* 265 */       this.imSessionHandler.chatClosed(this.sessionId);
/* 266 */       if (saveFlag) {
/* 267 */         return saveChatTranscript(webClientSession);
/*     */       }
/*     */     }
/* 270 */     return false;
/*     */   }

/*     */   public boolean isOpened() {
/* 274 */     return this.isOpened;
/*     */   }






/*     */   private boolean saveChatTranscript(WebClientSession webClientSession)
/*     */     throws Exception
/*     */   {
/* 285 */     boolean result = true;
/* 286 */     if (this.mbo.isNew()) {
/* 287 */       IMSessionHandler.logInfo("This chat transcript was not saved because the related record was not saved yet when the chat conversation began.");
/*     */ 
/* 289 */       result = false;
/*     */     } else {
/* 291 */       ChatStopHelper ChatStopHelper = new ChatStopHelper(this.httpSession, this.partnerInfo, this.chatHistory.toString(), this.mbo);
/* 292 */       ChatStopHelper.save(webClientSession);
/*     */     }
/* 294 */     this.chatHistory = new StringBuffer();
/* 295 */     return result;
/*     */   }
/*     */ }
