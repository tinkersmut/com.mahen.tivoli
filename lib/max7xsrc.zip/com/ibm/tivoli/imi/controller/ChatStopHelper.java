/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.app.doclink.DocinfoRemote;
/*     */ import psdi.app.doclink.DocinfoSetRemote;
/*     */ import psdi.app.doclink.DoclinksRemote;
/*     */ import psdi.app.doclink.DoclinksSetRemote;
/*     */ import psdi.common.commlog.CommLogDocSetRemote;
/*     */ import psdi.common.commlog.CommLogRemote;
/*     */ import psdi.common.commlog.CommLogSetRemote;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 
















/*     */ class ChatStopHelper
/*     */ {
/*     */   private HttpSession httpSession;
/*     */   private UserInfo userInfo;
/*     */   private PartnerInfo partnerInfo;
/*     */   private String chatHistory;
/*     */   private MboRemote mbo;
/*     */   private String documentName;
/*     */   private String fileURL;
/*     */   private long newCommLogID;
/*     */   private long newCommLogUID;
/*     */   private static final int MAX_HISTORY_BYTES_LENGTH = 32767;
/*     */ 
/*     */   ChatStopHelper(HttpSession httpSession, PartnerInfo partnerInfo, String chatHistory, MboRemote mbo)
/*     */   {
/*  57 */     setHttpSession(httpSession);
/*  58 */     setUserInfo();
/*  59 */     setPartnerInfo(partnerInfo);
/*  60 */     setChatHistory(chatHistory);
/*  61 */     setMbo(mbo);
/*     */   }

/*     */   private void setHttpSession(HttpSession httpSession) {
/*  65 */     if (httpSession == null) {
/*  66 */       throw new IllegalArgumentException("Invalid session");
/*     */     }
/*  68 */     this.httpSession = httpSession;
/*     */   }

/*     */   private void setUserInfo() {
/*  72 */     this.userInfo = IMSessionHandler.getUserInfo(this.httpSession);
/*     */   }

/*     */   private void setPartnerInfo(PartnerInfo partnerInfo) {
/*  76 */     if (partnerInfo == null) {
/*  77 */       throw new IllegalArgumentException("Invalid Partner Info");
/*     */     }
/*  79 */     this.partnerInfo = partnerInfo;
/*     */   }

/*     */   private void setChatHistory(String chatHistory) {
/*  83 */     if ((chatHistory == null) || (chatHistory.trim().equals(""))) {
/*  84 */       throw new IllegalArgumentException("Invalid Chat History");
/*     */     }
/*  86 */     this.chatHistory = chatHistory;
/*     */   }

/*     */   private void setMbo(MboRemote mbo) {
/*  90 */     if (mbo == null) {
/*  91 */       throw new IllegalArgumentException("Invalid MBO");
/*     */     }
/*  93 */     this.mbo = mbo;
/*     */   }

/*     */   void save(WebClientSession webClientSession) {
/*     */     try {
/*  98 */       createCommLog();
/*  99 */       createAttachedFile();
/* 100 */       linkAttachedFile();
/*     */     } catch (Exception e) {
/* 102 */       IMSessionHandler.logInfo("Chat transcript could not be completely saved. Reason: " + e.getMessage());
/*     */     }
/*     */     try {
/* 105 */       reloadTable(webClientSession);
/*     */     } catch (SessionInfoException e) {
/* 107 */       IMSessionHandler.logInfo("A unexpected problem occured after chat transcript was saved. Reason: " + e.getMessage());
/*     */     }
/*     */   }

/*     */   private void createCommLog()
/*     */     throws RemoteException, MXException, UnsupportedEncodingException, SessionInfoException
/*     */   {
/* 114 */     CommLogSetRemote commLogMboSet = (CommLogSetRemote)this.mbo.getMboSet("COMMLOG");
/*     */ 
/* 116 */     String imUserID = this.userInfo.getIMUserID();
/* 117 */     String mxUserName = this.userInfo.getMXUserName();
/*     */ 
/* 119 */     MXSession mxSession = SessionInfoHelper.getMXSession(this.httpSession);
/*     */ 
/* 121 */     String mxUserEmail = mxSession.getUserInfo().getEmail();
/* 122 */     String imPartnerID = this.partnerInfo.getIMPartnerID();
/* 123 */     String mxPartnerName = this.partnerInfo.getMXPartnerName();
/* 124 */     String mxPartnerEmail = this.partnerInfo.getMXPartnerEmail();
/*     */ 
/* 126 */     boolean validUserEmail = (mxUserEmail != null) && (!(mxUserEmail.trim().equals("")));
/*     */ 
/* 128 */     boolean validPartnerEmail = (mxPartnerEmail != null) && (!(mxPartnerEmail.trim().equals("")));
/*     */ 
/* 130 */     CommLogRemote newCommLog = (CommLogRemote)commLogMboSet.add();
/*     */ 
/* 132 */     newCommLog.setValue("SENDFROM", (validUserEmail) ? mxUserEmail : imUserID);
/* 133 */     newCommLog.setValue("SENDTO", (validPartnerEmail) ? mxPartnerEmail : imPartnerID);
/* 134 */     newCommLog.setValue("CC", "");
/* 135 */     newCommLog.setValue("BCC", "");
/* 136 */     newCommLog.setValue("REPLYTO", (validUserEmail) ? mxUserEmail : imUserID);
/* 137 */     newCommLog.setValue("SUBJECT", "Chat session between " + mxUserName + " and " + mxPartnerName);
/*     */ 
/* 139 */     byte[] historyBytes = this.chatHistory.getBytes("UTF-8");
/* 140 */     if (historyBytes.length > 32767) {
/* 141 */       String shortHistorySuffix = " *** (" + Messages.getString(this.httpSession, "SHORT_HISTORY_SUFFIX") + ") ***";
/* 142 */       int length = 32767 - shortHistorySuffix.getBytes("UTF-8").length;
/* 143 */       String shortHistory = new String(historyBytes, 0, length) + shortHistorySuffix;
/* 144 */       newCommLog.setValue("MESSAGE", shortHistory);
/*     */     } else {
/* 146 */       newCommLog.setValue("MESSAGE", this.chatHistory);
/*     */     }
/*     */ 
/* 149 */     commLogMboSet.save();
/*     */ 
/* 151 */     this.newCommLogID = newCommLog.getLong("COMMLOGID");
/* 152 */     this.newCommLogUID = newCommLog.getLong("COMMLOGUID");
/* 153 */     IMSessionHandler.logInfo("Chat transcript 'Comm Log' created: ID[" + this.newCommLogID + "] UID[" + this.newCommLogUID + "]");
/*     */   }







/*     */   private void createAttachedFile()
/*     */     throws Exception
/*     */   {
/* 165 */     String filePath = MXServer.getMXServer().getProperty("mxe.doclink.doctypes.defpath");
/* 166 */     if ((filePath == null) || (filePath.trim().equals(""))) {
/* 167 */       throw new Exception("Chat transcript file could not be saved because the Maximo system property 'mxe.doclink.doctypes.defpath' is not set");
/*     */     }
/*     */ 
/* 170 */     IMSessionHandler.logDebug("mxe.doclink.doctypes.defpath: " + filePath);

/*     */ 
/* 173 */     filePath = filePath + File.separatorChar + "ATTACHMENTS" + File.separatorChar;
/* 174 */     IMSessionHandler.logDebug("fileRoot: " + filePath);
/*     */ 
/* 176 */     File file = new File(filePath, String.valueOf(System.currentTimeMillis()));
/* 177 */     file.getParentFile().mkdirs();
/*     */ 
/* 179 */     BufferedWriter bw = new BufferedWriter(new FileWriter(file));
/* 180 */     bw.write(this.chatHistory);
/* 181 */     bw.close();
/*     */ 
/* 183 */     this.fileURL = file.getCanonicalPath();
/* 184 */     String fileName = file.getName();
/* 185 */     this.documentName = fileName.substring(0, Math.min(8, fileName.length()));
/*     */ 
/* 187 */     IMSessionHandler.logInfo("Chat transcript file created on: " + file.getCanonicalPath());
/*     */   }

/*     */   private void linkAttachedFile() throws MXException, IOException, SessionInfoException {
/* 191 */     CommLogRemote commLog = getCommLogJustSaved();
/*     */ 
/* 193 */     DoclinksSetRemote doclinksSet = (DoclinksSetRemote)commLog.getMboSet("DOCLINKS");
/* 194 */     DoclinksRemote newDoclinks = (DoclinksRemote)doclinksSet.add();
/*     */ 
/* 196 */     DocinfoSetRemote docinfoSet = (DocinfoSetRemote)newDoclinks.getMboSet("DOCINFO");
/* 197 */     DocinfoRemote newDocinfo = (DocinfoRemote)docinfoSet.add();
/*     */ 
/* 199 */     fillDocinfo(docinfoSet, newDocinfo);
/* 200 */     fillDoclinks(doclinksSet, newDoclinks, newDocinfo);
/*     */ 
/* 202 */     doclinksSet.save();
/* 203 */     docinfoSet.save();
/*     */ 
/* 205 */     createCommLogDoc(commLog, newDocinfo);
/*     */ 
/* 207 */     IMSessionHandler.logInfo("Chat transcript file has been attached");
/*     */   }

/*     */   private void fillDocinfo(DocinfoSetRemote docinfoSet, DocinfoRemote newDocinfo) throws MXException, IOException {
/* 211 */     String mxUserName = this.userInfo.getMXUserName();
/* 212 */     String mxPartnerName = this.partnerInfo.getMXPartnerName();
/* 213 */     String description = "Chat session between " + mxUserName + " and " + mxPartnerName;
/*     */ 
/* 215 */     newDocinfo.setValue("DOCUMENT", this.documentName, 9L);
/* 216 */     newDocinfo.setValue("DESCRIPTION", description, 9L);
/* 217 */     newDocinfo.setValue("DOCTYPE", "Attachments", 9L);
/* 218 */     newDocinfo.setValue("URLTYPE", "FILE", 9L);

/*     */ 
/* 221 */     newDocinfo.setValue("URLNAME", this.fileURL, 9L);
/*     */ 
/* 223 */     newDocinfo.setValue("PRINTTHRULINKDFLT", 1, 9L);

/*     */ 
/* 226 */     newDocinfo.setValue("USEDEFAULTFILEPATH", 1, 2L);
/* 227 */     newDocinfo.setValue("SHOW", 1, 9L);
/*     */ 
/* 229 */     long id = newDocinfo.getLong("DOCINFOID");
/* 230 */     String document = newDocinfo.getString("DOCUMENT");
/* 231 */     IMSessionHandler.logDebug("Docinfo created: ID[" + id + "] DOCUMENT[" + document + "]");
/*     */   }

/*     */   private void fillDoclinks(DoclinksSetRemote doclinksSet, DoclinksRemote newDoclinks, DocinfoRemote newDocinfo) throws RemoteException, MXException
/*     */   {
/* 236 */     newDoclinks.copyFromDocinfo(newDocinfo);
/*     */ 
/* 238 */     newDoclinks.setValue("DOCUMENT", this.documentName, 9L);
/* 239 */     newDoclinks.setValue("OWNERTABLE", "COMMLOG", 9L);
/* 240 */     newDoclinks.setValue("OWNERID", this.newCommLogUID, 9L);
/* 241 */     newDoclinks.setValue("REFERENCE", this.documentName, 9L);
/* 242 */     newDoclinks.setValue("DOCTYPE", "Attachments", 9L);
/* 243 */     newDoclinks.setValue("DOCVERSION", "1", 9L);
/* 244 */     newDoclinks.setValue("COPYLINKTOWO", 1, 9L);
/* 245 */     newDoclinks.setValue("DOCINFOID", newDocinfo.getLong("DOCINFOID"), 9L);
/*     */ 
/* 247 */     long id = newDoclinks.getLong("DOCLINKSID");
/* 248 */     long docinfoId = newDoclinks.getLong("DOCINFOID");
/* 249 */     String ownerTable = newDoclinks.getString("OWNERTABLE");
/* 250 */     long ownerId = newDoclinks.getLong("OWNERID");
/* 251 */     String document = newDoclinks.getString("DOCUMENT");
/* 252 */     IMSessionHandler.logDebug("Doclinks created: ID[" + id + "] DOCINFOID[" + docinfoId + "] OWNERTABLE[" + ownerTable + "] OWNERID[" + ownerId + "] DOCUMENT[" + document + "]");
/*     */   }

/*     */   private void createCommLogDoc(CommLogRemote commLog, DocinfoRemote newDocinfo)
/*     */     throws RemoteException, MXException
/*     */   {
/* 258 */     CommLogDocSetRemote commLogDocSet = (CommLogDocSetRemote)commLog.getMboSet("COMMLOGDOCS");
/* 259 */     MboRemote newCommLogDoc = commLogDocSet.add();
/* 260 */     long docInfoId = newDocinfo.getLong("DOCINFOID");
/* 261 */     newCommLogDoc.setValue("COMMLOGID", this.newCommLogID, 9L);
/* 262 */     newCommLogDoc.setValue("DOCINFOID", docInfoId, 9L);
/* 263 */     newCommLogDoc.setValue("URLNAME", this.fileURL, 9L);
/*     */ 
/* 265 */     commLogDocSet.save();
/*     */ 
/* 267 */     IMSessionHandler.logDebug("CommLogDoc created");
/*     */   }

/*     */   private CommLogRemote getCommLogJustSaved() throws RemoteException, MXException, SessionInfoException {
/* 271 */     CommLogSetRemote commLogMboSet = (CommLogSetRemote)this.mbo.getMboSet("COMMLOG");
/* 272 */     String sql = "COMMLOGID = :1";
/* 273 */     MXSession mxSession = SessionInfoHelper.getMXSession(this.httpSession);
/* 274 */     psdi.security.UserInfo mxUserInfo = mxSession.getUserInfo();
/* 275 */     SqlFormat sqlFormat = new SqlFormat(mxUserInfo, sql);
/* 276 */     sqlFormat.setObject(1, "COMMLOG", "COMMLOGID", String.valueOf(this.newCommLogID));
/* 277 */     commLogMboSet.setWhere(sqlFormat.format());
/* 278 */     commLogMboSet.reset();
/* 279 */     return ((CommLogRemote)commLogMboSet.getMbo(0));
/*     */   }






/*     */   private void reloadTable(WebClientSession webClientSession)
/*     */     throws SessionInfoException
/*     */   {
/* 290 */     webClientSession.getCurrentApp().getDataBean().reloadTable();
/*     */   }
/*     */ }
