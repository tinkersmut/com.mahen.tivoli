/*    */ package com.ibm.tivoli.imi.controller;
/*    */ 
/*    */ import javax.servlet.http.HttpSession;
/*    */ import psdi.util.MXSession;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 

















/*    */ class MxSessionAliveVerifier
/*    */   implements Runnable
/*    */ {
/*    */   private IMSessionHandler imSessionHandler;
/* 28 */   private boolean isRunning = true;
/*    */ 
/*    */   static MxSessionAliveVerifier getAliveVerifier(IMSessionHandler imSessionHandler) {
/* 31 */     MxSessionAliveVerifier mxSessionAliveVerifier = new MxSessionAliveVerifier(imSessionHandler);
/* 32 */     new Thread(mxSessionAliveVerifier).start();
/* 33 */     return mxSessionAliveVerifier;
/*    */   }

/*    */   private MxSessionAliveVerifier(IMSessionHandler imSessionHandler) {
/* 37 */     if (imSessionHandler == null) {
/* 38 */       throw new IllegalArgumentException("Invalid IM session handler");
/*    */     }
/* 40 */     this.imSessionHandler = imSessionHandler;
/* 41 */     IMSessionHandler.logDebug("Mx session alive verifier started");
/*    */   }

/*    */   public void run() {
/* 45 */     String reason = "unknow reason";
/*    */ 
/* 47 */     while (this.isRunning)

/*    */     {
/* 50 */       HttpSession httpSession = this.imSessionHandler.getHttpSession();
/* 51 */       if (httpSession == null) {
/* 52 */         reason = "HttpSession is null";
/* 53 */         break;
/*    */       }
/*    */       try {
/* 56 */         MXSession mxSession = SessionInfoHelper.getMXSession(httpSession);
/* 57 */         boolean isMXSessionConnected = mxSession.isConnected();
/* 58 */         if (!(isMXSessionConnected)) {
/* 59 */           reason = "Maximo session is no longer connected";
/* 60 */           break label119:
/*    */         }
/*    */ 
/* 63 */         WebClientSession webClientSession = SessionInfoHelper.getAnyValidWebClientSession(httpSession);
/* 64 */         boolean isValid = webClientSession.isValid();
/* 65 */         if (!(isValid)) {
/* 66 */           reason = "Maximo web client session is no longer valid";
/* 67 */           break label119:
/*    */         }
/*    */       } catch (Exception e) {
/* 70 */         reason = e.getMessage();
/* 71 */         break label119:
/*    */       }
/*    */       try {
/* 74 */         synchronized (this) {
/* 75 */           super.wait(4000L);
/*    */         }
/*    */       } catch (InterruptedException e) {
/*    */       }
/*    */     }
/* 80 */     label119: closeSessionHandler(reason);
/*    */   }

/*    */   private void closeSessionHandler(String reason) {
/* 84 */     synchronized (this.imSessionHandler) {
/* 85 */       if (this.isRunning) {
/* 86 */         IMSessionHandler.logDebug("MxSessionAliveVerifier has asked IM session handler to close");
/* 87 */         this.imSessionHandler.closeIMSessionHandler(reason);
/* 88 */         this.isRunning = false;
/*    */       }
/*    */     }
/*    */   }

/*    */   void closeVerifier() {
/* 94 */     IMSessionHandler.logDebug("MxSessionAliveVerifier has been closed by IMSessionHandler");
/* 95 */     this.isRunning = false;
/*    */   }
/*    */ }
