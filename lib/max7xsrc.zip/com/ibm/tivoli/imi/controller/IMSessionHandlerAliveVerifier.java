/*    */ package com.ibm.tivoli.imi.controller;
/*    */ 















/*    */ class IMSessionHandlerAliveVerifier
/*    */   implements Runnable
/*    */ {
/*    */   private IMSessionHandler imSessionHandler;
/*    */ 
/*    */   static void startAliveVerifier(IMSessionHandler imSessionHandler)
/*    */   {
/* 25 */     IMSessionHandlerAliveVerifier imSessionHandlerAliveVerifier = new IMSessionHandlerAliveVerifier(imSessionHandler);
/*    */ 
/* 27 */     new Thread(imSessionHandlerAliveVerifier).start();
/*    */   }

/*    */   private IMSessionHandlerAliveVerifier(IMSessionHandler imSessionHandler) {
/* 31 */     if (imSessionHandler == null) {
/* 32 */       throw new IllegalArgumentException("Invalid IM session handler");
/*    */     }
/* 34 */     this.imSessionHandler = imSessionHandler;
/*    */   }

/*    */   public void run() {
/* 38 */     IMSessionHandler.logDebug("IM session handler alive verifier started");
/*    */     while (true) {
/* 40 */       if (this.imSessionHandler.isActive()) {
/* 41 */         this.imSessionHandler.resetActivityFlag();
/*    */       } else {
/* 43 */         this.imSessionHandler.closeIMSessionHandler("Inactive for 300000ms");
/* 44 */         return;
/*    */       }
/*    */       try {
/* 47 */         synchronized (this) {
/* 48 */           super.wait(300000L);
/*    */         }
/*    */       }
/*    */       catch (InterruptedException e)
/*    */       {
/*    */       }
/*    */     }
/*    */   }
/*    */ }
