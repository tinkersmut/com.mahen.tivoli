/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 
























/*     */ public class SessionInfoHelper
/*     */ {
/*  45 */   private static Hashtable<HttpSession, ConcurrentLinkedQueue<WebClientSession>> webClientSessions = new Hashtable();
/*     */   private static final String MXSESSON_ATTRIBUTE_NAME = "MXSession";
/*     */ 
/*     */   public static String getSessionId(HttpServletRequest request)
/*     */     throws RemoteException, MXException, NoSuchAlgorithmException, SessionInfoException
/*     */   {
/*  50 */     if (request == null) {
/*  51 */       throw new IllegalArgumentException("Invalid request");
/*     */     }
/*  53 */     WebClientSession webClientSession = WebClientRuntime.getWebClientRuntime().getWebClientSession(request);
/*     */ 
/*  55 */     putWebClientSession(webClientSession);
/*     */ 
/*  57 */     MboRemote mbo = getMbo(webClientSession);
/*  58 */     String mboId = String.valueOf(mbo.getUniqueIDValue());
/*     */ 
/*  60 */     if ((mboId == null) || (mboId.trim().equals(""))) {
/*  61 */       throw new SessionInfoException("Could not get MBO id");
/*     */     }
/*     */ 
/*  64 */     String appTitle = getAppTitle(webClientSession);
/*  65 */     if ((appTitle == null) || (appTitle.trim().equals(""))) {
/*  66 */       throw new SessionInfoException("There is no appName related to this webClientSession");
/*     */     }
/*     */ 
/*  69 */     String controlId = request.getParameter("controlid");
/*  70 */     if ((controlId == null) || (controlId.trim().equals(""))) {
/*  71 */       throw new SessionInfoException("There is no controlId related to this HTTP request");
/*     */     }
/*     */ 
/*  74 */     String _sessionid = webClientSession.getHttpSession().getId() + appTitle + controlId + mboId;
/*     */ 
/*  76 */     MessageDigest md = MessageDigest.getInstance("SHA");
/*  77 */     md.update(_sessionid.getBytes());
/*  78 */     byte[] bytes = md.digest();
/*  79 */     StringBuffer buff = new StringBuffer();
/*  80 */     for (int i = 0; i < bytes.length; ++i) {
/*  81 */       buff.append(Integer.toHexString(bytes[i]));
/*     */     }
/*     */ 
/*  84 */     return buff.toString();
/*     */   }

/*     */   private static String getAppTitle(WebClientSession webClientSession) throws SessionInfoException {
/*     */     try {
/*  89 */       AppInstance appInstance = webClientSession.getCurrentApp();
/*  90 */       if (appInstance == null) {
/*  91 */         throw new SessionInfoException("App instance row could not be gotten");
/*     */       }
/*  93 */       String appTitle = appInstance.getAppTitle();
/*  94 */       if ((appTitle == null) || (appTitle.trim().equals(""))) {
/*  95 */         throw new SessionInfoException("App instance title could not be gotten");
/*     */       }
/*     */ 
/*  98 */       return appTitle;
/*     */     } catch (NullPointerException e) {
/* 100 */       e.printStackTrace();
/* 101 */       throw new SessionInfoException("User might not be logged in Maximo");
/*     */     }
/*     */   }

/*     */   private static MboRemote getMbo(WebClientSession webClientSession) throws RemoteException, MXException, SessionInfoException
/*     */   {
/*     */     try {
/* 108 */       AppInstance appInstance = webClientSession.getCurrentApp();
/* 109 */       if (appInstance == null) {
/* 110 */         throw new SessionInfoException("App instance row could not be gotten");
/*     */       }
/* 112 */       DataBean appBean = appInstance.getAppBean();
/* 113 */       MboRemote mbo = appBean.getMbo(0);
/* 114 */       if (mbo == null) {
/* 115 */         throw new SessionInfoException("MBO could not be gotten");
/*     */       }
/* 117 */       return mbo;
/*     */     } catch (NullPointerException e) {
/* 119 */       e.printStackTrace();
/* 120 */       throw new SessionInfoException("User might not be logged in Maximo");
/*     */     }
/*     */   }

/*     */   static MboRemote getMbo(HttpServletRequest request) throws RemoteException, MXException, SessionInfoException {
/* 125 */     WebClientSession webClientSession = WebClientRuntime.getWebClientRuntime().getWebClientSession(request);
/*     */ 
/* 127 */     putWebClientSession(webClientSession);
/*     */ 
/* 129 */     return getMbo(webClientSession);
/*     */   }

/*     */   static MXSession getMXSession(HttpSession httpSession) throws SessionInfoException {
/* 133 */     MXSession mxSession = (MXSession)httpSession.getAttribute("MXSession");
/* 134 */     if (mxSession == null) {
/* 135 */       throw new SessionInfoException("There is no MXSession related to this HttpSession");
/*     */     }
/* 137 */     return mxSession;
/*     */   }

/*     */   public static synchronized void putWebClientSession(HttpServletRequest request) {
/* 141 */     WebClientSession webClientSession = WebClientRuntime.getWebClientRuntime().getWebClientSession(request);
/* 142 */     putWebClientSession(webClientSession);
/*     */   }

/*     */   public static synchronized void putWebClientSession(WebClientSession webClientSession) {
/* 146 */     HttpSession httpSession = webClientSession.getHttpSession();
/* 147 */     ConcurrentLinkedQueue wcsQueue = (ConcurrentLinkedQueue)webClientSessions.get(httpSession);
/* 148 */     if (wcsQueue == null) {
/* 149 */       wcsQueue = new ConcurrentLinkedQueue();
/* 150 */       webClientSessions.put(httpSession, wcsQueue);
/*     */     }
/* 152 */     wcsQueue.add(webClientSession);
/*     */   }





















/*     */   static synchronized WebClientSession getAnyValidWebClientSession(HttpSession httpSession)
/*     */     throws SessionInfoException
/*     */   {
/* 178 */     ConcurrentLinkedQueue wcsQueue = (ConcurrentLinkedQueue)webClientSessions.get(httpSession);
/* 179 */     if (wcsQueue == null) {
/* 180 */       throw new SessionInfoException("There is no WebClientSession correlated to this HttpSession");
/*     */     }
/* 182 */     WebClientSession wcs = null;
/*     */     while (true) {
/* 184 */       wcs = (WebClientSession)wcsQueue.peek();
/* 185 */       if (wcs == null) break; if ((wcs.isValid()) && (wcs.isConnected())) {
/*     */         break;
/*     */       }
/* 188 */       wcsQueue.remove();
/*     */     }
/* 190 */     if (wcs == null) {
/* 191 */       throw new SessionInfoException("There is no WebClientSession correlated to this HttpSession");
/*     */     }
/* 193 */     return wcs;
/*     */   }
/*     */ }
