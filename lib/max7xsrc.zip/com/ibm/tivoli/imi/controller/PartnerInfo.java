/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import psdi.app.person.PersonRemote;
/*     */ import psdi.app.person.PersonSetRemote;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXException;
/*     */ 




























/*     */ public class PartnerInfo
/*     */ {
/*     */   private String mxPartnerID;
/*     */   private String mxPartnerName;
/*     */   private String mxPartnerEmail;
/*     */   private String imPartnerID;
/*  38 */   private boolean freshIMID = true;
/*     */   public static final String MBO_IS_THE_PERSON = "0914782936423507";
/*     */   private String mx_imPartnerID;
/*     */ 
/*     */   PartnerInfo(HttpServletRequest httpRequest)
/*     */     throws RemoteException, MXException, SessionInfoException
/*     */   {
/*  52 */     PersonRemote person = getPerson(httpRequest);
/*  53 */     this.mxPartnerID = person.getString("personid");
/*  54 */     this.mxPartnerName = person.getString("displayname");
/*  55 */     this.mxPartnerEmail = person.getString("PRIMARYEMAIL");
/*  56 */     this.mx_imPartnerID = (this.imPartnerID = person.getString("IM_ID"));
/*     */   }

/*     */   public synchronized void setIMPartnerID(String imPartnerID) {
/*  60 */     if ((imPartnerID == null) || (imPartnerID.trim().equals(""))) {
/*  61 */       throw new IllegalArgumentException("Partner IM ID must not be null");
/*     */     }
/*  63 */     this.imPartnerID = imPartnerID;
/*  64 */     this.freshIMID = true;
/*     */   }

/*     */   public String getMXPartnerID() {
/*  68 */     return this.mxPartnerID;
/*     */   }

/*     */   public String getMXPartnerName() {
/*  72 */     return this.mxPartnerName;
/*     */   }

/*     */   public String getMXPartnerEmail() {
/*  76 */     return this.mxPartnerEmail;
/*     */   }

/*     */   public synchronized String getIMPartnerID() {
/*  80 */     return this.imPartnerID;
/*     */   }

/*     */   synchronized boolean isFreshIMID() {
/*  84 */     return this.freshIMID;
/*     */   }

/*     */   synchronized void registeredIMID() {
/*  88 */     this.freshIMID = false;
/*     */   }

/*     */   public String toString() {
/*  92 */     return "mxPartnerName=" + this.mxPartnerName + "\r\n" + "mxPartnerIMID=" + this.imPartnerID + "\r\n";
/*     */   }

/*     */   void refreshIMID(HttpServletRequest httpRequest) throws RemoteException, MXException, SessionInfoException
/*     */   {
/*  97 */     String current_mx_imPartnerID = getCurrentPartnerIMID(httpRequest);
/*  98 */     if (!(this.mx_imPartnerID.equals(current_mx_imPartnerID))) {
/*  99 */       this.mx_imPartnerID = (this.imPartnerID = (current_mx_imPartnerID == null) ? "" : current_mx_imPartnerID);
/* 100 */       this.freshIMID = true;
/* 101 */       IMSessionHandler.logInfo("Refreshing IM ID of '" + this.mxPartnerName + "' from '" + this.imPartnerID + "' to '" + current_mx_imPartnerID + "'");
/*     */     }
/*     */   }

/*     */   private String getCurrentPartnerIMID(HttpServletRequest httpRequest)
/*     */     throws RemoteException, MXException, SessionInfoException
/*     */   {
/* 108 */     PersonRemote person = getPerson(httpRequest);
/* 109 */     return person.getString("IM_ID");
/*     */   }

/*     */   boolean isValid(HttpServletRequest httpRequest) throws RemoteException, MXException, SessionInfoException
/*     */   {
/* 114 */     PersonRemote person = getPerson(httpRequest);
/* 115 */     String _mxPartnerID = person.getString("personid");
/* 116 */     String _mxPartnerName = person.getString("displayname");
/* 117 */     if (!(this.mxPartnerID.equals(_mxPartnerID))) {
/* 118 */       return false;
/*     */     }
/*     */ 
/* 121 */     return (this.mxPartnerName.equals(_mxPartnerName));
/*     */   }


/*     */   private PersonRemote getPerson(HttpServletRequest httpRequest)
/*     */     throws RemoteException, MXException, SessionInfoException
/*     */   {
/* 128 */     String relationship = httpRequest.getParameter("relationship");
/* 129 */     if (relationship == null) {
/* 130 */       throw new IllegalArgumentException("Invalid relationship");
/*     */     }
/* 132 */     MboRemote mbo = SessionInfoHelper.getMbo(httpRequest);

/*     */ 
/* 135 */     if (relationship.equals("0914782936423507")) {
/* 136 */       if (mbo instanceof PersonRemote) {
/* 137 */         PersonRemote person = (PersonRemote)mbo; break label122:
/*     */       }
/* 139 */       throw new SessionInfoException("This MBO is not a Person. You need to set a valid relationship for the relationship parameter of imicon tag");
/*     */     }
/*     */ 
/* 142 */     MboSetRemote mboSetRemote = mbo.getMboSet(relationship);
/* 143 */     if ((mboSetRemote == null) || (!(mboSetRemote instanceof PersonSetRemote))) {
/* 144 */       throw new IllegalArgumentException("Invalid person set. Verify the relationship set to this IM icon.");
/*     */     }
/* 146 */     PersonSetRemote personSetRemote = (PersonSetRemote)mboSetRemote;
/* 147 */     personSetRemote.reset();
/* 148 */     PersonRemote person = (PersonRemote)personSetRemote.getMbo(0);

/*     */ 
/* 151 */     if (person == null) {
/* 152 */       label122: throw new SessionInfoException("Person row is null");
/*     */     }
/* 154 */     return person;
/*     */   }
/*     */ }
