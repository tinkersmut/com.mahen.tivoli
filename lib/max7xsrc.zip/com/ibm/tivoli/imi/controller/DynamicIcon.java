/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 
/*     */ import com.ibm.tivoli.imi.spi.IMException;
/*     */ import com.ibm.tivoli.imi.spi.IMUser.IMUserStatus;
/*     */ import java.rmi.RemoteException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.text.DecimalFormat;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import psdi.util.MXException;
/*     */ 












































































































































/*     */ public class DynamicIcon
/*     */ {
/*     */   private IMSessionHandler imSessionHandler;
/*  34 */   private IMUser.IMUserStatus userStatus = IMUser.IMUserStatus.UNKNOW;
/*     */   private boolean blankPartnerInfo;
/*  36 */   private boolean partnerIsChatting = false;
/*     */   private static final String ICON_PATH = "/webclient/images/imi/";
/*  39 */   private static final DecimalFormat formatter = new DecimalFormat("00");
/*     */   private static final String HAS_LINK_CODE_FOR_CLOSED_CONNECTION = "1";
/*     */   private static final String HAS_LINK_CODE_FOR_LOOKUP_ERROR = "0";
/*     */ 
/*     */   public DynamicIcon(HttpServletRequest request)
/*     */     throws RemoteException, NoSuchAlgorithmException, MXException, IMException
/*     */   {
/* 165 */     if (request == null) {
/* 166 */       throw new IllegalArgumentException("Request must not be null");
/*     */     }
/* 168 */     this.imSessionHandler = IMSessionHandler.getIMSessionHandler(request.getSession());
/* 169 */     if ((this.imSessionHandler != null) && (this.imSessionHandler.isIMSessionOpened())) {
/* 170 */       PartnerInfo partnerInfo = this.imSessionHandler.getPartnerInfo(request);
/* 171 */       this.blankPartnerInfo = (partnerInfo == null);
/* 172 */       if (!(this.blankPartnerInfo)) {
/* 173 */         this.partnerIsChatting = this.imSessionHandler.isPartnerChatting(partnerInfo.getIMPartnerID());
/* 174 */         String imPartnerId = partnerInfo.getIMPartnerID();
/* 175 */         this.userStatus = this.imSessionHandler.getUserStatus(imPartnerId);
/*     */       }
/*     */     }
/*     */   }

/*     */   DynamicIcon(IMSessionHandler imSessionHandler, String imPartnerId, IMUser.IMUserStatus userStatus) {
/* 181 */     this.blankPartnerInfo = false;
/* 182 */     this.imSessionHandler = imSessionHandler;
/* 183 */     this.partnerIsChatting = imSessionHandler.isPartnerChatting(imPartnerId);
/* 184 */     this.userStatus = userStatus;
/*     */   }







/*     */   private boolean shouldHaveLink()
/*     */   {
/* 195 */     if (this.blankPartnerInfo) {
/* 196 */       return false;
/*     */     }
/* 198 */     if (this.partnerIsChatting) {
/* 199 */       return false;
/*     */     }
/*     */ 
/* 202 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$spi$IMUser$IMUserStatus[this.userStatus.ordinal()])





/*     */     {
/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/* 212 */       return (!(this.imSessionHandler.isIMSessionOpened()));


/*     */     }
/*     */ 
/* 217 */     return true;
/*     */   }

/*     */   static boolean isAvailable(IMUser.IMUserStatus imUserStatus)
/*     */   {
/* 222 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$spi$IMUser$IMUserStatus[imUserStatus.ordinal()])
/*     */     {/*     */     case 2:
/*     */     case 3:
/* 225 */       return false;
/*     */     }
/* 227 */     return true;
/*     */   }

/*     */   private int getIconPathOrdinal()
/*     */   {
/* 232 */     if ((this.imSessionHandler == null) || (!(this.imSessionHandler.isIMSessionOpened()))) {
/* 233 */       return IconPath.CONN_CLOSED.ordinal();
/*     */     }
/* 235 */     return IconPath.valueOf(this.userStatus.name()).ordinal();
/*     */   }
/*     */   private int getAltMessageOrdinal()/*     */   {
/*     */     int altMessageOrdinal;
/*     */     int altMessageOrdinal;
/* 240 */     if ((this.imSessionHandler != null) && (this.imSessionHandler.isIMSessionOpened()))
/*     */     {/*     */       int altMessageOrdinal;/* 241 */       if (this.blankPartnerInfo)
/* 242 */         altMessageOrdinal = IconAlt.PARTNER_BLANK.ordinal();
/*     */       else
/* 244 */         altMessageOrdinal = IconAlt.valueOf(this.userStatus.name()).ordinal();
/*     */     }
/*     */     else {
/* 247 */       altMessageOrdinal = IconAlt.CONN_CLOSED.ordinal();
/*     */     }
/* 249 */     return altMessageOrdinal;
/*     */   }

/*     */   public String getCode() {
/* 253 */     String hasLink = (shouldHaveLink()) ? "1" : "0";
/* 254 */     return hasLink + formatter.format(getAltMessageOrdinal()) + formatter.format(getIconPathOrdinal());
/*     */   }

/*     */   public static String getCodeForLookupError() {
/* 258 */     int iconAltOrdinal = IconAlt.LOOKUP_ERROR.ordinal();
/* 259 */     return "0" + formatter.format(IconPath.UNKNOW.ordinal()) + formatter.format(iconAltOrdinal);
/*     */   }

/*     */   static String getCodeForClosedIMConnection()
/*     */   {
/* 264 */     return "1" + formatter.format(IconPath.CONN_CLOSED.ordinal()) + formatter.format(IconAlt.CONN_CLOSED.ordinal());
/*     */   }
/*     */ 
/*     */   public static enum IconAlt
/*     */   {
/*  86 */     AWAY, DONT_DISTURB, IN_A_MEETING, MOBILE, AVAILABLE, OFFLINE, UNKNOW, CONN_CLOSED, INCOMPATIBLE_ERROR, PARTNER_BLANK, LOOKUP_ERROR, ICON_LOADING, EX_INTERNAL_ERROR;
/*     */   }
/*     */ 
/*     */   public static enum IconPath
/*     */   {
/*  43 */     AWAY, DONT_DISTURB, IN_A_MEETING, MOBILE, AVAILABLE, OFFLINE, UNKNOW, CONN_CLOSED;
/*     */   }
/*     */ }
