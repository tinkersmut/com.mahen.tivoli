/*    */ package com.ibm.tivoli.imi.controller;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 

















/*    */ public class FrontController
/*    */ {
/*    */   public static void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 27 */     ActionCode actionCode = ActionCode.valueOf(request.getParameter("action_code"));
/*    */ 
/* 29 */     switch (1.$SwitchMap$com$ibm$tivoli$imi$controller$FrontController$ActionCode[actionCode.ordinal()])
/*    */     {/*    */     case 1:
/* 31 */       IMIconRefreshHelper.handleRequest(request, response);
/* 32 */       break;
/*    */     case 2:
/* 34 */       ChatRefreshHelper.handleRequest(request, response);
/*    */     }
/*    */   }
/*    */ 
/*    */   static enum ActionCode
/*    */   {
/* 22 */     IMICON_REFRESH, CHAT_REFRESH;
/*    */   }
/*    */ }
