/*    */ package com.ibm.tivoli.imi.controller;
/*    */ 
/*    */ import javax.servlet.http.HttpSession;
/*    */ import psdi.util.MXSession;
/*    */ 













/*    */ public class UserInfo
/*    */ {
/*    */   private String mxUserID;
/*    */   private String mxUserName;
/* 25 */   private String mxUserEmail = "";
/*    */   private String imUserID;
/*    */   private String imUserPassword;
/*    */   private MXSession mxSession;
/*    */ 
/*    */   UserInfo(HttpSession httpSession)
/*    */     throws SessionInfoException
/*    */   {
/* 31 */     if (httpSession == null) {
/* 32 */       throw new IllegalArgumentException("Invalid session");
/*    */     }
/* 34 */     this.mxSession = SessionInfoHelper.getMXSession(httpSession);
/* 35 */     if (this.mxSession == null) {
/* 36 */       throw new IllegalArgumentException("This session does not contain the MXSession attribute");
/*    */     }
/* 38 */     psdi.security.UserInfo userInfo = this.mxSession.getUserInfo();
/* 39 */     if (userInfo == null) {
/* 40 */       throw new IllegalArgumentException("MXSession UserInfo is null");
/*    */     }
/* 42 */     this.mxUserID = userInfo.getLoginID();
/* 43 */     if ((this.mxUserID == null) || (this.mxUserID.trim().equals(""))) {
/* 44 */       this.mxUserID = "";
/*    */     }
/* 46 */     this.mxUserName = userInfo.getDisplayName();
/* 47 */     if ((this.mxUserName == null) || (this.mxUserName.trim().equals(""))) {
/* 48 */       this.mxUserName = "";
/*    */     }
/* 50 */     refresh();
/*    */   }

/*    */   void refresh() {
/* 54 */     this.imUserID = "";
/* 55 */     this.imUserPassword = "";
/* 56 */     IMSessionHandler.logDebug("IM user account was refreshed");
/*    */   }

/*    */   public void setIMUserID(String mxUserIMID) {
/* 60 */     this.imUserID = mxUserIMID;
/*    */   }

/*    */   public void setIMUserPassword(String mxUserIMPassword) {
/* 64 */     this.imUserPassword = mxUserIMPassword;
/*    */   }

/*    */   public String getMXUserID() {
/* 68 */     return this.mxUserID;
/*    */   }

/*    */   public String getMXUserName() {
/* 72 */     return this.mxUserName;
/*    */   }

/*    */   public String getIMUserID() {
/* 76 */     return this.imUserID;
/*    */   }

/*    */   public String getIMUserPassword() {
/* 80 */     return this.imUserPassword;
/*    */   }

/*    */   public String toString() {
/* 84 */     return "mxUserName=" + this.mxUserName + "\r\n" + "mxUserIMID=" + this.imUserID + "\r\n" + "mxUserEmail=" + this.mxUserEmail;
/*    */   }
/*    */ }
