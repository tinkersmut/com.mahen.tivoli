/*    */ package com.ibm.tivoli.imi.controller;
/*    */ 
/*    */ public enum MessageKey
/*    */ {
/* 23 */   CON_ALREADY_CLOSED, CON_JUST_CLOSED, CON_ALREADY_OPENED, CON_JUST_OPENED, EXCEPTION, CONFIG_VALIDATION_USER, CONFIG_VALIDATION_PASSWORD, SERVER_CHANGED, PROFILE_APPLIED, PROFILE_NOT_SELECTED;
/*    */ }
