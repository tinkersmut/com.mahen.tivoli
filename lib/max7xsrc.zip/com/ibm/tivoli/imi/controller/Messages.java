/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ 































/*     */ public abstract class Messages
/*     */ {
/*     */   private static final String BUNDLE_NAME = "com.ibm.tivoli.imi.controller.message";
/*  50 */   private static ResourceBundle resourceBundle = null;
/*  51 */   private static String lang = null;
/*  52 */   private static String localeLang = null;
/*     */ 
/*     */   public static synchronized void setResourceBundle(HttpSession httpSession)
/*     */     throws RemoteException, MXException, SessionInfoException
/*     */   {
/*  57 */     setResourceBundle(SessionInfoHelper.getMXSession(httpSession));
/*     */   }







/*     */   private static synchronized void setResourceBundle(MXSession mxSession)
/*     */     throws RemoteException, MXException
/*     */   {
/*  69 */     lang = mxSession.getUserInfo().getLangCode();
/*     */ 
/*  71 */     if (lang == null) {
/*  72 */       lang = getMaxBaseLang(mxSession);

/*     */     }
/*     */ 
/*  76 */     if (localeLang == null) {
/*  77 */       localeLang = lang;

/*     */     }
/*     */ 
/*  81 */     if ((localeLang.equals(lang)) && (resourceBundle != null)) {
/*  82 */       return;
/*     */     }
/*  84 */     localeLang = lang;
/*  85 */     Locale locale = new Locale(lang);
/*     */ 
/*  87 */     IMSessionHandler.logDebug("Language: " + lang);
/*  88 */     IMSessionHandler.logDebug("Related locale: " + locale.toString());
/*     */ 
/*  90 */     resourceBundle = ResourceBundle.getBundle("com.ibm.tivoli.imi.controller.message", locale);
/*     */   }






/*     */   private static String getMaxBaseLang(MXSession mxSession)
/*     */     throws RemoteException, MXException
/*     */   {
/* 101 */     UserInfo mxUserInfo = mxSession.getUserInfo();
/*     */ 
/* 103 */     SqlFormat sqlFormat = new SqlFormat(mxUserInfo, "VARNAME = :1");
/* 104 */     sqlFormat.setObject(1, "MAXVARS", "VARNAME", "BASELANGUAGE");
/* 105 */     MboSetRemote maxVars = MXServer.getMXServer().getMboSet("MAXVARS", mxUserInfo);
/* 106 */     maxVars.setWhere(sqlFormat.format());
/* 107 */     String localeCode = maxVars.getMbo(0).getString("VARVALUE");
/*     */ 
/* 109 */     return localeCode.toLowerCase();
/*     */   }

/*     */   public static String getString(MXSession mxSession, String key) {
/*     */     try {
/* 114 */       setResourceBundle(mxSession);
/* 115 */       return resourceBundle.getString(key);
/*     */     } catch (MissingResourceException e) {
/* 117 */       return '!' + key + '!';
/*     */     } catch (Exception e) {
/* 119 */       IMSessionHandler.logError(e); }
/* 120 */     return '!' + key + '!';
/*     */   }

/*     */   public static String getString(HttpSession httpSession, String key) throws SessionInfoException
/*     */   {
/* 125 */     return getString(SessionInfoHelper.getMXSession(httpSession), key);
/*     */   }






/*     */   static String getString(String key)
/*     */   {
/*     */     try
/*     */     {
/* 137 */       if (resourceBundle == null) {
/* 138 */         IMSessionHandler.logDebug("ResouerBundle has not been initialized yet. Returning blank message.");
/* 139 */         return "";
/*     */       }
/* 141 */       return resourceBundle.getString(key);
/*     */     } catch (MissingResourceException e) {
/* 143 */       return '!' + key + '!';
/*     */     } catch (Exception e) {
/* 145 */       IMSessionHandler.logError(e); }
/* 146 */     return '!' + key + '!';
/*     */   }
/*     */ }
