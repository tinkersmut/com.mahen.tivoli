/*     */ package com.ibm.tivoli.imi.controller;
/*     */ 





























































/*     */ public class TsdIMException extends Exception
/*     */ {
/*     */   private Code code;
/*     */   private static final long serialVersionUID = -4761177698751059157L;
/*     */ 
/*     */   public TsdIMException(Code code)
/*     */   {
/*  71 */     setCode(code);
/*     */   }

/*     */   public TsdIMException(Code code, String message) {
/*  75 */     super(message);
/*  76 */     setCode(code);
/*     */   }

/*     */   public TsdIMException(Code code, Throwable throwable) {
/*  80 */     super(throwable);
/*  81 */     setCode(code);
/*     */   }

/*     */   public TsdIMException(Code code, String message, Throwable throwable) {
/*  85 */     super(message, throwable);
/*  86 */     setCode(code);
/*     */   }

/*     */   private void setCode(Code code) {
/*  90 */     if (code == null) {
/*  91 */       throw new IllegalArgumentException("Invalid IMException code");
/*     */     }
/*  93 */     this.code = code;
/*     */   }

/*     */   public Code getCode() {
/*  97 */     return this.code;
/*     */   }

/*     */   public String getMessage() {
/* 101 */     String message = super.getMessage();
/* 102 */     String result = this.code.toString();
/* 103 */     if ((message != null) && (!(message.trim().equals("")))) {
/* 104 */       result = result + " (" + message + ")";
/*     */     }
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */   public static enum Code
/*     */   {
/*  36 */     CHAT_ABORTION_EXCEPTION, CHAT_ABORTED_NOT_SAVED, INVALID_CHAT_IDENTIFIER, NLS_RESOURCE_BUNDLE;
/*     */   }
/*     */ }
