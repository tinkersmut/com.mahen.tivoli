/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.script.Bindings;
/*     */ import javax.script.Compilable;
/*     */ import javax.script.CompiledScript;
/*     */ import javax.script.ScriptContext;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineFactory;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.ScriptException;
/*     */ import javax.script.SimpleScriptContext;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 












/*     */ public class JSR223ScriptDriver extends AbstractScriptDriver
/*     */ {
/*     */   private Map<String, CompiledScript> compiledScriptCache;
/*  53 */   private static Set<String> supportedScrEngShortNames = new HashSet();
/*     */ 
/*  55 */   private static Map<String, ScriptEngineInfo> supportedScrEngineMap = new HashMap();
/*     */   public static final String SCRIPT_LOGGER = "maximo.script";
/*  59 */   public static final MXLogger SCRIPTLOGGER = MXLoggerFactory.getLogger("maximo.script");
/*     */ 
/*     */   public JSR223ScriptDriver()
/*     */   {
/*  51 */     this.compiledScriptCache = new HashMap();
/*     */   }

















































/*     */   public static Set<String> getSupportedScriptEngineNames()
/*     */   {
/* 104 */     return supportedScrEngShortNames;
/*     */   }






/*     */   public static Map<String, ScriptEngineInfo> getAllSupportedScriptEngines()
/*     */   {
/* 114 */     return supportedScrEngineMap;
/*     */   }







/*     */   public static ScriptEngineInfo getSupportedScriptEngineInfo(String engShortName)
/*     */   {
/* 125 */     return ((ScriptEngineInfo)supportedScrEngineMap.get(engShortName));
/*     */   }




/*     */   public boolean canRun(String scriptLang)
/*     */   {
/* 133 */     return supportedScrEngShortNames.contains(scriptLang);
/*     */   }



/*     */   protected void evalScript(ScriptInfo scriptInfo, Map<String, Object> context)
/*     */     throws MXException, RemoteException
/*     */   {
/* 141 */     String name = scriptInfo.getName();
/* 142 */     String launchPointName = (String)context.get("launchPoint");
/* 143 */     PrintWriter prout = null;
/* 144 */     PrintWriter prerr = null;
/* 145 */     long startTime = System.currentTimeMillis();


/*     */     try
/*     */     {
/* 150 */       StringWriter stdout = new StringWriter();
/* 151 */       StringWriter stderr = new StringWriter();
/*     */ 
/* 153 */       prout = new PrintWriter(stdout);
/* 154 */       prerr = new PrintWriter(stderr);
/*     */ 
/* 156 */       CompiledScript cs = null;
/* 157 */       Bindings bindings = null;
/* 158 */       ScriptContext sc = null;
/* 159 */       if (this.compiledScriptCache.containsKey(scriptInfo.getName()))
/*     */       {
/* 161 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 163 */           getLogger().debug("about to execute the cached compiled script for " + scriptInfo.getName() + " for launch point " + launchPointName);
/*     */         }
/* 165 */         cs = (CompiledScript)this.compiledScriptCache.get(scriptInfo.getName());
/* 166 */         bindings = cs.getEngine().createBindings();
/*     */ 
/* 168 */         sc = createScriptContext(bindings, context, prout, prerr);
/* 169 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 171 */           getLogger().debug("created script context for cached compiled script " + scriptInfo.getName() + " for launch point " + launchPointName);
/*     */         }
/*     */ 
/* 174 */         cs.eval(sc);
/* 175 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 177 */           getLogger().debug("execution completed for cached compiled script " + scriptInfo.getName() + " for launch point " + launchPointName);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 183 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 185 */           getLogger().debug("about to execute script " + scriptInfo.getName() + " for launch point " + launchPointName);
/*     */         }
/*     */ 
/* 188 */         String scriptLanguage = scriptInfo.getScriptLanguge();
/* 189 */         ScriptEngineManager mgr = new ScriptEngineManager();
/* 190 */         ScriptEngine scriptEngine = mgr.getEngineByName(scriptLanguage);
/* 191 */         bindings = scriptEngine.createBindings();
/* 192 */         sc = createScriptContext(bindings, context, prout, prerr);
/* 193 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 195 */           getLogger().debug("created script context for script " + scriptInfo.getName() + " for launch point " + launchPointName);
/*     */         }
/*     */ 
/* 198 */         scriptEngine.eval(scriptInfo.getScriptSource(), sc);
/* 199 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 201 */           getLogger().debug("execution completed for script " + scriptInfo.getName() + " for launch point " + launchPointName);
/*     */         }
/*     */       }
/* 204 */       String opLog = stdout.toString();
/* 205 */       if ((opLog != null) && (opLog.trim().length() > 0))
/*     */       {
/* 207 */         if (scriptInfo.isLogLevelInfo())
/*     */         {
/* 209 */           getLogger().info(opLog);
/*     */         }
/* 211 */         else if (scriptInfo.isLogLevelDebug())
/*     */         {
/* 213 */           getLogger().debug(opLog);
/*     */         }
/*     */       }
/* 216 */       String errLog = stderr.toString();
/* 217 */       if ((errLog != null) && (errLog.trim().length() > 0))
/*     */       {
/* 219 */         getLogger().error(errLog);
/*     */       }
/*     */ 
/* 222 */       if (ScriptEngineContext.getCurrentContext() != null)
/*     */       {
/* 224 */         ScriptEngineContext.getCurrentContext().setProperty(ScriptEngineContext.OUTLOG, opLog);
/* 225 */         ScriptEngineContext.getCurrentContext().setProperty(ScriptEngineContext.ERRLOG, errLog);
/*     */       }
/*     */ 
/* 228 */       Set bindingsEntrySet = bindings.entrySet();
/* 229 */       for (Map.Entry bindingEntry : bindingsEntrySet)
/*     */       {
/* 231 */         Object varValue = bindingEntry.getValue();
/*     */ 
/* 233 */         context.put(bindingEntry.getKey(), varValue);
/*     */       }/*     */     }
/*     */     catch (ScriptException se)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*     */       long endTime;
/*     */       long totalTime;
/*     */       String[] paramsLog;
/*     */       String[] params;
/* 244 */       if (prout != null)
/*     */       {
/* 246 */         prout.flush();
/* 247 */         prout.close();
/*     */       }
/*     */ 
/* 250 */       if (prerr != null)
/*     */       {
/* 252 */         prerr.flush();
/* 253 */         prerr.close();
/*     */       }
/* 255 */       long endTime = System.currentTimeMillis();
/* 256 */       long totalTime = endTime - startTime;
/*     */ 
/* 258 */       String[] paramsLog = { name, launchPointName, "" + totalTime };
/* 259 */       getLogger().logDisregardLevel("script", "timelog", paramsLog);
/*     */     }
/*     */   }


/*     */   protected ScriptContext createScriptContext(Bindings bindings, Map<String, Object> context, Writer stdout, Writer stderr)
/*     */   {
/* 266 */     bindings.putAll(context);
/* 267 */     SimpleScriptContext sc = new SimpleScriptContext();
/* 268 */     sc.setBindings(bindings, 100);
/* 269 */     sc.setWriter(stdout);
/* 270 */     sc.setErrorWriter(stderr);
/* 271 */     return sc;
/*     */   }


/*     */   public void releaseResources()
/*     */   {
/* 277 */     this.compiledScriptCache.clear();
/*     */   }


/*     */   public boolean preCompileScript(ScriptInfo scriptInfo)
/*     */     throws MXApplicationException
/*     */   {
/* 284 */     CompiledScript cs = null;
/* 285 */     String scriptLanguage = scriptInfo.getScriptLanguge();
/* 286 */     ScriptEngineManager mgr = new ScriptEngineManager();
/* 287 */     ScriptEngine scriptEngine = mgr.getEngineByName(scriptLanguage);
/* 288 */     if (scriptEngine instanceof Compilable)
/*     */     {
/* 290 */       String scriptSource = scriptInfo.getScriptSource();
/* 291 */       StringReader sr = new StringReader(scriptSource);
/*     */       try
/*     */       {
/* 294 */         cs = ((Compilable)scriptEngine).compile(sr);
/* 295 */         this.compiledScriptCache.put(scriptInfo.getName(), cs);
/* 296 */         return true;

/*     */       }
/*     */       catch (ScriptException se)
/*     */       {
/* 301 */         String[] params = { scriptInfo.getName() };
/* 302 */         throw new MXApplicationException("script", "compileerr", params, se);
/*     */       }
/*     */     }
/*     */ 
/* 306 */     return false;
/*     */   }


/*     */   public Map<String, ScriptEngineInfo> getSupportedEngines()
/*     */   {
/* 312 */     return supportedScrEngineMap;
/*     */   }


/*     */   public boolean isBinaryScript()
/*     */   {
/* 318 */     return false;
/*     */   }

/*     */   public List<ScriptParamInfo> parseScriptForParams(byte[] scriptBytes)
/*     */     throws MXException
/*     */   {
/* 324 */     return null;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  66 */       ScriptEngineManager seMgr = new ScriptEngineManager();
/*  67 */       List seFactories = seMgr.getEngineFactories();
/*  68 */       for (ScriptEngineFactory factory : seFactories)
/*     */       {
/*  70 */         List engNames = factory.getNames();
/*  71 */         supportedScrEngShortNames.addAll(engNames);
/*     */ 
/*  73 */         String engName = factory.getEngineName();
/*  74 */         String engVersion = factory.getEngineVersion();
/*  75 */         String langName = factory.getLanguageName();
/*  76 */         String langVersion = factory.getLanguageVersion();
/*     */ 
/*  78 */         for (String name : engNames)
/*     */         {
/*  80 */           supportedScrEngineMap.put(name, new ScriptEngineInfo(name, engName, engVersion, langName, langVersion));
/*     */         }
/*  82 */         if (SCRIPTLOGGER.isDebugEnabled())
/*     */         {
/*  84 */           SCRIPTLOGGER.debug("Script Engine name:" + engName + ", Engine alias name or short names:" + engNames + ", Engine name: " + engVersion + ", Lang name: " + langName + ", Lang version: " + langVersion);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  93 */       SCRIPTLOGGER.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }
