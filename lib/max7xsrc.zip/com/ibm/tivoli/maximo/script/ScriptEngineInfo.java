/*    */ package com.ibm.tivoli.maximo.script;
/*    */ 
























/*    */ public class ScriptEngineInfo
/*    */ {
/*    */   private String engineName;
/*    */   private String engineVersion;
/*    */   private String languageName;
/*    */   private String langVersion;
/*    */   private String shortName;
/*    */ 
/*    */   public ScriptEngineInfo(String shortName, String engineName, String engineVersion, String languageName, String langVersion)
/*    */   {
/* 37 */     this.shortName = shortName;
/* 38 */     this.engineName = engineName;
/* 39 */     this.engineVersion = engineVersion;
/* 40 */     this.languageName = languageName;
/* 41 */     this.langVersion = langVersion;
/*    */   }





/*    */   public String getShortName()
/*    */   {
/* 50 */     return this.shortName;
/*    */   }




/*    */   public String getEngineName()
/*    */   {
/* 58 */     return this.engineName;
/*    */   }




/*    */   public String getEngineVersion()
/*    */   {
/* 66 */     return this.engineVersion;
/*    */   }




/*    */   public String getLanguageName()
/*    */   {
/* 74 */     return this.languageName;
/*    */   }




/*    */   public String getLanguageVersion()
/*    */   {
/* 82 */     return this.langVersion;
/*    */   }
/*    */ }
