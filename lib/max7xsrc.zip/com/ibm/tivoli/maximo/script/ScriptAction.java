/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import psdi.common.action.ActionCustomClass;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ import psdi.workflow.WFActionRemote;
/*     */ import psdi.workflow.WFInstance;
/*     */ 



























/*     */ public class ScriptAction
/*     */   implements ActionCustomClass
/*     */ {
/*     */   public void applyCustomAction(MboRemote mbo, Object[] params)
/*     */     throws MXException, RemoteException
/*     */   {
/*  50 */     if (params.length == 0) throw new MXApplicationException("script", "missingscriptname");
/*  51 */     String param = (String)params[0];
/*  52 */     String scriptName = null;
/*  53 */     String launchPointName = null;
/*  54 */     String actionName = null;
/*  55 */     StringTokenizer tokenizer = new StringTokenizer(param, ",");
/*  56 */     if (tokenizer.hasMoreTokens())
/*     */     {
/*  58 */       scriptName = tokenizer.nextToken();
/*  59 */       if (scriptName == null) throw new MXApplicationException("script", "missingscriptname");
/*  60 */       if (tokenizer.hasMoreTokens())
/*     */       {
/*  62 */         launchPointName = tokenizer.nextToken();
/*  63 */         if (launchPointName == null) throw new MXApplicationException("script", "missinglp");
/*     */       }
/*     */     }
/*     */ 
/*  67 */     if (tokenizer.hasMoreTokens())
/*     */     {
/*  69 */       actionName = tokenizer.nextToken();
/*     */     }
/*  71 */     if (getLogger().isDebugEnabled())
/*     */     {
/*  73 */       getLogger().debug("ScriptAction called for scriptName " + scriptName + " has been called for " + "launch point " + launchPointName);

/*     */     }
/*     */ 
/*  77 */     Map context = new HashMap();
/*  78 */     context.put("mbo", mbo);
/*  79 */     context.put("scriptHome", mbo);
/*  80 */     context.put("scriptName", scriptName);
/*     */ 
/*  82 */     context.put("launchPoint", launchPointName);
/*  83 */     context.put("action", actionName);
/*  84 */     ScriptEngineContext scrThreadContext = ScriptEngineContext.getCurrentContext();
/*  85 */     boolean contextOwner = false;
/*     */     try
/*     */     {
/*  88 */       if (scrThreadContext == null)
/*     */       {
/*  90 */         contextOwner = true;
/*  91 */         scrThreadContext = ScriptEngineContext.createCurrentContext();
/*     */       }
/*     */ 
/*  94 */       WFInstance wf = null;
/*  95 */       WFActionRemote wfAction = null;
/*  96 */       if (params.length > 2)
/*     */       {
/*  98 */         wf = (WFInstance)params[1];
/*  99 */         context.put("wfinstance", wf);
/* 100 */         wfAction = (WFActionRemote)params[2];
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 105 */         ScriptDriverFactory.getInstance().getScriptDriver(scriptName).runScript(scriptName, context);
/* 106 */         invokeCustomExtension(wf, wfAction, mbo, null);
/*     */       }
/*     */       catch (MXException e)
/*     */       {
/* 110 */         getLogger().error(e.getMessage(), e);
/* 111 */         invokeCustomExtension(wf, wfAction, mbo, e);
/* 112 */         throw e;
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 117 */       if (contextOwner)
/*     */       {
/* 119 */         ScriptEngineContext.destroyCurrentContext();
/*     */       }
/*     */     }
/* 122 */     if (!(getLogger().isDebugEnabled()))
/*     */       return;
/* 124 */     getLogger().debug("ScriptAction call ended for scriptName " + scriptName + " and " + "launch point " + launchPointName);
/*     */   }







/*     */   protected MXLogger getLogger()
/*     */   {
/* 135 */     return MXLoggerFactory.getLogger("maximo.script");
/*     */   }

/*     */   private void invokeCustomExtension(WFInstance wfInstance, WFActionRemote wfAction, MboRemote targetMbo, Exception e) throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 142 */       String extensionClass = MXServer.getMXServer().getProperty("mxe.script.actionextention");
/* 143 */       if ((extensionClass != null) && (extensionClass.trim().length() > 0))
/*     */       {
/* 145 */         ScriptActionExtension extension = (ScriptActionExtension)Class.forName(extensionClass).newInstance();
/* 146 */         extension.action(wfInstance, wfAction, targetMbo, e);
/*     */       }
/*     */     }
/*     */     catch (MXException me)
/*     */     {
/* 151 */       throw me;
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/* 155 */       throw re;
/*     */     }
/*     */     catch (Exception e1)
/*     */     {
/* 159 */       throw new MXApplicationException("script", "extension", e);
/*     */     }
/*     */   }
/*     */ }
