/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import javax.script.Bindings;
/*     */ import javax.script.Compilable;
/*     */ import javax.script.CompiledScript;
/*     */ import javax.script.Invocable;
/*     */ import javax.script.ScriptContext;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineFactory;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.SimpleScriptContext;
/*     */ 
























/*     */ public class EvalScript
/*     */ {
/*  22 */   static ScriptEngine engine = null;
/*  23 */   static CompiledScript cs = null;
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  50 */     new MyThread(2.5D, 3.5D).start();
/*  51 */     new MyThread(4.0D, 5.0D).start();
/*  52 */     new MyThread(6.1D, 7.9D).start();
/*     */   }






/*     */   public static void evalParams(int a, int b)
/*     */     throws Exception
/*     */   {
/*  63 */     Bindings binding = cs.getEngine().createBindings();
/*  64 */     binding.put("a", Integer.valueOf(a));
/*  65 */     binding.put("b", Integer.valueOf(b));
/*     */ 
/*  67 */     ScriptContext sc = cs.getEngine().getContext();
/*  68 */     System.out.println(sc.getScopes());












/*     */ 
/*  82 */     cs.eval(binding);


/*     */ 
/*  86 */     System.out.println(a + "+" + b + "=" + binding.get("a"));
/*     */   }






/*     */   public static void evalParams2(double a, double b)
/*     */     throws Exception
/*     */   {
/*  97 */     Bindings binding = cs.getEngine().createBindings();
/*  98 */     binding.put("a", Double.valueOf(a));
/*  99 */     binding.put("b", Double.valueOf(b));
/* 100 */     SimpleScriptContext sc = new SimpleScriptContext();
/* 101 */     sc.setBindings(binding, 100);















/*     */ 
/* 118 */     cs.eval(sc);


/*     */ 
/* 122 */     System.out.println(a + "+" + b + "=" + binding.get("a"));
/*     */   }


/*     */   public static void evalPerformance()
/*     */     throws Exception
/*     */   {
/* 129 */     ScriptEngineManager factory = new ScriptEngineManager();
/*     */ 
/* 131 */     List list = factory.getEngineFactories();
/* 132 */     for (ScriptEngineFactory sf : list)
/*     */     {
/* 134 */       System.out.println(sf.getEngineName() + " the short names are " + sf.getNames());
/*     */ 
/* 136 */       String sName = (String)sf.getNames().get(0);
/*     */ 
/* 138 */       ScriptEngine engine = factory.getEngineByName(sName);
/* 139 */       if (engine instanceof Compilable)
/*     */       {
/* 141 */         System.out.println("compilable");
/*     */       }
/* 143 */       if (engine instanceof Invocable)
/*     */       {
/* 145 */         System.out.println("Invocable");

/*     */       }
/*     */ 
/* 149 */       String code = null;
/* 150 */       if (sf.getNames().contains("JavaScript"))
/*     */       {
/* 152 */         code = "print('Hello, World')";
/*     */       }
/*     */       else
/*     */       {
/* 156 */         code = "print 'Hello, World'";









/*     */       }
/*     */ 
/* 168 */       long t3 = System.currentTimeMillis();
/* 169 */       for (int i = 0; i < 1000; ++i)
/* 170 */         engine.eval(code);
/* 171 */       long t4 = System.currentTimeMillis();
/* 172 */       System.out.println("Total time " + (t4 - t3));
/*     */     }
/*     */   }




/*     */   static class MyThread extends Thread
/*     */   {
/* 181 */     double i = 1.0D;
/* 182 */     double j = 1.0D;
/*     */ 
/*     */     MyThread(double a, double b) {
/* 185 */       this.i = a;
/* 186 */       this.j = b;
/*     */     }

/*     */     public void run()
/*     */     {
/* 191 */       long t1 = System.currentTimeMillis();
/* 192 */       for (int k = 0; k < 10; ++k)
/*     */       {
/*     */         try
/*     */         {
/* 196 */           EvalScript.evalParams2(this.i, k);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 200 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 203 */       long t2 = System.currentTimeMillis();
/* 204 */       System.out.println("total time===" + (t2 - t1));
/*     */     }
/*     */   }
/*     */ }
