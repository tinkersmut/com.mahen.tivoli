/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 



























/*     */ public class ScriptEngineContext
/*     */   implements ScriptConstants
/*     */ {
/*  31 */   private static ThreadLocal<ScriptEngineContext> currentIntegrationContext = new ThreadLocal();
/*  32 */   public static String ERRLOG = "errlog";
/*  33 */   public static String OUTLOG = "outlog";
/*     */   private Map<String, Object> map;
/*     */ 
/*     */   private ScriptEngineContext(Map<String, Object> map)
/*     */   {
/*  44 */     this.map = map;
/*     */   }






/*     */   public Map<String, Object> getProperties()
/*     */   {
/*  54 */     return this.map;
/*     */   }







/*     */   public Object getProperty(String propName)
/*     */   {
/*  65 */     return this.map.get(propName);
/*     */   }







/*     */   public String getStringProperty(String propName)
/*     */   {
/*  76 */     return ((String)this.map.get(propName));
/*     */   }








/*     */   public Integer getIntegerProperty(String propName)
/*     */   {
/*  88 */     return ((Integer)this.map.get(propName));
/*     */   }







/*     */   public Long getLongProperty(String propName)
/*     */   {
/*  99 */     return ((Long)this.map.get(propName));
/*     */   }







/*     */   public void setIntegerProperty(String propName, int val)
/*     */   {
/* 110 */     this.map.put(propName, Integer.valueOf(val));
/*     */   }







/*     */   public void setDoubleProperty(String propName, double val)
/*     */   {
/* 121 */     this.map.put(propName, Double.valueOf(val));
/*     */   }







/*     */   public Double getDoubleProperty(String propName)
/*     */   {
/* 132 */     return ((Double)this.map.get(propName));
/*     */   }







/*     */   public Date getDateProperty(String propName)
/*     */   {
/* 143 */     return ((Date)this.map.get(propName));
/*     */   }








/*     */   public void setProperty(String propName, Object value)
/*     */   {
/* 155 */     this.map.put(propName, value);
/*     */   }





/*     */   public void removeProperty(String propName)
/*     */   {
/* 164 */     this.map.remove(propName);
/*     */   }





/*     */   public void setProperties(Map<String, Object> data)
/*     */   {
/* 173 */     if (data == null)
/*     */       return;
/* 175 */     this.map.putAll(data);
/*     */   }









/*     */   public static ScriptEngineContext getCurrentContext()
/*     */   {
/* 188 */     return ((ScriptEngineContext)currentIntegrationContext.get());
/*     */   }










/*     */   public static ScriptEngineContext createCurrentContext()
/*     */   {
/* 202 */     setCurrentContext(new HashMap());
/* 203 */     return ((ScriptEngineContext)currentIntegrationContext.get());
/*     */   }






/*     */   private static void setCurrentContext(Map<String, Object> map)
/*     */   {
/* 213 */     currentIntegrationContext.set(new ScriptEngineContext(map));
/*     */   }

/*     */   public static void destroyCurrentContext()
/*     */   {
/* 218 */     if (currentIntegrationContext.get() == null)
/*     */       return;
/* 220 */     ((ScriptEngineContext)currentIntegrationContext.get()).clearContext();
/* 221 */     currentIntegrationContext.set(null);
/*     */   }








/*     */   private void clearContext()
/*     */   {
/* 233 */     if (this.map != null)
/*     */     {
/* 235 */       this.map.clear();
/*     */     }
/* 237 */     this.map = null;
/*     */   }
/*     */ }
