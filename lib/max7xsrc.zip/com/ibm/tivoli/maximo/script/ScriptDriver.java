package com.ibm.tivoli.maximo.script;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public abstract interface ScriptDriver
{
  public abstract void runScript(String paramString, Map<String, Object> paramMap)
    throws MXException, RemoteException;

  public abstract boolean canRun(String paramString);

  public abstract void releaseResources();

  public abstract boolean preCompileScript(ScriptInfo paramScriptInfo)
    throws MXApplicationException;

  public abstract Map<String, ScriptEngineInfo> getSupportedEngines();

  public abstract boolean isBinaryScript();

  public abstract List<ScriptParamInfo> parseScriptForParams(byte[] paramArrayOfByte)
    throws MXException;

  public abstract boolean isVarNameMatchesKeyWord(String paramString);

  public abstract boolean supportsPublishedParams();

  public abstract boolean allowImplicitParams();
}
