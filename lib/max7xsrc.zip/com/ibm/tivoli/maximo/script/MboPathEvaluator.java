/*    */ package com.ibm.tivoli.maximo.script;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import psdi.mbo.DomainInfo;
/*    */ import psdi.mbo.MaximoDD;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetInfo;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValueData;
/*    */ import psdi.mbo.MboValueInfo;
/*    */ import psdi.mbo.SYNONYMDomainInfo;
/*    */ import psdi.mbo.Translate;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXException;
/*    */ 




/*    */ public class MboPathEvaluator
/*    */ {
/*    */   public static void evaluateArrayNotation(ScriptParamInfo param, Map<String, Object> context, Mbo mbo)
/*    */     throws RemoteException, MXException
/*    */   {
/* 30 */     String paramName = param.getName();
/* 31 */     String mboRelationPath = param.getMboRelationPath();
/* 32 */     String attrLocalName = param.getMboAttributeNameLocalPart();
/* 33 */     List relatedMboList = mbo.getMboList(mboRelationPath);
/* 34 */     int mboListSize = relatedMboList.size();
/* 35 */     int i = 0;
/* 36 */     Object arrayValue = null;
/* 37 */     Object arrayInitialValue = null;
/* 38 */     String[] arrayInternalValue = null;
/* 39 */     boolean[] arrayFlagModified = null;
/* 40 */     boolean[] arrayFlagHidden = null;
/* 41 */     boolean[] arrayFlagReadonly = null;
/* 42 */     boolean[] arrayFlagRequired = null;
/*    */ 
/* 44 */     if (mboListSize > 0)
/*    */     {
/* 46 */       if (param.isMboAttributeFlag())
/*    */       {
/* 48 */         if (param.isMboAttributeFlagHidden())
/*    */         {
/* 50 */           arrayFlagHidden = new boolean[mboListSize];
/* 51 */           context.put(paramName, arrayFlagHidden);
/*    */         }
/* 53 */         else if (param.isMboAttributeFlagModified())
/*    */         {
/* 55 */           arrayFlagModified = new boolean[mboListSize];
/* 56 */           context.put(paramName, arrayFlagModified);
/*    */         }
/* 58 */         else if (param.isMboAttributeFlagReadonly())
/*    */         {
/* 60 */           arrayFlagReadonly = new boolean[mboListSize];
/* 61 */           context.put(paramName, arrayFlagReadonly);
/*    */         }
/* 63 */         else if (param.isMboAttributeFlagRequired())
/*    */         {
/* 65 */           arrayFlagRequired = new boolean[mboListSize];
/* 66 */           context.put(paramName, arrayFlagRequired);
/*    */         }
/*    */       }
/*    */       else
/*    */       {
/* 71 */         arrayFlagModified = new boolean[mboListSize];
/* 72 */         arrayFlagHidden = new boolean[mboListSize];
/* 73 */         arrayFlagReadonly = new boolean[mboListSize];
/* 74 */         arrayFlagRequired = new boolean[mboListSize];
/* 75 */         context.put(paramName + "_required", arrayFlagRequired);
/* 76 */         context.put(paramName + "_readonly", arrayFlagReadonly);
/* 77 */         context.put(paramName + "_hidden", arrayFlagHidden);
/* 78 */         context.put(paramName + "_modified", arrayFlagModified);
/*    */       }
/*    */ 
/* 81 */       for (MboRemote relatedMbo : relatedMboList)
/*    */       {
/* 83 */         MboValueData mboValueData = relatedMbo.getMboValueData(attrLocalName);
/* 84 */         MboValueInfo mboValueInfo = relatedMbo.getThisMboSet().getMboSetInfo().getMboValueInfo(attrLocalName);
/*    */ 
/* 86 */         int type = mboValueData.getTypeAsInt();
/*    */ 
/* 88 */         Object attrValue = mboValueData.getDataAsObject(type);
/* 89 */         Object attrValueInitial = ScriptUtil.getValueFromMaxType(relatedMbo.getInitialValue(attrLocalName));
/* 90 */         String attrValueInternal = null;
/* 91 */         boolean attrModified = relatedMbo.isModified(attrLocalName);
/* 92 */         boolean attrRequired = mboValueData.isRequired();
/* 93 */         boolean attrReadonly = mboValueData.isReadOnly();
/* 94 */         boolean attrHidden = mboValueData.isHidden();
/*    */ 
/* 96 */         String domainId = mboValueInfo.getDomainId();
/* 97 */         DomainInfo domainInfo = mboValueInfo.getDomainInfo();
/* 98 */         if ((domainId != null) && (domainInfo instanceof SYNONYMDomainInfo))
/*    */         {
/* 100 */           if ((arrayInternalValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInternal()))))
/*    */           {
/* 102 */             arrayInternalValue = new String[mboListSize];
/* 103 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 105 */               context.put(paramName + "_internal", arrayInternalValue);
/*    */             }
/*    */             else
/*    */             {
/* 109 */               context.put(paramName, arrayInternalValue);
/*    */             }
/*    */           }
/* 112 */           if (arrayInternalValue != null)
/*    */           {
/* 114 */             Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
/*    */ 
/* 116 */             String maxValue = translate.toInternalString(domainId, mboValueData.getData(), relatedMbo);
/*    */ 
/* 118 */             attrValueInternal = maxValue;
/* 119 */             arrayInternalValue[i] = attrValueInternal;

/*    */           }
/*    */ 
/*    */         }
/*    */ 
/* 125 */         switch (type)
/*    */         {
/*    */         case 3:
/*    */         case 4:
/*    */         case 5:
/* 130 */           if ((arrayValue == null) && (!(param.isMboAttributeFlag())))
/*    */           {
/* 132 */             arrayValue = new Date[mboListSize];
/* 133 */             context.put(paramName, arrayValue);
/*    */           }
/* 135 */           if ((arrayInitialValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInitial()))))
/*    */           {
/* 137 */             arrayInitialValue = new Date[mboListSize];
/* 138 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 140 */               context.put(paramName + "_initial", arrayInitialValue);
/*    */             }
/*    */             else
/*    */             {
/* 144 */               context.put(paramName, arrayInitialValue); }  }/* 144 */           break;




/*    */         case 9:
/*    */         case 10:
/*    */         case 11:
/* 152 */           if ((arrayValue == null) && (!(param.isMboAttributeFlag())))
/*    */           {
/* 154 */             arrayValue = new double[mboListSize];
/* 155 */             context.put(paramName, arrayValue);
/*    */           }
/* 157 */           if ((arrayInitialValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInitial()))))
/*    */           {
/* 159 */             arrayInitialValue = new double[mboListSize];
/* 160 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 162 */               context.put(paramName + "_initial", arrayInitialValue);
/*    */             }
/*    */             else
/*    */             {
/* 166 */               context.put(paramName, arrayInitialValue); }  }/* 166 */           break;




/*    */         case 8:
/* 172 */           if ((arrayValue == null) && (!(param.isMboAttributeFlag())))
/*    */           {
/* 174 */             arrayValue = new float[mboListSize];
/* 175 */             context.put(paramName, arrayValue);
/*    */           }
/* 177 */           if ((arrayInitialValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInitial()))))
/*    */           {
/* 179 */             arrayInitialValue = new float[mboListSize];
/* 180 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 182 */               context.put(paramName + "_initial", arrayInitialValue);
/*    */             }
/*    */             else
/*    */             {
/* 186 */               context.put(paramName, arrayInitialValue); }  }/* 186 */           break;




/*    */         case 6:
/*    */         case 19:
/* 193 */           if ((arrayValue == null) && (!(param.isMboAttributeFlag())))
/*    */           {
/* 195 */             arrayValue = new long[mboListSize];
/* 196 */             context.put(paramName, arrayValue);
/*    */           }
/* 198 */           if ((arrayInitialValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInitial()))))
/*    */           {
/* 200 */             arrayInitialValue = new long[mboListSize];
/* 201 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 203 */               context.put(paramName + "_initial", arrayInitialValue);
/*    */             }
/*    */             else
/*    */             {
/* 207 */               context.put(paramName, arrayInitialValue); }  }/* 207 */           break;




/*    */         case 7:
/* 213 */           if ((arrayValue == null) && (!(param.isMboAttributeFlag())))
/*    */           {
/* 215 */             arrayValue = new int[mboListSize];
/* 216 */             context.put(paramName, arrayValue);
/*    */           }
/* 218 */           if ((arrayInitialValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInitial()))))
/*    */           {
/* 220 */             arrayInitialValue = new int[mboListSize];
/* 221 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 223 */               context.put(paramName + "_initial", arrayInitialValue);
/*    */             }
/*    */             else
/*    */             {
/* 227 */               context.put(paramName, arrayInitialValue); }  }/* 227 */           break;




/*    */         case 12:
/* 233 */           if ((arrayValue == null) && (!(param.isMboAttributeFlag())))
/*    */           {
/* 235 */             arrayValue = new boolean[mboListSize];
/* 236 */             context.put(paramName, arrayValue);
/*    */           }
/* 238 */           if ((arrayInitialValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInitial()))))
/*    */           {
/* 240 */             arrayInitialValue = new boolean[mboListSize];
/* 241 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 243 */               context.put(paramName + "_initial", arrayInitialValue);
/*    */             }
/*    */             else
/*    */             {
/* 247 */               context.put(paramName, arrayInitialValue);
/*    */             }
/*    */           }
/* 250 */           if (((Integer)attrValue).equals(Integer.valueOf(1)))
/*    */           {
/* 252 */             attrValue = Boolean.valueOf(true);
/*    */           }
/*    */           else
/*    */           {
/* 256 */             attrValue = Boolean.valueOf(false);
/*    */           }
/*    */ 
/* 259 */           break;
/*    */         case 18:
/* 261 */           if ((arrayValue == null) && (!(param.isMboAttributeFlag())))
/*    */           {
/* 263 */             arrayValue = Array.newInstance([B.class, mboListSize);
/* 264 */             context.put(paramName, arrayValue);
/*    */           }
/* 266 */           if ((arrayInitialValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInitial()))))
/*    */           {
/* 268 */             arrayInitialValue = Array.newInstance([B.class, mboListSize);
/* 269 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 271 */               context.put(paramName + "_initial", arrayInitialValue);
/*    */             }
/*    */             else
/*    */             {
/* 275 */               context.put(paramName, arrayInitialValue); }  }/* 275 */           break;
/*    */         case 13:/*    */         case 14:
/*    */         case 15:
/*    */         case 16:
/*    */         case 17:
/*    */         default:
/* 281 */           if ((arrayValue == null) && (!(param.isMboAttributeFlag())))
/*    */           {
/* 283 */             arrayValue = new String[mboListSize];
/* 284 */             context.put(paramName, arrayValue);
/*    */           }
/* 286 */           if ((arrayInitialValue == null) && (((!(param.isMboAttributeFlag())) || (param.isMboAttributeFlagInitial()))))
/*    */           {
/* 288 */             arrayInitialValue = new String[mboListSize];
/* 289 */             if (!(param.isMboAttributeFlag()))
/*    */             {
/* 291 */               context.put(paramName + "_initial", arrayInitialValue);
/*    */             }
/*    */             else
/*    */             {
/* 295 */               context.put(paramName, arrayInitialValue);
/*    */             }
/*    */           }
/*    */ 
/*    */         }
/*    */ 
/* 301 */         if (param.isMboAttributeFlag())
/*    */         {
/* 303 */           if (param.isMboAttributeFlagHidden())
/*    */           {
/* 305 */             Array.set(arrayFlagHidden, i, Boolean.valueOf(attrHidden));

/*    */           }
/* 308 */           else if (param.isMboAttributeFlagModified())
/*    */           {
/* 310 */             Array.set(arrayFlagModified, i, Boolean.valueOf(attrModified));

/*    */           }
/* 313 */           else if (param.isMboAttributeFlagReadonly())
/*    */           {
/* 315 */             Array.set(arrayFlagReadonly, i, Boolean.valueOf(attrReadonly));

/*    */           }
/* 318 */           else if (param.isMboAttributeFlagRequired())
/*    */           {
/* 320 */             Array.set(arrayFlagRequired, i, Boolean.valueOf(attrRequired));

/*    */           }
/* 323 */           else if (param.isMboAttributeFlagInitial())
/*    */           {
/* 325 */             Array.set(arrayInitialValue, i, attrValueInitial);
/*    */           }
/*    */         }
/*    */         else
/*    */         {
/* 330 */           Array.set(arrayValue, i, attrValue);
/* 331 */           Array.set(arrayInitialValue, i, attrValueInitial);
/* 332 */           Array.set(arrayFlagModified, i, Boolean.valueOf(attrModified));
/* 333 */           Array.set(arrayFlagHidden, i, Boolean.valueOf(attrHidden));
/* 334 */           Array.set(arrayFlagReadonly, i, Boolean.valueOf(attrReadonly));
/* 335 */           Array.set(arrayFlagRequired, i, Boolean.valueOf(attrRequired));
/*    */         }
/* 337 */         ++i;

/*    */       }
/*    */ 
/*    */     }
/* 342 */     else if (param.isMboAttributeFlag())






/*    */     {
/* 350 */       context.put(paramName, null);

/*    */     }
/*    */     else
/*    */     {
/* 355 */       context.put(paramName, null);
/* 356 */       context.put(paramName + "_initial", null);
/* 357 */       context.put(paramName + "_internal", null);
/* 358 */       context.put(paramName + "_required", null);
/* 359 */       context.put(paramName + "_readonly", null);
/* 360 */       context.put(paramName + "_hidden", null);
/* 361 */       context.put(paramName + "_modified", null);
/*    */     }
/*    */   }
/*    */ }
