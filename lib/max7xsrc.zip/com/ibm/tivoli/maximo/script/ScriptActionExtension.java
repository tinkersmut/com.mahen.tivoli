package com.ibm.tivoli.maximo.script;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.util.MXException;
import psdi.workflow.WFActionRemote;
import psdi.workflow.WFInstance;

public abstract interface ScriptActionExtension
{
  public abstract void action(WFInstance paramWFInstance, WFActionRemote paramWFActionRemote, MboRemote paramMboRemote, Exception paramException)
    throws MXException, RemoteException;
}
