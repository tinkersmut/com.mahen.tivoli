/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeMap;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 
















/*     */ public class ScriptDriverFactory
/*     */ {
/*  33 */   private static ScriptDriverFactory factory = new ScriptDriverFactory();
/*     */ 
/*  35 */   private List<ScriptDriver> scriptDriversList = new ArrayList();
/*     */ 
/*  37 */   private Map<String, ScriptEngineInfo> allsupportedScrEngineMap = new TreeMap();
/*     */ 
/*     */   private ScriptDriverFactory()
/*     */   {
/*  41 */     String scriptDrivers = null;
/*     */     try
/*     */     {
/*  44 */       scriptDrivers = MXServer.getMXServer().getProperty("mxe.script.drivers");
/*  45 */       if (scriptDrivers == null)
/*     */       {
/*  47 */         scriptDrivers = "com.ibm.tivoli.maximo.script.JSR223ScriptDriver";
/*     */       }
/*  49 */       StringTokenizer strtk = new StringTokenizer(scriptDrivers, ",");
/*  50 */       while (strtk.hasMoreTokens())
/*     */       {
/*     */         try
/*     */         {
/*  54 */           ScriptDriver driver = (ScriptDriver)Class.forName(strtk.nextToken()).newInstance();
/*  55 */           this.scriptDriversList.add(driver);
/*  56 */           Map map = driver.getSupportedEngines();
/*  57 */           this.allsupportedScrEngineMap.putAll(map);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*  61 */           MXLoggerFactory.getLogger("maximo.script").error(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/*  67 */       MXLoggerFactory.getLogger("maximo.script").error(re.getMessage(), re);
/*     */     }
/*     */   }

/*     */   public Map<String, ScriptEngineInfo> getAllSupportedEngines()
/*     */   {
/*  73 */     return this.allsupportedScrEngineMap;
/*     */   }




/*     */   public static final ScriptDriverFactory getInstance()
/*     */   {
/*  81 */     return factory;
/*     */   }





/*     */   public ScriptDriver getScriptDriver(String scriptName)
/*     */     throws MXException
/*     */   {
/*  91 */     ScriptInfo scriptInfo = ScriptCache.getInstance().getScriptInfo(scriptName);
/*  92 */     return getScriptDriver(scriptInfo);
/*     */   }

/*     */   public ScriptDriver getScriptDriverForLanguage(String scriptLang) throws MXException
/*     */   {
/*  97 */     for (ScriptDriver driver : this.scriptDriversList)
/*     */     {
/*  99 */       if (driver.canRun(scriptLang)) return driver;
/*     */     }
/* 101 */     String[] params = { scriptLang };
/* 102 */     throw new MXApplicationException("script", "nomatchingdriver", params);
/*     */   }





/*     */   public ScriptDriver getScriptDriver(ScriptInfo scriptInfo)
/*     */     throws MXException
/*     */   {
/* 112 */     if (scriptInfo == null)
/*     */     {
/* 114 */       String[] params = { scriptInfo.getName() };
/* 115 */       throw new MXApplicationException("script", "nosuchscript", params);
/*     */     }
/*     */ 
/* 118 */     String scriptLang = scriptInfo.getScriptLanguge();
/* 119 */     for (ScriptDriver driver : this.scriptDriversList)
/*     */     {
/* 121 */       if (driver.canRun(scriptLang)) return driver;
/*     */     }
/* 123 */     String[] params = { scriptLang };
/* 124 */     throw new MXApplicationException("script", "nomatchingdriver", params);
/*     */   }





/*     */   public void releaseDriverResources()
/*     */   {
/* 133 */     for (ScriptDriver driver : this.scriptDriversList)
/*     */     {
/* 135 */       driver.releaseResources();
/*     */     }
/*     */   }
/*     */ }
