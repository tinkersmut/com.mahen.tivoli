/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import psdi.common.parse.ParserServiceRemote;
/*     */ import psdi.iface.mos.ConversionUtil;
/*     */ import psdi.mbo.DomainInfo;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueData;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.mbo.SYNONYMDomainInfo;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.MaxVarServiceRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXCorrelator;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 


































/*     */ public abstract class AbstractScriptDriver
/*     */   implements ScriptDriver
/*     */ {
/*  53 */   private static Set<String> keyWords = new HashSet();
/*     */ 
/*     */   public boolean isVarNameMatchesKeyWord(String varName)
/*     */   {
/*  73 */     return keyWords.contains(varName);
/*     */   }


/*     */   public final void runScript(String name, Map<String, Object> context)
/*     */     throws MXException, RemoteException
/*     */   {
/*  80 */     boolean enableCorrelator = "1".equals(MXServer.getMXServer().getProperty("mxe.logging.CorrelationEnabled"));
/*  81 */     MXCorrelator correlator = null;
/*  82 */     if (enableCorrelator)
/*     */     {
/*  84 */       correlator = MXCorrelator.startCorrelation("MXSCRIPT");



/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  92 */       ScriptInfo scriptInfo = ScriptCache.getInstance().getScriptInfo(name);
/*  93 */       if (scriptInfo == null)
/*     */       {
/*  95 */         String[] params = { name };
/*  96 */         throw new MXApplicationException("script", "nosuchscript", params);
/*     */       }
/*  98 */       if (context == null)
/*     */       {
/* 100 */         context = new HashMap();
/*     */       }
/* 102 */       String launchPointName = (String)context.get("launchPoint");
/* 103 */       ScriptLaunchPointInfo scriptLaunchPointInfo = scriptInfo.getLaunchPoint(launchPointName);






/*     */ 
/* 111 */       String expression = null;
/* 112 */       if (scriptLaunchPointInfo != null)
/*     */       {
/* 114 */         if (!(scriptLaunchPointInfo.isActive()))
/*     */         {
/* 116 */           String[] params = { name, launchPointName };
/* 117 */           throw new MXApplicationException("script", "inactivelp", params);

/*     */         }
/*     */ 
/* 121 */         expression = scriptLaunchPointInfo.getExpression();

/*     */       }
/*     */ 
/* 125 */       if (correlator != null)
/*     */       {
/* 127 */         correlator.addCorrelationData("Script", name);
/* 128 */         correlator.addCorrelationData("LaunchPoint", launchPointName);

/*     */       }
/*     */ 
/* 132 */       long ts0 = System.currentTimeMillis();
/* 133 */       if (expression != null)
/*     */       {
/* 135 */         MboRemote mbo = (MboRemote)context.get("mbo");
/* 136 */         ParserServiceRemote parserService = (ParserServiceRemote)MXServer.getMXServer().lookup("PARSER");
/* 137 */         boolean allow = parserService.getBoolean(expression, mbo);
/* 138 */         if (!(allow))
/*     */         {
/* 140 */           getLogger().info("AbstractScriptDriver - the call to script " + name + " for launchpoint " + launchPointName + " has been skipped as the " + "filter criterion was not satified");

/*     */           return;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 147 */       long ts1 = System.currentTimeMillis();
/* 148 */       if ((expression != null) && (correlator != null))
/*     */       {
/* 150 */         correlator.addCorrelationData("filterEvalTime", Long.toString(ts1 - ts0));
/*     */       }
/* 152 */       evalINParams(scriptInfo, context);
/* 153 */       long ts2 = System.currentTimeMillis();
/* 154 */       Map clonedContext = (Map)((HashMap)context).clone();
/* 155 */       if (ScriptEngineContext.getCurrentContext() != null)
/*     */       {
/* 157 */         ScriptEngineContext.getCurrentContext().setProperties(context);
/*     */       }
/*     */ 
/* 160 */       evalScript(scriptInfo, context);
/* 161 */       long ts3 = System.currentTimeMillis();
/* 162 */       evalOUTParams(scriptInfo, context, clonedContext);
/* 163 */       long ts4 = System.currentTimeMillis();
/*     */ 
/* 165 */       if (correlator != null)
/*     */       {
/* 167 */         correlator.addCorrelationData("evalINParamsTime", Long.toString(ts2 - ts1));
/* 168 */         correlator.addCorrelationData("evalScriptTime", Long.toString(ts3 - ts2));
/* 169 */         correlator.addCorrelationData("evalOUTParamsTime", Long.toString(ts4 - ts3));
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 174 */       MXCorrelator.endCorrelation();
/*     */     }
/*     */   }






/*     */   public boolean isParamErrorKey(String contextParam)
/*     */   {
/* 185 */     return contextParam.equals("errorkey");
/*     */   }





/*     */   public boolean isParamErrorGroup(String contextParam)
/*     */   {
/* 194 */     return contextParam.equals("errorgroup");
/*     */   }

















/*     */   protected void evalINParams(ScriptInfo scriptInfo, Map<String, Object> context)
/*     */     throws MXException, RemoteException
/*     */   {
/* 216 */     MXCorrelator correlator = MXCorrelator.getCorrelator();
/* 217 */     String launchPointName = (String)context.get("launchPoint");
/* 218 */     Map params = null;
/* 219 */     if (launchPointName != null)
/*     */     {
/* 221 */       params = scriptInfo.getLaunchPoint(launchPointName).getScriptParams();
/*     */     }
/*     */     else
/*     */     {
/* 225 */       params = scriptInfo.getScriptParams();
/*     */     }
/* 227 */     MboRemote mbo = (MboRemote)context.get("mbo");
/* 228 */     if (mbo != null)
/*     */     {
/* 230 */       context.put("app", mbo.getThisMboSet().getApp());
/* 231 */       context.put("user", mbo.getUserName());
/*     */ 
/* 233 */       if (correlator != null)
/*     */       {
/* 235 */         correlator.addCorrelationData("app", mbo.getThisMboSet().getApp());
/* 236 */         correlator.addCorrelationData("UserName", mbo.getThisMboSet().getApp());
/* 237 */         correlator.addCorrelationData("MboName", mbo.getName());
/* 238 */         correlator.addCorrelationData("MboId", "" + mbo.getUniqueIDValue());
/*     */       }
/*     */ 
/* 241 */       context.put("onadd", Boolean.valueOf(mbo.toBeAdded()));
/* 242 */       context.put("onupdate", Boolean.valueOf(mbo.toBeUpdated()));
/* 243 */       context.put("ondelete", Boolean.valueOf(mbo.toBeDeleted()));





/*     */     }
/*     */ 
/* 251 */     Set paramSet = params.entrySet();
/* 252 */     for (Map.Entry paramEntry : paramSet)
/*     */     {
/* 254 */       ScriptParamInfo param = (ScriptParamInfo)paramEntry.getValue();
/*     */ 
/* 256 */       if (param.getInoutType().equals("OUT"))
/*     */       {
/* 258 */         if (param.isBindingMboAttr())
/*     */         {
/* 260 */           String[] errparams = { param.getName(), launchPointName, scriptInfo.getName() };
/* 261 */           if (param.isArrayType())
/*     */           {
/* 263 */             throw new MXApplicationException("script", "attrarrayoutnotsupported", errparams);
/*     */           }
/* 265 */           if (!(param.hasVarBindingValue()))
/*     */           {
/* 267 */             throw new MXApplicationException("script", "noattrbindingvalue", errparams);
/*     */           }
/* 269 */           String mboAttr = null;
/* 270 */           if (param.isMboAttributeFlag())
/*     */           {
/* 272 */             mboAttr = param.getMboAttributeName();
/*     */           }
/*     */           else
/*     */           {
/* 276 */             mboAttr = param.getVarBindingValue();
/*     */           }
/*     */ 
/* 279 */           if (!(param.isMboAttributeFlag()))
/*     */           {
/* 281 */             MboValueData mboValueData = mbo.getMboValueData(mboAttr);
/* 282 */             Object value = mboValueData.getDataAsObject();
/* 283 */             getLogger().debug("AbstractScriptDriver context value = " + value + " for mbo attribute " + param.getName());
/* 284 */             if (mbo.isNull(mboAttr))
/*     */             {
/* 286 */               context.put(param.getName(), null);
/*     */             }
/*     */             else
/*     */             {
/* 290 */               context.put(param.getName(), value);
/*     */             }
/*     */ 
/* 293 */             context.put(param.getName() + "_required", Boolean.valueOf(mboValueData.isRequired()));
/* 294 */             context.put(param.getName() + "_readonly", Boolean.valueOf(mboValueData.isReadOnly()));
/* 295 */             context.put(param.getName() + "_hidden", Boolean.valueOf(mboValueData.isHidden()));

/*     */           }
/*     */           else
/*     */           {
/* 300 */             MboValueData mboValueData = mbo.getMboValueData(mboAttr);
/* 301 */             if (param.isMboAttributeFlagHidden())
/*     */             {
/* 303 */               context.put(param.getName(), Boolean.valueOf(mboValueData.isHidden()));
/*     */             }
/* 305 */             else if (param.isMboAttributeFlagRequired())
/*     */             {
/* 307 */               context.put(param.getName(), Boolean.valueOf(mboValueData.isRequired()));
/*     */             }
/* 309 */             else if (param.isMboAttributeFlagReadonly())
/*     */             {
/* 311 */               context.put(param.getName(), Boolean.valueOf(mboValueData.isReadOnly()));
/*     */             }
/*     */             else
/*     */             {
/* 315 */               String[] errparams1 = { scriptInfo.getName(), param.getMboAttributeFlagName(), launchPointName };
/* 316 */               throw new MXApplicationException("script", "unsupported_metadata_forout", errparams1);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/* 324 */       else if (param.isBindingMaxProp())
/*     */       {
/* 326 */         String maxProp = param.getVarBindingValue();

/*     */ 
/* 329 */         String value = MXServer.getMXServer().getProperty(maxProp);
/* 330 */         getLogger().debug("AbstractScriptDriver context value = " + value + " for maxprop " + param.getName());
/* 331 */         context.put(param.getName(), value);
/*     */       }
/* 333 */       else if (param.isBindingMaxVar())
/*     */       {
/* 335 */         String maxVar = param.getVarBindingValue();
/* 336 */         String value = null;
/* 337 */         String site = null;
/* 338 */         String org = null;
/* 339 */         if (mbo != null)
/*     */         {
/* 341 */           String[] siteOrg = mbo.getSiteOrg();
/* 342 */           site = siteOrg[0];
/* 343 */           org = siteOrg[1];
/*     */         }
/*     */ 
/* 346 */         value = ((MaxVarServiceRemote)MXServer.getMXServer().lookup("MAXVARS")).getString(maxVar, org, site);
/* 347 */         getLogger().debug("AbstractScriptDriver context value = " + value + " for maxvar " + param.getName());
/* 348 */         context.put(param.getName(), value);
/*     */       }
/* 350 */       else if (param.isBindingMboAttr())
/*     */       {
/* 352 */         String mboAttr = null;
/* 353 */         if (!(param.hasVarBindingValue()))
/*     */         {
/* 355 */           String[] errparams = { param.getName(), launchPointName, scriptInfo.getName() };
/* 356 */           throw new MXApplicationException("script", "noattrbindingvalue", errparams);
/*     */         }
/*     */ 
/* 359 */         if (param.isMboAttributeFlag())
/*     */         {
/* 361 */           mboAttr = param.getMboAttributeName();
/*     */         }
/*     */         else
/*     */         {
/* 365 */           mboAttr = param.getVarBindingValue();

/*     */         }
/*     */ 
/* 369 */         if (!(param.isMboAttributeFlag()))
/*     */         {
/* 371 */           if (param.isArrayType())
/*     */           {
/* 373 */             MboPathEvaluator.evaluateArrayNotation(param, context, (Mbo)mbo);
/*     */           }
/*     */           else
/*     */           {
/* 377 */             MboValueData mboValueData = mbo.getMboValueData(mboAttr);
/*     */ 
/* 379 */             MboValueInfo mboValueInfo = mbo.getThisMboSet().getMboSetInfo().getMboValueInfo(mboAttr);

/*     */ 
/* 382 */             Object value = mboValueData.getDataAsObject();
/* 383 */             getLogger().debug("AbstractScriptDriver context value = " + value + " for mbo attribute " + param.getName());
/* 384 */             if (mbo.isNull(mboAttr))
/*     */             {
/* 386 */               context.put(param.getName(), null);
/*     */             }
/*     */             else
/*     */             {
/* 390 */               context.put(param.getName(), value);
/*     */             }
/*     */ 
/* 393 */             context.put(param.getName() + "_required", Boolean.valueOf(mboValueData.isRequired()));
/* 394 */             context.put(param.getName() + "_readonly", Boolean.valueOf(mboValueData.isReadOnly()));
/* 395 */             context.put(param.getName() + "_hidden", Boolean.valueOf(mboValueData.isHidden()));
/* 396 */             context.put(param.getName() + "_initial", mbo.getInitialValue(mboAttr));
/*     */ 
/* 398 */             if (mboValueInfo != null)
/*     */             {
/* 400 */               String domainId = mboValueInfo.getDomainId();
/* 401 */               DomainInfo domainInfo = mboValueInfo.getDomainInfo();
/* 402 */               if ((domainId != null) && (domainInfo instanceof SYNONYMDomainInfo))
/*     */               {
/* 404 */                 Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
/*     */ 
/* 406 */                 String maxValue = translate.toInternalString(domainId, mboValueData.getData(), mbo);
/*     */ 
/* 408 */                 context.put(param.getName() + "_internal", maxValue);
/*     */               }
/* 410 */               context.put(param.getName() + "_modified", Boolean.valueOf(mbo.isModified(mboAttr)));

/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/* 417 */         else if (param.isArrayType())
/*     */         {
/* 419 */           MboPathEvaluator.evaluateArrayNotation(param, context, (Mbo)mbo);
/*     */         }
/*     */         else
/*     */         {
/* 423 */           MboValueData mboValueData = mbo.getMboValueData(mboAttr);
/* 424 */           if (param.isMboAttributeFlagHidden())
/*     */           {
/* 426 */             context.put(param.getName(), Boolean.valueOf(mboValueData.isHidden()));
/*     */           }
/* 428 */           else if (param.isMboAttributeFlagRequired())
/*     */           {
/* 430 */             context.put(param.getName(), Boolean.valueOf(mboValueData.isRequired()));
/*     */           }
/* 432 */           else if (param.isMboAttributeFlagReadonly())
/*     */           {
/* 434 */             context.put(param.getName(), Boolean.valueOf(mboValueData.isReadOnly()));
/*     */           }
/* 436 */           else if (param.isMboAttributeFlagModified())
/*     */           {
/* 438 */             context.put(param.getName(), Boolean.valueOf(mbo.isModified(mboAttr)));
/*     */           }
/* 440 */           else if (param.isMboAttributeFlagInternal())
/*     */           {
/* 442 */             MboValueInfo mboValueInfo = mbo.getThisMboSet().getMboSetInfo().getMboValueInfo(mboAttr);

/*     */ 
/* 445 */             if (mboValueInfo != null)
/*     */             {
/* 447 */               String domainId = mboValueInfo.getDomainId();
/* 448 */               DomainInfo domainInfo = mboValueInfo.getDomainInfo();
/* 449 */               if ((domainId != null) && (domainInfo instanceof SYNONYMDomainInfo))
/*     */               {
/* 451 */                 Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
/*     */ 
/* 453 */                 String maxValue = translate.toInternalString(domainId, mboValueData.getData(), mbo);
/*     */ 
/* 455 */                 context.put(param.getName(), maxValue);
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/* 460 */               context.put(param.getName(), mboValueData.getDataAsObject());
/*     */             }
/*     */           }
/* 463 */           else if (param.isMboAttributeFlagInitial())
/*     */           {
/* 465 */             if (context.containsKey(mboAttr.toLowerCase() + "_initial"))
/*     */             {
/* 467 */               context.put(param.getName(), context.get(mboAttr.toLowerCase() + "_initial"));
/*     */             }
/*     */             else
/*     */             {
/* 471 */               context.put(param.getName(), ScriptUtil.getValueFromMaxType(mbo.getInitialValue(mboAttr)));
/*     */             }
/*     */           }
/* 474 */           else if (param.isMboAttributeFlagPrevious())
/*     */           {
/* 476 */             if (context.containsKey(mboAttr.toLowerCase() + "_previous"))
/*     */             {
/* 478 */               context.put(param.getName(), context.get(mboAttr.toLowerCase() + "_previous"));
/*     */             }
/*     */             else
/*     */             {
/* 482 */               context.put(param.getName(), ScriptUtil.getValueFromMaxType(mbo.getInitialValue(mboAttr)));
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 491 */         context.put(param.getName(), getLiteralValue(param.getVarBindingValue(), param.getLiteralValueType()));
/* 492 */         getLogger().debug("AbstractScriptDriver context value = " + context.get(param.getName()) + " for literal param " + param.getName());
/*     */       }
/*     */     }
/*     */   }


/*     */   protected boolean isChildAttribute(String attrBindingValue)
/*     */   {
/* 500 */     return (attrBindingValue.indexOf(".") > 0);
/*     */   }
















/*     */   private Object getLiteralValue(String value, String type)
/*     */     throws MXException
/*     */   {
/* 521 */     if (type.equals("SMALLINT"))
/*     */     {
/* 523 */       return Integer.valueOf(Integer.parseInt(value));
/*     */     }
/* 525 */     if (type.equals("DECIMAL"))
/*     */     {
/* 527 */       return Double.valueOf(Double.parseDouble(value));
/*     */     }
/* 529 */     if (type.equals("FLOAT"))
/*     */     {
/* 531 */       return Float.valueOf(Float.parseFloat(value));
/*     */     }
/* 533 */     if (type.equals("INTEGER"))
/*     */     {
/* 535 */       return Long.valueOf(Long.parseLong(value));
/*     */     }
/* 537 */     if (type.equals("DATETIME"))
/*     */     {
/* 539 */       return ConversionUtil.stringToDate(value);

/*     */     }
/*     */ 
/* 543 */     return value;
/*     */   }







/*     */   protected boolean isNull(String s)
/*     */   {
/* 554 */     return ((s == null) || (s.trim().length() == 0));
/*     */   }










/*     */   protected void evalOUTParams(ScriptInfo scriptInfo, Map<String, Object> context, Map<String, Object> clonedContext)
/*     */     throws MXException, RemoteException
/*     */   {
/* 569 */     String launchPointName = (String)context.get("launchPoint");
/* 570 */     checkForScriptError(context);
/*     */ 
/* 572 */     Map params = null;
/* 573 */     if (launchPointName != null)
/*     */     {
/* 575 */       params = scriptInfo.getLaunchPoint(launchPointName).getScriptParams();
/*     */     }
/*     */     else
/*     */     {
/* 579 */       params = scriptInfo.getScriptParams();
/*     */     }
/*     */ 
/* 582 */     MboRemote mbo = (MboRemote)context.get("mbo");

/*     */ 
/* 585 */     Set paramSet = params.entrySet();
/* 586 */     for (Map.Entry paramEntry : paramSet)


/*     */     {
/* 590 */       ScriptParamInfo param = (ScriptParamInfo)paramEntry.getValue();
/* 591 */       if (param.getInoutType().equals("IN")) continue; if (!(param.isBindingMboAttr()))
/*     */         continue;
/* 593 */       if (!(param.hasVarBindingValue()))
/*     */       {
/* 595 */         String[] errparams = { param.getName(), launchPointName };
/* 596 */         throw new MXApplicationException("script", "noattrbindingvalue", errparams);
/*     */       }
/*     */ 
/* 599 */       String attributeName = null;
/* 600 */       if (param.isMboAttributeFlag())
/*     */       {
/* 602 */         attributeName = param.getMboAttributeName();
/*     */       }
/*     */       else
/*     */       {
/* 606 */         attributeName = param.getVarBindingValue();


/*     */       }
/*     */ 
/* 611 */       if (!(param.isMboAttributeFlag()))
/*     */       {
/* 613 */         if (hasValueChanged(param.getName(), context, clonedContext))
/*     */         {
/* 615 */           Object paramValue = context.get(param.getName());
/* 616 */           long accessMod = param.getAccessFlag();
/* 617 */           setValue(mbo, attributeName, paramValue, accessMod);
/*     */         }
/*     */ 
/* 620 */         String paramReqdFlag = param.getName() + "_required";
/* 621 */         if (hasValueChanged(paramReqdFlag, context, clonedContext))
/*     */         {
/* 623 */           boolean paramReqdValue = ((Boolean)context.get(paramReqdFlag)).booleanValue();
/* 624 */           mbo.setFieldFlag(attributeName, 128L, paramReqdValue);
/*     */         }
/*     */ 
/* 627 */         String paramHiddenFlag = param.getName() + "_hidden";
/* 628 */         if (hasValueChanged(paramHiddenFlag, context, clonedContext))
/*     */         {
/* 630 */           boolean paramHiddenValue = ((Boolean)context.get(paramHiddenFlag)).booleanValue();
/* 631 */           mbo.setFieldFlag(attributeName, 263L, paramHiddenValue);
/*     */         }
/*     */ 
/* 634 */         String paramReadonlyFlag = param.getName() + "_readonly";
/* 635 */         if (hasValueChanged(paramReadonlyFlag, context, clonedContext))
/*     */         {
/* 637 */           boolean paramReadonlyValue = ((Boolean)context.get(param.getName() + "_readonly")).booleanValue();
/* 638 */           mbo.setFieldFlag(attributeName, 7L, paramReadonlyValue);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 643 */         boolean paramValue = ((Boolean)context.get(param.getName())).booleanValue();
/* 644 */         if (hasValueChanged(param.getName(), context, clonedContext))
/*     */         {
/* 646 */           if (param.isMboAttributeFlagHidden())
/*     */           {
/* 648 */             mbo.setFieldFlag(attributeName, 263L, paramValue);
/*     */           }
/* 650 */           else if (param.isMboAttributeFlagRequired())
/*     */           {
/* 652 */             mbo.setFieldFlag(attributeName, 128L, paramValue);
/*     */           }
/* 654 */           else if (param.isMboAttributeFlagReadonly())
/*     */           {
/* 656 */             mbo.setFieldFlag(attributeName, 7L, paramValue);
/*     */           }
/*     */           else
/*     */           {
/* 660 */             String[] errparams = { scriptInfo.getName(), param.getMboAttributeFlagName(), launchPointName };
/* 661 */             throw new MXApplicationException("script", "unsupported_metadata_forout", errparams);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }






/*     */   protected void checkForScriptError(Map<String, Object> context)
/*     */     throws MXException
/*     */   {
/* 676 */     String errKeyVal = (String)context.get("errorkey");
/* 677 */     String errGrpVal = (String)context.get("errorgroup");
/* 678 */     Object paramsO = context.get("params");
/* 679 */     String[] params = null;
/* 680 */     if (paramsO != null)
/*     */     {/*     */       int i;/*     */       Iterator i$;
/* 682 */       if (paramsO instanceof List)
/*     */       {
/* 684 */         params = new String[((List)paramsO).size()];
/* 685 */         i = 0;
/* 686 */         for (i$ = ((List)paramsO).iterator(); i$.hasNext(); ) { Object o = i$.next();
/*     */ 
/* 688 */           params[i] = o.toString();
/* 689 */           ++i;
/*     */         }
/*     */       }
/* 692 */       else if ((paramsO.getClass().isArray()) && (paramsO.getClass().getComponentType().equals(String.class)))
/*     */       {
/* 694 */         params = (String[])(String[])paramsO;
/*     */       }
/*     */     }
/* 697 */     if ((isNull(errGrpVal)) || (isNull(errKeyVal)))
/*     */       return;
/* 699 */     if ((params == null) || (params.length == 0))
/*     */     {
/* 701 */       throw new MXApplicationException(errGrpVal, errKeyVal);

/*     */     }
/*     */ 
/* 705 */     throw new MXApplicationException(errGrpVal, errKeyVal, params);
/*     */   }












/*     */   protected void setValue(MboRemote mbo, String attributeName, Object value, long flag)
/*     */     throws MXException, RemoteException
/*     */   {
/* 722 */     if (value instanceof Date)
/*     */     {
/* 724 */       mbo.setValue(attributeName, (Date)value, flag);
/*     */     }
/* 726 */     else if (value instanceof Double)
/*     */     {
/* 728 */       mbo.setValue(attributeName, ((Double)value).doubleValue(), flag);
/*     */     }
/* 730 */     else if (value instanceof Float)
/*     */     {
/* 732 */       mbo.setValue(attributeName, ((Float)value).floatValue(), flag);
/*     */     }
/* 734 */     else if (value instanceof Long)
/*     */     {
/* 736 */       mbo.setValue(attributeName, ((Long)value).longValue(), flag);
/*     */     }
/* 738 */     else if (value instanceof Integer)
/*     */     {
/* 740 */       mbo.setValue(attributeName, ((Integer)value).intValue(), flag);
/*     */     }
/* 742 */     else if (value instanceof byte[])
/*     */     {
/* 744 */       mbo.setValue(attributeName, (byte[])(byte[])value, flag);
/*     */     }
/*     */     else
/*     */     {
/* 748 */       mbo.setValue(attributeName, (String)value, flag);
/*     */     }
/*     */   }








































/*     */   protected MXLogger getLogger()
/*     */   {
/* 793 */     return MXLoggerFactory.getLogger("maximo.script");
/*     */   }








/*     */   protected boolean hasValueChanged(String contextVar, Map<String, Object> context, Map<String, Object> clonedContext)
/*     */   {
/* 805 */     Object initialValue = context.get(contextVar);
/* 806 */     Object value = clonedContext.get(contextVar);
/* 807 */     if ((initialValue == null) && (value != null)) return true;
/* 808 */     if ((initialValue == null) && (value == null)) return false;
/* 809 */     return (!(initialValue.equals(value)));
/*     */   }

/*     */   public boolean supportsPublishedParams()
/*     */   {
/* 814 */     return false;
/*     */   }

/*     */   public boolean allowImplicitParams()
/*     */   {
/* 819 */     return true;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  56 */     keyWords.add("app");
/*  57 */     keyWords.add("errorgroup");
/*  58 */     keyWords.add("errorkey");
/*  59 */     keyWords.add("evalresult");
/*  60 */     keyWords.add("params");
/*  61 */     keyWords.add("user");
/*  62 */     keyWords.add("launchPoint");
/*  63 */     keyWords.add("scriptName");
/*  64 */     keyWords.add("mboname");
/*  65 */     keyWords.add("mbo");
/*  66 */     keyWords.add("onadd");
/*  67 */     keyWords.add("onupdate");
/*  68 */     keyWords.add("ondelete");
/*     */   }
/*     */ }
