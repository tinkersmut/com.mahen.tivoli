/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import psdi.common.condition.CustomCondition;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 






















/*     */ public class ScriptCustomCondition
/*     */   implements CustomCondition
/*     */ {
/*     */   public boolean evaluateCondition(MboRemote mbo, Object param)
/*     */     throws MXException, RemoteException
/*     */   {
/*  43 */     String scriptName = null;
/*  44 */     String lpName = null;
/*  45 */     if ((param instanceof MboRemote) && (((MboRemote)param).getName().equalsIgnoreCase("WFCONDITION")))
/*     */     {
/*  47 */       MboRemote cond = (MboRemote)param;
/*     */ 
/*  49 */       MboRemote node = cond.getOwner();
/*  50 */       String nodeTitle = node.getString("title").toUpperCase();
/*  51 */       if (nodeTitle.indexOf(":") > 0)
/*     */       {
/*  53 */         String[] scriptPointer = nodeTitle.split(":");
/*  54 */         scriptName = scriptPointer[0];
/*  55 */         lpName = scriptPointer[1];
/*  56 */         ScriptInfo scriptInfo = ScriptCache.getInstance().getScriptInfo(nodeTitle);
/*  57 */         if (scriptInfo == null)
/*     */         {
/*  59 */           String[] params = { scriptName };
/*  60 */           throw new MXApplicationException("script", "nosuchscript", params);
/*     */         }
/*     */ 
/*  63 */         ScriptLaunchPointInfo lpInfo = scriptInfo.getLaunchPoint(lpName);
/*  64 */         if (lpInfo == null)
/*     */         {
/*  66 */           String[] params = { scriptName, lpName };
/*  67 */           throw new MXApplicationException("script", "nosuchlp", params);

/*     */         }
/*     */ 
/*  71 */         if (!(lpInfo.getType().equals("CUSTOMCONDITION")))
/*     */         {
/*  73 */           String[] params = { lpInfo.getName(), "CUSTOMCONDITION", lpInfo.getType() };
/*  74 */           throw new MXApplicationException("script", "inavlidlptype", params);

/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*  81 */         ScriptInfo scriptInfo = ScriptCache.getInstance().getScriptInfo(nodeTitle);
/*  82 */         if (scriptInfo == null)
/*     */         {
/*  84 */           String[] params = { nodeTitle };
/*  85 */           throw new MXApplicationException("script", "nosuchscript", params);
/*     */         }
/*  87 */         Set lpInfoSet = scriptInfo.getLaunchPoints().entrySet();
/*  88 */         if (lpInfoSet.size() > 1)
/*     */         {
/*  90 */           String[] params = { nodeTitle };
/*  91 */           throw new MXApplicationException("script", "ambiguouslp", params);
/*     */         }
/*  93 */         ScriptLaunchPointInfo lpInfo = (ScriptLaunchPointInfo)((Map.Entry)lpInfoSet.iterator().next()).getValue();
/*  94 */         if (!(lpInfo.getType().equals("CUSTOMCONDITION")))
/*     */         {
/*  96 */           String[] params = { lpInfo.getName(), "CUSTOMCONDITION", lpInfo.getType() };
/*  97 */           throw new MXApplicationException("script", "inavlidlptype", params);
/*     */         }
/*  99 */         scriptName = nodeTitle;
/* 100 */         lpName = lpInfo.getName();

/*     */       }
/*     */ 
/*     */     }
/* 105 */     else if (param instanceof String)
/*     */     {
/* 107 */       String paramExp = ((String)param).toUpperCase();
/* 108 */       if (paramExp.indexOf(":") > 0)
/*     */       {
/* 110 */         String[] scriptPointer = paramExp.split(":");
/* 111 */         scriptName = scriptPointer[0];
/* 112 */         lpName = scriptPointer[1];
/*     */       }
/*     */       else
/*     */       {
/* 116 */         ScriptInfo scriptInfo = ScriptCache.getInstance().getScriptInfo(paramExp);
/* 117 */         Set lpInfoSet = scriptInfo.getLaunchPoints().entrySet();
/* 118 */         ScriptLaunchPointInfo lpInfo = (ScriptLaunchPointInfo)((Map.Entry)lpInfoSet.iterator().next()).getValue();
/*     */ 
/* 120 */         scriptName = paramExp;
/* 121 */         lpName = lpInfo.getName();
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 127 */       return false;
/*     */     }
/* 129 */     Map context = new HashMap();
/* 130 */     context.put("mbo", mbo);
/* 131 */     context.put("launchPoint", lpName);
/*     */ 
/* 133 */     ScriptDriverFactory.getInstance().getScriptDriver(scriptName).runScript(scriptName, context);
/* 134 */     return ((Boolean)context.get("evalresult")).booleanValue();
/*     */   }


/*     */   public String toWhereClause(Object param, MboSetRemote msr)
/*     */     throws MXException, RemoteException
/*     */   {
/* 141 */     return null;
/*     */   }
/*     */ }
