/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import psdi.mbo.MaximoCache;
/*     */ import psdi.security.SecurityService;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.DBManager;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXFormat;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 

































/*     */ public class ScriptCache
/*     */   implements MaximoCache
/*     */ {
/*  48 */   private Map<String, ScriptInfo> scriptMap = new HashMap();
/*  49 */   private static ScriptCache scriptCache = null;
/*     */   public static final String SCRIPT_LOGGER = "maximo.script";
/*  51 */   public static final MXLogger SCRIPTLOGGER = MXLoggerFactory.getLogger("maximo.script");
/*     */ 
/*  53 */   private ScriptListenerManager manager = new ScriptListenerManager();
/*     */ 
/*     */   public static final ScriptCache getInstance()
/*     */   {
/*  69 */     return scriptCache;
/*     */   }

/*     */   private ScriptCache() throws MXException
/*     */   {
/*  74 */     loadScripts();
/*     */     try
/*     */     {
/*  77 */       MXServer.getMXServer().addToMaximoCache(getName(), this);
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/*  81 */       if (!(SCRIPTLOGGER.isErrorEnabled()))
/*     */         return;
/*  83 */       SCRIPTLOGGER.error(e.getMessage(), e);
/*     */     }
/*     */   }



/*     */   public String getName()
/*     */   {
/*  91 */     return "SCRIPT";
/*     */   }

/*     */   public void init() throws MXException
/*     */   {
/*  96 */     loadScripts();
/*     */   }

/*     */   public void reload() throws MXException
/*     */   {
/* 101 */     loadScripts();
/*     */   }

/*     */   public void reload(String key) throws MXException
/*     */   {
/* 106 */     loadScripts();
/*     */   }

/*     */   public ScriptInfo getScriptInfo(String name)
/*     */   {
/* 111 */     return ((ScriptInfo)this.scriptMap.get(name));
/*     */   }

/*     */   public void loadScripts()
/*     */     throws MXException
/*     */   {
/* 117 */     this.manager.unregisterAllListeners();
/* 118 */     this.scriptMap.clear();
/* 119 */     ScriptDriverFactory.getInstance().releaseDriverResources();
/* 120 */     Statement s = null;
/* 121 */     UserInfo systemUserInfo = null;
/*     */     try
/*     */     {
/* 124 */       SecurityService secServ = (SecurityService)MXServer.getMXServer().lookup("SECURITY");
/* 125 */       systemUserInfo = secServ.getSystemUserInfo();
/* 126 */       Connection connection = MXServer.getMXServer().getDBManager().getConnection(systemUserInfo.getConnectionKey());
/*     */ 
/* 128 */       s = connection.createStatement();
/*     */ 
/* 130 */       s.execute("select ascr.autoscript, ascr.source, ascr.binaryscriptsource, ascr.scriptlanguage, ascr.loglevel, ascrv.varname, ascrv.vartype, ascrv.varbindingtype, ascrv.varbindingvalue, ascrv.accessflag, ascrv.literaldatatype, ascrv.allowoverride from autoscript ascr left outer join autoscriptvars ascrv on ascr.autoscript=ascrv.autoscript order by ascr.autoscript");





/*     */ 
/* 137 */       ResultSet rs = s.getResultSet();

/*     */ 
/* 140 */       Set corruptScript = new HashSet();
/* 141 */       while (rs.next())
/*     */       {
/* 143 */         String name = rs.getString(1);
/* 144 */         if (!(corruptScript.contains(name)));
/* 145 */         Clob clobData = rs.getClob(2);
/* 146 */         String source = null;
/* 147 */         if (!(rs.wasNull()))
/*     */         {
/* 149 */           source = MXFormat.clobToString(clobData);
/*     */         }
/* 151 */         String scriptLanguage = rs.getString(4);
/*     */ 
/* 153 */         byte[] binarySource = null;
/* 154 */         Blob blobData = rs.getBlob(3);
/* 155 */         if (!(rs.wasNull()))
/*     */         {
/* 157 */           binarySource = MXFormat.blobToBytes(blobData);








/*     */         }
/*     */ 
/* 168 */         String logLevel = rs.getString(5);
/* 169 */         String varName = rs.getString(6);
/*     */ 
/* 171 */         ScriptInfo info = (ScriptInfo)this.scriptMap.get(name);
/* 172 */         if (info == null)
/*     */         {
/* 174 */           info = new ScriptInfo(name, scriptLanguage, source, binarySource, logLevel);

/*     */           try
/*     */           {
/* 178 */             ScriptDriverFactory.getInstance().getScriptDriver(info).preCompileScript(info);
/* 179 */             this.scriptMap.put(name, info);
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 183 */             SCRIPTLOGGER.error(e.getMessage(), e);
/* 184 */             SCRIPTLOGGER.error("Error in compiling script - skipping this script " + name);
/* 185 */             corruptScript.add(name);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 190 */         if (varName != null)
/*     */         {
/* 192 */           String inOutType = rs.getString(7);
/*     */ 
/* 194 */           String varBindingType = rs.getString(8);
/* 195 */           String varBindingValue = rs.getString(9);
/* 196 */           long accessFlag = rs.getLong(10);
/* 197 */           String litValueType = rs.getString(11);
/* 198 */           boolean allowOverride = rs.getBoolean(12);
/* 199 */           ScriptParamInfo paramInfo = new ScriptParamInfo(varName, inOutType, varBindingValue, varBindingType, accessFlag, litValueType, allowOverride);
/*     */ 
/* 201 */           info.addScriptParam(paramInfo);




/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 216 */       if (s != null)
/*     */       {
/*     */         try
/*     */         {
/* 220 */           s.close();
/*     */         }
/*     */         catch (SQLException sqe)
/*     */         {
/* 224 */           SCRIPTLOGGER.error(sqe.getMessage(), sqe);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 229 */       if (systemUserInfo != null)
/*     */       {
/*     */         try
/*     */         {
/* 233 */           MXServer.getMXServer().getDBManager().freeConnection(systemUserInfo.getConnectionKey());

/*     */         }
/*     */         catch (RemoteException re)
/*     */         {
/* 238 */           SCRIPTLOGGER.error(re.getMessage(), re);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 244 */     loadScriptLaunchPoint();
/*     */   }

/*     */   public void loadScriptLaunchPoint() throws MXException
/*     */   {
/* 249 */     Statement s = null;
/* 250 */     UserInfo systemUserInfo = null;
/*     */     try
/*     */     {
/* 253 */       SecurityService secServ = (SecurityService)MXServer.getMXServer().lookup("SECURITY");
/* 254 */       systemUserInfo = secServ.getSystemUserInfo();
/* 255 */       Connection connection = MXServer.getMXServer().getDBManager().getConnection(systemUserInfo.getConnectionKey());
/*     */ 
/* 257 */       s = connection.createStatement();
/*     */ 
/* 259 */       s.execute("select ascr.launchpointname, ascr.autoscript, ascr.objectname, ascr.objectevent, ascr.attributename, ascr.condition, ascr.launchpointtype, ascrv.varname, ascrv.varbindingvalue, ascr.active from scriptlaunchpoint ascr left outer join launchpointvars ascrv on ascr.autoscript=ascrv.autoscript and ascr.launchpointname=ascrv.launchpointname order by ascr.autoscript,ascr.launchpointname");





/*     */ 
/* 266 */       ResultSet rs = s.getResultSet();
/* 267 */       Set corruptLPScript = new HashSet();
/* 268 */       Set corruptLPName = new HashSet();
/* 269 */       while (rs.next())
/*     */       {
/* 271 */         String launchPointName = rs.getString(1);
/* 272 */         String scriptName = rs.getString(2);
/* 273 */         if (corruptLPName.contains(launchPointName))
/*     */         {
/* 275 */           SCRIPTLOGGER.error("Skipping corrupt Launch point " + launchPointName + " for script name " + scriptName);


/*     */         }
/*     */ 
/* 280 */         if ((scriptName != null) && (scriptName.equals(corruptLPScript)))
/*     */         {
/* 282 */           SCRIPTLOGGER.error("Skipping Launch point " + launchPointName + " for invalid script name " + scriptName);

/*     */         }
/*     */ 
/* 286 */         String mboName = rs.getString(3);
/* 287 */         long mboEvent = rs.getLong(4);
/* 288 */         String attributeName = rs.getString(5);
/* 289 */         String expression = rs.getString(6);
/* 290 */         String type = rs.getString(7);
/* 291 */         int active = rs.getInt(10);
/* 292 */         boolean isActive = active == 1;
/* 293 */         ScriptInfo info = (ScriptInfo)this.scriptMap.get(scriptName);
/* 294 */         if (info == null)



/*     */         {
/* 299 */           corruptLPScript.add(scriptName);
/* 300 */           SCRIPTLOGGER.error("Skipping Launch point " + launchPointName + " for invalid script name " + scriptName);
/*     */         }
/*     */ 
/* 303 */         ScriptLaunchPointInfo launchPointInfo = (ScriptLaunchPointInfo)info.getLaunchPoints().get(launchPointName);
/* 304 */         if (launchPointInfo == null)
/*     */         {
/* 306 */           Map scriptParams = info.getScriptParams();
/* 307 */           Map launchPointScriptParams = new HashMap(scriptParams);
/*     */ 
/* 309 */           launchPointInfo = new ScriptLaunchPointInfo(launchPointName, type, mboName, mboEvent, attributeName, expression, isActive, launchPointScriptParams);
/*     */ 
/* 311 */           info.addLaunchPoint(launchPointInfo);
/* 312 */           if (isActive)
/*     */           {
/*     */             try
/*     */             {
/* 316 */               this.manager.registerScriptAsListener(scriptName, launchPointInfo);
/*     */             }
/*     */             catch (MXException me)
/*     */             {
/* 320 */               SCRIPTLOGGER.error("Error registering event for Launch point " + launchPointName + " for script " + scriptName + " - skipping");
/* 321 */               corruptLPName.add(launchPointName);

/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 327 */           SCRIPTLOGGER.info("Not registering event listener for inactive Launch point " + launchPointName + " for script " + scriptName);
/*     */         }
/*     */ 
/* 330 */         Map launchPointScriptParams = launchPointInfo.getScriptParams();
/* 331 */         if ((launchPointScriptParams != null) && (launchPointScriptParams.size() > 0))
/*     */         {
/* 333 */           String varName = rs.getString(8);
/*     */ 
/* 335 */           if (varName != null)
/*     */           {
/* 337 */             ScriptParamInfo paramInfo = (ScriptParamInfo)launchPointScriptParams.get(varName);
/* 338 */             String varBindingValue = rs.getString(9);
/* 339 */             ScriptLaunchPointParamInfo launchPointParamInfo = new ScriptLaunchPointParamInfo(paramInfo.getName(), paramInfo.getInoutType(), varBindingValue, paramInfo.getVarBindingType(), paramInfo.getAccessFlag(), paramInfo.getLiteralValueType(), true);

/*     */ 
/* 342 */             launchPointScriptParams.put(paramInfo.getName(), launchPointParamInfo);



/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 358 */       if (s != null)
/*     */       {
/*     */         try
/*     */         {
/* 362 */           s.close();
/*     */         }
/*     */         catch (SQLException sqe)
/*     */         {
/* 366 */           SCRIPTLOGGER.error(sqe.getMessage(), sqe);
/*     */         }
/*     */       }
/* 369 */       if (systemUserInfo != null)
/*     */       {
/*     */         try
/*     */         {
/* 373 */           MXServer.getMXServer().getDBManager().freeConnection(systemUserInfo.getConnectionKey());
/*     */         }
/*     */         catch (RemoteException re)
/*     */         {
/* 377 */           SCRIPTLOGGER.error(re.getMessage(), re);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  58 */       scriptCache = new ScriptCache();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  62 */       SCRIPTLOGGER.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }
