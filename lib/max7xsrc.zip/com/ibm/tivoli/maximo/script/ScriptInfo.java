/*     */ package com.ibm.tivoli.maximo.script;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
























/*     */ public class ScriptInfo
/*     */   implements Serializable
/*     */ {
/*     */   private String name;
/*  30 */   private Map<String, ScriptParamInfo> scriptParams = new HashMap();
/*     */   private String scriptLanguge;
/*  33 */   private Map<String, ScriptLaunchPointInfo> launchPointMap = new HashMap();
/*     */ 
/*  35 */   private String logLevel = null;
/*     */   private String scriptSource;
/*  39 */   private byte[] scriptBinarySource = null;
/*     */ 
/*     */   public ScriptInfo(String name, String scriptLanguge, String scriptSource, byte[] scriptBinarySource, String logLevel)
/*     */   {
/*  45 */     this.name = name;
/*  46 */     this.scriptLanguge = scriptLanguge;
/*  47 */     this.scriptSource = scriptSource;
/*  48 */     this.scriptBinarySource = scriptBinarySource;
/*  49 */     this.logLevel = logLevel;
/*     */   }

/*     */   void addScriptParam(ScriptParamInfo paramInfo)
/*     */   {
/*  54 */     this.scriptParams.put(paramInfo.getName(), paramInfo);
/*     */   }

/*     */   void addLaunchPoint(ScriptLaunchPointInfo launchPointInfo)
/*     */   {
/*  59 */     this.launchPointMap.put(launchPointInfo.getName(), launchPointInfo);
/*     */   }


/*     */   Map<String, ScriptLaunchPointInfo> getLaunchPoints()
/*     */   {
/*  65 */     return this.launchPointMap;
/*     */   }

/*     */   public ScriptLaunchPointInfo getLaunchPoint(String launchPointName)
/*     */   {
/*  70 */     return ((ScriptLaunchPointInfo)this.launchPointMap.get(launchPointName));
/*     */   }


/*     */   public String getLogLevel()
/*     */   {
/*  76 */     return this.logLevel;
/*     */   }

/*     */   public boolean isLogLevelDebug()
/*     */   {
/*  81 */     return this.logLevel.equals("DEBUG");
/*     */   }

/*     */   public boolean isLogLevelInfo()
/*     */   {
/*  86 */     return this.logLevel.equals("INFO");
/*     */   }




/*     */   public String getName()
/*     */   {
/*  94 */     return this.name;
/*     */   }




/*     */   public Map<String, ScriptParamInfo> getScriptParams()
/*     */   {
/* 102 */     return this.scriptParams;
/*     */   }




/*     */   public String getScriptLanguge()
/*     */   {
/* 110 */     return this.scriptLanguge;
/*     */   }




/*     */   public String getScriptSource()
/*     */   {
/* 118 */     return this.scriptSource;
/*     */   }




/*     */   public byte[] getScriptBinarySource()
/*     */   {
/* 126 */     return this.scriptBinarySource;
/*     */   }
/*     */ }
