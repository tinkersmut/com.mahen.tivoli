/*     */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.asset.ilog.applet.ILogApplet;
/*     */ import ilog.views.IlvGraphic;
/*     */ import ilog.views.diagrammer.IlvDiagrammer;
/*     */ import ilog.views.sdm.IlvSDMEngine;
/*     */ import ilog.views.swing.IlvPopupMenuContext;
/*     */ import ilog.views.swing.IlvPopupMenuManager;
/*     */ import ilog.views.swing.IlvSimplePopupMenu;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPopupMenu;
/*     */ 




















/*     */ public abstract class DiagrammerApplet extends ILogApplet
/*     */ {
/*     */   private void registerPopupInView(IlvDiagrammer diagrammer)
/*     */   {
/*  43 */     IlvPopupMenuManager.registerView(diagrammer.getView());
/*     */   }

/*     */   protected void initPopupMenus(IlvDiagrammer diagrammer, LinkedHashMap<String, ActionReference> nodeActionRefs, Action[] linkActions) {
/*  47 */     registerPopupInView(diagrammer);
/*     */ 
/*  49 */     if ((nodeActionRefs != null) && (nodeActionRefs.size() > 0))
/*     */     {
/*  51 */       JPopupMenu nodeMenu = createNodeLinkPopupMenu(diagrammer, true, nodeActionRefs);







/*     */ 
/*  60 */       IlvPopupMenuManager.registerMenu("NodePopupMenu", nodeMenu);
/*     */     }
/*     */ 
/*  63 */     if ((linkActions == null) || (linkActions.length <= 0)) {
/*     */       return;
/*     */     }
/*  66 */     JPopupMenu linkMenu = createNodeLinkPopupMenu(diagrammer, false, linkActions);







/*     */ 
/*  75 */     IlvPopupMenuManager.registerMenu("LinkPopupMenu", linkMenu);
/*     */   }

/*     */   protected void initPopupMenus(IlvDiagrammer diagrammer, Action[] nodeActions, Action[] linkActions)
/*     */   {
/*  80 */     registerPopupInView(diagrammer);
/*     */ 
/*  82 */     if ((nodeActions != null) && (nodeActions.length > 0))
/*     */     {
/*  84 */       JPopupMenu nodeMenu = createNodeLinkPopupMenu(diagrammer, true, nodeActions);







/*     */ 
/*  93 */       IlvPopupMenuManager.registerMenu("NodePopupMenu", nodeMenu);
/*     */     }
/*     */ 
/*  96 */     if ((linkActions != null) && (linkActions.length > 0))

/*     */     {
/*  99 */       JPopupMenu linkMenu = createNodeLinkPopupMenu(diagrammer, false, linkActions);







/*     */ 
/* 108 */       IlvPopupMenuManager.registerMenu("LinkPopupMenu", linkMenu);

/*     */     }
/*     */ 
/* 112 */     JPopupMenu testmenu = new IlvSimplePopupMenu();
/* 113 */     testmenu.add(new JMenuItem("1-week order, demo only"));
/* 114 */     testmenu.add(new JMenuItem("2-week order, demo only"));
/* 115 */     testmenu.add(new JMenuItem("3-week order, demo only"));
/* 116 */     IlvPopupMenuManager.registerMenu("ScheduledTasksNodePopupMenu", testmenu);
/*     */   }









/*     */   private JPopupMenu createNodeLinkPopupMenu(IlvDiagrammer diagrammer, boolean isNode, LinkedHashMap<String, ActionReference> nodeActionRefs)
/*     */   {
/* 129 */     NodeLinkPopupMenu popupMenu = new NodeLinkPopupMenu(diagrammer, isNode);

/*     */ 
/* 132 */     popupMenu.addActions(nodeActionRefs);

/*     */ 
/* 135 */     popupMenu.applyComponentOrientation(diagrammer.getComponentOrientation());

/*     */ 
/* 138 */     return popupMenu;
/*     */   }

/*     */   private JPopupMenu createNodeLinkPopupMenu(IlvDiagrammer diagrammer, boolean isNode, Action[] actions) {
/* 142 */     IlvSimplePopupMenu popupMenu = new NodeLinkPopupMenu(diagrammer, isNode);

/*     */ 
/* 145 */     popupMenu.addActions(actions);

/*     */ 
/* 148 */     popupMenu.applyComponentOrientation(diagrammer.getComponentOrientation());

/*     */ 
/* 151 */     return popupMenu;
/*     */   }





/*     */   private void beforeNodeLinkPopupDisplay(IlvSimplePopupMenu popupMenu, IlvPopupMenuContext context, IlvDiagrammer diagrammer, boolean isNode)
/*     */   {
/* 160 */     diagrammer.deselectAll();
/*     */ 
/* 162 */     IlvGraphic g = context.getGraphic();
/*     */ 
/* 164 */     Object obj = (g == null) ? null : diagrammer.getEngine().getObject(g);
/*     */ 
/* 166 */     if (obj != null)
/* 167 */       diagrammer.setSelected(obj, true);
/*     */   }

















































/*     */   class NodeLinkPopupMenu extends IlvSimplePopupMenu
/*     */   {
/*     */     private IlvDiagrammer diagrammer;
/*     */     private boolean isNode;
/*     */ 
/*     */     public NodeLinkPopupMenu(IlvDiagrammer paramIlvDiagrammer, boolean paramBoolean)
/*     */     {
/* 225 */       this.diagrammer = paramIlvDiagrammer;
/* 226 */       this.isNode = isNode;

/*     */ 
/* 229 */       applyComponentOrientation(paramIlvDiagrammer.getComponentOrientation());
/*     */     }




/*     */     protected void beforeDisplay(IlvPopupMenuContext context)
/*     */     {
/* 237 */       super.beforeDisplay(context);
/*     */ 
/* 239 */       DiagrammerApplet.this.beforeNodeLinkPopupDisplay(this, context, this.diagrammer, this.isNode);
/*     */     }



/*     */     public void addActions(LinkedHashMap<String, ActionReference> nodeActionRefs)
/*     */     {
/* 246 */       Map.Entry entry = null;
/* 247 */       Iterator itr = nodeActionRefs.entrySet().iterator();
/* 248 */       while (itr.hasNext()) {
/* 249 */         entry = (Map.Entry)itr.next();
/*     */ 
/* 251 */         String parentKey = ((ActionReference)entry.getValue()).getParentKey();
/* 252 */         Action action = ((ActionReference)entry.getValue()).getAction();
/* 253 */         ActionType actionType = ((ActionReference)entry.getValue()).getActionType();

/*     */ 
/* 256 */         if (actionType == ActionType.JSEPARATOR) {
/* 257 */           addSeparator();


/*     */         }
/*     */ 
/* 262 */         if (actionType == ActionType.JMENU) {
/* 263 */           JMenu jmenu = new JMenu((String)action.getValue("Name"));
/* 264 */           action.putValue("assetTopoJMenuKey", jmenu);
/* 265 */           add(jmenu);


/*     */         }
/*     */ 
/* 270 */         if (actionType == ActionType.JMENUITEM) {
/* 271 */           JMenuItem jmenuitem = new JMenuItem(action);
/* 272 */           if (parentKey == null) {
/* 273 */             add(jmenuitem);


/*     */           }
/*     */ 
/* 278 */           JMenu parentJMenu = (JMenu)((ActionReference)nodeActionRefs.get(parentKey)).getAction().getValue("assetTopoJMenuKey");
/* 279 */           parentJMenu.add(jmenuitem);
/* 280 */           jmenuitem.putClientProperty("assetTopoParentJMenuItem", parentJMenu);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }
