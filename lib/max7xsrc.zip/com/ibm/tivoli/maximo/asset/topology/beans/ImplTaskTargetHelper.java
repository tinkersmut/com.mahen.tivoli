/*    */ package com.ibm.tivoli.maximo.asset.topology.beans;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 


















/*    */ public class ImplTaskTargetHelper
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String taskWonum;
/*    */   private String taskID;
/*    */   private String description;
/* 30 */   private List<TargetHelper> taskTargetsList = new ArrayList();
/* 31 */   private List<TargetHelper> taskTargetsImpactedList = new ArrayList();
/*    */ 
/*    */   public ImplTaskTargetHelper()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ImplTaskTargetHelper(String taskWonum, String taskID, String description)
/*    */   {
/* 41 */     this.taskWonum = taskWonum;
/* 42 */     this.taskID = taskID;
/* 43 */     this.description = description;
/*    */   }

/*    */   public String getTaskWonum() {
/* 47 */     return this.taskWonum; }

/*    */   public void setTaskWonum(String taskWonum) {
/* 50 */     this.taskWonum = taskWonum; }

/*    */   public String getTaskID() {
/* 53 */     return this.taskID; }

/*    */   public void setTaskID(String taskID) {
/* 56 */     this.taskID = taskID; }

/*    */   public String getDescription() {
/* 59 */     return this.description; }

/*    */   public void setDescription(String description) {
/* 62 */     this.description = description;
/*    */   }

/*    */   public List<TargetHelper> getTaskTargetsList() {
/* 66 */     return this.taskTargetsList;
/*    */   }

/*    */   public void setTaskTargetsList(List<TargetHelper> taskTargetsList) {
/* 70 */     this.taskTargetsList = taskTargetsList;
/*    */   }

/*    */   public List<TargetHelper> getTaskTargetsImpactedList() {
/* 74 */     return this.taskTargetsImpactedList;
/*    */   }

/*    */   public void setTaskTargetsImpactedList(List<TargetHelper> taskTargetsImpactedList)
/*    */   {
/* 79 */     this.taskTargetsImpactedList = taskTargetsImpactedList;
/*    */   }
/*    */ }
