/*    */ package com.ibm.tivoli.maximo.asset.topology.renderer;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JList;
/*    */ import javax.swing.ListCellRenderer;
/*    */ 















/*    */ public class TaskCellRenderer extends JLabel
/*    */   implements ListCellRenderer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 28 */   private final Color HIGHLIGHT_COLOR = new Color(0, 0, 128);
/*    */ 
/*    */   public TaskCellRenderer() {
/* 31 */     setOpaque(true);
/*    */   }



/*    */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*    */   {
/* 38 */     setText((value == null) ? "" : value.toString());

/*    */ 
/* 41 */     if (isSelected) {
/* 42 */       setBackground(this.HIGHLIGHT_COLOR);
/* 43 */       setForeground(Color.white);
/*    */     } else {
/* 45 */       setBackground(Color.white);
/* 46 */       setForeground(Color.black);
/*    */     }
/* 48 */     return this;
/*    */   }
/*    */ }
