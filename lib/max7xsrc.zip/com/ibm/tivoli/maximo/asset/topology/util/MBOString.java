/*    */ package com.ibm.tivoli.maximo.asset.topology.util;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.MXFormat;
/*    */ 
































/*    */ public class MBOString
/*    */ {
/*    */   public static String getString(MboRemote mbo, String mboattr, int datatype)
/*    */     throws RemoteException, MXException
/*    */   {
/* 45 */     if ((datatype == 0) || (datatype == 1) || (datatype == 2) || (datatype == 14) || (datatype == 13))



/*    */     {
/* 50 */       return mbo.getString(mboattr);

/*    */     }
/*    */ 
/* 54 */     if (datatype == 19) {
/* 55 */       return MXFormat.longToString(mbo.getLong(mboattr));

/*    */     }
/*    */ 
/* 59 */     if ((datatype == 7) || (datatype == 6))
/*    */     {
/* 61 */       return MXFormat.intToString(mbo.getInt(mboattr));

/*    */     }
/*    */ 
/* 65 */     if ((datatype == 11) || (datatype == 8) || (datatype == 9))
/*    */     {
/* 67 */       return MXFormat.doubleToString(mbo.getDouble(mboattr));

/*    */     }
/*    */ 
/* 71 */     if (datatype == 3) {
/* 72 */       return MXFormat.dateToString(mbo.getDate(mboattr));

/*    */     }
/*    */ 
/* 76 */     if (datatype == 5) {
/* 77 */       return MXFormat.timeToString(mbo.getDate(mboattr));

/*    */     }
/*    */ 
/* 81 */     if (datatype == 4) {
/* 82 */       return MXFormat.dateTimeToString(mbo.getDate(mboattr));

/*    */     }
/*    */ 
/* 86 */     if (datatype == 12) {
/* 87 */       return MXFormat.booleanToString(mbo.getBoolean(mboattr));

/*    */     }
/*    */ 
/* 91 */     return "N/A";
/*    */   }
/*    */ }
