/*    */ package com.ibm.tivoli.maximo.asset.topology.controls;
/*    */ 























/*    */ public class NodeStat
/*    */ {
/* 26 */   private int degree = -1;
/*    */ 
/* 28 */   private boolean degreeIsSetExternally = false;
/* 29 */   private int constructedDegree = 0;
/*    */ 
/*    */   public int getDegree()
/*    */   {
/* 35 */     return this.degree;
/*    */   }

/*    */   protected void setDegree(int degree) {
/* 39 */     this.degree = degree;
/* 40 */     this.degreeIsSetExternally = true;
/*    */   }

/*    */   public void constructOneDegree() {
/* 44 */     this.constructedDegree += 1;
/*    */   }

/*    */   public boolean isDegreeFullyConstructed() {
/* 48 */     return ((this.degreeIsSetExternally) && (this.constructedDegree >= this.degree));
/*    */   }

/*    */   public String toString()
/*    */   {
/* 53 */     return "degree=[" + this.degree + "], constructedDegree=[" + this.constructedDegree + "]";
/*    */   }
/*    */ }
