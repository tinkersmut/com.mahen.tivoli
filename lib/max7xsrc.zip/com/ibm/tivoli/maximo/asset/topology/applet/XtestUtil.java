/*    */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.BufferedOutputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.InputStream;/*    */ import java.io.OutputStream;/*    */ import java.io.PrintStream;/*    */ 
/*    */ public class XtestUtil
/*    */ {
/*    */   public static void dumpInputStream(InputStream src)
/*    */     throws Exception
/*    */   {
/* 12 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 13 */     copyStream(src, baos);
/* 14 */     System.out.println(baos.toString());
/* 15 */     baos.close();
/*    */   }

/*    */   public static void copyStream(InputStream src, OutputStream dest) throws Exception {
/* 19 */     int bufferSize = 8096;
/* 20 */     src = new BufferedInputStream(src, bufferSize);
/* 21 */     dest = new BufferedOutputStream(dest, bufferSize);
/* 22 */     byte[] buffer = new byte[bufferSize];
/*    */ 
/* 24 */     while ((count = src.read(buffer, 0, bufferSize)) != -1)
/*    */     {/*    */       int count;/* 25 */       dest.write(buffer, 0, count);
/*    */     }
/* 27 */     dest.flush();
/*    */   }
/*    */ }
