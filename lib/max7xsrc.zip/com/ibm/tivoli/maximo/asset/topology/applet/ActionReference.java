/*    */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.swing.Action;
/*    */ 























/*    */ public class ActionReference
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 680717937086173392L;
/*    */   public static final String JMENU_KEY = "assetTopoJMenuKey";
/*    */   public static final String PARENT_JMENUITEM = "assetTopoParentJMenuItem";
/* 35 */   private String parentKey = null;
/*    */ 
/* 37 */   private ActionType actionType = null;
/*    */ 
/* 39 */   private Action action = null;
/*    */ 
/*    */   public ActionReference(ActionType actionType, String parentKey, Action action) {
/* 42 */     this.actionType = actionType;
/* 43 */     this.parentKey = parentKey;
/* 44 */     this.action = action;
/*    */   }

/*    */   public String getParentKey() {
/* 48 */     return this.parentKey;
/*    */   }

/*    */   public ActionType getActionType() {
/* 52 */     return this.actionType;
/*    */   }

/*    */   public Action getAction() {
/* 56 */     return this.action;
/*    */   }
/*    */ }
