/*    */ package com.ibm.tivoli.maximo.asset.topology.beans;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
















/*    */ public class TargetHelper
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String cinum;
/*    */   private String description;
/*    */ 
/*    */   public TargetHelper(String cinum, String description)
/*    */   {
/* 30 */     this.cinum = cinum;
/* 31 */     this.description = description; }

/*    */   public String getCinum() {
/* 34 */     return this.cinum; }

/*    */   public void setCinum(String cinum) {
/* 37 */     this.cinum = cinum; }

/*    */   public String getDescription() {
/* 40 */     return this.description; }

/*    */   public void setDescription(String description) {
/* 43 */     this.description = description; }

/*    */   public boolean equals(Object o) {
/* 46 */     if (this == o) return true;
/* 47 */     if (!(o instanceof TargetHelper)) return false;
/*    */ 
/* 49 */     TargetHelper h = (TargetHelper)o;
/* 50 */     return h.cinum.equals(this.cinum);
/*    */   }

/*    */   public int hashCode() {
/* 54 */     return this.cinum.hashCode();
/*    */   }
/*    */ }
