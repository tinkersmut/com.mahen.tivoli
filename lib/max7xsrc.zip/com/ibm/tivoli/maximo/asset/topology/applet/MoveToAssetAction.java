/*    */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.asset.ilog.applet.ILogApplet;
/*    */ import ilog.views.IlvGraphic;
/*    */ import ilog.views.diagrammer.IlvDiagrammer;
/*    */ import ilog.views.sdm.IlvSDMEngine;
/*    */ import ilog.views.swing.IlvPopupMenuContext;
/*    */ import ilog.views.swing.IlvPopupMenuManager;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.util.Hashtable;
/*    */ import java.util.ResourceBundle;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JMenuItem;
/*    */ 
















/*    */ public class MoveToAssetAction extends AbstractAction
/*    */ {
/*    */   private static final long serialVersionUID = 5134691168053021273L;
/*    */   private IlvDiagrammer diagrammer;
/*    */   private ILogApplet applet;
/*    */   private String target;
/*    */ 
/*    */   public MoveToAssetAction(IlvDiagrammer diagrammer, ILogApplet applet, String target, ResourceBundle bundle)
/*    */   {
/* 42 */     super(bundle.getString("Topology.Label.MoveToAsset.Name"));
/* 43 */     this.diagrammer = diagrammer;
/* 44 */     this.applet = applet;
/* 45 */     this.target = target;
/*    */   }

/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/* 50 */     JMenuItem m = (JMenuItem)e.getSource();

/*    */ 
/* 53 */     IlvPopupMenuContext context = IlvPopupMenuManager.getPopupMenuContext(m);
/* 54 */     if (context == null) return;
/*    */ 
/* 56 */     IlvGraphic g = context.getGraphic();
/*    */ 
/* 58 */     Object obj = (g == null) ? null : this.diagrammer.getEngine().getObject(g);
/* 59 */     if (obj == null) return;
/*    */ 
/* 61 */     String assetnum = (String)this.diagrammer.getObjectProperty(obj, "assetnum");
/*    */     try {
/* 63 */       assetnum = URLEncoder.encode(assetnum, "UTF-8");
/*    */     }
/*    */     catch (UnsupportedEncodingException e1) {
/*    */     }
/* 67 */     Hashtable args = new Hashtable();
/* 68 */     args.put("assetnum", assetnum);
/* 69 */     ((TopologyApplet)this.applet).acceptMovedToAssetNum(assetnum);
/* 70 */     this.applet.sendEvent("MoveTo", this.target, args);
/*    */   }
/*    */ }
