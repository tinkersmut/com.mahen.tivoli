/*     */ package com.ibm.tivoli.maximo.asset.topology.beans;
/*     */ 
/*     */ import java.net.URLDecoder;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.util.BidiUtils;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 




































/*     */ public class AssetDetailsBean extends DataBean
/*     */ {
/*  33 */   private static final Class CLASS = AssetDetailsBean.class;
/*     */ 
/*  35 */   private static Map<String, String> allActionsDialogIds = new HashMap();
/*     */ 
/*     */   public int OnAllAssetDetails()
/*     */   {
/*     */     try
/*     */     {
/*  62 */       String targetId = this.clientSession.getRequest().getParameter("targetid");
/*  63 */       String assetnum = this.clientSession.getRequest().getParameter("assetnum");
/*  64 */       String actionkey = this.clientSession.getRequest().getParameter("actionkey");
/*     */ 
/*  66 */       if ((assetnum != null) && (!("".equals(assetnum)))) {
/*  67 */         assetnum = URLDecoder.decode(WebClientRuntime.decodeSafevalue(assetnum), "UTF-8");
/*  68 */         if (BidiUtils.isBidiEnabled()) {
/*  69 */           assetnum = BidiUtils.removeMarkers(assetnum);
/*     */         }
/*  71 */         MboSetRemote mboSet = getMboSet();
/*     */ 
/*  73 */         SqlFormat sqf = new SqlFormat(getMXSession().getUserInfo(), "assetnum = :1");
/*  74 */         sqf.setObject(1, "ASSET", "ASSETNUM", assetnum);
/*  75 */         String whereClause = sqf.format();
/*  76 */         mboSet.setWhere(whereClause);
/*  77 */         mboSet.reset();
/*  78 */         setCurrentRow(0);
/*  79 */         refreshTable();



/*     */ 
/*  84 */         WebClientEvent wce = new WebClientEvent((String)allActionsDialogIds.get(actionkey), targetId, "", this.clientSession);
/*  85 */         wce.addParameter("assetnum", assetnum);
/*  86 */         WebClientRuntime.sendEvent(wce);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  91 */       ex.printStackTrace();
/*     */     }
/*     */ 
/*  94 */     return 1;
/*     */   }

/*     */   public int markciimpacted()
/*     */   {
/*     */     try
/*     */     {
/* 101 */       String targetId = this.clientSession.getRequest().getParameter("targetid");
/* 102 */       String cinum = URLDecoder.decode(this.clientSession.getRequest().getParameter("cinum"), "UTF-8");
/*     */ 
/* 104 */       MboSetRemote mboSet = getMboSet();
/*     */ 
/* 106 */       SqlFormat sqf = new SqlFormat(getMXSession().getUserInfo(), "cinum = :1");
/* 107 */       sqf.setObject(1, "CI", "CINUM", cinum);
/* 108 */       String whereClause = sqf.format();
/* 109 */       mboSet.setWhere(whereClause);
/* 110 */       mboSet.reset();
/* 111 */       setCurrentRow(0);
/* 112 */       refreshTable();
/*     */ 
/* 114 */       WebClientRuntime.sendEvent(this.clientSession, targetId, "pmchgmarkciimpacted", "");
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 118 */       ex.printStackTrace();
/*     */     }
/*     */ 
/* 121 */     return 1;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  39 */     allActionsDialogIds.put("SELECTVALUE", "selectvalue");
/*     */ 
/*  41 */     allActionsDialogIds.put("DETAILS", "relationships_astdetails");
/*  42 */     allActionsDialogIds.put("REPORTDOWNTIME", "REPDOWN");
/*  43 */     allActionsDialogIds.put("MANAGEDOWNTIMEHISTORY", "mandwntime");
/*     */ 
/*  45 */     allActionsDialogIds.put("WORKDETAILS", "relationships_WOPMS_BYASSET");
/*  46 */     allActionsDialogIds.put("VIEWCONTRACTS", "relationships_VIEWCNTAST");
/*  47 */     allActionsDialogIds.put("VIEWTICKETS", "viewtkt");
/*  48 */     allActionsDialogIds.put("MOVEHISTORY", "asmovehist");
/*  49 */     allActionsDialogIds.put("SPECHISTORY", "VIEWASHIS");
/*  50 */     allActionsDialogIds.put("RELATIONSHIPHISTORY", "VIEWARHIST");
/*     */ 
/*  52 */     allActionsDialogIds.put("SERVICEREQUEST", "createsr");
/*  53 */     allActionsDialogIds.put("INCIDENT", "CREATEINC");
/*  54 */     allActionsDialogIds.put("PROBLEM", "CREATEPROB");
/*  55 */     allActionsDialogIds.put("WORKORDER", "CREATEWO");
/*  56 */     allActionsDialogIds.put("CHANGE", "CREATECHNG");
/*  57 */     allActionsDialogIds.put("RELEASE", "CREATEREL");
/*     */   }
/*     */ }
