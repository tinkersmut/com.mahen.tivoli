/*     */ package com.ibm.tivoli.maximo.asset.topology.controls;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import psdi.app.workorder.WORemote;
/*     */ import psdi.app.workorder.WOSet;
/*     */ import psdi.util.MXException;
/*     */ 





















/*     */ public class TaskIndicator
/*     */ {
/*  31 */   public static final TaskIndicator NULL_WORK = new TaskIndicator(-1);
/*     */ 
/*  33 */   public static final TaskIndicator SCHEDLED_WORK_PASTDUE = new TaskIndicator(0);
/*     */ 
/*  35 */   public static final TaskIndicator SCHEDLED_WORK_IN_1ST_WEEK = new TaskIndicator(1);
/*  36 */   public static final TaskIndicator SCHEDLED_WORK_IN_2ND_WEEK = new TaskIndicator(2);
/*  37 */   public static final TaskIndicator SCHEDLED_WORK_IN_3RD_WEEK = new TaskIndicator(3);
/*  38 */   public static final TaskIndicator SCHEDLED_WORK_IN_4WEEKS_PLUS = new TaskIndicator(4);
/*     */ 
/*  40 */   public static final TaskIndicator NO_SCHEDLED_WORK_YET = new TaskIndicator(39393);
/*     */   private static final long ONEDAY_MILLIS = 86400000L;
/*     */   private static final long ONE_WEEK_MILLIS = 604800000L;
/*     */   private static final long TWO_WEEK_MILLIS = 1209600000L;
/*     */   private static final long THREE_WEEK_MILLIS = 1814400000L;
/*     */   private int indicator;
/*     */ 
/*     */   private TaskIndicator(int indicator)
/*     */   {
/*  50 */     this.indicator = indicator;
/*     */   }

/*     */   private boolean isEarlierThan(TaskIndicator taskIndicator) {
/*  54 */     return (this.indicator < taskIndicator.getIndicator());
/*     */   }




/*     */   public int getIndicator()
/*     */   {
/*  62 */     return this.indicator;
/*     */   }










/*     */   public static TaskIndicator resolveTaskIndicator(WOSet wos)
/*     */     throws RemoteException, MXException
/*     */   {
/*  77 */     if ((wos == null) || (wos.count() == 0)) {
/*  78 */       return NULL_WORK;



/*     */     }
/*     */ 
/*  84 */     long current = System.currentTimeMillis();
/*  85 */     TaskIndicator notScheduledYet = null;
/*  86 */     TaskIndicator pastDue = null;
/*  87 */     TaskIndicator inWeeks = null;
/*  88 */     WORemote wo = null;
/*  89 */     int j = 0;
/*  90 */     while ((wo = (WORemote)wos.getMbo(j)) != null) {
/*     */       try {
/*  92 */         Date schedStart = wo.getDate("SCHEDSTART");
/*  93 */         if (schedStart == null) {
/*  94 */           notScheduledYet = NO_SCHEDLED_WORK_YET;

/*     */         }
/*  97 */         long scheduled = schedStart.getTime();
/*  98 */         if (scheduled < current) {
/*  99 */           pastDue = SCHEDLED_WORK_PASTDUE;


/*     */         }
/* 103 */         TaskIndicator nextInweeks = matchWIForWeeksSchedStart(scheduled, current);
/* 104 */         if (inWeeks == null) {
/* 105 */           inWeeks = nextInweeks;

/*     */         }
/* 108 */         if (nextInweeks.isEarlierThan(inWeeks))
/* 109 */           inWeeks = nextInweeks;


/*     */ 
/*     */       }/*     */       finally/*     */       {/*     */ /*     */ /* 113 */           ++j;/* 113 */           ++j;/* 113 */           ++j;/* 113 */         ++j;


/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 120 */     if (inWeeks != null) {
/* 121 */       return inWeeks;
/*     */     }
/* 123 */     if (pastDue != null) {
/* 124 */       return pastDue;
/*     */     }
/* 126 */     if (notScheduledYet != null) {
/* 127 */       return notScheduledYet;

/*     */     }
/*     */ 
/* 131 */     throw new RemoteException("No SCHEDSTART for asset [" + wo.getString("ASSETNUM") + "]");
/*     */   }






/*     */   private static TaskIndicator matchWIForWeeksSchedStart(long scheduled, long current)
/*     */   {
/* 141 */     long delta = scheduled - current;
/* 142 */     if (delta <= 604800000L) {
/* 143 */       return SCHEDLED_WORK_IN_1ST_WEEK;
/*     */     }
/* 145 */     if (delta <= 1209600000L) {
/* 146 */       return SCHEDLED_WORK_IN_2ND_WEEK;
/*     */     }
/* 148 */     if (delta <= 1814400000L) {
/* 149 */       return SCHEDLED_WORK_IN_3RD_WEEK;
/*     */     }
/* 151 */     return SCHEDLED_WORK_IN_4WEEKS_PLUS;
/*     */   }
/*     */ }
