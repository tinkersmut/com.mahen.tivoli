/*      */ package com.ibm.tivoli.maximo.asset.topology.controls;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.asset.topology.constants.StatusConstants;
/*      */ import com.ibm.tivoli.maximo.asset.topology.util.MBOString;
/*      */ import com.ibm.tivoli.maximo.util.StringUtil;
/*      */ import ilog.views.sdm.model.IlvDefaultSDMModel;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.rmi.RemoteException;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TreeSet;
/*      */ import psdi.app.assetcatalog.ClassStructure;
/*      */ import psdi.app.workorder.WOSet;
/*      */ import psdi.mbo.MaximoDD;
/*      */ import psdi.mbo.MboRemote;
/*      */ import psdi.mbo.MboSetInfo;
/*      */ import psdi.mbo.MboSetRemote;
/*      */ import psdi.mbo.MboValueInfo;
/*      */ import psdi.mbo.SqlFormat;
/*      */ import psdi.mbo.Translate;
/*      */ import psdi.security.UserInfo;
/*      */ import psdi.server.MXServer;
/*      */ import psdi.util.BidiUtils;
/*      */ import psdi.util.MXException;
/*      */ import psdi.webclient.system.session.WebClientSession;
/*      */ 














/*      */ public class AssetNodeVisitor
/*      */ {
/*   52 */   private static final Class CLASS = AssetNodeVisitor.class;
/*      */   private IlvDefaultSDMModel model;
/*      */   private int maxNodeDepth;
/*      */   private int maxAssetDepth;
/*      */   private int maxNodes;
/*      */   private ResourceBundle bundle;
/*   60 */   private Stack<AssetNode> assetNodeStack = new Stack();
/*   61 */   private Stack<Object> ilvNodeStack = new Stack();
/*      */ 
/*   64 */   private HashMap<String, NodeStat> accessedAssets = new HashMap();
/*      */ 
/*   66 */   private HashMap<String, AssetClassification> classMap = new HashMap();
/*      */ 
/*   68 */   private TopologyControl topologyControl = null;
/*      */ 
/*   71 */   private Hashtable<String, Boolean> impactedAsset = new Hashtable();
/*      */ 
/*   74 */   private TreeSet<NodeTooltipInfo> configuredNodeTooltipItems = new TreeSet(new NodeTooltipInfoComparator());
/*      */ 
/*   76 */   private String defaultStartMeasureLabel = "";
/*   77 */   private String defaultEndMeasureLabel = "";
/*      */ 
/*   79 */   private static Map<String, Integer> maxtypeOfAssetSpec = Collections.synchronizedMap(new HashMap());
/*   80 */   private static boolean isMaxtypeOfAssetSpecPopulated = false;
/*      */ 
/*   82 */   private static Map<String, String> datatypeOfAssetAttr = Collections.synchronizedMap(new HashMap());
/*      */ 
/*   84 */   private static Object fetchSvrDataLock = new Object();
/*      */ 
/*   86 */   private static Map<String, String> nativeStatusMapper = null;
/*      */ 
/*      */   static class NodeTooltipInfoComparator
/*      */     implements Comparator<AssetNodeVisitor.NodeTooltipInfo>
/*      */   {
/*      */     public int compare(AssetNodeVisitor.NodeTooltipInfo object1, AssetNodeVisitor.NodeTooltipInfo object2)
/*      */     {
/*   91 */       if (object1.getDisplayOrder() > object2.getDisplayOrder()) {
/*   92 */         return 1;
/*      */       }
/*   94 */       if (object1.getDisplayOrder() < object2.getDisplayOrder()) {
/*   95 */         return -1;
/*      */       }
/*   97 */       return 0;
/*      */     }
/*      */   }
/*      */   public Hashtable<String, Boolean> getImpactedAsset()
/*      */   {
/*  102 */     return this.impactedAsset;
/*      */   }

/*      */   public void setImpactedASset(Hashtable<String, Boolean> impactedAsset) {
/*  106 */     this.impactedAsset = impactedAsset;
/*      */   }

/*      */   public AssetNodeVisitor(IlvDefaultSDMModel model, int maxNodeDepth, int maxAssetDepth, int maxNodes, TopologyControl topologyControl) {
/*  110 */     this.model = model;
/*  111 */     this.maxNodeDepth = maxNodeDepth;
/*  112 */     this.maxAssetDepth = maxAssetDepth;
/*  113 */     this.maxNodes = maxNodes;
/*      */ 
/*  115 */     this.topologyControl = topologyControl;
/*      */   }

/*      */   public static synchronized void nativeInit(MboRemote mbo) {
/*  119 */     if ((nativeStatusMapper != null) && (nativeStatusMapper.size() > 0)) {
/*  120 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  124 */       nativeStatusMapper = new HashMap();
/*  125 */       MboSetRemote statusDmSet = MXServer.getMXServer().getMboSet("SYNONYMDOMAIN", mbo.getUserInfo());
/*  126 */       statusDmSet.setQbeExactMatch(true);
/*  127 */       statusDmSet.setQbe("domainid", "LOCASSETSTATUS");
/*      */ 
/*  129 */       MboRemote statusDmMbo = null;
/*  130 */       while ((statusDmMbo = statusDmSet.moveNext()) != null) {
/*  131 */         nativeStatusMapper.put(statusDmMbo.getString("VALUE"), statusDmMbo.getString("MAXVALUE"));
/*      */       }
/*  133 */       statusDmSet.close();
/*      */     }
/*      */     catch (Throwable t) {
/*  136 */       StringUtil.toString(t);
/*      */     }
/*      */   }

/*      */   public boolean atMaxNodeDepth()
/*      */   {
/*  142 */     return (this.ilvNodeStack.size() >= this.maxNodeDepth + 1);
/*      */   }

/*      */   public boolean maxNodesReached()
/*      */   {
/*  147 */     return (this.accessedAssets.size() >= this.maxNodes);
/*      */   }

/*      */   public boolean atMaxAssetDepth()
/*      */   {
/*  152 */     int depthCount = 0;
/*  153 */     int n = this.assetNodeStack.size();
/*  154 */     for (int i = n - 1; i >= 0; --i)
/*      */     {
/*  156 */       AssetNode assetNode = (AssetNode)this.assetNodeStack.get(i);
/*  157 */       if (assetNode.ilvNode != null)
/*      */         break;
/*  159 */       ++depthCount;





/*      */     }
/*      */ 
/*  167 */     return (depthCount >= this.maxAssetDepth);
/*      */   }






/*      */   public boolean notVisited(String assetnum)
/*      */   {
/*  177 */     return (!(this.accessedAssets.keySet().contains(assetnum)));
/*      */   }






/*      */   public boolean proceedDeepForEncounteredNode(String assetnum)
/*      */   {
/*  187 */     if (!(this.accessedAssets.keySet().contains(assetnum))) {
/*  188 */       return true;

/*      */     }
/*      */ 
/*  192 */     for (int i = 0; i < this.ilvNodeStack.size(); ++i) {
/*  193 */       if (getModel().getID(this.ilvNodeStack.get(i)).equals(assetnum)) {
/*  194 */         return false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  199 */     NodeStat ns = resolveNodeStat(assetnum);
/*  200 */     if (!(ns.isDegreeFullyConstructed())) {
/*  201 */       return true;

/*      */     }
/*      */ 
/*  205 */     System.out.println("Proceed Eventaul Decision to false, for [" + assetnum + "], nodestat is [" + resolveNodeStat(assetnum) + "]");
/*  206 */     return false;
/*      */   }

/*      */   public void push(String assetNum, Object ilvNode)
/*      */   {
/*  211 */     push(assetNum, ilvNode, null, null);
/*      */   }

/*      */   public void push(String assetNum, HashSet<String> fromRelations, HashSet<String> toRelations)
/*      */   {
/*  216 */     push(assetNum, null, fromRelations, toRelations);
/*      */   }

/*      */   public void push(String assetNum, Object ilvNode, HashSet<String> inRelations, HashSet<String> outRelations)
/*      */   {
/*  221 */     AssetNode assetNode = new AssetNode();
/*  222 */     assetNode.assetNum = assetNum;
/*  223 */     assetNode.ilvNode = ilvNode;
/*  224 */     assetNode.inRelations = inRelations;
/*  225 */     assetNode.outRelations = outRelations;
/*  226 */     this.assetNodeStack.push(assetNode);
/*  227 */     if (ilvNode == null)
/*      */       return;
/*  229 */     this.ilvNodeStack.push(ilvNode);
/*      */   }


/*      */   public void pop()
/*      */   {
/*  235 */     AssetNode assetNode = (AssetNode)this.assetNodeStack.pop();
/*  236 */     if (assetNode.ilvNode == null)
/*      */       return;
/*  238 */     this.ilvNodeStack.pop();
/*      */   }

/*      */   public Object generateIlvNode(MboRemote assetMbo, String tag) throws MXException, RemoteException
/*      */   {
/*  243 */     String ilvNodeID = assetMbo.getString("ASSETNUM");
/*  244 */     Object ilvNode = getModel().getObject(ilvNodeID);
/*  245 */     if (ilvNode != null) {
/*  246 */       return ilvNode;


/*      */     }
/*      */ 
/*  251 */     String langCode = assetMbo.getUserInfo().getLangCode();
/*  252 */     String mboName = assetMbo.getName();
/*  253 */     String bidiDir = "";
/*  254 */     TaskIndicator scheduledTaskIndicator = null;
/*      */ 
/*  256 */     String status = assetMbo.getString("STATUS");
/*  257 */     scheduledTaskIndicator = getScheduledTaskIndicator(assetMbo);
/*  258 */     String nodeToolTip = getNodeToolTip(assetMbo, this.configuredNodeTooltipItems);
/*      */ 
/*  260 */     bidiDir = BidiUtils.getMboTextDirection(mboName, "ASSETNUM", true);










/*      */ 
/*  272 */     String className = getClassificationId(assetMbo);
/*  273 */     String bidiClassName = className;
/*  274 */     if (BidiUtils.isBidiEnabled()) {
/*  275 */       bidiClassName = BidiUtils.applyBidiAttributes(mboName, "CLASSSTRUCTUREID", className, langCode);
/*      */     }
/*  277 */     ilvNode = getModel().createNode(tag);
/*  278 */     getModel().setID(ilvNode, ilvNodeID);
/*      */ 
/*  280 */     if (!(BidiUtils.isBidiEnabled())) {
/*  281 */       getModel().setObjectProperty(ilvNode, "assetnum", ilvNodeID);
/*      */     } else {
/*  283 */       String nodeId = (assetMbo.getName().equals("ACTCI")) ? BidiUtils.applyBidiAttributes(mboName, "ACTCINUM", ilvNodeID, langCode) : BidiUtils.applyBidiAttributes(mboName, "ASSETNUM", ilvNodeID, langCode);

/*      */ 
/*  286 */       getModel().setObjectProperty(ilvNode, "assetnum", nodeId);
/*      */     }
/*  288 */     getModel().setObjectProperty(ilvNode, "Incidents", Integer.valueOf(0));
/*  289 */     getModel().setObjectProperty(ilvNode, "Impacted", Boolean.valueOf(isCiImpacted(ilvNodeID)));
/*  290 */     getModel().setObjectProperty(ilvNode, "searchmatch", Boolean.valueOf(false));
/*  291 */     getModel().setObjectProperty(ilvNode, "toplevel", Boolean.valueOf(isTopLevelAsset(assetMbo)));
/*  292 */     if (tag.equalsIgnoreCase("root"))
/*      */     {
/*  294 */       getModel().setObjectProperty(ilvNode, "root", Boolean.valueOf(true));
/*      */     }
/*      */     else
/*      */     {
/*  298 */       getModel().setObjectProperty(ilvNode, "root", Boolean.valueOf(false));
/*      */     }
/*  300 */     getModel().setObjectProperty(ilvNode, "description", assetMbo.getString("DESCRIPTION"));
/*      */ 
/*  302 */     getModel().setObjectProperty(ilvNode, "statusNative", status);
/*  303 */     getModel().setObjectProperty(ilvNode, "status", StatusConstants.flavourOfModel2ILOG((String)nativeStatusMapper.get(status)));
/*      */ 
/*  305 */     getModel().setObjectProperty(ilvNode, "scheduledTasks", Integer.valueOf(scheduledTaskIndicator.getIndicator()));
/*  306 */     getModel().setObjectProperty(ilvNode, "availableHops", Integer.valueOf(0));
/*  307 */     getModel().setObjectProperty(ilvNode, "classification", className);
/*  308 */     if (BidiUtils.isBidiEnabled()) {
/*  309 */       getModel().setObjectProperty(ilvNode, "bidiclassification", bidiClassName);
/*  310 */       getModel().setObjectProperty(ilvNode, "bididirection", bidiDir);
/*      */     }
/*      */ 
/*  313 */     getModel().setObjectProperty(ilvNode, "hidden", Boolean.valueOf(false));
/*  314 */     getModel().setObjectProperty(ilvNode, "image", getNodeImage(assetMbo));
/*  315 */     getModel().setObjectProperty(ilvNode, "nodeToolTip", nodeToolTip);
/*      */ 
/*  317 */     getModel().addObject(ilvNode, null, null);

















/*      */ 
/*  336 */     return ilvNode;
/*      */   }

/*      */   public void setupMouseOverInfo(MboRemote mbo) throws RemoteException, MXException {
/*  340 */     setupPrimaryMouseOverInfo(mbo);
/*  341 */     setupAstSpecMouseOverInfo(mbo);
/*  342 */     setupDefaultLinearLabels(mbo);
/*      */   }

/*      */   private void setupPrimaryMouseOverInfo(MboRemote mbo) throws RemoteException, MXException {
/*  346 */     MboSetRemote assetMOItems = MXServer.getMXServer().getMboSet("ASTMSOVER", mbo.getUserInfo());
/*  347 */     assetMOItems.setQbeExactMatch(true);
/*  348 */     assetMOItems.setQbe("showinmouseover", "1");

/*      */ 
/*  351 */     MboRemote mombo = null;
/*  352 */     while ((mombo = assetMOItems.moveNext()) != null) {
/*  353 */       NodeTooltipInfo nodeTooltipInfo = new NodeTooltipInfo();
/*  354 */       nodeTooltipInfo.setName(mombo.getString("NAME"));
/*  355 */       nodeTooltipInfo.setMoObject(mombo.getString("MOOBJECT"));
/*  356 */       nodeTooltipInfo.setMoAttribute(mombo.getString("MOATTRIBUTE"));
/*  357 */       nodeTooltipInfo.setDisplayTitle(mombo.getString("TITLE"));
/*  358 */       nodeTooltipInfo.setDisplayOrder(mombo.getInt("DISPLAYORDER"));
/*      */ 
/*  360 */       this.configuredNodeTooltipItems.add(nodeTooltipInfo);
/*      */     }
/*      */ 
/*  363 */     assetMOItems.close();
/*      */   }

/*      */   private void setupAstSpecMouseOverInfo(MboRemote mbo) throws RemoteException, MXException {
/*  367 */     MboSetRemote assetAttrSpecMOItems = MXServer.getMXServer().getMboSet("ASTSPECMSOVER", mbo.getUserInfo());
/*  368 */     assetAttrSpecMOItems.setQbeExactMatch(true);
/*  369 */     assetAttrSpecMOItems.setQbe("showinmouseover", "1");


/*      */ 
/*  373 */     MboRemote mombo = null;
/*  374 */     while ((mombo = assetAttrSpecMOItems.moveNext()) != null) {
/*  375 */       NodeTooltipInfo nodeTooltipInfo = new NodeTooltipInfo();
/*  376 */       nodeTooltipInfo.setName(mombo.getString("NAME"));
/*  377 */       nodeTooltipInfo.setMoObject("ASSETSPEC");
/*  378 */       nodeTooltipInfo.setMoAttribute(mombo.getString("ASTSPECATTRIBUTE"));
/*  379 */       nodeTooltipInfo.setDisplayTitle(mombo.getString("TITLE"));
/*  380 */       nodeTooltipInfo.setDisplayOrder(mombo.getInt("DISPLAYORDER"));
/*      */ 
/*  382 */       this.configuredNodeTooltipItems.add(nodeTooltipInfo);
/*      */     }
/*      */ 
/*  385 */     assetAttrSpecMOItems.close();
/*      */   }

/*      */   private void setupDefaultLinearLabels(MboRemote mbo) throws RemoteException, MXException {
/*  389 */     MboSetRemote maxlabels = MXServer.getMXServer().getMboSet("MAXLABELS", mbo.getUserInfo());
/*      */ 
/*  391 */     maxlabels.setQbeExactMatch(false);
/*  392 */     maxlabels.setQbe("app", "asset%");
/*  393 */     maxlabels.setQbe("id", "lin_det_grid10_10_11_1%");
/*  394 */     maxlabels.reset();
/*      */ 
/*  396 */     MboRemote lablembo = null;
/*  397 */     while ((lablembo = maxlabels.moveNext()) != null) {
/*  398 */       String labelId = lablembo.getString("ID");
/*  399 */       if (labelId.equals("lin_det_grid10_10_11_1_13a")) {
/*  400 */         this.defaultStartMeasureLabel = lablembo.getString("VALUE");
/*      */       }
/*  402 */       if (labelId.equals("lin_det_grid10_10_11_1_15a")) {
/*  403 */         this.defaultEndMeasureLabel = lablembo.getString("VALUE");
/*      */       }
/*      */     }
/*      */ 
/*  407 */     maxlabels.close();
/*      */   }

/*      */   public boolean isCiImpacted(String assetnum) {
/*  411 */     return (this.impactedAsset.containsKey(assetnum));
/*      */   }

/*      */   public void generateLinks(Object ilvNode, HashSet<String> inRelations, HashSet<String> outRelations, String tag)
/*      */   {
/*  416 */     if (!(ilvNode.equals(getLastIlvNode())))

/*      */     {
/*  419 */       HashSet in = combineAllInRelations(inRelations);

/*      */ 
/*  422 */       boolean inferred = false;
/*  423 */       if (in.size() > 0)
/*      */       {
/*  425 */         String relations = convertRelationListToString(in);
/*  426 */         String linkId = generateLinkId(getLastIlvNode(), ilvNode, relations);
/*  427 */         Object link = getModel().getObject(linkId);
/*  428 */         if (link == null)
/*      */         {
/*  430 */           link = getModel().createLink(tag);
/*  431 */           getModel().setID(link, linkId);
/*      */ 
/*  433 */           getModel().setFrom(link, getLastIlvNode());
/*  434 */           getModel().setTo(link, ilvNode);
/*  435 */           reportOneConstructedDegree(getLastIlvNode());
/*  436 */           reportOneConstructedDegree(ilvNode);
/*      */ 
/*  438 */           getModel().setObjectProperty(link, "relation", relations);


/*      */ 
/*  442 */           if (getLastIlvNodeFromAssetStack() != null) {
/*  443 */             getModel().setObjectProperty(link, "linkToolTip", getLinkToolTip(relations));
/*  444 */             getModel().setObjectProperty(link, "inferred", Boolean.valueOf(false));
/*      */           } else {
/*  446 */             getModel().setObjectProperty(link, "linkToolTip", "");
/*  447 */             getModel().setObjectProperty(link, "inferred", Boolean.valueOf(true));
/*  448 */             inferred = true;
/*      */           }
/*  450 */           getModel().setObjectProperty(link, "hidden", Boolean.valueOf(false));
/*  451 */           getModel().addObject(link, null, null);

/*      */         }
/*      */         else
/*      */         {
/*  456 */           System.out.println(CLASS + "createLinks Link " + linkId + " already created");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  461 */       HashSet out = combineAllOutRelations(outRelations);
/*      */ 
/*  463 */       if ((out.size() > 0) && (!(inferred)))
/*      */       {
/*  465 */         String relations = convertRelationListToString(out);
/*  466 */         String linkId = generateLinkId(ilvNode, getLastIlvNode(), relations);
/*  467 */         Object link = getModel().getObject(linkId);
/*  468 */         if (link == null)
/*      */         {
/*  470 */           link = getModel().createLink(tag);
/*  471 */           getModel().setID(link, linkId);
/*      */ 
/*  473 */           getModel().setFrom(link, ilvNode);
/*  474 */           getModel().setTo(link, getLastIlvNode());
/*  475 */           reportOneConstructedDegree(getLastIlvNode());
/*  476 */           reportOneConstructedDegree(ilvNode);
/*      */ 
/*  478 */           getModel().setObjectProperty(link, "relation", relations);
/*  479 */           if (getLastIlvNodeFromAssetStack() != null) {
/*  480 */             getModel().setObjectProperty(link, "linkToolTip", getLinkToolTip(relations));
/*  481 */             getModel().setObjectProperty(link, "inferred", Boolean.valueOf(false));
/*      */           } else {
/*  483 */             getModel().setObjectProperty(link, "linkToolTip", "");
/*  484 */             getModel().setObjectProperty(link, "inferred", Boolean.valueOf(true));
/*      */           }
/*  486 */           getModel().setObjectProperty(link, "hidden", Boolean.valueOf(false));
/*  487 */           getModel().addObject(link, null, null);
/*      */         }
/*      */         else
/*      */         {
/*  491 */           System.out.println(CLASS + "createLinks Link " + linkId + " already created");
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  497 */       System.out.println(CLASS + "createLinks Links are between the same node, do not create");
/*      */     }
/*      */   }







/*      */   public String getCLASSSTRUCTURE_CLASSIFICATIONID(MboRemote assetMbo)
/*      */     throws MXException, RemoteException
/*      */   {
/*  510 */     return getClassificationId(assetMbo);
/*      */   }

/*      */   public String getClassificationId(MboRemote assetMbo) throws MXException, RemoteException {
/*  514 */     AssetClassification acf = getClassification(assetMbo);
/*  515 */     return ((acf == null) ? "" : acf.classificationId);
/*      */   }

/*      */   public String getCLASSSTRUCTURE_DESCRIPTION(MboRemote assetMbo) throws MXException, RemoteException {
/*  519 */     AssetClassification acf = getClassification(assetMbo);
/*  520 */     return ((acf == null) ? "" : acf.description);
/*      */   }

/*      */   private AssetClassification getClassification(MboRemote assetMbo) throws MXException, RemoteException {
/*  524 */     AssetClassification assetClass = null;
/*      */ 
/*  526 */     String classStructId = assetMbo.getString("CLASSSTRUCTUREID");
/*  527 */     if ((classStructId != null) && (!(classStructId.equals("")))) {
/*  528 */       assetClass = (AssetClassification)getClassificationMap().get(classStructId);
/*  529 */       if (assetClass == null)
/*      */       {
/*  531 */         assetClass = fetchClassification(assetMbo, classStructId);
/*  532 */         getClassificationMap().put(classStructId, assetClass);
/*      */       }
/*      */     }
/*  535 */     return assetClass;
/*      */   }

/*      */   public boolean isTopLevelAsset(MboRemote assetMbo) throws MXException, RemoteException
/*      */   {
/*  540 */     String classStructId = assetMbo.getString("CLASSSTRUCTUREID");
/*  541 */     boolean isTopLevelAsset = false;
/*  542 */     if ((classStructId != null) && (!(classStructId.equals("")))) {
/*  543 */       AssetClassification assetClass = (AssetClassification)getClassificationMap().get(classStructId);
/*  544 */       if (assetClass == null)
/*      */       {
/*  546 */         assetClass = fetchClassification(assetMbo, classStructId);
/*  547 */         getClassificationMap().put(classStructId, assetClass);
/*      */       }
/*  549 */       isTopLevelAsset = assetClass.isTopLevel;
/*      */     }
/*  551 */     return isTopLevelAsset;
/*      */   }


/*      */   public String getNodeImage(MboRemote assetMbo)
/*      */     throws MXException, RemoteException
/*      */   {
/*  558 */     String classStructureId = assetMbo.getString("CLASSSTRUCTUREID");
/*  559 */     if ((classStructureId == null) || (classStructureId.trim().length() == 0)) {
/*  560 */       return "";



/*      */     }
/*      */ 
/*  566 */     ClassStructure classstructure = null;
/*  567 */     byte[] image = null;
/*      */     try {
/*  569 */       SqlFormat sqf = new SqlFormat("classstructureid = :1");
/*  570 */       sqf.setObject(1, "CLASSSTRUCTURE", "CLASSSTRUCTUREID", classStructureId);
/*  571 */       classstructure = (ClassStructure)assetMbo.getMboSet("$CLASSSTRUCTRURE", "CLASSSTRUCTURE", sqf.format()).getMbo(0);
/*  572 */       image = classstructure.getBytes("IMGLIB.IMAGE");
/*      */     } catch (Exception e) {
/*      */     }
/*  575 */     if (image == null) {
/*  576 */       return "";



/*      */     }
/*      */ 
/*  582 */     String nodeImage = "";
/*  583 */     if ((classStructureId != null) && (!(classStructureId.equals("")))) {
/*  584 */       AssetClassification assetClass = (AssetClassification)getClassificationMap().get(classStructureId);
/*  585 */       if (assetClass == null)
/*      */       {
/*  587 */         assetClass = fetchClassification(assetMbo, classStructureId);
/*  588 */         getClassificationMap().put(classStructureId, assetClass);
/*      */       }
/*  590 */       nodeImage = assetClass.topoImage;
/*      */     }
/*      */ 
/*  593 */     return nodeImage;
/*      */   }

/*      */   private String getNodeToolTip(MboRemote assetMbo, Set<NodeTooltipInfo> configuredNodeTooltipInfos) throws MXException, RemoteException {
/*  597 */     String langCode = assetMbo.getUserInfo().getLangCode();
/*  598 */     String bidiPrefix = (BidiUtils.isBidiEnabled()) ? BidiUtils.getDelimeterPrefix(langCode) : "";
/*  599 */     boolean isRTL = (BidiUtils.isBidiEnabled()) && (BidiUtils.getLayoutOrientation(langCode).equals("RTL"));
/*      */ 
/*  601 */     StringBuffer codeBuff = new StringBuffer();
/*      */ 
/*  603 */     createTableHeader(codeBuff);
/*      */ 
/*  605 */     for (NodeTooltipInfo nodeTooltipInfo : configuredNodeTooltipInfos) {
/*  606 */       String mboName = nodeTooltipInfo.getMoObject();
/*  607 */       String mboAttr = nodeTooltipInfo.getMoAttribute();
/*  608 */       String keyLabel = nodeTooltipInfo.getDisplayTitle();
/*  609 */       List valueLabels = resolveValueDetails(assetMbo, mboName, mboAttr, isRTL);

/*      */ 
/*  612 */       if (valueLabels == null) continue; if (valueLabels.size() == 0)









/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/*  626 */       if (valueLabels.size() == 1) {
/*  627 */         addOneRowToNodeTooltip(codeBuff, toBidiString(keyLabel, mboName, mboAttr, langCode), null, null, ":", toBidiString(((ValueDetail)valueLabels.get(0)).getValuelabel(), mboName, mboAttr, langCode), isRTL, bidiPrefix);








/*      */       }
/*      */ 
/*  638 */       StringBuffer comboKey = new StringBuffer();
/*  639 */       comboKey.append(keyLabel);
/*  640 */       comboKey.append(", ");
/*  641 */       Iterator itr = valueLabels.iterator();
/*  642 */       while (itr.hasNext()) {
/*  643 */         ValueDetail valueDetail = (ValueDetail)itr.next();
/*  644 */         addOneRowToNodeTooltip(codeBuff, toBidiString(keyLabel, mboName, mboAttr, langCode), valueDetail.getStartLinearData(), valueDetail.getEndLinearData(), ":", toBidiString(valueDetail.getValuelabel(), mboName, mboAttr, langCode), isRTL, bidiPrefix);





/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  654 */     createTableFooter(codeBuff);
/*      */ 
/*  656 */     return codeBuff.toString();
/*      */   }

/*      */   private String toBidiString(String entry, String mboName, String mboAttr, String langCode) {
/*  660 */     if (!(BidiUtils.isBidiEnabled())) {
/*  661 */       return entry;
/*      */     }
/*  663 */     return BidiUtils.applyBidiAttributes(mboName, mboAttr, entry, langCode);
/*      */   }

/*      */   private List<ValueDetail> resolveValueDetails(MboRemote assetMbo, String mboName, String mboAttr, boolean isRTL) throws RemoteException, MXException {
/*  667 */     List valueDetails = new LinkedList();

/*      */ 
/*  670 */     if (mboName.equals("ASSET")) {
/*  671 */       valueDetails.add(new ValueDetail(assetMbo.getString(mboAttr)));
/*  672 */       return valueDetails;

/*      */     }
/*      */ 
/*  676 */     if (mboName.equals("ASSETSPEC")) {
/*  677 */       List assetspecreply = null;
/*      */       try {
/*  679 */         assetspecreply = getAssetSpecValueDetails(assetMbo, mboAttr, isRTL);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*  684 */       if ((assetspecreply != null) && (assetspecreply.size() > 0)) {
/*  685 */         return assetspecreply;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  690 */     String method = "get" + mboName + "_" + mboAttr;
/*  691 */     String apireply = "";
/*      */     try {
/*  693 */       apireply = invokeMethod(this, method, assetMbo);
/*  694 */       valueDetails.add(new ValueDetail(apireply));
/*  695 */       return valueDetails;



/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  702 */       System.out.println("Unable to resolve the mouse over value from attribue [" + mboAttr + "] of mbo [" + mboName + "] for assetnum [" + assetMbo.getString("ASSETNUM") + "]"); }
/*  703 */     return null;
/*      */   }














/*      */   /** @deprecated */
/*      */   private List<String> getValueLabelsByBasicRule(MboRemote assetMbo, String mboName, String mboAttr)
/*      */     throws RemoteException, MXException
/*      */   {
/*  723 */     List reply = new LinkedList();
/*  724 */     MboSetRemote allProperItems = MXServer.getMXServer().getMboSet(mboName, assetMbo.getUserInfo());
/*  725 */     allProperItems.setQbeExactMatch(true);
/*  726 */     allProperItems.setQbe("ASSETNUM", assetMbo.getString("ASSETNUM"));
/*  727 */     allProperItems.setQbe("SITEID", assetMbo.getString("SITEID"));
/*  728 */     allProperItems.setQbe("ORGID", assetMbo.getString("ORGID"));
/*      */ 
/*  730 */     int maxType = MXServer.getMXServer().getMaximoDD().getMboSetInfo(mboName).getMboValueInfo(mboAttr).getTypeAsInt();
/*      */ 
/*  732 */     MboRemote mbo = null;
/*  733 */     while ((mbo = allProperItems.moveNext()) != null) {
/*  734 */       reply.add(MBOString.getString(mbo, mboAttr, maxType));
/*      */     }
/*  736 */     return reply;
/*      */   }













/*      */   private List<ValueDetail> getAssetSpecValueDetails(MboRemote assetMbo, String mboAttr, boolean isRTL)
/*      */     throws RemoteException, MXException
/*      */   {
/*  754 */     List reply = new LinkedList();
/*      */ 
/*  756 */     MboSetRemote allProperItems = MXServer.getMXServer().getMboSet("ASSETSPEC", assetMbo.getUserInfo());
/*  757 */     allProperItems.setQbeExactMatch(true);
/*  758 */     allProperItems.setQbe("ASSETNUM", assetMbo.getString("ASSETNUM"));
/*  759 */     allProperItems.setQbe("ASSETATTRID", mboAttr);
/*  760 */     allProperItems.setQbe("SITEID", assetMbo.getString("SITEID"));
/*  761 */     allProperItems.setQbe("ORGID", assetMbo.getString("ORGID"));
/*  762 */     allProperItems.setOrderBy("DISPLAYSEQUENCE");
/*      */ 
/*  764 */     if (!(isMaxtypeOfAssetSpecPopulated)) {
/*  765 */       synchronized (fetchSvrDataLock) {
/*  766 */         if (!(isMaxtypeOfAssetSpecPopulated)) {
/*  767 */           MboSetInfo msi = MXServer.getMXServer().getMaximoDD().getMboSetInfo("ASSETSPEC");
/*  768 */           maxtypeOfAssetSpec.put("NUMVALUE", Integer.valueOf(msi.getMboValueInfo("NUMVALUE").getTypeAsInt()));
/*  769 */           maxtypeOfAssetSpec.put("MEASUREUNITID", Integer.valueOf(msi.getMboValueInfo("MEASUREUNITID").getTypeAsInt()));
/*  770 */           maxtypeOfAssetSpec.put("ALNVALUE", Integer.valueOf(msi.getMboValueInfo("ALNVALUE").getTypeAsInt()));
/*  771 */           maxtypeOfAssetSpec.put("STARTMEASURE", Integer.valueOf(msi.getMboValueInfo("STARTMEASURE").getTypeAsInt()));
/*  772 */           maxtypeOfAssetSpec.put("STARTMEASUREUNITID", Integer.valueOf(msi.getMboValueInfo("STARTMEASUREUNITID").getTypeAsInt()));
/*  773 */           maxtypeOfAssetSpec.put("ENDMEASURE", Integer.valueOf(msi.getMboValueInfo("ENDMEASURE").getTypeAsInt()));
/*  774 */           maxtypeOfAssetSpec.put("ENDMEASUREUNITID", Integer.valueOf(msi.getMboValueInfo("ENDMEASUREUNITID").getTypeAsInt()));
/*  775 */           isMaxtypeOfAssetSpecPopulated = true;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  780 */     MboRemote mbo = null;
/*  781 */     while ((mbo = allProperItems.moveNext()) != null) {
/*  782 */       String numvalue = MBOString.getString(mbo, "NUMVALUE", ((Integer)maxtypeOfAssetSpec.get("NUMVALUE")).intValue());
/*  783 */       String measureunitid = MBOString.getString(mbo, "MEASUREUNITID", ((Integer)maxtypeOfAssetSpec.get("MEASUREUNITID")).intValue());
/*  784 */       String alnvalue = MBOString.getString(mbo, "ALNVALUE", ((Integer)maxtypeOfAssetSpec.get("ALNVALUE")).intValue());
/*      */ 
/*  786 */       String startMeasure = MBOString.getString(mbo, "STARTMEASURE", ((Integer)maxtypeOfAssetSpec.get("STARTMEASURE")).intValue());
/*  787 */       String startMeasureUnitId = MBOString.getString(mbo, "STARTMEASUREUNITID", ((Integer)maxtypeOfAssetSpec.get("STARTMEASUREUNITID")).intValue());
/*  788 */       String endMeasure = MBOString.getString(mbo, "ENDMEASURE", ((Integer)maxtypeOfAssetSpec.get("ENDMEASURE")).intValue());
/*  789 */       String endMeasureUnitId = MBOString.getString(mbo, "ENDMEASUREUNITID", ((Integer)maxtypeOfAssetSpec.get("ENDMEASUREUNITID")).intValue());
/*      */ 
/*  791 */       String datatype = (String)datatypeOfAssetAttr.get(mboAttr);
/*  792 */       if (StringUtil.isEmptyString(datatype)) {
/*  793 */         synchronized (fetchSvrDataLock) {
/*  794 */           if (StringUtil.isEmptyString(datatype)) {
/*  795 */             MboSetRemote attrs = MXServer.getMXServer().getMboSet("ASSETATTRIBUTE", assetMbo.getUserInfo());
/*  796 */             attrs.setQbeExactMatch(true);
/*  797 */             attrs.setQbe("ASSETATTRID", mboAttr);
/*  798 */             datatype = attrs.getMbo(0).getString("DATATYPE");
/*  799 */             String internaldatatype = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("DATATYPE", datatype);
/*  800 */             datatypeOfAssetAttr.put(mboAttr, internaldatatype);
/*  801 */             datatype = internaldatatype;
/*  802 */             attrs.close();
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  808 */       String valueLabel = "";
/*  809 */       if (datatype.equalsIgnoreCase("NUMERIC")) {
/*  810 */         valueLabel = numvalue + " " + measureunitid;
/*      */       }
/*  812 */       else if (datatype.equalsIgnoreCase("ALN")) {
/*  813 */         valueLabel = alnvalue;



/*      */       }
/*      */ 
/*  819 */       ValueDetail valueDetail = new ValueDetail(valueLabel);
/*  820 */       reply.add(valueDetail);

/*      */ 
/*  823 */       LinearData startLinearData = new LinearData(isRTL);
/*  824 */       startLinearData.setLinearLabel(this.defaultStartMeasureLabel);
/*  825 */       startLinearData.setLinearMeasure(startMeasure);
/*  826 */       startLinearData.setLinearMeasureUnitID(startMeasureUnitId);
/*  827 */       valueDetail.setStartLinearData(startLinearData);

/*      */ 
/*  830 */       LinearData endLinearData = new LinearData(isRTL);
/*  831 */       endLinearData.setLinearLabel(this.defaultEndMeasureLabel);
/*  832 */       endLinearData.setLinearMeasure(endMeasure);
/*  833 */       endLinearData.setLinearMeasureUnitID(endMeasureUnitId);
/*  834 */       valueDetail.setEndLinearData(endLinearData);
/*      */     }
/*      */ 
/*  837 */     allProperItems.close();
/*      */ 
/*  839 */     return reply;
/*      */   }

/*      */   private String invokeMethod(Object obj, String method, MboRemote mbo) throws Exception {
/*  843 */     return ((String)obj.getClass().getMethod(method, new Class[] { MboRemote.class }).invoke(obj, new Object[] { mbo }));
/*      */   }

/*      */   private void createTableHeader(StringBuffer nodeTooltipBuff) {
/*  847 */     nodeTooltipBuff.append("<html>");
/*  848 */     nodeTooltipBuff.append("<head><style type=\"text/css\" >.table-border{border:2px solid #333333}.tdbg{padding-top: 11px;padding-bottom: 11px;padding-left:15px;padding-right: 15px;background-color:#fefee2}</style></head>");
/*  849 */     nodeTooltipBuff.append("<body>");
/*  850 */     nodeTooltipBuff.append("<table class=\"table-border\" ><tr><td class=\"tdbg\" >");
/*  851 */     nodeTooltipBuff.append("<table>");
/*      */   }




/*      */   private void addOneRowToNodeTooltip(StringBuffer nodeTooltipBuff, String keyLable, LinearData startlinear, LinearData endlinear, String del, String valueLabel, boolean isRTL, String bidiPrefix)
/*      */   {
/*  859 */     if (isRTL) {
/*  860 */       addOneRTLRRowToNodeTooltip(nodeTooltipBuff, keyLable, del, startlinear, endlinear, valueLabel, bidiPrefix);
/*      */     }
/*      */     else
/*  863 */       addOneLTRRowToNodeTooltip(nodeTooltipBuff, keyLable, del, startlinear, endlinear, valueLabel, bidiPrefix);
/*      */   }



/*      */   private void addOneLTRRowToNodeTooltip(StringBuffer nodeTooltipBuff, String keyLable, String del, LinearData startlinear, LinearData endlinear, String valueLabel, String bidiPrefix)
/*      */   {
/*  870 */     nodeTooltipBuff.append("<tr>");
/*      */ 
/*  872 */     StringBuffer subBuff = new StringBuffer();

/*      */ 
/*  875 */     subBuff.append("<td class=\"txtgray\"").append(">");
/*  876 */     subBuff.append(bidiPrefix + keyLable);
/*  877 */     subBuff.append("</td>");

/*      */ 
/*  880 */     if ((startlinear != null) || (endlinear != null)) {
/*  881 */       subBuff.append("<td><table width=\"100%\"><tr>");
/*  882 */       if (startlinear != null) {
/*  883 */         subBuff.append("<td class=\"txtgray\">" + startlinear.getLinearLabel() + "</td>");
/*  884 */         subBuff.append("<td class=\"txtgray\">" + startlinear.getLinearMeasure() + "</td>");
/*  885 */         subBuff.append("<td class=\"txtgray\">" + startlinear.getLinearMeasureUnitID() + "</td>");
/*      */       }
/*  887 */       if (endlinear != null) {
/*  888 */         if (startlinear != null) subBuff.append("<td class=\"txtgray\">, </td>");
/*  889 */         subBuff.append("<td class=\"txtgray\">" + endlinear.getLinearLabel() + "</td>");
/*  890 */         subBuff.append("<td class=\"txtgray\">" + endlinear.getLinearMeasure() + "</td>");
/*  891 */         subBuff.append("<td class=\"txtgray\">" + endlinear.getLinearMeasureUnitID() + "</td>");
/*      */       }
/*  893 */       subBuff.append("</tr></table></td>");
/*      */     }
/*      */     else {
/*  896 */       subBuff.append("<td><table><tr></tr></table></td>");

/*      */     }
/*      */ 
/*  900 */     subBuff.append("<td class=\"txtgray\"").append(">");
/*  901 */     subBuff.append(del);
/*  902 */     subBuff.append("</td>");

/*      */ 
/*  905 */     subBuff.append("<td class=\"txtblack\"").append(">");
/*  906 */     subBuff.append(valueLabel);
/*  907 */     subBuff.append("</td>");
/*      */ 
/*  909 */     nodeTooltipBuff.append(subBuff);
/*      */ 
/*  911 */     nodeTooltipBuff.append("</tr>");
/*      */   }


/*      */   private void addOneRTLRRowToNodeTooltip(StringBuffer nodeTooltipBuff, String keyLable, String del, LinearData startlinear, LinearData endlinear, String valueLabel, String bidiPrefix)
/*      */   {
/*  917 */     nodeTooltipBuff.append("<tr>");
/*      */ 
/*  919 */     StringBuffer subBuff = new StringBuffer();

/*      */ 
/*  922 */     subBuff.append("<td class=\"txtblack\" align=\"right\"").append(">");
/*  923 */     subBuff.append(valueLabel);
/*  924 */     subBuff.append("</td>");

/*      */ 
/*  927 */     subBuff.append("<td class=\"txtgray\" align=\"right\"").append(">");
/*  928 */     subBuff.append(del);
/*  929 */     subBuff.append("</td>");

/*      */ 
/*  932 */     if ((startlinear != null) || (endlinear != null)) {
/*  933 */       subBuff.append("<td><table width=\"100%\"><tr>");
/*  934 */       if (endlinear != null) {
/*  935 */         subBuff.append("<td class=\"txtgray\" align=\"right\">" + endlinear.getLinearMeasureUnitID() + "</td>");
/*  936 */         subBuff.append("<td class=\"txtgray\" align=\"right\">" + endlinear.getLinearMeasure() + "</td>");
/*  937 */         subBuff.append("<td class=\"txtgray\" align=\"right\">" + endlinear.getLinearLabel() + "</td>");
/*      */       }
/*  939 */       if (startlinear != null) {
/*  940 */         if (endlinear != null) subBuff.append("<td class=\"txtgray\" align=\"right\">, </td>");
/*  941 */         subBuff.append("<td class=\"txtgray\" align=\"right\">" + startlinear.getLinearMeasureUnitID() + "</td>");
/*  942 */         subBuff.append("<td class=\"txtgray\" align=\"right\">" + startlinear.getLinearMeasure() + "</td>");
/*  943 */         subBuff.append("<td class=\"txtgray\" align=\"right\">" + startlinear.getLinearLabel() + "</td>");
/*      */       }
/*  945 */       subBuff.append("</tr></table></td>");
/*      */     }
/*      */     else {
/*  948 */       subBuff.append("<td><table><tr></tr></table></td>");

/*      */     }
/*      */ 
/*  952 */     subBuff.append("<td class=\"txtgray\"  align=\"right\"").append(">");
/*  953 */     subBuff.append(bidiPrefix + keyLable);
/*  954 */     subBuff.append("</td>");
/*      */ 
/*  956 */     nodeTooltipBuff.append(subBuff);
/*      */ 
/*  958 */     nodeTooltipBuff.append("</tr>");
/*      */   }

/*      */   private void createTableFooter(StringBuffer nodeTooltipBuff) {
/*  962 */     nodeTooltipBuff.append("</table>");
/*  963 */     nodeTooltipBuff.append("</td></tr></table>");
/*  964 */     nodeTooltipBuff.append("</body>");
/*  965 */     nodeTooltipBuff.append("</html>");
/*      */   }

/*      */   public String getLinkToolTip(String relations)
/*      */   {
/*  970 */     StringTokenizer stk = new StringTokenizer(relations, ",");
/*  971 */     StringBuffer codeBuff = new StringBuffer();
/*  972 */     codeBuff.append("<html>");
/*  973 */     codeBuff.append("<head><style type=\"text/css\" >.table-border{border:2px solid #333333}.tdbg{padding-top: 11px;padding-bottom: 11px;padding-left:15px;padding-right: 15px;background-color:#fefee2}</style></head>");
/*  974 */     codeBuff.append("<table class=\"table-border\" ><tr><td class=\"tdbg\" >");
/*  975 */     codeBuff.append("<table>");
/*  976 */     while (stk.hasMoreTokens()) {
/*  977 */       codeBuff.append("<tr><td class=\"txtblack\">");
/*  978 */       codeBuff.append(stk.nextToken());
/*  979 */       codeBuff.append("</td></tr>");
/*      */     }
/*  981 */     codeBuff.append("</table>");
/*  982 */     codeBuff.append("</td></tr></table>");
/*  983 */     codeBuff.append("</html>");
/*  984 */     return codeBuff.toString();
/*      */   }






/*      */   public TaskIndicator getScheduledTaskIndicator(MboRemote assetMbo)
/*      */     throws MXException, RemoteException
/*      */   {
/*  995 */     MboSetRemote scheduledTasks = assetMbo.getMboSet("TOPOLOGYASSETWORKS");
/*  996 */     return TaskIndicator.resolveTaskIndicator((WOSet)scheduledTasks);
/*      */   }


/*      */   private String generateLinkId(Object from, Object to, String relation)
/*      */   {
/* 1002 */     int i = from.hashCode();
/* 1003 */     int j = to.hashCode();
/* 1004 */     int k = relation.hashCode();
/* 1005 */     return String.valueOf(i) + "-" + String.valueOf(j) + "-" + String.valueOf(k);
/*      */   }

/*      */   private HashSet<String> combineAllInRelations(HashSet<String> currentInRelations)
/*      */   {
/* 1010 */     HashSet allInRelations = new HashSet();
/* 1011 */     if (currentInRelations != null)
/*      */     {
/* 1013 */       allInRelations.addAll(currentInRelations);
/*      */     }
/* 1015 */     int n = this.assetNodeStack.size();
/* 1016 */     for (int i = n - 1; i >= 0; --i)
/*      */     {
/* 1018 */       AssetNode assetNode = (AssetNode)this.assetNodeStack.get(i);
/* 1019 */       if (assetNode.ilvNode != null)
/*      */         break;
/* 1021 */       if (assetNode.inRelations == null)
/*      */         continue;
/* 1023 */       allInRelations.addAll(assetNode.inRelations);





/*      */     }
/*      */ 
/* 1031 */     return allInRelations;
/*      */   }

/*      */   private HashSet<String> combineAllOutRelations(HashSet<String> currentOutRelations)
/*      */   {
/* 1036 */     HashSet allOutRelations = new HashSet();
/* 1037 */     if (currentOutRelations != null)
/*      */     {
/* 1039 */       allOutRelations.addAll(currentOutRelations);
/*      */     }
/* 1041 */     int n = this.assetNodeStack.size();
/* 1042 */     for (int i = n - 1; i >= 0; --i)
/*      */     {
/* 1044 */       AssetNode assetNode = (AssetNode)this.assetNodeStack.get(i);
/* 1045 */       if (assetNode.ilvNode != null)
/*      */         break;
/* 1047 */       if (assetNode.outRelations == null)
/*      */         continue;
/* 1049 */       allOutRelations.addAll(assetNode.outRelations);





/*      */     }
/*      */ 
/* 1057 */     return allOutRelations;
/*      */   }

/*      */   private String convertRelationListToString(HashSet<String> relations)
/*      */   {
/* 1062 */     StringBuffer buff = new StringBuffer();
/* 1063 */     Iterator it = relations.iterator();
/* 1064 */     while (it.hasNext())
/*      */     {
/* 1066 */       buff.append((String)it.next());
/* 1067 */       if (!(it.hasNext()))
/*      */         continue;
/* 1069 */       buff.append(",");
/*      */     }
/*      */ 
/* 1072 */     return buff.toString();
/*      */   }

/*      */   private AssetClassification fetchClassification(MboRemote mbo, String classStructId) throws MXException, RemoteException {
/* 1076 */     AssetClassification assetClass = null;
/* 1077 */     if ((classStructId != null) && (!(classStructId.equals("")))) {
/* 1078 */       SqlFormat sqf = new SqlFormat(mbo.getUserInfo(), "classstructureid = :1");
/* 1079 */       sqf.setObject(1, "CLASSSTRUCTURE", "classstructureid", classStructId);
/* 1080 */       String whereClause = sqf.format();
/* 1081 */       MboSetRemote csMboSet = mbo.getMboSet("$CLASSSTRUCTURE", "CLASSSTRUCTURE", whereClause);
/*      */ 
/* 1083 */       if (!(csMboSet.isEmpty())) {
/* 1084 */         MboRemote csMbo = csMboSet.moveFirst();
/* 1085 */         assetClass = new AssetClassification();
/* 1086 */         assetClass.classificationId = csMbo.getString("CLASSIFICATIONID");
/* 1087 */         assetClass.description = csMbo.getString("DESCRIPTION");
/*      */ 
/* 1089 */         String showinbiz = csMbo.getString("SHOWINASSETTOPO");
/* 1090 */         if ((showinbiz == null) || (showinbiz.equals(""))) {
/* 1091 */           assetClass.isTopLevel = true;
/*      */         }
/*      */         else {
/* 1094 */           assetClass.isTopLevel = csMbo.getBoolean("SHOWINASSETTOPO");




/*      */         }
/*      */ 
/* 1101 */         assetClass.topoImage = csMbo.getString("CLASSSTRUCTUREID") + "/topology?uisessionid=" + getTopologyControl().getWebClientSession().getUISessionID() + "&controlid=" + getTopologyControl().getId() + "&name=topology.gif";




/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1110 */     return assetClass;
/*      */   }

/*      */   protected IlvDefaultSDMModel getModel()
/*      */   {
/* 1115 */     return this.model;
/*      */   }

/*      */   private HashMap<String, AssetClassification> getClassificationMap() {
/* 1119 */     return this.classMap;
/*      */   }

/*      */   private NodeStat resolveNodeStat(String assetnum)
/*      */   {
/* 1124 */     NodeStat ns = (NodeStat)this.accessedAssets.get(assetnum);
/* 1125 */     if (ns != null) {
/* 1126 */       return ns;
/*      */     }
/*      */ 
/* 1129 */     ns = new NodeStat();
/* 1130 */     this.accessedAssets.put(assetnum, ns);
/* 1131 */     return ns;
/*      */   }

/*      */   protected void setNodeDegree(String assetnum, int degree)
/*      */   {
/* 1136 */     resolveNodeStat(assetnum).setDegree(degree);
/*      */   }

/*      */   protected void reportOneConstructedDegree(Object ilvNode)
/*      */   {
/* 1141 */     String assetnum = getModel().getID(ilvNode);
/* 1142 */     resolveNodeStat(assetnum).constructOneDegree();
/*      */   }

/*      */   private Object getLastIlvNode() {
/* 1146 */     return this.ilvNodeStack.peek();
/*      */   }

/*      */   private Object getLastIlvNodeFromAssetStack() {
/* 1150 */     return ((AssetNode)this.assetNodeStack.peek()).ilvNode;
/*      */   }






/*      */   class AssetClassification
/*      */   {
/*      */     public String classificationId;
/*      */     public String description;
/*      */     public String topoImage;
/*      */     public boolean isTopLevel;
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1167 */       return "classificationId: " + this.classificationId + " topoImage: " + this.topoImage + " isTopLevel: " + this.isTopLevel;
/*      */     }
/*      */   }


/*      */   class NodeTooltipInfo
/*      */   {
/*      */     private String name;
/*      */     private String moObject;
/*      */     private String moAttribute;
/*      */     private String displayTitle;
/*      */     private int displayOrder;
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1182 */       return this.name;
/*      */     }

/*      */     protected void setName(String name) {
/* 1186 */       this.name = name;
/*      */     }

/*      */     public String getMoObject() {
/* 1190 */       return this.moObject;
/*      */     }

/*      */     protected void setMoObject(String moObject) {
/* 1194 */       this.moObject = moObject;
/*      */     }

/*      */     public String getMoAttribute() {
/* 1198 */       return this.moAttribute;
/*      */     }

/*      */     protected void setMoAttribute(String moAttribute) {
/* 1202 */       this.moAttribute = moAttribute;
/*      */     }

/*      */     public String getDisplayTitle() {
/* 1206 */       return this.displayTitle;
/*      */     }

/*      */     protected void setDisplayTitle(String displayTitle) {
/* 1210 */       this.displayTitle = displayTitle;
/*      */     }

/*      */     public int getDisplayOrder() {
/* 1214 */       return this.displayOrder;
/*      */     }

/*      */     protected void setDisplayOrder(int displayOrder) {
/* 1218 */       this.displayOrder = displayOrder;
/*      */     }

/*      */     public String toString()
/*      */     {
/* 1223 */       return "{" + this.name + ", " + this.moObject + "," + this.moAttribute + "," + this.displayTitle + "," + this.displayOrder + "}";
/*      */     }
/*      */   }
/*      */   public ResourceBundle getBundle()
/*      */   {
/* 1228 */     return this.bundle;
/*      */   }

/*      */   public void setBundle(ResourceBundle bundle) {
/* 1232 */     this.bundle = bundle;
/*      */   }

/*      */   protected TopologyControl getTopologyControl() {
/* 1236 */     return this.topologyControl;
/*      */   }
/*      */   static class ValueDetail/*      */   {/*      */     private String valuelabel;/*      */     private AssetNodeVisitor.LinearData startLinearData;/*      */     private AssetNodeVisitor.LinearData endLinearData;/*      */ /*      */     public ValueDetail()
/*      */     {
/*      */     public ValueDetail(String valuelabel, AssetNodeVisitor.LinearData startLinearData, AssetNodeVisitor.LinearData endLinearData)/*      */     {/* 1240 */       this.valuelabel = "";/* 1240 */       this.valuelabel = "";
/* 1241 */       this.startLinearData = null;/* 1241 */       this.startLinearData = null;
/* 1242 */       this.endLinearData = null;/* 1242 */       this.endLinearData = null;
/*      */     }


/*      */     public ValueDetail(String valuelabel)
/*      */     {
/* 1248 */       this(valuelabel, null, null);
/*      */     }

/*      */ 
/* 1252 */       this.valuelabel = valuelabel;
/* 1253 */       this.startLinearData = startLinearData;
/* 1254 */       this.endLinearData = endLinearData;
/*      */     }

/*      */     public String getValuelabel() {
/* 1258 */       return this.valuelabel;
/*      */     }

/*      */     protected void setValuelabel(String valuelabel) {
/* 1262 */       this.valuelabel = valuelabel;
/*      */     }

/*      */     public AssetNodeVisitor.LinearData getStartLinearData() {
/* 1266 */       return this.startLinearData;
/*      */     }

/*      */     protected void setStartLinearData(AssetNodeVisitor.LinearData startLinearData) {
/* 1270 */       this.startLinearData = startLinearData;
/*      */     }

/*      */     public AssetNodeVisitor.LinearData getEndLinearData() {
/* 1274 */       return this.endLinearData;
/*      */     }

/*      */     protected void setEndLinearData(AssetNodeVisitor.LinearData endLinearData) {
/* 1278 */       this.endLinearData = endLinearData;
/*      */     }
/*      */   }
/*      */   static class LinearData
/*      */   {
/* 1283 */     private boolean isRTL = false;
/*      */ 
/* 1285 */     private String linearLabel = "";
/* 1286 */     private String linearMeasure = "";
/* 1287 */     private String linearMeasureUnitID = "";
/*      */ 
/*      */     public LinearData(boolean isRTL) {
/* 1290 */       this.isRTL = isRTL;
/*      */     }

/*      */     public String getLinearLabel() {
/* 1294 */       return this.linearLabel;
/*      */     }

/*      */     protected void setLinearLabel(String linearLabel) {
/* 1298 */       this.linearLabel = linearLabel;
/*      */     }

/*      */     public String getLinearMeasure() {
/* 1302 */       return this.linearMeasure;
/*      */     }

/*      */     protected void setLinearMeasure(String linearMeasure) {
/* 1306 */       this.linearMeasure = linearMeasure;
/*      */     }

/*      */     public String getLinearMeasureUnitID() {
/* 1310 */       return this.linearMeasureUnitID;
/*      */     }

/*      */     protected void setLinearMeasureUnitID(String linearMeasureUnitID) {
/* 1314 */       this.linearMeasureUnitID = linearMeasureUnitID;
/*      */     }

/*      */     public String toString()
/*      */     {
/* 1319 */       return getLinearLabel() + " " + getLinearMeasure() + " " + getLinearMeasureUnitID();
/*      */     }
/*      */   }
/*      */ }
