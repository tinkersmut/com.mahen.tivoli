package com.ibm.tivoli.maximo.asset.topology.applet;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

public class AssetSeparatorAction extends AbstractAction
{
  private static final long serialVersionUID = 683717937386173692L;

  public void actionPerformed(ActionEvent e)
  {
  }
}
