/*    */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*    */ 
/*    */ public class ActionType
/*    */ {
/* 21 */   public static ActionType JMENUITEM = new ActionType();
/*    */ 
/* 23 */   public static ActionType JMENU = new ActionType();
/*    */ 
/* 25 */   public static ActionType JSEPARATOR = new ActionType();
/*    */ }
