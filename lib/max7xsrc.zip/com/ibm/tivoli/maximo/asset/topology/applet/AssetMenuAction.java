/*    */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.util.ResourceBundle;
/*    */ import javax.swing.AbstractAction;
/*    */ 















/*    */ public class AssetMenuAction extends AbstractAction
/*    */ {
/*    */   private static final long serialVersionUID = 687717977786173692L;
/*    */ 
/*    */   public AssetMenuAction(ResourceBundle bundle, String actionKey)
/*    */   {
/* 28 */     super(bundle.getString("Topology.Label." + actionKey + ".Name"));
/*    */   }
/*    */ 
/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/*    */   }
/*    */ }
