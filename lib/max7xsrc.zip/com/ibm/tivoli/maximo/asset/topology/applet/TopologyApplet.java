/*      */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.asset.ilog.applet.ShowPropertiesAction;
/*      */ import com.ibm.tivoli.maximo.asset.topology.applet.util.AssetTopologyUtil;
/*      */ import com.ibm.tivoli.maximo.asset.topology.beans.ImplTaskTargetHelper;
/*      */ import com.ibm.tivoli.maximo.asset.topology.beans.TargetHelper;
/*      */ import com.ibm.tivoli.maximo.asset.topology.constants.TopologyConstants;
/*      */ import com.ibm.tivoli.maximo.asset.topology.renderer.ImpactedTargetCellRenderer;
/*      */ import com.ibm.tivoli.maximo.asset.topology.renderer.TargetCellRenderer;
/*      */ import com.ibm.tivoli.maximo.asset.topology.renderer.TaskCellRenderer;
/*      */ import com.ibm.tivoli.maximo.util.StringUtil;
/*      */ import ilog.views.dashboard.IlvDashboardExpandablePane;
/*      */ import ilog.views.dashboard.IlvDashboardExpandableSplitPane;
/*      */ import ilog.views.diagrammer.IlvDiagrammer;
/*      */ import ilog.views.diagrammer.application.IlvDiagrammerOverview;
/*      */ import ilog.views.diagrammer.application.IlvDiagrammerViewBar;
/*      */ import ilog.views.sdm.IlvSDMEngine;
/*      */ import ilog.views.sdm.IlvSDMView;
/*      */ import ilog.views.sdm.model.IlvDefaultSDMModel;
/*      */ import ilog.views.sdm.util.IlvXMLConnector;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.ComponentOrientation;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FlowLayout;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.SystemColor;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URL;
/*      */ import java.net.URLEncoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;/*      */ import java.util.List;/*      */ import java.util.ResourceBundle;/*      */ import java.util.StringTokenizer;/*      */ import javax.swing.Action;/*      */ import javax.swing.BorderFactory;/*      */ import javax.swing.Box;/*      */ import javax.swing.BoxLayout;/*      */ import javax.swing.ButtonGroup;/*      */ import javax.swing.JButton;/*      */ import javax.swing.JComboBox;/*      */ import javax.swing.JComponent;/*      */ import javax.swing.JLabel;/*      */ import javax.swing.JList;/*      */ import javax.swing.JPanel;/*      */ import javax.swing.JRadioButton;/*      */ import javax.swing.JScrollPane;/*      */ import javax.swing.JSpinner;/*      */ import javax.swing.JSplitPane;/*      */ import javax.swing.JTextField;/*      */ import javax.swing.ListModel;/*      */ import javax.swing.SpinnerListModel;/*      */ import javax.swing.border.Border;/*      */ import javax.swing.border.LineBorder;/*      */ import javax.swing.event.ChangeEvent;/*      */ import javax.swing.event.ChangeListener;/*      */ import javax.swing.event.ListSelectionEvent;/*      */ import javax.swing.event.ListSelectionListener;/*      */ import javax.swing.text.AbstractDocument;/*      */ import javax.swing.text.AttributeSet;/*      */ import javax.swing.text.BadLocationException;/*      */ import javax.swing.text.DocumentFilter;/*      */ import javax.swing.text.DocumentFilter.FilterBypass;/*      */ 
/*      */ public class TopologyApplet extends DiagrammerApplet
/*      */   implements TopologyConstants
/*      */ {
/*   89 */   public static String NODE_ICONS_LOC = null;
/*   90 */   public static String NODE_ICONS_PATH_DEFAULT = null;
/*      */   private static final long serialVersionUID = 5536687282015761293L;
/*      */   private JSpinner graphDepthSpinner;
/*      */   private JList relationshipList;
/*      */   private JList classificationList;
/*      */   private IlvDiagrammer diagrammer;
/*      */   private ListSelectionListener classSelectListener;
/*      */   private ListSelectionListener relationSelectListener;
/*      */   private ChangeListener graphDepthChangeListener;
/*      */   private JSplitPane centerPane;
/*      */   private JTextField searchText;
/*      */   private JButton searchButton;
/*      */   private String[] topologyDepth;
/*      */   private String searchDir;
/*      */   private BidiDocumentHandler bidiHandler;
/*      */   private boolean rtlOrientation;
/*      */   private IlvDefaultSDMModel bizModel;
/*      */   private IlvDefaultSDMModel detailModel;
/*      */   protected boolean needlegend;
/*      */   private JComboBox taskList;
/*      */   private JList targetList;
/*      */   private JList imptargetList;
/*      */   private JScrollPane implistScrollPane;
/*      */   private JSplitPane impactsPane;
/*      */   private ArrayList<ImplTaskTargetHelper> tasktargets;
/*      */   private List<TargetHelper> impactedAll;
/*      */   private List<TargetHelper> targetAll;
/*      */   private String appname;
/*      */   private boolean businessModelActive;
/*      */   private JRadioButton detailButton;
/*      */   private JRadioButton bizButton;
/*      */   private String detaillSpinner;
/*      */   private String bizSpinner;
/*      */   private int bizSelectedTask;
/*      */   private int[] bizSelectedtargets;
/*      */   private int detailSelectedTask;
/*      */   private int[] detailSelectedtargets;
/*      */   private String currentAssetNumInBusinessView;
/*      */   private String currentAssetNumInDetailsView;
/*      */   private boolean firstAlreadyLoaded;
/*      */   ActionListener radioListener;
/*      */   ActionListener searchListener;
/*      */   ActionListener taskListener;
/*      */   ActionListener refreshListener;
/*      */ 
/*      */   public TopologyApplet()
/*      */   {
/*   94 */     this.graphDepthSpinner = null;
/*   95 */     this.relationshipList = null;
/*   96 */     this.classificationList = null;
/*      */ 
/*   98 */     this.diagrammer = null;
/*      */ 
/*  100 */     this.classSelectListener = new ClassificationSelectionListener();
/*  101 */     this.relationSelectListener = new RelationshipSelectionListener();
/*  102 */     this.graphDepthChangeListener = new GraphDepthChangeListener();
/*  103 */     this.centerPane = null;
/*  104 */     this.searchText = null;
/*  105 */     this.searchButton = null;
/*  106 */     this.topologyDepth = null;
/*      */ 
/*  108 */     this.searchDir = "";

/*      */ 
/*  111 */     this.bizModel = null;
/*  112 */     this.detailModel = null;
/*  113 */     this.needlegend = true;

/*      */ 
/*  116 */     this.taskList = null;
/*  117 */     this.targetList = null;
/*  118 */     this.imptargetList = null;
/*  119 */     this.implistScrollPane = null;
/*  120 */     this.impactsPane = null;
/*  121 */     this.tasktargets = new ArrayList();
/*  122 */     this.impactedAll = new ArrayList();
/*  123 */     this.targetAll = new ArrayList();
/*  124 */     this.appname = "CI";
/*  125 */     this.businessModelActive = true;
/*  126 */     this.detailButton = null;
/*  127 */     this.bizButton = null;
/*  128 */     this.detaillSpinner = "1";
/*  129 */     this.bizSpinner = "1";
/*  130 */     this.bizSelectedTask = 0;
/*  131 */     this.bizSelectedtargets = new int[] { 0 };
/*  132 */     this.detailSelectedTask = 0;
/*  133 */     this.detailSelectedtargets = new int[] { 0 };
/*      */ 
/*  135 */     this.currentAssetNumInBusinessView = "";
/*  136 */     this.currentAssetNumInDetailsView = "";
/*      */ 
/*  138 */     this.firstAlreadyLoaded = false;



/*      */   public void createGUI()
/*      */   {
/*  144 */     prepareGUI();
/*  145 */     kreateGUI();
/*  146 */     postGUI();
/*      */   }

/*      */   private void prepareGUI()
/*      */   {
/*  151 */     getContentPane().setLayout(new BorderLayout(0, 0));
/*      */ 
/*  153 */     this.rtlOrientation = Boolean.parseBoolean(getParameter("rtlOrientation"));
/*  154 */     initDepthSpinner();
/*  155 */     setAppname(getParameter("appname"));
/*      */   }




/*      */   private void kreateGUI()
/*      */   {
/*  163 */     getContentPane().add(createTopPanel(), "North");



/*      */ 
/*  168 */     this.diagrammer = new IlvDiagrammer();
/*  169 */     this.diagrammer.setSelectMode(true);
/*  170 */     this.diagrammer.setEditingAllowed(true);
/*  171 */     this.diagrammer.setMinimumZoom(0.01999999955296516D);
/*  172 */     this.diagrammer.setMaximumZoom(10.0D);
/*  173 */     this.diagrammer.getView().setBackground(Color.white);
/*  174 */     this.diagrammer.getView().setForeground(SystemColor.windowText);
/*  175 */     if (this.isRTL) {
/*  176 */       this.diagrammer.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */     }
/*      */ 
/*  179 */     if (this.rtlOrientation) {
/*  180 */       this.centerPane = new JSplitPane(1, createRightPane(), this.diagrammer);
/*      */     }
/*      */     else {
/*  183 */       this.centerPane = new JSplitPane(1, this.diagrammer, createRightPane());
/*      */     }
/*  185 */     this.centerPane.setOneTouchExpandable(true);
/*  186 */     this.centerPane.setResizeWeight(1.0D);
/*      */ 
/*  188 */     if (!(isChangeApp())) {
/*  189 */       getContentPane().add(this.centerPane, "Center");
/*      */     }
/*      */     else {
/*  192 */       this.impactsPane = new JSplitPane(0, createChangeFilters(), this.centerPane);
/*  193 */       this.impactsPane.setOneTouchExpandable(true);
/*  194 */       this.impactsPane.setDividerLocation(150);
/*  195 */       getContentPane().add(this.impactsPane, "Center");



/*      */     }
/*      */ 
/*  201 */     getContentPane().add(createBottomPanel(), "South");



/*      */ 
/*  206 */     initPopupMenus();

/*      */     try
/*      */     {
/*  210 */       URL codeBase = getCodeBase();
/*      */ 
/*  212 */       URL iconsUrl = new URL(codeBase, "../../../images/asset/topology/");
/*  213 */       this.atu.logMessage("Images URL " + iconsUrl);
/*  214 */       NODE_ICONS_LOC = iconsUrl.toString();
/*      */ 
/*  216 */       URL defaulticonsUrl = new URL(codeBase, "../../images/asset/topology/");
/*  217 */       this.atu.logMessage("Default Images URL " + defaulticonsUrl);
/*  218 */       NODE_ICONS_PATH_DEFAULT = defaulticonsUrl.toString();
/*      */ 
/*  220 */       URL styleSheetUrl = new URL(codeBase, "../../css/asttopo.css");
/*  221 */       this.atu.logMessage("Load applet CSS using URL " + styleSheetUrl);
/*  222 */       this.diagrammer.setStyleSheet(styleSheetUrl);
/*      */     }
/*      */     catch (Exception ex) {
/*  225 */       ex.printStackTrace(System.out);
/*      */     }
/*      */   }

/*      */   private void postGUI()
/*      */   {
/*  231 */     if (this.rtlOrientation) {
/*  232 */       applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */ 
/*  234 */       getContentPane().applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  235 */       this.diagrammer.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  236 */       this.centerPane.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  237 */       this.centerPane.setDividerLocation(this.centerPane.getInsets().left + this.centerPane.getDividerSize() + 200);
/*      */     }
/*      */ 
/*  240 */     if ((this.rtlOrientation) && (this.impactsPane != null))
/*  241 */       this.impactsPane.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */   }


/*      */   private void initDepthSpinner()
/*      */   {
/*  247 */     String depth = getParameter("topologydepth");
/*  248 */     this.atu.logMessage("initDepthSpinner, depth is = [" + depth + "]");
/*  249 */     int dep = 1;
/*      */     String[] temp;
/*      */     String[] temp;
/*  252 */     if ((depth != null) && (!(depth.equals("")))) {
/*  253 */       this.atu.logMessage("Depth is =" + depth);
/*  254 */       dep = Integer.parseInt(depth);
/*  255 */       temp = new String[dep];
/*      */     } else {
/*  257 */       this.atu.logMessage("Depth is null setting to some default value");
/*  258 */       temp = new String[dep];
/*      */     }
/*  260 */     for (int i = 1; i <= dep; ++i) {
/*  261 */       temp[(i - 1)] = String.valueOf(i);
/*      */     }
/*  263 */     setTopologyDepth(temp);
/*      */   }

/*      */   private void initPopupMenus() {
/*  267 */     String nodePopupTarget = getParameter("nodepopuptarget");
/*  268 */     String linkPopupTarget = getParameter("linkpopuptarget");
/*      */ 
/*  270 */     String movetopopuptarget = getParameter("movetopopuptarget");
/*      */ 
/*  272 */     if ((!(StringUtil.isEmptyString(nodePopupTarget))) || (!(StringUtil.isEmptyString(linkPopupTarget))) || (!(StringUtil.isEmptyString(movetopopuptarget))))



/*      */     {
/*  277 */       LinkedHashMap nodeActionRefs = new LinkedHashMap();




/*      */ 
/*  283 */       nodeActionRefs.put("moveto", new ActionReference(ActionType.JMENUITEM, null, new MoveToAssetAction(this.diagrammer, this, movetopopuptarget, this.bundle)));

/*      */ 
/*  286 */       nodeActionRefs.put("astdetails", new ActionReference(ActionType.JMENUITEM, null, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "DETAILS")));

/*      */ 
/*  289 */       nodeActionRefs.put("reportdowntime", new ActionReference(ActionType.JMENUITEM, null, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "REPORTDOWNTIME")));

/*      */ 
/*  292 */       nodeActionRefs.put("managedowntimehistory", new ActionReference(ActionType.JMENUITEM, null, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "MANAGEDOWNTIMEHISTORY")));

/*      */ 
/*  295 */       nodeActionRefs.put("sepcreate", new ActionReference(ActionType.JSEPARATOR, null, new AssetSeparatorAction()));
/*      */ 
/*  297 */       String submenucreate = "submenucreate";
/*  298 */       nodeActionRefs.put(submenucreate, new ActionReference(ActionType.JMENU, null, new AssetMenuAction(this.bundle, "Create")));
/*      */ 
/*  300 */       nodeActionRefs.put("servicerequest", new ActionReference(ActionType.JMENUITEM, submenucreate, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "SERVICEREQUEST")));
/*      */ 
/*  302 */       nodeActionRefs.put("incident", new ActionReference(ActionType.JMENUITEM, submenucreate, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "INCIDENT")));
/*      */ 
/*  304 */       nodeActionRefs.put("problem", new ActionReference(ActionType.JMENUITEM, submenucreate, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "PROBLEM")));
/*      */ 
/*  306 */       nodeActionRefs.put("workorder", new ActionReference(ActionType.JMENUITEM, submenucreate, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "WORKORDER")));
/*      */ 
/*  308 */       nodeActionRefs.put("change", new ActionReference(ActionType.JMENUITEM, submenucreate, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "CHANGE")));
/*      */ 
/*  310 */       nodeActionRefs.put("release", new ActionReference(ActionType.JMENUITEM, submenucreate, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "RELEASE")));

/*      */ 
/*  313 */       nodeActionRefs.put("sepview", new ActionReference(ActionType.JSEPARATOR, null, new AssetSeparatorAction()));
/*      */ 
/*  315 */       String submenuview = "submenuview";
/*  316 */       nodeActionRefs.put(submenuview, new ActionReference(ActionType.JMENU, null, new AssetMenuAction(this.bundle, "View")));
/*      */ 
/*  318 */       nodeActionRefs.put("workdetails", new ActionReference(ActionType.JMENUITEM, submenuview, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "WORKDETAILS")));
/*      */ 
/*  320 */       nodeActionRefs.put("viewcontracts", new ActionReference(ActionType.JMENUITEM, submenuview, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "VIEWCONTRACTS")));
/*      */ 
/*  322 */       nodeActionRefs.put("viewtickets", new ActionReference(ActionType.JMENUITEM, submenuview, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "VIEWTICKETS")));
/*      */ 
/*  324 */       nodeActionRefs.put("movehistory", new ActionReference(ActionType.JMENUITEM, submenuview, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "MOVEHISTORY")));
/*      */ 
/*  326 */       nodeActionRefs.put("spechistory", new ActionReference(ActionType.JMENUITEM, submenuview, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "SPECHISTORY")));
/*      */ 
/*  328 */       nodeActionRefs.put("relationshiphistory", new ActionReference(ActionType.JMENUITEM, submenuview, new AssetDetailsAction(this.diagrammer, this, nodePopupTarget, this.bundle, "RELATIONSHIPHISTORY")));

/*      */ 
/*  331 */       Action[] linkActions = null;
/*  332 */       if (!(StringUtil.isEmptyString(linkPopupTarget))) {
/*  333 */         linkActions = new Action[] { new ShowCiRelationPropertiesAction(this.diagrammer, this, linkPopupTarget, this.bundle) };

/*      */       }
/*      */ 
/*  337 */       initPopupMenus(this.diagrammer, nodeActionRefs, linkActions);
/*      */     }
/*      */     else {
/*  340 */       this.atu.logMessage("No node or link popup menu available, use default popup");
/*  341 */       Action[] actions = { new ShowPropertiesAction(this.diagrammer, this.bundle) };
/*  342 */       initPopupMenus(this.diagrammer, actions, actions);
/*      */     }
/*      */   }

/*      */   private JPanel createTopPanel()
/*      */   {
/*  348 */     JPanel topPanel = new JPanel(new FlowLayout(3));
/*      */ 
/*  350 */     this.searchText = new JTextField("", 16);
/*  351 */     topPanel.add(this.searchText);
/*  352 */     this.searchText.addActionListener(this.searchListener);
/*      */ 
/*  354 */     this.searchButton = new JButton(this.bundle.getString("Topology.Label.Search.Name"));
/*  355 */     topPanel.add(this.searchButton);
/*  356 */     this.searchButton.addActionListener(this.searchListener);
/*      */ 
/*  358 */     IlvDiagrammerViewBar toolbar = new IlvDiagrammerViewBar();
/*  359 */     topPanel.add(toolbar);

/*      */ 
/*  362 */     if (this.rtlOrientation) {
/*  363 */       toolbar.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  364 */       topPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  365 */       this.searchText.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  366 */       this.searchButton.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

/*      */     }
/*      */ 
/*  370 */     return topPanel;
/*      */   }

/*      */   private JComponent createRightPane() {
/*  374 */     IlvDiagrammerOverview overview = new IlvDiagrammerOverview();
/*  375 */     String overviewTitle = this.bundle.getString("Topology.Label.Overview.Name");
/*  376 */     IlvDashboardExpandablePane overviewFrame = new IlvDashboardExpandablePane(overviewTitle, createImageIcon("overview.gif"), overview);
/*      */ 
/*  378 */     overviewFrame.expand();
/*  379 */     String filterTitle = this.bundle.getString("Topology.Tab.Filter.Name");
/*  380 */     IlvDashboardExpandablePane other = new IlvDashboardExpandablePane(filterTitle, createImageIcon("filter.gif"), makeControlPanel(this.diagrammer.getEngine()));

/*      */ 
/*  383 */     IlvDashboardExpandableSplitPane split = new IlvDashboardExpandableSplitPane(overviewFrame, other);

/*      */ 
/*  386 */     if (this.rtlOrientation) {
/*  387 */       overview.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  388 */       overviewFrame.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  389 */       overviewFrame.setAlignmentX(1.0F);
/*  390 */       other.setAlignmentX(1.0F);
/*  391 */       other.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  392 */       split.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */     }
/*      */ 
/*  395 */     split.setDividerLocation(100);
/*  396 */     split.setMinimumSize(new Dimension(150, split.getMinimumSize().height));
/*  397 */     return split;
/*      */   }

/*      */   private JPanel createChangeFilters() {
/*  401 */     JPanel changeFilters = new JPanel(new FlowLayout(0));
/*      */ 
/*  403 */     this.taskList = new JComboBox();
/*  404 */     this.taskList.addActionListener(this.taskListener);
/*  405 */     this.taskList.setRenderer(new TaskCellRenderer());
/*      */ 
/*  407 */     JPanel tasksPanel = new JPanel();
/*  408 */     tasksPanel.setPreferredSize(new Dimension(150, 50));
/*  409 */     tasksPanel.setLayout(new BoxLayout(tasksPanel, 3));
/*  410 */     tasksPanel.setBorder(BorderFactory.createTitledBorder(this.bundle.getString("IA.Tasks.Label.name")));
/*  411 */     this.taskList.setAlignmentX(0.0F);
/*  412 */     tasksPanel.add(this.taskList);

/*      */ 
/*  415 */     this.targetList = new JList();
/*  416 */     this.targetList.setSelectionMode(2);
/*  417 */     this.targetList.setCellRenderer(new TargetCellRenderer());
/*  418 */     this.targetList.setVisibleRowCount(5);
/*  419 */     JScrollPane listScrollPane = new JScrollPane(this.targetList);
/*  420 */     listScrollPane.setPreferredSize(new Dimension(300, 100));
/*  421 */     listScrollPane.setViewportBorder(new LineBorder(Color.BLACK));
/*      */ 
/*  423 */     JPanel targetPanel = new JPanel();
/*  424 */     targetPanel.setLayout(new BoxLayout(targetPanel, 3));
/*  425 */     listScrollPane.setAlignmentX(0.0F);
/*  426 */     targetPanel.add(listScrollPane);
/*  427 */     targetPanel.setBorder(BorderFactory.createTitledBorder(this.bundle.getString("IA.TaskTargets.Label.name")));

/*      */ 
/*  430 */     this.imptargetList = new JList();
/*  431 */     this.imptargetList.setSelectionMode(2);
/*  432 */     this.imptargetList.setCellRenderer(new ImpactedTargetCellRenderer());
/*  433 */     this.imptargetList.setEnabled(false);
/*  434 */     this.imptargetList.setVisibleRowCount(5);
/*  435 */     this.implistScrollPane = new JScrollPane(this.imptargetList);
/*  436 */     this.implistScrollPane.setPreferredSize(new Dimension(300, 100));
/*  437 */     this.implistScrollPane.setViewportBorder(new LineBorder(Color.BLACK));
/*  438 */     this.imptargetList.setBackground(ImpactedTargetCellRenderer.LIGHT_GRAY);

/*      */ 
/*  441 */     JPanel impactedTargetPanel = new JPanel();
/*  442 */     impactedTargetPanel.setLayout(new BoxLayout(impactedTargetPanel, 3));
/*      */ 
/*  444 */     impactedTargetPanel.setBackground(new Color(224, 224, 224));
/*  445 */     this.implistScrollPane.setAlignmentX(0.0F);
/*  446 */     impactedTargetPanel.add(this.implistScrollPane);
/*  447 */     impactedTargetPanel.setBorder(BorderFactory.createTitledBorder(this.bundle.getString("IA.TaskImpactedTargets.Label.name")));

/*      */ 
/*  450 */     JButton refreshButton = new JButton(this.bundle.getString("IA.RefreshButton.name"));
/*  451 */     refreshButton.addActionListener(this.refreshListener);
/*  452 */     GridBagConstraints c = new GridBagConstraints();
/*  453 */     c.fill = 3;
/*  454 */     c.gridx = 0;
/*  455 */     c.gridy = 0;
/*  456 */     changeFilters.add(tasksPanel, c);
/*  457 */     c.gridx = 1;
/*  458 */     c.gridy = 0;
/*  459 */     changeFilters.add(targetPanel, c);
/*  460 */     c.gridx = 2;
/*  461 */     c.gridy = 0;
/*  462 */     changeFilters.add(impactedTargetPanel, c);
/*  463 */     c.gridx = 3;
/*  464 */     c.gridy = 0;
/*  465 */     changeFilters.add(refreshButton, c);
/*  466 */     changeFilters.setBorder(BorderFactory.createTitledBorder(""));

/*      */ 
/*  469 */     if (this.rtlOrientation) {
/*  470 */       changeFilters.setLayout(new FlowLayout(2));
/*      */ 
/*  472 */       listScrollPane.setAlignmentX(1.0F);
/*  473 */       this.implistScrollPane.setAlignmentX(1.0F);
/*  474 */       this.taskList.setAlignmentX(1.0F);
/*      */ 
/*  476 */       changeFilters.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  477 */       this.taskList.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  478 */       tasksPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  479 */       listScrollPane.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */ 
/*  481 */       targetPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  482 */       this.targetList.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  483 */       this.imptargetList.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  484 */       this.implistScrollPane.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  485 */       impactedTargetPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  486 */       refreshButton.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */     }
/*      */ 
/*  489 */     return changeFilters;
/*      */   }

/*      */   private JPanel createBottomPanel()
/*      */   {
/*  494 */     JPanel bottomPanel = new JPanel(new FlowLayout(3));












/*      */ 
/*  508 */     this.detailButton = new JRadioButton(this.bundle.getString("Topology.Radio.Detail.Name"));
/*  509 */     this.detailButton.setActionCommand("DETAIL");
/*  510 */     this.detailButton.addActionListener(this.radioListener);
/*      */ 
/*  512 */     this.bizButton = new JRadioButton(this.bundle.getString("Topology.Radio.Business.Name"));
/*  513 */     this.bizButton.setActionCommand("BUSINESS");
/*  514 */     this.bizButton.addActionListener(this.radioListener);

/*      */ 
/*  517 */     ButtonGroup group = new ButtonGroup();
/*  518 */     group.add(this.bizButton);
/*  519 */     group.add(this.detailButton);
/*      */ 
/*  521 */     JPanel radioPanel = new JPanel(new GridBagLayout());
/*      */ 
/*  523 */     radioPanel.add(this.bizButton);
/*  524 */     radioPanel.add(this.detailButton);
/*  525 */     radioPanel.setBorder(BorderFactory.createTitledBorder(""));
/*  526 */     bottomPanel.add(radioPanel);
/*      */ 
/*  528 */     if (isActciApp()) {
/*  529 */       this.detailButton.setEnabled(false);
/*  530 */       this.bizButton.setEnabled(false);
/*  531 */       this.detailButton.setSelected(true);
/*      */     } else {
/*  533 */       this.bizButton.setSelected(true);
/*      */     }
/*      */ 
/*  536 */     if (this.needlegend) {
/*  537 */       int dim = 30;
/*  538 */       bottomPanel.add(createStatusLengend(dim));
/*  539 */       bottomPanel.add(createTaskIndictorLengend(dim));

/*      */     }
/*      */ 
/*  543 */     if (this.rtlOrientation)
/*      */     {
/*  545 */       this.detailButton.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  546 */       this.bizButton.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  547 */       radioPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  548 */       bottomPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

/*      */     }
/*      */ 
/*  552 */     return bottomPanel;
/*      */   }

/*      */   private JPanel createStatusLengend(int dim)
/*      */   {
/*  557 */     JPanel statusLegendPanel = new JPanel(new FlowLayout(3));
/*  558 */     Border border = BorderFactory.createEtchedBorder();
/*  559 */     statusLegendPanel.setBorder(border);

/*      */ 
/*  562 */     statusLegendPanel.add(new JLabel(this.bundle.getString("IA.Legend.Status.Start")));

/*      */ 
/*  565 */     JLabel operatingStatus = new JLabel(createImageIcon("st_operating.jpeg"));
/*  566 */     statusLegendPanel.add(operatingStatus);
/*  567 */     operatingStatus.setPreferredSize(new Dimension(dim, dim));
/*  568 */     operatingStatus.setToolTipText(this.bundle.getString("IA.Legend.operatingstatus.tooltip"));

/*      */ 
/*  571 */     JLabel notReadyStatus = new JLabel(createImageIcon("st_notReady.jpeg"));
/*  572 */     statusLegendPanel.add(notReadyStatus);
/*  573 */     notReadyStatus.setPreferredSize(new Dimension(dim, dim));
/*  574 */     notReadyStatus.setToolTipText(this.bundle.getString("IA.Legend.notreadystatus.tooltip"));

/*      */ 
/*  577 */     JLabel decommissionedStatus = new JLabel(createImageIcon("st_decommissioned.jpeg"));
/*  578 */     statusLegendPanel.add(decommissionedStatus);
/*  579 */     decommissionedStatus.setPreferredSize(new Dimension(dim, dim));
/*  580 */     decommissionedStatus.setToolTipText(this.bundle.getString("IA.Legend.decommissionedstatus.tooltip"));
/*      */ 
/*  582 */     if (this.rtlOrientation) {
/*  583 */       statusLegendPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  584 */       operatingStatus.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  585 */       notReadyStatus.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  586 */       decommissionedStatus.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */     }
/*      */ 
/*  589 */     return statusLegendPanel;
/*      */   }

/*      */   private JPanel createTaskIndictorLengend(int dim)
/*      */   {
/*  594 */     JPanel taskIndicatorLegendPanel = new JPanel(new FlowLayout(3));
/*  595 */     Border border = BorderFactory.createEtchedBorder();
/*  596 */     taskIndicatorLegendPanel.setBorder(border);
/*  597 */     int minWidth = 35;
/*      */ 
/*  599 */     if (minWidth > taskIndicatorLegendPanel.getPreferredSize().getWidth());




/*  604 */     taskIndicatorLegendPanel.add(new JLabel(this.bundle.getString("IA.Legend.TaskIndicator.Start")));

/*      */ 
/*  607 */     JLabel firstweekwi = new JLabel(createImageIcon("wi_1stweek.jpeg"));
/*  608 */     taskIndicatorLegendPanel.add(firstweekwi);
/*  609 */     firstweekwi.setPreferredSize(new Dimension(dim, dim));
/*  610 */     firstweekwi.setToolTipText(this.bundle.getString("IA.Legend.firstweektaskindictor.tooltip"));

/*      */ 
/*  613 */     JLabel secondweekwi = new JLabel(createImageIcon("wi_2ndweek.jpeg"));
/*  614 */     taskIndicatorLegendPanel.add(secondweekwi);
/*  615 */     secondweekwi.setPreferredSize(new Dimension(dim, dim));
/*  616 */     secondweekwi.setToolTipText(this.bundle.getString("IA.Legend.secondweekstaskindictor.tooltip"));

/*      */ 
/*  619 */     JLabel thirdweekwi = new JLabel(createImageIcon("wi_3rdweek.jpeg"));
/*  620 */     taskIndicatorLegendPanel.add(thirdweekwi);
/*  621 */     thirdweekwi.setPreferredSize(new Dimension(dim, dim));
/*  622 */     thirdweekwi.setToolTipText(this.bundle.getString("IA.Legend.thirdweekstaskindictor.tooltip"));

/*      */ 
/*  625 */     JLabel fourweekspluskwi = new JLabel(createImageIcon("wi_4weeksplus.jpeg"));
/*  626 */     taskIndicatorLegendPanel.add(fourweekspluskwi);
/*  627 */     fourweekspluskwi.setPreferredSize(new Dimension(dim, dim));
/*  628 */     fourweekspluskwi.setToolTipText(this.bundle.getString("IA.Legend.fourweeksplustaskindictor.tooltip"));

/*      */ 
/*  631 */     JLabel notscheduledyetwi = new JLabel(createImageIcon("wi_noschedyet.jpeg"));
/*  632 */     taskIndicatorLegendPanel.add(notscheduledyetwi);
/*  633 */     notscheduledyetwi.setPreferredSize(new Dimension(dim, dim));
/*  634 */     notscheduledyetwi.setToolTipText(this.bundle.getString("IA.Legend.notschedyettaskindictor.tooltip"));

/*      */ 
/*  637 */     JLabel pastduewi = new JLabel(createImageIcon("wi_pastdue.jpeg"));
/*  638 */     taskIndicatorLegendPanel.add(pastduewi);
/*  639 */     pastduewi.setPreferredSize(new Dimension(dim, dim));
/*  640 */     pastduewi.setToolTipText(this.bundle.getString("IA.Legend.pastduetaskindictor.tooltip"));
/*      */ 
/*  642 */     if (this.rtlOrientation) {
/*  643 */       taskIndicatorLegendPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  644 */       firstweekwi.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  645 */       secondweekwi.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  646 */       thirdweekwi.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  647 */       fourweekspluskwi.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  648 */       notscheduledyetwi.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  649 */       pastduewi.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */     }
/*      */ 
/*  652 */     return taskIndicatorLegendPanel;
/*      */   }
/*      */ 
/*  655 */     this.radioListener = new ActionListener() {
/*      */       public void actionPerformed(ActionEvent actionEvent) {
/*  657 */         TopologyApplet.this.atu.logMessage("Clicked on the radio button" + actionEvent.getActionCommand());
/*      */ 
/*  659 */         if (actionEvent.getActionCommand().equals("BUSINESS")) {
/*  660 */           TopologyApplet.this.atu.logMessage("Radio: Show Business View");

/*      */ 
/*  663 */           if (TopologyApplet.this.isBusinessModelActive()) {
/*  664 */             return;

/*      */           }
/*      */ 
/*  668 */           if (TopologyApplet.this.getBizModel() == null) {
/*  669 */             TopologyApplet.this.loadBizModel(TopologyApplet.access$200(TopologyApplet.this));
/*  670 */             return;

/*      */           }
/*      */ 
/*  674 */           if (TopologyApplet.this.isBothViewsOnTheSameAssetNum() == 0) {
/*  675 */             TopologyApplet.this.loadModel(TopologyApplet.this.getSpinnerValue(), TopologyApplet.this.getCurrentAssetNumInDetailsView(), false);
/*  676 */             return;



/*      */           }
/*      */ 
/*  682 */           TopologyApplet.this.applyExistingModel(ModelType.BUSINESS);
/*      */         }
/*      */         else {
/*  685 */           TopologyApplet.this.atu.logMessage("Radio: Show Details View");

/*      */ 
/*  688 */           if (!(TopologyApplet.this.isBusinessModelActive())) {
/*  689 */             return;

/*      */           }
/*      */ 
/*  693 */           if (TopologyApplet.this.getDetailModel() == null) {
/*  694 */             TopologyApplet.this.loadDetailsModel(TopologyApplet.access$200(TopologyApplet.this));
/*  695 */             return;

/*      */           }
/*      */ 
/*  699 */           if (TopologyApplet.this.isBothViewsOnTheSameAssetNum() == 0) {
/*  700 */             TopologyApplet.this.loadModel(TopologyApplet.this.getSpinnerValue(), TopologyApplet.this.getCurrentAssetNumInBusinessView(), true);
/*  701 */             return;



/*      */           }
/*      */ 
/*  707 */           TopologyApplet.this.applyExistingModel(ModelType.DEATAILS);



/*      */   private boolean isBothViewsOnTheSameAssetNum()
/*      */   {
/*  713 */     return getCurrentAssetNumInBusinessView().equals(getCurrentAssetNumInDetailsView());
/*      */   }




/*      */   private void applyExistingModel(ModelType modelType)
/*      */   {
/*  721 */     this.graphDepthSpinner.removeChangeListener(this.graphDepthChangeListener);
/*      */ 
/*  723 */     IlvDefaultSDMModel workModel = null;
/*  724 */     if (modelType == ModelType.BUSINESS) {
/*  725 */       workModel = getBizModel();
/*  726 */       this.graphDepthSpinner.setValue(getBizSpinner());
/*  727 */       setBusinessModelActive(true);
/*      */     }
/*      */     else {
/*  730 */       workModel = getDetailModel();
/*  731 */       this.graphDepthSpinner.setValue(getDetaillSpinner());
/*  732 */       setBusinessModelActive(false);
/*      */     }
/*      */ 
/*  735 */     this.graphDepthSpinner.addChangeListener(this.graphDepthChangeListener);



/*      */ 
/*      */         }/*  740 */     fitModel(workModel);/*      */   }
/*      */       }
/*      */     };
/*  743 */     this.searchListener = new ActionListener()
/*      */     {
/*      */       public void actionPerformed(ActionEvent actionEvent)
/*      */       {
/*  747 */         String text = TopologyApplet.this.searchText.getText();
/*  748 */         TopologyApplet.this.atu.logMessage("in action, got the seach text [" + text + "]");
/*  749 */         TopologyApplet.this.reloadModelSearched(text);

/*      */       }
/*      */     };
/*  753 */     this.taskListener = new ActionListener()

/*      */     {
/*      */       public void actionPerformed(ActionEvent actionEvent)
/*      */       {
/*  758 */         TopologyApplet.this.atu.logMessage("Inside task Listener");
/*  759 */         int sel = TopologyApplet.this.taskList.getSelectedIndex();
/*  760 */         TopologyApplet.this.atu.logMessage("Selected Index" + sel);
/*  761 */         if (sel >= 0) {
/*  762 */           TopologyApplet.this.populateTargetsForTask(sel);
/*  763 */           IlvDefaultSDMModel model = (IlvDefaultSDMModel)TopologyApplet.this.getDiagrammer().getEngine().getModel();
/*  764 */           TopologyApplet.this.markImpactedCIsNotInTopology(model);

/*      */         }
/*      */       }
/*      */     };
/*  769 */     this.refreshListener = new ActionListener()

/*      */     {
/*      */       public void actionPerformed(ActionEvent actionEvent)
/*      */       {
/*  774 */         TopologyApplet.this.reloadModel();
/*      */       }
/*      */     };
/*      */   }
/*      */   private void populateTargetsForTask(int selectedIndex)/*      */   {
/*  779 */     this.atu.logMessage("Inside populateTargetsForTask");
/*  780 */     this.atu.logMessage("Populate targets for --> " + selectedIndex);
/*      */ 
/*  782 */     if (!(this.tasktargets.isEmpty())) {
/*  783 */       this.atu.logMessage("Not Empty");
/*      */ 
/*  785 */       if (selectedIndex == 0) {
/*  786 */         if (!(this.targetAll.isEmpty())) this.targetList.setListData(this.targetAll.toArray());
/*      */ 
/*  788 */         if (this.targetAll.size() != 0) this.targetList.setSelectedIndex(0);
/*  789 */         if (this.impactedAll.isEmpty()) return; this.imptargetList.setListData(this.impactedAll.toArray());
/*      */       } else {
/*  791 */         ImplTaskTargetHelper helper = (ImplTaskTargetHelper)this.tasktargets.get(selectedIndex - 1);
/*  792 */         this.atu.logMessage("Not Empty--> " + helper.getTaskWonum());
/*  793 */         this.targetList.setListData(helper.getTaskTargetsList().toArray());
/*      */ 
/*  795 */         if (helper.getTaskTargetsList().size() != 0) this.targetList.setSelectedIndex(0);
/*  796 */         this.imptargetList.setListData(helper.getTaskTargetsImpactedList().toArray());
/*      */       }
/*      */     }
/*      */   }


/*      */   private JComponent makeControlPanel(IlvSDMEngine engine)
/*      */   {
/*  804 */     JPanel p = new JPanel();
/*  805 */     p.setLayout(new BorderLayout());
/*      */ 
/*  807 */     Box box1 = Box.createVerticalBox();
/*      */ 
/*  809 */     this.relationshipList = new JList();
/*  810 */     this.relationshipList.setSelectionMode(2);
/*  811 */     this.relationshipList.setLayoutOrientation(0);
/*  812 */     this.relationshipList.addListSelectionListener(this.relationSelectListener);
/*  813 */     JScrollPane listScroller = new JScrollPane(this.relationshipList);
/*      */ 
/*  815 */     JPanel listPane = new JPanel();
/*  816 */     listPane.setLayout(new BoxLayout(listPane, 3));
/*  817 */     listPane.add(Box.createHorizontalGlue());
/*  818 */     listPane.add(listScroller);
/*  819 */     listPane.setBorder(BorderFactory.createTitledBorder(this.bundle.getString("Topology.Label.Showrelations.Name")));
/*      */ 
/*  821 */     listPane.setPreferredSize(new Dimension(200, 5));
/*  822 */     box1.add(listPane);
/*      */ 
/*  824 */     this.classificationList = new JList();
/*  825 */     this.classificationList.setSelectionMode(2);
/*  826 */     this.classificationList.setLayoutOrientation(0);
/*  827 */     this.classificationList.addListSelectionListener(this.classSelectListener);
/*  828 */     JScrollPane listScroller1 = new JScrollPane(this.classificationList);
/*      */ 
/*  830 */     JPanel listPane1 = new JPanel();
/*  831 */     listPane1.setLayout(new BoxLayout(listPane1, 3));
/*  832 */     listPane1.add(listScroller1);
/*  833 */     listPane1.setBorder(BorderFactory.createTitledBorder(this.bundle.getString("Topology.Label.Showclassification.Name")));
/*      */ 
/*  835 */     listPane1.setPreferredSize(new Dimension(200, 5));
/*      */ 
/*  837 */     box1.add(listPane1);

/*      */ 
/*  840 */     SpinnerListModel sp = new SpinnerListModel(getTopologyDepth());
/*  841 */     this.graphDepthSpinner = new JSpinner(sp);
/*  842 */     this.graphDepthSpinner.addChangeListener(this.graphDepthChangeListener);
/*      */ 
/*  844 */     JPanel spinnerPanel = new JPanel();
/*  845 */     spinnerPanel.setLayout(new BorderLayout());
/*  846 */     spinnerPanel.setBorder(BorderFactory.createTitledBorder(this.bundle.getString("Topology.Label.Depth.Name")));
/*      */ 
/*  848 */     spinnerPanel.add(this.graphDepthSpinner, "Center");
/*      */ 
/*  850 */     p.add(spinnerPanel, "North");
/*  851 */     p.add(box1, "Center");

/*      */ 
/*  854 */     if (this.rtlOrientation)
/*      */     {
/*  856 */       p.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  857 */       this.relationshipList.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  858 */       this.classificationList.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  859 */       this.graphDepthSpinner.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  860 */       box1.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  861 */       this.relationshipList.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  862 */       listScroller.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  863 */       listPane.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  864 */       this.classificationList.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  865 */       listScroller1.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  866 */       listPane1.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  867 */       this.graphDepthSpinner.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  868 */       spinnerPanel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);


/*      */     }
/*      */ 
/*  873 */     return p;
/*      */   }



/*      */   public void loadModel(boolean isInitialLoadRequired)
/*      */   {
/*  880 */     if ((!(isFirstAlreadyLoaded())) || (isInitialLoadRequired)) {
/*  881 */       firstLoadModel();
/*  882 */       setFirstAlreadyLoaded(true);
/*  883 */       return;
/*      */     }
/*  885 */     reloadModel();
/*      */   }

/*      */   private void firstLoadModel()
/*      */   {
/*  890 */     clearEverything();
/*      */ 
/*  892 */     this.graphDepthSpinner.removeChangeListener(this.graphDepthChangeListener);
/*  893 */     this.graphDepthSpinner.setValue(getInitialNodeDepth());
/*  894 */     this.graphDepthSpinner.addChangeListener(this.graphDepthChangeListener);
/*      */ 
/*  896 */     if (isChangeApp()) {
/*  897 */       loadImpactAssesmentFiltersData();
/*      */     }
/*  899 */     if (isActciApp()) {
/*  900 */       loadDetailsModel(getInitialNodeDepth());
/*      */     }
/*      */     else {
/*  903 */       loadBizModel(getInitialNodeDepth());
/*      */     }
/*      */ 
/*  906 */     this.searchDir = "";
/*  907 */     if ((this.isBidi) && (this.searchDir.length() > 0))
/*  908 */       if (this.searchDir.equalsIgnoreCase("LTR")) {
/*  909 */         this.searchText.applyComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
/*  910 */       } else if (this.searchDir.equalsIgnoreCase("RTL")) {
/*  911 */         this.searchText.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*  912 */       } else if (this.searchDir.equalsIgnoreCase("CONTEXTUAL")) {
/*  913 */         this.bidiHandler = new BidiDocumentHandler();
/*  914 */         ((AbstractDocument)this.searchText.getDocument()).setDocumentFilter(this.bidiHandler);
/*      */       }
/*      */   }

/*      */   private void loadBizModel(String depth)
/*      */   {
/*  920 */     this.atu.logMessage("Reloading Business model");
/*  921 */     loadModel(depth, "", false);
/*      */   }

/*      */   private void loadDetailsModel(String depth) {
/*  925 */     this.atu.logMessage("Reloading Details model");
/*  926 */     loadModel(depth, "", true);
/*      */   }

/*      */   protected void loadModel(String depth, String assetnum, boolean isDetailedView) {
/*  930 */     IlvDefaultSDMModel workModel = new IlvDefaultSDMModel();
/*      */     try
/*      */     {
/*  933 */       String[] argNames = { "graphdepth", "detailview", "assetnum" };
/*  934 */       String[] argValues = { depth, (isDetailedView) ? "true" : "false", assetnum };
/*      */ 
/*  936 */       URL servletUrl = getControlServletURL(argNames, argValues);
/*      */ 
/*  938 */       this.atu.logMessage("Load applet model using URL " + servletUrl);
/*  939 */       IlvXMLConnector xmlConnector = new IlvXMLConnector();





/*      */ 
/*  946 */       xmlConnector.readXML(workModel, servletUrl.openStream(), false, null);
/*      */     } catch (Exception ex) {
/*  948 */       ex.printStackTrace(System.out);




/*      */     }
/*      */ 
/*  955 */     if (!(StringUtil.isEmptyString(this.searchText.getText()))) {
/*  956 */       updateModelWithSearchText(workModel, this.searchText.getText());



/*      */     }
/*      */ 
/*  962 */     fitModel(workModel);


/*      */ 
/*  966 */     if (isDetailedView) {
/*  967 */       setDetailModel(workModel);
/*  968 */       setDetailSpinner(depth);
/*  969 */       setBusinessModelActive(false);
/*  970 */       setCurrentAssetNumInDetailsView(assetnum);
/*      */     }
/*      */     else {
/*  973 */       setBizModel(workModel);
/*  974 */       setBizSpinner(depth);
/*  975 */       setBusinessModelActive(true);
/*  976 */       setCurrentAssetNumInBusinessView(assetnum);
/*      */     }
/*      */   }









/*      */   private void fitModel(IlvDefaultSDMModel workModel)
/*      */   {
/*  990 */     getDiagrammer().getEngine().setModel(workModel);
/*  991 */     getDiagrammer().alignHorizontalCenter();
/*  992 */     fitToContents(getDiagrammer());
/*  993 */     populateRelationshipList(workModel);
/*  994 */     populateClassificationList(workModel);
/*      */   }

/*      */   private void reloadModel()
/*      */   {
/*  999 */     if (isBusinessModelActive()) {
/* 1000 */       loadModel(getSpinnerValue(), getCurrentAssetNumInBusinessView(), false);
/* 1001 */       return;
/*      */     }
/* 1003 */     loadModel(getSpinnerValue(), getCurrentAssetNumInDetailsView(), true);
/*      */   }

/*      */   private void fitToContents(IlvDiagrammer diagrammer)
/*      */   {
/* 1008 */     this.atu.logMessage("fitModel");
/* 1009 */     IlvDefaultSDMModel model = (IlvDefaultSDMModel)diagrammer.getEngine().getModel();
/* 1010 */     Enumeration en = model.getObjects();
/* 1011 */     int nodeSize = 0;
/* 1012 */     while (en.hasMoreElements()) {
/* 1013 */       if (!(model.isLink(en.nextElement())));
/* 1014 */       ++nodeSize;
/*      */     }
/*      */ 
/* 1017 */     if (nodeSize >= 5) {
/* 1018 */       this.atu.logMessage("Number of nodes Greater than 5 -->" + nodeSize);
/* 1019 */       diagrammer.fitToContents();
/*      */     } else {
/* 1021 */       this.atu.logMessage("Number of nodes Lesser than 5 -->" + nodeSize);
/*      */     }
/*      */   }



/*      */   public void markImpactedCIsNotInTopology(IlvDefaultSDMModel model)
/*      */   {
/* 1029 */     this.atu.logMessage("markImpactedCIsNotInTopology");
/*      */ 
/* 1031 */     if (this.impactedAll.size() == 0) return;
/*      */ 
/* 1033 */     Hashtable impactedAllHashTbl = new Hashtable();
/*      */ 
/* 1035 */     for (int i = 0; i < this.impactedAll.size(); ++i) {
/* 1036 */       TargetHelper target = (TargetHelper)this.impactedAll.get(i);
/* 1037 */       impactedAllHashTbl.put(target.getCinum(), Integer.valueOf(i));
/*      */     }
/*      */ 
/* 1040 */     HashSet targetsSelected = getSelectedTargetsHash();


/*      */ 
/* 1044 */     Enumeration en = model.getObjects();
/* 1045 */     while (en.hasMoreElements())
/*      */     {
/* 1047 */       Object item = en.nextElement();
/*      */ 
/* 1049 */       if (!(model.isLink(item)))
/*      */       {
/* 1051 */         String name = (String)model.getObjectProperty(item, "cinum");
/* 1052 */         this.atu.logMessage("markImpactedCIsNotInTopology: Inside Loop" + name);
/* 1053 */         if (impactedAllHashTbl.containsKey(name))
/*      */         {
/* 1055 */           impactedAllHashTbl.remove(name);

/*      */         }
/*      */ 
/* 1059 */         if (targetsSelected.contains(name)) {
/* 1060 */           this.atu.logMessage("This is root node mark it again" + name);
/* 1061 */           model.setObjectProperty(item, "root", Boolean.valueOf(true));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1068 */     int[] selected = new int[impactedAllHashTbl.size()];
/* 1069 */     Enumeration e = impactedAllHashTbl.elements();
/* 1070 */     for (int j = 0; e.hasMoreElements(); ++j)
/*      */     {
/* 1072 */       selected[j] = ((Integer)e.nextElement()).intValue();
/*      */     }
/*      */ 
/* 1075 */     this.imptargetList.setSelectedIndices(selected);
/*      */   }




/*      */   public HashSet<String> getSelectedTargetsHash()
/*      */   {
/* 1083 */     Object[] selectedTargets = this.targetList.getSelectedValues();
/* 1084 */     HashSet set = new HashSet(selectedTargets.length);

/*      */ 
/* 1087 */     for (int i = 0; i < selectedTargets.length; ++i) {
/* 1088 */       TargetHelper t = (TargetHelper)selectedTargets[i];
/* 1089 */       this.atu.logMessage("Selected value = " + t.getCinum() + "<--i=-->" + i);
/* 1090 */       set.add((!(this.isBidi)) ? t.getCinum() : removeMarkers(t.getCinum()));
/*      */     }
/*      */ 
/* 1093 */     return set;
/*      */   }


/*      */   private void loadImpactAssesmentFiltersData()
/*      */   {
/* 1099 */     String pref = (this.isRTL) ? "‏" : "‎";
/*      */     try {
/* 1101 */       URL servletUrl = getControlServletURL(new String[] { "taskTargets" }, new String[] { "true" });
/* 1102 */       this.atu.logMessage("Load applet model using URL " + servletUrl);
/* 1103 */       ObjectInputStream in = new ObjectInputStream(servletUrl.openStream());
/* 1104 */       this.tasktargets = ((ArrayList)in.readObject());
/*      */     } catch (Exception ex) {
/* 1106 */       ex.printStackTrace();
/*      */     }
/*      */ 
/* 1109 */     this.taskList.removeAllItems();
/* 1110 */     this.targetAll.clear();
/* 1111 */     this.impactedAll.clear();
/* 1112 */     this.imptargetList.setListData(this.impactedAll.toArray());
/* 1113 */     this.targetList.setListData(this.targetAll.toArray());

/*      */ 
/* 1116 */     if (!(this.tasktargets.isEmpty())) {
/* 1117 */       this.atu.logMessage("Array Count = " + this.tasktargets.size());
/*      */ 
/* 1119 */       this.taskList.removeActionListener(this.taskListener);
/* 1120 */       this.taskList.addItem(this.bundle.getString("IA.AllTasks.name"));
/* 1121 */       for (int i = 0; i < this.tasktargets.size(); ++i) {
/* 1122 */         ImplTaskTargetHelper helper = (ImplTaskTargetHelper)this.tasktargets.get(i);
/* 1123 */         if (!(this.isBidi))
/* 1124 */           this.taskList.addItem(helper.getTaskWonum() + "|" + helper.getDescription());
/*      */         else
/* 1126 */           this.taskList.addItem(pref + helper.getTaskWonum() + pref + "|" + pref + helper.getDescription());
/* 1127 */         this.atu.logMessage("First Item = " + helper.getTaskWonum() + helper.getDescription());
/* 1128 */         this.impactedAll.addAll(helper.getTaskTargetsImpactedList());
/* 1129 */         this.targetAll.addAll(helper.getTaskTargetsList());
/*      */       }
/*      */ 
/* 1132 */       this.imptargetList.setListData(this.impactedAll.toArray());
/* 1133 */       this.targetList.setListData(this.targetAll.toArray());
/*      */ 
/* 1135 */       if (!(this.targetAll.isEmpty())) {
/* 1136 */         int[] selected = new int[this.targetAll.size()];
/* 1137 */         for (int j = 0; j < this.targetAll.size(); ++j) {
/* 1138 */           selected[j] = j;
/*      */         }
/* 1140 */         this.targetList.setSelectedIndices(selected);

/*      */       }
/*      */ 
/* 1144 */       this.taskList.addActionListener(this.taskListener);
/*      */     }
/*      */   }

/*      */   private String getSelectedTargets() throws UnsupportedEncodingException
/*      */   {
/* 1150 */     Object[] selectedTargets = this.targetList.getSelectedValues();
/* 1151 */     StringBuffer result = new StringBuffer();
/*      */ 
/* 1153 */     if (selectedTargets.length > 0) {
/* 1154 */       TargetHelper t = (TargetHelper)selectedTargets[0];
/* 1155 */       String cinum = (!(this.isBidi)) ? t.getCinum() : removeMarkers(t.getCinum());
/* 1156 */       result.append(URLEncoder.encode(cinum, "UTF-8"));
/* 1157 */       for (int i = 1; i < selectedTargets.length; ++i) {
/* 1158 */         result.append(URLEncoder.encode(",", "UTF-8"));
/* 1159 */         t = (TargetHelper)selectedTargets[i];
/* 1160 */         cinum = (!(this.isBidi)) ? t.getCinum() : removeMarkers(t.getCinum());
/* 1161 */         result.append(URLEncoder.encode(cinum, "UTF-8"));
/*      */       }
/*      */     }
/* 1164 */     return result.toString();
/*      */   }




/*      */   public void reloadModelSearched(String searchtext)
/*      */   {
/* 1172 */     IlvDefaultSDMModel model = (IlvDefaultSDMModel)getDiagrammer().getEngine().getModel();
/* 1173 */     updateModelWithSearchText(model, searchtext);
/* 1174 */     getDiagrammer().getEngine().setModel(model);
/*      */   }

/*      */   private void updateModelWithSearchText(IlvDefaultSDMModel model, String searchtext) {
/* 1178 */     Enumeration en = model.getObjects();
/*      */ 
/* 1180 */     while (en.hasMoreElements()) {
/* 1181 */       Object item = en.nextElement();
/* 1182 */       String desc = (String)model.getObjectProperty(item, "description");
/* 1183 */       if (StringUtil.isEmptyString(searchtext)) continue; if (!(StringUtil.isEmptyString(desc)));
/* 1184 */       if (desc.toLowerCase().indexOf(searchtext.toLowerCase()) >= 0) {
/* 1185 */         this.atu.logMessage("Search Matched " + desc);
/* 1186 */         model.setObjectProperty(item, "searchmatch", Boolean.valueOf(true));
/*      */       }
/*      */       else {
/* 1189 */         this.atu.logMessage("Resetting the rest to false ");
/* 1190 */         model.setObjectProperty(item, "searchmatch", Boolean.valueOf(false));
/*      */       }
/*      */     }
/*      */   }

/*      */   private void populateRelationshipList(IlvDefaultSDMModel model)
/*      */   {
/* 1197 */     HashSet relationships = new HashSet();
/* 1198 */     Enumeration en = model.getObjects();
/* 1199 */     while (en.hasMoreElements()) {
/* 1200 */       Object item = en.nextElement();
/* 1201 */       if (model.isLink(item)) {
/* 1202 */         String relation = (String)model.getObjectProperty(item, "relation");
/* 1203 */         StringTokenizer st = new StringTokenizer(relation, ",");
/* 1204 */         while (st.hasMoreTokens())
/*      */         {
/* 1206 */           relationships.add(st.nextToken());
/*      */         }
/*      */       }
/*      */     }
/* 1210 */     String[] relationshipArray = new String[relationships.size() + 1];
/* 1211 */     Iterator it = relationships.iterator();
/* 1212 */     relationshipArray[0] = this.bundle.getString("Topology.List.All.Name");
/* 1213 */     int i = 1;
/* 1214 */     while (it.hasNext()) {
/* 1215 */       relationshipArray[(i++)] = ((String)it.next());
/*      */     }
/* 1217 */     this.relationshipList.removeListSelectionListener(this.relationSelectListener);
/* 1218 */     this.relationshipList.setListData(relationshipArray);
/* 1219 */     this.relationshipList.setSelectedIndex(0);
/* 1220 */     this.relationshipList.addListSelectionListener(this.relationSelectListener);
/*      */   }

/*      */   private void populateClassificationList(IlvDefaultSDMModel model)
/*      */   {
/* 1225 */     HashSet classifications = new HashSet();
/* 1226 */     Enumeration en = model.getObjects();
/* 1227 */     while (en.hasMoreElements()) {
/* 1228 */       Object item = en.nextElement();
/* 1229 */       if (!(model.isLink(item))) {
/* 1230 */         String classification = (String)model.getObjectProperty(item, "classification");
/*      */ 
/* 1232 */         String bidiclassification = (String)model.getObjectProperty(item, "bidiclassification");
/* 1233 */         if (bidiclassification != null)
/* 1234 */           classifications.add(bidiclassification);
/*      */         else
/* 1236 */           classifications.add(classification);
/* 1237 */         if (model.getObjectProperty(item, "bididirection") != null)
/* 1238 */           this.searchDir = ((String)model.getObjectProperty(item, "bididirection"));
/*      */       }
/*      */     }
/* 1241 */     String[] classificationArray = new String[classifications.size() + 1];
/* 1242 */     Iterator it = classifications.iterator();
/* 1243 */     classificationArray[0] = this.bundle.getString("Topology.List.All.Name");
/* 1244 */     int i = 1;
/* 1245 */     while (it.hasNext()) {
/* 1246 */       classificationArray[(i++)] = ((String)it.next());
/*      */     }
/* 1248 */     this.classificationList.removeListSelectionListener(this.classSelectListener);
/* 1249 */     this.classificationList.setListData(classificationArray);
/* 1250 */     this.classificationList.setSelectedIndex(0);
/* 1251 */     this.classificationList.addListSelectionListener(this.classSelectListener);
/*      */   }

/*      */   private void applyNodeFilter()
/*      */   {
/* 1256 */     HashSet filterList = new HashSet();
/* 1257 */     int[] selections = this.classificationList.getSelectedIndices();
/* 1258 */     if ((selections.length > 0) && (selections[0] != 0))
/*      */     {
/* 1260 */       for (int i = 0; i < selections.length; ++i)
/*      */       {
/* 1262 */         filterList.add((String)this.classificationList.getModel().getElementAt(selections[i]));
/*      */       }
/*      */     }
/*      */ 
/* 1266 */     IlvDefaultSDMModel model = (IlvDefaultSDMModel)getDiagrammer().getEngine().getModel();
/* 1267 */     Enumeration en = model.getObjects();
/* 1268 */     while (en.hasMoreElements())
/*      */     {
/* 1270 */       Object item = en.nextElement();
/* 1271 */       if (!(model.isLink(item)))
/*      */       {
/* 1273 */         if (filterList.size() > 0)
/*      */         {
/* 1275 */           String classification = (String)model.getObjectProperty(item, "classification");
/* 1276 */           String bidiclassification = (String)model.getObjectProperty(item, "bidiclassification");
/* 1277 */           if (bidiclassification != null)
/* 1278 */             classification = bidiclassification;
/* 1279 */           if (filterList.contains(classification))
/*      */           {
/* 1281 */             model.setObjectProperty(item, "hidden", Boolean.valueOf(false));
/*      */           }
/*      */           else
/*      */           {
/* 1285 */             model.setObjectProperty(item, "hidden", Boolean.valueOf(true));
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1290 */           model.setObjectProperty(item, "hidden", Boolean.valueOf(false));
/*      */         }
/*      */       }
/*      */     }
/* 1294 */     getDiagrammer().getEngine().setModel(model);
/*      */   }

/*      */   private void applyLinkFilter()
/*      */   {
/* 1299 */     HashSet filterList = new HashSet();
/* 1300 */     int[] selections = this.relationshipList.getSelectedIndices();
/* 1301 */     if ((selections.length > 0) && (selections[0] != 0))
/*      */     {
/* 1303 */       for (int i = 0; i < selections.length; ++i)
/*      */       {
/* 1305 */         filterList.add((String)this.relationshipList.getModel().getElementAt(selections[i]));
/*      */       }
/*      */     }
/*      */ 
/* 1309 */     IlvDefaultSDMModel model = (IlvDefaultSDMModel)getDiagrammer().getEngine().getModel();
/* 1310 */     Enumeration en = model.getObjects();
/* 1311 */     while (en.hasMoreElements())
/*      */     {
/* 1313 */       Object item = en.nextElement();
/* 1314 */       if (model.isLink(item))
/*      */       {
/* 1316 */         if (filterList.size() > 0)
/*      */         {
/* 1318 */           String relations = (String)model.getObjectProperty(item, "relation");
/* 1319 */           HashSet relationSet = new HashSet();
/* 1320 */           StringTokenizer st = new StringTokenizer(relations, ",");
/* 1321 */           while (st.hasMoreTokens())
/*      */           {
/* 1323 */             relationSet.add(st.nextToken());
/*      */           }
/* 1325 */           boolean contained = false;
/* 1326 */           Iterator it = filterList.iterator();
/* 1327 */           while (it.hasNext())
/*      */           {
/* 1329 */             String filterVal = (String)it.next();
/* 1330 */             if (relationSet.contains(filterVal))
/*      */             {
/* 1332 */               contained = true;
/* 1333 */               break;
/*      */             }
/*      */           }
/* 1336 */           if (contained)
/*      */           {
/* 1338 */             model.setObjectProperty(item, "hidden", Boolean.valueOf(false));
/*      */           }
/*      */           else
/*      */           {
/* 1342 */             model.setObjectProperty(item, "hidden", Boolean.valueOf(true));
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1347 */           model.setObjectProperty(item, "hidden", Boolean.valueOf(false));
/*      */         }
/*      */       }
/*      */     }
/* 1351 */     getDiagrammer().getEngine().setModel(model);
/*      */   }
/*      */   public class GraphDepthChangeListener
/*      */     implements ChangeListener
/*      */   {
/*      */     public void stateChanged(ChangeEvent e)
/*      */     {
/* 1358 */       TopologyApplet.this.reloadModel();
/*      */     }
/*      */   }
/*      */   public class RelationshipSelectionListener
/*      */     implements ListSelectionListener
/*      */   {
/*      */     public void valueChanged(ListSelectionEvent e)
/*      */     {
/* 1366 */       if (!(TopologyApplet.this.relationshipList.getValueIsAdjusting()))
/* 1367 */         TopologyApplet.this.applyLinkFilter();
/*      */     }
/*      */   }

/*      */   public class ClassificationSelectionListener
/*      */     implements ListSelectionListener
/*      */   {
/*      */     public void valueChanged(ListSelectionEvent e)
/*      */     {
/* 1376 */       if (!(TopologyApplet.this.classificationList.getValueIsAdjusting()))
/* 1377 */         TopologyApplet.this.applyNodeFilter();
/*      */     }
/*      */   }


/*      */   public IlvDiagrammer getDiagrammer()
/*      */   {
/* 1384 */     return this.diagrammer;
/*      */   }

/*      */   public void setDiagrammer(IlvDiagrammer diagrammer)
/*      */   {
/* 1389 */     this.diagrammer = diagrammer;
/*      */   }

/*      */   public String[] getTopologyDepth()
/*      */   {
/* 1394 */     return this.topologyDepth;
/*      */   }

/*      */   public void setTopologyDepth(String[] topologyDepth)
/*      */   {
/* 1399 */     this.topologyDepth = topologyDepth;
/*      */   }
/*      */   public class BidiDocumentHandler extends DocumentFilter/*      */   {
/*      */     public void insertString(DocumentFilter.FilterBypass fb, int offset, String str, AttributeSet attr)
/*      */       throws BadLocationException
/*      */     {
/* 1405 */       AbstractDocument doc = (AbstractDocument)fb.getDocument();
/* 1406 */       int length = doc.getLength();
/* 1407 */       String result = new StringBuilder().append((offset > 0) ? doc.getText(0, offset) : "").append(str).append((offset < length) ? doc.getText(offset, length - offset) : "").toString();
/*      */ 
/* 1409 */       TopologyApplet.this.handleDirection(result);
/* 1410 */       super.insertString(fb, offset, str, attr);
/*      */     }

/*      */     public void remove(DocumentFilter.FilterBypass fb, int offset, int length) throws BadLocationException
/*      */     {
/* 1415 */       AbstractDocument doc = (AbstractDocument)fb.getDocument();
/* 1416 */       int dLength = doc.getLength();
/* 1417 */       String result = new StringBuilder().append((offset > 0) ? doc.getText(0, offset) : "").append((offset < dLength) ? doc.getText(offset + length, dLength - (offset + length)) : "").toString();
/*      */ 
/* 1419 */       TopologyApplet.this.handleDirection(result);
/* 1420 */       super.remove(fb, offset, length);
/*      */     }

/*      */     public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String str, AttributeSet attr) throws BadLocationException
/*      */     {
/* 1425 */       AbstractDocument doc = (AbstractDocument)fb.getDocument();
/* 1426 */       int dLength = doc.getLength();
/* 1427 */       String result = new StringBuilder().append((offset > 0) ? doc.getText(0, offset) : "").append(str).append((offset < dLength) ? doc.getText(offset + length, dLength - (offset + length)) : "").toString();
/*      */ 
/* 1429 */       TopologyApplet.this.handleDirection(result);
/* 1430 */       super.replace(fb, offset, length, str, attr);
/*      */     }
/*      */   }
/*      */   public void handleDirection(String txt)
/*      */   {
/* 1435 */     String dir = "";
/* 1436 */     for (int i = 0; i < txt.length(); ++i) {
/* 1437 */       char c = txt.charAt(i);
/* 1438 */       if ((Character.getDirectionality(c) == 1) || (Character.getDirectionality(c) == 2))
/*      */       {
/* 1440 */         dir = "RTL";
/* 1441 */         break;
/*      */       }
/* 1443 */       if (Character.getDirectionality(c) == 0) {
/* 1444 */         dir = "LTR";
/* 1445 */         break;
/*      */       }
/*      */     }
/* 1448 */     if (dir.length() == 0) {
/* 1449 */       if (this.isRTL)
/* 1450 */         dir = "RTL";
/*      */       else
/* 1452 */         dir = "LTR";
/*      */     }
/* 1454 */     if ((dir.equals("RTL")) && (this.searchText.getComponentOrientation().isLeftToRight())) {
/* 1455 */       this.searchText.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
/*      */     }
/* 1457 */     else if ((dir.equals("LTR")) && (!(this.searchText.getComponentOrientation().isLeftToRight())))
/* 1458 */       this.searchText.applyComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
/*      */   }

/*      */   public IlvDefaultSDMModel getBizModel()
/*      */   {
/* 1463 */     return this.bizModel;
/*      */   }

/*      */   public void setBizModel(IlvDefaultSDMModel bizModel) {
/* 1467 */     this.bizModel = bizModel;
/*      */   }

/*      */   public IlvDefaultSDMModel getDetailModel() {
/* 1471 */     return this.detailModel;
/*      */   }

/*      */   public void setDetailModel(IlvDefaultSDMModel detailModel) {
/* 1475 */     this.detailModel = detailModel;
/*      */   }

/*      */   public boolean isBusinessModelActive() {
/* 1479 */     if (isActciApp()) return false;
/* 1480 */     return this.businessModelActive;
/*      */   }

/*      */   public void setBusinessModelActive(boolean businessModelActive) {
/* 1484 */     this.businessModelActive = businessModelActive;
/*      */   }

/*      */   public void clearDetailModel() {
/* 1488 */     setDetailModel(null);
/*      */   }

/*      */   public void clearBizModel() {
/* 1492 */     setBizModel(null);
/*      */   }

/*      */   public String getAppname() {
/* 1496 */     return this.appname;
/*      */   }

/*      */   public void setAppname(String appname) {
/* 1500 */     this.appname = appname;
/*      */   }

/*      */   private boolean isChangeApp() {
/* 1504 */     return (getAppname().equalsIgnoreCase("CHANGE")); }

/*      */   private boolean isActciApp() {
/* 1507 */     return (getAppname().equalsIgnoreCase("ACTCI"));
/*      */   }

/*      */   protected String getSpinnerValue()
/*      */   {
/* 1512 */     return ((String)this.graphDepthSpinner.getValue());
/*      */   }

/*      */   private String getInitialNodeDepth()
/*      */   {
/* 1517 */     String value = getParameter("topologyinitdepth");
/* 1518 */     if ((value == null) || (value.equals(""))) value = "1";
/* 1519 */     return value;
/*      */   }

/*      */   public String getDetaillSpinner() {
/* 1523 */     return this.detaillSpinner;
/*      */   }

/*      */   public void setDetailSpinner(String detaillSpinner) {
/* 1527 */     this.detaillSpinner = detaillSpinner;
/*      */   }

/*      */   public String getBizSpinner() {
/* 1531 */     return this.bizSpinner;
/*      */   }

/*      */   public void setBizSpinner(String bizSpinner) {
/* 1535 */     this.bizSpinner = bizSpinner;
/*      */   }

/*      */   public int getBizSelectedTask() {
/* 1539 */     return this.bizSelectedTask;
/*      */   }

/*      */   public void setBizSelectedTask(int bizSelectedTask) {
/* 1543 */     this.bizSelectedTask = bizSelectedTask;
/*      */   }

/*      */   public int[] getBizSelectedtargets() {
/* 1547 */     return this.bizSelectedtargets;
/*      */   }

/*      */   public void setBizSelectedtargets(int[] bizSelectedtargets) {
/* 1551 */     this.bizSelectedtargets = bizSelectedtargets;
/*      */   }

/*      */   public int getDetailSelectedTask() {
/* 1555 */     return this.detailSelectedTask;
/*      */   }

/*      */   public void setDetailSelectedTask(int detailSelectedTask) {
/* 1559 */     this.detailSelectedTask = detailSelectedTask;
/*      */   }

/*      */   public int[] getDetailSelectedtargets() {
/* 1563 */     return this.detailSelectedtargets;
/*      */   }

/*      */   public void setDetailSelectedtargets(int[] detailSelectedtargets) {
/* 1567 */     this.detailSelectedtargets = detailSelectedtargets;
/*      */   }



/*      */   private void clearEverything()
/*      */   {
/* 1574 */     clearBizModel();
/* 1575 */     clearDetailModel();
/*      */ 
/* 1577 */     if (isActciApp()) {
/* 1578 */       this.detailButton.setSelected(true);
/*      */     }
/*      */     else {
/* 1581 */       this.bizButton.setSelected(true);
/*      */     }
/* 1583 */     this.searchText.setText("");
/*      */   }






/*      */   protected void acceptMovedToAssetNum(String movedtoassetnum)
/*      */   {
/* 1593 */     if (isBusinessModelActive())
/*      */     {
/* 1595 */       setCurrentAssetNumInBusinessView(movedtoassetnum);
/* 1596 */       return;

/*      */     }
/*      */ 
/* 1600 */     setCurrentAssetNumInDetailsView(movedtoassetnum);
/*      */   }

/*      */   protected String getCurrentAssetNumInBusinessView() {
/* 1604 */     return this.currentAssetNumInBusinessView;
/*      */   }

/*      */   protected void setCurrentAssetNumInBusinessView(String assetnum) {
/* 1608 */     this.currentAssetNumInBusinessView = assetnum;
/*      */   }

/*      */   protected String getCurrentAssetNumInDetailsView() {
/* 1612 */     return this.currentAssetNumInDetailsView;
/*      */   }

/*      */   protected void setCurrentAssetNumInDetailsView(String assetnum) {
/* 1616 */     this.currentAssetNumInDetailsView = assetnum;
/*      */   }

/*      */   protected boolean isFirstAlreadyLoaded() {
/* 1620 */     return this.firstAlreadyLoaded;
/*      */   }

/*      */   protected void setFirstAlreadyLoaded(boolean firstAlreadyLoaded) {
/* 1624 */     this.firstAlreadyLoaded = firstAlreadyLoaded;
/*      */   }
/*      */ }
