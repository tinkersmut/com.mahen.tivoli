/*    */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.asset.ilog.applet.ILogApplet;
/*    */ import ilog.views.IlvGraphic;
/*    */ import ilog.views.diagrammer.IlvDiagrammer;
/*    */ import ilog.views.sdm.IlvSDMEngine;
/*    */ import ilog.views.swing.IlvPopupMenuContext;
/*    */ import ilog.views.swing.IlvPopupMenuManager;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.util.Hashtable;
/*    */ import java.util.ResourceBundle;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JMenuItem;
/*    */ 





















/*    */ public class ShowCiRelationPropertiesAction extends AbstractAction
/*    */ {
/*    */   private static final long serialVersionUID = 5030421888411463455L;
/*    */   private IlvDiagrammer diagrammer;
/*    */   private ILogApplet applet;
/*    */   private String target;
/*    */ 
/*    */   public ShowCiRelationPropertiesAction(IlvDiagrammer diagrammer, ILogApplet applet, String target, ResourceBundle bundle)
/*    */   {
/* 45 */     super(bundle.getString("Topology.Label.RelationProperties.Name"));
/* 46 */     putValue("Name", bundle.getString("Topology.Label.RelationProperties.Name"));
/* 47 */     this.diagrammer = diagrammer;
/* 48 */     this.applet = applet;
/* 49 */     this.target = target;
/*    */   }


/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/* 55 */     JMenuItem m = (JMenuItem)e.getSource();

/*    */ 
/* 58 */     IlvPopupMenuContext context = IlvPopupMenuManager.getPopupMenuContext(m);
/* 59 */     if (context == null) return;
/* 60 */     IlvGraphic g = context.getGraphic();
/*    */ 
/* 62 */     Object obj = (g == null) ? null : this.diagrammer.getEngine().getObject(g);
/*    */ 
/* 64 */     if (obj == null) return;

/*    */ 
/* 67 */     Hashtable args = new Hashtable();
/* 68 */     String sourceCi = (String)this.diagrammer.getObjectProperty(this.diagrammer.getSourceNode(obj), "cinum");
/* 69 */     String targetCi = (String)this.diagrammer.getObjectProperty(this.diagrammer.getTargetNode(obj), "cinum");
/* 70 */     String relation = (String)this.diagrammer.getObjectProperty(obj, "relation");
/* 71 */     args.put("sourceci", sourceCi);
/* 72 */     args.put("targetci", targetCi);
/* 73 */     args.put("relation", relation);
/* 74 */     this.applet.sendEvent("properties", this.target, args);
/*    */   }
/*    */ }
