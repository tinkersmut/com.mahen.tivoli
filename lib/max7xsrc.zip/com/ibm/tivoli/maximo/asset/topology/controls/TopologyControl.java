/*     */ package com.ibm.tivoli.maximo.asset.topology.controls;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.asset.ilog.controls.ILogControl;
/*     */ import com.ibm.tivoli.maximo.asset.topology.beans.ImplTaskTargetHelper;
/*     */ import com.ibm.tivoli.maximo.asset.topology.beans.TargetHelper;
/*     */ import com.ibm.tivoli.maximo.asset.topology.constants.TopologyConstants;
/*     */ import ilog.views.sdm.model.IlvDefaultSDMModel;
/*     */ import ilog.views.sdm.util.IlvXMLConnector;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.BidiUtils;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 






/*     */ public class TopologyControl extends ILogControl
/*     */   implements TopologyConstants
/*     */ {
/*  55 */   private static final Class CLASS = TopologyControl.class;
/*     */   private String topologyDepth;
/*     */   private String topologyInitDepth;
/*     */   private int topologyMaxNodes;
/*     */   private boolean detailView;
/*     */   private Hashtable<String, Boolean> impactedAsset;
/*     */ 
/*     */   public TopologyControl()
/*     */   {
/*  56 */     this.topologyDepth = "1";
/*  57 */     this.topologyInitDepth = "1";
/*  58 */     this.topologyMaxNodes = 200;
/*  59 */     this.detailView = false;
/*  60 */     this.impactedAsset = new Hashtable();
/*     */   }

/*     */   public void initialize() {
/*  64 */     super.initialize();
/*     */     try {
/*  66 */       String topoD = MXServer.getMXServer().getConfig().getProperty("mxe.assettopology.depth");
/*  67 */       if (topoD != null) {
/*  68 */         int i = Integer.parseInt(topoD);
/*  69 */         if (i > 0) setTopologyDepth(topoD);
/*     */       }
/*  71 */       String topoInitD = MXServer.getMXServer().getConfig().getProperty("mxe.assettopology.init");
/*  72 */       if (topoInitD != null) {
/*  73 */         int i = Integer.parseInt(topoInitD);
/*  74 */         if (i > 0) setTopologyInitDepth(topoInitD);
/*     */       }
/*  76 */       String topoMaxNodes = MXServer.getMXServer().getConfig().getProperty("mxe.assettopology.maxnodes");
/*  77 */       if (topoMaxNodes != null) {
/*  78 */         int maxNodes = Integer.parseInt(topoMaxNodes);
/*  79 */         if (maxNodes > 0) setTopologyMaxNodes(maxNodes);
/*     */       }
/*     */     } catch (RemoteException e) {
/*  82 */       e.printStackTrace(System.out);
/*     */     }
/*     */   }

/*     */   public boolean handleServletRequest(ServletContext context, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/*  87 */     System.out.println("");
/*  88 */     System.out.println("++++++++++++++++++++Entering handleServletRequest++++++++++++");
/*     */     try {
/*  90 */       request.setCharacterEncoding("UTF-8");
/*  91 */       response.setContentType("text/xml; charset=UTF-8");
/*     */ 
/*  93 */       String assetnum = "";
/*  94 */       if (getProperty("appname").equalsIgnoreCase("CHANGE"))
/*     */       {
/*  96 */         String taskTargets = request.getParameter("taskTargets");
/*     */ 
/*  98 */         if (taskTargets != null) {
/*  99 */           ArrayList taskHelper = loadTaskTargetsAndImpacts();
/* 100 */           ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
/* 101 */           out.writeObject(taskHelper);
/* 102 */           out.flush();
/* 103 */           out.close();
/* 104 */           int i = 1;
/*     */           return i;/*     */         }
/* 106 */         assetnum = request.getParameter("assetnum");
/*     */       }
/*     */ 
/* 109 */       String depthStr = request.getParameter("graphdepth");
/* 110 */       int depth = getIntDepthFromString(depthStr);
/* 111 */       String parmDetailView = request.getParameter("detailview");
/* 112 */       setDetailView(parmDetailView);
/*     */ 
/* 114 */       assetnum = request.getParameter("assetnum");
/*     */ 
/* 116 */       IlvDefaultSDMModel model = createModel(depth, assetnum);
/*     */ 
/* 118 */       IlvXMLConnector xmlConnector = new IlvXMLConnector();
/* 119 */       OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream(), "UTF-8");
/* 120 */       xmlConnector.writeXML(model, writer, null, null);
/* 121 */       writer.close();
/*     */ 
/* 123 */       int j = 1;
/*     */     }/*     */     finally
/*     */     {
/*     */ /* 126 */       System.out.println("----------Leaving handleServletRequest---------");
/* 127 */       return j;/* 127 */       System.out.println();
/*     */     }
/*     */   }

/*     */   private IlvDefaultSDMModel createModel(int depth, String assetnum) {
/* 132 */     IlvDefaultSDMModel model = new IlvDefaultSDMModel();

/*     */ 
/* 135 */     if ((getProperty("appname").equalsIgnoreCase("CHANGE")) && (((assetnum == null) || (assetnum.equals(""))))) {
/* 136 */       return model;
/*     */     }
/*     */     try
/*     */     {
/* 140 */       AppInstance appInst = getWebClientSession().getCurrentApp();
/* 141 */       if (appInst == null) {
/* 142 */         System.out.println(CLASS + " loadData appInst is null!");
/* 143 */         return model;
/*     */       }
/*     */ 
/* 146 */       DataBean appBean = appInst.getAppBean();
/* 147 */       if (appBean == null) {
/* 148 */         System.out.println(CLASS + "loadData appBean is null!");
/* 149 */         return model;
/*     */       }
/*     */ 
/* 152 */       MboRemote mbo = appBean.getMbo();
/* 153 */       if (mbo == null) {
/* 154 */         System.out.println(CLASS + "loadData mbo is null!");
/* 155 */         return model;








/*     */       }
/*     */ 
/* 166 */       if (!(isDetailView()))
/*     */       {
/* 168 */         MboSetRemote cachedMbos = MXServer.getMXServer().getMboSet("ASSETTOPOCACHE", mbo.getUserInfo());
/* 169 */         if (cachedMbos.count() == 0) {
/* 170 */           getWebClientSession().addWarning(new MXApplicationException("assettopo", "NoNodesFound"));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 175 */       if (getProperty("appname").equalsIgnoreCase("CHANGE")) {
/* 176 */         MboSetRemote assetMboSet = getAssets(mbo, assetnum);
/* 177 */         if (assetMboSet.count() == 0) {
/* 178 */           System.out.println(CLASS + "loadData ASSET MBO Count is zero nothing matched");
/*     */         }
/*     */         else
/* 181 */           for (int i = 0; i < assetMboSet.count(); ++i) {
/* 182 */             MboRemote assetmbo = assetMboSet.getMbo(i);

/*     */ 
/* 185 */             AssetNodeVisitor visitor = new AssetNodeVisitor(model, depth, 10, getTopologyMaxNodes(), this);
/* 186 */             visitor.setImpactedASset(this.impactedAsset);
/* 187 */             visitor.setBundle(this.bundle);
/* 188 */             Object node = visitor.generateIlvNode(assetmbo, "root");
/* 189 */             visitor.push(assetmbo.getString("ASSETNUM"), node);
/* 190 */             createRelatedNodesWithAsset(visitor, assetmbo);
/* 191 */             visitor.pop();
/*     */           }
/*     */       }
/*     */       else
/*     */       {
/* 196 */         AssetNodeVisitor.nativeInit(mbo);
/* 197 */         AssetNodeVisitor visitor = new AssetNodeVisitor(model, depth, 10, getTopologyMaxNodes(), this);
/* 198 */         visitor.setupMouseOverInfo(mbo);
/* 199 */         visitor.setBundle(this.bundle);
/*     */ 
/* 201 */         Object ilvRoot = visitor.generateIlvNode(mbo, "root");
/*     */ 
/* 203 */         if (mbo.getName().equals("ACTCI")) {
/* 204 */           visitor.push(mbo.getString("ACTCINUM"), ilvRoot);
/*     */         }
/*     */         else {
/* 207 */           visitor.push(mbo.getString("ASSETNUM"), ilvRoot);
/*     */         }
/*     */ 
/* 210 */         createRelatedNodesWithAsset(visitor, mbo);
/*     */ 
/* 212 */         visitor.pop();
/*     */       }
/*     */     } catch (MXException me) {
/* 215 */       System.out.println(CLASS + "loadData Exception received: " + me.getMessage());
/* 216 */       getWebClientSession().addWarning(me);
/*     */     } catch (RemoteException re) {
/* 218 */       re.printStackTrace(System.out);
/*     */     }
/*     */ 
/* 221 */     return model;
/*     */   }

/*     */   private MboSetRemote fetchAsset(MboRemote mbo, String assetnum) throws MXException, RemoteException
/*     */   {
/* 226 */     if (mbo.getName().equals("ACTCI")) {
/* 227 */       SqlFormat sqf = new SqlFormat(mbo.getUserInfo(), "actcinum = :1");
/* 228 */       sqf.setObject(1, "ACTCI", "ACTCINUM", assetnum);
/* 229 */       String whereClause = sqf.format();
/* 230 */       MboSetRemote ciMboSet = mbo.getMboSet("$ACTCI", "ACTCI", whereClause);
/* 231 */       return ciMboSet;
/*     */     }
/*     */ 
/* 234 */     SqlFormat sqf = new SqlFormat(mbo.getUserInfo(), "assetnum = :1");
/* 235 */     sqf.setObject(1, "ASSET", "ASSETNUM", assetnum);
/* 236 */     String whereClause = sqf.format();
/* 237 */     MboSetRemote assetMboSet = mbo.getMboSet("$ASSET", "ASSET", whereClause);
/* 238 */     return assetMboSet;
/*     */   }

/*     */   private void createRelatedNodesWithAsset(AssetNodeVisitor visitor, MboRemote parentAssetMbo) throws MXException, RemoteException
/*     */   {
/* 243 */     if (visitor.atMaxNodeDepth()) {
/* 244 */       System.out.println(CLASS + "createNode Maximum node depth is reached");
/* 245 */       return;
/*     */     }
/*     */ 
/* 248 */     if (visitor.atMaxAssetDepth()) {
/* 249 */       System.out.println(CLASS + "createNode Maximum Asset depth is reached");
/* 250 */       return;
/*     */     }
/*     */ 
/* 253 */     if (visitor.maxNodesReached()) {
/* 254 */       System.out.println(CLASS + "createNode Reached the maximum number of nodes of " + getTopologyMaxNodes());
/* 255 */       Object[] params = new Object[1];
/* 256 */       params[0] = Integer.valueOf(getTopologyMaxNodes());
/* 257 */       getWebClientSession().addWarning(new MXApplicationException("assettopo", "NodeLimitReached", params));
/* 258 */       return;



/*     */     }
/*     */ 
/* 264 */     String assetNum = null;
/* 265 */     if (parentAssetMbo.getName().equals("ACTCI")) {
/* 266 */       assetNum = parentAssetMbo.getString("ACTCINUM");
/*     */     }
/*     */     else {
/* 269 */       assetNum = parentAssetMbo.getString("ASSETNUM");

/*     */     }
/*     */ 
/* 273 */     HashSet relatedAssets = new HashSet();
/*     */ 
/* 275 */     HashMap inMap = new HashMap();
/* 276 */     HashMap outMap = new HashMap();
/*     */     MboSetRemote assetlocrelations;/*     */     MboSetRemote assetlocrelations;
/* 278 */     if (isDetailView())
/*     */     {
/* 280 */       System.out.println("Details View...");
/* 281 */       String assetLocRelationStr = getProperty("assetlocrelation");
/* 282 */       assetlocrelations = parentAssetMbo.getMboSet(assetLocRelationStr);
/*     */     }
/*     */     else
/*     */     {
/* 286 */       System.out.println("Business View...");
/* 287 */       assetlocrelations = parentAssetMbo.getMboSet("ASSETCACHEREL");
/*     */     }
/*     */ 
/* 290 */     buildRelationListsForOneAsset(assetNum, assetlocrelations, relatedAssets, inMap, outMap);
/* 291 */     visitor.setNodeDegree(assetNum, relatedAssets.size());
/*     */ 
/* 293 */     Iterator itr = relatedAssets.iterator();
/* 294 */     while ((itr.hasNext()) && (!(visitor.maxNodesReached()))) {
/* 295 */       String nextAssetNum = (String)itr.next();
/*     */ 
/* 297 */       HashSet inRelations = (HashSet)inMap.get(nextAssetNum);
/* 298 */       HashSet outRelations = (HashSet)outMap.get(nextAssetNum);
/*     */ 
/* 300 */       MboRemote nextAssetMbo = fetchAsset(parentAssetMbo, nextAssetNum).moveFirst();
/*     */ 
/* 302 */       Object ilvNode = visitor.generateIlvNode(nextAssetMbo, "leaf");
/* 303 */       visitor.generateLinks(ilvNode, inRelations, outRelations, "link");
/*     */ 
/* 305 */       if (visitor.proceedDeepForEncounteredNode(nextAssetNum)) {
/* 306 */         visitor.push(nextAssetNum, ilvNode);
/* 307 */         createRelatedNodesWithAsset(visitor, nextAssetMbo);
/* 308 */         visitor.pop();
/*     */       }
/*     */     }
/*     */   }





/*     */   private void buildRelationListsForOneAsset(String parentAssetNum, MboSetRemote assetrelations, HashSet<String> relatedAssets, HashMap<String, HashSet<String>> inMap, HashMap<String, HashSet<String>> outMap)
/*     */     throws MXException, RemoteException
/*     */   {
/* 320 */     String langCode = assetrelations.getUserInfo().getLangCode();
/* 321 */     for (int i = 0; i < assetrelations.count(); ++i) {
/* 322 */       MboRemote assetrelation = assetrelations.getMbo(i);
/* 323 */       String mboName = assetrelation.getName();
/*     */       String relation;
/* 325 */       if (isDetailView())
/*     */       {
/* 327 */         String relation = assetrelation.getString("ASSETRELATIONNUM");
/*     */ 
/* 329 */         if (BidiUtils.isBidiEnabled()) relation = BidiUtils.applyBidiAttributes(mboName, "ASSETRELATIONNUM", relation, langCode);

/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 335 */         relation = "";

/*     */       }
/*     */ 
/* 339 */       String sourceAssetNum = assetrelation.getString("SOURCEASSETNUM");
/* 340 */       String targetAssetNum = assetrelation.getString("TARGETASSETNUM");
/*     */ 
/* 342 */       if (!(parentAssetNum.equalsIgnoreCase(sourceAssetNum))) {
/* 343 */         relatedAssets.add(sourceAssetNum);
/*     */ 
/* 345 */         if (!(outMap.containsKey(sourceAssetNum)))
/*     */         {
/* 347 */           outMap.put(sourceAssetNum, new HashSet());
/*     */         }
/* 349 */         HashSet relationList = (HashSet)outMap.get(sourceAssetNum);
/* 350 */         relationList.add(relation);
/*     */       }
/* 352 */       else if (!(parentAssetNum.equalsIgnoreCase(targetAssetNum))) {
/* 353 */         relatedAssets.add(targetAssetNum);
/*     */ 
/* 355 */         if (!(inMap.containsKey(targetAssetNum)))
/*     */         {
/* 357 */           inMap.put(targetAssetNum, new HashSet());
/*     */         }
/* 359 */         HashSet relationList = (HashSet)inMap.get(targetAssetNum);
/* 360 */         relationList.add(relation);
/*     */       }
/*     */       else
/*     */       {
/* 364 */         System.out.println(CLASS + "buildRelationLists ASSET " + parentAssetNum + " is linked to itself - ignore");

/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 370 */     System.out.println("");
/* 371 */     System.out.println("FOR assetnum [" + parentAssetNum + "], relatedAssets=[" + relatedAssets + "]");
/* 372 */     Iterator itr = relatedAssets.iterator();
/* 373 */     while (itr.hasNext()) {
/* 374 */       String theassetnum = (String)itr.next();
/* 375 */       System.out.println("    THEN [" + theassetnum + "] has inbound=[" + inMap.get(theassetnum) + "], outbound=[" + outMap.get(theassetnum) + "]");
/*     */     }
/* 377 */     System.out.println("");
/*     */   }


/*     */   private ArrayList<ImplTaskTargetHelper> loadTaskTargetsAndImpacts()
/*     */   {
/* 383 */     ArrayList taskTargets = new ArrayList();
/*     */     try
/*     */     {
/* 386 */       AppInstance appInst = getWebClientSession().getCurrentApp();
/* 387 */       if (appInst == null) {
/* 388 */         System.out.println(CLASS + "loadData appInst is null!");
/* 389 */         return taskTargets;
/*     */       }
/*     */ 
/* 392 */       DataBean appBean = appInst.getAppBean();
/* 393 */       if (appBean == null) {
/* 394 */         System.out.println(CLASS + "loadData appBean is null!");
/* 395 */         return taskTargets;
/*     */       }
/*     */ 
/* 398 */       MboRemote mbo = appBean.getMbo();
/* 399 */       if (mbo == null) {
/* 400 */         System.out.println(CLASS + "loadData mbo is null!");
/* 401 */         return taskTargets;
/*     */       }
/*     */ 
/* 404 */       MboSetRemote impltasks = mbo.getMboSet("PMCHGSHOWALLTASKS");
/* 405 */       if (impltasks.count() == 0) {
/* 406 */         return taskTargets;
/*     */       }
/*     */ 
/* 409 */       ImplTaskTargetHelper helper = null;
/* 410 */       this.impactedAsset.clear();
/* 411 */       for (int i = 0; i < impltasks.count(); ++i) {
/* 412 */         helper = new ImplTaskTargetHelper();
/* 413 */         MboRemote taskmbo = impltasks.getMbo(i);
/*     */ 
/* 415 */         if (!(BidiUtils.isBidiEnabled())) {
/* 416 */           helper.setTaskWonum(taskmbo.getString("wonum"));
/* 417 */           helper.setDescription(taskmbo.getString("description"));
/* 418 */           helper.setTaskID(taskmbo.getString("taskid"));
/*     */         }
/*     */         else {
/* 421 */           helper.setTaskWonum(BidiUtils.applyBidiAttributes(taskmbo.getName(), "wonum", taskmbo.getString("wonum"), taskmbo.getUserInfo().getLangCode()));
/*     */ 
/* 423 */           helper.setDescription(BidiUtils.applyBidiAttributes(taskmbo.getName(), "description", taskmbo.getString("description"), taskmbo.getUserInfo().getLangCode()));
/*     */ 
/* 425 */           helper.setTaskID(BidiUtils.applyBidiAttributes(taskmbo.getName(), "taskid", taskmbo.getString("taskid"), taskmbo.getUserInfo().getLangCode()));


/*     */         }
/*     */ 
/* 430 */         MboSetRemote impltaskTargets = taskmbo.getMboSet("PMCHGALLTARGETS");
/* 431 */         if (impltaskTargets.count() != 0) {
/* 432 */           HashSet t = new HashSet();

/*     */ 
/* 435 */           for (int j = 0; j < impltaskTargets.count(); ++j) {
/* 436 */             MboRemote targetMbo = impltaskTargets.getMbo(j);
/* 437 */             String mboName = targetMbo.getName();
/* 438 */             String langCode = targetMbo.getUserInfo().getLangCode();
/* 439 */             if (!(BidiUtils.isBidiEnabled())) {
/* 440 */               t.add(new TargetHelper(targetMbo.getString("assetnum"), targetMbo.getString("targetdesc")));
/*     */             }
/*     */             else {
/* 443 */               t.add(new TargetHelper(BidiUtils.applyBidiAttributes(mboName, "assetnum", targetMbo.getString("assetnum"), langCode), BidiUtils.applyBidiAttributes(mboName, "targetdesc", targetMbo.getString("targetdesc"), langCode)));
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 448 */           List list = new ArrayList(t);
/*     */ 
/* 450 */           helper.setTaskTargetsList(list);
/*     */         }
/*     */         else {
/* 453 */           System.out.println(CLASS + "loadTaskTargetsAndImpacts Implementation Task Has No Targets" + taskmbo.getString("wonum"));

/*     */         }
/*     */ 
/* 457 */         MboSetRemote implTaskImpactedTargets = taskmbo.getMboSet("PMCHGSINGIMPACTED");
/*     */ 
/* 459 */         if (implTaskImpactedTargets.count() != 0) {
/* 460 */           HashSet tt = new HashSet();

/*     */ 
/* 463 */           for (int j = 0; j < implTaskImpactedTargets.count(); ++j) {
/* 464 */             MboRemote impactedTargetMbo = implTaskImpactedTargets.getMbo(j);
/* 465 */             String mboName = impactedTargetMbo.getName();
/* 466 */             String langCode = impactedTargetMbo.getUserInfo().getLangCode();
/* 467 */             this.impactedAsset.put(impactedTargetMbo.getString("assetnum"), Boolean.valueOf(true));
/*     */ 
/* 469 */             if (!(BidiUtils.isBidiEnabled())) {
/* 470 */               tt.add(new TargetHelper(impactedTargetMbo.getString("assetnum"), "TargetCI:" + impactedTargetMbo.getString("TARGETCI")));
/*     */             }
/*     */             else {
/* 473 */               tt.add(new TargetHelper(BidiUtils.getDelimeterPrefix(langCode) + BidiUtils.applyBidiAttributes(mboName, "assetnum", impactedTargetMbo.getString("assetnum"), langCode), BidiUtils.getDelimeterPrefix(langCode) + "TargetCI:" + BidiUtils.getDelimeterPrefix(langCode) + BidiUtils.applyBidiAttributes(mboName, "TARGETCI", impactedTargetMbo.getString("TARGETCI"), langCode)));



/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 481 */           List list1 = new ArrayList(tt);
/*     */ 
/* 483 */           helper.setTaskTargetsImpactedList(list1);
/*     */         }
/*     */         else {
/* 486 */           System.out.println(CLASS + "loadTaskTargetsAndImpacts Implementation Task Has No Impacted Targets" + taskmbo.getString("wonum"));
/*     */         }
/*     */ 
/* 489 */         taskTargets.add(helper);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 494 */       e.printStackTrace(System.out);
/*     */     }
/*     */ 
/* 497 */     return taskTargets;
/*     */   }

/*     */   private MboSetRemote getAssets(MboRemote mbo, String assetnum) throws MXException, RemoteException {
/* 501 */     String properStrings = addParenethesis(assetnum);
/* 502 */     SqlFormat sqf = new SqlFormat(mbo.getUserInfo(), "assetnum in  (" + properStrings + ")");
/* 503 */     sqf.setObject(1, "ASSET", "ASSETNUM", assetnum);
/* 504 */     String whereClause = sqf.format();
/* 505 */     MboSetRemote assetMboSet = mbo.getMboSet("$ASSET", "ASSET", whereClause);
/* 506 */     return assetMboSet;
/*     */   }

/*     */   private String addParenethesis(String assetnum) {
/* 510 */     String converted = "";
/* 511 */     if ((assetnum == null) || (assetnum.equals(""))) {
/* 512 */       return converted;
/*     */     }
/* 514 */     StringTokenizer tk = new StringTokenizer(assetnum, ",");
/* 515 */     while (tk.hasMoreElements())
/*     */     {
/* 517 */       if (converted.equals("")) {
/* 518 */         converted = "'" + tk.nextToken() + "'";
/*     */       }
/* 520 */       converted = converted + ",'" + tk.nextToken() + "'";
/*     */     }
/*     */ 
/* 523 */     return converted;
/*     */   }

/*     */   private int getIntDepthFromString(String depthStr) {
/* 527 */     int depth = 1;
/*     */     try
/*     */     {
/* 530 */       depth = Integer.parseInt(depthStr);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 534 */       System.out.println(CLASS + ", Invalid Depth String [" + depthStr + "]");
/*     */     }
/* 536 */     return depth;
/*     */   }

/*     */   public int getTopologyMaxNodes() {
/* 540 */     return this.topologyMaxNodes;
/*     */   }

/*     */   public void setTopologyMaxNodes(int topologyMaxNodes) {
/* 544 */     this.topologyMaxNodes = topologyMaxNodes;
/*     */   }

/*     */   public String getTopologyDepth() {
/* 548 */     return this.topologyDepth;
/*     */   }

/*     */   public void setTopologyDepth(String topologyDepth) {
/* 552 */     this.topologyDepth = topologyDepth;
/*     */   }

/*     */   public String getTopologyInitDepth() {
/* 556 */     return this.topologyInitDepth;
/*     */   }

/*     */   public void setTopologyInitDepth(String topologyInitDepth) {
/* 560 */     this.topologyInitDepth = topologyInitDepth;
/*     */   }

/*     */   public boolean isDetailView() {
/* 564 */     return this.detailView;
/*     */   }

/*     */   public void setDetailView(String detailView) {
/* 568 */     this.detailView = Boolean.parseBoolean(detailView);
/*     */   }

/*     */   public Hashtable<String, Boolean> getImpactedAsset() {
/* 572 */     return this.impactedAsset; }

/*     */   public void setImpactedAsset(Hashtable<String, Boolean> impactedAsset) {
/* 575 */     this.impactedAsset = impactedAsset;
/*     */   }
/*     */ }
