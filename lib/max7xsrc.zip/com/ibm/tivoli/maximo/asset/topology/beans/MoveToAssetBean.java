/*     */ package com.ibm.tivoli.maximo.asset.topology.beans;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.util.BidiUtils;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.beans.ResultsBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.BoundComponentInstance;
/*     */ import psdi.webclient.system.controller.ComponentInstance;
/*     */ import psdi.webclient.system.controller.ControlInstance;
/*     */ import psdi.webclient.system.controller.NavigationHistory;
/*     */ import psdi.webclient.system.controller.NavigationHistoryStack;
/*     */ import psdi.webclient.system.controller.PageInstance;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 









/*     */ public class MoveToAssetBean extends DataBean
/*     */ {
/*     */   public int MoveTo()
/*     */   {
/*     */     try
/*     */     {
/*  40 */       String assetnum = this.clientSession.getRequest().getParameter("assetnum");
/*     */ 
/*  42 */       if ((assetnum != null) && (!("".equals(assetnum)))) {
/*  43 */         assetnum = URLDecoder.decode(WebClientRuntime.decodeSafevalue(assetnum), "UTF-8");
/*  44 */         if (BidiUtils.isBidiEnabled()) {
/*  45 */           assetnum = BidiUtils.removeMarkers(assetnum);
/*     */         }
/*  47 */         MboSetRemote mboSet = getMboSet();
/*     */ 
/*  49 */         SqlFormat sqf = new SqlFormat(getMXSession().getUserInfo(), "assetnum = :1");
/*  50 */         sqf.setObject(1, "ASSET", "ASSETNUM", assetnum);
/*  51 */         String whereClause = sqf.format();
/*  52 */         mboSet.setWhere(whereClause);
/*  53 */         mboSet.reset();
/*  54 */         setCurrentRow(0);
/*  55 */         refreshTable();



/*     */ 
/*  60 */         String label = this.app.getDataBean().getString(this.app.getDataBean().getKeyAttribute());
/*     */ 
/*  62 */         NavigationHistory history = new NavigationHistory(this.app.getDataBean().getUniqueIdValue(), label);
/*  63 */         this.app.getNavigationHistory().push(history);



/*     */ 
/*  68 */         ResultsBean rb = this.clientSession.getCurrentApp().getResultsBean();
/*  69 */         rb.setUserWhere("");
/*  70 */         rb.resetQbe();
/*  71 */         long uniqueid = getMboSet().getMbo(0).getUniqueIDValue();
/*  72 */         rb.getMboForUniqueId(uniqueid);
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*  77 */       t.printStackTrace(System.out);
/*     */     }
/*     */ 
/*  80 */     return 1;
/*     */   }




/*     */   public int researchSelectProtoType()
/*     */   {
/*     */     try
/*     */     {
/*  90 */       System.out.println("this.getCreator()=[" + getCreator() + "]");
/*  91 */       System.out.println("this.getCreator().getComponents()=[" + getCreator().getComponents() + "]");
/*  92 */       System.out.println("clientSession.getCurrentApp().getCurrentPage().getControlInstance(\"asset_assettopoapplet\")=[" + this.clientSession.getCurrentApp().getCurrentPage().getControlInstance("asset_assettopoapplet") + "]");
/*     */ 
/*  94 */       ControlInstance ctrlIns = this.clientSession.getCurrentApp().getCurrentPage().getControlInstance("asset_assettopoapplet");
/*  95 */       Iterator components = ctrlIns.getComponents().iterator();
/*  96 */       while (components.hasNext()) {
/*  97 */         ComponentInstance componentInstance = (ComponentInstance)components.next();
/*  98 */         System.out.println("   ...got componentInstance=[" + componentInstance + "]");
/*     */       }
/* 100 */       ComponentInstance h = (ComponentInstance)ctrlIns.getComponents().get(0);
/* 101 */       ComponentInstance v = (ComponentInstance)h.getChildren().get(0);
/* 102 */       ComponentInstance asttopo = (ComponentInstance)v.getChildren().get(0);
/* 103 */       System.out.println("asttopo=[" + asttopo + "]");
/*     */ 
/* 105 */       asttopo.setProperty("lookup", "linearasset");
/* 106 */       ((BoundComponentInstance)asttopo).selectvalue();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 110 */       t.printStackTrace(System.out);
/*     */     }
/*     */ 
/* 113 */     return 1;
/*     */   }
/*     */ }
