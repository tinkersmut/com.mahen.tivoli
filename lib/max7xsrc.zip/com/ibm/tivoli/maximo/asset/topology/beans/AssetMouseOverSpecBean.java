/*    */ package com.ibm.tivoli.maximo.asset.topology.beans;
/*    */ 
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ 




















/*    */ public class AssetMouseOverSpecBean extends DataBean
/*    */ {
/*    */   public int addrow()
/*    */     throws MXException
/*    */   {
/* 31 */     super.addrow();



/*    */ 
/* 36 */     return 1;
/*    */   }
/*    */ }
