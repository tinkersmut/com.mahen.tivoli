package com.ibm.tivoli.maximo.asset.topology.constants;

public abstract interface TopologyConstants
{
  public static final String TOPOLOGY_MAX_DEPTH_KEY = "mxe.assettopology.depth";
  public static final String TOPOLOGY_INIT_DEPTH_KEY = "mxe.assettopology.init";
  public static final String TOPOLOGY_MAX_NODES_KEY = "mxe.assettopology.maxnodes";
  public static final String PROPERTY_NODEPOPUP_TARGET = "nodepopuptarget";
  public static final String PROPERTY_LINKPOPUP_TARGET = "linkpopuptarget";
  public static final String PROPERTY_MOVETOPOPUP_TARGET = "movetopopuptarget";
  public static final String PROPERTY_MAXNODE_DEPTH = "topologydepth";
  public static final String PROPERTY_INITNODE_DEPTH = "topologyinitdepth";
  public static final String PROPERTY_MAXNODES = "topologymaxnodes";
  public static final String PROPERTY_APP_NAME = "appname";
  public static final String PROPERTY_CHANGE_APP_VAL = "CHANGE";
  public static final String PROPERTY_CI_APP_VAL = "CI";
  public static final String PROPERTY_ACTCI_APP_VAL = "ACTCI";
  public static final String URL_PARAM_DETAILED_VIEW = "detailview";
  public static final String URL_PARAM_GRAPH_DEPTH = "graphdepth";
  public static final String URL_PARAM_IA_TASK_TARGETS = "taskTargets";
  public static final String URL_PARAM_ASSETNUM = "assetnum";
  public static final String URL_PARAM_CINUM_SEPERATOR = ",";
  public static final String ASSET_TO_CACHE_RELATION = "ASSETCACHEREL";
  public static final String RADIO_BIZ_ACTION = "BUSINESS";
  public static final String RADIO_DET_ACTION = "DETAIL";
  public static final String ASSETDETAILS_SELECT_VALUE = "SELECTVALUE";
  public static final String ASSETDETAILS_DETAILS = "DETAILS";
  public static final String ASSETDETAILS_REPORT_DOWNTIME = "REPORTDOWNTIME";
  public static final String ASSETDETAILS_MANAGE_DOWNTIME_HISTORY = "MANAGEDOWNTIMEHISTORY";
  public static final String ASSETDETAILS_SERVICE_REQUEST = "SERVICEREQUEST";
  public static final String ASSETDETAILS_INCIDENT = "INCIDENT";
  public static final String ASSETDETAILS_PROBLEM = "PROBLEM";
  public static final String ASSETDETAILS_WORK_ORDER = "WORKORDER";
  public static final String ASSETDETAILS_CHANGE = "CHANGE";
  public static final String ASSETDETAILS_RELEASE = "RELEASE";
  public static final String ASSETDETAILS_WORK_DETAILS = "WORKDETAILS";
  public static final String ASSETDETAILS_VIEW_CONTRACTS = "VIEWCONTRACTS";
  public static final String ASSETDETAILS_VIEW_TICKETS = "VIEWTICKETS";
  public static final String ASSETDETAILS_MOVE_HISTORY = "MOVEHISTORY";
  public static final String ASSETDETAILS_SPEC_HISTORY = "SPECHISTORY";
  public static final String ASSETDETAILS_RELATIONSHIP_HISTORY = "RELATIONSHIPHISTORY";
  public static final String SUBMENU_VIEW = "View";
  public static final String SUBMENU_CREATE = "Create";
}
