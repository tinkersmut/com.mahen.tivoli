/*    */ package com.ibm.tivoli.maximo.asset.topology.renderer;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.asset.topology.applet.TopologyApplet;
/*    */ import com.ibm.tivoli.maximo.asset.topology.applet.util.AssetTopologyUtil;
/*    */ import ilog.views.graphic.IlvGraphicSet;
/*    */ import ilog.views.sdm.graphic.IlvURLGraphic;
/*    */ 


















/*    */ public class GraphicRenderer extends IlvGraphicSet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private IlvURLGraphic graphic;
/*    */   private static final String defaultIcon = "icon_asset_default.svg";
/* 31 */   private AssetTopologyUtil atu = null;
/*    */ 
/*    */   public GraphicRenderer()
/*    */   {
/* 35 */     customize();
/*    */   }

/*    */   private void customize() {
/* 39 */     this.graphic = new IlvURLGraphic();
/* 40 */     addObject(this.graphic, false);
/* 41 */     this.atu = AssetTopologyUtil.instance();
/*    */   }

/*    */   public void setImage(String image) {
/* 45 */     String totalPath = null;
/*    */ 
/* 47 */     this.atu.logMessage("recevied image=[" + image + "]");
/*    */ 
/* 49 */     if ((image == null) || (image.trim().equals("")))

/*    */     {
/* 52 */       totalPath = TopologyApplet.NODE_ICONS_PATH_DEFAULT + "icon_asset_default.svg";
/*    */     }
/*    */     else {
/* 55 */       totalPath = TopologyApplet.NODE_ICONS_LOC + image;
/*    */     }
/*    */ 
/* 58 */     this.atu.logMessage("image path=[" + totalPath + "]");
/*    */ 
/* 60 */     this.graphic.setURL(totalPath);
/*    */   }
/*    */ }
