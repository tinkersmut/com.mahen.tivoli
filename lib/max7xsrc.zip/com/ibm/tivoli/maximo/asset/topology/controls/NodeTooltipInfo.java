/*    */ package com.ibm.tivoli.maximo.asset.topology.controls;
/*    */ 















/*    */ public class NodeTooltipInfo
/*    */ {
/* 20 */   private String resourcePropertyId = null;
/* 21 */   private String attribute = null;
/* 22 */   private String method = null;
/*    */ 
/*    */   public NodeTooltipInfo(String resourcePropertyId, String attribute, String method) {
/* 25 */     this.resourcePropertyId = resourcePropertyId;
/* 26 */     this.attribute = attribute;
/* 27 */     this.method = method;
/*    */   }

/*    */   public String getResourcePropertyId() {
/* 31 */     return this.resourcePropertyId;
/*    */   }

/*    */   public String getAttribute() {
/* 35 */     return this.attribute;
/*    */   }

/*    */   public String getMethod() {
/* 39 */     return this.method;
/*    */   }
/*    */ }
