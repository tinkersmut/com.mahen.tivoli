/*    */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*    */ 
/*    */ public class ModelType
/*    */ {
/* 21 */   public static final ModelType BUSINESS = new ModelType();
/*    */ 
/* 23 */   public static final ModelType DEATAILS = new ModelType();
/*    */ }
