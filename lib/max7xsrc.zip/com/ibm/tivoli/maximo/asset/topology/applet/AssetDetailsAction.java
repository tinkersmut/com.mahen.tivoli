/*    */ package com.ibm.tivoli.maximo.asset.topology.applet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.asset.ilog.applet.ILogApplet;
/*    */ import ilog.views.IlvGraphic;
/*    */ import ilog.views.diagrammer.IlvDiagrammer;
/*    */ import ilog.views.sdm.IlvSDMEngine;
/*    */ import ilog.views.swing.IlvPopupMenuContext;
/*    */ import ilog.views.swing.IlvPopupMenuManager;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import java.util.Hashtable;
/*    */ import java.util.ResourceBundle;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JMenuItem;
/*    */ 















/*    */ public class AssetDetailsAction extends AbstractAction
/*    */ {
/*    */   private static final long serialVersionUID = 680717907086173692L;
/*    */   private IlvDiagrammer diagrammer;
/*    */   private ILogApplet applet;
/*    */   private String target;
/*    */   private String actionKey;
/*    */ 
/*    */   public AssetDetailsAction(IlvDiagrammer diagrammer, ILogApplet applet, String target, ResourceBundle bundle, String actionKey)
/*    */   {
/* 42 */     super(bundle.getString("Topology.Label.AssetDetails." + actionKey + ".Name"));
/* 43 */     this.diagrammer = diagrammer;
/* 44 */     this.applet = applet;
/* 45 */     this.target = target;
/* 46 */     this.actionKey = actionKey;
/*    */   }

/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/* 51 */     JMenuItem m = (JMenuItem)e.getSource();

/*    */ 
/* 54 */     IlvPopupMenuContext context = IlvPopupMenuManager.getPopupMenuContext(m);
/* 55 */     if (context == null)
/*    */     {
/* 57 */       JMenuItem jmi = (JMenuItem)m.getClientProperty("assetTopoParentJMenuItem");
/* 58 */       context = IlvPopupMenuManager.getPopupMenuContext(jmi);
/*    */     }
/* 60 */     if (context == null) return;
/*    */ 
/* 62 */     IlvGraphic g = context.getGraphic();
/*    */ 
/* 64 */     Object obj = (g == null) ? null : this.diagrammer.getEngine().getObject(g);
/* 65 */     if (obj == null) return;

/*    */ 
/* 68 */     Hashtable args = new Hashtable();
/* 69 */     String assetnum = (String)this.diagrammer.getObjectProperty(obj, "assetnum");
/*    */     try
/*    */     {
/* 72 */       args.put("assetnum", URLEncoder.encode(assetnum, "UTF-8"));
/* 73 */       args.put("actionkey", this.actionKey);
/*    */     }
/*    */     catch (UnsupportedEncodingException e1) {
/* 76 */       args.put("assetnum", assetnum);
/*    */     }
/*    */ 
/* 79 */     this.applet.sendEvent("OnAllAssetDetails", this.target, args);
/*    */   }
/*    */ }
