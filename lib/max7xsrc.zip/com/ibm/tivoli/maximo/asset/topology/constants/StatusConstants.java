/*    */ package com.ibm.tivoli.maximo.asset.topology.constants;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 























































/*    */ public class StatusConstants
/*    */ {
/*    */   protected static final String NOTREADY_MODEL = "NOT READY";
/*    */   protected static final String NOTREADY_ILOG = "NOTREADY";
/*    */   protected static final String UNINITIALIZED_MODEL = "UNINITIALIZED";
/*    */   protected static final String UNINITIALIZED_ILOG = "UNINITIALIZED";
/*    */   protected static final String BUILD_MODEL = "BUILD";
/*    */   protected static final String BUILD_ILOG = "BUILD";
/*    */   protected static final String DECOMMISSIONED_MODEL = "DECOMMISSIONED";
/*    */   protected static final String DECOMMISSIONED_ILOG = "DECOMMISSIONED";
/*    */   protected static final String DEVELOPMENT_MODEL = "DEVELOPMENT";
/*    */   protected static final String DEVELOPMENT_ILOG = "DEVELOPMENT";
/*    */   protected static final String DRAFT_MODEL = "DRAFT";
/*    */   protected static final String DRAFT_ILOG = "DRAFT";
/*    */   protected static final String INVENTORY_MODEL = "INVENTORY";
/*    */   protected static final String INVENTORY_ILOG = "INVENTORY";
/*    */   protected static final String POSTPRODUCTION_MODEL = "POSTPRODUCTION";
/*    */   protected static final String POSTPRODUCTION_ILOG = "POSTPRODUCTION";
/*    */   protected static final String PREPRODUCTION_MODEL = "PREPRODUCTION";
/*    */   protected static final String PREPRODUCTION_ILOG = "PREPRODUCTION";
/*    */   protected static final String SUNSET_MODEL = "SUNSET";
/*    */   protected static final String SUNSET_ILOG = "SUNSET";
/*    */   protected static final String ARCHIVED_MODEL = "ARCHIVED";
/*    */   protected static final String ARCHIVED_ILOG = "ARCHIVED";
/*    */   protected static final String OPERATING_MODEL = "OPERATING";
/*    */   protected static final String OPERATING_ILOG = "OPERATING";
/*    */   protected static final String PRODUCTION_MODEL = "PRODUCTION";
/*    */   protected static final String PRODUCTION_ILOG = "PRODUCTION";
/* 66 */   private static Map<String, String> model2ilog = new HashMap();
/*    */ 
/*    */   public static String flavourOfModel2ILOG(String modelFlavour)
/*    */   {
/* 93 */     return ((String)model2ilog.get(modelFlavour));
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 69 */     model2ilog.put("NOT READY", "NOTREADY");
/* 70 */     model2ilog.put("UNINITIALIZED", "UNINITIALIZED");
/* 71 */     model2ilog.put("BUILD", "BUILD");
/* 72 */     model2ilog.put("DECOMMISSIONED", "DECOMMISSIONED");
/* 73 */     model2ilog.put("DEVELOPMENT", "DEVELOPMENT");
/* 74 */     model2ilog.put("DRAFT", "DRAFT");
/* 75 */     model2ilog.put("INVENTORY", "INVENTORY");
/* 76 */     model2ilog.put("POSTPRODUCTION", "POSTPRODUCTION");
/* 77 */     model2ilog.put("PREPRODUCTION", "PREPRODUCTION");
/* 78 */     model2ilog.put("SUNSET", "SUNSET");
/* 79 */     model2ilog.put("ARCHIVED", "ARCHIVED");
/* 80 */     model2ilog.put("OPERATING", "OPERATING");
/* 81 */     model2ilog.put("PRODUCTION", "PRODUCTION");
/*    */   }
/*    */ }
