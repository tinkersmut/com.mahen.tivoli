/*    */ package com.ibm.tivoli.maximo.asset.topology.renderer;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.asset.topology.beans.TargetHelper;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JList;
/*    */ import javax.swing.ListCellRenderer;
/*    */ 



















/*    */ public class TargetCellRenderer extends JLabel
/*    */   implements ListCellRenderer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 32 */   private final Color SELECTED_BG_COLOR = new Color(0, 0, 128);
/*    */ 
/*    */   public TargetCellRenderer() { setOpaque(true);
/*    */   }
/*    */ 
/*    */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*    */   {
/* 40 */     TargetHelper entry = (TargetHelper)value;
/* 41 */     setText(entry.getCinum());
/*    */ 
/* 43 */     setToolTipText(entry.getDescription());
/* 44 */     setBackground((isSelected) ? this.SELECTED_BG_COLOR : Color.white);
/* 45 */     setForeground((isSelected) ? Color.white : Color.black);
/*    */ 
/* 47 */     return this;
/*    */   }
/*    */ }
