/*    */ package com.ibm.tivoli.maximo.asset.topology.renderer;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.asset.topology.applet.DiagrammerApplet;
/*    */ import com.ibm.tivoli.maximo.asset.topology.beans.TargetHelper;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JList;
/*    */ import javax.swing.ListCellRenderer;
/*    */ 

















/*    */ public class ImpactedTargetCellRenderer extends JLabel
/*    */   implements ListCellRenderer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 32 */   public static final Color DARK_GRAY = new Color(128, 128, 128);
/* 33 */   public static final Color LIGHT_GRAY = new Color(224, 224, 224);
/*    */ 
/*    */   public ImpactedTargetCellRenderer() {
/* 36 */     setOpaque(true);
/*    */   }



/*    */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*    */   {
/* 43 */     TargetHelper entry = (TargetHelper)value;
/* 44 */     setText(entry.getCinum() + " | " + entry.getDescription());
/*    */ 
/* 46 */     setToolTipText(entry.getDescription());
/* 47 */     setBackground(LIGHT_GRAY);
/* 48 */     setForeground(Color.black);
/* 49 */     if (isSelected) {
/* 50 */       setIcon(DiagrammerApplet.createImageIcon("node_notshown.gif"));
/* 51 */       setIconTextGap(5);
/*    */     } else {
/* 53 */       setIcon(null);
/*    */     }
/* 55 */     return this;
/*    */   }
/*    */ }
