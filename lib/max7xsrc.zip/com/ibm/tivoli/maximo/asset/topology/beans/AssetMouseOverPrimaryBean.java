/*    */ package com.ibm.tivoli.maximo.asset.topology.beans;
/*    */ 
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ 




















/*    */ public class AssetMouseOverPrimaryBean extends DataBean
/*    */ {
/*    */   public int addrow()
/*    */     throws MXException
/*    */   {
/* 31 */     super.addrow();
/*    */ 
/* 33 */     return 1;
/*    */   }
/*    */ }
