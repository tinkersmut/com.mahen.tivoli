/*     */ package com.ibm.tivoli.maximo.asset.topology.applet.util;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.asset.topology.applet.TopologyApplet;
/*     */ import com.ibm.tivoli.maximo.util.StringUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 




























/*     */ public class AssetTopologyUtil
/*     */ {
/*     */   private static AssetTopologyUtil atu;
/*  34 */   private TopologyApplet applet = null;
/*  35 */   private SimpleDateFormat logDateFormat = null;
/*     */ 
/*     */   public static synchronized AssetTopologyUtil instance()
/*     */   {
/*  45 */     if (atu == null)
/*     */     {
/*  47 */       atu = new AssetTopologyUtil();
/*     */     }
/*  49 */     return atu;
/*     */   }

/*     */   private AssetTopologyUtil()
/*     */   {
/*  54 */     this.logDateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS");
/*     */   }








/*     */   public void logMessage(String message, Throwable t)
/*     */   {
/*  66 */     String currentDate = this.logDateFormat.format(new Date());
/*     */ 
/*  68 */     System.out.println(currentDate + " " + getAppletName() + " : " + message);
/*  69 */     if (t == null)
/*     */       return;
/*  71 */     t.printStackTrace(System.out);
/*     */   }







/*     */   public void logMessage(String message)
/*     */   {
/*  82 */     logMessage(message, null);
/*     */   }






/*     */   public void logMessage(Object o)
/*     */   {
/*  92 */     logMessage(o.toString());
/*     */   }





/*     */   protected String getAppletName()
/*     */   {
/* 101 */     if (this.applet == null) {
/* 102 */       return "";
/*     */     }
/*     */ 
/* 105 */     String name = this.applet.getName();
/* 106 */     if (StringUtil.isEmptyString(name)) {
/* 107 */       return "";
/*     */     }
/* 109 */     return name;
/*     */   }




/*     */   public void setApplet(TopologyApplet applet)
/*     */   {
/* 117 */     this.applet = applet;
/*     */   }
/*     */ }
