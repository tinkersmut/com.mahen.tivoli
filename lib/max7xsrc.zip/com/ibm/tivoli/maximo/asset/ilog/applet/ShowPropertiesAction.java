/*     */ package com.ibm.tivoli.maximo.asset.ilog.applet;
/*     */ 
/*     */ import ilog.views.IlvGraphic;
/*     */ import ilog.views.IlvPoint;
/*     */ import ilog.views.diagrammer.IlvDiagrammer;
/*     */ import ilog.views.diagrammer.application.IlvDiagrammerPropertySheet;
/*     */ import ilog.views.sdm.IlvSDMEngine;
/*     */ import ilog.views.swing.IlvPopupMenuContext;
/*     */ import ilog.views.swing.IlvPopupMenuManager;
/*     */ import java.awt.Container;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Point;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.SwingUtilities;
/*     */ 


















/*     */ public class ShowPropertiesAction extends AbstractAction
/*     */ {
/*     */   private IlvDiagrammer diagrammer;
/*     */   private IlvDiagrammerPropertySheet propertySheet;
/*     */   private JDialog propertySheetDialog;
/*     */   private ResourceBundle bundle;
/*     */ 
/*     */   public ShowPropertiesAction(IlvDiagrammer diagrammer, ResourceBundle bundle)
/*     */   {
/*  52 */     super(bundle.getString("Diagrammer.Label.Properties.Name"));
/*  53 */     putValue("Name", bundle.getString("Diagrammer.Label.Properties.Name"));
/*  54 */     this.diagrammer = diagrammer;
/*  55 */     this.bundle = bundle;
/*     */   }


/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/*  61 */     JMenuItem m = (JMenuItem)e.getSource();

/*     */ 
/*  64 */     IlvPopupMenuContext context = IlvPopupMenuManager.getPopupMenuContext(m);
/*  65 */     if (context == null) return;
/*  66 */     IlvGraphic g = context.getGraphic();
/*     */ 
/*  68 */     Object obj = (g == null) ? null : this.diagrammer.getEngine().getObject(g);
/*     */ 
/*  70 */     if (obj == null) return;

/*     */ 
/*  73 */     IlvPoint p = context.getPoint();
/*     */ 
/*  75 */     showProperties(this.diagrammer, obj, (int)p.x, (int)p.y);
/*     */   }

/*     */   private void showProperties(IlvDiagrammer diagrammer, Object object, int x, int y)
/*     */   {
/*  80 */     if (this.propertySheet == null)
/*     */     {
/*  82 */       Window window = SwingUtilities.getWindowAncestor(diagrammer);
/*  83 */       if (window instanceof Frame)
/*  84 */         this.propertySheetDialog = new JDialog((Frame)window);
/*     */       else
/*  86 */         this.propertySheetDialog = new JDialog();
/*  87 */       this.propertySheetDialog.setTitle(this.bundle.getString("Diagrammer.Label.Properties.Name"));
/*  88 */       this.propertySheetDialog.setModal(true);
/*     */ 
/*  90 */       this.propertySheet = new IlvDiagrammerPropertySheet();
/*  91 */       this.propertySheetDialog.getContentPane().add(this.propertySheet);

/*     */ 
/*  94 */       this.propertySheetDialog.applyComponentOrientation(this.diagrammer.getComponentOrientation());
/*  95 */       this.propertySheet.applyComponentOrientation(this.diagrammer.getComponentOrientation());

/*     */ 
/*  98 */       JPanel buttonPanel = new JPanel(new FlowLayout(1, 5, 5));
/*  99 */       JButton close = new JButton("Close");
/*     */ 
/* 101 */       buttonPanel.applyComponentOrientation(this.diagrammer.getComponentOrientation());
/* 102 */       close.applyComponentOrientation(this.diagrammer.getComponentOrientation());
/*     */ 
/* 104 */       close.addActionListener(new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 106 */           ShowPropertiesAction.this.propertySheetDialog.setVisible(false);
/*     */         }
/*     */       });
/* 109 */       buttonPanel.add(close);
/* 110 */       this.propertySheetDialog.getContentPane().add(buttonPanel, "Last");
/*     */ 
/* 112 */       this.propertySheetDialog.setSize(300, 300);
/*     */     }
/* 114 */     Point pos = diagrammer.getLocationOnScreen();
/* 115 */     this.propertySheetDialog.setLocation(pos.x + x + 20, pos.y + y + 20);
/*     */ 
/* 117 */     this.propertySheetDialog.setVisible(true);
/*     */   }
/*     */ }
