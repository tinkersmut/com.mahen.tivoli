/*     */ package com.ibm.tivoli.maximo.asset.ilog.controls;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.webclient.controls.ControlServletRequestHandler;
/*     */ import psdi.webclient.controls.Tab;
/*     */ import psdi.webclient.controls.TabGroup;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.beans.DataBeanListener;
/*     */ import psdi.webclient.system.controller.DatasrcInstance;
/*     */ import psdi.webclient.system.controller.PageInstance;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 





/*     */ public abstract class ILogControl extends DatasrcInstance
/*     */   implements DataBeanListener, ControlServletRequestHandler
/*     */ {
/*     */   private static final String APPLET_LOAD_TIMEOUT_KEY = "telco.applet.loadmsg.timeout";
/*     */   private boolean appletVisible;
/*     */   private boolean refreshVisibility;
/*     */   private boolean dataChanged;
/*     */   private int appletLoadingTimeout;
/*     */   private String error;
/*     */   protected ResourceBundle bundle;
/*     */   private boolean initialLoadRequired;
/*     */ 
/*     */   public ILogControl()
/*     */   {
/*  38 */     this.appletVisible = false;
/*  39 */     this.refreshVisibility = false;
/*  40 */     this.dataChanged = false;
/*     */ 
/*  42 */     this.appletLoadingTimeout = 60;
/*     */ 
/*  44 */     this.error = null;

/*     */ 
/*  47 */     this.initialLoadRequired = true;
/*     */   }




/*     */   public boolean getDataChanged() {
/*  54 */     return this.dataChanged;
/*     */   }

/*     */   public void setDataChanged(boolean dataChanged)
/*     */   {
/*  59 */     this.dataChanged = dataChanged;
/*     */   }

/*     */   public void structureChangedEvent(DataBean speaker)
/*     */   {
/*  64 */     setChangedFlag(true);
/*  65 */     this.dataChanged = true;
/*     */   }

/*     */   public void initialize()
/*     */   {
/*  70 */     this.appletVisible = false;
/*  71 */     this.refreshVisibility = false;
/*  72 */     this.dataChanged = false;
/*  73 */     this.error = null;
/*  74 */     getDataBean().addListener(this);
/*  75 */     super.initialize();
/*  76 */     this.bundle = ResourceBundle.getBundle("com.ibm.tivoli.maximo.asset.ilog.applet.properties.flowmap", getWebClientSession().getLocale());
/*     */     try {
/*  78 */       String timeoutStr = MXServer.getMXServer().getConfig().getProperty("telco.applet.loadmsg.timeout");
/*  79 */       if (timeoutStr != null) {
/*  80 */         int i = Integer.parseInt(timeoutStr);
/*  81 */         if (i > 0)
/*  82 */           this.appletLoadingTimeout = i;
/*     */       }
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/*  87 */       e.printStackTrace(System.out);
/*     */     }
/*     */   }

/*     */   public int render() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/*     */     try {
/*  94 */       checkVisibility();
/*  95 */       return super.render();
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }

/*     */   public String getAppId() {
/* 103 */     String appId = getWebClientSession().getCurrentAppId();
/* 104 */     return appId;
/*     */   }

/*     */   public String getUiSessionId()
/*     */   {
/* 109 */     String uisession = getWebClientSession().getUISessionID();
/* 110 */     return uisession;
/*     */   }

/*     */   public int checkVisibility()
/*     */   {
/* 115 */     PageInstance currentPage = getPage();
/*     */ 
/* 117 */     TabGroup maintabgroup = (TabGroup)currentPage.getControlInstance(getProperty("tabgroupid"));

/*     */ 
/* 120 */     boolean shouldAppVis = (maintabgroup != null) && (maintabgroup.getCurrentTab().getId().equalsIgnoreCase(getProperty("tabid")));
/*     */ 
/* 122 */     if (shouldAppVis != getAppletVisible())
/*     */     {
/* 124 */       this.appletVisible = shouldAppVis;
/* 125 */       setRefreshVisibility(true);
/* 126 */       setChangedFlag();
/*     */     }
/*     */ 
/* 129 */     return 1;
/*     */   }

/*     */   public boolean getAppletVisible()
/*     */   {
/* 134 */     return this.appletVisible;
/*     */   }

/*     */   public boolean getRefreshVisibility()
/*     */   {
/* 139 */     return this.refreshVisibility;
/*     */   }

/*     */   public void setRefreshVisibility(boolean vis)
/*     */   {
/* 144 */     this.refreshVisibility = vis;
/*     */   }

/*     */   public int updateapplet()
/*     */   {
/* 149 */     return 1;
/*     */   }

/*     */   public int showerror()
/*     */   {
/* 154 */     WebClientSession wcs = getWebClientSession();
/* 155 */     WebClientEvent currentEvent = wcs.getCurrentEvent();
/* 156 */     Object eventValue = wcs.getCurrentEvent().getValue();
/*     */ 
/* 158 */     if (eventValue instanceof MXException)
/*     */     {
/* 160 */       wcs.showMessageBox(currentEvent, (MXException)eventValue);
/*     */     }
/* 162 */     else if (eventValue instanceof String)
/*     */     {
/* 164 */       setError((String)eventValue);
/* 165 */       setChangedFlag(true);
/*     */     }
/* 167 */     return 1;
/*     */   }

/*     */   public String getError()
/*     */   {
/* 172 */     return this.error;
/*     */   }

/*     */   public void setError(String error)
/*     */   {
/* 177 */     this.error = error;
/*     */   }

/*     */   public String getSkinName() {
/* 181 */     String skinName = getWebClientSession().getSkinName();
/* 182 */     if (skinName == null) {
/* 183 */       skinName = "";
/*     */     }
/*     */     else {
/* 186 */       skinName = skinName.trim();
/*     */     }
/* 188 */     return skinName;
/*     */   }

/*     */   public String bidiPrepareForWrap(String str) {
/* 192 */     if (str == null)
/* 193 */       return str;
/* 194 */     if ((!(str.startsWith("‪"))) && (!(str.startsWith("‫"))))
/* 195 */       return str;
/* 196 */     if (str.length() < 5)
/* 197 */       return str;
/* 198 */     int length = str.length();
/* 199 */     StringBuffer result = new StringBuffer(str.substring(0, 2));
/* 200 */     int k = 2; int j = 2;
/* 201 */     boolean start = false; boolean stop = false;
/* 202 */     byte dir = Character.getDirectionality(str.charAt(2));
/* 203 */     boolean rtlChars = (dir == 1) || (dir == 2);
/* 204 */     for (int i = 2; i < str.length() - 2; ++i) {
/* 205 */       if (Character.isWhitespace(str.charAt(i))) {
/* 206 */         start = false;
/*     */       }
/* 208 */       else if (!(start)) {
/* 209 */         start = true;
/* 210 */         if ((i - k < 11) && (!(stop))) {
/* 211 */           j = i;
/*     */         } else {
/* 213 */           if (k != 2)
/* 214 */             result.append("\n");
/* 215 */           if (j == k) {
/* 216 */             result.append(str.charAt(0) + str.substring(k, i));
/* 217 */             k = j = i;
/*     */           }
/*     */           else {
/* 220 */             result.append(str.charAt(0) + str.substring(k, j));
/* 221 */             k = j;
/*     */           }
/* 223 */           dir = Character.getDirectionality(str.charAt(k));
/* 224 */           rtlChars = (dir == 1) || (dir == 2);
/* 225 */           stop = false;
/*     */         }
/*     */       }
/* 228 */       if (!(Character.isWhitespace(str.charAt(i)))) {
/* 229 */         byte cDir = Character.getDirectionality(str.charAt(i));
/* 230 */         boolean cRtlChars = (cDir == 1) || (cDir == 2);
/* 231 */         if (rtlChars != cRtlChars)
/* 232 */           stop = true;
/*     */       }
/*     */     }
/* 235 */     if (k != 2)
/* 236 */       result.append("\n" + str.charAt(0));
/* 237 */     result.append(str.substring(k, str.length() - 2));
/* 238 */     result.append(str.substring(length - 2, length));
/* 239 */     return result.toString();
/*     */   }

/*     */   public String getAppletLoadingMsg() {
/* 243 */     return getWebClientSession().getMessage("assettopo", "LoadingAppletsPleaseWait");
/*     */   }

/*     */   public int getAppletLoadingTimeout() {
/* 247 */     return (this.appletLoadingTimeout * 1000);
/*     */   }

/*     */   public boolean isInitialLoadRequired() {
/* 251 */     return this.initialLoadRequired;
/*     */   }

/*     */   public void setInitialLoadRequired(boolean initialLoadRequired) {
/* 255 */     this.initialLoadRequired = initialLoadRequired;
/*     */   }
/*     */ }
