/*     */ package com.ibm.tivoli.maximo.asset.ilog.applet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.asset.topology.applet.TopologyApplet;
/*     */ import com.ibm.tivoli.maximo.asset.topology.applet.util.AssetTopologyUtil;
/*     */ import com.ibm.tivoli.maximo.util.StringUtil;
/*     */ import ilog.views.util.IlvResourceUtil;
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.EventQueue;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JApplet;
/*     */ import netscape.javascript.JSObject;
/*     */ 





/*     */ public abstract class ILogApplet extends JApplet
/*     */ {
/*     */   protected ResourceBundle bundle;
/*     */   private String uiSessionId;
/*     */   private String appId;
/*     */   private String controlId;
/*     */   private String loadOnInit;
/*     */   private String skinName;
/*     */   private String name;
/*     */   protected boolean isRTL;
/*     */   protected boolean isBidi;
/*     */   private boolean setupCompleted;
/*     */   public static final String LRE = "‪";
/*     */   public static final String RLE = "‫";
/*     */   public static final String PDF = "‬";
/*     */   public static final String LRM = "‎";
/*     */   public static final String RLM = "‏";
/*     */   public static final String CHAR_ENCODING = "UTF-8";
/*     */   protected AssetTopologyUtil atu;
/*     */ 
/*     */   public ILogApplet()
/*     */   {
/*  50 */     this.skinName = "";

/*     */ 
/*  53 */     this.isRTL = false;
/*  54 */     this.isBidi = false;
/*  55 */     this.setupCompleted = false;









/*     */ 
/*  66 */     this.atu = null; }





/*     */   public final void init() { try { this.atu = AssetTopologyUtil.instance();
/*  73 */       this.atu.setApplet((TopologyApplet)this);
/*     */ 
/*  75 */       this.atu.logMessage("init starting...");
/*     */ 
/*  77 */       this.name = getParameter("name");
/*  78 */       this.uiSessionId = getParameter("uisessionid");
/*  79 */       this.controlId = getParameter("controlid");
/*  80 */       this.appId = getParameter("appId");
/*  81 */       this.loadOnInit = getParameter("loadoninit");
/*  82 */       this.skinName = getParameter("skinname");
/*  83 */       this.atu.logMessage("Applet skin: " + this.skinName);
/*  84 */       String appletLocale = getParameter("appletlocale");
/*  85 */       this.atu.logMessage("appletlocale: " + appletLocale);
/*     */ 
/*  87 */       String language = null;
/*  88 */       String country = null;
/*  89 */       String variant = null;
/*  90 */       StringTokenizer st = new StringTokenizer(appletLocale, "_");
/*  91 */       if (st.hasMoreTokens())
/*     */       {
/*  93 */         language = st.nextToken();
/*  94 */         if (st.hasMoreTokens())
/*     */         {
/*  96 */           country = st.nextToken();
/*  97 */           if (st.hasMoreTokens())
/*     */           {
/*  99 */             variant = st.nextToken();
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 104 */       if ((language != null) && (country != null) && (variant != null))
/*     */       {
/* 106 */         setLocale(new Locale(language, country, variant));
/*     */       }
/* 108 */       else if ((language != null) && (country != null))
/*     */       {
/* 110 */         setLocale(new Locale(language, country));
/*     */       }
/* 112 */       else if (language != null)
/*     */       {
/* 114 */         setLocale(new Locale(language));
/*     */       }
/*     */ 
/* 117 */       this.atu.logMessage("parsed language=[" + language + "], parsed country/region=[" + country + "], parsed variant=[" + variant + "]");


/*     */ 
/* 121 */       String langcode = getParameter("langcode");
/* 122 */       this.atu.logMessage("User Specific Lang Code: " + langcode);
/* 123 */       if ((!(StringUtil.isEmptyString(langcode))) && (!(language.equalsIgnoreCase(langcode)))) {
/* 124 */         if (StringUtil.isEmptyString(country)) {
/* 125 */           this.atu.logMessage("setLocale with language=[" + langcode + "]");
/* 126 */           setLocale(new Locale(langcode));
/*     */         }
/*     */         else {
/* 129 */           this.atu.logMessage("setLocale with language=[" + langcode + "], country/region=[" + country + "]");
/* 130 */           setLocale(new Locale(langcode, country));
/*     */         }
/*     */       }
/*     */ 
/* 134 */       this.atu.logMessage("Applet locale: " + getLocale());
/* 135 */       String orient = getParameter("rtlOrientation");
/* 136 */       if ((orient != null) && (orient.equals("true")))
/* 137 */         this.isRTL = true;
/* 138 */       String bidiEnabled = getParameter("bidienabled");
/* 139 */       if ((bidiEnabled != null) && (bidiEnabled.equals("true"))) {
/* 140 */         this.isBidi = true;
/*     */       }
/*     */ 
/* 143 */       if (this.isRTL) {
/* 144 */         applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);

/*     */       }
/*     */ 
/* 148 */       this.atu.logMessage("loadDataOnInit()=[" + loadDataOnInit() + "]");
/* 149 */       if (loadDataOnInit()) {
/* 150 */         loadData("true");
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 155 */       this.atu.logMessage("applet init is done!");
/*     */     }
/*     */   }



/*     */   public final void loadData(String initialLoadRequired)
/*     */   {
/* 163 */     this.atu.logMessage("Entering loadData");
/*     */ 
/* 165 */     boolean isInitialLoadRequired = (initialLoadRequired == null) || (initialLoadRequired.equalsIgnoreCase("true"));
/* 166 */     EventQueue.invokeLater(new Runnable(isInitialLoadRequired) {
/*     */       public void run() {
/*     */         try {
/* 169 */           ILogApplet.this.atu.logMessage("starting to load data...");
/*     */ 
/* 171 */           if (!(ILogApplet.this.setupCompleted))
/*     */           {
/* 173 */             ILogApplet.this.atu.logMessage("jvm default locale =[" + Locale.getDefault() + "], using locale=[" + ILogApplet.this.getLocale() + "]");
/* 174 */             ILogApplet.this.bundle = ResourceBundle.getBundle("com.ibm.tivoli.maximo.asset.ilog.applet.properties.flowmap", ILogApplet.this.getLocale());
/* 175 */             ILogApplet.this.atu.logMessage("effective resource bundle locale, l=[" + ILogApplet.this.bundle.getLocale().getLanguage() + "], c=[" + ILogApplet.this.bundle.getLocale().getCountry() + "], v=[" + ILogApplet.this.bundle.getLocale().getVariant() + "]");
/* 176 */             ILogApplet.this.createGUI();
/* 177 */             ILogApplet.access$002(ILogApplet.this, true);
/* 178 */             ILogApplet.this.atu.logMessage("Applet " + ILogApplet.this.getClass().getName() + " setup completed");
/*     */           }
/*     */ 
/* 181 */           ILogApplet.this.loadModel(this.val$isInitialLoadRequired);

/*     */         }
/*     */         catch (Throwable t)
/*     */         {
/* 186 */           t.printStackTrace(System.out);

/*     */         }
/*     */         finally
/*     */         {
/*     */         }
/*     */ 
/* 193 */         ILogApplet.this.atu.logMessage("loadData is done");
/*     */       }
/*     */     });
/*     */   }

/*     */   public void showWarnings()
/*     */   {
/* 200 */     if (this.appId != null)
/* 201 */       sendEvent("showwarnings", this.appId);
/*     */   }

/*     */   public static ImageIcon createImageIcon(String name)
/*     */   {
/* 206 */     String path = "images/" + name;
/* 207 */     URL imgURL = ILogApplet.class.getResource(path);
/* 208 */     if (imgURL != null)
/*     */     {
/* 210 */       return new ImageIcon(imgURL);

/*     */     }
/*     */ 
/* 214 */     System.err.println("Couldn't find file: " + path);
/* 215 */     return null;
/*     */   }

/*     */   public URL getControlServletURL(String[] argNames, String[] argValues)
/*     */     throws MalformedURLException
/*     */   {
/* 221 */     URL codeBase = getCodeBase();
/* 222 */     String servletBase = "../../../ControlInterfaceServlet?uisessionid=" + this.uiSessionId + "&controlid=" + this.controlId;
/* 223 */     for (int i = 0; i < argNames.length; ++i)
/*     */     {
/* 225 */       servletBase = servletBase + "&" + argNames[i] + "=" + argValues[i];
/*     */     }
/* 227 */     URL servletUrl = new URL(codeBase, servletBase);
/* 228 */     return servletUrl;
/*     */   }

/*     */   public URL getControlServletURL(Hashtable<String, String[]> args) throws MalformedURLException, UnsupportedEncodingException
/*     */   {
/* 233 */     URL codeBase = getCodeBase();
/* 234 */     String servletBase = "../../../ControlInterfaceServlet?uisessionid=" + this.uiSessionId + "&controlid=" + this.controlId;
/* 235 */     Enumeration argnamesE = args.keys();
/* 236 */     while (argnamesE.hasMoreElements()) {
/* 237 */       String argname = (String)argnamesE.nextElement();
/* 238 */       String[] argvalue = (String[])(String[])args.get(argname);
/* 239 */       servletBase = servletBase + "&" + argname + "=" + arrayToString(argvalue, ",");
/* 240 */       this.atu.logMessage("getControlServletURL:" + servletBase);
/*     */     }
/* 242 */     URL servletUrl = new URL(codeBase, servletBase);
/* 243 */     this.atu.logMessage("composed control servlet url [" + servletUrl + "]");
/* 244 */     return servletUrl;
/*     */   }

/*     */   public static String arrayToString(String[] a, String separator) throws UnsupportedEncodingException {
/* 248 */     StringBuffer result = new StringBuffer();
/* 249 */     if (a.length > 0) {
/* 250 */       result.append(URLEncoder.encode(a[0], "UTF-8"));
/* 251 */       for (int i = 1; i < a.length; ++i) {
/* 252 */         result.append(URLEncoder.encode(separator, "UTF-8"));
/* 253 */         result.append(URLEncoder.encode(a[i], "UTF-8"));
/*     */       }
/*     */     }
/* 256 */     return result.toString();
/*     */   }

/*     */   public boolean loadDataOnInit() {
/* 260 */     return ((this.loadOnInit != null) && (this.loadOnInit.equalsIgnoreCase("true")));
/*     */   }

/*     */   public void sendEvent(String event)
/*     */   {
/* 265 */     sendEvent(event, this.name, null);
/*     */   }

/*     */   public void sendEvent(String event, Hashtable values)
/*     */   {
/* 270 */     sendEvent(event, this.name, values);
/*     */   }

/*     */   public void sendEvent(String event, String target)
/*     */   {
/* 275 */     sendEvent(event, target, null);
/*     */   }

/*     */   public void sendEvent(String event, String target, Hashtable values)
/*     */   {
/* 280 */     String jscript = "";
/*     */ 
/* 282 */     if (values != null)
/*     */     {
/* 284 */       Enumeration keys = values.keys();
/* 285 */       while (keys.hasMoreElements())
/*     */       {
/* 287 */         String keyName = (String)keys.nextElement();
/* 288 */         String value = (String)values.get(keyName);
/* 289 */         jscript = jscript + "addCommInput('" + keyName + "', '" + value + "');";
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 294 */     jscript = jscript + "sendEvent('" + event + "', '" + target + "','');";
/*     */ 
/* 296 */     callJavascriptEval(jscript);
/*     */   }

/*     */   public String getSkinName() {
/* 300 */     return this.skinName;
/*     */   }

/*     */   private void callJavascriptEval(String eval) {
/* 304 */     JSObject win = JSObject.getWindow(this);
/* 305 */     String evalString = eval;
/* 306 */     Runnable javascriptCall = new Runnable(win, evalString) {
/*     */       public void run() {
/*     */         try {
/* 309 */           this.val$win.eval(this.val$evalString);
/*     */         }
/*     */         catch (Throwable t) {
/* 312 */           ILogApplet.this.atu.logMessage("callJavascriptEval", t);
/*     */         }
/*     */       }
/*     */     };
/* 316 */     new Thread(javascriptCall).start();
/*     */   }





/*     */   private static void registerIlog()
/*     */   {
/* 325 */     IlvResourceUtil.setAvailableResourceSuffixes(new String[] { "" });
/*     */   }

/*     */   public static String removeMarkers(String str) {
/* 329 */     if ((str == null) || (str.length() == 0))
/* 330 */       return str;
/* 331 */     return str.replaceAll("‎", "").replaceAll("‏", "").replaceAll("‪", "").replaceAll("‫", "").replaceAll("‬", "");
/*     */   }




/*     */   protected String getUISessionId()
/*     */   {
/* 339 */     return this.uiSessionId;
/*     */   }




/*     */   protected String getControlId()
/*     */   {
/* 347 */     return this.controlId;
/*     */   }

/*     */   public String getName() {
/* 351 */     return this.name;
/*     */   }
/*     */ }
