/*    */ package com.ibm.tivoli.maximo.interaction.ebp;
/*    */ 


















/*    */ public class EndpointInfo
/*    */ {
/*    */   private String epUrl;
/*    */   private String soapAction;
/*    */   private String mep;
/*    */   private String serviceName;
/*    */   private String bindingType;
/*    */ 
/*    */   public EndpointInfo(String serviceName, String epUrl, String soapAction, String bindingType, String mep)
/*    */   {
/* 31 */     this.serviceName = serviceName;
/* 32 */     this.epUrl = epUrl;
/* 33 */     this.soapAction = soapAction;
/* 34 */     this.bindingType = bindingType;
/* 35 */     this.mep = mep;
/*    */   }

/*    */   public String getServiceName()
/*    */   {
/* 40 */     return this.serviceName;
/*    */   }

/*    */   public String getEpUrl()
/*    */   {
/* 45 */     return this.epUrl;
/*    */   }

/*    */   public String getSoapAction()
/*    */   {
/* 50 */     return this.soapAction;
/*    */   }

/*    */   public String getMep()
/*    */   {
/* 55 */     return this.mep;
/*    */   }

/*    */   public String getBindingType()
/*    */   {
/* 60 */     return this.bindingType;
/*    */   }
/*    */ }
