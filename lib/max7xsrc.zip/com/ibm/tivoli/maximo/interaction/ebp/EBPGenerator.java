/*    */ package com.ibm.tivoli.maximo.interaction.ebp;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.interaction.wsdl.OperationInfo;
/*    */ import com.ibm.tivoli.maximo.interaction.wsdl.PortInfo;
/*    */ import com.ibm.tivoli.maximo.interaction.wsdl.ServiceInfo;
/*    */ import com.ibm.tivoli.maximo.interaction.wsdl.WSDLInfo;
/*    */ import org.jdom.Document;
/*    */ import org.jdom.Element;
/*    */ import org.jdom.Namespace;
/*    */ import psdi.iface.util.XMLUtils;
/*    */ import psdi.util.MXException;
/*    */ 



















/*    */ public class EBPGenerator
/*    */ {
/*    */   private String interactionName;
/* 34 */   public static Namespace ebpNS = Namespace.getNamespace("http://www.ibm.com/ebp10");
/*    */ 
/*    */   public EBPGenerator(String interactionName)
/*    */   {
/* 39 */     this.interactionName = interactionName;
/*    */   }


/*    */   public EndpointInfo createEndpoint(WSDLInfo wsdlInfo, String serviceName, String portName, String operationName)
/*    */   {
/* 45 */     ServiceInfo serviceInfo = wsdlInfo.getServiceInfo(serviceName);
/* 46 */     PortInfo portInfo = serviceInfo.getPortInfo(portName);
/* 47 */     OperationInfo operationInfo = portInfo.getOperationInfo(operationName);
/* 48 */     String epUrl = portInfo.getEndPointUrl();
/* 49 */     EndpointInfo endpointInfo = new EndpointInfo(serviceInfo.getName(), epUrl, operationInfo.getSoapAction(), portInfo.getBindingType(), operationInfo.getMep());
/*    */ 
/* 51 */     return endpointInfo;
/*    */   }

/*    */   public byte[] toBytes(EndpointInfo endpointInfo) throws MXException
/*    */   {
/* 56 */     Document doc = new Document();
/* 57 */     Element root = new Element("ENDPOINT", ebpNS);
/* 58 */     doc.setRootElement(root);
/* 59 */     Element mep = new Element("MEP", ebpNS);
/* 60 */     mep.setText(endpointInfo.getMep());
/* 61 */     root.addContent(mep);
/* 62 */     Element soapaction = new Element("SOAPACTION", ebpNS);
/* 63 */     soapaction.setText(endpointInfo.getSoapAction());
/* 64 */     root.addContent(soapaction);
/* 65 */     Element epUrl = new Element("EPURL", ebpNS);
/* 66 */     epUrl.setText(endpointInfo.getEpUrl());
/* 67 */     root.addContent(epUrl);
/* 68 */     Element serviceName = new Element("SERVICENAME", ebpNS);
/* 69 */     serviceName.setText(endpointInfo.getServiceName());
/*    */ 
/* 71 */     root.addContent(serviceName);
/* 72 */     Element binding = new Element("BINDING", ebpNS);
/* 73 */     binding.setText(endpointInfo.getBindingType());
/*    */ 
/* 75 */     root.addContent(binding);
/* 76 */     return XMLUtils.convertDocumentToBytes(doc);
/*    */   }
/*    */ }
