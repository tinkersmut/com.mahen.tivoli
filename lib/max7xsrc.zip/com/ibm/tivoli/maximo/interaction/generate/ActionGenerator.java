/*     */ package com.ibm.tivoli.maximo.interaction.generate;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.List;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.txn.MXTransaction;
/*     */ import psdi.util.MXException;
/*     */ 
































/*     */ public class ActionGenerator
/*     */ {
/*     */   public void addGroupAction(String optionName, String description, String objectName, List<String> memebers, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/*  52 */     SqlFormat sqf = new SqlFormat(userInfo, "action = :1");
/*  53 */     sqf.setObject(1, "ACTION", "ACTION", optionName);
/*  54 */     MboSetRemote actionSet = MXServer.getMXServer().getMboSet("ACTION", userInfo);
/*  55 */     actionSet.setWhere(sqf.format());
/*  56 */     actionSet.reset();
/*  57 */     if (!(actionSet.isEmpty()))
/*     */       return;
/*  59 */     actionSet.setMXTransaction(trans);
/*  60 */     MboRemote action = actionSet.add();
/*  61 */     action.setValue("action", optionName, 2L);
/*  62 */     action.setValue("description", description, 2L);
/*  63 */     action.setValue("objectname", objectName, 2L);
/*  64 */     String groupSynonyms = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("ACTIONTYPE", "GROUP", null, null);
/*     */ 
/*  66 */     action.setValue("type", groupSynonyms, 2L);
/*  67 */     String useWith = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("ACTIONUSEWITH", "ALL", null, null);
/*     */ 
/*  69 */     action.setValue("usewith", useWith, 2L);
/*  70 */     action.setValue("langcode", userInfo.getLangCode(), 2L);
/*  71 */     if (memebers.size() <= 0)
/*     */       return;
/*  73 */     MboSetRemote actionGroupSet = action.getMboSet("ACTION_MEMBERS");
/*  74 */     for (int i = 0; i < memebers.size(); ++i)
/*     */     {
/*  76 */       MboRemote actionGroup = actionGroupSet.add();
/*  77 */       actionGroup.setValue("memeber", (String)memebers.get(i), 2L);
/*  78 */       actionGroup.setValue("sequence", i + 10, 2L);
/*     */     }
/*     */   }








/*     */   public void addCustomAction(String actionName, String description, String objectName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/*  92 */     SqlFormat sqf = new SqlFormat(userInfo, "action = :1");
/*  93 */     sqf.setObject(1, "ACTION", "ACTION", actionName);
/*  94 */     MboSetRemote actionSet = MXServer.getMXServer().getMboSet("ACTION", userInfo);
/*  95 */     actionSet.setWhere(sqf.format());
/*  96 */     actionSet.reset();
/*  97 */     if (!(actionSet.isEmpty()))
/*     */       return;
/*  99 */     actionSet.setMXTransaction(trans);
/* 100 */     MboRemote action = actionSet.add();
/* 101 */     action.setValue("action", actionName, 2L);
/* 102 */     action.setValue("description", description, 2L);
/* 103 */     action.setValue("objectname", objectName, 2L);
/* 104 */     String customSynonyms = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("ACTIONTYPE", "CUSTOM", null, null);
/*     */ 
/* 106 */     action.setValue("type", customSynonyms, 2L);
/* 107 */     action.setValue("parameter", actionName, 2L);
/* 108 */     String useWith = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("ACTIONUSEWITH", "ALL", null, null);
/*     */ 
/* 110 */     action.setValue("usewith", useWith, 2L);
/* 111 */     action.setValue("langcode", userInfo.getLangCode(), 2L);
/* 112 */     action.setValue("dispvalue", "com.ibm.tivoli.maximo.interaction.process.InteractionCustomClass", 2L);
/*     */   }








/*     */   public void addSetValueAction(String optionName, String objectName, String value, String parameter, String object, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 125 */     SqlFormat sqf = new SqlFormat(userInfo, "action = :1");
/* 126 */     sqf.setObject(1, "ACTION", "ACTION", optionName);
/* 127 */     MboSetRemote actionSet = MXServer.getMXServer().getMboSet("ACTION", userInfo);
/* 128 */     actionSet.setWhere(sqf.format());
/* 129 */     actionSet.reset();
/* 130 */     if (!(actionSet.isEmpty()))
/*     */       return;
/* 132 */     actionSet.setMXTransaction(trans);
/* 133 */     MboRemote action = actionSet.add();
/* 134 */     action.setValue("action", optionName, 2L);
/* 135 */     action.setValue("description", "Set Value to " + parameter + " in object " + object, 2L);
/* 136 */     action.setValue("objectname", objectName, 2L);
/* 137 */     String customSynonyms = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("ACTIONTYPE", "SETVALUE", null, null);
/*     */ 
/* 139 */     action.setValue("type", customSynonyms, 2L);
/* 140 */     String useWith = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("ACTIONUSEWITH", "ALL", null, null);
/*     */ 
/* 142 */     action.setValue("usewith", useWith, 2L);
/* 143 */     action.setValue("langcode", userInfo.getLangCode(), 2L);
/* 144 */     action.setValue("dispvalue", value, 2L);
/* 145 */     action.setValue("parameter", parameter, 2L);
/* 146 */     trans.save();
/*     */   }








/*     */   public MboSetRemote checkAction(String optionName, UserInfo userInfo)
/*     */     throws RemoteException, MXException
/*     */   {
/* 159 */     SqlFormat sqf = new SqlFormat(userInfo, "action = :1");
/* 160 */     sqf.setObject(1, "ACTION", "ACTION", optionName);
/* 161 */     MboSetRemote actionSet = MXServer.getMXServer().getMboSet("ACTION", userInfo);
/* 162 */     actionSet.setWhere(sqf.format());
/* 163 */     return actionSet;
/*     */   }






/*     */   public void deleteAction(String optionName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 174 */     MboSetRemote actionSet = checkAction(optionName, userInfo);
/* 175 */     if (!(actionSet.isEmpty()))
/*     */     {
/* 177 */       actionSet.setMXTransaction(trans);
/* 178 */       actionSet.deleteAll();
/*     */     }
/* 180 */     trans.save();
/*     */   }







/*     */   public void deleteActionGroup(String optionName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 192 */     SqlFormat sqf = new SqlFormat(userInfo, "action = :1");
/* 193 */     sqf.setObject(1, "ACTION", "ACTION", optionName);
/* 194 */     MboSetRemote actionSet = MXServer.getMXServer().getMboSet("ACTION", userInfo);
/* 195 */     actionSet.setWhere(sqf.format());
/* 196 */     actionSet.reset();
/* 197 */     if (!(actionSet.isEmpty()))
/*     */     {
/* 199 */       MboSetRemote actionGroupSet = actionSet.moveFirst().getMboSet("ACTION_MEMBERS");
/* 200 */       MboRemote line = null;
/* 201 */       for (int j = 0; ; ++j)
/*     */       {
/* 203 */         line = actionGroupSet.getMbo(j);
/* 204 */         if (line == null) {
/*     */           break;
/*     */         }
/*     */ 
/* 208 */         deleteAction(line.getString("member"), userInfo, trans);
/*     */       }
/*     */     }
/* 211 */     trans.save();
/*     */   }
/*     */ }
