/*     */ package com.ibm.tivoli.maximo.interaction.generate;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.ebp.EndpointInfo;
/*     */ import java.io.Serializable;
/*     */ 


































/*     */ public final class IntGeneratorInfo
/*     */   implements Serializable
/*     */ {
/*     */   private String interationName;
/*     */   private String reqOSName;
/*     */   private String respOSName;
/*     */   private String invkChannelName;
/*     */   private String endPointName;
/*  36 */   private boolean processresponse = false;
/*     */   private String reqRelName;
/*     */   private String mainObjectName;
/*     */   private String defaultLength;
/*     */   private EndpointInfo endPointInfo;
/*     */ 
/*     */   public void setInteractionName(String intrName)
/*     */   {
/*  56 */     this.interationName = intrName;
/*     */   }





/*     */   public void setProcessResponse(boolean hasResponse)
/*     */   {
/*  65 */     this.processresponse = hasResponse;
/*     */   }





/*     */   public void setReqRelationName(String relName)
/*     */   {
/*  74 */     this.reqRelName = relName;
/*     */   }





/*     */   public void setDefaultAttributeLength(String length)
/*     */   {
/*  83 */     this.defaultLength = length;
/*     */   }





/*     */   public void setInteractionMainObject(String mainObjName)
/*     */   {
/*  92 */     this.mainObjectName = mainObjName;
/*     */   }





/*     */   public void setReqOSName(String osName)
/*     */   {
/* 101 */     this.reqOSName = osName;
/*     */   }





/*     */   public void setRespOSName(String osName)
/*     */   {
/* 110 */     this.respOSName = osName;
/*     */   }





/*     */   public void setInvkChannelName(String channelName)
/*     */   {
/* 119 */     this.invkChannelName = channelName;
/*     */   }





/*     */   public void setEndPointName(String epName)
/*     */   {
/* 128 */     this.endPointName = epName;
/*     */   }





/*     */   public void setEndpointInfo(EndpointInfo epInfo)
/*     */   {
/* 137 */     this.endPointInfo = epInfo;
/*     */   }







/*     */   public String getInteractionName()
/*     */   {
/* 148 */     return this.interationName;
/*     */   }






/*     */   public String getReqOSName()
/*     */   {
/* 158 */     return this.reqOSName;
/*     */   }






/*     */   public String getRespOSName()
/*     */   {
/* 168 */     return this.respOSName;
/*     */   }





/*     */   public String getDefaultAttributeLength()
/*     */   {
/* 177 */     return this.defaultLength;
/*     */   }






/*     */   public String getEndPointName()
/*     */   {
/* 187 */     return this.endPointName;
/*     */   }






/*     */   public String getInvokeChannelName()
/*     */   {
/* 197 */     return this.invkChannelName;
/*     */   }





/*     */   public boolean isProcessResponse()
/*     */   {
/* 206 */     return this.processresponse;
/*     */   }





/*     */   public String getReqRelationName()
/*     */   {
/* 215 */     return this.reqRelName;
/*     */   }






/*     */   public String getInteractionMainObject()
/*     */   {
/* 225 */     return this.mainObjectName;
/*     */   }






/*     */   public EndpointInfo getEndPointInfo()
/*     */   {
/* 235 */     return this.endPointInfo;
/*     */   }
/*     */ }
