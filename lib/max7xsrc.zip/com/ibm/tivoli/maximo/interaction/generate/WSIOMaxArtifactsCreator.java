/*     */ package com.ibm.tivoli.maximo.interaction.generate;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.ebp.EndpointInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIOAttribute;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionUtil;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import psdi.app.configure.MaxObjectCfg;
/*     */ import psdi.mbo.DomainInfo;
/*     */ import psdi.mbo.MaxMessage;
/*     */ import psdi.mbo.MaxMessageCache;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.txn.MXTransaction;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 












/*     */ public class WSIOMaxArtifactsCreator
/*     */ {
/*  40 */   private static final MXLogger interactionLogger = InteractionUtil.INTERACTIONLOGGER;
/*     */ 
/*     */   public static void create(WSIO optimizedRequest, WSIO optimizedResponse, IntGeneratorInfo interActionInfo, UserInfo userInfo, MXTransaction mxTrans)
/*     */     throws MXException, RemoteException
/*     */   {
/*  47 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/*  49 */       interactionLogger.debug("WSIOMaxArtifactsCreator - create()- Request:" + optimizedRequest + ", Response:" + optimizedResponse + ", IntGeneratorInfo:" + interActionInfo + ", userInfo:" + userInfo);

/*     */     }
/*     */ 
/*  53 */     if (optimizedRequest == null)
/*  54 */       throw new MXApplicationException("iface", "optrequest_not_exist");
/*  55 */     createArtifacts(optimizedRequest, optimizedResponse, interActionInfo, userInfo, mxTrans);
/*     */   }



/*     */   private static void createArtifacts(WSIO optimizedRequest, WSIO optimizedResponse, IntGeneratorInfo interActionInfo, UserInfo userInfo, MXTransaction mxTrans)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/*  65 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/*  67 */         interactionLogger.debug("Entering WSIOMaxArtifactsCreator -createArtifacts()");
/*     */       }
/*  69 */       createMaxArtifacts(optimizedRequest, optimizedResponse, userInfo, interActionInfo, mxTrans);
/*  70 */       createIntegrationArtifacts(optimizedRequest, optimizedResponse, interActionInfo, userInfo, mxTrans);
/*  71 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/*  73 */         interactionLogger.debug("mxTrans.save()");
/*     */       }
/*  75 */       mxTrans.save();
/*  76 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/*  78 */         interactionLogger.debug("Leaving WSIOMaxArtifactsCreator -createArtifacts()");
/*     */       }
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/*  83 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/*  85 */         interactionLogger.error("Error in createArtifacts() - Rollback the Transaction");
/*     */       }
/*  87 */       mxTrans.rollback();
/*  88 */       throw e;
/*     */     }
/*     */   }


/*     */   private static void createMaxArtifacts(WSIO reqwsio, WSIO reswsio, UserInfo usrInfo, IntGeneratorInfo interActionInfo, MXTransaction mxTrans)
/*     */     throws MXException, RemoteException
/*     */   {
/*  96 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/*  98 */       interactionLogger.debug("Entering WSIOMaxArtiCreator -createMaxArtifacts()");
/*     */     }
/*     */ 
/* 101 */     MboSetRemote maxDomainMboSet = MXServer.getMXServer().getMboSet("MAXDOMAIN", usrInfo);
/* 102 */     maxDomainMboSet.getMXTransaction().remove(maxDomainMboSet);
/* 103 */     maxDomainMboSet.setMXTransaction(null);
/* 104 */     maxDomainMboSet.setMXTransaction(mxTrans);
/* 105 */     Map reqDomainMap = new HashMap();

/*     */     try
/*     */     {
/* 109 */       createDomains(reqwsio, maxDomainMboSet, interActionInfo, reqDomainMap);



/*     */ 
/* 114 */       mxTrans.save();
/* 115 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 117 */         interactionLogger.info("WSIOMaxArtiCreator -createMaxArtifacts()-Done with MAXDOMAIN Artifacts.");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 123 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 125 */         interactionLogger.error("Error in WSIOMaxArtiCreator -createMaxArtifacts()- Rollback the Transaction - MaxDomain");
/*     */       }
/*     */ 
/* 128 */       mxTrans.rollback();
/* 129 */       throw e;

/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 135 */       MboSetRemote maxObjectCfgSet = MXServer.getMXServer().getMboSet("MAXOBJECTCFG", usrInfo);
/* 136 */       maxObjectCfgSet.getMXTransaction().remove(maxObjectCfgSet);
/* 137 */       maxObjectCfgSet.setMXTransaction(null);
/* 138 */       maxObjectCfgSet.setMXTransaction(mxTrans);
/* 139 */       createObjectArtifacts(reqwsio, maxObjectCfgSet, true, interActionInfo, reqDomainMap);
/* 140 */       if (reswsio != null)
/* 141 */         createObjectArtifacts(reswsio, maxObjectCfgSet, false, interActionInfo, new HashMap());
/* 142 */       mxTrans.save();
/* 143 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 145 */         interactionLogger.info("WSIOMaxArtiCreator -createMaxArtifacts()-Done with MAXOBJECT Artifacts");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 151 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 153 */         interactionLogger.error("Error in WSIOMaxArtiCreator -createMaxArtifacts()- Rollback the Transaction - MaxObject and MaxAttribute");
/*     */       }
/*     */ 
/* 156 */       mxTrans.rollback();
/* 157 */       throw e;
/*     */     }
/*     */ 
/* 160 */     MboSetRemote maxRelMboSet = MXServer.getMXServer().getMboSet("MAXRELATIONSHIP", usrInfo);
/* 161 */     maxRelMboSet.getMXTransaction().remove(maxRelMboSet);
/* 162 */     maxRelMboSet.setMXTransaction(null);
/* 163 */     maxRelMboSet.setMXTransaction(mxTrans);

/*     */     try
/*     */     {
/* 167 */       createRelation(interActionInfo.getReqRelationName(), interActionInfo.getInteractionMainObject(), reqwsio.getName(), maxRelMboSet);
/*     */ 
/* 169 */       if (reswsio != null)

/*     */       {
/* 172 */         createRelation(reswsio.getName(), reqwsio.getName(), reswsio.getName(), maxRelMboSet);
/*     */       }
/*     */ 
/* 175 */       if (!(reqwsio.getWSIOChildren().isEmpty())) {
/* 176 */         createRelations(reqwsio, maxRelMboSet);
/*     */       }
/* 178 */       if ((reswsio != null) && (!(reswsio.getWSIOChildren().isEmpty())))
/* 179 */         createRelations(reswsio, maxRelMboSet);
/* 180 */       mxTrans.save();
/* 181 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 183 */         interactionLogger.info("WSIOMaxArtiCreator -createMaxArtifacts()-Done with MAXRELATION Artifacts");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 189 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 191 */         interactionLogger.error("Error in WSIOMaxArtiCreator -createMaxArtifacts()- Rollback the Transaction - MaxRelation");
/*     */       }
/*     */ 
/* 194 */       mxTrans.rollback();
/* 195 */       throw e;

/*     */     }
/*     */ 
/* 199 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 201 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator -createMaxArtifacts()");
/*     */   }


/*     */   private static void createIntegrationArtifacts(WSIO reqwsio, WSIO reswsio, IntGeneratorInfo interActionInfo, UserInfo usrInfo, MXTransaction mxTrans)
/*     */     throws MXException, RemoteException
/*     */   {
/* 208 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 210 */       interactionLogger.debug("Entering WSIOMaxArtiCreator -createIntegrationArtifacts()");
/*     */     }
/*     */     try
/*     */     {
/* 214 */       MboSetRemote maxOSSet = MXServer.getMXServer().getMboSet("MAXINTOBJECT", usrInfo);
/* 215 */       maxOSSet.getMXTransaction().remove(maxOSSet);
/* 216 */       maxOSSet.setMXTransaction(null);
/* 217 */       maxOSSet.setMXTransaction(mxTrans);
/* 218 */       mxTrans.put("INTLEVEL", "1");
/* 219 */       mxTrans.put("INTEGRATION", true);
/*     */ 
/* 221 */       createObjectStructure(reqwsio, interActionInfo.getReqOSName(), maxOSSet);
/* 222 */       if (reswsio != null)
/* 223 */         createObjectStructure(reswsio, interActionInfo.getRespOSName(), maxOSSet);
/* 224 */       mxTrans.save();
/* 225 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 227 */         interactionLogger.info("WSIOMaxArtiCreator -createIntegrationArtifacts()-Done with Object Structure Artifacts");
/*     */       }
/*     */ 
/* 230 */       MboSetRemote maxEPSet = MXServer.getMXServer().getMboSet("MAXENDPOINT", usrInfo);
/* 231 */       maxEPSet.getMXTransaction().remove(maxEPSet);
/* 232 */       maxEPSet.setMXTransaction(null);
/* 233 */       maxEPSet.setMXTransaction(mxTrans);
/*     */ 
/* 235 */       createEndPoint(interActionInfo, maxEPSet);
/* 236 */       mxTrans.save();
/* 237 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 239 */         interactionLogger.info("WSIOMaxArtiCreator -createIntegrationArtifacts()-Done with End Point Artifacts");

/*     */       }
/*     */ 
/* 243 */       MboSetRemote maxInvokeSet = MXServer.getMXServer().getMboSet("MAXIFACEINVOKE", usrInfo);
/* 244 */       maxInvokeSet.getMXTransaction().remove(maxInvokeSet);
/* 245 */       maxInvokeSet.setMXTransaction(null);
/* 246 */       maxInvokeSet.setMXTransaction(mxTrans);
/* 247 */       createInvokeChannel(interActionInfo, maxInvokeSet);
/*     */ 
/* 249 */       mxTrans.save();
/* 250 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 252 */         interactionLogger.info("WSIOMaxArtiCreator -createIntegrationArtifacts()-Done with Invoke Channel Artifacts");
/*     */       }
/*     */ 
/* 255 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 257 */         interactionLogger.debug("Leaving WSIOMaxArtiCreator -createIntegrationArtifacts()");
/*     */       }
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 262 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 264 */         interactionLogger.error("Error in WSIOMaxArtiCreator -createIntegrationArtifacts- Rollback the Transaction - IntegrationArtifacts");
/*     */       }
/*     */ 
/* 267 */       mxTrans.rollback();
/* 268 */       throw e;
/*     */     }
/*     */   }



/*     */   private static void createObjectArtifacts(WSIO wsio, MboSetRemote maxObjectCfgSet, boolean isReq, IntGeneratorInfo interActionInfo, Map<String, Map<String, String>> reqDomainMap)
/*     */     throws MXException, RemoteException
/*     */   {
/* 277 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 279 */       interactionLogger.debug("Entering WSIOMaxArtiCreator -createObjectArtifacts()- wsio name:" + wsio.getName());
/*     */     }
/*     */ 
/* 282 */     Map attrDomIdMap = new HashMap();
/* 283 */     if ((reqDomainMap != null) && (!(reqDomainMap.isEmpty())) && (reqDomainMap.get(wsio.getName()) != null))
/*     */     {
/* 285 */       attrDomIdMap = (Map)reqDomainMap.get(wsio.getName());
/*     */     }
/* 287 */     registerNPObject(wsio, maxObjectCfgSet, isReq, interActionInfo, attrDomIdMap);
/* 288 */     List wsioList = wsio.getWSIOChildren();
/* 289 */     if (wsioList != null)
/*     */     {
/* 291 */       for (WSIO childWSIO : wsioList)
/* 292 */         createObjectArtifacts(childWSIO, maxObjectCfgSet, isReq, interActionInfo, reqDomainMap);
/*     */     }
/* 294 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 296 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator -createObjectArtifacts()");
/*     */   }


/*     */   private static void registerNPObject(WSIO wsio, MboSetRemote maxObjectCfgSet, boolean isReq, IntGeneratorInfo interActionInfo, Map<String, String> attrDomIdMap)
/*     */     throws MXException, RemoteException
/*     */   {
/* 303 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 305 */       interactionLogger.debug("Entering WSIOMaxArtiCreator -registerNPObject()-wsio" + wsio.getName());
/*     */     }
/* 307 */     MboRemote maxObjectCfgMbo = maxObjectCfgSet.add();
/* 308 */     ((MaxObjectCfg)maxObjectCfgMbo).setMeaFlag(true);
/* 309 */     maxObjectCfgMbo.setValue("addrowstamp", false, 2L);
/* 310 */     ((MaxObjectCfg)maxObjectCfgMbo).setLoadDefaultAttributes(false);
/* 311 */     maxObjectCfgMbo.setValue("persistent", false, 2L);
/* 312 */     maxObjectCfgMbo.setValue("objectname", wsio.getName(), 2L);
/* 313 */     maxObjectCfgMbo.setValue("description", wsio.getTitle(), 2L);
/*     */ 
/* 315 */     maxObjectCfgMbo.setValue("isview", false, 2L);
/* 316 */     maxObjectCfgMbo.setValue("imported", false, 2L);
/* 317 */     maxObjectCfgMbo.setValue("servicename", "MIC", 2L);
/* 318 */     if (isReq)
/*     */     {
/* 320 */       maxObjectCfgMbo.setValue("classname", "com.ibm.tivoli.maximo.interaction.process.RequestMboSet", 2L);
/*     */     }
/*     */     else
/*     */     {
/* 324 */       maxObjectCfgMbo.setValue("classname", "com.ibm.tivoli.maximo.interaction.process.ResponseMboSet", 2L);
/*     */     }
/* 326 */     maxObjectCfgMbo.setValue("changed", "N", 38L);
/* 327 */     MboSetRemote maxAttributeCfgSet = maxObjectCfgMbo.getMboSet("MAXATTRIBUTECFG");
/* 328 */     registerWSIOAttributes(wsio.getWSIOAttributes(), maxAttributeCfgSet, isReq, interActionInfo, attrDomIdMap);
/* 329 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 331 */       interactionLogger.debug("WSIOMaxArtiCreator -registerNPObject()-getTitle:" + wsio.getTitle() + ". copying MaxObject from MaxObjectCfg");

/*     */     }
/*     */ 
/* 335 */     MboSetRemote maxObjectMboSet = maxObjectCfgMbo.getMboSet("MAXOBJECT");
/* 336 */     MboRemote maxObjectMbo = maxObjectCfgMbo.copy(maxObjectMboSet);
/*     */ 
/* 338 */     maxObjectMbo.setValue("objectname", maxObjectCfgMbo.getString("objectname"), 2L);
/* 339 */     maxObjectMbo.setValue("classname", maxObjectCfgMbo.getString("classname"), 2L);
/*     */ 
/* 341 */     MboSetRemote maxAttributeMboSet = maxObjectMbo.getMboSet("MAXATTRIBUTE");
/*     */ 
/* 343 */     int j = 0;
/* 344 */     MboRemote attrCfgMbo = maxAttributeCfgSet.getMbo(j);
/* 345 */     while (attrCfgMbo != null)
/*     */     {
/* 347 */       MboRemote maxAttrMbo = attrCfgMbo.copy(maxAttributeMboSet);
/* 348 */       maxAttrMbo.setValue("objectname", maxObjectCfgMbo.getString("objectname"), 2L);
/* 349 */       maxAttrMbo.setValue("attributeno", attrCfgMbo.getInt("attributeno"), 2L);
/* 350 */       attrCfgMbo = maxAttributeCfgSet.getMbo(++j);
/*     */     }
/* 352 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 354 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator -registerNPObject()");
/*     */   }



/*     */   private static void registerWSIOAttributes(List<WSIOAttribute> lstWSIOAttr, MboSetRemote maxAttributeCfgSet, boolean isReq, IntGeneratorInfo interActionInfo, Map<String, String> attrDomIdMap)
/*     */     throws MXException, RemoteException
/*     */   {
/* 362 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 364 */       interactionLogger.debug("Entering WSIOMaxArtiCreator -registerWSIOAttribute()");
/*     */     }
/* 366 */     if (lstWSIOAttr != null)
/*     */     {
/* 368 */       for (WSIOAttribute wsioAttr : lstWSIOAttr)
/*     */       {
/* 370 */         String domainId = null;
/* 371 */         if ((attrDomIdMap != null) && (!(attrDomIdMap.isEmpty())) && (attrDomIdMap.get(wsioAttr.getName()) != null))
/*     */         {
/* 373 */           domainId = (String)attrDomIdMap.get(wsioAttr.getName());
/*     */         }
/* 375 */         registerAttribute(wsioAttr, maxAttributeCfgSet, isReq, interActionInfo, domainId);
/*     */       }
/*     */     }
/* 378 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 380 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator -registerWSIOAttribute()");
/*     */   }

/*     */   private static void registerAttribute(WSIOAttribute wsioAttr, MboSetRemote maxAttributeCfgSet, boolean isReq, IntGeneratorInfo interActionInfo, String domainId)
/*     */     throws MXException, RemoteException
/*     */   {
/* 386 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 388 */       interactionLogger.debug("Entering WSIOMaxArtiCreator -registerAttribute()-wsioAttr name:" + wsioAttr.getName() + ", title:" + wsioAttr.getTitle());
/*     */     }
/*     */ 
/* 391 */     MboRemote maxAttributeCfg = maxAttributeCfgSet.add();
/* 392 */     maxAttributeCfg.setValue("attributename", wsioAttr.getName(), 2L);
/* 393 */     maxAttributeCfg.setValue("title", wsioAttr.getTitle(), 2L);
/* 394 */     maxAttributeCfg.setValue("changed", "N", 38L);
/* 395 */     String type = InteractionUtil.getMaxType(wsioAttr);
/* 396 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 398 */       interactionLogger.debug("WSIOMaxArtiCreator -registerAttribute()-wsioAttr type:" + wsioAttr.getType() + ",Max Yype:" + type);
/*     */     }
/*     */ 
/* 401 */     maxAttributeCfg.setValue("maxtype", type, 2L);
/* 402 */     int length = getLength(wsioAttr, type, interActionInfo);
/* 403 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 405 */       interactionLogger.debug("WSIOMaxArtiCreator -registerAttribute()- Length:" + length);
/*     */     }
/*     */ 
/* 408 */     if (length > 0)
/*     */     {
/* 410 */       maxAttributeCfg.setValue("length", length, 2L);
/*     */     }
/* 412 */     if ((type.equals("DECIMAL")) && (wsioAttr.getFractionDigits() > -1))
/*     */     {
/* 414 */       maxAttributeCfg.setValue("scale", wsioAttr.getFractionDigits(), 2L);
/*     */     }
/* 416 */     String defaultValue = wsioAttr.getDefaultValue();
/* 417 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 419 */       interactionLogger.debug("WSIOMaxArtiCreator -registerAttribute()- defaultValue:" + defaultValue);
/*     */     }
/*     */ 
/* 422 */     boolean required = false;
/* 423 */     if (type.equals("YORN"))
/*     */     {
/* 425 */       required = true;
/* 426 */       if ((defaultValue == null) || (defaultValue.trim().length() == 0))
/* 427 */         defaultValue = "0";
/*     */     }
/* 429 */     maxAttributeCfg.setValue("required", required, 11L);
/* 430 */     maxAttributeCfg.setValue("defaultvalue", defaultValue, 2L);
/* 431 */     if (wsioAttr.getXmlLocation() == null)
/*     */     {
/* 433 */       maxAttributeCfg.setValue("remarks", wsioAttr.getTitle(), 2L);
/*     */     }
/*     */     else
/*     */     {
/* 437 */       maxAttributeCfg.setValue("remarks", wsioAttr.getXmlLocation(), 2L);
/*     */     }
/*     */ 
/* 440 */     if (isReq)
/*     */     {
/* 442 */       if (domainId == null)
/* 443 */         maxAttributeCfg.setValue("classname", "com.ibm.tivoli.maximo.interaction.process.FldWSIOAttribute", 2L);
/*     */       else {
/* 445 */         maxAttributeCfg.setValue("domainid", domainId, 2L);
/*     */       }
/*     */     }
/*     */ 
/* 449 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 451 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator -registerAttribute()");
/*     */   }




/*     */   private static int getLength(WSIOAttribute wsioAttr, String maxType, IntGeneratorInfo interActionInfo)
/*     */   {
/* 459 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 461 */       interactionLogger.debug("Entering WSIOMaxArtiCreator - getLength()");
/*     */     }
/* 463 */     if ((maxType.equals("INTEGER")) || (maxType.equals("DECIMAL")))
/* 464 */       return wsioAttr.getTotalDigits();
/* 465 */     if (maxType.equals("ALN"))
/*     */     {
/* 467 */       int i = wsioAttr.getMaxLength();
/* 468 */       if (i > 0) {
/* 469 */         return i;
/*     */       }
/* 471 */       return Integer.valueOf(interActionInfo.getDefaultAttributeLength()).intValue();
/*     */     }
/* 473 */     if (maxType.equals("DATE"))
/* 474 */       return 4;
/* 475 */     if (maxType.equals("DATETIME"))
/* 476 */       return 10;
/* 477 */     if (maxType.equals("TIME"))
/* 478 */       return 3;
/* 479 */     if (maxType.equals("YORN")) {
/* 480 */       return 1;
/*     */     }
/* 482 */     return wsioAttr.getMaxLength();
/*     */   }

/*     */   private static void createRelations(WSIO wsio, MboSetRemote maxRelMboSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 488 */     if (wsio.getParent() != null)
/* 489 */       createRelation(wsio.getName(), wsio.getParent().getName(), wsio.getName(), maxRelMboSet);
/* 490 */     List wsioList = wsio.getWSIOChildren();
/* 491 */     if (wsioList == null)
/*     */       return;
/* 493 */     for (WSIO childWSIO : wsioList)
/* 494 */       createRelations(childWSIO, maxRelMboSet);
/*     */   }


/*     */   private static void createRelation(String relName, String parentObj, String childObj, MboSetRemote maxRelMboSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 501 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 503 */       interactionLogger.debug("Entering WSIOMaxArtiCreator - createRelation()-relName" + relName + ",parentObj:" + parentObj + ", childObj:" + childObj);
/*     */     }
/*     */ 
/* 506 */     MboRemote maxRelMbo = maxRelMboSet.add();
/* 507 */     maxRelMbo.setValue("NAME", relName, 2L);
/* 508 */     maxRelMbo.setValue("PARENT", parentObj, 2L);
/* 509 */     maxRelMbo.setValue("CHILD", childObj, 2L);
/* 510 */     maxRelMbo.setValueNull("WHERECLAUSE", 2L);
/* 511 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 513 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator - createRelation()");
/*     */   }



/*     */   private static void createObjectStructure(WSIO wsio, String objStrName, MboSetRemote maxIntObjectSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 521 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 523 */       interactionLogger.debug("Entering WSIOMaxArtiCreator - createObjectStructure()-objStrName:" + objStrName);
/*     */     }
/*     */ 
/* 526 */     MaxMessage mxMsg = MXServer.getMXServer().getMaxMessageCache().getMaxMessage("iface", "objstrname");
/* 527 */     String msg = "";
/* 528 */     if (mxMsg != null)
/* 529 */       msg = mxMsg.getMessage();
/* 530 */     MboRemote mboIntObj = maxIntObjectSet.add();
/* 531 */     mboIntObj.setValue("intobjectname", objStrName);
/* 532 */     mboIntObj.setValue("description", objStrName + " " + msg);
/* 533 */     String usewith = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("INTUSEWITH", "INTEGRATION", null, null);
/*     */ 
/* 535 */     mboIntObj.setValue("usewith", usewith);
/* 536 */     MboSetRemote detailsSet = mboIntObj.getMboSet("MAXINTOBJDETAIL");
/* 537 */     createOSDetails(wsio, detailsSet);
/* 538 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 540 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator - createObjectStructure()");
/*     */   }

/*     */   private static void createOSDetails(WSIO wsio, MboSetRemote detailsSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 546 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 548 */       interactionLogger.debug("Entering WSIOMaxArtiCreator - createOSDetails()-OBJECTNAME:" + wsio.getName());
/*     */     }
/*     */ 
/* 551 */     MboRemote detailMbo = detailsSet.add();
/* 552 */     detailMbo.setValue("OBJECTNAME", wsio.getName(), 2L);
/*     */ 
/* 554 */     if (wsio.getParent() != null)
/*     */     {
/* 556 */       detailMbo.setValue("PARENTOBJNAME", wsio.getParent().getName(), 2L);
/* 557 */       detailMbo.setValue("RELATION", wsio.getName(), 11L);

/*     */     }
/*     */ 
/* 561 */     List lstWSIOAttr = wsio.getWSIOAttributes();
/* 562 */     MboSetRemote colsSet = detailMbo.getMboSet("MAXINTOBJCOLS");
/* 563 */     for (WSIOAttribute wsioAttr : lstWSIOAttr)
/*     */     {
/* 565 */       MboRemote colMbo = colsSet.add();
/* 566 */       colMbo.setValue("NAME", wsioAttr.getName());
/* 567 */       colMbo.setValue("INTOBJFLDTYPE", "NONPERSISTENT");
/*     */     }
/*     */ 
/* 570 */     List wsioList = wsio.getWSIOChildren();
/* 571 */     if (wsioList != null)
/*     */     {
/* 573 */       for (WSIO childWSIO : wsioList)
/* 574 */         createOSDetails(childWSIO, detailsSet);
/*     */     }
/* 576 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 578 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator - createOSDetails()");
/*     */   }



/*     */   private static void createInvokeChannel(IntGeneratorInfo interActionInfo, MboSetRemote maxInvokeSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 586 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 588 */       interactionLogger.debug("Entering WSIOMaxArtiCreator - createInvokeChannel()-InvokeChannel:" + interActionInfo.getInvokeChannelName() + ",intobjectname:" + interActionInfo.getReqOSName() + ",processresponse:" + interActionInfo.isProcessResponse() + ",replyintobjname:" + interActionInfo.getRespOSName() + ", endpointname:" + interActionInfo.getEndPointName());


/*     */     }
/*     */ 
/* 593 */     MaxMessage mxMsg = MXServer.getMXServer().getMaxMessageCache().getMaxMessage("iface", "invkcnlname");
/* 594 */     String msg = "";
/* 595 */     if (mxMsg != null)
/* 596 */       msg = mxMsg.getMessage();
/* 597 */     MboRemote mboInvoke = maxInvokeSet.add();
/* 598 */     mboInvoke.setValue("ifacename", interActionInfo.getInvokeChannelName());
/* 599 */     mboInvoke.setValue("description", interActionInfo.getInteractionName() + " " + msg);
/* 600 */     mboInvoke.setValue("intobjectname", interActionInfo.getReqOSName());
/* 601 */     mboInvoke.setValue("processresponse", interActionInfo.isProcessResponse());
/* 602 */     if (interActionInfo.isProcessResponse())
/* 603 */       mboInvoke.setValue("replyintobjname", interActionInfo.getRespOSName());
/* 604 */     mboInvoke.setValue("endpointname", interActionInfo.getEndPointName());
/* 605 */     mboInvoke.setValue("ifaceexitclass", "com.ibm.tivoli.maximo.interaction.process.WSIORequestExit");
/* 606 */     if (interActionInfo.isProcessResponse())
/* 607 */       mboInvoke.setValue("replyexitclass", "com.ibm.tivoli.maximo.interaction.process.WSIOResponseExit");
/* 608 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 610 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator - createInvokeChannel()");
/*     */   }


/*     */   private static void createEndPoint(IntGeneratorInfo interActionInfo, MboSetRemote maxEPSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 617 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 619 */       interactionLogger.debug("Entering WSIOMaxArtiCreator - createEndPoint()- endpointname:" + interActionInfo.getEndPointName());
/*     */     }
/*     */ 
/* 622 */     EndpointInfo endpointInfo = interActionInfo.getEndPointInfo();
/* 623 */     MaxMessage mxMsg = MXServer.getMXServer().getMaxMessageCache().getMaxMessage("iface", "endpntname");
/* 624 */     String msg = "";
/* 625 */     if (mxMsg != null)
/* 626 */       msg = mxMsg.getMessage();
/* 627 */     MboRemote mboEP = maxEPSet.add();
/* 628 */     mboEP.setValue("endpointname", interActionInfo.getEndPointName());
/* 629 */     String useJaxws = MXServer.getMXServer().getProperty("mxe.int.containerdeploy");
/* 630 */     if ((useJaxws != null) && (useJaxws.equals("1")))
/*     */     {
/* 632 */       mboEP.setValue("handlername", "WEBSERVICE-JAXWS", 2L);
/*     */     }
/*     */     else
/*     */     {
/* 636 */       mboEP.setValue("handlername", "WEBSERVICE", 2L);
/*     */     }
/* 638 */     mboEP.setValue("description", interActionInfo.getInteractionName() + " " + msg, 2L);
/* 639 */     MboSetRemote dtlSet = mboEP.getMboSet("MAXENDPOINTDTL");
/* 640 */     int i = 0;
/* 641 */     MboRemote epDetailMbo = dtlSet.getMbo(i);
/* 642 */     while (epDetailMbo != null)
/*     */     {
/* 644 */       if (epDetailMbo.getString("property").equals("ENDPOINTURL"))
/*     */       {
/* 646 */         epDetailMbo.setValue("value", endpointInfo.getEpUrl(), 2L);
/*     */       }
/* 648 */       else if (epDetailMbo.getString("property").equals("SERVICENAME"))
/*     */       {
/* 650 */         epDetailMbo.setValue("value", endpointInfo.getServiceName());
/*     */       }
/* 652 */       else if (epDetailMbo.getString("property").equals("SOAPACTION"))
/*     */       {
/* 654 */         epDetailMbo.setValue("value", endpointInfo.getSoapAction());
/*     */       }
/* 656 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 658 */         interactionLogger.debug("WSIOMaxArtiCreator - createEndPoint()- ENDPOINTURL:" + endpointInfo.getEpUrl() + ",SERVICENAME:" + endpointInfo.getServiceName() + ", SOAPACTION:" + endpointInfo.getSoapAction());

/*     */       }
/*     */ 
/* 662 */       epDetailMbo = dtlSet.getMbo(++i);
/*     */     }
/*     */   }

/*     */   private static void createDomains(WSIO wsio, MboSetRemote maxDomainMboSet, IntGeneratorInfo interActionInfo, Map<String, Map<String, String>> domainMap)
/*     */     throws MXException, RemoteException
/*     */   {
/* 669 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 671 */       interactionLogger.debug("Entering WSIOMaxArtiCreator - createDomains");
/*     */     }
/* 673 */     List lstWSIOAttr = wsio.getWSIOAttributes();
/* 674 */     for (WSIOAttribute wsioAttr : lstWSIOAttr)
/*     */     {
/* 676 */       List lst = wsioAttr.getEnumList();
/* 677 */       if ((lst != null) && (lst.size() > 0))
/*     */       {
/* 679 */         if (interactionLogger.isDebugEnabled())
/*     */         {
/* 681 */           interactionLogger.debug("WSIOMaxArtiCreator - createDomains-wsioAttr:" + wsioAttr.getName() + ", EnumList size:" + lst.size());
/*     */         }
/*     */ 
/* 684 */         String maxType = InteractionUtil.getMaxType(wsioAttr);
/* 685 */         if ((maxType.equals("FLOAT")) || (maxType.equals("DECIMAL")) || (maxType.equals("INTEGER")))
/*     */         {
/* 687 */           createDomain(wsioAttr, maxDomainMboSet, "NUMERIC", lst, interActionInfo, domainMap);
/*     */         }
/* 689 */         else if (maxType.equals("ALN"))
/*     */         {
/* 691 */           createDomain(wsioAttr, maxDomainMboSet, "ALN", lst, interActionInfo, domainMap);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 696 */     List wsioList = wsio.getWSIOChildren();
/* 697 */     if (wsioList != null)
/*     */     {
/* 699 */       for (WSIO childWSIO : wsioList)
/* 700 */         createDomains(childWSIO, maxDomainMboSet, interActionInfo, domainMap);
/*     */     }
/* 702 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 704 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator - createDomains");
/*     */   }


/*     */   private static void createDomain(WSIOAttribute wsioAttr, MboSetRemote maxDomainMboSet, String type, List<String> lst, IntGeneratorInfo interActionInfo, Map<String, Map<String, String>> domainMap)
/*     */     throws MXException, RemoteException
/*     */   {
/* 711 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 713 */       interactionLogger.debug("Entering WSIOMaxArtiCreator - createDomain() type:" + type);
/*     */     }
/* 715 */     String relName = "";
/* 716 */     if (type.equals("ALN"))
/* 717 */       relName = "ALNDOMAINVALUE";
/*     */     else {
/* 719 */       relName = "NUMDOMAINVALUE";
/*     */     }
/* 721 */     Object[] params = { wsioAttr.getName(), interActionInfo.getInteractionName() };
/* 722 */     MaxMessage mxMsg = MXServer.getMXServer().getMaxMessageCache().getMaxMessage("iface", "intrdomdesc");
/* 723 */     String msg = "";
/* 724 */     if (mxMsg != null) {
/* 725 */       msg = mxMsg.getMessage(params);
/*     */     }
/*     */ 
/* 728 */     MboRemote maxDomain = maxDomainMboSet.add();
/*     */ 
/* 730 */     String domainId = wsioAttr.getName();
/* 731 */     if (wsioAttr.getName().length() > 15)
/*     */     {
/* 733 */       domainId = domainId.substring(0, 14);
/*     */     }
/* 735 */     else if (interActionInfo.getInteractionName().length() + wsioAttr.getName().length() < 15)
/*     */     {
/* 737 */       domainId = interActionInfo.getInteractionName() + domainId;
/*     */     }
/*     */     else
/*     */     {
/* 741 */       domainId = interActionInfo.getInteractionName().substring(0, 15 - wsioAttr.getName().length()) + domainId;
/*     */     }
/* 743 */     domainId = getDomainName(domainId.trim(), domainId.length());
/* 744 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 746 */       interactionLogger.debug("WSIOMaxArtiCreator - createDomain() domainId:" + domainId);
/*     */     }
/* 748 */     maxDomain.setValue("domainid", domainId);
/* 749 */     maxDomain.setValue("description", msg);
/* 750 */     maxDomain.setValue("domaintype", type.toUpperCase());
/* 751 */     maxDomain.setValue("maxtype", type.toUpperCase());
/* 752 */     maxDomain.setValue("length", String.valueOf(getLength(wsioAttr, type, interActionInfo)));
/* 753 */     if (!(type.equals("ALN"))) {
/* 754 */       maxDomain.setValue("scale", wsioAttr.getFractionDigits());
/*     */     }
/* 756 */     MboSetRemote childSet = maxDomain.getMboSet(relName);
/* 757 */     for (String value : lst)
/*     */     {
/* 759 */       MboRemote childMbo = childSet.add();
/* 760 */       childMbo.setValue("description", msg);
/* 761 */       if (relName.equals("ALNDOMAINVALUE"))
/*     */       {
/* 763 */         ((Mbo)childMbo).getMboValue("value").setBypassOperatorCheck(true);
/*     */       }
/* 765 */       childMbo.setValue("value", value);
/* 766 */       Map map = new HashMap();
/* 767 */       map.put(wsioAttr.getName(), domainId);
/* 768 */       domainMap.put(wsioAttr.getParentWSIOName(), map);
/*     */     }
/* 770 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 772 */     interactionLogger.debug("Leaving WSIOMaxArtiCreator - createDomain");
/*     */   }


/*     */   private static String getDomainName(String DomainId, int length)
/*     */     throws MXException, RemoteException
/*     */   {
/* 779 */     String objName = DomainId;
/* 780 */     DomainInfo domainInfo = MXServer.getMXServer().getMaximoDD().getDomainInfo(objName);
/* 781 */     if (domainInfo != null)
/*     */     {
/* 783 */       String origName = objName.substring(0, length);
/* 784 */       int count = 0;
/* 785 */       if (objName.length() > length)
/* 786 */         count = new Integer(objName.substring(length)).intValue();
/* 787 */       objName = getDomainName(origName.concat(String.valueOf(++count)), length);
/*     */     }
/* 789 */     return objName;
/*     */   }
/*     */ }
