/*    */ package com.ibm.tivoli.maximo.interaction.generate;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.app.configure.ConfigureServiceRemote;
/*    */ import psdi.app.configure.virtual.ProcessMonitor;
/*    */ import psdi.iface.mic.MicService;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.security.UserInfo;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 














/*    */ public class ConfigIntArtifacts
/*    */ {
/*    */   private UserInfo getUserInfo()
/*    */     throws MXException, RemoteException
/*    */   {
/* 34 */     return ((MicService)MXServer.getMXServer().lookup("MIC")).getNewUserInfo();
/*    */   }

/*    */   public void runConfigDB() throws MXException, RemoteException
/*    */   {
/* 39 */     MboSetRemote processMonitorSet = MXServer.getMXServer().getMboSet("PROCESSMONITOR", getUserInfo());
/*    */     try
/*    */     {
/* 42 */       if (processMonitorSet != null)
/*    */       {
/* 44 */         ConfigureServiceRemote configService = (ConfigureServiceRemote)MXServer.getMXServer().lookup("CONFIGURE");
/* 45 */         MboRemote processMonitorMbo = processMonitorSet.add();
/* 46 */         if (processMonitorMbo != null)
/*    */         {
/* 48 */           System.out.println("ConfigDB Started ********");
/*    */           try
/*    */           {
/* 51 */             configService.runConfigDB(processMonitorMbo);

/*    */           }
/*    */           catch (Exception ce)
/*    */           {
/* 56 */             if (ce instanceof MXApplicationException)
/*    */             {
/* 58 */               String errKey = ((MXApplicationException)ce).getErrorKey();
/* 59 */               if (errKey != null)
/*    */               {
/* 61 */                 if ((errKey.equalsIgnoreCase("NothingToConfigure")) || (errKey.equalsIgnoreCase("AdminModeRequired")))

/*    */                 {
/* 64 */                   if (errKey.equalsIgnoreCase("AdminModeRequired")) {
/* 65 */                     throw new MXApplicationException("system", "AdminModeRequired", ce);
/*    */                   }
/*    */                 }
/*    */                 else {
/* 69 */                   throw new MXApplicationException("system", "major", ce);
/*    */                 }
/*    */               }
/*    */             }
/*    */ 
/*    */           }
/*    */ 
/* 76 */           int configStatus = processMonitorMbo.getInt("completionstatus");
/* 77 */           while (configStatus == ProcessMonitor.PROCESS_RUNNING)
/*    */           {
/* 79 */             System.out.println("ConfigDB PROCESS_RUNNING********");
/* 80 */             synchronized (this)
/*    */             {
/* 82 */               super.wait(10000L);
/*    */             }
/* 84 */             configStatus = processMonitorMbo.getInt("completionstatus");
/*    */           }
/*    */ 
/* 87 */           if (configStatus == ProcessMonitor.PROCESS_SUCCESS)
/*    */           {
/* 89 */             System.out.println("ConfigDB PROCESS_SUCCESS********");
/* 90 */             return;
/*    */           }
/* 92 */           if (configStatus == ProcessMonitor.PROCESS_ERROR)
/*    */           {
/* 94 */             System.out.println("ConfigDB PROCESS_ERROR********");
/* 95 */             throw new MXApplicationException("system", "major");
/*    */           }
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception ce)
/*    */     {
/* 104 */       if (ce instanceof MXApplicationException)
/*    */       {
/* 106 */         String errKey = ((MXApplicationException)ce).getErrorKey();
/* 107 */         if ((errKey != null) && (errKey.equalsIgnoreCase("AdminModeRequired")))
/*    */         {
/* 109 */           throw new MXApplicationException("system", "AdminModeRequired");
/*    */         }
/*    */       }
/* 112 */       throw new MXApplicationException("system", "major", ce);
/*    */     }
/*    */   }
/*    */ }
