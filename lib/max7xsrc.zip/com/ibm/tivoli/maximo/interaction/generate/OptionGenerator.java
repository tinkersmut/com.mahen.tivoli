/*     */ package com.ibm.tivoli.maximo.interaction.generate;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Vector;
/*     */ import org.jdom.Document;
/*     */ import psdi.mbo.MaxMessageCache;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.txn.MXTransaction;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.Message;
/*     */ import psdi.util.Resolver;
/*     */ 































/*     */ public class OptionGenerator
/*     */ {
/*  44 */   private MboRemote header = null;
/*  45 */   private DialogGenerator dialogGen = null;
/*     */ 
/*     */   public String addOption(String appName, String interaction, String description, UserInfo userInfo, boolean createMenu, MXTransaction trans, Vector selected, boolean isSilent)
/*     */     throws RemoteException, MXException
/*     */   {
/*  58 */     String sigOption = null;
/*  59 */     this.dialogGen = new DialogGenerator();
/*  60 */     if (interaction.length() > 8)
/*     */     {
/*  62 */       sigOption = interaction.substring(0, 8);
/*     */     }
/*     */     else
/*     */     {
/*  66 */       sigOption = interaction;
/*     */     }
/*  68 */     String optionName = includeSigOption(interaction, appName, sigOption, description, isSilent, this.dialogGen.getAppXML(appName, userInfo), userInfo, trans, 0);
/*     */ 
/*  70 */     if (createMenu)

/*     */     {
/*  73 */       includeMenuOption(appName, optionName, 10, null, userInfo, trans);


/*     */     }
/*     */ 
/*  78 */     includeAppAuth(appName, optionName, userInfo, trans, selected);
/*     */ 
/*  80 */     return optionName;
/*     */   }










/*     */   public void deleteOption(String appName, String optionName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/*  95 */     deleteAppAuth(appName, optionName, userInfo, trans);

/*     */ 
/*  98 */     deleteMenuOption(appName, optionName, userInfo, trans);
/*     */ 
/* 100 */     deleteSigOption(appName, optionName, userInfo, trans);
/*     */   }









/*     */   private String includeSigOption(String interaction, String appName, String sigName, String sigDesc, boolean isSilent, Document appDocument, UserInfo userInfo, MXTransaction trans, int start)
/*     */     throws RemoteException, MXException
/*     */   {
/* 114 */     if (this.dialogGen.findElementByID(appDocument.getRootElement(), sigName))
/*     */     {
/* 116 */       String newSigName = sigName + start;
/* 117 */       if (newSigName.length() > 10)
/*     */       {
/* 119 */         newSigName = newSigName.substring(0, 7) + start;
/*     */       }
/* 121 */       return includeSigOption(interaction, appName, newSigName, sigDesc, isSilent, appDocument, userInfo, trans, start++);
/*     */     }
/* 123 */     String sgName = addSigOption(appName, sigName, sigDesc, userInfo, trans);
/* 124 */     if (sgName == null)
/*     */     {
/* 126 */       String newSigName = sigName + start;
/* 127 */       if (newSigName.length() > 10)
/*     */       {
/* 129 */         newSigName = newSigName.substring(0, 7) + start;
/*     */       }
/* 131 */       return includeSigOption(interaction, appName, newSigName, sigDesc, isSilent, appDocument, userInfo, trans, start++);
/*     */     }
/* 133 */     return sgName;
/*     */   }








/*     */   public String addSigOption(String appName, String sigName, String sigDesc, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 146 */     SqlFormat sqf = new SqlFormat(userInfo, "app = :1 and optionname = :2");
/* 147 */     sqf.setObject(1, "SIGOPTION", "APP", appName);
/* 148 */     sqf.setObject(2, "SIGOPTION", "OPTIONNAME", sigName);
/* 149 */     MboSetRemote addSigOptionSet = MXServer.getMXServer().getMboSet("SIGOPTION", userInfo);
/* 150 */     addSigOptionSet.setWhere(sqf.format());
/* 151 */     addSigOptionSet.reset();
/* 152 */     if (addSigOptionSet.isEmpty())
/*     */     {
/* 154 */       addSigOptionSet.setMXTransaction(trans);
/* 155 */       MboRemote addSigOption = addSigOptionSet.add();
/* 156 */       addSigOption.setValue("app", appName, 2L);
/* 157 */       addSigOption.setValue("optionname", sigName, 2L);
/* 158 */       addSigOption.setValue("description", sigDesc, 2L);
/* 159 */       addSigOption.setValue("esigenabled", false, 2L);
/* 160 */       addSigOption.setValue("visible", true, 2L);
/* 161 */       addSigOption.setValue("langcode", userInfo.getLangCode(), 2L);
/* 162 */       return sigName;
/*     */     }
/* 164 */     return null;
/*     */   }










/*     */   private void includeAppAuth(String appName, String sigName, UserInfo userInfo, MXTransaction trans, Vector selected)
/*     */     throws RemoteException, MXException
/*     */   {
/* 179 */     MboSetRemote addAuth = MXServer.getMXServer().getMboSet("APPLICATIONAUTH", userInfo);
/* 180 */     addAuth.setWhere("1=2");
/* 181 */     addAuth.reset();


/*     */ 
/* 185 */     MboSetRemote existAuth = MXServer.getMXServer().getMboSet("APPLICATIONAUTH", userInfo);
/* 186 */     for (int x = 0; x < selected.size(); ++x)
/*     */     {
/* 188 */       MboRemote group = (MboRemote)selected.get(x);

/*     */ 
/* 191 */       SqlFormat sqf = new SqlFormat(userInfo, "app = :1 and optionname = :2 and groupname = :3");
/*     */ 
/* 193 */       sqf.setObject(1, "APPLICATIONAUTH", "APP", appName);
/* 194 */       sqf.setObject(2, "APPLICATIONAUTH", "OPTIONNAME", sigName);
/* 195 */       sqf.setObject(3, "APPLICATIONAUTH", "GROUPNAME", group.getString("groupname"));
/* 196 */       existAuth.setWhere(sqf.format());
/* 197 */       if (!(existAuth.isEmpty()))
/*     */         continue;
/* 199 */       addAuth.setMXTransaction(trans);
/* 200 */       MboRemote newAuth = addAuth.add();
/* 201 */       newAuth.setValue("groupname", group.getString("GROUPNAME"), 2L);
/* 202 */       newAuth.setValue("app", appName, 2L);
/* 203 */       newAuth.setValue("optionname", sigName, 2L);
/*     */     }
/*     */   }










/*     */   public void addAllAppAuth(String appName, String sigName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 219 */     MboSetRemote auth = MXServer.getMXServer().getMboSet("APPLICATIONAUTH", userInfo);
/* 220 */     SqlFormat sqf = new SqlFormat(userInfo, "app = :1 and optionname = :2");
/*     */ 
/* 222 */     sqf.setObject(1, "APPLICATIONAUTH", "APP", appName);
/* 223 */     sqf.setObject(2, "APPLICATIONAUTH", "OPTIONNAME", "READ");
/* 224 */     auth.setWhere(sqf.format());
/* 225 */     auth.reset();
/* 226 */     MboRemote mbo = null;
/* 227 */     for (int j = 0; ; ++j)
/*     */     {
/* 229 */       mbo = auth.getMbo(j);
/* 230 */       if (mbo == null) {
/*     */         break;
/*     */       }
/*     */ 
/* 234 */       mbo.select();
/*     */     }
/* 236 */     includeAppAuth(appName, sigName, userInfo, trans, auth.getSelection());
/*     */   }














/*     */   private void includeMenuOption(String appName, String sigName, int preferredSpot, String imageSource, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 255 */     SqlFormat sqf = new SqlFormat(userInfo, "moduleapp = :1 and menutype = 'APPMENU' and elementtype = 'OPTION' and keyvalue = :2");
/*     */ 
/* 257 */     sqf.setObject(1, "MAXMENU", "MODULEAPP", appName);
/* 258 */     sqf.setObject(2, "MAXMENU", "KEYVALUE", sigName);
/* 259 */     MboSetRemote checkMenuSet = MXServer.getMXServer().getMboSet("MAXMENU", userInfo);
/* 260 */     checkMenuSet.setWhere(sqf.format());
/* 261 */     if (!(checkMenuSet.isEmpty())) {
/*     */       return;
/*     */     }
/* 264 */     MboRemote header = includeHeader(appName, sigName, userInfo, trans);
/*     */ 
/* 266 */     if (!(header.toBeAdded()))


/*     */     {
/* 270 */       SqlFormat subSearch = new SqlFormat(userInfo, "moduleapp = :1 and position = :2 and menutype = 'APPMENU' ");
/*     */ 
/* 272 */       subSearch.setObject(1, "MAXMENU", "MODULEAPP", appName);
/* 273 */       subSearch.setInt(2, header.getInt("POSITION"));
/*     */ 
/* 275 */       MboSetRemote checkSubSet = MXServer.getMXServer().getMboSet("MAXMENU", userInfo);
/* 276 */       checkSubSet.setWhere(subSearch.format());
/*     */ 
/* 278 */       if (!(checkSubSet.isEmpty()))
/*     */       {
/* 280 */         checkSubSet.setOrderBy("subposition desc");
/* 281 */         double subPosition = checkSubSet.max("subposition");
/* 282 */         if (subPosition >= preferredSpot)
/*     */         {
/* 284 */           preferredSpot = new Double(subPosition).intValue() + 1;
/*     */         }
/*     */       }
/*     */     }
/* 288 */     addMenuOption(appName, sigName, "APPMENU", header.getInt("POSITION"), preferredSpot, "MAIN", imageSource, userInfo, trans);
/*     */   }














/*     */   public int addAppToolOption(String appName, String sigName, String imageSource, int preferredSpot, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 307 */     SqlFormat sqf = new SqlFormat(userInfo, "moduleapp = :1 and menutype = 'APPTOOL' and elementtype = 'OPTION' and keyvalue = :2");
/*     */ 
/* 309 */     sqf.setObject(1, "MAXMENU", "MODULEAPP", appName);
/* 310 */     sqf.setObject(2, "MAXMENU", "KEYVALUE", sigName);
/* 311 */     MboSetRemote checkMenuSet = MXServer.getMXServer().getMboSet("MAXMENU", userInfo);
/* 312 */     checkMenuSet.setWhere(sqf.format());
/* 313 */     if (checkMenuSet.isEmpty())


/*     */     {
/* 317 */       SqlFormat subSearch = new SqlFormat(userInfo, "moduleapp = :1 and menutype = 'APPTOOL' ");
/*     */ 
/* 319 */       subSearch.setObject(1, "MAXMENU", "MODULEAPP", appName);
/*     */ 
/* 321 */       MboSetRemote checkSubSet = MXServer.getMXServer().getMboSet("MAXMENU", userInfo);
/* 322 */       checkSubSet.setWhere(subSearch.format());
/*     */ 
/* 324 */       if (!(checkSubSet.isEmpty()))
/*     */       {
/* 326 */         checkSubSet.setOrderBy("position desc");
/* 327 */         double subPosition = checkSubSet.max("position");
/* 328 */         if (subPosition >= preferredSpot)
/*     */         {
/* 330 */           preferredSpot = new Double(subPosition).intValue() + 10;
/*     */         }
/*     */       }
/*     */ 
/* 334 */       addMenuOption(appName, sigName, "APPTOOL", preferredSpot, 0, "ALL", imageSource, userInfo, trans);
/*     */     }
/*     */ 
/* 337 */     return preferredSpot;
/*     */   }













/*     */   public void addMenuOption(String appName, String sigName, String menuType, int preferredSpot, int preferredSubSpot, String tabDisplay, String imageSource, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 355 */     MboSetRemote subMenuSet = MXServer.getMXServer().getMboSet("MAXMENU", userInfo);
/* 356 */     subMenuSet.setWhere("1=2");
/* 357 */     subMenuSet.reset();
/* 358 */     subMenuSet.setMXTransaction(trans);
/* 359 */     MboRemote subMenu = subMenuSet.add();
/* 360 */     subMenu.setValue("menutype", menuType, 2L);
/* 361 */     subMenu.setValue("moduleapp", appName, 2L);
/* 362 */     subMenu.setValue("position", preferredSpot, 2L);
/* 363 */     subMenu.setValue("subposition", preferredSubSpot, 2L);
/* 364 */     subMenu.setValue("elementtype", "OPTION", 2L);
/* 365 */     subMenu.setValue("keyvalue", sigName, 2L);
/* 366 */     subMenu.setValue("visible", true, 2L);
/* 367 */     String tabDysplaySynonyms = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("TABDISPLAY", tabDisplay, null, null);
/*     */ 
/* 369 */     subMenu.setValue("tabdisplay", tabDysplaySynonyms, 2L);
/* 370 */     if (imageSource == null)
/*     */       return;
/* 372 */     subMenu.setValue("image", imageSource, 2L);
/*     */   }







/*     */   private MboRemote includeHeader(String appName, String sigName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 384 */     if (this.header == null)
/*     */     {
/* 386 */       MboSetRemote headerSubMenuSet = MXServer.getMXServer().getMboSet("MAXMENU", userInfo);
/* 387 */       Resolver resolver = Resolver.getResolver();
/* 388 */       String headerTitle = resolver.getMessage("iface", "externalapp").getMessage();
/* 389 */       if (MXServer.getMXServer().getMaxMessageCache().getMaxMessage("iface", "externalapp") == null)
/*     */       {
/* 391 */         headerTitle = "External Services";
/*     */       }
/* 393 */       SqlFormat sqf = new SqlFormat(userInfo, "moduleapp = :1 and menutype = :2");
/*     */ 
/* 395 */       sqf.setObject(1, "MAXMENU", "MODULEAPP", appName);
/* 396 */       sqf.setObject(2, "MAXMENU", "MENUTYPE", "APPMENU");
/* 397 */       headerSubMenuSet.setWhere(sqf.format());
/* 398 */       headerSubMenuSet.reset();
/* 399 */       MboRemote mbo = null;
/* 400 */       for (int j = 0; ; ++j)
/*     */       {
/* 402 */         mbo = headerSubMenuSet.getMbo(j);
/* 403 */         if (mbo == null) {
/*     */           break;
/*     */         }
/*     */ 
/* 407 */         if ((mbo.getString("elementtype").equals("HEADER")) && (mbo.getString("keyvalue").equals("SM5981")))
/*     */         {
/* 409 */           return mbo;
/*     */         }
/*     */       }
/* 412 */       headerSubMenuSet.setMXTransaction(trans);
/* 413 */       String tabDysplaySynonyms = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("TABDISPLAY", "MAIN", null, null);

/*     */ 
/* 416 */       double position = headerSubMenuSet.max("position") + 1.0D;
/*     */ 
/* 418 */       MboRemote headerSep = headerSubMenuSet.add();
/* 419 */       headerSep.setValue("menutype", "APPMENU", 2L);
/* 420 */       headerSep.setValue("moduleapp", appName, 2L);
/* 421 */       headerSep.setValue("position", position, 2L);
/* 422 */       headerSep.setValue("subposition", 0, 2L);
/* 423 */       headerSep.setValue("keyvalue", "AM5980", 2L);
/* 424 */       headerSep.setValue("elementtype", "SEP", 2L);
/* 425 */       headerSep.setValue("visible", true, 2L);
/* 426 */       headerSep.setValue("tabdisplay", tabDysplaySynonyms, 2L);
/*     */ 
/* 428 */       this.header = headerSubMenuSet.add();
/* 429 */       this.header.setValue("menutype", "APPMENU", 2L);
/* 430 */       this.header.setValue("moduleapp", appName, 2L);
/* 431 */       this.header.setValue("position", position + 1.0D, 2L);
/* 432 */       this.header.setValue("subposition", 0, 2L);
/* 433 */       this.header.setValue("keyvalue", "SM5981", 2L);
/* 434 */       this.header.setValue("elementtype", "HEADER", 2L);
/* 435 */       this.header.setValue("headerdescription", headerTitle, 2L);
/* 436 */       this.header.setValue("visible", true, 2L);
/* 437 */       this.header.setValue("tabdisplay", tabDysplaySynonyms, 2L);
/*     */     }
/*     */ 
/* 440 */     return this.header;
/*     */   }







/*     */   public MboSetRemote checkSigOption(String appName, String sigName, UserInfo userInfo)
/*     */     throws RemoteException, MXException
/*     */   {
/* 452 */     SqlFormat sqf = new SqlFormat(userInfo, "app = :1 and optionname = :2");
/* 453 */     sqf.setObject(1, "SIGOPTION", "APP", appName);
/* 454 */     sqf.setObject(2, "SIGOPTION", "OPTIONNAME", sigName);
/* 455 */     MboSetRemote addSigOptionSet = MXServer.getMXServer().getMboSet("SIGOPTION", userInfo);
/* 456 */     addSigOptionSet.setWhere(sqf.format());
/* 457 */     return addSigOptionSet;
/*     */   }








/*     */   private void deleteSigOption(String appName, String sigName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 470 */     MboSetRemote addSigOptionSet = checkSigOption(appName, sigName, userInfo);
/* 471 */     if (addSigOptionSet.isEmpty())
/*     */       return;
/* 473 */     addSigOptionSet.setMXTransaction(trans);
/* 474 */     addSigOptionSet.deleteAll();
/* 475 */     trans.save();
/*     */   }













/*     */   public MboSetRemote checkMenuOption(String appName, String sigName, UserInfo userInfo)
/*     */     throws RemoteException, MXException
/*     */   {
/* 493 */     SqlFormat sqf = new SqlFormat(userInfo, "moduleapp = :1 and menutype = 'APPMENU' and elementtype = 'OPTION' and keyvalue = :2");
/*     */ 
/* 495 */     sqf.setObject(1, "MAXMENU", "MODULEAPP", appName);
/* 496 */     sqf.setObject(2, "MAXMENU", "KEYVALUE", sigName);
/* 497 */     MboSetRemote checkMenuSet = MXServer.getMXServer().getMboSet("MAXMENU", userInfo);
/* 498 */     checkMenuSet.setWhere(sqf.format());
/* 499 */     return checkMenuSet;
/*     */   }











/*     */   private void deleteMenuOption(String appName, String sigName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 515 */     MboSetRemote checkMenuSet = checkMenuOption(appName, sigName, userInfo);
/* 516 */     if (checkMenuSet.isEmpty())
/*     */       return;
/* 518 */     checkMenuSet.setMXTransaction(trans);
/* 519 */     checkMenuSet.deleteAll();
/* 520 */     trans.save();
/*     */   }










/*     */   private void deleteAppAuth(String appName, String sigName, UserInfo userInfo, MXTransaction trans)
/*     */     throws RemoteException, MXException
/*     */   {
/* 535 */     MboSetRemote existAuth = MXServer.getMXServer().getMboSet("APPLICATIONAUTH", userInfo);
/*     */ 
/* 537 */     SqlFormat sqf = new SqlFormat(userInfo, "app = :1 and optionname = :2");
/*     */ 
/* 539 */     sqf.setObject(1, "APPLICATIONAUTH", "APP", appName);
/* 540 */     sqf.setObject(2, "APPLICATIONAUTH", "OPTIONNAME", sigName);
/* 541 */     existAuth.setWhere(sqf.format());
/* 542 */     if (existAuth.isEmpty())
/*     */       return;
/* 544 */     existAuth.setMXTransaction(trans);
/* 545 */     existAuth.deleteAll();
/* 546 */     trans.save();
/*     */   }
/*     */ }
