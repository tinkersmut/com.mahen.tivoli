/*     */ package com.ibm.tivoli.maximo.interaction.generate;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionCache;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionUtil;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import psdi.iface.mic.InvokeChannelCache;
/*     */ import psdi.iface.mic.InvokeInfo;
/*     */ import psdi.iface.mos.MosDetailInfo;
/*     */ import psdi.iface.mos.MosInfo;
/*     */ import psdi.iface.mos.ObjectStructureCache;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.txn.MXTransaction;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 





























/*     */ public class WSIOMaxArtifactsRemove
/*     */ {
/*  43 */   private static final MXLogger interactionLogger = InteractionUtil.INTERACTIONLOGGER;
/*     */ 
/*     */   public static void remove(String interactionName, UserInfo userInfo, MXTransaction mxTrans)
/*     */     throws MXException, RemoteException
/*     */   {
/*  65 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/*  67 */       interactionLogger.debug("Entering WSIOMaxArtifactsRemove - remove()- interactionName:" + interactionName);
/*     */     }
/*  69 */     InteractionInfo interactionInfo = InteractionCache.getInstance().getInteractionInfo(interactionName);
/*     */ 
/*  71 */     if (interactionInfo == null)
/*     */     {
/*  73 */       Object[] params = { interactionName };
/*  74 */       throw new MXApplicationException("iface", "interaction_not_exist", params);
/*     */     }
/*  76 */     InvokeInfo invokeInfo = InvokeChannelCache.getInstance().getInvokeInfo(interactionInfo.getChannelName());
/*  77 */     if (invokeInfo == null)
/*     */     {
/*  79 */       Object[] params = { interactionInfo.getChannelName() };
/*  80 */       throw new MXApplicationException("iface", "invokechannel_not_exist", params);
/*     */     }
/*     */ 
/*  83 */     String endPtName = invokeInfo.getEndPointName();
/*  84 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/*  86 */       interactionLogger.debug("WSIOMaxArtifactsRemove - remove()- ChannelName:" + interactionInfo.getChannelName() + ", EndPointName:" + endPtName);

/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  92 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/*  94 */         interactionLogger.info("WSIOMaxArtifactsRemove -remove()-Starting to delete MAXIFACEINVOKE records.");
/*     */       }
/*     */ 
/*  97 */       MboSetRemote maxInvokeSet = MXServer.getMXServer().getMboSet("MAXIFACEINVOKE", userInfo);
/*  98 */       maxInvokeSet.getMXTransaction().remove(maxInvokeSet);
/*  99 */       maxInvokeSet.setMXTransaction(null);
/* 100 */       maxInvokeSet.setMXTransaction(mxTrans);
/*     */ 
/* 102 */       SqlFormat sqf = new SqlFormat(userInfo, " ifacename =:1");
/* 103 */       sqf.setObject(1, "MAXIFACEINVOKE", "ifacename", interactionInfo.getChannelName());
/* 104 */       maxInvokeSet.setWhere(sqf.format());
/* 105 */       maxInvokeSet.reset();
/* 106 */       if (!(maxInvokeSet.isEmpty()))
/*     */       {
/* 108 */         maxInvokeSet.deleteAll();
/* 109 */         mxTrans.save();
/*     */       }
/* 111 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 113 */         interactionLogger.info("WSIOMaxArtifactsRemove -remove()-MAXIFACEINVOKE records have been deleted.");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 119 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 121 */         interactionLogger.error("Error in WSIOMaxArtifactsRemove -remove()- Rollback the Transaction - MAXIFACEINVOKE");
/*     */       }
/*     */ 
/* 124 */       mxTrans.rollback();
/* 125 */       throw e;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 130 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 132 */         interactionLogger.info("WSIOMaxArtifactsRemove -remove()-Starting to delete MAXENDPOINT records.");

/*     */       }
/*     */ 
/* 136 */       MboSetRemote maxEPSet = MXServer.getMXServer().getMboSet("MAXENDPOINT", userInfo);
/* 137 */       maxEPSet.getMXTransaction().remove(maxEPSet);
/* 138 */       maxEPSet.setMXTransaction(null);
/* 139 */       maxEPSet.setMXTransaction(mxTrans);
/*     */ 
/* 141 */       SqlFormat sqf1 = new SqlFormat(userInfo, " endpointname =:1");
/* 142 */       sqf1.setObject(1, "MAXENDPOINT", "endpointname", endPtName);
/* 143 */       maxEPSet.setWhere(sqf1.format());
/* 144 */       maxEPSet.reset();
/* 145 */       if (!(maxEPSet.isEmpty()))
/*     */       {
/* 147 */         maxEPSet.deleteAll();
/* 148 */         mxTrans.save();
/*     */       }
/* 150 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 152 */         interactionLogger.info("WSIOMaxArtifactsRemove -remove()-MAXENDPOINT records have been deleted.");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 158 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 160 */         interactionLogger.error("Error in WSIOMaxArtifactsRemove -remove()- Rollback the Transaction - MAXENDPOINT");
/*     */       }
/*     */ 
/* 163 */       mxTrans.rollback();
/* 164 */       throw e;


/*     */     }
/*     */ 
/* 169 */     OBPInfo obpInfo = OBPGenerator.parse(interactionInfo.getObp());
/* 170 */     WSIO reqWsio = obpInfo.getRequest();
/* 171 */     deleteMos(reqWsio, interactionInfo, userInfo, mxTrans, true);
/*     */ 
/* 173 */     if (interactionInfo.getResponseOSName() == null)
/*     */       return;
/* 175 */     WSIO respWsio = obpInfo.getResponse();
/* 176 */     deleteMos(respWsio, interactionInfo, userInfo, mxTrans, false);
/*     */   }


















/*     */   private static void deleteMos(WSIO wsio, InteractionInfo interactionInfo, UserInfo userInfo, MXTransaction mxTrans, boolean isReq)
/*     */     throws MXException, RemoteException
/*     */   {
/* 199 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 201 */       interactionLogger.debug("Entering WSIOMaxArtifactsRemove - deleteMos().");
/*     */     }/*     */     String mosName;
/*     */     String mosName;
/* 204 */     if (isReq)
/* 205 */       mosName = interactionInfo.getRequestOSName();
/*     */     else {
/* 207 */       mosName = interactionInfo.getResponseOSName();
/*     */     }
/* 209 */     MosInfo mosInfo = ObjectStructureCache.getInstance().getMosInfo(mosName);
/* 210 */     if (mosInfo == null)
/*     */     {
/* 212 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 214 */         interactionLogger.debug("WSIOMaxArtifactsRemove - deleteMos(). ObjectStructure is not available. Can not delete MaxObject, MaxRelationship and MaxDomain related records.");
/*     */       }
/*     */ 
/* 217 */       return;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 222 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 224 */         interactionLogger.info("WSIOMaxArtifactsRemove -deleteMos()-Starting to delete MAXINTOBJECT records.");
/*     */       }
/*     */ 
/* 227 */       MboSetRemote maxOSSet = MXServer.getMXServer().getMboSet("MAXINTOBJECT", userInfo);
/* 228 */       maxOSSet.getMXTransaction().remove(maxOSSet);
/* 229 */       maxOSSet.setMXTransaction(null);
/* 230 */       maxOSSet.setMXTransaction(mxTrans);
/* 231 */       SqlFormat sqf = new SqlFormat(userInfo, " intobjectname =:1");
/* 232 */       sqf.setObject(1, "MAXINTOBJECT", "intobjectname", mosName);
/* 233 */       maxOSSet.setWhere(sqf.format());
/* 234 */       if (!(maxOSSet.isEmpty()))
/*     */       {
/* 236 */         maxOSSet.deleteAll();
/* 237 */         mxTrans.save();
/*     */       }
/* 239 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 241 */         interactionLogger.info("WSIOMaxArtifactsRemove -remove()-MAXINTOBJECT records have been deleted.");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 247 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 249 */         interactionLogger.error("Error in WSIOMaxArtifactsRemove -deleteMos()- Rollback the Transaction - MAXINTOBJECT");
/*     */       }
/*     */ 
/* 252 */       mxTrans.rollback();
/* 253 */       throw e;

/*     */     }
/*     */ 
/* 257 */     deleteRelations(wsio, userInfo, mxTrans, interactionInfo, isReq);
/*     */ 
/* 259 */     deleteMbos(wsio, userInfo, mxTrans);
/*     */ 
/* 261 */     if (!(interactionLogger.isDebugEnabled()))
/*     */       return;
/* 263 */     interactionLogger.debug("Leaving WSIOMaxArtifactsRemove - deleteMos().");
/*     */   }















/*     */   private static void deleteRelations(WSIO wsio, UserInfo userInfo, MXTransaction mxTrans, InteractionInfo interactionInfo, boolean isReq)
/*     */     throws MXException, RemoteException
/*     */   {
/* 283 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 285 */       interactionLogger.debug("Entering WSIOMaxArtifactsRemove - deleteRelations().wsio:" + wsio.getName());
/*     */     }
/*     */     try
/*     */     {
/* 289 */       MboSetRemote maxRelSet = MXServer.getMXServer().getMboSet("MAXRELATIONSHIP", userInfo);
/* 290 */       StringBuffer buf = new StringBuffer();
/* 291 */       if (isReq)

/*     */       {
/* 294 */         buf.append("(name='");
/* 295 */         buf.append(interactionInfo.getReqRelation());
/* 296 */         buf.append("' and parent='");
/* 297 */         buf.append(interactionInfo.getIntMainObject());
/* 298 */         buf.append("')");

/*     */       }
/*     */       else
/*     */       {
/* 303 */         String responseObject = wsio.getName();
/* 304 */         String requestObject = ObjectStructureCache.getInstance().getMosInfo(interactionInfo.getRequestOSName()).getPrimaryMosDetailInfo().getObjectName();

/*     */ 
/* 307 */         buf.append("(name='");
/* 308 */         buf.append(responseObject);
/* 309 */         buf.append("' and parent='");
/* 310 */         buf.append(requestObject);
/* 311 */         buf.append("')");
/*     */       }
/* 313 */       buf = getRelationsWhere(wsio, buf);
/* 314 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 316 */         interactionLogger.debug("WSIOMaxArtifactsRemove - deleteRelations().where clause:" + buf.toString());
/*     */       }
/* 318 */       maxRelSet.setWhere(buf.toString());
/* 319 */       if (!(maxRelSet.isEmpty()))
/*     */       {
/* 321 */         maxRelSet.getMXTransaction().remove(maxRelSet);
/* 322 */         maxRelSet.setMXTransaction(null);
/* 323 */         maxRelSet.setMXTransaction(mxTrans);
/* 324 */         maxRelSet.deleteAll();
/* 325 */         mxTrans.save();

















































/*     */       }
/*     */ 
/* 377 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 379 */         interactionLogger.info("WSIOMaxArtifactsRemove -deleteRelations()-MAXRELATIONSHIP records have been deleted.");
/*     */       }
/*     */ 
/* 382 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 384 */         interactionLogger.debug("Leaving WSIOMaxArtifactsRemove - deleteRelations().");
/*     */       }
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 389 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 391 */         interactionLogger.error("Error in WSIOMaxArtifactsRemove -deleteRelations()- Rollback the Transaction - MAXRELATIONSHIP");
/*     */       }
/*     */ 
/* 394 */       mxTrans.rollback();
/* 395 */       throw e;
/*     */     }
/*     */   }











/*     */   private static void deleteMbos(WSIO wsio, UserInfo userInfo, MXTransaction mxTrans)
/*     */     throws MXException, RemoteException
/*     */   {
/* 412 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 414 */       interactionLogger.debug("Entering WSIOMaxArtifactsRemove - deleteMbos().wsio:" + wsio.getName());
/*     */     }
/*     */     try
/*     */     {
/* 418 */       MboSetRemote maxObjectCfgSet = MXServer.getMXServer().getMboSet("MAXOBJECTCFG", userInfo);
/* 419 */       StringBuffer whereClsBuf = new StringBuffer();
/* 420 */       whereClsBuf.append("objectname in (");
/* 421 */       whereClsBuf = getObjectsWhere(wsio, whereClsBuf);
/* 422 */       whereClsBuf.append(")");
/* 423 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 425 */         interactionLogger.debug("WSIOMaxArtifactsRemove - deleteMbos().where clause:" + whereClsBuf.toString());
/*     */       }
/* 427 */       String setwhere = whereClsBuf.toString();
/* 428 */       maxObjectCfgSet.setWhere(setwhere);
/*     */ 
/* 430 */       Set domIdSet = getMaxAttrDomainIds(whereClsBuf, userInfo);
/* 431 */       if (!(maxObjectCfgSet.isEmpty()))
/*     */       {
/* 433 */         maxObjectCfgSet.getMXTransaction().remove(maxObjectCfgSet);
/* 434 */         maxObjectCfgSet.setMXTransaction(null);
/* 435 */         maxObjectCfgSet.setMXTransaction(mxTrans);
/* 436 */         maxObjectCfgSet.deleteAll(1024L);
/* 437 */         mxTrans.save();
/*     */       }
/*     */ 
/* 440 */       MboSetRemote maxObjectSet = MXServer.getMXServer().getMboSet("MAXOBJECT", userInfo);
/* 441 */       maxObjectSet.setWhere(setwhere);
/* 442 */       if (!(maxObjectSet.isEmpty()))
/*     */       {
/* 444 */         maxObjectSet.getMXTransaction().remove(maxObjectSet);
/* 445 */         maxObjectSet.setMXTransaction(null);
/* 446 */         maxObjectSet.setMXTransaction(mxTrans);
/* 447 */         maxObjectSet.deleteAll(1024L);
/* 448 */         mxTrans.save();
/*     */       }
/*     */ 
/* 451 */       deleteDomains(domIdSet, userInfo, mxTrans);





















































/*     */ 
/* 506 */       if (interactionLogger.isInfoEnabled())
/*     */       {
/* 508 */         interactionLogger.info("WSIOMaxArtifactsRemove -deleteMbos()-MAXOBJECTCFG records have been deleted.");
/*     */       }
/*     */ 
/* 511 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 513 */         interactionLogger.debug("Leaving WSIOMaxArtifactsRemove - deleteMbos().");
/*     */       }
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 518 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 520 */         interactionLogger.error("Error in WSIOMaxArtifactsRemove -deleteMbos()- Rollback the Transaction - MAXOBJECTCFG");
/*     */       }
/*     */ 
/* 523 */       mxTrans.rollback();
/* 524 */       throw e;
/*     */     }
/*     */   }










/*     */   private static void deleteDomains(Set<String> domHashSet, UserInfo userInfo, MXTransaction mxTrans)
/*     */     throws MXException, RemoteException
/*     */   {
/* 540 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 542 */       interactionLogger.debug("Entering WSIOMaxArtifactsRemove - deleteDomains().");
/*     */     }
/*     */     try
/*     */     {
/* 546 */       if (!(domHashSet.isEmpty()))
/*     */       {
/* 548 */         MboSetRemote domainSet = MXServer.getMXServer().getMboSet("MAXDOMAIN", userInfo);
/* 549 */         domainSet.getMXTransaction().remove(domainSet);
/* 550 */         domainSet.setMXTransaction(null);
/* 551 */         domainSet.setMXTransaction(mxTrans);
/* 552 */         StringBuffer buf = new StringBuffer();
/* 553 */         buf.append("domainid in (");
/*     */ 
/* 555 */         Iterator itr = domHashSet.iterator();
/* 556 */         while (itr.hasNext())
/*     */         {
/* 558 */           String domName = (String)itr.next();
/* 559 */           buf.append("'");
/* 560 */           buf.append(domName);
/* 561 */           buf.append("'");
/* 562 */           if (itr.hasNext())
/* 563 */             buf.append(" , ");
/*     */         }
/* 565 */         buf.append(")");
/* 566 */         if (interactionLogger.isDebugEnabled())
/*     */         {
/* 568 */           interactionLogger.debug("WSIOMaxArtifactsRemove - deleteDomains().where clause:" + buf.toString());
/*     */         }
/* 570 */         domainSet.setWhere(buf.toString());
/* 571 */         if (!(domainSet.isEmpty()))



/*     */         {
/* 576 */           userInfo.setInteractive(false);
/* 577 */           domainSet.deleteAll();
/* 578 */           userInfo.setInteractive(true);
/* 579 */           mxTrans.save();
/* 580 */           if (interactionLogger.isInfoEnabled())
/*     */           {
/* 582 */             interactionLogger.info("WSIOMaxArtifactsRemove -deleteDomains()-MAXDOMAIN records have been deleted.");
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 587 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 589 */         interactionLogger.debug("Leaving WSIOMaxArtifactsRemove - deleteDomains().");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 595 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 597 */         interactionLogger.error("Error in WSIOMaxArtifactsRemove -deleteDomains()- Rollback the Transaction - MAXDOMAIN");
/*     */       }
/*     */ 
/* 600 */       mxTrans.rollback();
/* 601 */       throw e;
/*     */     }
/*     */   }










/*     */   private static Set<String> getMaxAttrDomainIds(StringBuffer whereclause, UserInfo userInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 617 */     if (interactionLogger.isDebugEnabled())
/*     */     {
/* 619 */       interactionLogger.debug("Entering WSIOMaxArtifactsRemove - getMaxAttrDomainIds().");
/*     */     }
/*     */     try
/*     */     {
/* 623 */       MboSetRemote maxAttributeCfgSet = MXServer.getMXServer().getMboSet("MAXATTRIBUTECFG", userInfo);
/* 624 */       whereclause.append(" and domainid is not null");
/* 625 */       maxAttributeCfgSet.setWhere(whereclause.toString());
/* 626 */       Set domHashSet = new HashSet();
/* 627 */       if (!(maxAttributeCfgSet.isEmpty()))
/*     */       {
/* 629 */         int i = 0;
/* 630 */         MboRemote objectCfg = maxAttributeCfgSet.getMbo(i);
/* 631 */         while (objectCfg != null)
/*     */         {
/* 633 */           domHashSet.add(objectCfg.getString("domainid"));
/* 634 */           objectCfg = maxAttributeCfgSet.getMbo(++i);
/*     */         }
/*     */       }
/* 637 */       if (interactionLogger.isDebugEnabled())
/*     */       {
/* 639 */         interactionLogger.debug("Leaving WSIOMaxArtifactsRemove - getMaxAttrDomainIds().");
/*     */       }
/* 641 */       return domHashSet;
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 645 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 647 */         interactionLogger.error("Error in WSIOMaxArtifactsRemove -getMaxAttrDomainIds()." + e.getMessage());
/*     */       }
/* 649 */       throw e;
/*     */     }
/*     */   }

/*     */   private static StringBuffer getRelationsWhere(WSIO wsio, StringBuffer where) throws MXException, RemoteException
/*     */   {
/* 655 */     StringBuffer bufWhere = where;
/* 656 */     if (wsio.getParent() != null)
/*     */     {
/* 658 */       bufWhere.append(" or ");
/* 659 */       bufWhere.append("(name='");
/* 660 */       bufWhere.append(wsio.getName());
/* 661 */       bufWhere.append("' and parent='");
/* 662 */       bufWhere.append(wsio.getParent().getName());
/* 663 */       bufWhere.append("')");
/*     */     }
/* 665 */     List wsioList = wsio.getWSIOChildren();
/* 666 */     if (wsioList != null)
/*     */     {
/* 668 */       for (WSIO childWSIO : wsioList)
/*     */       {
/* 670 */         bufWhere = getRelationsWhere(childWSIO, bufWhere);
/*     */       }
/*     */     }
/* 673 */     return bufWhere;
/*     */   }

/*     */   private static StringBuffer getObjectsWhere(WSIO wsio, StringBuffer where)
/*     */     throws MXException, RemoteException
/*     */   {
/* 679 */     StringBuffer bufWhere = where;
/* 680 */     bufWhere.append("'");
/* 681 */     bufWhere.append(wsio.getName());
/* 682 */     bufWhere.append("'");
/* 683 */     List wsioList = wsio.getWSIOChildren();
/* 684 */     if (wsioList != null)
/*     */     {
/* 686 */       for (WSIO childWSIO : wsioList)
/*     */       {
/* 688 */         bufWhere.append(" , ");
/* 689 */         bufWhere = getObjectsWhere(childWSIO, bufWhere);
/*     */       }
/*     */     }
/* 692 */     return bufWhere;
/*     */   }
/*     */ }
