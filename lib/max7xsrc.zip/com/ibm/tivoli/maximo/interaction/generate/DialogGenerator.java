/*      */ package com.ibm.tivoli.maximo.interaction.generate;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.interaction.process.InteractionUtil;
/*      */ import java.rmi.RemoteException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Vector;
/*      */ import org.jdom.Document;
/*      */ import org.jdom.Element;
/*      */ import psdi.iface.util.XMLUtils;
/*      */ import psdi.mbo.MaximoDD;
/*      */ import psdi.mbo.MboRemote;
/*      */ import psdi.mbo.MboSetRemote;
/*      */ import psdi.mbo.SqlFormat;
/*      */ import psdi.mbo.Translate;
/*      */ import psdi.security.UserInfo;
/*      */ import psdi.server.MXServer;
/*      */ import psdi.util.MXApplicationException;
/*      */ import psdi.util.MXException;
/*      */ import psdi.util.logging.MXLogger;
/*      */ 
















































/*      */ public class DialogGenerator
/*      */ {
/*   51 */   public static final MXLogger INTERACTIONLOGGER = InteractionUtil.INTERACTIONLOGGER;
/*      */ 
/*   53 */   String requestTabLabel = "Request Data";
/*   54 */   String responseTabLabel = "Response Data";
/*   55 */   String applyButtonLabel = "Apply";
/*   56 */   String okButtonLabel = "Ok";
/*   57 */   String cancelButtonLabel = "Cancel";
/*   58 */   String invokeServiceButtonLabel = "Invoke Service";
/*   59 */   String newRowButtonLabel = "New Row";
/*   60 */   String requestLabel = "Request";
/*   61 */   String responseLabel = "Response";
/*   62 */   String detailsLabel = "Details";
/*   63 */   String openLinkLabel = "Open link for";
/*   64 */   String imageTextLabel = "Click to see image in its actual size";
/*   65 */   String markRowForDeleteLabel = "Mark Row for Delete";
/*      */ 
/*      */   public String generateDialog(MboRemote intGenerator, byte[] presentataion)
/*      */     throws RemoteException, MXException
/*      */   {
/*   91 */     INTERACTIONLOGGER.debug("Entering generateDialog ");
/*      */ 
/*   93 */     MboSetRemote set = intGenerator.getThisMboSet();
/*      */ 
/*   95 */     this.requestTabLabel = set.getMessage("iface", "requestdata");
/*   96 */     this.responseTabLabel = set.getMessage("iface", "responsedata");
/*   97 */     this.applyButtonLabel = set.getMessage("iface", "applydata");
/*   98 */     this.okButtonLabel = set.getMessage("iface", "okbutton");
/*   99 */     this.cancelButtonLabel = set.getMessage("iface", "cancelbutton");
/*  100 */     this.invokeServiceButtonLabel = set.getMessage("iface", "invokeservicebutton");
/*  101 */     this.newRowButtonLabel = set.getMessage("iface", "newrowbutton");
/*  102 */     this.requestLabel = set.getMessage("iface", "requesttab");
/*  103 */     this.responseLabel = set.getMessage("iface", "responsetab");
/*  104 */     this.detailsLabel = set.getMessage("iface", "detailstab");
/*  105 */     this.openLinkLabel = set.getMessage("iface", "openlink");
/*  106 */     this.imageTextLabel = set.getMessage("iface", "imagetext");
/*  107 */     this.markRowForDeleteLabel = set.getMessage("iface", "markrowfordelete");
/*      */ 
/*  109 */     Document doc = XMLUtils.convertBytesToDocument(presentataion);
/*  110 */     String interaction = intGenerator.getString("interaction").toLowerCase();
/*      */ 
/*  112 */     String intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", intGenerator.getString("intmode"));
/*      */ 
/*  114 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  116 */       INTERACTIONLOGGER.debug("Interaction Mode " + intMode);
/*      */     }
/*  118 */     Element root = doc.getRootElement();
/*  119 */     if (intMode.equals("SILENT"))
/*      */     {
/*  121 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  123 */         INTERACTIONLOGGER.debug("Action id " + intGenerator.getString("mapoption").toLowerCase());
/*      */       }
/*  125 */       Element action = new Element("action");
/*  126 */       action.setAttribute("id", intGenerator.getString("mapoption").toLowerCase());
/*  127 */       action.setAttribute("beanclass", "com.ibm.tivoli.maximo.interaction.beans.process.ExternalServiceBean");
/*  128 */       action.setAttribute("method", "silentmode");
/*  129 */       root.addContent(action);
/*  130 */       XMLUtils.writeDocumentToXMLFile(doc, InteractionUtil.getFileName(interaction, "dialog"));
/*  131 */       return new String(XMLUtils.convertDocumentToBytes(doc));
/*      */     }
/*  133 */     Element dialog = new Element("dialog");
/*  134 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  136 */       INTERACTIONLOGGER.debug("Dialog id " + intGenerator.getString("mapoption").toLowerCase());
/*      */     }
/*  138 */     dialog.setAttribute("id", intGenerator.getString("mapoption").toLowerCase());
/*  139 */     dialog.setAttribute("label", intGenerator.getString("optdescription"));
/*  140 */     dialog.setAttribute("beanclass", "com.ibm.tivoli.maximo.interaction.beans.process.ExternalServiceBean");
/*  141 */     dialog.setAttribute("width", "800");
/*  142 */     dialog.setAttribute("height", "350");
/*  143 */     dialog.setAttribute("hidehelp", "true");
/*      */ 
/*  145 */     if (intMode.equals("SHOWREQRESP"))
/*      */     {
/*  147 */       INTERACTIONLOGGER.debug("Before request ");
/*  148 */       Element tabs = new Element("tabgroup");
/*  149 */       tabs.setAttribute("id", interaction + "_tabs_" + intGenerator.getString("mapoption").toLowerCase());
/*  150 */       dialog.addContent(tabs);
/*      */ 
/*  152 */       Element requestTab = new Element("tab");
/*  153 */       requestTab.setAttribute("id", interaction + "_request_tab_" + intGenerator.getString("mapoption").toLowerCase());
/*  154 */       requestTab.setAttribute("default", "true");
/*  155 */       requestTab.setAttribute("label", this.requestTabLabel);
/*  156 */       tabs.addContent(requestTab);
/*      */ 
/*  158 */       generateTab(interaction, requestTab, "REQATTRIBUTES", "request", intGenerator.getMboSet("REQUESTMBOS"), intGenerator.getBoolean("isreqmultiple"), null, null, intMode, 0);

/*      */ 
/*  161 */       Element btngroup = new Element("buttongroup");
/*  162 */       btngroup.setAttribute("id", interaction + "_request_grid4" + "_" + generateUniqueID());
/*  163 */       requestTab.addContent(btngroup);
/*      */ 
/*  165 */       Element button1 = new Element("pushbutton");
/*  166 */       button1.setAttribute("id", interaction + "_request_grid4_1" + "_" + generateUniqueID());
/*  167 */       button1.setAttribute("label", this.invokeServiceButtonLabel);
/*  168 */       button1.setAttribute("default", "true");
/*  169 */       button1.setAttribute("mxevent", "invokeservice");
/*  170 */       button1.setAttribute("value", interaction);
/*  171 */       btngroup.addContent(button1);
/*  172 */       INTERACTIONLOGGER.debug("After request ");
/*      */ 
/*  174 */       Element responseTab = new Element("tab");
/*  175 */       responseTab.setAttribute("id", interaction + "_response_tab_" + intGenerator.getString("mapoption").toLowerCase());
/*  176 */       responseTab.setAttribute("label", this.responseTabLabel);
/*  177 */       if (!(intGenerator.getBoolean("isrespmultiple")))
/*      */       {
/*  179 */         responseTab.setAttribute("relationship", intGenerator.getString("resprelation"));
/*      */       }
/*  181 */       tabs.addContent(responseTab);
/*      */ 
/*  183 */       generateTab(interaction, responseTab, "RESPATTRIBUTES", "response", intGenerator.getMboSet("RESPONSEMBOS"), intGenerator.getBoolean("isrespmultiple"), null, null, intMode, 0);

/*      */ 
/*  186 */       if (intGenerator.getBoolean("applyresponse"))
/*      */       {
/*  188 */         INTERACTIONLOGGER.debug("Generating apply response button ");
/*  189 */         Element applygroup = new Element("buttongroup");
/*  190 */         applygroup.setAttribute("id", interaction + "_response_table_grid4" + "_" + generateUniqueID());
/*  191 */         responseTab.addContent(applygroup);
/*      */ 
/*  193 */         Element button3 = new Element("pushbutton");
/*  194 */         button3.setAttribute("id", interaction + "_response_table_grid4_2" + "_" + generateUniqueID());
/*  195 */         button3.setAttribute("label", this.applyButtonLabel);
/*  196 */         button3.setAttribute("mxevent", "applychanges");
/*  197 */         button3.setAttribute("value", interaction);
/*  198 */         applygroup.addContent(button3);
/*      */       }
/*  200 */       INTERACTIONLOGGER.debug("After response ");
/*      */     }
/*  202 */     else if (intMode.equals("SHOWREQONLY"))
/*      */     {
/*  204 */       INTERACTIONLOGGER.debug("Before request ");
/*  205 */       generateTab(interaction, dialog, "REQATTRIBUTES", "request", intGenerator.getMboSet("REQUESTMBOS"), intGenerator.getBoolean("isreqmultiple"), null, null, intMode, 0);

/*      */ 
/*  208 */       Element btngroup = new Element("buttongroup");
/*  209 */       btngroup.setAttribute("id", interaction + "_request_grid4" + "_" + generateUniqueID());
/*  210 */       dialog.addContent(btngroup);
/*      */ 
/*  212 */       Element button1 = new Element("pushbutton");
/*  213 */       button1.setAttribute("id", interaction + "_request_grid4_1" + "_" + generateUniqueID());
/*  214 */       button1.setAttribute("label", this.invokeServiceButtonLabel);
/*  215 */       button1.setAttribute("default", "true");
/*  216 */       button1.setAttribute("mxevent", "invokeservice");
/*  217 */       button1.setAttribute("value", interaction);
/*  218 */       btngroup.addContent(button1);
/*  219 */       INTERACTIONLOGGER.debug("After request ");
/*      */     }
/*  221 */     else if (intMode.equals("SHOWRESPONLY"))
/*      */     {
/*  223 */       INTERACTIONLOGGER.debug("Before response ");
/*      */ 
/*  225 */       generateTab(interaction, dialog, "RESPATTRIBUTES", "response", intGenerator.getMboSet("RESPONSEMBOS"), intGenerator.getBoolean("isrespmultiple"), null, null, intMode, 0);

/*      */ 
/*  228 */       if (intGenerator.getBoolean("applyresponse"))
/*      */       {
/*  230 */         Element applygroup = new Element("buttongroup");
/*  231 */         applygroup.setAttribute("id", interaction + "_response_table_grid4" + "_" + generateUniqueID());
/*  232 */         dialog.addContent(applygroup);
/*      */ 
/*  234 */         Element button2 = new Element("pushbutton");
/*  235 */         button2.setAttribute("id", interaction + "_response_table_grid4_2" + "_" + generateUniqueID());
/*  236 */         button2.setAttribute("label", this.applyButtonLabel);
/*  237 */         button2.setAttribute("mxevent", "applychanges");
/*  238 */         button2.setAttribute("value", interaction);
/*  239 */         applygroup.addContent(button2);
/*      */       }
/*  241 */       INTERACTIONLOGGER.debug("After response ");
/*      */     }
/*      */ 
/*  244 */     Element btngroup = new Element("buttongroup");
/*  245 */     btngroup.setAttribute("id", interaction + "_2" + "_" + generateUniqueID());
/*  246 */     dialog.addContent(btngroup);
/*      */ 
/*  248 */     Element button1 = new Element("pushbutton");
/*  249 */     button1.setAttribute("id", interaction + "_2_1" + "_" + generateUniqueID());
/*  250 */     button1.setAttribute("label", this.okButtonLabel);
/*  251 */     button1.setAttribute("mxevent", "dialogok");
/*  252 */     btngroup.addContent(button1);
/*      */ 
/*  254 */     Element button2 = new Element("pushbutton");
/*  255 */     button2.setAttribute("id", interaction + "_2_2" + "_" + generateUniqueID());
/*  256 */     button2.setAttribute("label", this.cancelButtonLabel);
/*  257 */     button2.setAttribute("mxevent", "dialogcancel");
/*  258 */     btngroup.addContent(button2);
/*      */ 
/*  260 */     List allDialogs = root.getChildren("dialog");
/*  261 */     for (int i = 0; i < allDialogs.size(); ++i)
/*      */     {
/*  263 */       Element el = (Element)allDialogs.get(i);
/*  264 */       String id = el.getAttributeValue("id");
/*  265 */       if (!(id.equals(interaction)))
/*      */         continue;
/*  267 */       allDialogs.remove(el);
/*  268 */       break;
/*      */     }
/*      */ 
/*  271 */     root.addContent(dialog);
/*  272 */     XMLUtils.writeDocumentToXMLFile(doc, InteractionUtil.getFileName(interaction, "dialog"));
/*      */ 
/*  274 */     INTERACTIONLOGGER.debug("Leaving generateDialog ");
/*      */ 
/*  276 */     return new String(XMLUtils.convertDocumentToBytes(doc));
/*      */   }












/*      */   public Document getAppXML(String app, UserInfo userInfo)
/*      */     throws RemoteException, MXException
/*      */   {
/*  293 */     Document doc = null;
/*  294 */     INTERACTIONLOGGER.debug("Entering getAppXML ");
/*      */ 
/*  296 */     SqlFormat sqf = new SqlFormat(userInfo, "app = :1");
/*  297 */     sqf.setObject(1, "MAXPRESENTATION", "APP", app);
/*  298 */     MboSetRemote presentSet = MXServer.getMXServer().getMboSet("MAXPRESENTATION", userInfo);
/*  299 */     presentSet.setWhere(sqf.format());
/*  300 */     presentSet.reset();
/*  301 */     if (presentSet.isEmpty())
/*      */     {
/*  303 */       String[] params = { app };
/*  304 */       throw new MXApplicationException("designer", "nopresentation", params);
/*      */     }
/*  306 */     MboRemote present = presentSet.moveFirst();
/*  307 */     String data = present.getString("presentation");
/*      */     try
/*      */     {
/*  310 */       doc = XMLUtils.convertBytesToDocument(data.getBytes("UTF-8"));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  314 */       throw new MXApplicationException("iface", "schemaenc", e);
/*      */     }
/*      */ 
/*  317 */     INTERACTIONLOGGER.debug("Leaving getAppXML ");
/*  318 */     return doc;
/*      */   }
























/*      */   private void generateTab(String interaction, Element parent, String attributeRel, String requestResponse, MboSetRemote objectSet, boolean isMultiple, String hierarchyPath, String parentObject, String intMode, int level)
/*      */     throws RemoteException, MXException
/*      */   {
/*  347 */     Element processElement = null;
/*  348 */     Element tabs = null;
/*  349 */     List allChildren = findChildren(objectSet, attributeRel, hierarchyPath);
/*  350 */     String parentName = null;
/*      */ 
/*  352 */     int childrenSize = allChildren.size();
/*  353 */     if (childrenSize == 0)
/*      */     {
/*  355 */       return;
/*      */     }
/*  357 */     for (int i = 0; i < childrenSize; ++i)
/*      */     {
/*  359 */       MboRemote processMbo = (MboRemote)allChildren.get(i);
/*  360 */       if (childrenSize == 1)
/*      */       {
/*  362 */         processElement = parent;
/*      */       }
/*      */       else
/*      */       {
/*  366 */         processElement = new Element("tab");
/*  367 */         if (parentObject == null)
/*      */         {
/*  369 */           processElement.setAttribute("id", interaction + "_" + requestResponse + "_tab_" + interaction.toLowerCase() + "_" + i + "_" + generateUniqueID());
/*      */         }
/*      */         else
/*      */         {
/*  373 */           processElement.setAttribute("id", interaction + "_" + requestResponse + "_tab_" + parentObject.toLowerCase() + "_" + i + "_" + generateUniqueID());
/*      */         }
/*  375 */         if (i == 0)
/*      */         {
/*  377 */           processElement.setAttribute("default", "true");
/*      */         }
/*  379 */         if (requestResponse.equals("request"))
/*      */         {
/*  381 */           processElement.setAttribute("label", this.requestLabel + " " + processMbo.getString("wsioobjname"));
/*      */         }
/*      */         else
/*      */         {
/*  385 */           processElement.setAttribute("label", this.responseLabel + " " + processMbo.getString("wsioobjname"));
/*      */         }
/*  387 */         if (i == 0)
/*      */         {
/*  389 */           tabs = new Element("tabgroup");
/*  390 */           if (parentObject == null)
/*      */           {
/*  392 */             tabs.setAttribute("id", interaction + "_" + requestResponse + "_" + interaction.toLowerCase() + "_tabs" + "_" + generateUniqueID());
/*      */           }
/*      */           else
/*      */           {
/*  396 */             tabs.setAttribute("id", interaction + "_" + requestResponse + "_" + parentObject.toLowerCase() + "_tabs" + "_" + generateUniqueID());
/*      */           }
/*  398 */           parent.addContent(tabs);
/*  399 */           tabs.addContent(processElement);
/*      */         }
/*      */         else
/*      */         {
/*  403 */           tabs.addContent(processElement);
/*      */         }
/*      */       }
/*  406 */       Vector allColumns = processMbo.getMboSet(attributeRel).getSelection();
/*  407 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  409 */         INTERACTIONLOGGER.debug("Hierarachy Path " + processMbo.getString("hierarchypath"));
/*  410 */         INTERACTIONLOGGER.debug("Columns size " + allColumns.size());
/*  411 */         INTERACTIONLOGGER.debug("Is unbounded " + isMultiple);
/*  412 */         INTERACTIONLOGGER.debug("Level is " + level);
/*  413 */         INTERACTIONLOGGER.debug("ParentObject before " + parentObject);
/*      */       }
/*      */ 
/*  416 */       if ((isMultiple) || (level > 0))
/*      */       {
/*  418 */         generateTable(processElement, interaction, processMbo.getString("wsioobjname").toLowerCase(), parentObject, requestResponse, allColumns, level);



/*      */       }
/*  423 */       else if ((intMode.equals("SHOWRESPONLY")) && (requestResponse.equals("response")))
/*      */       {
/*  425 */         generateSection(processElement, interaction, processMbo.getString("wsioobjname"), requestResponse, allColumns);
/*      */       }
/*      */       else
/*      */       {
/*  429 */         generateSection(processElement, interaction, null, requestResponse, allColumns);
/*      */       }
/*      */ 
/*  432 */       if ((isMultiple) || (level > 1))
/*      */       {
/*  434 */         parentName = processMbo.getString("wsioobjname").toLowerCase();
/*      */       }
/*      */       else
/*      */       {
/*  438 */         parentName = parentObject;
/*      */       }
/*      */ 
/*  441 */       generateTab(interaction, processElement, attributeRel, requestResponse, objectSet, isMultiple, processMbo.getString("hierarchypath"), parentName, intMode, level + 1);
/*      */     }
/*      */   }

















/*      */   private void generateSection(Element tab, String interaction, String relation, String type, Vector columns)
/*      */     throws RemoteException, MXException
/*      */   {
/*  464 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  466 */       INTERACTIONLOGGER.debug("Entering generateSection " + type);
/*  467 */       INTERACTIONLOGGER.debug("column size  " + columns.size());
/*      */     }
/*  469 */     Element section = new Element("section");
/*  470 */     section.setAttribute("id", interaction + "_" + type + "_grid1" + "_" + generateUniqueID());
/*  471 */     section.setAttribute("border", "true");
/*  472 */     if (relation != null)
/*      */     {
/*  474 */       section.setAttribute("relationship", relation.toUpperCase());
/*      */     }
/*  476 */     tab.addContent(section);
/*      */ 
/*  478 */     Element sectionrow = new Element("sectionrow");
/*  479 */     sectionrow.setAttribute("id", interaction + "_" + type + "_grid1_row" + "_" + generateUniqueID());
/*  480 */     section.addContent(sectionrow);
/*      */ 
/*  482 */     Element sectioncol1 = new Element("sectioncol");
/*  483 */     sectioncol1.setAttribute("id", interaction + "_" + type + "_grid1_row_col1" + "_" + generateUniqueID());
/*  484 */     sectionrow.addContent(sectioncol1);
/*      */ 
/*  486 */     Element section1 = new Element("section");
/*  487 */     section1.setAttribute("id", interaction + "_" + type + "_grid1_row_col1_sec" + "_" + generateUniqueID());
/*  488 */     sectioncol1.addContent(section1);
/*      */ 
/*  490 */     boolean firstColumn = true;
/*  491 */     Element sectioncol2 = null;
/*  492 */     Element section2 = null;
/*      */ 
/*  494 */     for (int i = 0; i < columns.size(); ++i)
/*      */     {
/*  496 */       MboRemote attr = (MboRemote)columns.get(i);
/*      */ 
/*  498 */       String name = attr.getString("attributename").toLowerCase();
/*  499 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  501 */         INTERACTIONLOGGER.debug("Attribute name " + name);
/*      */       }
/*  503 */       String colType = attr.getString("maxtype");
/*  504 */       Element textbox = null;
/*  505 */       if (colType.equalsIgnoreCase("YORN"))
/*      */       {
/*  507 */         textbox = new Element("checkbox");
/*      */       }
/*      */       else
/*      */       {
/*  511 */         textbox = new Element("textbox");
/*      */       }
/*  513 */       textbox.setAttribute("id", interaction + "_" + type + "_grid1_row_col1_sec_" + i + "_" + generateUniqueID());
/*  514 */       textbox.setAttribute("dataattribute", name);
/*  515 */       if (attr.getBoolean("readonly"))
/*      */       {
/*  517 */         textbox.setAttribute("inputmode", "readonly");
/*      */       }
/*  519 */       if (!(attr.isNull("domaintype")))
/*      */       {
/*  521 */         setLookup(textbox, attr.getString("domaintype"));
/*      */       }
/*  523 */       if ((!(attr.isNull("specialprocess"))) && (attr.getString("specialprocess").equals("PASSWORD")))
/*      */       {
/*  525 */         textbox.setAttribute("inputmode", "password");
/*      */       }
/*  527 */       if (firstColumn)
/*      */       {
/*  529 */         section1.addContent(textbox);
/*  530 */         firstColumn = false;

/*      */       }
/*      */       else
/*      */       {
/*  535 */         if (sectioncol2 == null)
/*      */         {
/*  537 */           sectioncol2 = new Element("sectioncol");
/*  538 */           sectioncol2.setAttribute("id", interaction + "_" + type + "_grid1_row_col2" + "_" + generateUniqueID());
/*  539 */           sectionrow.addContent(sectioncol2);
/*      */ 
/*  541 */           section2 = new Element("section");
/*  542 */           section2.setAttribute("id", interaction + "_" + type + "_grid1_row_col2_sec" + "_" + generateUniqueID());
/*  543 */           sectioncol2.addContent(section2);
/*      */         }
/*  545 */         section2.addContent(textbox);
/*  546 */         firstColumn = true;
/*      */       }
/*      */     }
/*      */   }


















/*      */   private Element generateTable(Element tab, String interaction, String objectName, String parentObject, String type, Vector columns, int level)
/*      */     throws RemoteException, MXException
/*      */   {
/*  571 */     Element sectionWrapper = new Element("section");
/*  572 */     sectionWrapper.setAttribute("id", "section_" + interaction + "_" + type + "_" + objectName + "_table" + "_" + generateUniqueID());
/*  573 */     sectionWrapper.setAttribute("border", "true");
/*  574 */     tab.addContent(sectionWrapper);
/*      */ 
/*  576 */     Element table = new Element("table");
/*  577 */     table.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_1111");
/*  578 */     table.setAttribute("label", objectName.toUpperCase());
/*  579 */     if (parentObject != null)
/*      */     {
/*  581 */       table.setAttribute("parentdatasrc", interaction + "_" + type + "_" + parentObject + "_table_1111");
/*      */     }
/*  583 */     if (type.equals("response"))
/*      */     {
/*  585 */       table.setAttribute("relationship", objectName.toUpperCase());
/*  586 */       table.setAttribute("selectmode", "multiple");
/*      */     }
/*  588 */     if ((type.equals("request")) && (level > 0))
/*      */     {
/*  590 */       table.setAttribute("relationship", objectName.toUpperCase());
/*      */     }
/*  592 */     sectionWrapper.addContent(table);
/*      */ 
/*  594 */     Element tablebody = new Element("tablebody");
/*  595 */     tablebody.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_tablebody" + "_" + generateUniqueID());
/*  596 */     tablebody.setAttribute("displayrowsperpage", "20");
/*  597 */     tablebody.setAttribute("filterexpanded", "false");
/*  598 */     tablebody.setAttribute("filterable", "false");
/*  599 */     table.addContent(tablebody);
/*      */ 
/*  601 */     Element tablecolsys1 = new Element("tablecol");
/*  602 */     tablecolsys1.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_tablebody_sys1" + "_" + generateUniqueID());
/*  603 */     tablecolsys1.setAttribute("type", "event");
/*  604 */     tablecolsys1.setAttribute("mxevent", "toggleselectrow");
/*  605 */     tablecolsys1.setAttribute("sortable", "false");
/*  606 */     tablecolsys1.setAttribute("filterable", "false");
/*  607 */     tablecolsys1.setAttribute("hidden", "false");
/*  608 */     tablebody.addContent(tablecolsys1);
/*      */ 
/*  610 */     Element tablecolsys2 = new Element("tablecol");
/*  611 */     tablecolsys2.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_tablebody_sys2" + "_" + generateUniqueID());
/*  612 */     tablecolsys2.setAttribute("type", "event");
/*  613 */     tablecolsys2.setAttribute("mxevent", "toggledetailstate");
/*  614 */     tablecolsys2.setAttribute("mxevent_desc", "Show Details");
/*  615 */     tablecolsys2.setAttribute("sortable", "false");
/*  616 */     tablecolsys2.setAttribute("filterable", "false");
/*  617 */     tablecolsys2.setAttribute("hidden", "false");
/*  618 */     tablebody.addContent(tablecolsys2);
/*      */ 
/*  620 */     Element tabledet = new Element("tabledetails");
/*  621 */     tabledet.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_details" + "_" + generateUniqueID());
/*  622 */     table.addContent(tabledet);
/*      */ 
/*  624 */     Element section = new Element("section");
/*  625 */     section.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1" + "_" + generateUniqueID());
/*  626 */     section.setAttribute("label", this.detailsLabel);
/*  627 */     tabledet.addContent(section);
/*      */ 
/*  629 */     Element sectionrow = new Element("sectionrow");
/*  630 */     sectionrow.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1_row" + "_" + generateUniqueID());
/*  631 */     section.addContent(sectionrow);
/*      */ 
/*  633 */     Element sectioncol1 = new Element("sectioncol");
/*  634 */     sectioncol1.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1_row_col1" + "_" + generateUniqueID());
/*  635 */     sectionrow.addContent(sectioncol1);
/*      */ 
/*  637 */     Element section1 = new Element("section");
/*  638 */     section1.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1_row_col1_sec" + "_" + generateUniqueID());
/*  639 */     sectioncol1.addContent(section1);
/*      */ 
/*  641 */     int colOrder = 1;
/*  642 */     int attrPos = 0;
/*  643 */     Element sectioncol2 = null;
/*  644 */     Element section2 = null;
/*  645 */     Element sectioncol3 = null;
/*  646 */     Element section3 = null;
/*  647 */     Element tablecol = null;
/*      */ 
/*  649 */     for (int i = 0; i < columns.size(); ++i)
/*      */     {
/*  651 */       MboRemote attr = (MboRemote)columns.get(i);
/*  652 */       String name = attr.getString("attributename").toLowerCase();
/*  653 */       ++attrPos;
/*      */ 
/*  655 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  657 */         INTERACTIONLOGGER.debug("Attribute name " + name);
/*  658 */         INTERACTIONLOGGER.debug("Attribute position " + attrPos);
/*      */       }
/*  660 */       if (attrPos < 6)
/*      */       {
/*  662 */         INTERACTIONLOGGER.debug("In table column ");
/*  663 */         tablecol = new Element("tablecol");
/*  664 */         tablecol.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_tablebody_" + attrPos + "_" + generateUniqueID());
/*  665 */         tablecol.setAttribute("dataattribute", name);
/*  666 */         tablecol.setAttribute("sortable", "false");
/*  667 */         if ((!(attr.isNull("specialprocess"))) && (attr.getString("specialprocess").equals("PASSWORD")))
/*      */         {
/*  669 */           tablecol.setAttribute("inputmode", "password");
/*      */         }
/*  671 */         if (attr.getBoolean("readonly"))
/*      */         {
/*  673 */           tablecol.setAttribute("inputmode", "readonly");
/*      */         }
/*  675 */         if (!(attr.isNull("domaintype")))
/*      */         {
/*  677 */           setLookup(tablecol, attr.getString("domaintype"));
/*      */         }
/*  679 */         tablebody.addContent(tablecol);
/*      */       }
/*      */ 
/*  682 */       String colType = attr.getString("maxtype");
/*  683 */       Element textbox = null;
/*  684 */       if (colType.equalsIgnoreCase("YORN"))
/*      */       {
/*  686 */         textbox = new Element("checkbox");
/*      */       }
/*      */       else
/*      */       {
/*  690 */         textbox = new Element("textbox");
/*      */       }
/*  692 */       textbox.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1_row_col_sec_" + attrPos + "_" + generateUniqueID());
/*      */ 
/*  694 */       textbox.setAttribute("dataattribute", name);
/*  695 */       if (attr.getBoolean("readonly"))
/*      */       {
/*  697 */         textbox.setAttribute("inputmode", "readonly");
/*      */       }
/*  699 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  701 */         INTERACTIONLOGGER.debug("Has domain " + attr.getString("domainid"));
/*      */       }
/*  703 */       if (!(attr.isNull("domaintype")))
/*      */       {
/*  705 */         setLookup(textbox, attr.getString("domaintype"));
/*      */       }
/*  707 */       if (colOrder == 1)
/*      */       {
/*  709 */         section1.addContent(textbox);
/*  710 */         colOrder = 2;

/*      */       }
/*  713 */       else if (colOrder == 2)
/*      */       {
/*  715 */         if (sectioncol2 == null)
/*      */         {
/*  717 */           sectioncol2 = new Element("sectioncol");
/*  718 */           sectioncol2.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1_row_col2" + "_" + generateUniqueID());
/*  719 */           sectionrow.addContent(sectioncol2);
/*      */ 
/*  721 */           section2 = new Element("section");
/*  722 */           section2.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1_row_col2_sec" + "_" + generateUniqueID());
/*  723 */           sectioncol2.addContent(section2);
/*      */         }
/*  725 */         section2.addContent(textbox);
/*  726 */         colOrder = 3;
/*      */       }
/*      */       else {
/*  729 */         if (colOrder != 3)
/*      */           continue;
/*  731 */         if (sectioncol3 == null)
/*      */         {
/*  733 */           sectioncol3 = new Element("sectioncol");
/*  734 */           sectioncol3.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1_row_col3" + "_" + generateUniqueID());
/*  735 */           sectionrow.addContent(sectioncol3);
/*      */ 
/*  737 */           section3 = new Element("section");
/*  738 */           section3.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_grid1_row_col3_sec" + "_" + generateUniqueID());
/*  739 */           sectioncol3.addContent(section3);
/*      */         }
/*  741 */         section3.addContent(textbox);
/*  742 */         colOrder = 1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  747 */     Element tablecolsys3 = new Element("tablecol");
/*  748 */     tablecolsys3.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_tablebody_sys3" + "_" + generateUniqueID());
/*  749 */     tablecolsys3.setAttribute("type", "event");
/*  750 */     tablecolsys3.setAttribute("mxevent", "toggledeleterow");
/*  751 */     tablecolsys3.setAttribute("mxevent_desc", this.markRowForDeleteLabel);
/*  752 */     tablecolsys3.setAttribute("mxevent_icon", "btn_garbage.gif");
/*  753 */     tablecolsys3.setAttribute("sortable", "false");
/*  754 */     tablecolsys3.setAttribute("filterable", "false");
/*  755 */     tablecolsys3.setAttribute("hidden", "false");
/*  756 */     tablebody.addContent(tablecolsys3);
/*      */ 
/*  758 */     if (type.equals("request"))
/*      */     {
/*  760 */       Element btngroup = new Element("buttongroup");
/*  761 */       btngroup.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_buttongroup" + "_" + generateUniqueID());
/*  762 */       table.addContent(btngroup);
/*      */ 
/*  764 */       Element button2 = new Element("pushbutton");
/*  765 */       button2.setAttribute("id", interaction + "_" + type + "_" + objectName + "_table_button1" + "_" + generateUniqueID());
/*  766 */       button2.setAttribute("label", this.newRowButtonLabel);
/*  767 */       button2.setAttribute("mxevent", "addrow");
/*  768 */       button2.setAttribute("default", "true");
/*  769 */       btngroup.addContent(button2);
/*      */     }
/*  771 */     return table;
/*      */   }











/*      */   public String removeDialog(Document doc, String dialogID)
/*      */     throws RemoteException, MXException
/*      */   {
/*  787 */     Element root = doc.getRootElement();
/*  788 */     List allDialogs = root.getChildren("dialog");
/*  789 */     for (int i = 0; i < allDialogs.size(); ++i)
/*      */     {
/*  791 */       Element el = (Element)allDialogs.get(i);
/*  792 */       String id = el.getAttributeValue("id");
/*  793 */       if (!(id.equals(dialogID.toLowerCase())))
/*      */         continue;
/*  795 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  797 */         INTERACTIONLOGGER.debug("Found Dialog " + dialogID);
/*      */       }
/*  799 */       allDialogs.remove(el);
/*  800 */       break;
/*      */     }
/*      */ 
/*  803 */     return new String(XMLUtils.convertDocumentToBytes(doc));
/*      */   }












/*      */   public boolean findDialog(Document doc, String appName, String dialogID)
/*      */     throws RemoteException, MXException
/*      */   {
/*  820 */     boolean found = false;
/*  821 */     Element root = doc.getRootElement();
/*  822 */     List allDialogs = root.getChildren("dialog");
/*  823 */     for (int i = 0; i < allDialogs.size(); ++i)
/*      */     {
/*  825 */       Element el = (Element)allDialogs.get(i);
/*  826 */       String id = el.getAttributeValue("id");
/*  827 */       if (!(id.equalsIgnoreCase(dialogID)))
/*      */         continue;
/*  829 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  831 */         INTERACTIONLOGGER.debug("Leaving findDialog " + found);
/*      */       }
/*  833 */       return true;
/*      */     }
/*      */ 
/*  836 */     return found;
/*      */   }











/*      */   public boolean findElementByID(Element in, String inid)
/*      */     throws RemoteException, MXException
/*      */   {
/*  852 */     String id = in.getAttributeValue("id");
/*  853 */     if (id.equalsIgnoreCase(inid))
/*      */     {
/*  855 */       return true;
/*      */     }
/*  857 */     List allDialogs = in.getChildren();
/*  858 */     for (int i = 0; i < allDialogs.size(); ++i)
/*      */     {
/*  860 */       Element el = (Element)allDialogs.get(i);
/*  861 */       if (!(findElementByID(el, inid)))
/*      */         continue;
/*  863 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  865 */         INTERACTIONLOGGER.debug("Find Element By ID " + inid);
/*      */       }
/*  867 */       return true;
/*      */     }
/*      */ 
/*  870 */     return false;
/*      */   }












/*      */   public boolean findAction(Document doc, String appName, String actionId)
/*      */     throws RemoteException, MXException
/*      */   {
/*  887 */     Element root = doc.getRootElement();
/*  888 */     List allActions = root.getChildren("action");
/*  889 */     for (int i = 0; i < allActions.size(); ++i)
/*      */     {
/*  891 */       Element el = (Element)allActions.get(i);
/*  892 */       String id = el.getAttributeValue("id");
/*  893 */       if (!(id.equalsIgnoreCase(actionId)))
/*      */         continue;
/*  895 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  897 */         INTERACTIONLOGGER.debug("Found Action " + actionId);
/*      */       }
/*  899 */       return true;
/*      */     }
/*      */ 
/*  902 */     return false;
/*      */   }













/*      */   public List<MboRemote> findChildren(MboSetRemote set, String relation, String hierarchyPath)
/*      */     throws RemoteException, MXException
/*      */   {
/*  920 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  922 */       INTERACTIONLOGGER.debug("Entering findChildren " + hierarchyPath);
/*      */     }
/*  924 */     List allChildren = new ArrayList();
/*      */ 
/*  926 */     for (int j = 0; j < set.getSize(); ++j)
/*      */     {
/*  928 */       MboRemote mbo = set.getMbo(j);
/*  929 */       if (mbo == null) {
/*      */         break;
/*      */       }
/*      */ 
/*  933 */       String mboPath = mbo.getString("hierarchypath");
/*  934 */       if (hierarchyPath == null)
/*      */       {
/*  936 */         if (mboPath.indexOf("/") != -1)
/*      */           continue;
/*  938 */         Vector requestColumns = mbo.getMboSet(relation).getSelection();
/*  939 */         if (requestColumns.size() <= 0)
/*      */           break;
/*  941 */         allChildren.add(mbo); break;


/*      */       }
/*      */ 
/*  946 */       if (mboPath.equals(hierarchyPath)) continue; if (mboPath.indexOf(hierarchyPath) == -1)

/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/*  952 */       String rest = mboPath.substring(hierarchyPath.length());
/*  953 */       if (!(rest.startsWith("/"))) {
/*      */         continue;
/*      */       }
/*      */ 
/*  957 */       rest = rest.substring(1);
/*  958 */       if (rest.indexOf("/") != -1) {
/*      */         continue;
/*      */       }
/*  961 */       Vector requestColumns = mbo.getMboSet(relation).getSelection();
/*  962 */       if (requestColumns.size() <= 0)
/*      */         continue;
/*  964 */       allChildren.add(mbo);


/*      */     }
/*      */ 
/*  969 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  971 */       INTERACTIONLOGGER.debug("Leaving findChildren " + allChildren.size());
/*      */     }
/*  973 */     return allChildren;
/*      */   }











/*      */   public void setLookup(Element data, String type)
/*      */     throws RemoteException, MXException
/*      */   {
/*  989 */     String domainType = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("DOMTYPE", type);
/*      */ 
/*  991 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  993 */       INTERACTIONLOGGER.debug("Domain type " + domainType);
/*      */     }
/*  995 */     if (domainType.equals("ALN"))
/*      */     {
/*  997 */       data.setAttribute("lookup", "alndomain");
/*      */     }
/*  999 */     else if (domainType.equals("SYNONYM"))
/*      */     {
/* 1001 */       data.setAttribute("lookup", "valuelist");
/*      */     } else {
/* 1003 */       if (!(domainType.equals("NUMERIC")))
/*      */         return;
/* 1005 */       data.setAttribute("lookup", "numericdomain");
/*      */     }
/*      */   }





/*      */   public String generateUniqueID()
/*      */   {
/* 1015 */     return String.valueOf(System.currentTimeMillis());
/*      */   }
/*      */ }
