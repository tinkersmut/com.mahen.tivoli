/*     */ package com.ibm.tivoli.maximo.interaction.generate;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.app.createint.IntGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionUtil;
/*     */ import java.io.IOException;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
















































/*     */ public class IntArtifactsGenerator
/*     */ {
/*  44 */   public static final MXLogger INTERACTIONLOGGER = InteractionUtil.INTERACTIONLOGGER;
/*     */ 
/*     */   public void createInteraction(MboRemote intGenerator)
/*     */     throws MXException, RemoteException
/*     */   {
/*  70 */     INTERACTIONLOGGER.debug("Entering createInteraction ");
/*     */ 
/*  72 */     MboRemote inter = null;
/*  73 */     MboSetRemote interSet = intGenerator.getMboSet("MAXINTERACTION");
/*  74 */     interSet.setMXTransaction(intGenerator.getMXTransaction());
/*  75 */     if (interSet.isEmpty())
/*     */     {
/*  77 */       inter = interSet.add();
/*     */     }
/*     */     else
/*     */     {
/*  81 */       inter = interSet.moveFirst();
/*     */     }
/*  83 */     inter.setValue("interaction", intGenerator.getString("interaction"));
/*  84 */     inter.setValue("description", intGenerator.getString("description"), 11L);
/*     */ 
/*  86 */     inter.setValue("channelname", intGenerator.getString("invchannelname"), 11L);
/*     */ 
/*  88 */     inter.setValue("appname", intGenerator.getString("appname"), 11L);
/*     */ 
/*  90 */     inter.setValue("intmainobject", intGenerator.getString("appobject"), 11L);
/*     */ 
/*  92 */     inter.setValue("intmode", intGenerator.getString("intmode"), 11L);
/*     */ 
/*  94 */     inter.setValue("mapoption", intGenerator.getString("mapoption"), 11L);
/*     */ 
/*  96 */     if (intGenerator.getBoolean("generatedialog"))
/*     */     {
/*  98 */       inter.setValue("dialogid", intGenerator.getString("mapoption"), 11L);
/*     */     }
/*     */ 
/* 101 */     inter.setValue("reqrelation", intGenerator.getString("reqrelation"), 11L);
/*     */ 
/* 103 */     inter.setValue("resprelation", intGenerator.getString("resprelation"), 11L);
/*     */ 
/* 105 */     inter.setValue("applyresponse", intGenerator.getBoolean("applyresponse"), 11L);
/*     */ 
/* 107 */     inter.setValue("commitresponse", intGenerator.getBoolean("commitresponse"), 11L);
/*     */ 
/* 109 */     inter.setValue("showsingleresponse", intGenerator.getBoolean("showsingleresponse"), 11L);
/*     */ 
/* 111 */     inter.setValue("reqclassname", intGenerator.getString("reqclassname"), 11L);
/*     */ 
/* 113 */     inter.setValue("respclassname", intGenerator.getString("respclassname"), 11L);
/*     */ 
/* 115 */     inter.setValue("url", intGenerator.getString("url"), 11L);
/*     */ 
/* 117 */     inter.setValue("servicename", intGenerator.getString("servicename"), 11L);
/*     */ 
/* 119 */     inter.setValue("portname", intGenerator.getString("portname"), 11L);
/*     */ 
/* 121 */     inter.setValue("operation", intGenerator.getString("operation"), 11L);
/*     */ 
/* 123 */     inter.setValue("reqclassname", intGenerator.getString("reqclassname"), 11L);
/*     */ 
/* 125 */     inter.setValue("respclassname", intGenerator.getString("respclassname"), 11L);
/*     */ 
/* 127 */     inter.setValue("genmenuoption", intGenerator.getString("genmenuoption"), 11L);

/*     */ 
/* 130 */     IntGenerator intGen = (IntGenerator)intGenerator;
/* 131 */     OBPInfo info = intGen.getOBPInfo().createNewInstance(intGen.optimizedRequest, intGen.optimizedResponse);
/*     */     try
/*     */     {
/* 134 */       inter.setValue("obp", new String(OBPGenerator.toBytes(info), "UTF-8"), 11L);

/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 139 */       ioe.printStackTrace();
/* 140 */       throw new MXApplicationException("iface", "bytestostringerror", new String[] { "UTF-8" }, ioe);
/*     */     }
/*     */ 
/* 143 */     inter.setValue("requestxml", intGenerator.getString("requestxml"), 11L);
/*     */ 
/* 145 */     inter.setValue("responsexml", intGenerator.getString("responsexml"), 11L);
/*     */ 
/* 147 */     inter.setValue("active", true, 11L);

/*     */ 
/* 150 */     createInteractionMapping(intGenerator, inter.getMboSet("MAXINTMAPPING"), "REQUESTMBOS", "REQUESTMAPPING", false);
/*     */ 
/* 152 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 154 */       INTERACTIONLOGGER.debug("Apply response " + intGenerator.getBoolean("applyresponse"));
/*     */     }
/* 156 */     if (intGenerator.getBoolean("applyresponse"))
/*     */     {
/* 158 */       createInteractionMapping(intGenerator, inter.getMboSet("MAXINTMAPPING"), "RESPONSEMBOS", "RESPONSEMAPPING", true);
/*     */     }
/* 160 */     INTERACTIONLOGGER.debug("Leaving createInteraction ");
/*     */   }


/*     */   public void createInteractionMapping(MboRemote intGenerator, MboSetRemote interMappingSet, String mboRelation, String attrRelation, boolean isResponse)
/*     */     throws MXException, RemoteException
/*     */   {
/* 167 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 169 */       INTERACTIONLOGGER.debug("Entering createInteractionMapping for request/response " + isResponse);
/*     */     }
/* 171 */     MboSetRemote requestMboSet = intGenerator.getMboSet(mboRelation);
/* 172 */     MboRemote requestMbo = null;
/* 173 */     for (int j = 0; ; ++j)
/*     */     {
/* 175 */       requestMbo = requestMboSet.getMbo(j);
/* 176 */       if (requestMbo == null) {
/*     */         break;
/*     */       }
/*     */ 
/* 180 */       MboRemote interMapping = interMappingSet.add();
/* 181 */       interMapping.setValue("processorder", requestMbo.getInt("processorder"), 11L);
/*     */ 
/* 183 */       interMapping.setValue("mapobject", requestMbo.getString("objectname"), 11L);
/*     */ 
/* 185 */       interMapping.setValue("objectname", requestMbo.getString("wsioobjname"), 11L);
/*     */ 
/* 187 */       if (isResponse)
/*     */       {
/* 189 */         interMapping.setValue("intobjectname", intGenerator.getString("resposname"), 11L);

/*     */       }
/*     */       else
/*     */       {
/* 194 */         interMapping.setValue("intobjectname", intGenerator.getString("reqosname"), 11L);
/*     */       }
/*     */ 
/* 197 */       interMapping.setValue("interaction", intGenerator.getString("interaction"), 11L);
/*     */ 
/* 199 */       interMapping.setValue("relation", requestMbo.getString("apprelation"), 11L);
/*     */ 
/* 201 */       interMapping.setValue("hierarchypath", requestMbo.getString("hierarchypath"), 11L);
/*     */ 
/* 203 */       interMapping.setValue("sourceelement", requestMbo.getString("sourceelement"), 11L);
/*     */ 
/* 205 */       interMapping.setValue("isresponse", isResponse, 11L);

/*     */ 
/* 208 */       MboSetRemote showRequestAttrSet = requestMbo.getMboSet(attrRelation);
/* 209 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 211 */         INTERACTIONLOGGER.debug("Before mapping of attributes " + showRequestAttrSet.getSize());
/*     */       }
/* 213 */       MboSetRemote interMappingDetailSet = interMapping.getMboSet("MAXINTMAPPINGDETAIL");
/* 214 */       MboRemote reqAttr = null;
/* 215 */       for (int k = 0; ; ++k)
/*     */       {
/* 217 */         reqAttr = showRequestAttrSet.getMbo(k);
/* 218 */         if (reqAttr == null) {
/*     */           break;
/*     */         }
/*     */ 
/* 222 */         if (reqAttr.isNull("attributename")) {
/*     */           continue;
/*     */         }
/*     */ 
/* 226 */         MboRemote interMappingDet = interMappingDetailSet.add();
/* 227 */         interMappingDet.setValue("interaction", intGenerator.getString("interaction"), 11L);
/*     */ 
/* 229 */         interMappingDet.setValue("attributename", reqAttr.getString("attributename"), 11L);
/*     */ 
/* 231 */         interMappingDet.setValue("value", reqAttr.getString("value"), 11L);
/*     */ 
/* 233 */         interMappingDet.setValue("password", reqAttr.getString("password"), 11L);
/*     */ 
/* 235 */         interMappingDet.setValue("hierarchypath", requestMbo.getString("hierarchypath"), 11L);
/*     */ 
/* 237 */         interMappingDet.setValue("encryptvalue", reqAttr.getBoolean("encryptvalue"), 11L);
/*     */       }
/*     */ 
/* 240 */       INTERACTIONLOGGER.debug("After mapping of attributes ");
/*     */     }
/* 242 */     if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*     */       return;
/* 244 */     INTERACTIONLOGGER.debug("Leaving createInteractionMapping for request/response " + isResponse);
/*     */   }
/*     */ }
