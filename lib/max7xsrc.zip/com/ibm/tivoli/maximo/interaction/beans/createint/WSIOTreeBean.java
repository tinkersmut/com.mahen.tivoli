/*    */ package com.ibm.tivoli.maximo.interaction.beans.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.beans.common.TreeControlBean;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 



























/*    */ public class WSIOTreeBean extends TreeControlBean
/*    */ {
/* 33 */   public String uniqueIdSelected = null;
/*    */ 
/*    */   public void setcurrentnode(String newobjectname, String newuniqueidname, String newuniqueidvalue)
/*    */     throws MXException, RemoteException
/*    */   {
/*    */   }
/*    */ 
/*    */   public int selectnode()
/*    */     throws MXException, RemoteException
/*    */   {
/* 49 */     this.uniqueIdSelected = this.clientSession.getCurrentEvent().getValueString();
/* 50 */     return 1;
/*    */   }

/*    */   public synchronized void structureChangedEvent(DataBean speaker)
/*    */   {
/* 55 */     super.structureChangedEvent(speaker);
/* 56 */     setRefreshTree(true);
/*    */   }
/*    */ }
