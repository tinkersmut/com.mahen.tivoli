/*     */ package com.ibm.tivoli.maximo.interaction.beans.createint;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.app.createint.WSIOTreeSet;
/*     */ import com.ibm.tivoli.maximo.interaction.app.createint.WSIOTreeSetRemote;
/*     */ import java.io.PrintStream;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.webclient.beans.common.TreeControlBean;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 



























/*     */ public class WSIOAttributesTreeBean extends TreeControlBean
/*     */ {
/*     */   protected void initialize()
/*     */     throws MXException, RemoteException
/*     */   {
/*  49 */     super.initialize();
/*  50 */     WSIOTreeSet responseWsioSet = (WSIOTreeSet)getMboSet();
/*  51 */     responseWsioSet.clear();
/*  52 */     responseWsioSet.fill(this.parent.getMbo().getOwner(), true);
/*     */   }






/*     */   public int selectnode() throws MXException, RemoteException
/*     */   {
/*  62 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/*     */     try
/*     */     {
/*  65 */       String uniqueIdSelected = this.clientSession.getCurrentEvent().getValueString();
/*  66 */       System.out.println("Uniquid selectd " + uniqueIdSelected);
/*  67 */       System.out.println("Mbo is " + getMboSet().getMbo(0).getName());
/*  68 */       MboRemote rec = ((WSIOTreeSetRemote)getMboSet()).findMbo(getMboSet().getMbo(0), uniqueIdSelected);
/*  69 */       String fullObjectName = null;
/*  70 */       if (!(rec.isNull("title")))
/*     */       {
/*  72 */         fullObjectName = ":" + rec.getString("title") + "." + rec.getString("objectname").toLowerCase();
/*     */       }
/*     */       else
/*     */       {
/*  76 */         fullObjectName = ":" + rec.getString("objectname").toLowerCase();
/*     */       }
/*  78 */       this.parent.getMbo().setValue("value", fullObjectName);
/*  79 */       System.out.println("element path " + rec.getString("elementpath"));
/*  80 */       int start = rec.getString("elementpath").indexOf("(");
/*  81 */       int end = rec.getString("elementpath").lastIndexOf(")");
/*  82 */       System.out.println("start " + start);
/*  83 */       System.out.println("end " + end);
/*  84 */       this.parent.getMbo().setValue("hierarchypath", rec.getString("elementpath").substring(start + 1, end));
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/*  88 */       WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/*  89 */       this.clientSession.showMessageBox(event, e);
/*     */     }
/*     */     catch (RemoteException m)
/*     */     {
/*  93 */       WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/*  94 */       this.clientSession.showMessageBox(event, m);
/*     */     }
/*  96 */     WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/*  97 */     this.parent.fireDataChangedEvent();
/*  98 */     this.parent.fireStructureChangedEvent();
/*  99 */     return 1;
/*     */   }

/*     */   public synchronized void structureChangedEvent(DataBean speaker)
/*     */   {
/* 104 */     super.structureChangedEvent(speaker);
/* 105 */     setRefreshTree(true);
/*     */   }
/*     */ }
