/*    */ package com.ibm.tivoli.maximo.interaction.beans.manageint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.common.expbuilder.ExpBuilderObjectTreeSetRemote;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.beans.common.DlgRelationshipTreeBean;
/*    */ 


























/*    */ public class WSIORelationshipTreeBean extends DlgRelationshipTreeBean
/*    */ {
/*    */   public synchronized void setRelationshipTreeObject()
/*    */     throws RemoteException, MXException
/*    */   {
/* 41 */     String objectname = this.mboSetRemote.getOwner().getString("objectname");
/* 42 */     if (this.mboSetRemote == null)
/*    */       return;
/* 44 */     ((ExpBuilderObjectTreeSetRemote)this.mboSetRemote).setIncludeNonpersistentAttributes(true);
/* 45 */     ((ExpBuilderObjectTreeSetRemote)this.mboSetRemote).setRelationshipTreeObject(objectname);
/*    */   }
/*    */ }
