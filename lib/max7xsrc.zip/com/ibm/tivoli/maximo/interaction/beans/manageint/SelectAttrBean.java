/*    */ package com.ibm.tivoli.maximo.interaction.beans.manageint;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.interaction.app.manageint.MaxIntMappingDetailSetRemote;
/*    */ import java.io.PrintStream;
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.Vector;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.controller.AppInstance;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.runtime.WebClientRuntime;
/*    */ 












/*    */ public class SelectAttrBean extends DataBean
/*    */ {
/*    */   MboRemote parentMbo;
/*    */ 
/*    */   public SelectAttrBean()
/*    */   {
/* 33 */     this.parentMbo = null;
/*    */   }




/*    */   protected MboSetRemote getMboSetRemote()
/*    */     throws MXException, RemoteException
/*    */   {
/* 42 */     System.out.println("Starting mbo " + this.parent.getMboSet().getName());
/* 43 */     this.parentMbo = this.parent.getMboSet().getOwner();
/* 44 */     System.out.println("Parent mbo " + this.parentMbo.getName());
/* 45 */     return ((MaxIntMappingDetailSetRemote)this.parent.getMboSet()).fillAttributes(this.parentMbo, null);
/*    */   }

/*    */   public synchronized int selectattr() throws MXException, RemoteException {
/* 49 */     MboSetRemote targetSet = this.parent.getMboSet();
/* 50 */     Vector select = this.parentMbo.getMboSet("SELECTATTR").getSelection();
/* 51 */     if (select.isEmpty())
/*    */     {
/* 53 */       return 1;
/*    */     }
/* 55 */     MboRemote sel = null;
/* 56 */     for (int k = 0; k < select.size(); ++k)
/*    */     {
/* 58 */       sel = (MboRemote)select.get(k);
/* 59 */       if (sel == null) {
/*    */         break;
/*    */       }
/*    */ 
/* 63 */       MboRemote target = targetSet.addAtEnd();
/* 64 */       target.setValue("attributename", sel.getString("attributename"));
/*    */     }
/* 66 */     this.parent.refreshTable();
/* 67 */     WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/* 68 */     return 1;
/*    */   }
/*    */ }
