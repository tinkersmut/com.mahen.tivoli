/*     */ package com.ibm.tivoli.maximo.interaction.beans.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionProcesser;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.beans.ResultsBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.ControlInstance;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 















/*     */ public class ExternalServiceBean extends DataBean
/*     */ {
/*     */   InteractionProcesser interactionProcesser;
/*     */   String eventName;
/*     */ 
/*     */   public ExternalServiceBean()
/*     */   {
/*  39 */     this.interactionProcesser = null;
/*     */ 
/*  41 */     this.eventName = null;
/*     */   }




/*     */   protected MboSetRemote getMboSetRemote()
/*     */     throws MXException, RemoteException
/*     */   {
/*  50 */     MboRemote owner = this.clientSession.getCurrentEvent().getSourceControlInstance().getDataBean().getMbo();
/*     */ 
/*  52 */     this.eventName = this.creatingEvent.getType();
/*  53 */     this.interactionProcesser = new InteractionProcesser(this.eventName, this.app.getId());
/*  54 */     MboSetRemote set = this.interactionProcesser.processInteraction(owner);
/*  55 */     fireDataChangedEvent();
/*  56 */     fireStructureChangedEvent();
/*  57 */     if (!(this.interactionProcesser.showResponse()))
/*     */     {
/*  59 */       this.app.getAppBean().fireDataChangedEvent(this.app.getAppBean());
/*  60 */       this.app.getAppBean().fireStructureChangedEvent(this.app.getAppBean());
/*     */ 
/*  62 */       throw new MXApplicationException("iface", "intsuccess");
/*     */     }
/*  64 */     return set;
/*     */   }









/*     */   public int invokeservice()
/*     */     throws MXException, RemoteException
/*     */   {
/*  78 */     String name = (String)(String)this.app.getWebClientSession().getCurrentEvent().getValue();
/*  79 */     if (!(this.interactionProcesser.invokeservice(this.parent.getMbo())))
/*     */     {
/*  81 */       return applychanges();
/*     */     }
/*  83 */     fireDataChangedEvent();
/*  84 */     fireStructureChangedEvent();
/*     */ 
/*  86 */     WebClientEvent event = new WebClientEvent("changetab", name.toLowerCase() + "_tabs_" + this.eventName.toLowerCase(), name.toLowerCase() + "_response_tab_" + this.eventName.toLowerCase(), this.clientSession);
/*  87 */     event.setSourceControl(this.app);
/*  88 */     this.clientSession.queueEvent(event);
/*  89 */     return 1;
/*     */   }









/*     */   public int applychanges()
/*     */     throws MXException, RemoteException
/*     */   {
/* 103 */     if (this.interactionProcesser.applychanges(getMboSet(), this.parent.getMbo()))
/*     */     {
/* 105 */       this.app.getAppBean().save();
/*     */     }
/*     */ 
/* 108 */     fireDataChangedEvent();
/* 109 */     this.app.getAppBean().fireDataChangedEvent(this.app.getAppBean());
/* 110 */     fireStructureChangedEvent();
/* 111 */     this.app.getAppBean().fireStructureChangedEvent(this.app.getAppBean());
/* 112 */     this.app.getResultsBean().recHasChanged();
/* 113 */     WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.clientSession.getCurrentPageId(), null, this.clientSession));
/*     */ 
/* 115 */     String[] params = { this.creatingEvent.getType() };
/* 116 */     this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "iface", "intsuccess", params);
/* 117 */     return 1;
/*     */   }









/*     */   public int silentmode()
/*     */     throws MXException, RemoteException
/*     */   {
/* 131 */     this.app.getAppBean().fireDataChangedEvent(this.app.getAppBean());
/* 132 */     this.app.getAppBean().fireStructureChangedEvent(this.app.getAppBean());
/*     */ 
/* 134 */     String[] params = { this.creatingEvent.getType() };
/* 135 */     this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "iface", "intsuccess", params);
/* 136 */     return 1;
/*     */   }
/*     */ }
