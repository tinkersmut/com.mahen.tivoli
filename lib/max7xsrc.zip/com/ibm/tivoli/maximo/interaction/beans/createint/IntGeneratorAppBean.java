/*     */ package com.ibm.tivoli.maximo.interaction.beans.createint;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.app.createint.IntGeneratorRemote;
/*     */ import com.ibm.tivoli.maximo.interaction.app.createint.WSIOTreeSetRemote;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.LinkedHashMap;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfoStatic;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.webclient.system.beans.AppBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.ControlInstance;
/*     */ import psdi.webclient.system.controller.LabelCache;
/*     */ import psdi.webclient.system.controller.LabelCacheMgr;
/*     */ import psdi.webclient.system.controller.PageInstance;
/*     */ import psdi.webclient.system.controller.PresentationLoader;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 





/*     */ public class IntGeneratorAppBean extends AppBean
/*     */ {
/*     */   private String[] allTabs;
/*     */   private int processTabOrder;
/*     */   boolean regenerate;
/*     */   boolean optimizeRequest;
/*     */   boolean optimizeResponse;
/*     */   boolean alreadyGenerated;
/*     */   boolean neverOptimizedRequest;
/*     */   boolean neverOptimizedResponse;
/*     */   private String lastLabel;
/*     */ 
/*     */   public IntGeneratorAppBean()
/*     */   {
/*  48 */     this.allTabs = new String[] { "generate_schema_tab", "policies_tab", "generate_viewreqxml_tab", "generate_viewrespxml_tab", "generate_present_tab", "generate_filter_request_tab", "generate_filter_response_tab", "map_filter_request_tab", "map_filter_response_tab", "generate_complete_tab" };









/*     */ 
/*  59 */     this.processTabOrder = 0;
/*  60 */     this.regenerate = false;
/*  61 */     this.optimizeRequest = true;
/*  62 */     this.optimizeResponse = true;
/*  63 */     this.alreadyGenerated = false;
/*  64 */     this.neverOptimizedRequest = true;
/*  65 */     this.neverOptimizedResponse = true;
/*  66 */     this.lastLabel = null;
/*     */   }





/*     */   public int nexttab()
/*     */     throws MXException, RemoteException
/*     */   {
/*  76 */     int nextTabOrder = 0;
/*     */     try
/*     */     {
/*  79 */       nextTabOrder = getNextTabOrder(this.processTabOrder);
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/*  83 */       this.clientSession.showMessageBox(e);
/*  84 */       WebClientEvent event = new WebClientEvent("changetab", "generate_tabs", this.allTabs[this.processTabOrder], this.clientSession);
/*  85 */       event.setSourceControl(this.app);
/*  86 */       this.clientSession.queueEvent(event);
/*  87 */       return 1;
/*     */     }
/*  89 */     fireDataChangedEvent();
/*  90 */     fireStructureChangedEvent();
/*  91 */     WebClientEvent event = new WebClientEvent("changetab", "generate_tabs", this.allTabs[nextTabOrder], this.clientSession);
/*  92 */     event.setSourceControl(this.app);
/*  93 */     this.clientSession.queueEvent(event);
/*  94 */     this.processTabOrder = nextTabOrder;
/*  95 */     return 1;
/*     */   }







/*     */   public int getNextTabOrder(int currentTabOrder)
/*     */     throws MXException, RemoteException
/*     */   {
/* 107 */     int nextTabOrder = 0;
/* 108 */     if (currentTabOrder == 0)
/*     */     {
/* 110 */       this.lastLabel = this.app.getCurrentPage().getControlInstance("generate_complete_grid0").getProperty("label");
/* 111 */       if (getMbo().isNull("interaction"))
/*     */       {
/* 113 */         String[] params = { getMboValueInfo("interaction").getTitle() };
/* 114 */         throw new MXApplicationException("iface", "missingurl", params);
/*     */       }
/* 116 */       if (getMbo().isNull("url"))
/*     */       {
/* 118 */         String[] params = { getMboValueInfo("url").getTitle() };
/* 119 */         throw new MXApplicationException("iface", "missingurl", params);
/*     */       }
/* 121 */       this.regenerate = ((IntGeneratorRemote)getMbo()).setPortAndOperation();
/* 122 */       if (this.regenerate)
/*     */       {
/* 124 */         this.neverOptimizedRequest = true;
/* 125 */         this.neverOptimizedResponse = true;
/*     */       }
/* 127 */       if ((!(this.alreadyGenerated)) || (this.regenerate))
/*     */       {
/* 129 */         ((IntGeneratorRemote)getMbo()).viewSchema();
/* 130 */         fireDataChangedEvent();
/* 131 */         this.alreadyGenerated = true;
/*     */       }
/* 133 */       ((IntGeneratorRemote)getMbo()).logStep(currentTabOrder, this.app.getCurrentPage().getControlInstance("generate_schema_grid0").getProperty("label"));
/* 134 */       nextTabOrder = 2;
/*     */     }
/* 136 */     else if (currentTabOrder == 2)
/*     */     {
/* 138 */       if ((this.neverOptimizedRequest) || (this.optimizeRequest))
/*     */       {
/* 140 */         ((IntGeneratorRemote)getMbo()).viewOptimizedSchemaRequest(true);
/* 141 */         ((IntGeneratorRemote)getMbo()).setRequestArtifacts();
/* 142 */         fireDataChangedEvent();
/* 143 */         fireStructureChangedEvent();
/* 144 */         this.neverOptimizedRequest = false;
/* 145 */         this.optimizeRequest = false;
/*     */       }
/* 147 */       ((IntGeneratorRemote)getMbo()).logWSIOStep(true, this.app.getCurrentPage().getControlInstance("generate_viewreqxml_grid1_1_1_grid0").getProperty("label"));
/* 148 */       if (getMbo().getBoolean("processresponse"))
/*     */       {
/* 150 */         nextTabOrder = 3;
/*     */       }
/*     */       else
/*     */       {
/* 154 */         nextTabOrder = 4;
/*     */       }
/*     */     }
/* 157 */     else if (currentTabOrder == 3)
/*     */     {
/* 159 */       if ((this.neverOptimizedResponse) || (this.optimizeResponse))
/*     */       {
/* 161 */         ((IntGeneratorRemote)getMbo()).viewOptimizedSchemaResponse(true);
/* 162 */         ((IntGeneratorRemote)getMbo()).setResponseArtifacts();
/* 163 */         fireDataChangedEvent();
/* 164 */         fireStructureChangedEvent();
/* 165 */         this.neverOptimizedResponse = false;
/* 166 */         this.optimizeResponse = false;
/*     */       }
/* 168 */       ((IntGeneratorRemote)getMbo()).logWSIOStep(false, this.app.getCurrentPage().getControlInstance("generate_viewrespxml_grid1_1_1_grid0").getProperty("label"));
/* 169 */       nextTabOrder = 4;
/*     */     }
/* 171 */     else if (currentTabOrder == 4)
/*     */     {
/* 173 */       if (getMbo().isNull("appname"))
/*     */       {
/* 175 */         String[] params = { getMboValueInfo("appname").getTitle() };
/* 176 */         throw new MXApplicationException("iface", "missingurl", params);
/*     */       }
/* 178 */       if (getMbo().isNull("appobject"))
/*     */       {
/* 180 */         String[] params = { getMboValueInfo("appobject").getTitle() };
/* 181 */         throw new MXApplicationException("iface", "missingurl", params);
/*     */       }
/* 183 */       if (getMbo().isNull("intmode"))
/*     */       {
/* 185 */         String[] params = { getMboValueInfo("intmode").getTitle() };
/* 186 */         throw new MXApplicationException("iface", "missingurl", params);
/*     */       }
/* 188 */       if (getMbo().isNull("optdescription"))
/*     */       {
/* 190 */         String[] params = { getMboValueInfo("optdescription").getTitle() };
/* 191 */         throw new MXApplicationException("iface", "missingurl", params);
/*     */       }
/*     */ 
/* 194 */       ((IntGeneratorRemote)getMbo()).logStep(currentTabOrder, this.app.getCurrentPage().getControlInstance("generate_present_grid0").getProperty("label"));
/*     */ 
/* 196 */       String intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", getMbo().getString("intmode"));
/*     */ 
/* 198 */       if ((intMode.equals("SHOWREQRESP")) || (intMode.equals("SHOWREQONLY")))
/*     */       {
/* 200 */         nextTabOrder = 5;
/*     */       }
/* 202 */       else if (intMode.equals("SHOWRESPONLY"))
/*     */       {
/* 204 */         nextTabOrder = 6;
/*     */       }
/*     */       else
/*     */       {
/* 208 */         nextTabOrder = 7;
/*     */       }
/*     */     }
/* 211 */     else if (currentTabOrder == 5)
/*     */     {
/* 213 */       ((IntGeneratorRemote)getMbo()).logUISelectionStep(true, this.app.getCurrentPage().getControlInstance("generate_filter_request_grid0").getProperty("label"));
/*     */ 
/* 215 */       String intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", getMbo().getString("intmode"));
/*     */ 
/* 217 */       if (intMode.equals("SHOWREQRESP"))
/*     */       {
/* 219 */         nextTabOrder = 6;
/*     */       }
/*     */       else
/*     */       {
/* 223 */         nextTabOrder = 7;
/*     */       }
/*     */     }
/* 226 */     else if (currentTabOrder == 6)
/*     */     {
/* 228 */       ((IntGeneratorRemote)getMbo()).logUISelectionStep(false, this.app.getCurrentPage().getControlInstance("generate_filter_response_grid0").getProperty("label"));
/*     */ 
/* 230 */       nextTabOrder = 7;
/*     */     }
/* 232 */     else if (currentTabOrder == 7)
/*     */     {
/* 234 */       ((IntGeneratorRemote)getMbo()).validateMappings(false);
/*     */ 
/* 236 */       ((IntGeneratorRemote)getMbo()).logMappingStep(true, this.app.getCurrentPage().getControlInstance("map_filter_request_grid0").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_request_grid2_table_tablebody_1").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_request_grid2_table_tablebody_5").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_request_grid2_table_tablebody_6").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_request_grid3_tablebody_2").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_request_grid3_tablebody_3").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_request_grid3_tablebody_6").getProperty("label"));







/*     */ 
/* 245 */       if (getMbo().getBoolean("applyresponse"))
/*     */       {
/* 247 */         nextTabOrder = 8;
/*     */       }
/*     */       else
/*     */       {
/* 251 */         nextTabOrder = 9;
/*     */       }
/*     */     }
/* 254 */     else if (currentTabOrder == 8)
/*     */     {
/* 256 */       String param = ((IntGeneratorRemote)getMbo()).validateMappings(true);
/* 257 */       if (param != null)
/*     */       {
/* 259 */         String[] params = { param };
/* 260 */         this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "iface", "missingkeyvalue", params);
/*     */       }
/* 262 */       ((IntGeneratorRemote)getMbo()).logMappingStep(false, this.app.getCurrentPage().getControlInstance("map_filter_response_grid0").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_response_grid2_table1_tablebody_1").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_response_grid2_table1_tablebody_5").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_response_grid2_table1_tablebody_6").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_response_grid2_tablebody_2").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_response_grid2_tablebody_5").getProperty("label"), this.app.getCurrentPage().getControlInstance("map_filter_response_grid2_tablebody_4").getProperty("label"));







/*     */ 
/* 271 */       nextTabOrder = 9;
/*     */     }
/* 273 */     return nextTabOrder;
/*     */   }





/*     */   public int prevtab()
/*     */     throws MXException, RemoteException
/*     */   {
/* 283 */     int prevTabOrder = getPreviousTabOrder(this.processTabOrder);
/* 284 */     fireDataChangedEvent();
/* 285 */     fireStructureChangedEvent();
/* 286 */     WebClientEvent event = new WebClientEvent("changetab", "generate_tabs", this.allTabs[prevTabOrder], this.clientSession);
/* 287 */     event.setSourceControl(this.app);
/* 288 */     this.clientSession.queueEvent(event);
/* 289 */     this.processTabOrder = prevTabOrder;
/* 290 */     return 1;
/*     */   }







/*     */   public int getPreviousTabOrder(int currentTabOrder)
/*     */     throws MXException, RemoteException
/*     */   {
/* 302 */     int prevTabOrder = 0;
/* 303 */     if (currentTabOrder == 2)
/*     */     {
/* 305 */       this.optimizeRequest = false;
/* 306 */       prevTabOrder = 0;
/*     */     }
/* 308 */     else if (currentTabOrder == 3)
/*     */     {
/* 310 */       this.optimizeResponse = false;
/* 311 */       prevTabOrder = 2;
/*     */     }
/* 313 */     else if (currentTabOrder == 4)
/*     */     {
/* 315 */       if (getMbo().getBoolean("processresponse"))
/*     */       {
/* 317 */         prevTabOrder = 3;
/*     */       }
/*     */       else
/*     */       {
/* 321 */         prevTabOrder = 2;
/*     */       }
/*     */     }
/* 324 */     else if (currentTabOrder == 5)
/*     */     {
/* 326 */       prevTabOrder = 4;
/*     */     }
/* 328 */     else if (currentTabOrder == 6)
/*     */     {
/* 330 */       String intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", getMbo().getString("intmode"));
/*     */ 
/* 332 */       if (intMode.equals("SHOWREQRESP"))
/*     */       {
/* 334 */         prevTabOrder = 5;
/*     */       }
/* 336 */       else if (intMode.equals("SHOWRESPONLY"))
/*     */       {
/* 338 */         prevTabOrder = 4;
/*     */       }
/*     */     }
/* 341 */     else if (currentTabOrder == 7)
/*     */     {
/* 343 */       String intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", getMbo().getString("intmode"));
/*     */ 
/* 345 */       if ((intMode.equals("SHOWREQRESP")) || (intMode.equals("SHOWRESPONLY")))
/*     */       {
/* 347 */         prevTabOrder = 6;
/*     */       }
/* 349 */       else if (intMode.equals("SHOWREQONLY"))
/*     */       {
/* 351 */         prevTabOrder = 5;
/*     */       }
/* 353 */       else if (intMode.equals("SILENT"))
/*     */       {
/* 355 */         prevTabOrder = 4;
/*     */       }
/*     */     }
/* 358 */     else if (currentTabOrder == 8)
/*     */     {
/* 360 */       prevTabOrder = 7;
/*     */     }
/* 362 */     else if (currentTabOrder == 9)
/*     */     {
/* 364 */       if (getMbo().getBoolean("applyresponse"))
/*     */       {
/* 366 */         prevTabOrder = 8;
/*     */       }
/*     */       else
/*     */       {
/* 370 */         prevTabOrder = 7;
/*     */       }
/*     */     }
/* 373 */     return prevTabOrder;
/*     */   }





/*     */   public int complete()
/*     */     throws MXException, RemoteException
/*     */   {
/* 383 */     if (!(this.app.getWebClientSession().hasLongOpStarted()))
/*     */     {
/* 385 */       WebClientEvent event = this.app.getWebClientSession().getCurrentEvent();
/* 386 */       int row = getRowIndexFromEvent(event);
/* 387 */       setCurrentRow(row);
/*     */     }
/* 389 */     if (this.app.getWebClientSession().runLongOp(this, "complete"))
/*     */     {
/*     */       try
/*     */       {
/* 393 */         PresentationLoader present = new PresentationLoader();
/*     */ 
/* 395 */         LabelCache appLabelCache = LabelCacheMgr.getAppLabelCache(getMbo().getString("appname"), this.app.getWebClientSession());
/* 396 */         String xml = present.exportXML(this.app.getWebClientSession(), getMbo().getString("appname"));
/*     */ 
/* 398 */         ByteArrayOutputStream bo = new ByteArrayOutputStream();
/* 399 */         PrintWriter writer = new PrintWriter(new OutputStreamWriter(bo, "UTF-8"));
/* 400 */         writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*     */ 
/* 402 */         present.writeFormattedXML(writer, xml, appLabelCache);
/* 403 */         writer.flush();
/* 404 */         writer.close();
/*     */ 
/* 406 */         String presentationXML = ((IntGeneratorRemote)getMbo()).createIntegrationArtifacts(this.lastLabel, bo.toByteArray());
/* 407 */         if (presentationXML != null)
/*     */         {
/* 409 */           importXML(presentationXML);
/*     */         }
/*     */       }
/*     */       catch (MXException e)
/*     */       {
/* 414 */         e.printStackTrace();
/* 415 */         this.app.put("errored", "1");
/* 416 */         this.app.getWebClientSession().showMessageBox(e);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 420 */         e.printStackTrace();
/* 421 */         this.app.put("errored", "1");
/* 422 */         String[] params = new String[0];
/* 423 */         this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "system", "major", params);
/*     */       }
/*     */     }
/* 426 */     if (this.app.getWebClientSession().hasLongOpCompleted())
/*     */     {
/* 428 */       if ((this.app.get("errored") != null) && (this.app.get("errored").equals("1")))
/*     */       {
/* 430 */         return 1;
/*     */       }
/* 432 */       WebClientRuntime.sendEvent(new WebClientEvent("intchoice", this.app.getCurrentPageId(), null, this.clientSession));

/*     */     }
/*     */ 
/* 436 */     return 1;
/*     */   }






/*     */   public int manageint()
/*     */     throws MXException, RemoteException
/*     */   {
/* 447 */     WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/* 448 */     MboSetRemote interSet = getMbo().getMboSet("MAXINTERACTION");
/* 449 */     long uid = interSet.getMbo(0).getUniqueIDValue();
/* 450 */     this.clientSession.getCurrentApp().put("forcereload", "true");
/* 451 */     this.clientSession.queueEvent(new WebClientEvent("changeapp", this.app.getId(), "manageint", null, "changetab", "main", uid, this.clientSession));
/*     */ 
/* 453 */     return 1;
/*     */   }

/*     */   public int optimizereq() throws MXException, RemoteException {
/* 457 */     if ((this.neverOptimizedRequest) || (this.optimizeRequest))
/*     */     {
/* 459 */       ((IntGeneratorRemote)getMbo()).viewOptimizedSchemaRequest(true);
/* 460 */       ((IntGeneratorRemote)getMbo()).setRequestArtifacts();
/* 461 */       fireDataChangedEvent();
/* 462 */       fireStructureChangedEvent();
/* 463 */       this.neverOptimizedRequest = false;
/* 464 */       this.optimizeRequest = false;
/*     */     }
/* 466 */     return 1;
/*     */   }

/*     */   public int optimizeresp() throws MXException, RemoteException {
/* 470 */     if ((this.neverOptimizedResponse) || (this.optimizeResponse))
/*     */     {
/* 472 */       ((IntGeneratorRemote)getMbo()).viewOptimizedSchemaResponse(true);
/* 473 */       ((IntGeneratorRemote)getMbo()).setResponseArtifacts();
/* 474 */       fireDataChangedEvent();
/* 475 */       fireStructureChangedEvent();
/* 476 */       this.neverOptimizedResponse = false;
/* 477 */       this.optimizeResponse = false;
/*     */     }
/* 479 */     return 1;
/*     */   }

/*     */   public int deletenodereq() throws MXException, RemoteException {
/* 483 */     return deletenode("viewreqwsiotree", true);
/*     */   }

/*     */   public int deletenoderesp() throws MXException, RemoteException {
/* 487 */     return deletenode("viewrespwsiotree", false);
/*     */   }

/*     */   public int deletenode(String id, boolean isRequest) throws MXException, RemoteException {
/* 491 */     WSIOTreeBean treeBean = (WSIOTreeBean)this.clientSession.getDataBean(id);
/* 492 */     MboRemote wsioMbo = ((WSIOTreeSetRemote)treeBean.getMboSet()).findMbo(treeBean.getMbo(), treeBean.uniqueIdSelected);
/* 493 */     if ((wsioMbo != null) && (wsioMbo.getBoolean("required")))
/*     */     {
/* 495 */       throw new MXApplicationException("iface", "requiredinschema");
/*     */     }
/* 497 */     if ((wsioMbo != null) && (!(wsioMbo.getBoolean("hasparent"))))
/*     */     {
/* 499 */       throw new MXApplicationException("iface", "top_level_delete");
/*     */     }
/* 501 */     LinkedHashMap removeMap = ((IntGeneratorRemote)getMbo()).addRemoveID(treeBean.uniqueIdSelected);
/* 502 */     return processnode(treeBean, removeMap, isRequest);
/*     */   }

/*     */   public int undeletenodereq() throws MXException, RemoteException {
/* 506 */     WSIOTreeBean treeBean = (WSIOTreeBean)this.clientSession.getDataBean("viewreqwsiotree");
/* 507 */     LinkedHashMap removeMap = ((IntGeneratorRemote)getMbo()).undoRemove(treeBean.uniqueIdSelected);
/* 508 */     return processnode((WSIOTreeBean)this.clientSession.getDataBean("viewreqwsiotree"), removeMap, true);
/*     */   }

/*     */   public int undeletenoderesp() throws MXException, RemoteException {
/* 512 */     WSIOTreeBean treeBean = (WSIOTreeBean)this.clientSession.getDataBean("viewrespwsiotree");
/* 513 */     LinkedHashMap removeMap = ((IntGeneratorRemote)getMbo()).undoRemove(treeBean.uniqueIdSelected);
/* 514 */     return processnode((WSIOTreeBean)this.clientSession.getDataBean("viewrespwsiotree"), removeMap, false);
/*     */   }

/*     */   public int undeleteallreq() throws MXException, RemoteException {
/* 518 */     LinkedHashMap removeMap = ((IntGeneratorRemote)getMbo()).undoAllRemove();
/* 519 */     return processnode((WSIOTreeBean)this.clientSession.getDataBean("viewreqwsiotree"), removeMap, true);
/*     */   }

/*     */   public int undeleteallresp() throws MXException, RemoteException {
/* 523 */     LinkedHashMap removeMap = ((IntGeneratorRemote)getMbo()).undoAllRemove();
/* 524 */     return processnode((WSIOTreeBean)this.clientSession.getDataBean("viewrespwsiotree"), removeMap, false);
/*     */   }

/*     */   public int processnode(WSIOTreeBean treeBean, LinkedHashMap<String, String> removeMap, boolean isRequest) throws MXException, RemoteException {
/* 528 */     ((IntGeneratorRemote)getMbo()).processnode((WSIOTreeSetRemote)treeBean.getMboSet(), removeMap, isRequest);
/* 529 */     treeBean.markTreesForRefresh("");
/* 530 */     if (isRequest)
/*     */     {
/* 532 */       this.optimizeRequest = true;
/*     */     }
/*     */     else
/*     */     {
/* 536 */       this.optimizeResponse = true;
/*     */     }
/* 538 */     return 1;
/*     */   }

/*     */   public boolean removeMbo(MboRemote currentMbo, String removeID) throws MXException, RemoteException {
/* 542 */     String mboID = currentMbo.getString("wsiotreeid");
/* 543 */     if (removeID.equals(mboID))
/*     */     {
/* 545 */       currentMbo.getThisMboSet().deleteAndRemove(currentMbo);
/* 546 */       return true;
/*     */     }
/* 548 */     MboSetRemote child = currentMbo.getMboSet("TREENODE");
/* 549 */     for (int j = 0; j < child.getSize(); ++j)
/*     */     {
/* 551 */       MboRemote childMbo = child.getMbo(j);
/* 552 */       if ((childMbo != null) && 

/* 554 */         (removeMbo(childMbo, removeID)))
/*     */       {
/* 556 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 560 */     return false;
/*     */   }

/*     */   public void importXML(String presentationXML) throws MXException, RemoteException {
/* 564 */     PresentationLoader loader = new PresentationLoader();
/*     */     try
/*     */     {
/* 567 */       loader.importApp(this.clientSession, presentationXML);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 571 */       String[] params = { loader.getAppID() };
/* 572 */       this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "designer", "cannotparsefile", params);
/*     */     }
/*     */   }







/*     */   public int cancelchanges()
/*     */     throws MXException, RemoteException
/*     */   {
/* 585 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/* 586 */     int msgRet = event.getMessageReturn();
/*     */ 
/* 588 */     if (msgRet < 0)
/*     */     {
/* 590 */       throw new MXApplicationException("iface", "cancelchanges");
/*     */     }
/* 592 */     if ((msgRet == 8) || (msgRet == 2))

/*     */     {
/* 595 */       getMboSet().rollback();
/* 596 */       this.clientSession.getCurrentApp().put("forcereload", "true");
/* 597 */       this.clientSession.queueEvent(new WebClientEvent("changeapp", this.app.getId(), "startcntr", this.clientSession));
/*     */     } else {
/* 599 */       if (msgRet == 16) {
/* 600 */         return 1;
/*     */       }
/* 602 */       return 1;
/*     */     }
/*     */ 
/* 605 */     ((IntGeneratorRemote)getMbo()).logCancel();
/* 606 */     return 1;
/*     */   }
/*     */ }
