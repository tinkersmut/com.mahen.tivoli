/*    */ package com.ibm.tivoli.maximo.interaction.beans.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 

























/*    */ public class AttributesBean extends DataBean
/*    */ {
/*    */   public int instantdelete()
/*    */     throws MXException
/*    */   {
/* 40 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/* 41 */     int msgRet = event.getMessageReturn();
/* 42 */     if (msgRet < 0)
/*    */     {
/* 44 */       throw new MXApplicationException("system", "deletecontinue");
/*    */     }
/*    */ 
/* 47 */     if (msgRet == 8)
/*    */     {
/* 49 */       int row = getRowIndexFromEvent(event);

/*    */       try
/*    */       {
/* 53 */         deleteAndRemove(row);
/*    */       }
/*    */       catch (RemoteException e)
/*    */       {
/* 57 */         handleRemoteException(e);
/*    */       }
/*    */     }
/* 60 */     return 1;
/*    */   }
/*    */ }
