/*     */ package com.ibm.tivoli.maximo.interaction.beans.manageint;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.app.manageint.MaxInteractionRemote;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.webclient.system.beans.AppBean;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.beans.ResultsBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.LabelCache;
/*     */ import psdi.webclient.system.controller.LabelCacheMgr;
/*     */ import psdi.webclient.system.controller.PresentationLoader;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 























/*     */ public class MaxInteractionAppBean extends AppBean
/*     */ {
/*     */   public int DELETE()
/*     */     throws MXException, RemoteException
/*     */   {
/*  50 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/*  51 */     int msgRet = event.getMessageReturn();
/*  52 */     if ((msgRet < 0) && (!(this.clientSession.hasLongOpStarted())))
/*     */     {
/*  54 */       checkESigAuthenticated("DELETE");
/*  55 */       throw new MXApplicationException("system", "deletecontinue");
/*     */     }
/*  57 */     if (((msgRet == 8) && (this.clientSession.runLongOp(this, "DELETE"))) || ((msgRet != 8) && (this.clientSession.hasLongOpStarted()) && (!(this.clientSession.hasLongOpCompleted()))))


/*     */     {
/*  61 */       deleteInteraction(getMbo());
/*     */     }
/*  63 */     if (this.app.getWebClientSession().hasLongOpCompleted())

/*     */     {
/*  66 */       getMboSet().save();
/*  67 */       this.app.getResultsBean().save();
/*  68 */       this.app.getResultsBean().refreshTable();
/*  69 */       fireStructureChangedEvent();
/*  70 */       fireDataChangedEvent();
/*  71 */       WebClientEvent event1 = new WebClientEvent("changetab", "maintabs", "results", this.clientSession);
/*  72 */       event1.setSourceControl(this.app);
/*  73 */       this.clientSession.queueEvent(event1);
/*  74 */       return 1;
/*     */     }
/*  76 */     return 1;
/*     */   }






































/*     */   public void deleteInteraction(MboRemote mbo)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 121 */       if (!(getMbo().isNull("dialogid")))
/*     */       {
/* 123 */         PresentationLoader present = new PresentationLoader();
/*     */ 
/* 125 */         LabelCache appLabelCache = LabelCacheMgr.getAppLabelCache(getMbo().getString("appname"), this.app.getWebClientSession());
/* 126 */         String xml = present.exportXML(this.app.getWebClientSession(), getMbo().getString("appname"));
/*     */ 
/* 128 */         ByteArrayOutputStream bo = new ByteArrayOutputStream();
/* 129 */         PrintWriter writer = new PrintWriter(new OutputStreamWriter(bo, "UTF-8"));
/* 130 */         writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*     */ 
/* 132 */         present.writeFormattedXML(writer, xml, appLabelCache);
/* 133 */         writer.flush();
/* 134 */         writer.close();
/*     */ 
/* 136 */         String presentationXML = ((MaxInteractionRemote)mbo).deleteInteraction(bo.toByteArray());
/* 137 */         importXML(presentationXML);
/*     */       }
/*     */       else
/*     */       {
/* 141 */         ((MaxInteractionRemote)mbo).deleteInteraction(null);
/*     */       }
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 146 */       e.printStackTrace();
/* 147 */       this.app.put("errored", "1");
/* 148 */       this.app.getWebClientSession().showMessageBox(e);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 152 */       e.printStackTrace();
/* 153 */       this.app.put("errored", "1");
/* 154 */       String[] params = new String[0];
/* 155 */       this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "system", "major", params);
/*     */     }
/*     */   }







/*     */   public void importXML(String presentationXML)
/*     */     throws MXException, RemoteException
/*     */   {
/* 168 */     PresentationLoader loader = new PresentationLoader();
/*     */     try
/*     */     {
/* 171 */       loader.importApp(this.clientSession, presentationXML);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 175 */       String[] params = { loader.getAppID() };
/* 176 */       this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "designer", "cannotparsefile", params);
/*     */     }
/*     */   }






/*     */   public int ACTIVATE()
/*     */     throws MXException, RemoteException
/*     */   {
/* 188 */     MboRemote appMbo = this.app.getAppBean().getMbo();
/* 189 */     if (appMbo.getBoolean("active"))
/*     */     {
/* 191 */       appMbo.setValue("active", false);
/* 192 */       String[] params = new String[0];
/* 193 */       this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "iface", "intdeactive", params);
/*     */     }
/*     */     else
/*     */     {
/* 197 */       if (!(((MaxInteractionRemote)appMbo).validateInteraction()))
/*     */       {
/* 199 */         throw new MXApplicationException("iface", "intnotvalidated");
/*     */       }
/* 201 */       appMbo.setValue("active", true);
/* 202 */       String[] params = new String[0];
/* 203 */       this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "iface", "intactive", params);
/*     */     }
/* 205 */     save();
/* 206 */     return 1;
/*     */   }






/*     */   public int EXPORT()
/*     */     throws MXException, RemoteException
/*     */   {
/* 217 */     if (this.app.getWebClientSession().hasLongOpCompleted())
/*     */     {
/* 219 */       return 1;
/*     */     }
/* 221 */     checkESigAuthenticated("EXPORT");
/* 222 */     if (this.app.getWebClientSession().runLongOp(this, "EXPORT"))
/*     */     {
/* 224 */       ((MaxInteractionRemote)getMbo()).exportInteraction();
/*     */     }
/* 226 */     return 1;
/*     */   }
/*     */ }
