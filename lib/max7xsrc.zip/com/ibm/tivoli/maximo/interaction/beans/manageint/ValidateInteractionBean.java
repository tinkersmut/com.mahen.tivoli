/*    */ package com.ibm.tivoli.maximo.interaction.beans.manageint;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.interaction.app.manageint.MaxInteraction;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 
























/*    */ public class ValidateInteractionBean extends DataBean
/*    */ {
/*    */   protected MboSetRemote getMboSetRemote()
/*    */     throws MXException, RemoteException
/*    */   {
/* 40 */     return this.parent.getMboSet();
/*    */   }


/*    */   public int validint()
/*    */     throws MXException, RemoteException
/*    */   {
/* 47 */     checkESigAuthenticated("VALIDINT");
/*    */ 
/* 49 */     ((MaxInteraction)getMbo()).validateInteraction();
/*    */ 
/* 51 */     getMbo().getString("status");
/* 52 */     fireDataChangedEvent();
/* 53 */     this.clientSession.queueEvent(this.clientSession.getCurrentEvent());
/*    */ 
/* 55 */     return 1;
/*    */   }
/*    */ }
