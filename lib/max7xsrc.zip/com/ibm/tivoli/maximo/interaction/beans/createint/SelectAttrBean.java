/*    */ package com.ibm.tivoli.maximo.interaction.beans.createint;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.interaction.app.createint.IntGeneratorRemote;
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.Vector;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.controller.AppInstance;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.runtime.WebClientRuntime;
/*    */ 













/*    */ public class SelectAttrBean extends DataBean
/*    */ {
/*    */   MboRemote parentMbo;
/*    */ 
/*    */   public SelectAttrBean()
/*    */   {
/* 33 */     this.parentMbo = null;
/*    */   }




/*    */   protected MboSetRemote getMboSetRemote()
/*    */     throws MXException, RemoteException
/*    */   {
/* 42 */     this.parentMbo = this.parent.getMboSet().getOwner();
/* 43 */     return ((IntGeneratorRemote)this.parentMbo).fillAttributes(this.parentMbo, null, true);
/*    */   }

/*    */   public int selectattr() throws MXException, RemoteException {
/* 47 */     MboSetRemote targetSet = null;
/* 48 */     Vector select = this.parentMbo.getMboSet("SELECTATTR").getSelection();
/* 49 */     if (select.isEmpty())
/*    */     {
/* 51 */       return 1;
/*    */     }
/* 53 */     if (this.parentMbo.getString("recordtype").equals("REQUESTOBJECT"))
/*    */     {
/* 55 */       targetSet = this.parentMbo.getMboSet("REQUESTMAPPING");
/*    */     }
/*    */     else
/*    */     {
/* 59 */       targetSet = this.parentMbo.getMboSet("RESPONSEMAPPING");
/*    */     }
/* 61 */     MboRemote sel = null;
/* 62 */     for (int k = 0; k < select.size(); ++k)
/*    */     {
/* 64 */       sel = (MboRemote)select.get(k);
/* 65 */       if (sel == null) {
/*    */         break;
/*    */       }
/*    */ 
/* 69 */       MboRemote target = targetSet.addAtEnd();
/* 70 */       target.setValue("attributename", sel.getString("attributename"));
/* 71 */       target.setValue("hierarchypath", sel.getString("hierarchypath"));
/*    */     }
/* 73 */     this.parent.refreshTable();
/* 74 */     WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/* 75 */     return 1;
/*    */   }
/*    */ }
