/*    */ package com.ibm.tivoli.maximo.interaction.beans.createint;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.Vector;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.MXSession;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 




















/*    */ public class IntPolicyBean extends DataBean
/*    */ {
/*    */   protected MboSetRemote getMboSetRemote()
/*    */     throws MXException, RemoteException
/*    */   {
/* 40 */     MboSetRemote policySet = null;
/* 41 */     MXSession s = getMXSession();
/* 42 */     if (s == null)
/*    */     {
/* 44 */       return null;
/*    */     }
/* 46 */     Object valueObject = this.clientSession.getCurrentEvent().getValue();
/* 47 */     System.out.println("Value is " + valueObject);
/* 48 */     if (valueObject == null)
/*    */     {
/* 50 */       policySet = s.getMboSet("MAXINTPOLICY");
/* 51 */       policySet.setQbe("interaction", "GLOBAL");
/* 52 */       policySet.setQbeExactMatch(true);
/* 53 */       policySet.setOrderBy("policytype, policyname");
/* 54 */       policySet.reset();
/* 55 */       return policySet;
/*    */     }
/* 57 */     return this.parent.getMbo().getMboSet("MAXINTPOLICY");
/*    */   }

/*    */   public int restoredefaults() throws MXException, RemoteException {
/* 61 */     Vector selected = getMboSet().getSelection();
/* 62 */     if (selected.size() == 0)
/*    */     {
/* 64 */       throw new MXApplicationException("jspmessages", "table_noselectedrows");
/*    */     }
/*    */ 
/* 67 */     for (int i = 0; i < selected.size(); ++i)
/*    */     {
/* 69 */       MboRemote policy = (MboRemote)selected.get(i);
/* 70 */       MboSetRemote policyParamSet = policy.getMboSet("MAXINTPOLICYPARAM");
/* 71 */       MboRemote policyParam = null;
/* 72 */       for (int j = 0; ; ++j)
/*    */       {
/* 74 */         policyParam = policyParamSet.getMbo(j);
/* 75 */         if (policyParam == null) {
/*    */           break;
/*    */         }
/*    */ 
/* 79 */         policyParam.setValue("value", policyParam.getString("defaultvalue"), 11L);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 84 */     fireDataChangedEvent();
/* 85 */     fireStructureChangedEvent();
/* 86 */     return 1;
/*    */   }
/*    */ }
