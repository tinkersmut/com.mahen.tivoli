/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 

























/*    */ public class FldURL extends MboValueAdapter
/*    */ {
/*    */   public FldURL(MboValue mbv)
/*    */     throws MXException
/*    */   {
/* 39 */     super(mbv);
/*    */   }





/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 49 */     MboValue value = getMboValue();
/* 50 */     MboRemote thisMbo = value.getMbo();
/* 51 */     ((IntGenerator)thisMbo).parseWSDL();
/*    */   }
/*    */ }
