/*     */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Iterator;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.RelationInfo;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 


















/*     */ public class FldBindRelation extends MAXTableDomain
/*     */ {
/*     */   public FldBindRelation(MboValue mbv)
/*     */     throws MXException
/*     */   {
/*  40 */     super(mbv);
/*  41 */     setRelationship("INTOBJRELATION", "");
/*  42 */     setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "relation" });
/*     */   }






/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  53 */     MboValue value = getMboValue();
/*  54 */     MboRemote thisMbo = value.getMbo();
/*  55 */     MboRemote owner = thisMbo.getOwner();
/*  56 */     if (!(owner.getName().equals("MAXINTERACTION")))
/*     */     {
/*  58 */       return;
/*     */     }
/*  60 */     ((MaxInteraction)owner).checkMappingObject(thisMbo, "MAXINTMAPPINGDETAIL");
/*  61 */     if (value.isNull())
/*     */     {
/*  63 */       thisMbo.setValueNull("mapobject", 11L);
/*  64 */       thisMbo.setFieldFlag("useparent", 7L, false);
/*     */     }
/*     */     else
/*     */     {
/*  68 */       String parentName = ((MaxInteraction)owner).getParentTbName(thisMbo);
/*  69 */       if (parentName == null)
/*     */       {
/*  71 */         throw new MXApplicationException("iface", "missingparentobject");
/*     */       }
/*  73 */       System.out.println("Parent name " + parentName);
/*  74 */       MboServerInterface service = getMboValue().getMbo().getMboServer();
/*  75 */       MboSetRemote parentSet = service.getMboSet(parentName, thisMbo.getUserInfo());
/*  76 */       RelationInfo info = parentSet.getMboSetInfo().getRelationInfo(value.getString());
/*  77 */       System.out.println("Info is " + info);
/*  78 */       if (info == null)
/*     */       {
/*  80 */         String[] params = { value.getString(), thisMbo.getString("mapobject") };
/*  81 */         throw new MXApplicationException("system", "norelationship", params);
/*     */       }
/*  83 */       thisMbo.setValue("mapobject", info.getDest(), 11L);
/*  84 */       thisMbo.setFieldFlag("useparent", 7L, true);
/*     */     }
/*  86 */     MboSetRemote attrSet = thisMbo.getMboSet("MAXINTMAPPINGDETAIL");
/*  87 */     MboRemote attr = null;
/*  88 */     for (int k = 0; ; ++k)
/*     */     {
/*  90 */       attr = attrSet.getMbo(k);
/*  91 */       System.out.println("In validate attr " + attr);
/*  92 */       if (attr == null) {
/*     */         break;
/*     */       }
/*     */ 
/*  96 */       if (value.isNull())
/*     */       {
/*  98 */         attr.setValueNull("objectname", 11L);
/*     */       }
/*     */       else
/*     */       {
/* 102 */         attr.setValue("objectname", thisMbo.getString("mapobject"), 11L);
/*     */       }
/*     */     }
/* 105 */     System.out.println("After validate attr ");
/*     */   }






/*     */   public MboSetRemote getList()
/*     */     throws MXException, RemoteException
/*     */   {
/* 116 */     MboValue value = getMboValue();
/* 117 */     MboRemote thisMbo = value.getMbo();
/* 118 */     MboServerInterface service = getMboValue().getMbo().getMboServer();
/* 119 */     MboSetRemote relationSet = service.getMboSet("INTOBJRELATION", getMboValue().getMbo().getUserInfo());
/*     */ 
/* 121 */     String parentName = ((MaxInteraction)thisMbo.getOwner()).getParentTbName(thisMbo);
/* 122 */     if (parentName == null)
/*     */     {
/* 124 */       throw new MXApplicationException("iface", "missingparentobject");
/*     */     }
/* 126 */     MboSetRemote parentSet = service.getMboSet(parentName, thisMbo.getUserInfo());
/* 127 */     Iterator itr = parentSet.getMboSetInfo().getRelationsInfo();
/* 128 */     while (itr.hasNext())
/*     */     {
/* 130 */       RelationInfo relInfo = (RelationInfo)itr.next();
/* 131 */       MboRemote relationMbo = relationSet.add();
/* 132 */       relationMbo.setValue("relation", relInfo.getName());
/* 133 */       relationMbo.setValue("relsqlwhere", relInfo.getSqlExpr());
/*     */     }
/* 135 */     return relationSet;
/*     */   }
/*     */ }
