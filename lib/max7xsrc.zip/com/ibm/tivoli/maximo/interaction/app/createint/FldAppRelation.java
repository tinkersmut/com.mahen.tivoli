/*     */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Iterator;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.RelationInfo;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 



















/*     */ public class FldAppRelation extends MAXTableDomain
/*     */ {
/*     */   public FldAppRelation(MboValue mbv)
/*     */     throws MXException
/*     */   {
/*  41 */     super(mbv);
/*  42 */     setRelationship("INTOBJRELATION", "");
/*  43 */     setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "relation" });
/*     */   }







/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  55 */     String colsRelation = null;
/*  56 */     MboValue value = getMboValue();
/*  57 */     MboRemote thisMbo = value.getMbo();
/*  58 */     if (thisMbo.getString("recordtype").equals("REQUESTOBJECT"))
/*     */     {
/*  60 */       colsRelation = "REQUESTMAPPING";
/*     */     }
/*  62 */     else if (thisMbo.getString("recordtype").equals("RESPONSEOBJECT"))
/*     */     {
/*  64 */       colsRelation = "RESPONSEMAPPING";
/*     */     }
/*     */     else
/*     */     {
/*  68 */       return;
/*     */     }
/*  70 */     ((IntGenerator)thisMbo).checkMappingObject(colsRelation);
/*  71 */     if (value.isNull())
/*     */     {
/*  73 */       thisMbo.setValueNull("objectname", 11L);
/*  74 */       thisMbo.setFieldFlag("useparent", 7L, false);
/*     */     }
/*     */     else
/*     */     {
/*  78 */       String parentName = ((IntGenerator)thisMbo).getParentTbName(thisMbo.getString("hierarchypath"));
/*  79 */       if (parentName == null)
/*     */       {
/*  81 */         throw new MXApplicationException("iface", "missingparentobject");
/*     */       }
/*  83 */       MboServerInterface service = getMboValue().getMbo().getMboServer();
/*  84 */       MboSetRemote parentSet = service.getMboSet(parentName, thisMbo.getUserInfo());
/*  85 */       RelationInfo info = parentSet.getMboSetInfo().getRelationInfo(value.getString());
/*  86 */       if (info == null)
/*     */       {
/*  88 */         String[] params = { value.getString(), thisMbo.getString("appobject") };
/*  89 */         throw new MXApplicationException("system", "norelationship", params);
/*     */       }
/*  91 */       thisMbo.setValue("objectname", info.getDest(), 11L);
/*  92 */       thisMbo.setFieldFlag("useparent", 7L, true);
/*     */     }
/*  94 */     if (colsRelation == null)
/*     */       return;
/*  96 */     MboSetRemote attrSet = thisMbo.getMboSet(colsRelation);
/*  97 */     MboRemote attr = null;
/*  98 */     for (int k = 0; ; ++k)
/*     */     {
/* 100 */       attr = attrSet.getMbo(k);
/* 101 */       System.out.println("In validate attr " + attr);
/* 102 */       if (attr == null) {
/*     */         return;
/*     */       }
/*     */ 
/* 106 */       if (value.isNull())
/*     */       {
/* 108 */         attr.setValueNull("objectname", 11L);


/*     */       }
/* 112 */       else if (thisMbo.getString("recordtype").equals("REQUESTOBJECT"))
/*     */       {
/* 114 */         attr.setValue("objectname", thisMbo.getString("objectname"), 11L);
/*     */       } else {
/* 116 */         if (!(thisMbo.getString("recordtype").equals("RESPONSEOBJECT")))
/*     */           continue;
/* 118 */         attr.setValue("objectname", thisMbo.getString("wsioobjname"), 11L);
/*     */       }
/*     */     }
/*     */   }








/*     */   public MboSetRemote getList()
/*     */     throws MXException, RemoteException
/*     */   {
/* 133 */     MboValue value = getMboValue();
/* 134 */     MboRemote thisMbo = value.getMbo();
/* 135 */     MboServerInterface service = getMboValue().getMbo().getMboServer();
/* 136 */     MboSetRemote relationSet = service.getMboSet("INTOBJRELATION", getMboValue().getMbo().getUserInfo());
/*     */ 
/* 138 */     String parentName = ((IntGenerator)thisMbo).getParentTbName(thisMbo.getString("hierarchypath"));
/* 139 */     if ((parentName == null) || (parentName.equals("")))
/*     */     {
/* 141 */       throw new MXApplicationException("iface", "missingparentobject");
/*     */     }
/* 143 */     MboSetRemote parentSet = service.getMboSet(parentName, thisMbo.getUserInfo());
/* 144 */     Iterator itr = parentSet.getMboSetInfo().getRelationsInfo();
/* 145 */     while (itr.hasNext())
/*     */     {
/* 147 */       RelationInfo relInfo = (RelationInfo)itr.next();
/* 148 */       MboRemote relationMbo = relationSet.add();
/* 149 */       relationMbo.setValue("relation", relInfo.getName());
/* 150 */       relationMbo.setValue("relsqlwhere", relInfo.getSqlExpr());
/*     */     }
/* 152 */     return relationSet;
/*     */   }
/*     */ }
