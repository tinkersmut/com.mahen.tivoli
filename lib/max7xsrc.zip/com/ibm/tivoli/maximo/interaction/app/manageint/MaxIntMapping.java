/*     */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 



























/*     */ public class MaxIntMapping extends Mbo
/*     */ {
/*     */   public MaxIntMapping(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  46 */     super(ms);
/*     */   }


/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  53 */     super.init();
/*     */     try
/*     */     {
/*  56 */       if ((isNull("relation")) && (!(isNull("mapobject"))))
/*     */       {
/*  58 */         setFieldFlag("relation", 7L, true);
/*  59 */         setValue("useparent", true, 11L);
/*     */       }
/*     */       else
/*     */       {
/*  63 */         setValue("useparent", false, 11L);
/*  64 */         setFieldFlag("relation", 7L, false);
/*  65 */         if (!(isNull("relation")))
/*     */         {
/*  67 */           setFieldFlag("useparent", 7L, true);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/*  73 */       MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
/*  74 */       throw new MXApplicationException("system", "remote");
/*     */     }
/*     */   }





/*     */   public void add()
/*     */     throws MXException, RemoteException
/*     */   {
/*  85 */     MboRemote inter = getOwner();
/*  86 */     if (inter == null)
/*     */     {
/*  88 */       return;
/*     */     }
/*  90 */     setValue("changedate", MXServer.getMXServer().getDate(), 11L);
/*  91 */     setValue("changeby", getUserName(), 11L);
/*  92 */     if (!(inter.getName().equals("MAXINTERACTION")))
/*     */       return;
/*  94 */     setValue("interaction", inter.getString("interaction"), 11L);
/*  95 */     if (getThisMboSet().getRelationName().equals("REQOBJECTS"))
/*     */     {
/*  97 */       setValue("intobjectname", inter.getString("reqosname"), 11L);
/*  98 */       setValue("isresponse", false, 11L);
/*     */     }
/*     */     else
/*     */     {
/* 102 */       setValue("intobjectname", inter.getString("resposname"), 11L);
/* 103 */       setValue("isresponse", true, 11L);
/*     */     }
/*     */   }











/*     */   public void delete(long accessModifier)
/*     */     throws MXException, RemoteException
/*     */   {
/* 120 */     super.delete(accessModifier);

/*     */     try
/*     */     {
/* 124 */       getMboSet("MAXINTMAPPINGDETAIL").deleteAll(2L);

/*     */     }
/*     */     catch (MXException me)
/*     */     {
/* 129 */       super.undelete();
/*     */ 
/* 131 */       throw me;

/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/* 136 */       super.undelete();
/*     */ 
/* 138 */       throw re;
/*     */     }
/*     */   }







/*     */   public void undelete()
/*     */     throws MXException, RemoteException
/*     */   {
/* 151 */     super.undelete();
/*     */ 
/* 153 */     getMboSet("MAXINTMAPPINGDETAIL").undeleteAll();
/*     */   }
/*     */ }
