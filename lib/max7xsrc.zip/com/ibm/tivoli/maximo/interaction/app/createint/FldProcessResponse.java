/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 























/*    */ public class FldProcessResponse extends MboValueAdapter
/*    */ {
/*    */   public FldProcessResponse(MboValue mbv)
/*    */     throws MXException
/*    */   {
/* 39 */     super(mbv);
/*    */   }




/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 48 */     MboValue value = getMboValue();
/* 49 */     MboRemote thisMbo = value.getMbo();
/* 50 */     if ((thisMbo.getOwner() == null) || (thisMbo.getOwner().getOwner() == null) || (thisMbo.getOwner().getOwner().getOwner() == null))

/*    */     {
/* 53 */       return;
/*    */     }
/* 55 */     MboRemote owner = thisMbo.getOwner().getOwner().getOwner();
/* 56 */     if (value.getBoolean())
/*    */     {
/* 58 */       owner.setFieldFlag("applyresponse", 7L, false);
/*    */     }
/*    */     else
/*    */     {
/* 62 */       MboRemote objectMbo = owner.getMboSet("RESPONSEMBOS").getMbo(0);
/* 63 */       if ((objectMbo != null) && (!(objectMbo.isNull("objectname"))))
/*    */       {
/* 65 */         throw new MXApplicationException("iface", "cannotchangeresponse_mapping");
/*    */       }
/* 67 */       owner.setValue("applyresponse", false, 2L);
/* 68 */       owner.setFieldFlag("applyresponse", 7L, true);
/*    */     }
/*    */   }
/*    */ }
