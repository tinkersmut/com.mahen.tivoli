/*     */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionCache;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionUtil;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 































/*     */ public class MaxInteractionSet extends MboSet
/*     */ {
/*     */   public MaxInteractionSet(MboServerInterface ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  54 */     super(ms);
/*     */   }












/*     */   protected Mbo getMboInstance(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  71 */     return new MaxInteraction(ms);
/*     */   }





/*     */   public void commit()
/*     */     throws MXException, RemoteException
/*     */   {
/*  81 */     if ((getMbo() != null) && (getMbo().toBeDeleted()))
/*     */     {
/*  83 */       String interaction = getMbo().getString("interaction");
/*  84 */       InteractionInfo interactionInfo = InteractionCache.getInstance().getInteractionInfo(interaction);
/*     */ 
/*  86 */       if (interactionInfo == null)
/*     */       {
/*  88 */         Object[] params = { interaction };
/*  89 */         throw new MXApplicationException("iface", "interaction_not_exist", params);
/*     */       }
/*  91 */       OBPInfo obpInfo = OBPGenerator.parse(interactionInfo.getObp());
/*  92 */       WSIO reqWsio = obpInfo.getRequest();
/*  93 */       WSIO respWsio = null;
/*  94 */       if (interactionInfo.getResponseOSName() != null)
/*     */       {
/*  96 */         respWsio = obpInfo.getResponse();
/*     */       }
/*  98 */       super.commit();
/*  99 */       InteractionUtil.reloadCache(reqWsio, respWsio);
/*     */     }
/*     */     else {
/* 102 */       super.commit(); }
/* 103 */     MXServer.getMXServer().reloadMaximoCache(InteractionCache.getInstance().getName(), true);
/*     */   }
/*     */ }
