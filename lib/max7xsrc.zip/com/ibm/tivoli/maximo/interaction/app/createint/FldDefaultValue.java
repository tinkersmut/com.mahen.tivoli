/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.interaction.obp.WSIOAttribute;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 





























/*    */ public class FldDefaultValue extends MboValueAdapter
/*    */ {
/*    */   public FldDefaultValue(MboValue mbv)
/*    */   {
/* 43 */     super(mbv);
/*    */   }






/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 54 */     MboValue value = getMboValue();
/* 55 */     MboRemote mbo = value.getMbo();
/* 56 */     if ((!(mbo.getString("recordtype").equals("REQUESTATTRIBUTE"))) && (!(mbo.getString("recordtype").equals("RESPONSEATTRIBUTE")))) {
/*    */       return;
/*    */     }
/* 59 */     ((IntGenerator)value.getMbo()).getWSIOAttribute().setDefaultValue(value.getString());
/*    */   }
/*    */ }
