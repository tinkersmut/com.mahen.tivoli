/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MAXTableDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueInfo;
/*    */ import psdi.mbo.MboValueInfoStatic;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 

























/*    */ public class FldIntMainObject extends MAXTableDomain
/*    */ {
/*    */   public FldIntMainObject(MboValue mbv)
/*    */   {
/* 43 */     super(mbv);
/* 44 */     setRelationship("MAXOBJECT", "objectname=:objectname");
/* 45 */     setErrorMessage("common", "InvalidObjectName");
/*    */   }







/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 57 */     MboValue value = getMboValue();
/* 58 */     MboRemote thisMbo = value.getMbo();
/* 59 */     MboRemote requestMbo = value.getMbo().getMboSet("REQUESTOBJECT").getMbo(0);
/* 60 */     if ((requestMbo != null) && (!(requestMbo.isNull("objectname"))))
/*    */     {
/* 62 */       String[] params = { value.getMboValueInfo().getTitle() };
/* 63 */       throw new MXApplicationException("iface", "cannotchangemainobject", params);
/*    */     }
/* 65 */     MboRemote responseMbo = value.getMbo().getMboSet("RESPONSEOBJECT").getMbo(0);
/* 66 */     if ((responseMbo != null) && (!(responseMbo.isNull("objectname"))))
/*    */     {
/* 68 */       String[] params = { value.getMboValueInfo().getTitle() };
/* 69 */       throw new MXApplicationException("iface", "cannotchangemainobject", params);
/*    */     }
/* 71 */     if (thisMbo.isNull("appname"))
/*    */     {
/* 73 */       String[] params = { thisMbo.getMboValueInfoStatic("appname").getTitle() };
/* 74 */       throw new MXApplicationException("iface", "missingurl", params);
/*    */     }
/* 76 */     String mainObject = thisMbo.getMboSet("MAXAPPS").moveFirst().getString("maintbname");
/* 77 */     if (mainObject.equals(value.getString()))
/*    */     {
/* 79 */       thisMbo.setValue("genmenuoption", true, 2L);
/* 80 */       thisMbo.setFieldFlag("genmenuoption", 7L, false);
/*    */     }
/*    */     else
/*    */     {
/* 84 */       thisMbo.setValue("genmenuoption", false, 2L);
/* 85 */       thisMbo.setFieldFlag("genmenuoption", 7L, true);
/*    */     }
/*    */   }
/*    */ }
