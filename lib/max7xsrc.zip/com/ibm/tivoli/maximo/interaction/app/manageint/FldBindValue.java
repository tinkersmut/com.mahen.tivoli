/*    */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 




























/*    */ public class FldBindValue extends MboValueAdapter
/*    */ {
/*    */   public FldBindValue(MboValue mbv)
/*    */   {
/* 43 */     super(mbv);
/*    */   }







/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 55 */     MboValue value = getMboValue();
/* 56 */     MboRemote thisMbo = value.getMbo();
/* 57 */     if (!(thisMbo.getOwner().isNull("mapobject")))
/*    */       return;
/* 59 */     throw new MXApplicationException("iface", "missingparentobject");
/*    */   }








/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 72 */     MboValue value = getMboValue();
/* 73 */     MboRemote thisMbo = value.getMbo();
/* 74 */     if (!(thisMbo.getOwner().getBoolean("isresponse")))
/*    */     {
/* 76 */       return;
/*    */     }
/* 78 */     String remarks = ((MaxIntMappingDetailSet)thisMbo.getThisMboSet()).getSourceElement(thisMbo.getString("objectname"), thisMbo.getString("value"));
/* 79 */     if (remarks == null)
/*    */     {
/* 81 */       thisMbo.setValueNull("sourceelement", 11L);
/*    */     }
/*    */     else
/*    */     {
/* 85 */       thisMbo.setValue("sourceelement", remarks, 11L);
/*    */     }
/*    */   }



/*    */   public MboSetRemote getList()
/*    */     throws MXException, RemoteException
/*    */   {
/* 94 */     MboRemote thisMbo = getMboValue().getMbo();
/* 95 */     if (thisMbo.getOwner().isNull("mapobject"))
/*    */     {
/* 97 */       throw new MXApplicationException("iface", "missingparentobject");
/*    */     }
/* 99 */     return super.getList();
/*    */   }
/*    */ }
