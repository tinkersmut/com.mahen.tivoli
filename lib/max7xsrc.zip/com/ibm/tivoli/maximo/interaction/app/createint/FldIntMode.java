/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueInfoStatic;
/*    */ import psdi.mbo.SynonymDomain;
/*    */ import psdi.mbo.Translate;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 








/*    */ public class FldIntMode extends SynonymDomain
/*    */ {
/*    */   public FldIntMode(MboValue mbv)
/*    */     throws MXException
/*    */   {
/* 28 */     super(mbv);
/* 29 */     setDomainId("INTMODE");
/*    */   }

/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 35 */     MboRemote thisMbo = getMboValue().getMbo();
/* 36 */     if (getMboValue().isNull())
/*    */     {
/* 38 */       String[] params = { thisMbo.getMboValueInfoStatic("intmode").getTitle() };
/* 39 */       throw new MXApplicationException("iface", "missingurl", params);
/*    */     }
/* 41 */     String mode = getMboValue().getString();
/* 42 */     String val = getTranslator().toInternalString("INTMODE", mode);
/*    */ 
/* 44 */     if (val.equals("SILENT"))
/*    */     {
/* 46 */       thisMbo.setFieldFlag("generatedialog", 7L, false);
/*    */     }
/*    */     else
/*    */     {
/* 50 */       thisMbo.setValue("generatedialog", true, 11L);
/* 51 */       thisMbo.setFieldFlag("generatedialog", 7L, true);
/*    */     }
/* 53 */     if (thisMbo.getBoolean("processresponse"))
/*    */     {
/* 55 */       super.validate();
/* 56 */       return;
/*    */     }
/* 58 */     if ((val.equals("SILENT")) || (val.equals("SHOWREQONLY")))
/*    */     {
/* 60 */       super.validate();
/* 61 */       return;
/*    */     }
/* 63 */     String[] params = { mode };
/* 64 */     throw new MXApplicationException("iface", "invalidintmode", params);
/*    */   }




/*    */   public MboSetRemote getList()
/*    */     throws MXException, RemoteException
/*    */   {
/* 73 */     MboRemote thisMbo = getMboValue().getMbo();
/* 74 */     if (thisMbo.getBoolean("processresponse"))
/*    */     {
/* 76 */       return super.getList();
/*    */     }
/* 78 */     MboServerInterface service = getMboValue().getMbo().getMboServer();
/* 79 */     MboSetRemote set = service.getMboSet("SYNONYMDOMAIN", getMboValue().getMbo().getUserInfo());
/*    */ 
/* 81 */     set.setWhere("domainid = 'INTMODE' and (maxvalue = 'SILENT' or maxvalue = 'SHOWREQONLY')");
/*    */ 
/* 83 */     set.moveNext();
/* 84 */     return set;
/*    */   }
/*    */ }
