/*      */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.interaction.ebp.EBPGenerator;
/*      */ import com.ibm.tivoli.maximo.interaction.ebp.EndpointInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.generate.DialogGenerator;
/*      */ import com.ibm.tivoli.maximo.interaction.generate.IntArtifactsGenerator;
/*      */ import com.ibm.tivoli.maximo.interaction.generate.IntGeneratorInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.generate.OptionGenerator;
/*      */ import com.ibm.tivoli.maximo.interaction.generate.WSIOMaxArtifactsCreator;
/*      */ import com.ibm.tivoli.maximo.interaction.obp.OBPGenerator;
/*      */ import com.ibm.tivoli.maximo.interaction.obp.OBPInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*      */ import com.ibm.tivoli.maximo.interaction.obp.WSIOAttribute;
/*      */ import com.ibm.tivoli.maximo.interaction.policy.InteractionPolicyCache;
/*      */ import com.ibm.tivoli.maximo.interaction.policy.PolicyInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.policy.PolicyParamInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.process.InteractionCache;
/*      */ import com.ibm.tivoli.maximo.interaction.process.InteractionUtil;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.OperationInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.PortInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.ServiceInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.WSDLInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.WSDLParser;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.WSDLParserFactory;
/*      */ import java.net.URL;
/*      */ import java.rmi.RemoteException;
/*      */ import java.sql.Connection;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import javax.xml.namespace.QName;
/*      */ import psdi.configure.Util;
/*      */ import psdi.iface.mic.EndPointCache;
/*      */ import psdi.iface.mic.IntegrationContext;
/*      */ import psdi.iface.mic.InvokeChannel;
/*      */ import psdi.iface.mic.InvokeChannelCache;
/*      */ import psdi.iface.mic.MaxEndPointInfo;
/*      */ import psdi.iface.mic.MicUtil;
/*      */ import psdi.iface.mos.MosInfo;
/*      */ import psdi.iface.mos.ObjectStructureCache;
/*      */ import psdi.iface.util.XMLUtils;
/*      */ import psdi.mbo.MaximoDD;
/*      */ import psdi.mbo.MboRemote;
/*      */ import psdi.mbo.MboServerInterface;
/*      */ import psdi.mbo.MboSet;
/*      */ import psdi.mbo.MboSetInfo;
/*      */ import psdi.mbo.MboSetRemote;
/*      */ import psdi.mbo.MboValueInfo;
/*      */ import psdi.mbo.MboValueInfoStatic;
/*      */ import psdi.mbo.NonPersistentMbo;
/*      */ import psdi.mbo.SqlFormat;
/*      */ import psdi.mbo.Translate;
/*      */ import psdi.security.ConnectionKey;
/*      */ import psdi.security.UserInfo;
/*      */ import psdi.server.DBManager;
/*      */ import psdi.server.MXServer;
/*      */ import psdi.txn.MXTransaction;
/*      */ import psdi.util.MXApplicationException;
/*      */ import psdi.util.MXException;
/*      */ import psdi.util.MXFormat;
/*      */ import psdi.util.logging.MXLogger;
/*      */ 

/*      */ public class IntGenerator extends NonPersistentMbo
/*      */   implements IntGeneratorRemote
/*      */ {
/*   63 */   private OBPGenerator obpGenerator = null;
/*   64 */   private OBPInfo obpInfo = null;
/*   65 */   private WSDLInfo wsdlInfo = null;
/*      */ 
/*   67 */   private LinkedHashMap<String, String> removeMap = new LinkedHashMap();
/*   68 */   private WSIO wsio = null;
/*   69 */   private WSIO nonoptimizedRequest = null;
/*   70 */   private WSIO nonoptimizedResponse = null;
/*   71 */   public WSIO optimizedRequest = null;
/*   72 */   public WSIO optimizedResponse = null;
/*   73 */   private WSIOAttribute wsioAttribute = null;
/*   74 */   private IntGeneratorInfo intGeneratorInfo = new IntGeneratorInfo();
/*      */ 
/*   78 */   public static final MXLogger INTERACTIONLOGGER = InteractionUtil.INTERACTIONLOGGER;
/*      */ 
/*      */   public IntGenerator(MboSet ms)
/*      */     throws MXException, RemoteException
/*      */   {
/*   92 */     super(ms);
/*      */   }





/*      */   public void init()
/*      */     throws MXException
/*      */   {
/*  102 */     super.init();
/*      */   }








/*      */   public void add()
/*      */     throws MXException, RemoteException
/*      */   {
/*  115 */     MboRemote owner = getOwner();
/*  116 */     if (owner == null)
/*      */     {
/*  118 */       setValue("recordtype", "INTERACTION", 2L);
/*  119 */       setFieldFlag("mapoption", 7L, true);
/*      */     }
/*  121 */     else if (owner.getName().equals("MAXINTERACTION"))
/*      */     {
/*  123 */       setValue("recordtype", "INTERACTION", 2L);
/*  124 */       setValue("interaction", owner.getString("interaction"), 11L);
/*      */ 
/*  126 */       setValue("url", owner.getString("url"), 11L);

/*      */     }
/*  129 */     else if (owner.getName().equals("MAXINTMAPPING"))
/*      */     {
/*  131 */       setValue("recordtype", "INTERACTION", 2L);
/*  132 */       setValue("interaction", owner.getString("interaction"), 11L);
/*      */ 
/*  134 */       setValue("url", owner.getOwner().getString("url"), 11L);

/*      */     }
/*  137 */     else if (owner.getName().equals("MAXINTMAPPINGDETAIL"))
/*      */     {
/*  139 */       setValue("recordtype", "INTERACTION", 2L);
/*  140 */       setValue("interaction", owner.getString("interaction"), 11L);
/*      */ 
/*  142 */       setValue("url", owner.getOwner().getOwner().getString("url"), 11L);

/*      */     }
/*      */     else
/*      */     {
/*  147 */       setValue("interaction", owner.getString("interaction"), 11L);
/*      */ 
/*  149 */       setValue("url", owner.getString("url"), 11L);
/*      */ 
/*  151 */       if ((getThisMboSet().getRelationName() != null) && (getThisMboSet().getRelationName().equals("RESPONSEMAPPING")))
/*      */       {
/*  153 */         if (owner.isNull("objectname"))
/*      */         {
/*  155 */           getThisMboSet().remove(this);
/*  156 */           throw new MXApplicationException("iface", "missingmapobject");
/*      */         }
/*  158 */         setValue("recordtype", "RESPONSEMAPPING", 11L);
/*      */ 
/*  160 */         setValue("objectname", owner.getString("wsioobjname"), 11L);
/*      */ 
/*  162 */         setValue("wsioobjname", owner.getString("objectname"), 11L);
/*      */       }
/*      */       else {
/*  165 */         if ((getThisMboSet().getRelationName() == null) || (!(getThisMboSet().getRelationName().equals("REQUESTMAPPING"))))
/*      */           return;
/*  167 */         if (owner.isNull("objectname"))
/*      */         {
/*  169 */           getThisMboSet().remove(this);
/*  170 */           throw new MXApplicationException("iface", "missingmapobject");
/*      */         }
/*  172 */         setValue("recordtype", "REQUESTMAPPING", 11L);
/*      */ 
/*  174 */         setValue("objectname", owner.getString("objectname"), 11L);
/*      */ 
/*  176 */         setValue("wsioobjname", owner.getString("wsioobjname"), 11L);
/*      */ 
/*  178 */         setFieldFlag("password", 7L, true);
/*      */       }
/*      */     }
/*      */   }





/*      */   public void appValidate()
/*      */     throws MXException, RemoteException
/*      */   {
/*  190 */     if ((((getString("recordtype").equals("REQUESTMAPPING")) || (getString("recordtype").equals("RESPONSEMAPPING")))) && 


/*  193 */       (isNull("attributename")))
/*      */     {
/*  195 */       String[] params = { getMboValueInfoStatic("attributename").getTitle() };
/*  196 */       throw new MXApplicationException("system", "null", params);
/*      */     }
/*      */ 
/*  199 */     super.appValidate();
/*      */   }



/*      */   public void parseWSDL()
/*      */     throws MXException, RemoteException
/*      */   {
/*      */     Collection allServices;
/*      */     MboSetRemote serviceSet;
/*      */     try
/*      */     {
/*  211 */       setValue("processresponse", true, 11L);
/*  212 */       setValueNull("servicename", 11L);
/*  213 */       setValueNull("portname", 11L);
/*  214 */       setValueNull("operation", 11L);
/*      */ 
/*  216 */       this.wsdlInfo = WSDLParserFactory.getWSDLParser().parse(new URL(getString("url")));
/*  217 */       allServices = this.wsdlInfo.getAllServices();
/*  218 */       serviceSet = getMboSet("SCHEMASERVICES");
/*  219 */       serviceSet.clear();
/*  220 */       for (ServiceInfo serviceInfo : allServices)
/*      */       {
/*  222 */         MboRemote service = serviceSet.addAtEnd();
/*  223 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*      */         {
/*  225 */           INTERACTIONLOGGER.debug("Service Name " + serviceInfo.getName());
/*      */         }
/*  227 */         service.setValue("servicename", serviceInfo.getName(), 2L);
/*  228 */         if (allServices.size() == 1)
/*      */         {
/*  230 */           service.setValue("selected", true, 11L);
/*      */         }
/*  232 */         List allPorts = serviceInfo.getPorts();
/*  233 */         MboSetRemote portSet = service.getMboSet("SCHEMAPORTS");
/*  234 */         portSet.clear();
/*  235 */         for (int i = 0; i < allPorts.size(); ++i)
/*      */         {
/*  237 */           PortInfo portInfo = (PortInfo)allPorts.get(i);
/*  238 */           if (INTERACTIONLOGGER.isDebugEnabled())
/*      */           {
/*  240 */             INTERACTIONLOGGER.debug("Port Name " + portInfo.getName());
/*      */           }
/*  242 */           MboRemote port = portSet.addAtEnd();
/*  243 */           port.setValue("portname", portInfo.getName(), 11L);
/*  244 */           port.setValue("bindingname", portInfo.getBindingName(), 11L);
/*  245 */           port.setValue("bindingtype", portInfo.getBindingType(), 11L);
/*  246 */           port.setValue("endpointurl", portInfo.getEndPointUrl(), 11L);
/*  247 */           port.setValue("porttypename", portInfo.getPortTypeName(), 11L);
/*  248 */           if (allPorts.size() == 1)
/*      */           {
/*  250 */             port.setValue("selected", true, 11L);
/*      */           }
/*  252 */           List allOper = portInfo.getOperationList();
/*  253 */           MboSetRemote operSet = port.getMboSet("SCHEMAOPER");
/*  254 */           operSet.clear();
/*  255 */           for (int j = 0; j < allOper.size(); ++j)
/*      */           {
/*  257 */             OperationInfo operInfo = (OperationInfo)allOper.get(j);
/*  258 */             MboRemote oper = operSet.addAtEnd();
/*  259 */             oper.setValue("operation", operInfo.getName(), 11L);
/*  260 */             if (allOper.size() == 1)
/*      */             {
/*  262 */               oper.setValue("selected", true, 11L);
/*      */             }
/*  264 */             String input = operInfo.getInputElement().toString();
/*  265 */             if (input.indexOf("}") > -1)
/*      */             {
/*  267 */               input = input.substring(input.indexOf("}") + 1);
/*      */             }
/*  269 */             oper.setValue("inputelement", input, 2L);
/*  270 */             if (operInfo.getOutputElement() == null)
/*      */             {
/*  272 */               oper.setValueNull("outputelement", 11L);
/*  273 */               oper.setValue("processresponse", false, 11L);
/*  274 */               oper.setFieldFlag("processresponse", 7L, true);
/*  275 */               setValue("processresponse", false, 11L);
/*      */             }
/*      */             else
/*      */             {
/*  279 */               String output = operInfo.getOutputElement().toString();
/*  280 */               if ((output != null) && (output.length() > 0))
/*      */               {
/*  282 */                 if (output.indexOf("}") > -1)
/*      */                 {
/*  284 */                   output = output.substring(output.indexOf("}") + 1);
/*      */                 }
/*  286 */                 oper.setValue("outputelement", output, 11L);
/*  287 */                 oper.setValue("processresponse", true, 11L);
/*  288 */                 oper.setFieldFlag("processresponse", 7L, false);
/*  289 */                 setValue("processresponse", true, 11L);
/*      */               }
/*      */               else
/*      */               {
/*  293 */                 oper.setValueNull("outputelement", 11L);
/*  294 */                 oper.setValue("processresponse", false, 11L);
/*  295 */                 oper.setFieldFlag("processresponse", 7L, true);
/*  296 */                 setValue("processresponse", false, 11L);
/*      */               }
/*      */             }
/*  299 */             if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*      */               continue;
/*  301 */             INTERACTIONLOGGER.debug("Operation Name " + operInfo.getName());
/*  302 */             INTERACTIONLOGGER.debug("Operation Response " + getString("processresponse"));
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (MXException me)
/*      */     {
/*  310 */       throw me;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  314 */       e.printStackTrace();
/*  315 */       throw new MXApplicationException("system", "major", e);
/*      */     }
/*      */   }







/*      */   public boolean setPortAndOperation()
/*      */     throws MXException, RemoteException
/*      */   {
/*  328 */     boolean regenerate = false;
/*      */ 
/*  330 */     setFieldFlag("url", 7L, true);
/*  331 */     setFieldFlag("interaction", 7L, true);
/*      */ 
/*  333 */     MboSetRemote serviceSet = getMboSet("SCHEMASERVICES");
/*  334 */     MboRemote service = null;
/*  335 */     for (int i = 0; ; ++i)
/*      */     {
/*  337 */       service = serviceSet.getMbo(i);
/*  338 */       if (service == null)
/*      */       {
/*  340 */         String[] params = { getMboValueInfoStatic("servicename").getTitle() };
/*  341 */         throw new MXApplicationException("iface", "norowsselected", params);
/*      */       }
/*  343 */       if (!(service.getBoolean("selected"))) {
/*      */         continue;
/*      */       }
/*      */ 
/*  347 */       if (!(getString("servicename").equals(service.getString("servicename"))))
/*      */       {
/*  349 */         INTERACTIONLOGGER.debug("Service name changed ");
/*  350 */         regenerate = true;
/*      */       }
/*  352 */       setValue("servicename", service.getString("servicename"), 2L);
/*  353 */       MboSetRemote portSet = service.getMboSet("SCHEMAPORTS");
/*  354 */       MboRemote port = null;
/*  355 */       for (int j = 0; ; ++j)
/*      */       {
/*  357 */         port = portSet.getMbo(j);
/*  358 */         if (port == null)
/*      */         {
/*  360 */           String[] params = { getMboValueInfoStatic("portname").getTitle() };
/*  361 */           throw new MXApplicationException("iface", "norowsselected", params);
/*      */         }
/*  363 */         if (!(port.getBoolean("selected"))) {
/*      */           continue;
/*      */         }
/*      */ 
/*  367 */         if (!(getString("portname").equals(port.getString("portname"))))
/*      */         {
/*  369 */           INTERACTIONLOGGER.debug("Port name changed ");
/*  370 */           regenerate = true;
/*      */         }
/*  372 */         setValue("portname", port.getString("portname"), 2L);
/*  373 */         MboSetRemote operationSet = port.getMboSet("SCHEMAOPER");
/*  374 */         MboRemote oper = null;
/*  375 */         for (int l = 0; ; ++l)
/*      */         {
/*  377 */           oper = operationSet.getMbo(l);
/*  378 */           if (oper == null)
/*      */           {
/*  380 */             String[] params = { getMboValueInfoStatic("operation").getTitle() };
/*  381 */             throw new MXApplicationException("iface", "norowsselected", params);
/*      */           }
/*  383 */           if (!(oper.getBoolean("selected"))) {
/*      */             continue;
/*      */           }
/*      */ 
/*  387 */           if (!(getString("operation").equals(oper.getString("operation"))))
/*      */           {
/*  389 */             INTERACTIONLOGGER.debug("Operation name changed ");
/*  390 */             regenerate = true;
/*      */           }
/*  392 */           if (getBoolean("processresponse") != oper.getBoolean("processresponse"))
/*      */           {
/*  394 */             INTERACTIONLOGGER.debug("Process response changed ");
/*  395 */             regenerate = true;
/*      */           }
/*  397 */           setValue("operation", oper.getString("operation"), 2L);
/*  398 */           setValue("processresponse", oper.getString("processresponse"), 2L);
/*  399 */           setFieldFlag("generatedialog", 7L, true);
/*  400 */           if (getBoolean("processresponse"))
/*      */           {
/*  402 */             setValue("intmode", getMboServer().getMaximoDD().getTranslator().toExternalDefaultValue("INTMODE", "SHOWREQRESP", this), 11L);
/*  403 */             setValue("applyresponse", true, 11L);
/*  404 */             setFieldFlag("applyresponse", 7L, false);
/*      */           }
/*      */           else
/*      */           {
/*  408 */             setValue("intmode", getMboServer().getMaximoDD().getTranslator().toExternalDefaultValue("INTMODE", "SHOWREQONLY", this), 11L);
/*  409 */             setValue("applyresponse", false, 11L);
/*  410 */             setFieldFlag("applyresponse", 7L, true);
/*      */           }
/*  412 */           return regenerate;
/*      */         }
/*      */       }
/*      */     }
/*      */   }






/*      */   public void viewSchema()
/*      */     throws MXException, RemoteException
/*      */   {
/*      */     try
/*      */     {
/*  428 */       String ignoreAttr = InteractionPolicyCache.getInstance().getPolicyInfo("IATEP").getParamater("EXCLUDE_ATTRIBUTES").getValue();
/*      */ 
/*  430 */       String ignoreAnyElement = InteractionPolicyCache.getInstance().getPolicyInfo("IAEP").getParamater("EXCLUDE_ANY_ELEMENT").getValue();
/*      */ 
/*  432 */       String ingnoreRecurrence = InteractionPolicyCache.getInstance().getPolicyInfo("IORP").getParamater("SKIP_RECCURRENCE").getValue();
/*      */ 
/*  434 */       String treatAsAtomic = InteractionPolicyCache.getInstance().getPolicyInfo("ISTP").getParamater("TREAT_SIMPLE_LIST_TYPE_AS_ATOMIC").getValue();
/*      */ 
/*  436 */       String defaultLength = InteractionPolicyCache.getInstance().getPolicyInfo("IDALP").getParamater("DEFAULT_LENGTH").getValue();
/*      */ 
/*  438 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  440 */         INTERACTIONLOGGER.debug(InteractionPolicyCache.getInstance().getPolicyInfo("IATEP").getPolicyName() + ": " + ignoreAttr);

/*      */ 
/*  443 */         INTERACTIONLOGGER.debug(InteractionPolicyCache.getInstance().getPolicyInfo("IAEP").getPolicyName() + ": " + ignoreAnyElement);

/*      */ 
/*  446 */         INTERACTIONLOGGER.debug(InteractionPolicyCache.getInstance().getPolicyInfo("IORP").getPolicyName() + ": " + ingnoreRecurrence);

/*      */ 
/*  449 */         INTERACTIONLOGGER.debug(InteractionPolicyCache.getInstance().getPolicyInfo("ISTP").getPolicyName() + ": " + treatAsAtomic);

/*      */       }
/*      */ 
/*  453 */       this.obpGenerator = new OBPGenerator(getString("interaction"), MXFormat.stringToBoolean(ignoreAttr), MXFormat.stringToBoolean(ignoreAnyElement), MXFormat.stringToBoolean(ingnoreRecurrence), MXFormat.stringToBoolean(treatAsAtomic), getBoolean("processresponse"));


/*      */ 
/*  457 */       this.obpInfo = this.obpGenerator.create(new URL(getString("url")), getString("servicename"), getString("portname"), getString("operation"));
/*      */ 
/*  459 */       if (this.obpInfo == null)
/*  460 */         return;
/*  461 */       this.intGeneratorInfo.setInteractionName(getString("interaction"));
/*  462 */       String intName = getString("interaction").trim() + "Channel";
/*  463 */       this.intGeneratorInfo.setInvkChannelName(getInvkChannelName(intName, intName.length()));
/*  464 */       String epName = getString("interaction").trim() + "EP";
/*  465 */       this.intGeneratorInfo.setEndPointName(getEndPointName(epName, epName.length()));
/*  466 */       this.intGeneratorInfo.setProcessResponse(getBoolean("processresponse"));
/*  467 */       this.intGeneratorInfo.setDefaultAttributeLength(defaultLength);
/*  468 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  470 */         INTERACTIONLOGGER.debug("Invocation channel " + this.intGeneratorInfo.getInvokeChannelName());
/*  471 */         INTERACTIONLOGGER.debug("End Point " + this.intGeneratorInfo.getEndPointName());
/*      */       }
/*  473 */       setValue("invchannelname", this.intGeneratorInfo.getInvokeChannelName(), 2L);
/*  474 */       setValue("endpointname", this.intGeneratorInfo.getEndPointName(), 2L);
/*  475 */       setValue("recordtype", "INTERACTION", 2L);
/*  476 */       setValue("requestxml", new String(this.obpGenerator.getSampleRequestXML(), "utf-8"), 2L);
/*  477 */       if (getBoolean("processresponse"))
/*      */       {
/*  479 */         setValue("responsexml", new String(this.obpGenerator.getSampleResponseXML(), "utf-8"), 2L);
/*      */       }
/*  481 */       this.nonoptimizedRequest = this.obpInfo.getRequest();
/*  482 */       WSIOTreeSet requestWsioSet = (WSIOTreeSet)getMboSet("REQUESTWSIO");
/*  483 */       requestWsioSet.clear();
/*  484 */       requestWsioSet.fill(this.nonoptimizedRequest, true, this.removeMap);
/*  485 */       INTERACTIONLOGGER.debug("After fill request ");
/*  486 */       WSIOTreeSet responseWsioSet = (WSIOTreeSet)getMboSet("RESPONSEWSIO");
/*  487 */       responseWsioSet.clear();
/*  488 */       if (getBoolean("processresponse"))
/*      */       {
/*  490 */         this.nonoptimizedResponse = this.obpInfo.getResponse();
/*  491 */         responseWsioSet.fill(this.nonoptimizedResponse, true, this.removeMap);
/*  492 */         INTERACTIONLOGGER.debug("After fill response ");
/*      */       }
/*  494 */       MboSetRemote requestMboSet = getMboSet("REQUESTMBOS");
/*  495 */       requestMboSet.clear();
/*  496 */       MboSetRemote responseMboSet = getMboSet("RESPONSEMBOS");
/*  497 */       responseMboSet.clear();
/*  498 */       MboSetRemote optRequestWsioSet = getMboSet("REQUESTWSIOOPT");
/*  499 */       optRequestWsioSet.clear();
/*  500 */       MboSetRemote optResponseWsioSet = getMboSet("RESPONSEWSIOOPT");
/*  501 */       optResponseWsioSet.clear();
/*  502 */       setValueNull("reqosname", 2L);
/*  503 */       setValueNull("resposname", 2L);
/*      */     }
/*      */     catch (MXException me)
/*      */     {
/*  507 */       throw me;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  511 */       throw new MXApplicationException("system", "major", e);
/*      */     }
/*      */   }







/*      */   public void viewOptimizedSchemaRequest(boolean fill)
/*      */     throws MXException, RemoteException
/*      */   {
/*  524 */     OBPInfo requestInfo = this.obpGenerator.optimizeRequest(this.obpInfo);
/*  525 */     this.optimizedRequest = requestInfo.getRequest();
/*  526 */     WSIOTreeSet requestWsioSet = (WSIOTreeSet)getMboSet("REQUESTWSIOOPT");
/*  527 */     requestWsioSet.clear();
/*  528 */     if (!(fill))
/*      */       return;
/*  530 */     requestWsioSet.fill(this.optimizedRequest, true, null);
/*      */   }








/*      */   public void viewOptimizedSchemaResponse(boolean fill)
/*      */     throws MXException, RemoteException
/*      */   {
/*  543 */     OBPInfo responseInfo = this.obpGenerator.optimizeResponse(this.obpInfo);
/*  544 */     this.optimizedResponse = responseInfo.getResponse();
/*  545 */     if (this.optimizedResponse == null)
/*      */     {
/*  547 */       throw new MXApplicationException("iface", "uncheck_process_response");
/*      */     }
/*  549 */     WSIOTreeSet responseWsioSet = (WSIOTreeSet)getMboSet("RESPONSEWSIOOPT");
/*  550 */     responseWsioSet.clear();
/*  551 */     if (fill)
/*      */     {
/*  553 */       responseWsioSet.fill(this.optimizedResponse, true, null);
/*      */     }
/*  555 */     getOBPInfo().createNewInstance(this.optimizedRequest, this.optimizedResponse);
/*      */   }





/*      */   public void setRequestArtifacts()
/*      */     throws MXException, RemoteException
/*      */   {
/*  565 */     String intName = getString("interaction").trim() + "REQOS";
/*  566 */     this.intGeneratorInfo.setReqOSName(getOSName(intName, intName.length()));
/*  567 */     setValue("reqosname", this.intGeneratorInfo.getReqOSName(), 2L);
/*  568 */     setValue("isreqmultiple", this.optimizedRequest.isMaxOccursUnbounded(), 2L);
/*  569 */     fillObjStrUi(true);
/*      */   }





/*      */   public void setResponseArtifacts()
/*      */     throws MXException, RemoteException
/*      */   {
/*  579 */     String intName = getString("interaction").trim() + "RESOS";
/*  580 */     this.intGeneratorInfo.setRespOSName(getOSName(intName, intName.length()));
/*  581 */     setValue("resposname", this.intGeneratorInfo.getRespOSName(), 2L);
/*  582 */     setValue("isrespmultiple", this.optimizedResponse.isMaxOccursUnbounded(), 2L);
/*  583 */     fillObjStrUi(false);
/*      */   }

/*      */   public void fillObjStrUi(boolean isReq) throws MXException, RemoteException {
/*  587 */     Connection con = null;
/*  588 */     ConnectionKey sKey = null;
/*      */     try
/*      */     {
/*  591 */       sKey = MXServer.getMXServer().getDBManager().getSystemConnectionKey();
/*  592 */       con = MXServer.getMXServer().getDBManager().getConnection(sKey);
/*  593 */       Util util = new Util(con, null, null, false);
/*      */ 
/*  595 */       if (isReq)
/*      */       {
/*  597 */         MboSetRemote requestMboSet = getMboSet("REQUESTMBOS");
/*  598 */         requestMboSet.clear();
/*  599 */         fillUiMboTable(this.optimizedRequest, null, null, requestMboSet, isReq, util, 1);
/*      */       }
/*      */       else
/*      */       {
/*  603 */         MboSetRemote responseMboSet = getMboSet("RESPONSEMBOS");
/*  604 */         responseMboSet.clear();
/*  605 */         fillUiMboTable(this.optimizedResponse, null, null, responseMboSet, false, util, 1);
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  616 */         if (con != null)
/*      */         {
/*  618 */           MXServer.getMXServer().getDBManager().freeConnection(sKey);
/*      */         }
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/*  623 */         ex.printStackTrace();
/*      */       }
/*      */     }
/*      */   }







/*      */   private void fillUiMboTable(WSIO wsio, WSIO parentWSIO, String parentPath, MboSetRemote uiMboSet, boolean isReq, Util util, int processorder)
/*      */     throws MXException, RemoteException
/*      */   {
/*  637 */     String path = null;
/*  638 */     MboSetRemote attrSet = null;
/*  639 */     MboRemote mbo = uiMboSet.addAtEnd();
/*  640 */     ((IntGenerator)mbo).setWSIO(wsio);
/*  641 */     String wsioName = wsio.getName().trim();
/*  642 */     String objName = getObjectName(wsioName, util, wsioName.length());
/*  643 */     wsio.setName(objName);
/*  644 */     mbo.setValue("title", wsio.getTitle(), 2L);
/*  645 */     mbo.setValue("processorder", processorder);
/*  646 */     String location = wsio.getXmlLocation();
/*  647 */     if (location.indexOf("/") > -1)
/*      */     {
/*  649 */       location = location.substring(location.lastIndexOf("/") + 1);
/*      */     }
/*  651 */     if (location.indexOf(":") == -1)
/*      */     {
/*  653 */       mbo.setValue("sourceelement", location);
/*      */     }
/*      */     else
/*      */     {
/*  657 */       mbo.setValue("sourceelement", location.substring(location.lastIndexOf(":") + 1));
/*      */     }
/*      */ 
/*  660 */     if (parentWSIO != null)
/*      */     {
/*  662 */       mbo.setValue("parentobjname", parentWSIO.getName(), 2L);
/*      */     }
/*  664 */     if (parentPath != null)
/*      */     {
/*  666 */       path = parentPath + "/" + objName;
/*  667 */       mbo.setValue("parenthierarchy", parentPath, 2L);
/*      */     }
/*      */     else
/*      */     {
/*  671 */       path = wsio.getName();
/*      */     }
/*  673 */     mbo.setValue("hierarchypath", path, 2L);
/*  674 */     mbo.setValue("wsioobjname", objName, 2L);
/*  675 */     List wsioAttrList = wsio.getWSIOAttributes();
/*  676 */     if (isReq)
/*      */     {
/*  678 */       mbo.setValue("recordtype", "REQUESTOBJECT", 2L);
/*  679 */       attrSet = mbo.getMboSet("REQATTRIBUTES");
/*      */     }
/*      */     else
/*      */     {
/*  683 */       mbo.setValue("recordtype", "RESPONSEOBJECT", 2L);
/*  684 */       attrSet = mbo.getMboSet("RESPATTRIBUTES");
/*      */     }
/*      */ 
/*  687 */     for (WSIOAttribute wsioAttr : wsioAttrList)
/*      */     {
/*  689 */       MboRemote attrMbo = attrSet.addAtEnd();
/*  690 */       ((IntGenerator)attrMbo).setWSIOAttribute(wsioAttr);
/*  691 */       attrMbo.setValue("attributename", wsioAttr.getName(), 2L);
/*  692 */       attrMbo.setValue("required", wsioAttr.isRequired(), 2L);
/*  693 */       attrMbo.setValue("title", wsioAttr.getTitle(), 2L);
/*  694 */       attrMbo.setValue("maxtype", InteractionUtil.getMaxType(wsioAttr), 2L);
/*  695 */       attrMbo.setValue("defaultvalue", wsioAttr.getDefaultValue(), 2L);
/*  696 */       attrMbo.setValue("wsioobjname", objName, 2L);
/*  697 */       attrMbo.setValue("hierarchypath", wsioAttr.getXmlLocation(), 2L);
/*  698 */       if (isReq)
/*      */       {
/*  700 */         attrMbo.setValue("recordtype", "REQUESTATTRIBUTE", 2L);
/*      */       }
/*      */       else
/*      */       {
/*  704 */         attrMbo.setValue("recordtype", "RESPONSEATTRIBUTE", 2L);
/*      */       }
/*  706 */       attrMbo.setValue("readonly", wsioAttr.isReadOnly(), 2L);
/*  707 */       if (wsioAttr.isReadOnly())
/*      */       {
/*  709 */         attrMbo.setFieldFlag("readonly", 7L, true);
/*      */       }
/*  711 */       if ((wsioAttr.getEnumList() != null) && (wsioAttr.getEnumList().size() > 0))
/*      */       {
/*  713 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*      */         {
/*  715 */           INTERACTIONLOGGER.debug("Attribute " + wsioAttr.getName());
/*  716 */           INTERACTIONLOGGER.debug("Value list is " + wsioAttr.getEnumList());
/*      */         }
/*  718 */         String maxType = attrMbo.getString("maxtype");
/*  719 */         if ((maxType.equals("FLOAT")) || (maxType.equals("DECIMAL")) || (maxType.equals("INTEGER")))
/*      */         {
/*  721 */           attrMbo.setValue("domaintype", maxType, 2L);
/*      */         }
/*  723 */         else if (maxType.equals("ALN"))
/*      */         {
/*  725 */           attrMbo.setValue("domaintype", maxType, 2L);
/*      */         }
/*      */       }
/*  728 */       attrMbo.select();
/*      */     }
/*  730 */     List wsioList = wsio.getWSIOChildren();
/*  731 */     if (wsioList == null)
/*      */       return;
/*  733 */     for (WSIO childWSIO : wsioList)
/*  734 */       fillUiMboTable(childWSIO, wsio, path, uiMboSet, isReq, util, ++processorder);
/*      */   }










/*      */   public void processnode(WSIOTreeSetRemote treeSet, LinkedHashMap<String, String> removeMap, boolean isRequest)
/*      */     throws MXException, RemoteException
/*      */   {
/*  749 */     String objectRelation = null;
/*  750 */     if (isRequest)
/*      */     {
/*  752 */       objectRelation = "REQUESTMBOS";
/*      */     }
/*      */     else
/*      */     {
/*  756 */       objectRelation = "RESPONSEMBOS";
/*      */     }
/*  758 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  760 */       INTERACTIONLOGGER.debug("Object relation " + objectRelation);
/*      */     }
/*  762 */     MboRemote objectMbo = getMboSet(objectRelation).getMbo(0);
/*  763 */     if ((objectMbo != null) && 

/*  765 */       (!(objectMbo.isNull("objectname"))))
/*      */     {
/*  767 */       throw new MXApplicationException("iface", "cannotchangetreemap");
/*      */     }
/*      */ 
/*  770 */     treeSet.deleteAndRemoveAll();
/*  771 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  773 */       INTERACTIONLOGGER.debug("refill tree with new data " + isRequest);
/*      */     }
/*  775 */     if (isRequest)
/*      */     {
/*  777 */       treeSet.fill(this.nonoptimizedRequest, true, removeMap);
/*      */     }
/*      */     else
/*      */     {
/*  781 */       treeSet.fill(this.nonoptimizedResponse, true, removeMap);
/*      */     }
/*      */   }





/*      */   public void select()
/*      */     throws MXException, RemoteException
/*      */   {
/*  792 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  794 */       INTERACTIONLOGGER.debug("Record Type to select " + getString("recordtype"));
/*      */     }
/*  796 */     if ((getString("recordtype").equals("REQUESTATTRIBUTE")) || (getString("recordtype").equals("RESPONSEATTRIBUTE")))

/*      */     {
/*  799 */       MboRemote owner = getOwner();
/*  800 */       String path = owner.getString("hierarchypath");
/*  801 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  803 */         INTERACTIONLOGGER.debug("Hierarchy Path " + path);
/*      */       }
/*  805 */       if (!(path.equals(owner.getString("wsioobjname"))))
/*      */       {
/*  807 */         String parentPath = path.substring(0, path.lastIndexOf("/" + owner.getString("wsioobjname")));
/*  808 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*      */         {
/*  810 */           INTERACTIONLOGGER.debug("Parent Hierarchy Path " + parentPath);
/*      */         }
/*  812 */         for (int j = 0; j < owner.getThisMboSet().getSize(); ++j)
/*      */         {
/*  814 */           MboRemote searchMbo = owner.getThisMboSet().getMbo(j);
/*  815 */           if (searchMbo == null) {
/*      */             break;
/*      */           }
/*      */ 
/*  819 */           String mboPath = searchMbo.getString("hierarchypath");
/*  820 */           if (!(mboPath.equals(parentPath)))
/*      */             continue;
/*  822 */           if (INTERACTIONLOGGER.isDebugEnabled())
/*      */           {
/*  824 */             INTERACTIONLOGGER.debug("Hierarchy Path Found" + mboPath);
/*      */           }
/*  826 */           Vector select = null;
/*  827 */           if (getString("recordtype").equals("REQUESTATTRIBUTE"))
/*      */           {
/*  829 */             select = searchMbo.getMboSet("REQATTRIBUTES").getSelection();
/*      */           }
/*      */           else
/*      */           {
/*  833 */             select = searchMbo.getMboSet("RESPATTRIBUTES").getSelection();
/*      */           }
/*  835 */           if (select.size() != 0)
/*      */             continue;
/*  837 */           String[] params = { parentPath };
/*  838 */           throw new MXApplicationException("iface", "noparentselected", params);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  844 */     super.select();
/*      */   }





/*      */   public void unselect()
/*      */     throws MXException, RemoteException
/*      */   {
/*  854 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/*  856 */       INTERACTIONLOGGER.debug("Record Type to unselect " + getString("recordtype"));
/*      */     }
/*  858 */     if ((getString("recordtype").equals("REQUESTATTRIBUTE")) || (getString("recordtype").equals("RESPONSEATTRIBUTE")))

/*      */     {
/*  861 */       if (getThisMboSet().getSelection().size() > 1)
/*      */       {
/*  863 */         super.unselect();
/*  864 */         return;
/*      */       }
/*  866 */       MboRemote owner = getOwner();
/*  867 */       String path = owner.getString("hierarchypath");
/*  868 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  870 */         INTERACTIONLOGGER.debug("Hierarchy Path " + path);

/*      */       }
/*      */ 
/*  874 */       for (int j = 0; j < owner.getThisMboSet().getSize(); ++j)
/*      */       {
/*  876 */         MboRemote searchMbo = owner.getThisMboSet().getMbo(j);
/*  877 */         if (searchMbo == null) {
/*      */           break;
/*      */         }
/*      */ 
/*  881 */         String mboPath = searchMbo.getString("hierarchypath");
/*  882 */         if (mboPath.equals(path)) continue; if (mboPath.indexOf(path) == -1)

/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/*  888 */         String rest = mboPath.substring(path.length());
/*  889 */         if (!(rest.startsWith("/"))) {
/*      */           continue;
/*      */         }
/*      */ 
/*  893 */         rest = rest.substring(1);
/*  894 */         if (rest.indexOf("/") != -1)
/*      */           continue;
/*  896 */         Vector select = null;
/*  897 */         if (getString("recordtype").equals("REQUESTATTRIBUTE"))
/*      */         {
/*  899 */           select = searchMbo.getMboSet("REQATTRIBUTES").getSelection();
/*      */         }
/*      */         else
/*      */         {
/*  903 */           select = searchMbo.getMboSet("RESPATTRIBUTES").getSelection();
/*      */         }
/*  905 */         if (select.size() <= 0)
/*      */           continue;
/*  907 */         String[] params = { mboPath };
/*  908 */         throw new MXApplicationException("iface", "childselected", params);


/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  915 */     super.unselect();
/*      */   }







/*      */   public String validateMappings(boolean isResponse)
/*      */     throws MXException, RemoteException
/*      */   {
/*  927 */     String objectRelation = null;
/*  928 */     String attrRelation = null;
/*  929 */     Map requiredKeys = null;
/*  930 */     boolean checkKeys = false;
/*      */ 
/*  932 */     if (!(isResponse))
/*      */     {
/*  934 */       objectRelation = "REQUESTMBOS";
/*  935 */       attrRelation = "REQUESTMAPPING";
/*      */     }
/*      */     else
/*      */     {
/*  939 */       objectRelation = "RESPONSEMBOS";
/*  940 */       attrRelation = "RESPONSEMAPPING";
/*      */     }
/*  942 */     MboSetRemote applySet = getMboSet(objectRelation);
/*  943 */     for (int j = 0; ; ++j)
/*      */     {
/*  945 */       MboRemote searchMbo = applySet.getMbo(j);
/*  946 */       if (searchMbo == null) {
/*      */         break;
/*      */       }
/*      */ 
/*  950 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/*  952 */         INTERACTIONLOGGER.debug("In validate mappings objectname " + searchMbo.getString("objectname"));
/*      */       }
/*  954 */       if (searchMbo.isNull("objectname")) {
/*      */         continue;
/*      */       }
/*      */ 
/*  958 */       MboSetRemote attrSet = searchMbo.getMboSet(attrRelation);
/*  959 */       if ((isResponse) && (attrSet.getSize() == 0) && (!(searchMbo.getBoolean("useparent"))))
/*      */       {
/*  961 */         String[] params = { searchMbo.getString("objectname") };
/*  962 */         throw new MXApplicationException("iface", "nomapping", params);
/*      */       }
/*  964 */       if ((isResponse) && (searchMbo.isNull("parentobjname")) && (!(searchMbo.getBoolean("useparent"))))
/*      */       {
/*  966 */         checkKeys = true;
/*  967 */         MboSetInfo msi = MXServer.getMXServer().getMaximoDD().getMboSetInfo(searchMbo.getString("objectname"));
/*  968 */         requiredKeys = new HashMap();
/*  969 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*      */         {
/*  971 */           INTERACTIONLOGGER.debug("Check for add only objectname " + searchMbo.getString("objectname"));
/*      */         }
/*  973 */         String[] keys = MicUtil.getKeyArray(searchMbo.getString("objectname"));
/*  974 */         for (int i = 0; i < keys.length; ++i)
/*      */         {
/*  976 */           String key = keys[i];
/*  977 */           MboValueInfo mvi = msi.getMboValueInfo(key);
/*  978 */           if (!(mvi.isRequired()))
/*      */             continue;
/*  980 */           requiredKeys.put(key, key);
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  986 */         checkKeys = false;
/*      */       }
/*  988 */       for (int k = 0; ; ++k)
/*      */       {
/*  990 */         MboRemote attr = attrSet.getMbo(k);
/*  991 */         if (attr == null) {
/*      */           break;
/*      */         }
/*      */ 
/*  995 */         if (attr.isNull("attributename"))
/*      */         {
/*  997 */           String[] params = { searchMbo.getString("objectname") };
/*  998 */           throw new MXApplicationException("iface", "missingmappingattr", params);
/*      */         }
/* 1000 */         if (!(checkKeys))
/*      */           continue;
/* 1002 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*      */         {
/* 1004 */           INTERACTIONLOGGER.debug("Check for add only Attribute " + attr.getString("attributename"));
/* 1005 */           INTERACTIONLOGGER.debug("Check for add only value " + attr.getString("value"));
/*      */         }
/* 1007 */         if ((!(requiredKeys.containsKey(attr.getString("attributename")))) || (attr.isNull("value")))
/*      */           continue;
/* 1009 */         requiredKeys.remove(attr.getString("attributename"));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1014 */     if ((checkKeys) && (requiredKeys != null) && (!(requiredKeys.isEmpty())))
/*      */     {
/* 1016 */       Iterator itr = requiredKeys.keySet().iterator();
/*      */ 
/* 1018 */       String param = null;
/*      */ 
/* 1020 */       while (itr.hasNext())
/*      */       {
/* 1022 */         if (param == null)
/*      */         {
/* 1024 */           param = (String)itr.next();

/*      */         }
/*      */ 
/* 1028 */         param = param + "," + ((String)itr.next());
/*      */       }
/*      */ 
/* 1031 */       return param;
/*      */     }
/* 1033 */     return null;
/*      */   }







/*      */   public String createIntegrationArtifacts(String label, byte[] presentataion)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1045 */     String presentationXML = null;
/* 1046 */     String respObject = null;
/* 1047 */     UserInfo usrInfo = getUserInfo();
/* 1048 */     MXTransaction trans = getThisMboSet().getMXTransaction();
/* 1049 */     boolean created = false;
/*      */ 
/* 1051 */     ((IntGeneratorSet)getThisMboSet()).completed = true;
/* 1052 */     String reqObject = getMboSet("REQUESTMBOS").getMbo(0).getString("wsioobjname");
/*      */ 
/* 1054 */     String relName = getRelationName(reqObject.trim(), getString("appobject"), reqObject.trim().length());
/* 1055 */     setValue("reqrelation", relName, 2L);
/* 1056 */     MboRemote respMbo = getMboSet("RESPONSEMBOS").getMbo(0);
/* 1057 */     if (respMbo != null)
/*      */     {
/* 1059 */       respObject = respMbo.getString("wsioobjname");
/* 1060 */       setValue("resprelation", respObject, 2L);
/*      */     }
/*      */     else
/*      */     {
/* 1064 */       setValueNull("resprelation", 2L);
/*      */     }
/* 1066 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/* 1068 */       INTERACTIONLOGGER.debug("request relationship " + relName);
/* 1069 */       INTERACTIONLOGGER.debug("Response relationship " + respObject);
/*      */     }
/* 1071 */     this.intGeneratorInfo.setReqRelationName(relName);
/* 1072 */     this.intGeneratorInfo.setInteractionMainObject(getString("appobject"));
/* 1073 */     if (this.obpInfo == null)
/*      */     {
/* 1075 */       throw new MXApplicationException("system", "major");
/*      */     }
/* 1077 */     EBPGenerator ebpGen = new EBPGenerator(getString("interaction"));
/* 1078 */     EndpointInfo endpointInfo = ebpGen.createEndpoint(this.wsdlInfo, getString("servicename"), getString("portname"), getString("operation"));
/*      */ 
/* 1080 */     INTERACTIONLOGGER.debug("After end point generation ");
/* 1081 */     this.intGeneratorInfo.setEndpointInfo(endpointInfo);

/*      */     try
/*      */     {
/* 1085 */       if (IntegrationContext.getCurrentContext() == null)
/*      */       {
/* 1087 */         IntegrationContext.createCurrentContext();
/* 1088 */         created = true;
/*      */       }
/* 1090 */       IntegrationContext.getCurrentContext().setProperty("WSIOTXN", "1");
/* 1091 */       WSIOMaxArtifactsCreator.create(this.optimizedRequest, this.optimizedResponse, this.intGeneratorInfo, usrInfo, trans);
/*      */ 
/* 1093 */       INTERACTIONLOGGER.debug("After WSIO artifcts generation ");




/*      */ 
/* 1099 */       String intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", getString("intmode"));

/*      */ 
/* 1102 */       Vector allUserGroups = getMboSet("APPLICATIONAUTH").getSelection();
/* 1103 */       OptionGenerator optionGen = new OptionGenerator();
/* 1104 */       String optionName = optionGen.addOption(getString("appname"), getString("interaction"), getString("optdescription"), usrInfo, getBoolean("genmenuoption"), trans, allUserGroups, intMode.equals("SILENT"));
/*      */ 
/* 1106 */       setValue("mapoption", optionName, 2L);
/* 1107 */       INTERACTIONLOGGER.debug("After UI artifcts generation ");
/*      */ 
/* 1109 */       if (getBoolean("generatedialog"))
/*      */       {
/* 1111 */         DialogGenerator dialogGen = new DialogGenerator();
/* 1112 */         presentationXML = dialogGen.generateDialog(this, presentataion);
/*      */       }
/* 1114 */       INTERACTIONLOGGER.debug("After Dialog artifcts generation ");














/*      */ 
/* 1130 */       IntArtifactsGenerator artifactsGenerator = new IntArtifactsGenerator();
/* 1131 */       artifactsGenerator.createInteraction(this);
/* 1132 */       INTERACTIONLOGGER.debug("After Interaction artifcts generation ");
/*      */ 
/* 1134 */       logStep(9, label);
/* 1135 */       trans.save();
/* 1136 */       trans.commit();
/* 1137 */       INTERACTIONLOGGER.debug("After commit ");
/* 1138 */       InteractionUtil.reloadCache(this.optimizedRequest, this.optimizedResponse);
/* 1139 */       MXServer.getMXServer().reloadMaximoCache(InteractionCache.getInstance().getName(), true);
/*      */     }
/*      */     finally
/*      */     {
/* 1143 */       if (created)
/*      */       {
/* 1145 */         IntegrationContext.destroyCurrentContext();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1150 */     return presentationXML;
/*      */   }







/*      */   public LinkedHashMap<String, String> addRemoveID(String id)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1162 */     if (id == null)
/*      */     {
/* 1164 */       throw new MXApplicationException("jspmessages", "table_noselectedrows");
/*      */     }
/* 1166 */     this.removeMap.put(String.valueOf(MXFormat.stringToInt(id)), id);
/* 1167 */     return this.removeMap;
/*      */   }









/*      */   public LinkedHashMap<String, String> undoRemove(String id)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1181 */     if (id == null)
/*      */     {
/* 1183 */       throw new MXApplicationException("jspmessages", "table_noselectedrows");
/*      */     }
/* 1185 */     this.removeMap.remove(String.valueOf(MXFormat.stringToInt(id)));
/* 1186 */     return this.removeMap;
/*      */   }







/*      */   public LinkedHashMap<String, String> undoAllRemove()
/*      */     throws MXException, RemoteException
/*      */   {
/* 1198 */     this.removeMap.clear();
/* 1199 */     return this.removeMap;
/*      */   }







/*      */   public LinkedHashMap<String, String> undoRemoveLast()
/*      */     throws MXException, RemoteException
/*      */   {
/* 1211 */     String id = null;
/* 1212 */     Iterator itr = this.removeMap.keySet().iterator();
/* 1213 */     while (itr.hasNext())
/*      */     {
/* 1215 */       id = (String)itr.next();
/*      */     }
/* 1217 */     this.removeMap.remove(id);
/* 1218 */     return this.removeMap;
/*      */   }








/*      */   public LinkedHashMap<String, String> getRemoveMap()
/*      */     throws MXException, RemoteException
/*      */   {
/* 1231 */     return this.removeMap;
/*      */   }







/*      */   public OBPInfo getOBPInfo()
/*      */     throws MXException, RemoteException
/*      */   {
/* 1243 */     return this.obpInfo;
/*      */   }







/*      */   public OBPGenerator getOBPGenerator()
/*      */     throws MXException, RemoteException
/*      */   {
/* 1255 */     return this.obpGenerator;
/*      */   }










/*      */   public String getParentTbName(String hierPath)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1270 */     String parentName = null;
/* 1271 */     MboSetRemote thisSet = getThisMboSet();
/* 1272 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/* 1274 */       INTERACTIONLOGGER.debug("In parent table name recordtype " + getString("recordtype"));
/*      */     }
/* 1276 */     if (getString("recordtype").equals("INTERACTION"))
/*      */     {
/* 1278 */       parentName = getString("appobject");


/*      */     }
/* 1282 */     else if (hierPath.indexOf("/") == -1)
/*      */     {
/* 1284 */       if (getOwner().getString("recordtype").equals("INTERACTION"))
/*      */       {
/* 1286 */         parentName = getOwner().getString("appobject");
/*      */       }
/*      */       else
/*      */       {
/* 1290 */         parentName = getOwner().getString("objectname");
/*      */       }
/* 1292 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/* 1294 */         INTERACTIONLOGGER.debug("Parent table name " + parentName);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1299 */       String parentHierPath = hierPath.substring(0, hierPath.lastIndexOf("/"));
/* 1300 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/* 1302 */         INTERACTIONLOGGER.debug("Parent path " + parentHierPath);
/*      */       }
/* 1304 */       MboRemote parent = null;
/* 1305 */       for (int k = 0; ; ++k)
/*      */       {
/* 1307 */         parent = thisSet.getMbo(k);
/* 1308 */         if (parent == null) {
/*      */           break;
/*      */         }
/*      */ 
/* 1312 */         if (parent == this) {
/*      */           continue;
/*      */         }
/*      */ 
/* 1316 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*      */         {
/* 1318 */           INTERACTIONLOGGER.debug("In Mbo Parent path " + parent.getString("hierarchypath"));
/*      */         }
/* 1320 */         if (!(parent.getString("hierarchypath").equals(parentHierPath)))
/*      */           continue;
/* 1322 */         parentName = parent.getString("objectname");
/* 1323 */         if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*      */           break;
/* 1325 */         INTERACTIONLOGGER.debug("Found parent " + parentName); break;


/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1332 */     if (parentName == null)
/*      */     {
/* 1334 */       throw new MXApplicationException("iface", "missingparentobject");
/*      */     }
/* 1336 */     return parentName;
/*      */   }







/*      */   public void checkMappingObject(String colsRelation)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1348 */     MboSetRemote thisSet = getThisMboSet();
/* 1349 */     if (colsRelation != null)
/*      */     {
/* 1351 */       MboSetRemote attrSet = getMboSet(colsRelation);
/* 1352 */       if (!(attrSet.isEmpty()))
/*      */       {
/* 1354 */         throw new MXApplicationException("iface", "cannotchangeobject");
/*      */       }
/*      */     }
/* 1357 */     String hierPath = getString("hierarchypath");
/* 1358 */     MboRemote child = null;
/* 1359 */     for (int k = 0; ; ++k)
/*      */     {
/* 1361 */       child = thisSet.getMbo(k);
/* 1362 */       if (child == null) {
/*      */         return;
/*      */       }
/*      */ 
/* 1366 */       if (child == this) {
/*      */         continue;
/*      */       }
/*      */ 
/* 1370 */       if ((!(child.getString("hierarchypath").startsWith(hierPath))) || 

/* 1372 */         (child.isNull("objectname")))
/*      */         continue;
/* 1374 */       throw new MXApplicationException("iface", "cannotchangeobject");
/*      */     }
/*      */   }










/*      */   private String getOSName(String objectStructureName, int length)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1390 */     String osName = objectStructureName;
/* 1391 */     MosInfo mosInfo = ObjectStructureCache.getInstance().getMosInfo(osName);
/* 1392 */     if (mosInfo != null)
/*      */     {
/* 1394 */       String origName = osName.substring(0, length);
/* 1395 */       int count = 0;
/* 1396 */       if (osName.length() > length)
/* 1397 */         count = new Integer(osName.substring(length)).intValue();
/* 1398 */       osName = getOSName(origName.concat(String.valueOf(++count)), length);
/*      */     }
/* 1400 */     return osName;
/*      */   }








/*      */   private String getInvkChannelName(String invkChannelName, int length)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1413 */     String invkName = invkChannelName;
/* 1414 */     InvokeChannel invkChannel = InvokeChannelCache.getInstance().getInvokeChannel(invkName);
/* 1415 */     if (invkChannel != null)
/*      */     {
/* 1417 */       String origName = invkName.substring(0, length);
/* 1418 */       int count = 0;
/* 1419 */       if (invkName.length() > length)
/* 1420 */         count = new Integer(invkName.substring(length)).intValue();
/* 1421 */       invkName = getInvkChannelName(origName.concat(String.valueOf(++count)), length);
/*      */     }
/* 1423 */     return invkName;
/*      */   }








/*      */   private String getEndPointName(String endPointName, int length)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1436 */     String epName = endPointName;
/* 1437 */     MaxEndPointInfo epInfo = EndPointCache.getInstance().getEndPointInfo(epName);
/* 1438 */     if (epInfo != null)
/*      */     {
/* 1440 */       String origName = epName.substring(0, length);
/* 1441 */       int count = 0;
/* 1442 */       if (epName.length() > length)
/* 1443 */         count = new Integer(epName.substring(length)).intValue();
/* 1444 */       epName = getEndPointName(origName.concat(String.valueOf(++count)), length);
/*      */     }
/* 1446 */     return epName;
/*      */   }









/*      */   private String getObjectName(String objectName, Util util, int length)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1460 */     String objName = objectName;
/* 1461 */     MboSetInfo mboSetInfo = MXServer.getMXServer().getMaximoDD().getMboSetInfo(objName);
/* 1462 */     if (mboSetInfo != null)
/*      */     {
/* 1464 */       String origName = objName.substring(0, length);
/* 1465 */       int count = 0;
/* 1466 */       if (objName.length() > length)
/* 1467 */         count = new Integer(objName.substring(length)).intValue();
/* 1468 */       objName = getObjectName(origName.concat(String.valueOf(++count)), util, length);
/*      */     }
/*      */     else
/*      */     {
/*      */       try
/*      */       {
/* 1474 */         if (util.nativeTableExists(objName))
/*      */         {
/* 1476 */           String origName = objName.substring(0, length);
/* 1477 */           int count = 0;
/* 1478 */           if (objName.length() > length)
/* 1479 */             count = new Integer(objName.substring(length)).intValue();
/* 1480 */           objName = getObjectName(origName.concat(String.valueOf(++count)), util, length);
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1485 */         if (e instanceof MXException)
/* 1486 */           throw ((MXException)e);
/* 1487 */         throw new MXApplicationException("system", "major", e);
/*      */       }
/*      */     }
/* 1490 */     return objName;
/*      */   }











/*      */   private String getRelationName(String relationName, String mainObjName, int length)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1506 */     String relName = relationName;
/* 1507 */     MboSetRemote relationSet = MXServer.getMXServer().getMboSet("MAXRELATIONSHIP", getUserInfo());
/* 1508 */     SqlFormat sqf = new SqlFormat(getUserInfo(), "name = :1 and parent = :2");
/* 1509 */     sqf.setObject(1, "MAXRELATIONSHIP", "NAME", relName);
/* 1510 */     sqf.setObject(2, "MAXRELATIONSHIP", "PARENT", mainObjName);
/* 1511 */     relationSet.setWhere(sqf.format());
/* 1512 */     if (!(relationSet.isEmpty()))
/*      */     {
/* 1514 */       String origName = relName.substring(0, length);
/* 1515 */       int count = 0;
/* 1516 */       if (relName.length() > length)
/* 1517 */         count = new Integer(relName.substring(length)).intValue();
/* 1518 */       relName = getRelationName(origName.concat(String.valueOf(++count)), mainObjName, length);
/*      */     }
/* 1520 */     return relName;
/*      */   }






/*      */   public void setWSIO(WSIO in)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1531 */     this.wsio = in;
/*      */   }






/*      */   public void setWSIOAttribute(WSIOAttribute inAttr)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1542 */     this.wsioAttribute = inAttr;
/*      */   }






/*      */   public WSIO getWSIO()
/*      */     throws MXException, RemoteException
/*      */   {
/* 1553 */     return this.wsio;
/*      */   }






/*      */   public WSIOAttribute getWSIOAttribute()
/*      */     throws MXException, RemoteException
/*      */   {
/* 1564 */     return this.wsioAttribute;
/*      */   }










/*      */   public MboSetRemote fillAttributes(MboRemote parent, MboRemote thisMbo, boolean removeExisting)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1579 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*      */     {
/* 1581 */       INTERACTIONLOGGER.debug("Object name is " + parent.getString("objectname"));
/*      */     }
/* 1583 */     if (parent.isNull("objectname"))
/*      */     {
/* 1585 */       throw new MXApplicationException("iface", "missingmapobject");
/*      */     }
/* 1587 */     Map existingAttr = null;
/* 1588 */     MboSetRemote attrSet = parent.getMboSet("SELECTATTR");
/* 1589 */     attrSet.clear();
/* 1590 */     if (parent.getString("recordtype").equals("REQUESTOBJECT"))
/*      */     {
/* 1592 */       if (removeExisting)
/*      */       {
/* 1594 */         existingAttr = getExistingAttributes(parent.getMboSet("REQUESTMAPPING"), thisMbo);
/*      */       }
/* 1596 */       MboSetRemote allAttributeSet = parent.getMboSet("REQATTRIBUTES");
/* 1597 */       MboRemote list = null;
/* 1598 */       for (int i = 0; ; ++i)
/*      */       {
/* 1600 */         list = allAttributeSet.getMbo(i);
/* 1601 */         if (list == null) {
/*      */           break;
/*      */         }
/*      */ 
/* 1605 */         if ((existingAttr != null) && (existingAttr.containsKey(list.getString("attributename")))) {
/*      */           continue;
/*      */         }
/*      */ 
/* 1609 */         MboRemote attr = attrSet.addAtEnd();
/* 1610 */         attr.setValue("attributename", list.getString("attributename"));
/* 1611 */         attr.setValue("wsioobjname", list.getString("wsioobjname"));
/* 1612 */         attr.setValue("hierarchypath", list.getString("hierarchypath"));
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1617 */       if (removeExisting)
/*      */       {
/* 1619 */         existingAttr = getExistingAttributes(parent.getMboSet("RESPONSEMAPPING"), thisMbo);
/*      */       }
/* 1621 */       Iterator itr = MXServer.getMXServer().getMaximoDD().getMboSetInfo(parent.getString("objectname")).getAttributes();
/* 1622 */       ArrayList attrList = new ArrayList();
/* 1623 */       while (itr.hasNext())
/*      */       {
/* 1625 */         MboValueInfo info = (MboValueInfo)itr.next();
/* 1626 */         if ((existingAttr != null) && (existingAttr.containsKey(info.getName()))) {
/*      */           continue;
/*      */         }
/*      */ 
/* 1630 */         attrList.add(info.getName());
/*      */       }
/* 1632 */       Collections.sort(attrList);
/* 1633 */       Iterator attritr = attrList.iterator();
/* 1634 */       while (attritr.hasNext())
/*      */       {
/* 1636 */         String name = (String)attritr.next();
/* 1637 */         MboRemote attr = attrSet.addAtEnd();
/* 1638 */         attr.setValue("attributename", name);
/* 1639 */         attr.setValue("wsioobjname", parent.getString("objectname"));
/* 1640 */         attr.setValue("objectname", parent.getString("objectname"));
/*      */       }
/*      */     }
/*      */ 
/* 1644 */     return attrSet;
/*      */   }








/*      */   public Map<String, String> getExistingAttributes(MboSetRemote set, MboRemote thisMbo)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1657 */     Map existingAttr = null;
/* 1658 */     MboRemote mbo = null;
/* 1659 */     for (int i = 0; ; ++i)
/*      */     {
/* 1661 */       mbo = set.getMbo(i);
/* 1662 */       if (mbo == null) {
/*      */         break;
/*      */       }
/*      */ 
/* 1666 */       if (mbo == thisMbo) {
/*      */         break;
/*      */       }
/*      */ 
/* 1670 */       if (existingAttr == null)
/*      */       {
/* 1672 */         existingAttr = new HashMap();
/*      */       }
/* 1674 */       existingAttr.put(mbo.getString("attributename"), mbo.getString("attributename"));
/*      */     }
/* 1676 */     return existingAttr;
/*      */   }









/*      */   public void logStep(int step, String label)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1690 */     if (!(INTERACTIONLOGGER.isInfoEnabled()))
/*      */     {
/* 1692 */       return;
/*      */     }
/* 1694 */     if (step == 0)
/*      */     {
/* 1696 */       INTERACTIONLOGGER.info("*******************************************");
/* 1697 */       INTERACTIONLOGGER.info(getThisMboSet().getMessage("iface", "interaction_started"));
/* 1698 */       INTERACTIONLOGGER.info(label);
/* 1699 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("interaction").getTitle() + ": " + getString("interaction"));
/*      */ 
/* 1701 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("description").getTitle() + ": " + getString("description"));
/*      */ 
/* 1703 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("url").getTitle() + ": " + getString("url"));
/*      */ 
/* 1705 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("servicename").getTitle() + ": " + getString("servicename"));
/*      */ 
/* 1707 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("portname").getTitle() + ": " + getString("portname"));
/*      */ 
/* 1709 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("operation").getTitle() + ": " + getString("operation"));
/*      */ 
/* 1711 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("processresponse").getTitle() + ": " + getBoolean("processresponse"));
/*      */ 
/* 1713 */       INTERACTIONLOGGER.info("*******************************************");
/*      */     }
/* 1715 */     else if (step == 4)
/*      */     {
/* 1717 */       INTERACTIONLOGGER.info("*******************************************");
/* 1718 */       INTERACTIONLOGGER.info(label);
/* 1719 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("appname").getTitle() + ": " + getString("appname"));
/*      */ 
/* 1721 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("appobject").getTitle() + ": " + getString("appobject"));
/*      */ 
/* 1723 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("mapoption").getTitle() + ": " + getString("mapoption"));
/*      */ 
/* 1725 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("optdescription").getTitle() + ": " + getString("optdescription"));
/*      */ 
/* 1727 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("intmode").getTitle() + ":" + getString("intmode"));
/*      */ 
/* 1729 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("applyresponse").getTitle() + ": " + getBoolean("applyresponse"));
/*      */ 
/* 1731 */       INTERACTIONLOGGER.info("-----");
/* 1732 */       Vector sel = getMboSet("APPLICATIONAUTH").getSelection();
/* 1733 */       for (int i = 0; i < sel.size(); ++i)
/*      */       {
/* 1735 */         MboRemote aut = (MboRemote)sel.get(i);
/* 1736 */         INTERACTIONLOGGER.info(aut.getMboValueInfoStatic("groupname").getTitle() + ": " + aut.getString("groupname"));
/*      */       }
/*      */ 
/* 1739 */       INTERACTIONLOGGER.info("*******************************************");
/*      */     } else {
/* 1741 */       if (step != 9)
/*      */         return;
/* 1743 */       INTERACTIONLOGGER.info("*******************************************");
/* 1744 */       INTERACTIONLOGGER.info(label);
/* 1745 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("interaction").getTitle() + ": " + getString("interaction"));
/*      */ 
/* 1747 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("description").getTitle() + ": " + getString("description"));
/*      */ 
/* 1749 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("url").getTitle() + ": " + getString("url"));
/*      */ 
/* 1751 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("servicename").getTitle() + ": " + getString("servicename"));
/*      */ 
/* 1753 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("portname").getTitle() + ": " + getString("portname"));
/*      */ 
/* 1755 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("operation").getTitle() + ": " + getString("operation"));
/*      */ 
/* 1757 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("appname").getTitle() + ": " + getString("appname"));
/*      */ 
/* 1759 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("appobject").getTitle() + ": " + getString("appobject"));
/*      */ 
/* 1761 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("mapoption").getTitle() + ": " + getString("mapoption"));
/*      */ 
/* 1763 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("optdescription").getTitle() + ": " + getString("optdescription"));
/*      */ 
/* 1765 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("intmode").getTitle() + ": " + getString("intmode"));
/*      */ 
/* 1767 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("invchannelname").getTitle() + ": " + getString("invchannelname"));
/*      */ 
/* 1769 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("reqosname").getTitle() + ": " + getString("reqosname"));
/*      */ 
/* 1771 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("resposname").getTitle() + ": " + getString("resposname"));
/*      */ 
/* 1773 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("endpointname").getTitle() + ": " + getString("endpointname"));
/*      */ 
/* 1775 */       INTERACTIONLOGGER.info(getThisMboSet().getMessage("iface", "interaction_ended"));
/* 1776 */       INTERACTIONLOGGER.info("*******************************************");
/*      */     }
/*      */   }









/*      */   public void logWSIOStep(boolean isReq, String label)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1791 */     String objectRelation = null;
/* 1792 */     String attributeRelation = null;
/*      */ 
/* 1794 */     if (!(INTERACTIONLOGGER.isInfoEnabled()))
/*      */     {
/* 1796 */       return;
/*      */     }
/* 1798 */     INTERACTIONLOGGER.info("*******************************************");
/* 1799 */     INTERACTIONLOGGER.info(label);
/* 1800 */     if (isReq)
/*      */     {
/* 1802 */       objectRelation = "REQUESTMBOS";
/* 1803 */       attributeRelation = "REQATTRIBUTES";
/* 1804 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("reqosname").getTitle() + ": " + getString("reqosname"));
/*      */ 
/* 1806 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/* 1808 */         OBPInfo info = this.obpInfo.createNewInstance(this.optimizedRequest, null);
/* 1809 */         XMLUtils.writeBytesToXMLFile(OBPGenerator.toBytes(info), InteractionUtil.getFileName(getString("interaction"), "request"));
/* 1810 */         INTERACTIONLOGGER.debug(getMboValueInfoStatic("isreqmultiple").getTitle() + ": " + getBoolean("isreqmultiple"));
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1816 */       objectRelation = "RESPONSEMBOS";
/* 1817 */       attributeRelation = "RESPATTRIBUTES";
/* 1818 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("resposname").getTitle() + ": " + getString("resposname"));
/*      */ 
/* 1820 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*      */       {
/* 1822 */         OBPInfo info = this.obpInfo.createNewInstance(null, this.optimizedResponse);
/* 1823 */         XMLUtils.writeBytesToXMLFile(OBPGenerator.toBytes(info), InteractionUtil.getFileName(getString("interaction"), "response"));
/* 1824 */         INTERACTIONLOGGER.debug(getMboValueInfoStatic("isrespmultiple").getTitle() + ": " + getBoolean("isrespmultiple"));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1829 */     INTERACTIONLOGGER.info("----");
/* 1830 */     MboSetRemote objectSet = getMboSet(objectRelation);
/* 1831 */     MboRemote objectMbo = null;
/* 1832 */     for (int l = 0; ; ++l)
/*      */     {
/* 1834 */       objectMbo = objectSet.getMbo(l);
/* 1835 */       if (objectMbo == null) {
/*      */         break;
/*      */       }
/*      */ 
/* 1839 */       INTERACTIONLOGGER.info(objectMbo.getMboValueInfoStatic("wsioobjname").getTitle() + ": " + objectMbo.getString("wsioobjname"));
/*      */ 
/* 1841 */       INTERACTIONLOGGER.info(objectMbo.getMboValueInfoStatic("title").getTitle() + ": " + objectMbo.getString("title"));
/*      */ 
/* 1843 */       INTERACTIONLOGGER.info(objectMbo.getMboValueInfoStatic("sourceelement").getTitle() + ": " + objectMbo.getString("sourceelement"));
/*      */ 
/* 1845 */       MboSetRemote attrSet = objectMbo.getMboSet(attributeRelation);
/* 1846 */       MboRemote attrMbo = null;
/* 1847 */       for (int k = 0; ; ++k)
/*      */       {
/* 1849 */         attrMbo = attrSet.getMbo(k);
/* 1850 */         if (attrMbo == null) {
/*      */           break;
/*      */         }
/*      */ 
/* 1854 */         INTERACTIONLOGGER.info(attrMbo.getMboValueInfoStatic("attributename").getTitle() + ": " + attrMbo.getString("attributename"));
/*      */ 
/* 1856 */         INTERACTIONLOGGER.info(attrMbo.getMboValueInfoStatic("title").getTitle() + ":" + attrMbo.getString("title"));
/*      */ 
/* 1858 */         INTERACTIONLOGGER.info(attrMbo.getMboValueInfoStatic("sourceelement").getTitle() + ": " + attrMbo.getString("hierarchypath"));
/*      */       }
/*      */ 
/* 1861 */       INTERACTIONLOGGER.info("----");
/*      */     }
/* 1863 */     INTERACTIONLOGGER.info("*******************************************");
/*      */   }

















/*      */   public void logMappingStep(boolean isReq, String label, String wsioObjectName, String objectName, String objectRelationName, String attributeName, String locationPath, String value)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1885 */     String objectRelation = null;
/* 1886 */     String attributeRelation = null;
/*      */ 
/* 1888 */     if (!(INTERACTIONLOGGER.isInfoEnabled()))
/*      */     {
/* 1890 */       return;
/*      */     }
/* 1892 */     INTERACTIONLOGGER.info("*******************************************");
/* 1893 */     INTERACTIONLOGGER.info(label);
/* 1894 */     if (isReq)
/*      */     {
/* 1896 */       objectRelation = "REQUESTMBOS";
/* 1897 */       attributeRelation = "REQUESTMAPPING";
/* 1898 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("reqclassname").getTitle() + ": " + getString("reqclassname"));

/*      */     }
/*      */     else
/*      */     {
/* 1903 */       objectRelation = "RESPONSEMBOS";
/* 1904 */       attributeRelation = "RESPONSEMAPPING";
/* 1905 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("respclassname").getTitle() + ": " + getString("respclassname"));
/*      */ 
/* 1907 */       INTERACTIONLOGGER.info(getMboValueInfoStatic("commitresponse").getTitle() + ": " + getBoolean("commitresponse"));

/*      */     }
/*      */ 
/* 1911 */     INTERACTIONLOGGER.info("----");
/* 1912 */     MboSetRemote objectSet = getMboSet(objectRelation);
/* 1913 */     MboRemote object = null;
/* 1914 */     for (int l = 0; ; ++l)
/*      */     {
/* 1916 */       object = objectSet.getMbo(l);
/* 1917 */       if (object == null) {
/*      */         break;
/*      */       }
/*      */ 
/* 1921 */       if (object.isNull("objectname")) {
/*      */         continue;
/*      */       }
/*      */ 
/* 1925 */       INTERACTIONLOGGER.info(wsioObjectName + ": " + object.getString("wsioobjname"));
/*      */ 
/* 1927 */       INTERACTIONLOGGER.info(object.getMboValueInfoStatic("title").getTitle() + ": " + object.getString("title"));
/*      */ 
/* 1929 */       INTERACTIONLOGGER.info(objectName + ": " + object.getString("objectname"));
/*      */ 
/* 1931 */       INTERACTIONLOGGER.info(objectRelationName + ": " + object.getString("apprelation"));
/*      */ 
/* 1933 */       INTERACTIONLOGGER.info(object.getMboValueInfoStatic("useparent").getTitle() + ": " + object.getBoolean("useparent"));
/*      */ 
/* 1935 */       MboSetRemote attrSet = object.getMboSet(attributeRelation);
/* 1936 */       MboRemote attrMbo = null;
/* 1937 */       for (int k = 0; ; ++k)
/*      */       {
/* 1939 */         attrMbo = attrSet.getMbo(k);
/* 1940 */         if (attrMbo == null) {
/*      */           break;
/*      */         }
/*      */ 
/* 1944 */         INTERACTIONLOGGER.info(attributeName + ": " + attrMbo.getString("attributename"));
/*      */ 
/* 1946 */         INTERACTIONLOGGER.info(locationPath + ": " + attrMbo.getString("hierarchypath"));
/*      */ 
/* 1948 */         INTERACTIONLOGGER.info(value + ": " + attrMbo.getString("value"));
/*      */       }
/*      */ 
/* 1951 */       INTERACTIONLOGGER.info("----");
/*      */     }
/* 1953 */     INTERACTIONLOGGER.info("*******************************************");
/*      */   }





/*      */   public void logCancel()
/*      */     throws MXException, RemoteException
/*      */   {
/* 1963 */     if (!(INTERACTIONLOGGER.isInfoEnabled()))
/*      */     {
/* 1965 */       return;
/*      */     }
/* 1967 */     INTERACTIONLOGGER.info("*******************************************");
/* 1968 */     INTERACTIONLOGGER.info(getThisMboSet().getMessage("iface", "interaction_canceled"));
/* 1969 */     INTERACTIONLOGGER.info("*******************************************");
/*      */   }









/*      */   public void logUISelectionStep(boolean isReq, String label)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1983 */     String objectRelation = null;
/* 1984 */     String attributeRelation = null;
/*      */ 
/* 1986 */     if (!(INTERACTIONLOGGER.isInfoEnabled()))
/*      */     {
/* 1988 */       return;
/*      */     }
/* 1990 */     INTERACTIONLOGGER.info("*******************************************");
/* 1991 */     INTERACTIONLOGGER.info(label);
/* 1992 */     if (isReq)
/*      */     {
/* 1994 */       objectRelation = "REQUESTMBOS";
/* 1995 */       attributeRelation = "REQATTRIBUTES";
/*      */     }
/*      */     else
/*      */     {
/* 1999 */       objectRelation = "RESPONSEMBOS";
/* 2000 */       attributeRelation = "RESPATTRIBUTES";
/*      */     }
/*      */ 
/* 2003 */     MboSetRemote objectSet = getMboSet(objectRelation);
/* 2004 */     MboRemote object = null;
/* 2005 */     for (int l = 0; ; ++l)
/*      */     {
/* 2007 */       object = objectSet.getMbo(l);
/* 2008 */       if (object == null) {
/*      */         break;
/*      */       }
/*      */ 
/* 2012 */       INTERACTIONLOGGER.info(object.getMboValueInfoStatic("wsioobjname").getTitle() + ": " + object.getString("wsioobjname"));
/*      */ 
/* 2014 */       INTERACTIONLOGGER.info(object.getMboValueInfoStatic("title").getTitle() + ": " + object.getString("title"));
/*      */ 
/* 2016 */       Vector sel = object.getMboSet(attributeRelation).getSelection();
/* 2017 */       MboRemote attr = null;
/* 2018 */       for (int i = 0; i < sel.size(); ++i)
/*      */       {
/* 2020 */         attr = (MboRemote)sel.get(i);
/* 2021 */         INTERACTIONLOGGER.info(attr.getMboValueInfoStatic("attributename").getTitle() + ": " + attr.getString("attributename"));
/*      */ 
/* 2023 */         INTERACTIONLOGGER.info(attr.getMboValueInfoStatic("title").getTitle() + ": " + attr.getString("title"));
/*      */ 
/* 2025 */         INTERACTIONLOGGER.info(attr.getMboValueInfoStatic("readonly").getTitle() + ": " + attr.getBoolean("readonly"));
/*      */       }
/*      */ 
/* 2028 */       INTERACTIONLOGGER.info("----");
/*      */     }
/* 2030 */     INTERACTIONLOGGER.info("*******************************************");
/*      */   }
/*      */ }
