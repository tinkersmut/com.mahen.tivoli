package com.ibm.tivoli.maximo.interaction.app.manageint;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public abstract interface MaxIntMappingDetailSetRemote extends MboSetRemote
{
  public abstract MboSetRemote fillAttributes(MboRemote paramMboRemote1, MboRemote paramMboRemote2)
    throws MXException, RemoteException;
}
