/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 
























/*    */ public class FldSelected extends MboValueAdapter
/*    */ {
/*    */   public FldSelected(MboValue mbv)
/*    */     throws MXException
/*    */   {
/* 39 */     super(mbv);
/*    */   }




/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 48 */     MboValue value = getMboValue();
/* 49 */     MboRemote thisMbo = value.getMbo();
/*    */ 
/* 51 */     if (!(value.getBoolean()))
/*    */     {
/* 53 */       return;
/*    */     }
/*    */ 
/* 56 */     for (int j = 0; ; ++j)
/*    */     {
/* 58 */       MboRemote searchMbo = thisMbo.getThisMboSet().getMbo(j);
/* 59 */       if (searchMbo == null) {
/*    */         return;
/*    */       }
/*    */ 
/* 63 */       if (searchMbo == thisMbo) {
/*    */         continue;
/*    */       }
/*    */ 
/* 67 */       searchMbo.setValue("selected", false, 11L);
/*    */     }
/*    */   }
/*    */ }
