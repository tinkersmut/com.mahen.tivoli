/*     */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.generate.ActionGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.generate.DialogGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.generate.OptionGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.generate.WSIOMaxArtifactsRemove;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionMigrator;
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionValidator;
/*     */ import java.io.PrintStream;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Connection;
/*     */ import java.util.List;
/*     */ import psdi.app.configure.ConfigureService;
/*     */ import psdi.iface.util.XMLUtils;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.txn.MXTransaction;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ 

























/*     */ public class MaxInteraction extends Mbo
/*     */   implements MaxInteractionRemote
/*     */ {
/*     */   public MaxInteraction(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  60 */     super(ms);
/*     */   }





/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  70 */     super.init();
/*     */     try
/*     */     {
/*  73 */       if (toBeAdded())
/*     */       {
/*  75 */         return;
/*     */       }
/*  77 */       SqlFormat sqf = new SqlFormat(getUserInfo(), "ifacename = :1");
/*  78 */       sqf.setObject(1, "MAXIFACEINVOKE", "IFACENAME", getString("channelname"));
/*  79 */       MboSetRemote invokeSet = MXServer.getMXServer().getMboSet("MAXIFACEINVOKE", getUserInfo());
/*  80 */       invokeSet.setWhere(sqf.format());
/*  81 */       MboRemote invoke = invokeSet.moveFirst();
/*  82 */       if (invoke == null)
/*     */       {
/*  84 */         String[] params = { getString("channelname") };
/*  85 */         throw new MXApplicationException("iface", "InvalidIMChannel", params);
/*     */       }
/*  87 */       setValue("reqosname", invoke.getString("intobjectname"), 2L);
/*  88 */       setValue("resposname", invoke.getString("replyintobjname"), 2L);
/*  89 */       if (!(getBoolean("applyresponse")))
/*     */       {
/*  91 */         setFieldFlag("commitresponse", 7L, true);
/*     */       }
/*  93 */       String intMode = getTranslator().toInternalString("INTMODE", getString("intmode"));
/*  94 */       if ((intMode.equals("SILENT")) || (intMode.equals("SHOWREQONLY")))
/*     */       {
/*  96 */         setFieldFlag("showsingleresponse", 7L, true);
/*     */       }
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/* 101 */       throw new MXSystemException("system", "unknownobject", re);
/*     */     }
/*     */   }





/*     */   public void add()
/*     */     throws MXException, RemoteException
/*     */   {
/* 112 */     setValue("changedate", MXServer.getMXServer().getDate(), 11L);
/* 113 */     setValue("changeby", getUserName(), 11L);
/*     */   }

/*     */   public String deleteInteraction(byte[] presentataion) throws MXException, RemoteException {
/* 117 */     Connection con = null;
/* 118 */     String presentationXML = null;
/*     */     try
/*     */     {
/* 121 */       con = getMboServer().getDBConnection(getUserInfo().getConnectionKey());
/* 122 */       delete();
/*     */ 
/* 124 */       UserInfo ui = getUserInfo();
/* 125 */       String resetLang = ui.getLangCode();
/* 126 */       ui.setLangCode(MXServer.getMXServer().getBaseLang());
/* 127 */       MXTransaction trans = getThisMboSet().getMXTransaction();
/*     */ 
/* 129 */       OptionGenerator optionGen = new OptionGenerator();
/* 130 */       optionGen.deleteOption(getString("appname"), getString("mapoption"), ui, trans);
/*     */ 
/* 132 */       String intMode = getTranslator().toInternalString("INTMODE", getString("intmode"));
/* 133 */       if (intMode.equals("SILENT"))
/*     */       {
/* 135 */         ActionGenerator actionGen = new ActionGenerator();
/* 136 */         actionGen.deleteAction(getString("mapoption"), getUserInfo(), getMXTransaction());
/*     */       }
/*     */ 
/* 139 */       if (!(isNull("dialogid")))
/*     */       {
/* 141 */         dialogGen = new DialogGenerator();
/* 142 */         presentationXML = dialogGen.removeDialog(XMLUtils.convertBytesToDocument(presentataion), getString("dialogid"));
/*     */       }
/*     */ 
/* 145 */       WSIOMaxArtifactsRemove.remove(getString("interaction"), ui, trans);
/*     */ 
/* 147 */       ui.setLangCode(resetLang);
/* 148 */       DialogGenerator dialogGen = presentationXML;




/*     */     }
/*     */     catch (MXException me)
/*     */     {
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 162 */       if (con != null)
/*     */ 
/*     */       {/* 164 */       return dialogGen;/* 164 */         getMboServer().freeDBConnection(getUserInfo().getConnectionKey());
/*     */       }
/*     */     }
/*     */   }

/*     */   public void runConfigDB(MboRemote listenerMbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 172 */     ConfigureService cfgSvc = (ConfigureService)MXServer.getMXServer().lookup("CONFIGURE");
/* 173 */     cfgSvc.runConfigDB(listenerMbo);
/*     */   }








/*     */   public String getParentTbName(MboRemote mapObject)
/*     */     throws MXException, RemoteException
/*     */   {
/* 186 */     String parentName = null;
/* 187 */     MboSetRemote mapSet = mapObject.getThisMboSet();
/* 188 */     String hierPath = mapObject.getString("hierarchypath");
/* 189 */     if (hierPath.indexOf("/") == -1)
/*     */     {
/* 191 */       parentName = getString("intmainobject");
/*     */     }
/*     */     else
/*     */     {
/* 195 */       String parentHierPath = hierPath.substring(0, hierPath.lastIndexOf("/"));
/* 196 */       System.out.println("Parent Path " + parentHierPath);
/* 197 */       MboRemote parent = null;
/* 198 */       for (int k = 0; ; ++k)
/*     */       {
/* 200 */         parent = mapSet.getMbo(k);
/* 201 */         if (parent == null) {
/*     */           break;
/*     */         }
/*     */ 
/* 205 */         if (parent == mapObject) {
/*     */           continue;
/*     */         }
/*     */ 
/* 209 */         System.out.println("In parent Parent Path " + parent.getString("hierarchypath"));
/* 210 */         if (!(parent.getString("hierarchypath").equals(parentHierPath)))
/*     */           continue;
/* 212 */         parentName = parent.getString("mapobject");
/* 213 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 217 */     if (parentName == null)
/*     */     {
/* 219 */       throw new MXApplicationException("iface", "noparentforchild");
/*     */     }
/* 221 */     return parentName;
/*     */   }





/*     */   public void checkMappingObject(MboRemote mapObject, String colsRelation)
/*     */     throws MXException, RemoteException
/*     */   {
/* 231 */     MboSetRemote mapSet = mapObject.getThisMboSet();
/* 232 */     System.out.println("Cols relation = " + colsRelation);
/* 233 */     MboSetRemote attrSet = mapObject.getMboSet(colsRelation);
/* 234 */     MboRemote attr = null;
/* 235 */     for (int k = 0; ; ++k)
/*     */     {
/* 237 */       attr = attrSet.getMbo(k);
/* 238 */       if (attr == null) {
/*     */         break;
/*     */       }
/*     */ 
/* 242 */       if (attr.isNull("value")) {
/*     */         continue;
/*     */       }
/*     */ 
/* 246 */       System.out.println("Value = " + attr.getString("value"));
/* 247 */       throw new MXApplicationException("iface", "cannotchangeobject");
/*     */     }
/* 249 */     String hierPath = mapObject.getString("hierarchypath");
/* 250 */     System.out.println("Hier path = " + mapObject.getString("hierarchypath"));
/* 251 */     MboRemote child = null;
/* 252 */     for (int k = 0; ; ++k)
/*     */     {
/* 254 */       child = mapSet.getMbo(k);
/* 255 */       if (child == null) {
/*     */         return;
/*     */       }
/*     */ 
/* 259 */       if (child == mapObject) {
/*     */         continue;
/*     */       }
/*     */ 
/* 263 */       System.out.println("Child path = " + child.getString("hierarchypath"));
/* 264 */       if ((!(child.getString("hierarchypath").startsWith(hierPath))) || 

/* 266 */         (child.isNull("mapobject")))
/*     */         continue;
/* 268 */       throw new MXApplicationException("iface", "cannotchangeobject");
/*     */     }
/*     */   }









/*     */   public boolean validateInteraction()
/*     */     throws MXException, RemoteException
/*     */   {
/* 283 */     InteractionValidator valid = new InteractionValidator(getString("interaction"), getUserInfo());
/* 284 */     List result = valid.validateInteraction(getBoolean("genmenuoption"), !(isNull("dialogid")), getThisMboSet());
/* 285 */     boolean sucess = ((Boolean)result.get(0)).booleanValue();
/* 286 */     StringBuffer adminMsgs = (StringBuffer)result.get(1);
/* 287 */     setValue("status", adminMsgs.toString(), 2L);
/* 288 */     return sucess;
/*     */   }





/*     */   public void exportInteraction()
/*     */     throws MXException, RemoteException
/*     */   {
/* 298 */     InteractionMigrator mg = new InteractionMigrator(getString("interaction"), getMXTransaction(), getUserInfo());
/* 299 */     mg.migrateInteraction();
/*     */   }










/*     */   public void delete(long accessModifier)
/*     */     throws MXException, RemoteException
/*     */   {
/* 314 */     super.delete(accessModifier);

/*     */     try
/*     */     {
/* 318 */       getMboSet("MAXINTPOLICY").deleteAll(2L);
/* 319 */       getMboSet("MAXINTMAPPING").deleteAll(2L);

/*     */     }
/*     */     catch (MXException me)
/*     */     {
/* 324 */       super.undelete();
/*     */ 
/* 326 */       throw me;

/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/* 331 */       super.undelete();
/*     */ 
/* 333 */       throw re;
/*     */     }
/*     */   }











/*     */   public void undelete()
/*     */     throws MXException, RemoteException
/*     */   {
/* 350 */     super.undelete();
/*     */ 
/* 352 */     getMboSet("MAXINTPOLICY").undeleteAll();
/* 353 */     getMboSet("MAXINTMAPPING").undeleteAll();
/*     */   }
/*     */ }
