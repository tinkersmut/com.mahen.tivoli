/*    */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 






















/*    */ public class FldInteractionName extends MboValueAdapter
/*    */ {
/*    */   public FldInteractionName(MboValue mbv)
/*    */   {
/* 35 */     super(mbv);
/*    */   }





/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 45 */     MboValue value = getMboValue();
/* 46 */     if (value.isNull())
/* 47 */       return;
/* 48 */     super.validate();
/*    */ 
/* 50 */     if (!(value.getString().equals("GLOBAL")))
/*    */       return;
/* 52 */     String[] params = { value.getString() };
/* 53 */     throw new MXApplicationException("iface", "interaction_reserve_name", params);
/*    */   }
/*    */ }
