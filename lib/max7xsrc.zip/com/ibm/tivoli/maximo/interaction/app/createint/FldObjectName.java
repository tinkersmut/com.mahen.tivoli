/*     */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 




























/*     */ public class FldObjectName extends MAXTableDomain
/*     */ {
/*     */   public FldObjectName(MboValue mbv)
/*     */   {
/*  43 */     super(mbv);
/*  44 */     setRelationship("MAXOBJECT", "objectname=:objectname");
/*  45 */     setErrorMessage("common", "InvalidObjectName");
/*     */   }







/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  57 */     String colsRelation = null;
/*  58 */     MboValue value = getMboValue();
/*  59 */     MboRemote thisMbo = value.getMbo();
/*  60 */     MboSetRemote thisSet = thisMbo.getThisMboSet();
/*  61 */     if (thisSet.getFlags() < 1048586L)
/*     */     {
/*  63 */       colsRelation = "REQATTRIBUTES";
/*     */     }
/*  65 */     else if (thisSet.getFlags() < 1048596L)
/*     */     {
/*  67 */       colsRelation = "RESPATTRIBUTES";
/*     */     }
/*     */     else
/*     */     {
/*  71 */       return;
/*     */     }
/*  73 */     ((IntGenerator)thisMbo).checkMappingObject(colsRelation);
/*  74 */     if (value.isNull())
/*     */     {
/*  76 */       thisMbo.setValueNull("apprelation", 11L);
/*  77 */       thisMbo.setFieldFlag("apprelation", 7L, false);
/*  78 */       return;
/*     */     }
/*  80 */     String parentName = ((IntGenerator)thisMbo).getParentTbName(thisMbo.getString("hierarchypath"));
/*  81 */     if (!(value.getString().equals(parentName)))
/*     */     {
/*  83 */       throw new MXApplicationException("iface", "cannotchangeobject");
/*     */     }
/*  85 */     thisMbo.setValueNull("apprelation", 11L);
/*  86 */     thisMbo.setFieldFlag("apprelation", 7L, true);
/*  87 */     if (colsRelation == null)
/*     */       return;
/*  89 */     MboSetRemote attrSet = thisMbo.getMboSet(colsRelation);
/*  90 */     MboRemote attr = null;
/*  91 */     for (int k = 0; ; ++k)
/*     */     {
/*  93 */       attr = attrSet.getMbo(k);
/*  94 */       if (attr == null) {
/*     */         return;
/*     */       }
/*     */ 
/*  98 */       attr.setValue("objectname", thisMbo.getString("objectname"), 11L);
/*     */     }
/*     */   }

/*     */   public MboSetRemote getList() throws MXException, RemoteException
/*     */   {
/* 104 */     MboValue value = getMboValue();
/* 105 */     MboRemote thisMbo = value.getMbo();
/* 106 */     MboSetRemote msr = super.getList();
/* 107 */     msr.setWhere("objectname = '" + ((IntGenerator)thisMbo).getParentTbName(thisMbo.getString("hierarchypath")) + "'");
/* 108 */     msr.reset();
/* 109 */     return msr;
/*     */   }
/*     */ }
