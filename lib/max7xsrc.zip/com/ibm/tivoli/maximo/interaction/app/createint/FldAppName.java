/*     */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 



















/*     */ public class FldAppName extends MAXTableDomain
/*     */ {
/*     */   public FldAppName(MboValue mbv)
/*     */     throws MXException
/*     */   {
/*  39 */     super(mbv);
/*  40 */     setRelationship("MAXAPPS", "1=1");
/*  41 */     setLookupKeyMapInOrder(new String[] { "appname" }, new String[] { "app" });
/*     */   }








/*     */   public void action()
/*     */     throws MXException, RemoteException
/*     */   {
/*  54 */     MboValue value = getMboValue();
/*  55 */     MboRemote thisMbo = value.getMbo();
/*  56 */     if (!(value.isNull()))
/*     */     {
/*  58 */       MboServerInterface service = getMboValue().getMbo().getMboServer();
/*  59 */       MboSetRemote appSet = service.getMboSet("MAXAPPS", thisMbo.getUserInfo());
/*  60 */       SqlFormat sqf1 = new SqlFormat(thisMbo.getUserInfo(), "app = :1");
/*  61 */       sqf1.setObject(1, "MAXAPPS", "APP", value.getString());
/*  62 */       appSet.setWhere(sqf1.format());
/*  63 */       MboRemote appMbo = appSet.getMbo(0);
/*  64 */       if (appMbo == null)
/*     */       {
/*  66 */         throw new MXApplicationException("appsetup", "appnotfound");
/*     */       }
/*  68 */       String tb = appMbo.getString("maintbname");
/*  69 */       thisMbo.setValue("appobject", tb, 11L);
/*  70 */       thisMbo.setValue("genmenuoption", true, 11L);
/*  71 */       thisMbo.setValue("apprelation", tb, 11L);
/*  72 */       thisMbo.setValue("objectname", tb, 11L);
/*  73 */       thisMbo.setValue("mapoption", thisMbo.getString("interaction"), 11L);
/*  74 */       thisMbo.setValue("optdescription", value.getString() + " " + thisMbo.getString("interaction"), 11L);
/*  75 */       thisMbo.setFieldFlag("genmenuoption", 7L, false);
/*     */     }
/*     */     else
/*     */     {
/*  79 */       thisMbo.setValueNull("optdescription", 11L);
/*  80 */       thisMbo.setValueNull("mapoption", 11L);
/*  81 */       thisMbo.setValueNull("appobject", 11L);
/*  82 */       thisMbo.setValue("genmenuoption", false, 11L);
/*  83 */       thisMbo.setValueNull("apprelation", 11L);
/*  84 */       thisMbo.setValueNull("objectname", 11L);
/*  85 */       thisMbo.setFieldFlag("genmenuoption", 7L, true);
/*     */     }
/*     */   }





/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  96 */     MboValue value = getMboValue();
/*  97 */     MboRemote requestMbo = value.getMbo().getMboSet("REQUESTMBOS").getMbo(0);
/*  98 */     if ((requestMbo != null) && (!(requestMbo.isNull("objectname"))))
/*     */     {
/* 100 */       String[] params = { value.getMboValueInfo().getTitle() };
/* 101 */       throw new MXApplicationException("iface", "cannotchangemainobject", params);
/*     */     }
/* 103 */     MboRemote responseMbo = value.getMbo().getMboSet("RESPONSEMBOS").getMbo(0);
/* 104 */     if ((responseMbo == null) || (responseMbo.isNull("objectname")))
/*     */       return;
/* 106 */     String[] params = { value.getMboValueInfo().getTitle() };
/* 107 */     throw new MXApplicationException("iface", "cannotchangemainobject", params);
/*     */   }
/*     */ }
