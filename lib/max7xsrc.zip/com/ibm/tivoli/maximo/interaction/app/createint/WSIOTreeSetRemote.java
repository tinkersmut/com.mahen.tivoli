package com.ibm.tivoli.maximo.interaction.app.createint;

import com.ibm.tivoli.maximo.interaction.obp.WSIO;
import java.rmi.RemoteException;
import java.util.LinkedHashMap;
import psdi.mbo.MboRemote;
import psdi.mbo.MboValueData;
import psdi.mbo.NonPersistentMboSetRemote;
import psdi.util.MXException;

public abstract interface WSIOTreeSetRemote extends NonPersistentMboSetRemote
{
  public abstract void fill(WSIO paramWSIO, boolean paramBoolean, LinkedHashMap<String, String> paramLinkedHashMap)
    throws MXException, RemoteException;

  public abstract MboValueData[][] getTop(String[] paramArrayOfString, int paramInt)
    throws MXException, RemoteException;

  public abstract MboRemote findMbo(MboRemote paramMboRemote, String paramString)
    throws MXException, RemoteException;
}
