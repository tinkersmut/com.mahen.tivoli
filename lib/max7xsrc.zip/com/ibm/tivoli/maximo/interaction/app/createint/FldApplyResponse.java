/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.mbo.MboValueInfo;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 
























/*    */ public class FldApplyResponse extends MboValueAdapter
/*    */ {
/*    */   public FldApplyResponse(MboValue mbv)
/*    */   {
/* 41 */     super(mbv);
/*    */   }






/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 52 */     MboValue value = getMboValue();
/* 53 */     if (value.getBoolean())
/*    */     {
/* 55 */       return;
/*    */     }
/* 57 */     MboRemote objectMbo = value.getMbo().getMboSet("RESPONSEOBJECT").getMbo(0);
/* 58 */     if ((objectMbo == null) || (objectMbo.isNull("objectname")))
/*    */     {
/* 60 */       return;
/*    */     }
/* 62 */     String[] params = { value.getMboValueInfo().getTitle() };
/* 63 */     throw new MXApplicationException("iface", "cannotchangeapply", params);
/*    */   }
/*    */ }
