/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 

























/*    */ public class FldEncryptValue extends MboValueAdapter
/*    */ {
/*    */   public FldEncryptValue(MboValue mbv)
/*    */     throws MXException
/*    */   {
/* 39 */     super(mbv);
/*    */   }





/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 49 */     MboValue value = getMboValue();
/* 50 */     MboRemote thisMbo = value.getMbo();
/* 51 */     if (value.getBoolean())
/*    */     {
/* 53 */       thisMbo.setFieldFlag("value", 7L, true);
/* 54 */       thisMbo.setFieldFlag("password", 7L, false);
/* 55 */       thisMbo.setValueNull("value", 11L);
/*    */     }
/*    */     else
/*    */     {
/* 59 */       thisMbo.setFieldFlag("value", 7L, false);
/* 60 */       thisMbo.setFieldFlag("password", 7L, true);
/* 61 */       thisMbo.setValueNull("password", 11L);
/*    */     }
/*    */   }
/*    */ }
