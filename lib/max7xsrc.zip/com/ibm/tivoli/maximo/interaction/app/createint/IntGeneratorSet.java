/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.NonPersistentMboSet;
/*    */ import psdi.util.MXException;
/*    */ 





























/*    */ public class IntGeneratorSet extends NonPersistentMboSet
/*    */ {
/* 32 */   protected boolean completed = false;
/*    */ 
/*    */   public IntGeneratorSet(MboServerInterface ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 47 */     super(ms);
/*    */   }












/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 64 */     return new IntGenerator(ms);
/*    */   }






/*    */   public MboRemote setup()
/*    */     throws MXException, RemoteException
/*    */   {
/* 75 */     if (getOwner() == null) {
/* 76 */       return super.setup();
/*    */     }
/* 78 */     return null;
/*    */   }





/*    */   public void execute()
/*    */     throws MXException, RemoteException
/*    */   {
/* 88 */     if (this.completed)
/*    */     {
/* 90 */       save();
/*    */     }
/* 92 */     super.execute();
/*    */   }
/*    */ }
