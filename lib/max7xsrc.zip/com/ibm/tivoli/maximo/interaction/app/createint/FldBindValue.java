/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 



























/*    */ public class FldBindValue extends MboValueAdapter
/*    */ {
/*    */   public FldBindValue(MboValue mbv)
/*    */   {
/* 43 */     super(mbv);
/*    */   }







/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 55 */     MboValue value = getMboValue();
/* 56 */     MboRemote thisMbo = value.getMbo();
/* 57 */     if ((!(thisMbo.getString("recordtype").equals("REQUESTMAPPING"))) && (!(thisMbo.getString("recordtype").equals("RESPONSEMAPPING"))))

/*    */     {
/* 60 */       return;
/*    */     }
/* 62 */     if (value.isNull())
/*    */     {
/* 64 */       value.getMbo().setValueNull("hierarchypath", 11L);
/* 65 */       return;
/*    */     }
/* 67 */     if (thisMbo.getOwner().isNull("objectname"))
/*    */     {
/* 69 */       throw new MXApplicationException("iface", "missingparentobject");
/*    */     }
/* 71 */     if ((value.getString().equals(value.getPreviousValue())) || (!(value.getMbo().getMboValue("hierarchypath").getString().equals(value.getMbo().getMboValue("hierarchypath").getPreviousValue())))) {
/*    */       return;
/*    */     }
/* 74 */     value.getMbo().setValueNull("hierarchypath", 11L);
/* 75 */     return;
/*    */   }




/*    */   public MboSetRemote getList()
/*    */     throws MXException, RemoteException
/*    */   {
/* 84 */     MboRemote thisMbo = getMboValue().getMbo();
/* 85 */     if (thisMbo.getOwner().isNull("objectname"))
/*    */     {
/* 87 */       throw new MXApplicationException("iface", "missingparentobject");
/*    */     }
/* 89 */     return super.getList();
/*    */   }
/*    */ }
