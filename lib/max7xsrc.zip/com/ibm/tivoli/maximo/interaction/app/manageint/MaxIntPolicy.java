/*     */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ 






























/*     */ public class MaxIntPolicy extends Mbo
/*     */ {
/*     */   public MaxIntPolicy(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  45 */     super(ms);
/*     */   }







/*     */   public void add()
/*     */     throws MXException, RemoteException
/*     */   {
/*  57 */     setValue("changedate", MXServer.getMXServer().getDate(), 11L);
/*  58 */     setValue("changeby", getUserName(), 11L);
/*     */   }










/*     */   public void delete(long accessModifier)
/*     */     throws MXException, RemoteException
/*     */   {
/*  73 */     super.delete(accessModifier);

/*     */     try
/*     */     {
/*  77 */       getMboSet("MAXINTPOLICYPARAM").deleteAll(2L);

/*     */     }
/*     */     catch (MXException me)
/*     */     {
/*  82 */       super.undelete();
/*     */ 
/*  84 */       throw me;

/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/*  89 */       super.undelete();
/*     */ 
/*  91 */       throw re;
/*     */     }
/*     */   }







/*     */   public void undelete()
/*     */     throws MXException, RemoteException
/*     */   {
/* 104 */     super.undelete();
/*     */ 
/* 106 */     getMboSet("MAXINTPOLICYPARAM").undeleteAll();
/*     */   }
/*     */ }
