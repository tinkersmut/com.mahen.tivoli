/*     */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Map;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 




















/*     */ public class FldMapAttribute extends MAXTableDomain
/*     */ {
/*     */   public FldMapAttribute(MboValue mbv)
/*     */     throws MXException
/*     */   {
/*  42 */     super(mbv);
/*  43 */     setRelationship("INTGENERATOR", "");
/*  44 */     setLookupKeyMapInOrder(new String[] { "attributename" }, new String[] { "attributename" });
/*     */   }






/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  55 */     String objectName = null;
/*  56 */     MboValue value = getMboValue();
/*  57 */     MboRemote thisMbo = value.getMbo();
/*  58 */     if (!(thisMbo.getOwner().getBoolean("isresponse")))
/*     */     {
/*  60 */       objectName = thisMbo.getOwner().getString("objectname");
/*     */     }
/*     */     else
/*     */     {
/*  64 */       objectName = thisMbo.getOwner().getString("mapobject");
/*     */     }
/*  66 */     if (value.isNull())
/*     */     {
/*  68 */       return;
/*     */     }
/*  70 */     if (value.getString().indexOf(".") == -1)
/*     */     {
/*  72 */       MboValueInfo info = MXServer.getMXServer().getMaximoDD().getMboSetInfo(objectName).getMboValueInfo(value.getString());
/*  73 */       if (info == null)
/*     */       {
/*  75 */         String[] params = { value.getString() };
/*  76 */         throw new MXApplicationException("system", "noattribute", params);
/*     */       }
/*     */     }
/*  79 */     Map existingAttr = ((MaxIntMappingDetailSet)value.getMbo().getThisMboSet()).getExistingAttributes(value.getMbo());
/*  80 */     if (existingAttr == null)
/*     */     {
/*  82 */       return;
/*     */     }
/*  84 */     if (!(existingAttr.containsKey(value.getString())))
/*     */       return;
/*  86 */     throw new MXApplicationException("iface", "attralreadymapped");
/*     */   }








/*     */   public void action()
/*     */     throws MXException, RemoteException
/*     */   {
/*  99 */     MboValue value = getMboValue();
/* 100 */     MboRemote thisMbo = value.getMbo();
/* 101 */     if (thisMbo.getOwner().getBoolean("isresponse"))
/*     */     {
/* 103 */       return;
/*     */     }
/* 105 */     String remarks = ((MaxIntMappingDetailSet)thisMbo.getThisMboSet()).getSourceElement(thisMbo.getString("mapobject"), thisMbo.getString("attributename"));
/* 106 */     if (remarks == null)
/*     */     {
/* 108 */       thisMbo.setValueNull("sourceelement", 11L);
/*     */     }
/*     */     else
/*     */     {
/* 112 */       thisMbo.setValue("sourceelement", remarks, 11L);
/*     */     }
/*     */   }






/*     */   public MboSetRemote getList()
/*     */     throws MXException, RemoteException
/*     */   {
/* 124 */     MboValue value = getMboValue();
/* 125 */     MboRemote thisMbo = value.getMbo();
/* 126 */     return ((MaxIntMappingDetailSet)thisMbo.getThisMboSet()).fillAttributes(thisMbo.getOwner(), thisMbo);
/*     */   }
/*     */ }
