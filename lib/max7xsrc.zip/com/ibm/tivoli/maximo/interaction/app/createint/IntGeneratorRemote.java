package com.ibm.tivoli.maximo.interaction.app.createint;

import java.rmi.RemoteException;
import java.util.LinkedHashMap;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.NonPersistentMboRemote;
import psdi.util.MXException;

public abstract interface IntGeneratorRemote extends NonPersistentMboRemote
{
  public abstract boolean setPortAndOperation()
    throws MXException, RemoteException;

  public abstract MboSetRemote fillAttributes(MboRemote paramMboRemote1, MboRemote paramMboRemote2, boolean paramBoolean)
    throws MXException, RemoteException;

  public abstract void viewSchema()
    throws MXException, RemoteException;

  public abstract void viewOptimizedSchemaRequest(boolean paramBoolean)
    throws MXException, RemoteException;

  public abstract void setRequestArtifacts()
    throws MXException, RemoteException;

  public abstract void viewOptimizedSchemaResponse(boolean paramBoolean)
    throws MXException, RemoteException;

  public abstract void setResponseArtifacts()
    throws MXException, RemoteException;

  public abstract String validateMappings(boolean paramBoolean)
    throws MXException, RemoteException;

  public abstract String createIntegrationArtifacts(String paramString, byte[] paramArrayOfByte)
    throws MXException, RemoteException;

  public abstract LinkedHashMap<String, String> addRemoveID(String paramString)
    throws MXException, RemoteException;

  public abstract LinkedHashMap<String, String> undoRemove(String paramString)
    throws MXException, RemoteException;

  public abstract LinkedHashMap<String, String> undoAllRemove()
    throws MXException, RemoteException;

  public abstract LinkedHashMap<String, String> undoRemoveLast()
    throws MXException, RemoteException;

  public abstract void processnode(WSIOTreeSetRemote paramWSIOTreeSetRemote, LinkedHashMap<String, String> paramLinkedHashMap, boolean paramBoolean)
    throws MXException, RemoteException;

  public abstract void logStep(int paramInt, String paramString)
    throws MXException, RemoteException;

  public abstract void logCancel()
    throws MXException, RemoteException;

  public abstract void logWSIOStep(boolean paramBoolean, String paramString)
    throws MXException, RemoteException;

  public abstract void logUISelectionStep(boolean paramBoolean, String paramString)
    throws MXException, RemoteException;

  public abstract void logMappingStep(boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
    throws MXException, RemoteException;
}
