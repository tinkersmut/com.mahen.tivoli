package com.ibm.tivoli.maximo.interaction.app.manageint;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.util.MXException;

public abstract interface MaxInteractionRemote extends MboRemote
{
  public abstract String deleteInteraction(byte[] paramArrayOfByte)
    throws MXException, RemoteException;

  public abstract boolean validateInteraction()
    throws MXException, RemoteException;

  public abstract void exportInteraction()
    throws MXException, RemoteException;
}
