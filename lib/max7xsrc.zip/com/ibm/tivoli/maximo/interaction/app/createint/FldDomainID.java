/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MAXTableDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueInfo;
/*    */ import psdi.mbo.SqlFormat;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 





















/*    */ public class FldDomainID extends MAXTableDomain
/*    */ {
/*    */   public FldDomainID(MboValue mbv)
/*    */     throws MXException
/*    */   {
/* 41 */     super(mbv);
/* 42 */     setRelationship("MAXDOMAIN", "domainid=:" + getMboValue().getName());
/* 43 */     setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "domainid" });
/*    */   }

/*    */   public void validate() throws MXException, RemoteException
/*    */   {
/* 48 */     MboValue value = getMboValue();
/* 49 */     if (value.isNull())
/* 50 */       return;
/* 51 */     super.validate();
/*    */ 
/* 53 */     MboSetRemote domainSet = MXServer.getMXServer().getMboSet("MAXDOMAIN", getMboValue().getMbo().getUserInfo());
/* 54 */     SqlFormat sqf = new SqlFormat(value.getMbo().getUserInfo(), "domainid =:1");
/* 55 */     sqf.setObject(1, "MAXDOMAIN", "DOMAINID", value.getString());
/* 56 */     domainSet.setWhere(sqf.format());
/* 57 */     domainSet.reset();
/* 58 */     MboRemote domain = domainSet.moveFirst();
/* 59 */     if (domain == null)
/*    */     {
/* 61 */       String[] params = { value.getMboValueInfo().getTitle(), value.getString() };
/* 62 */       throw new MXApplicationException("assetcatalog", "notAvalidDomainId", params);
/*    */     }
/* 64 */     value.getMbo().setValue("domaintype", domain.getString("domaintype"), 11L);
/*    */   }
/*    */ }
