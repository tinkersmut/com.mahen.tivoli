/*     */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.MboValueAdapter;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXFormat;
/*     */ 

















/*     */ public class FldInteractionName extends MboValueAdapter
/*     */ {
/*     */   public FldInteractionName(MboValue mbv)
/*     */   {
/*  40 */     super(mbv);
/*     */   }










/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  55 */     MboValue value = getMboValue();
/*  56 */     if (value.isNull())
/*  57 */       return;
/*  58 */     super.validate();
/*     */ 
/*  60 */     if (!(MXFormat.isValidChar(getMboValue().getString()))) {
/*  61 */       throw new MXApplicationException("appsetup", "invalidAppChar");
/*     */     }
/*  63 */     if (value.getString().equals("GLOBAL"))
/*     */     {
/*  65 */       String[] params = { value.getString() };
/*  66 */       throw new MXApplicationException("iface", "interaction_reserve_name", params);
/*     */     }
/*     */ 
/*  69 */     int maxLength = MXServer.getMXServer().getMaximoDD().getMboSetInfo("MAXINTOBJECT").getMboValueInfo("intobjectname").getLength();
/*     */ 
/*  71 */     if (value.getString().length() > maxLength - 3)
/*     */     {
/*  73 */       String[] params = { value.getString() };
/*  74 */       throw new MXApplicationException("system", "maximumlength", params);
/*     */     }
/*  76 */     String userLang = getMboValue().getMbo().getUserInfo().getLangCode();
/*     */ 
/*  78 */     if ((userLang == null) || (!(userLang.equals(MXServer.getMXServer().getBaseLang()))))
/*     */     {
/*  80 */       throw new MXApplicationException("iface", "not_in_base_language");
/*     */     }
/*     */ 
/*  83 */     MboSetRemote intMboSet = MXServer.getMXServer().getMboSet("MAXINTERACTION", getMboValue().getMbo().getUserInfo());
/*  84 */     SqlFormat sqf = new SqlFormat(value.getMbo().getUserInfo(), "interaction =:1");
/*  85 */     sqf.setObject(1, "MAXINTERACTION", "INTERACTION", value.getString());
/*  86 */     intMboSet.setWhere(sqf.format());
/*  87 */     intMboSet.reset();
/*  88 */     if (intMboSet.isEmpty())
/*     */       return;
/*  90 */     String[] params = { value.getString() };
/*  91 */     throw new MXApplicationException("iface", "interactionexists", params);
/*     */   }








/*     */   public void action()
/*     */     throws MXException, RemoteException
/*     */   {
/* 104 */     MboSetRemote serviceSet = getMboValue().getMbo().getMboSet("SCHEMASERVICES");
/* 105 */     MboRemote service = null;
/* 106 */     for (int i = 0; ; ++i)
/*     */     {
/* 108 */       service = serviceSet.getMbo(i);
/* 109 */       if (service == null) {
/*     */         return;
/*     */       }
/*     */ 
/* 113 */       service.setValue("interaction", getMboValue().getString(), 11L);
/* 114 */       MboSetRemote portSet = service.getMboSet("SCHEMAPORTS");
/* 115 */       MboRemote port = null;
/* 116 */       for (int j = 0; ; ++j)
/*     */       {
/* 118 */         port = portSet.getMbo(j);
/* 119 */         if (port == null) {
/*     */           break;
/*     */         }
/*     */ 
/* 123 */         port.setValue("interaction", getMboValue().getString(), 11L);
/* 124 */         MboSetRemote operationSet = port.getMboSet("SCHEMAOPER");
/* 125 */         MboRemote oper = null;
/* 126 */         for (int l = 0; ; ++l)
/*     */         {
/* 128 */           oper = operationSet.getMbo(l);
/* 129 */           if (oper == null) {
/*     */             break;
/*     */           }
/*     */ 
/* 133 */           oper.setValue("interaction", getMboValue().getString(), 11L);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }
