/*    */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXException;
/*    */ 






























/*    */ public class MaxIntPolicyParam extends Mbo
/*    */ {
/*    */   public MaxIntPolicyParam(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 45 */     super(ms);
/*    */   }







/*    */   public void add()
/*    */     throws MXException, RemoteException
/*    */   {
/* 57 */     MboRemote inter = getOwner();
/* 58 */     setValue("policyid", inter.getString("policyid"), 11L);
/* 59 */     setValue("interaction", inter.getString("interaction"), 11L);
/* 60 */     setValue("changedate", MXServer.getMXServer().getDate(), 11L);
/* 61 */     setValue("changeby", getUserName(), 11L);
/*    */   }
/*    */ }
