/*     */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIOAttribute;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import psdi.mbo.HierarchicalMboSetRemote;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueData;
/*     */ import psdi.mbo.NonPersistentMboSet;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 













/*     */ public class WSIOTreeSet extends NonPersistentMboSet
/*     */   implements WSIOTreeSetRemote, HierarchicalMboSetRemote
/*     */ {
/*     */   public WSIOTreeSet(MboServerInterface ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  39 */     super(ms);
/*     */   }





/*     */   protected Mbo getMboInstance(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  49 */     return new WSIOTree(ms);
/*     */   }














/*     */   public MboValueData[][] getChildren(String object, String key, String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/*  68 */     List lst = new ArrayList();
/*     */ 
/*  70 */     MboRemote thisMbo = findMbo(getMbo(0), key);
/*  71 */     MboSetRemote child = thisMbo.getMboSet("TREENODE");
/*  72 */     for (int j = 0; j < child.getSize(); ++j)
/*     */     {
/*  74 */       MboRemote childMbo = child.getMbo(j);
/*  75 */       if (childMbo == null)
/*     */         continue;
/*  77 */       lst.add(childMbo.getMboValueData(attrs));
/*     */     }
/*     */ 
/*  80 */     MboValueData[][] aaa = new MboValueData[lst.size()][];
/*  81 */     int j = 0;
/*  82 */     for (MboValueData[] zzz : lst)
/*  83 */       aaa[(j++)] = zzz;
/*  84 */     return aaa;
/*     */   }













/*     */   public MboValueData[] getParent(String object, String key, String[] attrs)
/*     */     throws MXException, RemoteException
/*     */   {
/* 102 */     if (!(getMbo(0).getBoolean("hasparent")))
/*     */     {
/* 104 */       return null;
/*     */     }
/* 106 */     MboRemote mbo = getOwner();
/* 107 */     return mbo.getMboValueData(attrs);
/*     */   }













/*     */   public MboValueData[][] getSiblings(String object, String key, String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/* 125 */     return ((MboValueData[][])null);
/*     */   }













/*     */   public MboValueData[][] getTop(String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/* 143 */     if (getSize() == 0)
/*     */     {
/* 145 */       return ((MboValueData[][])null);
/*     */     }
/* 147 */     if (!(getBoolean("hasparent")))
/*     */     {
/* 149 */       return getMboValueData(0, count(), attrs);
/*     */     }
/* 151 */     MboRemote thisMbo = getMbo();
/*     */     while (true)
/*     */     {
/* 154 */       MboRemote owner = thisMbo.getOwner();
/* 155 */       if (owner == null)
/*     */       {
/* 157 */         return ((MboValueData[][])null);
/*     */       }
/* 159 */       if (!(owner.getBoolean("hasparent")))
/*     */       {
/* 161 */         return getMboValueData(0, count(), attrs);
/*     */       }
/* 163 */       thisMbo = owner;
/*     */     }
/*     */   }















/*     */   public MboValueData[][] getPathToTop(String object, String key, String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/* 184 */     return ((MboValueData[][])null);
/*     */   }






/*     */   public void fill(WSIO wsio, boolean top, LinkedHashMap<String, String> removeMap)
/*     */     throws MXException, RemoteException
/*     */   {
/* 195 */     MboRemote mbo = addAtEnd();
/* 196 */     mbo.setValue("wsiotreeid", wsio.getId());
/* 197 */     mbo.setValue("objectname", wsio.getName());
/* 198 */     mbo.setValue("title", wsio.getTitle());
/* 199 */     if (removeMap != null)
/*     */     {
/* 201 */       String id = new Integer(wsio.getId()).toString();
/* 202 */       if (removeMap.containsKey(id))
/*     */       {
/* 204 */         wsio.markForDelete(true);
/* 205 */         mbo.setValue("markedfordelete", true);


/*     */       }
/* 209 */       else if ((wsio.getParent() != null) && (wsio.getParent().isMarkedForDelete()))
/*     */       {
/* 211 */         wsio.markForDelete(true);
/* 212 */         mbo.setValue("markedfordelete", true);


/*     */       }
/*     */       else
/*     */       {
/* 218 */         wsio.markForDelete(false);
/* 219 */         mbo.setValue("markedfordelete", false);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 224 */       mbo.setValue("markedfordelete", false);
/* 225 */       mbo.setValue("elementpath", wsio.getTitle(), 2L);
/*     */     }
/* 227 */     if (top)
/*     */     {
/* 229 */       mbo.setValue("hasparent", false);
/*     */     }
/*     */     else
/*     */     {
/* 233 */       mbo.setValue("hasparent", true);
/*     */     }
/* 235 */     mbo.setValue("haschildren", true, 2L);
/* 236 */     List wsioAttrList = wsio.getWSIOAttributes();
/* 237 */     WSIOTreeSet requestAttrSet = (WSIOTreeSet)mbo.getMboSet("TREENODE");
/* 238 */     for (WSIOAttribute wsioAttr : wsioAttrList)
/*     */     {
/* 240 */       MboRemote attrMbo = requestAttrSet.addAtEnd();
/* 241 */       attrMbo.setValue("wsiotreeid", wsioAttr.getId());
/* 242 */       attrMbo.setValue("objectname", wsioAttr.getName(), 2L);






/*     */ 
/* 250 */       attrMbo.setValue("title", wsioAttr.getTitle(), 2L);
/* 251 */       attrMbo.setValue("required", wsioAttr.isRequired(), 2L);
/* 252 */       attrMbo.setValue("defaultvalue", wsioAttr.getDefaultValue(), 2L);
/* 253 */       attrMbo.setValue("hasparent", true, 2L);
/* 254 */       attrMbo.setValue("haschildren", false, 2L);
/* 255 */       if (removeMap != null)
/*     */       {
/* 257 */         if (wsio.isMarkedForDelete())
/*     */         {
/* 259 */           wsioAttr.markForDelete(true);
/*     */ 
/* 261 */           attrMbo.setValue("markedfordelete", true);
/*     */         }
/*     */ 
/* 264 */         String childID = String.valueOf(wsioAttr.getId());
/* 265 */         if (removeMap.containsKey(childID))
/*     */         {
/* 267 */           wsioAttr.markForDelete(true);
/* 268 */           attrMbo.setValue("markedfordelete", true);




/*     */         }
/*     */ 
/* 275 */         int parentid = wsioAttr.getContainerAttrId();
/* 276 */         if (parentid != -1)
/*     */         {
/* 278 */           String parid = String.valueOf(parentid);
/* 279 */           if (removeMap.containsKey(parid))
/*     */           {
/* 281 */             wsioAttr.markForDelete(true);
/*     */ 
/* 283 */             attrMbo.setValue("markedfordelete", true);
/*     */           }
/*     */         }
/*     */ 
/* 287 */         wsioAttr.markForDelete(false);
/* 288 */         attrMbo.setValue("markedfordelete", false);

/*     */       }
/*     */       else
/*     */       {
/* 293 */         attrMbo.setValue("elementpath", wsioAttr.getName() + "    " + wsioAttr.getTitle());
/* 294 */         attrMbo.setValue("markedfordelete", false);
/*     */       }
/*     */     }
/* 297 */     List wsioChildrenList = wsio.getWSIOChildren();
/* 298 */     for (WSIO wsioChild : wsioChildrenList)
/*     */     {
/* 300 */       requestAttrSet.fill(wsioChild, false, removeMap);
/*     */     }
/*     */   }






/*     */   public void fill(MboRemote parentMbo, boolean top)
/*     */     throws MXException, RemoteException
/*     */   {
/* 312 */     MboRemote mbo = addAtEnd();
/* 313 */     mbo.setValue("wsiotreeid", ((IntGenerator)parentMbo).getWSIO().getId());
/* 314 */     mbo.setValue("objectname", parentMbo.getString("wsioobjname"), 2L);
/*     */ 
/* 316 */     mbo.setValue("elementpath", parentMbo.getString("wsioobjname"), 2L);
/* 317 */     if (top)
/*     */     {
/* 319 */       mbo.setValue("hasparent", false);
/*     */     }
/*     */     else
/*     */     {
/* 323 */       mbo.setValue("hasparent", true);
/* 324 */       if (parentMbo.isNull("title"))
/*     */       {
/* 326 */         mbo.setValue("title", parentMbo.getString("wsioobjname"), 2L);
/*     */       }
/*     */       else
/*     */       {
/* 330 */         mbo.setValue("title", parentMbo.getString("title") + "." + parentMbo.getString("wsioobjname"), 2L);
/*     */       }
/*     */     }
/* 333 */     mbo.setValue("haschildren", true, 2L);
/* 334 */     MboSetRemote attrSet = parentMbo.getMboSet("RESPATTRIBUTES");
/* 335 */     WSIOTreeSet requestAttrSet = (WSIOTreeSet)mbo.getMboSet("TREENODE");
/* 336 */     MboRemote attr = null;
/* 337 */     for (int k = 0; ; ++k)
/*     */     {
/* 339 */       attr = attrSet.getMbo(k);
/* 340 */       if (attr == null) {
/*     */         break;
/*     */       }
/*     */ 
/* 344 */       MboRemote attrMbo = requestAttrSet.addAtEnd();
/* 345 */       attrMbo.setValue("wsiotreeid", ((IntGenerator)attr).getWSIOAttribute().getId(), 2L);
/* 346 */       attrMbo.setValue("objectname", attr.getString("attributename"), 2L);
/* 347 */       attrMbo.setValue("elementpath", attr.getString("attributename") + " (" + attr.getString("hierarchypath") + ")", 2L);
/* 348 */       attrMbo.setValue("hasparent", true, 2L);
/* 349 */       attrMbo.setValue("haschildren", false, 2L);
/* 350 */       if (top)
/*     */         continue;
/* 352 */       attrMbo.setValue("title", parentMbo.getString("title"), 2L);
/*     */     }
/*     */ 
/* 355 */     MboSetRemote parentSet = parentMbo.getThisMboSet();
/* 356 */     MboRemote children = null;
/* 357 */     for (int k = 0; ; ++k)
/*     */     {
/* 359 */       children = parentSet.getMbo(k);
/* 360 */       if (children == null) {
/*     */         return;
/*     */       }
/*     */ 
/* 364 */       if (children == parentMbo) {
/*     */         continue;
/*     */       }
/*     */ 
/* 368 */       if (!(children.getString("parenthierarchy").equals(parentMbo.getString("hierarchypath"))))
/*     */         continue;
/* 370 */       requestAttrSet.fill(children, false);
/*     */     }
/*     */   }


/*     */   public MboRemote setup()
/*     */     throws MXException, RemoteException
/*     */   {
/* 378 */     return null;
/*     */   }




/*     */   public MboValueData getUniqueIDValue(String object, String[] attributes, String[] values)
/*     */     throws MXException, RemoteException
/*     */   {
/* 387 */     return null;
/*     */   }














/*     */   public MboValueData[][] getAllHierarchies(String object, String key, String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/* 406 */     return ((MboValueData[][])null);
/*     */   }




/*     */   public MboValueData[] getHierarchy(String object, String key)
/*     */     throws MXException, RemoteException
/*     */   {
/* 415 */     return null;
/*     */   }




/*     */   public MboRemote findMbo(MboRemote mbo, String key)
/*     */     throws MXException, RemoteException
/*     */   {
/* 424 */     MboRemote returnMbo = null;
/* 425 */     if (key == null)
/*     */     {
/* 427 */       throw new MXApplicationException("jspmessages", "table_noselectedrows");
/*     */     }
/* 429 */     if (key.equals(mbo.getString("wsiotreeid")))
/*     */     {
/* 431 */       return mbo;
/*     */     }
/* 433 */     MboSetRemote child = mbo.getMboSet("TREENODE");
/* 434 */     for (int j = 0; j < child.getSize(); ++j)
/*     */     {
/* 436 */       MboRemote childMbo = child.getMbo(j);
/* 437 */       if (key.equals(childMbo.getString("wsiotreeid")))
/*     */       {
/* 439 */         return childMbo;

/*     */       }
/*     */ 
/* 443 */       returnMbo = findMbo(childMbo, key);
/* 444 */       if (returnMbo != null)
/*     */       {
/* 446 */         return returnMbo;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 451 */     return null;
/*     */   }
/*     */ }
