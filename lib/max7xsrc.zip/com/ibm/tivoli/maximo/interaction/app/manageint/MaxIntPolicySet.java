/*    */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.util.MXException;
/*    */ 
































/*    */ public class MaxIntPolicySet extends MboSet
/*    */ {
/*    */   public MaxIntPolicySet(MboServerInterface ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 46 */     super(ms);
/*    */   }












/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 63 */     return new MaxIntPolicy(ms);
/*    */   }
/*    */ }
