/*    */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.interaction.policy.InteractionPolicyCache;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXException;
/*    */ 
































/*    */ public class MaxIntPolicyParamSet extends MboSet
/*    */ {
/*    */   public MaxIntPolicyParamSet(MboServerInterface ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 48 */     super(ms);
/*    */   }












/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 65 */     return new MaxIntPolicyParam(ms);
/*    */   }





/*    */   public void commit()
/*    */     throws MXException, RemoteException
/*    */   {
/* 75 */     super.commit();
/*    */ 
/* 77 */     MXServer.getMXServer().reloadMaximoCache(InteractionPolicyCache.getInstance().getName(), true);
/*    */   }
/*    */ }
