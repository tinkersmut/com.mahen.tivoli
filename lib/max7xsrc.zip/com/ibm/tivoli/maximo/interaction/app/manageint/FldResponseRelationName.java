/*    */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.iface.mic.InvokeChannelCache;
/*    */ import psdi.iface.mic.InvokeInfo;
/*    */ import psdi.iface.mos.MosDetailInfo;
/*    */ import psdi.iface.mos.MosInfo;
/*    */ import psdi.iface.mos.ObjectStructureCache;
/*    */ import psdi.mbo.MAXTableDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.SqlFormat;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 



















/*    */ public class FldResponseRelationName extends MAXTableDomain
/*    */ {
/*    */   public FldResponseRelationName(MboValue mbv)
/*    */   {
/* 42 */     super(mbv);
/* 43 */     setRelationship("MAXRELATIONSHIP", "");
/* 44 */     setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "relation" });
/*    */   }








/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 57 */     MboValue value = getMboValue();
/* 58 */     if (value.isNull()) {
/* 59 */       return;
/*    */     }
/* 61 */     MboRemote thisMbo = value.getMbo();
/*    */ 
/* 63 */     InvokeInfo invokeInfo = InvokeChannelCache.getInstance().getInvokeInfo(thisMbo.getString("channelname"));
/* 64 */     String objectName = ObjectStructureCache.getInstance().getMosInfo(invokeInfo.getMosName()).getPrimaryMosDetailInfo().getObjectName();
/*    */ 
/* 66 */     MboServerInterface service = getMboValue().getMbo().getMboServer();
/* 67 */     MboSetRemote relationSet = service.getMboSet("MAXRELATIONSHIP", getMboValue().getMbo().getUserInfo());
/* 68 */     SqlFormat sqf = new SqlFormat(getMboValue().getMbo().getUserInfo(), "name = :1 and parent = :2");
/* 69 */     sqf.setObject(1, "MAXRELATIONSHIP", "NAME", value.getString());
/* 70 */     sqf.setObject(2, "MAXRELATIONSHIP", "PARENT", objectName);
/* 71 */     relationSet.setWhere(sqf.format());
/* 72 */     if (!(relationSet.isEmpty()))
/*    */       return;
/* 74 */     String[] params = { value.getString() };
/* 75 */     throw new MXApplicationException("iface", "InvalidRelationshipName", params);
/*    */   }
/*    */ }
