/*    */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 





























/*    */ public class FldUseParent extends MboValueAdapter
/*    */ {
/*    */   public FldUseParent(MboValue mbv)
/*    */   {
/* 43 */     super(mbv);
/*    */   }







/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 55 */     String colsRelation = "MAXINTMAPPINGDETAIL";
/* 56 */     MboValue value = getMboValue();
/* 57 */     MboRemote thisMbo = value.getMbo();
/* 58 */     MboRemote owner = thisMbo.getOwner();
/* 59 */     if (!(owner.getName().equals("MAXINTERACTION")))
/*    */     {
/* 61 */       return;
/*    */     }
/* 63 */     ((MaxInteraction)owner).checkMappingObject(thisMbo, colsRelation);
/* 64 */     if (!(value.getBoolean()))
/*    */     {
/* 66 */       thisMbo.setValueNull("mapobject", 11L);
/* 67 */       thisMbo.setFieldFlag("relation", 7L, false);
/*    */     }
/*    */     else
/*    */     {
/* 71 */       String parentName = ((MaxInteraction)owner).getParentTbName(thisMbo);
/* 72 */       thisMbo.setValue("mapobject", parentName, 11L);
/* 73 */       thisMbo.setValueNull("relation", 11L);
/* 74 */       thisMbo.setFieldFlag("relation", 7L, true);
/*    */     }
/* 76 */     if (colsRelation == null)
/*    */       return;
/* 78 */     MboSetRemote attrSet = thisMbo.getMboSet(colsRelation);
/* 79 */     MboRemote attr = null;
/* 80 */     for (int k = 0; ; ++k)
/*    */     {
/* 82 */       attr = attrSet.getMbo(k);
/* 83 */       if (attr == null) {
/*    */         return;
/*    */       }
/*    */ 
/* 87 */       if (value.getBoolean())
/*    */       {
/* 89 */         if (thisMbo.getBoolean("isresponse"))
/*    */         {
/* 91 */           attr.setValue("objectname", thisMbo.getString("objectname"), 11L);
/*    */         }
/*    */         else
/*    */         {
/* 95 */           attr.setValue("objectname", thisMbo.getString("mapobject"), 11L);
/*    */         }
/*    */ 
/*    */       }
/*    */       else
/* 100 */         attr.setValueNull("objectname", 11L);
/*    */     }
/*    */   }
/*    */ }
