/*    */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.util.MXException;
/*    */ 































/*    */ public class MaxIntMappingSet extends MboSet
/*    */ {
/*    */   public MaxIntMappingSet(MboServerInterface ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 45 */     super(ms);
/*    */   }












/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 62 */     return new MaxIntMapping(ms);
/*    */   }
/*    */ }
