/*    */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 




























/*    */ public class FldUseParent extends MboValueAdapter
/*    */ {
/*    */   public FldUseParent(MboValue mbv)
/*    */   {
/* 43 */     super(mbv);
/*    */   }







/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 55 */     String colsRelation = null;
/* 56 */     MboValue value = getMboValue();
/* 57 */     MboRemote thisMbo = value.getMbo();
/* 58 */     if (thisMbo.getString("recordtype").equals("REQUESTOBJECT"))
/*    */     {
/* 60 */       colsRelation = "REQUESTMAPPING";
/*    */     }
/* 62 */     else if (thisMbo.getString("recordtype").equals("RESPONSEOBJECT"))
/*    */     {
/* 64 */       colsRelation = "RESPONSEMAPPING";
/*    */     }
/*    */     else
/*    */     {
/* 68 */       return;
/*    */     }
/* 70 */     ((IntGenerator)thisMbo).checkMappingObject(colsRelation);
/* 71 */     if (!(value.getBoolean()))
/*    */     {
/* 73 */       thisMbo.setValueNull("objectname", 11L);
/* 74 */       thisMbo.setFieldFlag("apprelation", 7L, false);
/*    */     }
/*    */     else
/*    */     {
/* 78 */       String parentName = ((IntGenerator)thisMbo).getParentTbName(thisMbo.getString("hierarchypath"));
/* 79 */       if ((parentName == null) || (parentName.equals("")))
/*    */       {
/* 81 */         throw new MXApplicationException("iface", "missingparentobject");
/*    */       }
/* 83 */       thisMbo.setValue("objectname", parentName, 11L);
/* 84 */       thisMbo.setValueNull("apprelation", 11L);
/* 85 */       thisMbo.setFieldFlag("apprelation", 7L, true);
/*    */     }
/* 87 */     if (colsRelation == null)
/*    */       return;
/* 89 */     MboSetRemote attrSet = thisMbo.getMboSet(colsRelation);
/* 90 */     MboRemote attr = null;
/* 91 */     for (int k = 0; ; ++k)
/*    */     {
/* 93 */       attr = attrSet.getMbo(k);
/* 94 */       if (attr == null) {
/*    */         return;
/*    */       }
/*    */ 
/* 98 */       if (value.getBoolean())
/*    */       {
/* 100 */         attr.setValue("objectname", thisMbo.getString("objectname"), 11L);
/*    */       }
/*    */       else
/*    */       {
/* 104 */         attr.setValueNull("objectname", 11L);
/*    */       }
/*    */     }
/*    */   }
/*    */ }
