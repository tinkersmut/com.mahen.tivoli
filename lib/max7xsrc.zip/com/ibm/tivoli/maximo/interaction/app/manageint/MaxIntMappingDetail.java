/*     */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboValueInfoStatic;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 




























/*     */ public class MaxIntMappingDetail extends Mbo
/*     */ {
/*     */   public MaxIntMappingDetail(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  45 */     super(ms);
/*     */   }



/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  53 */     super.init();
/*     */     try
/*     */     {
/*  56 */       String remarks = null;
/*  57 */       MboRemote inter = getOwner();
/*  58 */       if (inter == null)
/*     */       {
/*  60 */         return;
/*     */       }
/*  62 */       if (inter.getName().equals("MAXINTMAPPING"))
/*     */       {
/*  64 */         if (!(inter.getBoolean("isresponse")))
/*     */         {
/*  66 */           setValue("objectname", inter.getString("mapobject"), 11L);
/*  67 */           setValue("mapobject", inter.getString("objectname"), 11L);
/*  68 */           if (!(toBeAdded()))
/*     */           {
/*  70 */             remarks = ((MaxIntMappingDetailSet)getThisMboSet()).getSourceElement(getString("mapobject"), getString("attributename"));
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*  75 */           setValue("objectname", inter.getString("objectname"), 11L);
/*  76 */           setValue("mapobject", inter.getString("mapobject"), 11L);
/*  77 */           if (!(toBeAdded()))
/*     */           {
/*  79 */             remarks = ((MaxIntMappingDetailSet)getThisMboSet()).getSourceElement(getString("objectname"), getString("value"));
/*     */           }
/*     */         }
/*  82 */         if (toBeAdded())
/*     */         {
/*  84 */           return;
/*     */         }
/*  86 */         if (inter.getName().equals("MAXINTMAPPING"))
/*     */         {
/*  88 */           if (getBoolean("encryptvalue"))
/*     */           {
/*  90 */             setFieldFlag("value", 7L, true);
/*  91 */             setFieldFlag("password", 7L, false);
/*     */           }
/*     */           else
/*     */           {
/*  95 */             setFieldFlag("value", 7L, false);
/*  96 */             setFieldFlag("password", 7L, true);
/*     */           }
/*     */         }
/*  99 */         if (remarks == null)
/*     */         {
/* 101 */           setValueNull("sourceelement", 11L);
/*     */         }
/*     */         else
/*     */         {
/* 105 */           setValue("sourceelement", remarks, 11L);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/* 111 */       throw new MXApplicationException("system", "noobject");
/*     */     }
/*     */   }






/*     */   public void add()
/*     */     throws MXException, RemoteException
/*     */   {
/* 123 */     MboRemote inter = getOwner();
/* 124 */     if (inter == null)
/*     */     {
/* 126 */       return;
/*     */     }
/* 128 */     setValue("changedate", MXServer.getMXServer().getDate(), 11L);
/* 129 */     setValue("changeby", getUserName(), 11L);
/* 130 */     setValue("encryptvalue", false, 11L);
/* 131 */     setFieldFlag("value", 7L, false);
/* 132 */     setFieldFlag("password", 7L, true);
/* 133 */     if (!(inter.getName().equals("MAXINTMAPPING")))
/*     */       return;
/* 135 */     if (inter.isNull("mapobject"))
/*     */     {
/* 137 */       throw new MXApplicationException("iface", "missingmapobject");
/*     */     }
/* 139 */     setValue("interaction", inter.getString("interaction"), 11L);
/* 140 */     setValue("hierarchypath", inter.getString("hierarchypath"), 11L);
/*     */   }






/*     */   public void setSourceElement(MboRemote sourceMbo, String value)
/*     */     throws MXException, RemoteException
/*     */   {
/* 151 */     if ((value == null) || (value.equals("")) || (value.startsWith("'")))
/*     */     {
/* 153 */       return;
/*     */     }
/* 155 */     if (value.startsWith(":"))
/*     */     {
/* 157 */       value = value.substring(1);
/*     */     }
/* 159 */     if (value.indexOf(".") != -1)
/*     */     {
/* 161 */       MboRemote mbo = ((Mbo)sourceMbo).getMboForAttribute(value);
/* 162 */       value = value.substring(value.indexOf(".") + 1, value.length());
/* 163 */       setSourceElement(mbo, value);
/*     */     }
/* 165 */     String remark = sourceMbo.getMboValueInfoStatic(value).getRemarks();
/* 166 */     setValue("sourceelement", remark, 11L);
/*     */   }
/*     */ }
