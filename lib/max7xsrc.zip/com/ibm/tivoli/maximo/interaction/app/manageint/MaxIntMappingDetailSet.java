/*     */ package com.ibm.tivoli.maximo.interaction.app.manageint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 























/*     */ public class MaxIntMappingDetailSet extends MboSet
/*     */   implements MaxIntMappingDetailSetRemote
/*     */ {
/*     */   public MaxIntMappingDetailSet(MboServerInterface ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  51 */     super(ms);
/*     */   }












/*     */   protected Mbo getMboInstance(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  68 */     return new MaxIntMappingDetail(ms);
/*     */   }






/*     */   public Map<String, String> getExistingAttributes(MboRemote thisMbo)
/*     */     throws MXException, RemoteException
/*     */   {
/*  79 */     Map existingAttr = null;
/*  80 */     MboRemote mbo = null;
/*  81 */     for (int i = 0; ; ++i)
/*     */     {
/*  83 */       mbo = getMbo(i);
/*  84 */       if (mbo == null) {
/*     */         break;
/*     */       }
/*     */ 
/*  88 */       if (mbo == thisMbo) {
/*     */         break;
/*     */       }
/*     */ 
/*  92 */       if (existingAttr == null)
/*     */       {
/*  94 */         existingAttr = new HashMap();
/*     */       }
/*  96 */       existingAttr.put(mbo.getString("attributename"), mbo.getString("attributename"));
/*     */     }
/*  98 */     return existingAttr;
/*     */   }

/*     */   public MboSetRemote fillAttributes(MboRemote parent, MboRemote thisMbo) throws MXException, RemoteException {
/* 102 */     String objectName = null;
/* 103 */     if (!(getOwner().getBoolean("isresponse")))
/*     */     {
/* 105 */       objectName = parent.getString("objectname");
/*     */     }
/*     */     else
/*     */     {
/* 109 */       objectName = parent.getString("mapobject");
/*     */     }
/* 111 */     if (objectName.equals(""))
/*     */     {
/* 113 */       throw new MXApplicationException("iface", "missingparentobject");
/*     */     }
/* 115 */     MboSetRemote attrSet = getOwner().getMboSet("SELECTATTR");
/* 116 */     Map existingAttr = getExistingAttributes(thisMbo);
/* 117 */     Iterator itr = MXServer.getMXServer().getMaximoDD().getMboSetInfo(objectName).getAttributes();
/* 118 */     ArrayList attrList = new ArrayList();
/* 119 */     while (itr.hasNext())
/*     */     {
/* 121 */       MboValueInfo info = (MboValueInfo)itr.next();
/* 122 */       if ((existingAttr != null) && (existingAttr.containsKey(info.getName()))) {
/*     */         continue;
/*     */       }
/*     */ 
/* 126 */       attrList.add(info.getName());
/*     */     }
/* 128 */     Collections.sort(attrList);
/* 129 */     Iterator attritr = attrList.iterator();
/* 130 */     while (attritr.hasNext())
/*     */     {
/* 132 */       String name = (String)attritr.next();
/* 133 */       MboRemote attr = attrSet.addAtEnd();
/* 134 */       attr.setValue("attributename", name);
/* 135 */       attr.setValue("objectname", objectName);
/* 136 */       attr.setValue("sourceelement", getSourceElement(objectName, name));
/*     */     }
/* 138 */     return attrSet;
/*     */   }





/*     */   public String getSourceElement(String sourceMbo, String value)
/*     */     throws MXException, RemoteException
/*     */   {
/* 148 */     if ((value == null) || (value.equals("")) || (value.startsWith("'")))
/*     */     {
/* 150 */       return null;
/*     */     }
/* 152 */     if (value.startsWith(":"))
/*     */     {
/* 154 */       value = value.substring(1);
/*     */     }
/* 156 */     if (value.indexOf(".") != -1)
/*     */     {
/* 158 */       return null;
/*     */     }
/* 160 */     MboSetRemote intMboSet = MXServer.getMXServer().getMboSet("MAXATTRIBUTE", getUserInfo());
/* 161 */     SqlFormat sqf = new SqlFormat(getUserInfo(), "objectname =:1 and attributename=:2");
/* 162 */     sqf.setObject(1, "MAXATTRIBUTE", "OBJECTNAME", sourceMbo);
/* 163 */     sqf.setObject(2, "MAXATTRIBUTE", "ATTRIBUTENAME", value);
/* 164 */     intMboSet.setWhere(sqf.format());
/* 165 */     intMboSet.reset();
/* 166 */     MboRemote intMbo = intMboSet.getMbo(0);
/* 167 */     if (intMbo != null)
/*     */     {
/* 169 */       return intMbo.getString("remarks");
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ }
