/*     */ package com.ibm.tivoli.maximo.interaction.app.createint;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Map;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 






















/*     */ public class FldMapAttribute extends MAXTableDomain
/*     */ {
/*     */   public FldMapAttribute(MboValue mbv)
/*     */     throws MXException
/*     */   {
/*  44 */     super(mbv);
/*  45 */     setRelationship("INTGENERATOR", "");
/*  46 */     setLookupKeyMapInOrder(new String[] { "attributename" }, new String[] { "attributename" });
/*     */   }






/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  57 */     MboValue value = getMboValue();
/*  58 */     if (value.isNull())
/*     */     {
/*  60 */       value.getMbo().setValueNull("hierarchypath", 11L);
/*  61 */       return;
/*     */     }
/*  63 */     if ((!(value.getMbo().getString("recordtype").equals("RESPONSEMAPPING"))) && (!(value.getMbo().getString("recordtype").equals("REQUESTMAPPING"))))

/*     */     {
/*  66 */       return;
/*     */     }
/*  68 */     if (value.getMbo().getString("recordtype").equals("REQUESTMAPPING"))
/*     */     {
/*  70 */       value.getMbo().setValueNull("hierarchypath", 11L);
/*  71 */       MboSetRemote set = ((IntGenerator)value.getMbo()).fillAttributes(value.getMbo().getOwner(), value.getMbo(), false);
/*  72 */       MboRemote mbo = null;
/*  73 */       for (int i = 0; ; ++i)
/*     */       {
/*  75 */         mbo = set.getMbo(i);
/*  76 */         if (mbo == null) {
/*     */           break;
/*     */         }
/*     */ 
/*  80 */         if (!(mbo.getString("attributename").equals(value.getString())))
/*     */           continue;
/*  82 */         value.getMbo().setValue("hierarchypath", mbo.getString("hierarchypath"), 11L);
/*  83 */         return;
/*     */       }
/*     */ 
/*  86 */       String[] params = { value.getString() };
/*  87 */       throw new MXApplicationException("system", "noattribute", params);

/*     */     }
/*     */ 
/*  91 */     if (value.getString().indexOf(".") == -1)
/*     */     {
/*  93 */       MboValueInfo info = MXServer.getMXServer().getMaximoDD().getMboSetInfo(value.getMbo().getString("wsioobjname")).getMboValueInfo(value.getString());
/*  94 */       if (info == null)
/*     */       {
/*  96 */         String[] params = { value.getString() };
/*  97 */         throw new MXApplicationException("system", "noattribute", params);
/*     */       }
/*     */     }
/*     */ 
/* 101 */     Map existingAttr = ((IntGenerator)value.getMbo()).getExistingAttributes(value.getMbo().getThisMboSet(), value.getMbo());
/* 102 */     if (existingAttr == null)
/*     */     {
/* 104 */       return;
/*     */     }
/* 106 */     if (!(existingAttr.containsKey(value.getString())))
/*     */       return;
/* 108 */     throw new MXApplicationException("iface", "attralreadymapped");
/*     */   }







/*     */   public MboSetRemote getList()
/*     */     throws MXException, RemoteException
/*     */   {
/* 120 */     MboValue value = getMboValue();
/* 121 */     MboRemote thisMbo = value.getMbo();
/* 122 */     return ((IntGenerator)thisMbo).fillAttributes(thisMbo.getOwner(), thisMbo, true);
/*     */   }
/*     */ }
