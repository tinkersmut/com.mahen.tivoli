/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import psdi.common.parse.ParserServiceRemote;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.iface.mos.ConversionUtil;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfoStatic;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 



































/*     */ public class InteractionBinder
/*     */ {
/*  46 */   InteractionInfo interactionInfo = null;
/*  47 */   ParserServiceRemote parserService = null;
/*     */ 
/*  51 */   public static final MXLogger INTERACTIONLOGGER = InteractionUtil.INTERACTIONLOGGER;
/*     */ 
/*     */   public InteractionBinder(String interactionName)
/*     */     throws MXException, RemoteException
/*     */   {
/*  64 */     this.interactionInfo = InteractionCache.getInstance().getInteractionInfo(interactionName.toUpperCase());
/*  65 */     this.parserService = ((ParserServiceRemote)MXServer.getMXServer().lookup("PARSER"));
/*     */   }


































/*     */   public void bindInteractionData(MboRemote sourceMbo, MboRemote targetMbo, IntMappingInfo mapping)
/*     */     throws MXException, RemoteException
/*     */   {
/* 104 */     INTERACTIONLOGGER.debug("Entering bindInteractionData ");
/*     */ 
/* 106 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 108 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Target Mbo Name ").append(sourceMbo.getName()).toString());
/* 109 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Source Mbo Name ").append(targetMbo.getName()).toString());
/*     */     }
/* 111 */     Iterator mappingItr = mapping.getObjectMappings().iterator();
/* 112 */     while (mappingItr.hasNext())
/*     */     {
/* 114 */       IntMappingDetailInfo mappingDetailInfo = (IntMappingDetailInfo)mappingItr.next();
/* 115 */       String parameter = mappingDetailInfo.getParameter();
/* 116 */       String value = mappingDetailInfo.getValue();
/* 117 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 119 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Attribute Name ").append(parameter).toString());
/* 120 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Value ").append(value).toString());
/*     */       }
/* 122 */       bindData(sourceMbo, targetMbo, parameter, value);
/*     */     }
/* 124 */     INTERACTIONLOGGER.debug("Before validation ");
/*     */ 
/* 126 */     targetMbo.validate();
/*     */ 
/* 128 */     INTERACTIONLOGGER.debug("Leaving bindInteractionData ");
/*     */   }
















/*     */   public void bindData(MboRemote sourceMbo, MboRemote targetMbo, String parameter, String value)
/*     */     throws MXException, RemoteException
/*     */   {
/* 149 */     INTERACTIONLOGGER.debug("Entering bindData ");
/*     */ 
/* 151 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 153 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Target Mbo ").append(targetMbo.getName()).toString());
/* 154 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Source Mbo ").append(sourceMbo.getName()).toString());
/* 155 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Paramater ").append(parameter).toString());
/* 156 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Value ").append(value).toString());
/*     */     }
/* 158 */     if ((value == null) || (value.equals("")))
/*     */     {
/* 160 */       targetMbo.setValueNull(parameter, 6L);
/* 161 */       return;
/*     */     }
/* 163 */     if (value.startsWith(":"))
/*     */     {
/* 165 */       value = value.substring(1);
/*     */     }
/* 167 */     if ((!(value.startsWith("'"))) && (value.indexOf(".") != -1))
/*     */     {
/* 169 */       MboRemote mbo = ((Mbo)sourceMbo).getMboForAttribute(value);
/* 170 */       value = value.substring(value.indexOf(".") + 1, value.length());
/* 171 */       bindData(mbo, targetMbo, parameter, value);
/*     */     }
/*     */     else
/*     */     {
/* 175 */       int type = this.parserService.getNodeDataType(parameter, targetMbo);
/*     */ 
/* 177 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 179 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Final source mbo ").append(sourceMbo.getName()).toString());
/* 180 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Final Value ").append(value).toString());
/* 181 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Type of the target attribute ").append(type).toString());
/*     */       }
/*     */ 
/* 184 */       if (type == 0)
/*     */       {
/* 186 */         boolean val = this.parserService.getBoolean(value, sourceMbo);
/* 187 */         targetMbo.setValue(parameter, val, 6L);
/*     */       }
/* 189 */       else if (type == 2)
/*     */       {
/* 191 */         double val = this.parserService.getDouble(value, sourceMbo);
/* 192 */         targetMbo.setValue(parameter, val, 6L);
/*     */       }
/* 194 */       else if (type == 1)
/*     */       {
/* 196 */         String val = this.parserService.getString(value, sourceMbo);
/* 197 */         targetMbo.setValue(parameter, val, 6L);
/*     */       }
/* 199 */       else if (type == 3)
/*     */       {
/* 201 */         Date val = this.parserService.getDate(value, sourceMbo);
/* 202 */         targetMbo.setValue(parameter, val, 6L);
/*     */       }
/*     */       else
/*     */       {
/* 206 */         throw new MXApplicationException("parse", "unknownType");
/*     */       }
/* 208 */       if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*     */         return;
/* 210 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Leaving bindData with data set to ").append(targetMbo.getString(parameter)).toString());
/*     */     }
/*     */   }

















/*     */   protected MboRemote findMbo(MboRemote sourceMbo, MboSetRemote targetSet, IntMappingInfo mapping, String action)
/*     */     throws MXException, RemoteException
/*     */   {
/* 233 */     INTERACTIONLOGGER.debug("Entering findMbo ");
/* 234 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 236 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Target Mbo ").append(targetSet.getName()).toString());
/* 237 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Source Mbo ").append(sourceMbo.getName()).toString());
/* 238 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Action ").append(action).toString());
/*     */     }
/* 240 */     if (action.equals("Add"))
/*     */     {
/* 242 */       return targetSet.addAtEnd();
/*     */     }
/* 244 */     if ((mapping.getObjectMappings() == null) || (mapping.getObjectMappings().size() == 0))
/*     */     {
/* 246 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 248 */         INTERACTIONLOGGER.debug("No mapping found returning add ");
/*     */       }
/* 250 */       return targetSet.addAtEnd();
/*     */     }
/* 252 */     String[] keys = MicUtil.getKeyArray(targetSet.getName());
/* 253 */     String[] keyValues = new String[keys.length];
/*     */ 
/* 255 */     for (int i = 0; i < keys.length; ++i)
/*     */     {
/* 257 */       String keyName = keys[i];
/* 258 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 260 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Key name ").append(keyName).toString());
/*     */       }
/* 262 */       IntMappingDetailInfo mapInfo = findKeyName(mapping, keyName);
/* 263 */       if (mapInfo != null)
/*     */       {
/* 265 */         keyValues[i] = getKeyValue(sourceMbo, mapInfo.getValue());
/*     */       }
/*     */       else
/*     */       {
/* 269 */         MboRemote owner = targetSet.getOwner();
/* 270 */         if (owner == null)
/*     */         {
/* 272 */           if (INTERACTIONLOGGER.isInfoEnabled())
/*     */           {
/* 274 */             INTERACTIONLOGGER.info(new StringBuilder().append("Mapping for the key ").append(keyName).append(" in Mbo ").append(targetSet.getName()).append(" is not found. Can only add Mbo ").toString());
/*     */           }
/*     */ 
/* 277 */           return targetSet.addAtEnd();

/*     */         }
/*     */ 
/* 281 */         MboValueInfoStatic mvi = owner.getMboValueInfoStatic(keyName);
/* 282 */         if ((mvi == null) || (owner.getMboValueData(keyName) == null))

/*     */         {
/* 285 */           if (INTERACTIONLOGGER.isInfoEnabled())
/*     */           {
/* 287 */             INTERACTIONLOGGER.info(new StringBuilder().append("Mapping for the key ").append(keyName).append(" in Mbo ").append(targetSet.getName()).append(" is not found. Can only add Mbo ").toString());
/*     */           }
/*     */ 
/* 290 */           return targetSet.addAtEnd();

/*     */         }
/*     */ 
/* 294 */         keyValues[i] = getKeyValue(owner, keyName);

/*     */       }
/*     */ 
/* 298 */       if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*     */         continue;
/* 300 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Key value ").append(keyValues[i]).toString());
/*     */     }
/*     */ 
/* 303 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 305 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Find Mbo in the Set ").append(targetSet.getName()).toString());
/*     */     }
/* 307 */     MboRemote targetMbo = targetSet.findByIntegrationKey(keys, keyValues);
/* 308 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 310 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Target Mbo Exists ").append(targetMbo != null).toString());
/*     */     }
/* 312 */     if (targetMbo == null)
/*     */     {
/* 314 */       return targetSet.addAtEnd();
/*     */     }
/* 316 */     INTERACTIONLOGGER.debug("Leaving findMbo ");
/*     */ 
/* 318 */     return targetMbo;
/*     */   }













/*     */   public IntMappingDetailInfo findKeyName(IntMappingInfo mapping, String keyName)
/*     */     throws MXException, RemoteException
/*     */   {
/* 336 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 338 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Entering findKeyName for attribute ").append(keyName).toString());
/*     */     }
/* 340 */     Iterator mappingDetailItr = mapping.getObjectMappings().iterator();
/* 341 */     while (mappingDetailItr.hasNext())
/*     */     {
/* 343 */       IntMappingDetailInfo mappingDetailInfo = (IntMappingDetailInfo)mappingDetailItr.next();
/* 344 */       String value = mappingDetailInfo.getAttributeName();
/* 345 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 347 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Mapping value is ").append(value).toString());
/*     */       }
/* 349 */       if (keyName.equalsIgnoreCase(value))
/*     */       {
/* 351 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/* 353 */           INTERACTIONLOGGER.debug("Leaving findKeyName. Key found");
/*     */         }
/* 355 */         return mappingDetailInfo;
/*     */       }
/*     */     }
/* 358 */     INTERACTIONLOGGER.debug("Leaving findKeyName. Key is not found");
/* 359 */     return null;
/*     */   }












/*     */   public String getKeyValue(MboRemote sourceMbo, String value)
/*     */     throws MXException, RemoteException
/*     */   {
/* 376 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 378 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Entering getKeyValue for value ").append(value).toString());
/* 379 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Source Mbo ").append(sourceMbo.getName()).toString());
/*     */     }
/* 381 */     if (value == null)
/*     */     {
/* 383 */       return null;
/*     */     }
/* 385 */     if (value.startsWith(":"))
/*     */     {
/* 387 */       value = value.substring(1);
/*     */     }
/* 389 */     if ((!(value.startsWith("'"))) && (value.indexOf(".") != -1))
/*     */     {
/* 391 */       MboRemote mbo = ((Mbo)sourceMbo).getMboForAttribute(value);
/* 392 */       value = value.substring(value.indexOf(".") + 1, value.length());
/* 393 */       return getKeyValue(mbo, value);
/*     */     }
/* 395 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 397 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Final key value ").append(value).toString());
/* 398 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Final Key Source Mbo ").append(sourceMbo.getName()).toString());
/*     */     }
/* 400 */     return formatColumn(sourceMbo, value);
/*     */   }












/*     */   public String formatColumn(MboRemote sourceMbo, String name)
/*     */     throws MXException, RemoteException
/*     */   {
/* 417 */     String formatedValue = null;
/* 418 */     INTERACTIONLOGGER.debug("Entering formatColumn ");
/*     */ 
/* 420 */     int type = this.parserService.getNodeDataType(name, sourceMbo);
/*     */ 
/* 422 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 424 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Attribute type is ").append(type).toString());
/*     */     }
/*     */ 
/* 427 */     if (type == 0)
/*     */     {
/* 429 */       boolean val = this.parserService.getBoolean(name, sourceMbo);
/* 430 */       formatedValue = String.valueOf(val);
/*     */     }
/* 432 */     else if (type == 2)
/*     */     {
/* 434 */       double val = this.parserService.getDouble(name, sourceMbo);
/* 435 */       formatedValue = String.valueOf(val);
/*     */     }
/* 437 */     else if (type == 1)
/*     */     {
/* 439 */       String val = this.parserService.getString(name, sourceMbo);
/* 440 */       formatedValue = val;
/*     */     }
/* 442 */     else if (type == 3)
/*     */     {
/* 444 */       Date val = this.parserService.getDate(name, sourceMbo);
/* 445 */       formatedValue = ConversionUtil.dateToString(val);
/*     */     }
/*     */     else
/*     */     {
/* 449 */       throw new MXApplicationException("parse", "unknownType");
/*     */     }
/*     */ 
/* 452 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 454 */       INTERACTIONLOGGER.debug(new StringBuilder().append("Leaving formatColumn. Formatted value ").append(formatedValue).toString());
/*     */     }
/* 456 */     return formatedValue;
/*     */   }














/*     */   public void getRelatedSets(MboRemote sourceMbo, String value, List<MboSetRemote> relatedSets)
/*     */     throws MXException, RemoteException
/*     */   {
/* 475 */     INTERACTIONLOGGER.debug("Entering getRelatedSets ");
/* 476 */     if (value == null)
/*     */     {
/* 478 */       return;
/*     */     }
/* 480 */     if (value.indexOf(".") != -1)
/*     */     {
/* 482 */       String relation = value.substring(0, value.indexOf("."));
/* 483 */       value = value.substring(value.indexOf(".") + 1, value.length());
/* 484 */       MboSetRemote relSet = sourceMbo.getMboSet(relation);
/* 485 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 487 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Relation ").append(relation).toString());
/* 488 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Value minus relation ").append(value).toString());
/* 489 */         INTERACTIONLOGGER.debug(new StringBuilder().append("Related Set ").append(relSet.getName()).toString());
/*     */       }
/* 491 */       MboRemote relMbo = null;
/* 492 */       for (int i = 0; ; ++i)
/*     */       {
/* 494 */         relMbo = relSet.getMbo(i);
/* 495 */         if (relMbo == null) {
/*     */           break;
/*     */         }
/*     */ 
/* 499 */         getRelatedSets(relMbo, value, relatedSets);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 504 */       String relation = value.substring(0, value.indexOf("."));
/* 505 */       MboSetRemote relSet = sourceMbo.getMboSet(relation);
/* 506 */       relatedSets.add(relSet);
/*     */     }
/* 508 */     INTERACTIONLOGGER.debug("Leaving getRelatedSets ");
/*     */   }
/*     */ }
