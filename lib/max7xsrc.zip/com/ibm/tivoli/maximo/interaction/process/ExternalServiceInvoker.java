/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Map;
/*     */ import psdi.iface.mic.InvokeChannel;
/*     */ import psdi.iface.mic.InvokeChannelCache;
/*     */ import psdi.iface.mic.PublishChannel;
/*     */ import psdi.iface.mic.PublishChannelCache;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXException;
/*     */ 













































/*     */ public class ExternalServiceInvoker
/*     */ {
/*     */   public void invokeService(MboRemote mbo, ServiceInvokerInfo info, Map<String, Object> metaData)
/*     */     throws MXException, RemoteException
/*     */   {
/*  63 */     String channelName = info.getChannelName();
/*  64 */     String operation = info.getOperation();
/*  65 */     if (operation.equals("Publish"))
/*     */     {
/*  67 */       PublishChannel pub = PublishChannelCache.getInstance().getPublishChannel(channelName);
/*  68 */       if (info.getExtSystem() == null)
/*     */       {
/*  70 */         if (info.getReqRelation() == null)
/*     */         {
/*  72 */           pub.publish(mbo, false);
/*     */         }
/*     */         else
/*     */         {
/*  76 */           pub.publish(mbo.getMboSet(info.getReqRelation()));

/*     */         }
/*     */ 
/*     */       }
/*  81 */       else if (info.getReqRelation() == null)
/*     */       {
/*  83 */         pub.publishTo(mbo.getThisMboSet(), info.getExtSystem());
/*     */       }
/*     */       else
/*     */       {
/*  87 */         pub.publishTo(mbo.getMboSet(info.getReqRelation()), info.getExtSystem());
/*     */       }
/*     */ 
/*  90 */       return;
/*     */     }
/*  92 */     String endPointName = info.getEndPointName();
/*  93 */     if ((info.getReqRelation() == null) && (info.getRespRelation() == null))
/*     */     {
/*  95 */       InvokeChannelCache.getInstance().getInvokeChannel(channelName).invoke(metaData, mbo, mbo, endPointName);
/*     */     }
/*  97 */     else if (info.getReqRelation() == null)
/*     */     {
/*  99 */       InvokeChannelCache.getInstance().getInvokeChannel(channelName).invoke(metaData, mbo, mbo.getMboSet(info.getRespRelation()), info.getAction(), endPointName);
/*     */     }
/*     */     else
/*     */     {
/* 103 */       InvokeChannelCache.getInstance().getInvokeChannel(channelName).invoke(metaData, mbo.getMboSet(info.getReqRelation()), mbo.getMboSet(info.getRespRelation()), info.getAction(), endPointName);
/*     */     }
/*     */   }














/*     */   public void invokeService(MboSetRemote mboSet, ServiceInvokerInfo info, Map<String, Object> metaData)
/*     */     throws MXException, RemoteException
/*     */   {
/* 123 */     String channelName = info.getChannelName();
/* 124 */     String endPointName = info.getEndPointName();
/* 125 */     if (info.getRespRelation() == null)
/*     */     {
/* 127 */       InvokeChannelCache.getInstance().getInvokeChannel(channelName).invoke(metaData, mboSet, mboSet, info.getAction(), endPointName);
/*     */     }
/*     */     else
/*     */     {
/* 131 */       InvokeChannelCache.getInstance().getInvokeChannel(channelName).invoke(metaData, mboSet, mboSet.getMbo(0).getMboSet(info.getRespRelation()), info.getAction(), endPointName);
/*     */     }
/*     */   }
/*     */ }
