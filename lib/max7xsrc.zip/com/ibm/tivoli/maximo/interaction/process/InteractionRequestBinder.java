/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import psdi.iface.mos.MosDetailInfo;
/*     */ import psdi.iface.mos.MosInfo;
/*     */ import psdi.iface.mos.ObjectStructureCache;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 































/*     */ public class InteractionRequestBinder extends InteractionBinder
/*     */ {
/*     */   public InteractionRequestBinder(String interactionName)
/*     */     throws MXException, RemoteException
/*     */   {
/*  51 */     super(interactionName);
/*     */   }















/*     */   public void bind(MboSetRemote interactionSet, MboRemote mainMbo, boolean isResponse)
/*     */     throws MXException, RemoteException
/*     */   {
/*  71 */     INTERACTIONLOGGER.debug("Entering bind ");
/*     */ 
/*  73 */     MosDetailInfo primaryInfo = ObjectStructureCache.getInstance().getMosInfo(this.interactionInfo.getRequestOSName()).getPrimaryMosDetailInfo();
/*     */ 
/*  75 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/*  77 */       INTERACTIONLOGGER.debug("Request OS Name " + this.interactionInfo.getRequestOSName());
/*  78 */       INTERACTIONLOGGER.debug("Primary Info Name " + primaryInfo.getObjectName());
/*     */     }
/*  80 */     bindLevel(primaryInfo, mainMbo, interactionSet);
/*     */ 
/*  82 */     INTERACTIONLOGGER.debug("Leaving bind ");
/*     */   }















/*     */   protected void bindLevel(MosDetailInfo mosInfo, MboRemote sourceMbo, MboSetRemote targetSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 102 */     INTERACTIONLOGGER.debug("Entering bindLevel ");
/*     */ 
/* 104 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 106 */       INTERACTIONLOGGER.debug("Int object name " + mosInfo.getIntObjectName());
/* 107 */       INTERACTIONLOGGER.debug("Object path name " + mosInfo.getObjectPath());
/*     */     }
/* 109 */     IntMappingInfo mapping = this.interactionInfo.getObjectMapping(mosInfo.getIntObjectName(), mosInfo.getObjectPath());
/*     */ 
/* 111 */     if ((mapping == null) || (mapping.getMapObject() == null))
/*     */     {
/* 113 */       if (mosInfo.isPrimaryTable())
/*     */       {
/* 115 */         targetSet.add();
/*     */       }
/* 117 */       INTERACTIONLOGGER.debug("No mapping found. Existing ");
/* 118 */       return;
/*     */     }
/* 120 */     List childrenInfo = mosInfo.getChildren();
/* 121 */     String sourceRelation = mapping.getRelation();
/* 122 */     if (sourceRelation == null)
/*     */     {
/* 124 */       INTERACTIONLOGGER.debug("In use parent logic ");
/* 125 */       MboRemote targetMbo = findMbo(sourceMbo, targetSet, mapping, "Add");
/* 126 */       if ((mapping.getObjectMappings() != null) && (mapping.getObjectMappings().size() > 0))
/*     */       {
/* 128 */         bindInteractionData(sourceMbo, targetMbo, mapping);
/*     */       }
/*     */       else
/*     */       {
/* 132 */         INTERACTIONLOGGER.debug("No mapping attributes found. No binding is performed");
/*     */       }
/* 134 */       if ((childrenInfo == null) || (childrenInfo.size() == 0))
/*     */       {
/* 136 */         return;
/*     */       }
/* 138 */       Iterator childrenInfoItr = childrenInfo.iterator();
/* 139 */       while (childrenInfoItr.hasNext())
/*     */       {
/* 141 */         MosDetailInfo childInfo = (MosDetailInfo)childrenInfoItr.next();
/* 142 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/* 144 */           INTERACTIONLOGGER.debug("Child Int object name " + childInfo.getIntObjectName());
/* 145 */           INTERACTIONLOGGER.debug("Child Object path name " + childInfo.getObjectPath());
/* 146 */           INTERACTIONLOGGER.debug("Child Relation " + childInfo.getRelation());
/*     */         }
/* 148 */         bindLevel(childInfo, sourceMbo, targetMbo.getMboSet(childInfo.getRelation()));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 153 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 155 */         INTERACTIONLOGGER.debug("In relation logic " + sourceRelation);
/*     */       }
/* 157 */       List relatedSets = new ArrayList();
/* 158 */       if (sourceRelation.indexOf(".") != -1)
/*     */       {
/* 160 */         getRelatedSets(sourceMbo, sourceRelation, relatedSets);
/*     */       }
/*     */       else
/*     */       {
/* 164 */         relatedSets.add(sourceMbo.getMboSet(sourceRelation));
/*     */       }
/* 166 */       Iterator itr = relatedSets.iterator();
/* 167 */       while (itr.hasNext())
/*     */       {
/* 169 */         MboSetRemote relSet = (MboSetRemote)itr.next();
/* 170 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/* 172 */           INTERACTIONLOGGER.debug("Related sets name " + relSet.getName());
/*     */         }
/* 174 */         MboRemote sourceChild = null;
/* 175 */         for (int i = 0; ; ++i)
/*     */         {
/* 177 */           sourceChild = relSet.getMbo(i);
/* 178 */           if (sourceChild == null) {
/*     */             break;
/*     */           }
/*     */ 
/* 182 */           MboRemote targetMbo = findMbo(sourceChild, targetSet, mapping, "Add");
/* 183 */           if (INTERACTIONLOGGER.isDebugEnabled())
/*     */           {
/* 185 */             INTERACTIONLOGGER.debug("Target Mbo " + targetMbo.getName());
/*     */           }
/* 187 */           if ((mapping.getObjectMappings() != null) && (mapping.getObjectMappings().size() > 0))
/*     */           {
/* 189 */             bindInteractionData(sourceChild, targetMbo, mapping);
/*     */           }
/*     */           else
/*     */           {
/* 193 */             INTERACTIONLOGGER.debug("No mapping attributes found. No binding is performed");
/*     */           }
/*     */ 
/* 196 */           if (childrenInfo == null) continue; if (childrenInfo.size() == 0) {
/*     */             continue;
/*     */           }
/*     */ 
/* 200 */           Iterator childrenInfoItr = childrenInfo.iterator();
/* 201 */           while (childrenInfoItr.hasNext())
/*     */           {
/* 203 */             MosDetailInfo childInfo = (MosDetailInfo)childrenInfoItr.next();
/* 204 */             if (INTERACTIONLOGGER.isDebugEnabled())
/*     */             {
/* 206 */               INTERACTIONLOGGER.debug("Child Int object name " + childInfo.getIntObjectName());
/* 207 */               INTERACTIONLOGGER.debug("Child Object path name " + childInfo.getObjectPath());
/* 208 */               INTERACTIONLOGGER.debug("Child Relation " + childInfo.getRelation());
/*     */             }
/* 210 */             bindLevel(childInfo, sourceChild, targetMbo.getMboSet(childInfo.getRelation()));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 215 */     INTERACTIONLOGGER.debug("Leaving bindLevel ");
/*     */   }
/*     */ }
