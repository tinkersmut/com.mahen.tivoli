/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.generate.DialogGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.generate.OptionGenerator;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import psdi.iface.mic.EndPointCache;
/*     */ import psdi.iface.mic.InvokeChannelCache;
/*     */ import psdi.iface.mic.InvokeInfo;
/*     */ import psdi.iface.mic.MaxEndPointInfo;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.iface.mos.MosDetailInfo;
/*     */ import psdi.iface.mos.MosInfo;
/*     */ import psdi.iface.mos.ObjectStructureCache;
/*     */ import psdi.iface.util.XMLUtils;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MaximoMLDD;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfoStatic;
/*     */ import psdi.mbo.RelationInfo;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 

























/*     */ public class InteractionValidator
/*     */ {
/*  53 */   StringBuffer adminMsgs = null;
/*  54 */   MaximoDD maximoDD = null;
/*  55 */   MaximoMLDD maximoMLDD = null;
/*  56 */   InteractionInfo interactionInfo = null;
/*  57 */   UserInfo ui = null;
/*  58 */   private String[] messages = { "StartIntValidation", "exists_for_int", "doesnotexist_for_int", "relation_exists_for_int", "relation_doesnotexist_for_int", "FinishIntValidationSuccess", "FinishIntValidationFail" };
/*     */ 
/*     */   public InteractionValidator(String name, UserInfo userInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/*  68 */     this.maximoDD = MXServer.getMXServer().getMaximoDD();
/*  69 */     this.ui = userInfo;
/*  70 */     this.interactionInfo = InteractionCache.getInstance().getInteractionInfo(name);
/*  71 */     this.maximoMLDD = MXServer.getMXServer().getMaximoMLDD();
/*     */   }











/*     */   public List<Object> validateInteraction(boolean validateMenuOption, boolean validateDialog, MboSetRemote set)
/*     */     throws MXException, RemoteException
/*     */   {
/*  87 */     boolean success = true;
/*  88 */     this.adminMsgs = new StringBuffer();
/*     */ 
/*  90 */     addAdminMsg(new String[0], 0, true, success, set);
/*     */ 
/*  92 */     XMLUtils.writeBytesToXMLFile(this.interactionInfo.getObp(), InteractionUtil.getFileName(this.interactionInfo.getInteractionName(), "obp"));
/*     */ 
/*  94 */     InvokeInfo invokeInfo = InvokeChannelCache.getInstance().getInvokeInfo(this.interactionInfo.getChannelName());
/*     */ 
/*  96 */     String[] invparams = { this.maximoMLDD.getMboValueInfoStatic(this.ui, "MAXIFACEINVOKE", "IFACENAME").getTitle(), this.interactionInfo.getChannelName() };
/*     */ 
/*  98 */     success = addAdminMsg(invparams, 1, invokeInfo != null, success, set);
/*  99 */     if (invokeInfo != null)
/*     */     {
/* 101 */       RelationInfo relInfo = (RelationInfo)this.maximoDD.getRelationships(this.interactionInfo.getIntMainObject()).get(this.interactionInfo.getReqRelation());
/* 102 */       String[] relationParam = { this.interactionInfo.getReqRelation(), this.interactionInfo.getIntMainObject() };
/* 103 */       success = addAdminMsg(relationParam, 3, relInfo != null, success, set);
/*     */ 
/* 105 */       if (this.interactionInfo.getRespRelation() != null)
/*     */       {
/* 107 */         String mainRequestObject = ObjectStructureCache.getInstance().getMosInfo(invokeInfo.getMosName()).getPrimaryMosDetailInfo().getObjectName();
/*     */ 
/* 109 */         RelationInfo respRelInfo = (RelationInfo)this.maximoDD.getRelationships(mainRequestObject).get(this.interactionInfo.getRespRelation());
/* 110 */         String[] relationParam1 = { this.interactionInfo.getRespRelation(), mainRequestObject };
/* 111 */         success = addAdminMsg(relationParam1, 3, respRelInfo != null, success, set);
/*     */       }
/*     */ 
/* 114 */       success = validateObjectStructure(invokeInfo.getMosName(), success, set);
/* 115 */       if (invokeInfo.isProcessResponse())
/*     */       {
/* 117 */         success = validateObjectStructure(invokeInfo.getReplyMosName(), success, set);
/*     */       }
/* 119 */       success = validateEndPoint(invokeInfo.getEndPointName(), success, set);
/*     */     }
/*     */ 
/* 122 */     OptionGenerator optionGen = new OptionGenerator();
/*     */ 
/* 124 */     MboSetRemote sigSet = optionGen.checkSigOption(this.interactionInfo.getAppName(), this.interactionInfo.getMapOption(), this.ui);
/*     */ 
/* 126 */     String[] sigparams = { this.maximoMLDD.getMboValueInfoStatic(this.ui, "SIGOPTION", "OPTIONNAME").getTitle(), this.interactionInfo.getMapOption() };
/*     */ 
/* 128 */     success = addAdminMsg(sigparams, 1, !(sigSet.isEmpty()), success, set);
/*     */ 
/* 130 */     if (validateMenuOption)
/*     */     {
/* 132 */       MboSetRemote optionSet = optionGen.checkMenuOption(this.interactionInfo.getAppName(), this.interactionInfo.getMapOption(), this.ui);
/*     */ 
/* 134 */       String[] optparams = { this.maximoMLDD.getMboValueInfoStatic(this.ui, "MAXMENU", "KEYVALUE").getTitle(), this.interactionInfo.getMapOption() };
/* 135 */       success = addAdminMsg(optparams, 1, !(optionSet.isEmpty()), success, set);
/*     */     }
/*     */ 
/* 138 */     if (validateDialog)
/*     */     {
/* 140 */       DialogGenerator dialogGen = new DialogGenerator();
/* 141 */       String intMode = this.maximoDD.getTranslator().toInternalString("INTMODE", this.interactionInfo.getIntMode());
/* 142 */       if (intMode.equals("SILENT"))
/*     */       {
/* 144 */         boolean isAction = dialogGen.findAction(dialogGen.getAppXML(this.interactionInfo.getAppName(), this.ui), this.interactionInfo.getAppName(), this.interactionInfo.getMapOption().toLowerCase());
/*     */ 
/* 146 */         String[] dialogparams = { "action", this.interactionInfo.getMapOption() };
/* 147 */         success = addAdminMsg(dialogparams, 1, isAction, success, set);
/*     */       }
/*     */       else
/*     */       {
/* 151 */         boolean isDialog = dialogGen.findDialog(dialogGen.getAppXML(this.interactionInfo.getAppName(), this.ui), this.interactionInfo.getAppName(), this.interactionInfo.getDialogId().toLowerCase());
/*     */ 
/* 153 */         String[] dialogparams = { this.maximoMLDD.getMboValueInfoStatic(this.ui, "MAXINTERACTION", "DIALOGID").getTitle(), this.interactionInfo.getDialogId() };
/* 154 */         success = addAdminMsg(dialogparams, 1, isDialog, success, set);
/*     */       }
/*     */     }
/*     */ 
/* 158 */     addAdminMsg(new String[0], 5, success, success, set);
/*     */ 
/* 160 */     List result = new ArrayList(2);
/* 161 */     result.add(0, Boolean.valueOf(success));
/* 162 */     result.add(1, this.adminMsgs);
/* 163 */     return result;
/*     */   }











/*     */   public boolean validateObjectStructure(String osName, boolean success, MboSetRemote set)
/*     */     throws MXException, RemoteException
/*     */   {
/* 179 */     MosInfo objectInfo = ObjectStructureCache.getInstance().getMosInfo(osName);
/*     */ 
/* 181 */     String[] params = { this.maximoMLDD.getMboValueInfoStatic(this.ui, "MAXINTOBJECT", "INTOBJECTNAME").getTitle(), osName };
/* 182 */     success = addAdminMsg(params, 1, objectInfo != null, success, set);
/* 183 */     if (objectInfo != null)
/*     */     {
/* 185 */       validateObjectAndRelations(objectInfo.getMosDetailList(), success, set);
/*     */     }
/* 187 */     return success;
/*     */   }











/*     */   public boolean validateEndPoint(String name, boolean success, MboSetRemote set)
/*     */     throws MXException, RemoteException
/*     */   {
/* 203 */     MaxEndPointInfo endpointInfo = EndPointCache.getInstance().getEndPointInfo(name);
/*     */ 
/* 205 */     String[] params = { this.maximoMLDD.getMboValueInfoStatic(this.ui, "MAXENDPOINT", "ENDPOINTNAME").getTitle(), name };
/* 206 */     success = addAdminMsg(params, 1, endpointInfo != null, success, set);
/* 207 */     return success;
/*     */   }











/*     */   public boolean validateObjectAndRelations(List<MosDetailInfo> list, boolean success, MboSetRemote set)
/*     */     throws MXException, RemoteException
/*     */   {
/* 223 */     String[] objectParam = new String[2];
/* 224 */     String[] relationParam = new String[2];

/*     */ 
/* 227 */     objectParam[0] = this.maximoMLDD.getMboValueInfoStatic(this.ui, "MAXOBJECT", "OBJECTNAME").getTitle();
/*     */ 
/* 229 */     for (int k = 0; k < list.size(); ++k)
/*     */     {
/* 231 */       MosDetailInfo mosDetInfo = (MosDetailInfo)list.get(k);
/*     */ 
/* 233 */       String objectName = mosDetInfo.getObjectName();
/*     */ 
/* 235 */       MboSetInfo mboInfo = this.maximoDD.getMboSetInfo(objectName);
/* 236 */       objectParam[1] = objectName;
/* 237 */       success = addAdminMsg(objectParam, 1, mboInfo != null, success, set);
/* 238 */       if (mosDetInfo.getRelation() == null) {
/*     */         continue;
/*     */       }
/*     */ 
/* 242 */       RelationInfo relInfo = (RelationInfo)this.maximoDD.getRelationships(mosDetInfo.getParentObjName()).get(mosDetInfo.getRelation());
/* 243 */       relationParam[0] = mosDetInfo.getRelation();
/* 244 */       relationParam[1] = mosDetInfo.getParentObjName();
/* 245 */       success = addAdminMsg(relationParam, 3, relInfo != null, success, set);
/*     */     }
/* 247 */     return success;
/*     */   }












/*     */   private boolean addAdminMsg(String[] params, int order, boolean found, boolean success, MboSetRemote set)
/*     */     throws MXException, RemoteException
/*     */   {
/* 264 */     String msg = null;
/* 265 */     MicUtil.INTEGRATIONLOGGER.info(msg);
/*     */ 
/* 267 */     this.adminMsgs.append('\r');
/* 268 */     this.adminMsgs.append('\n');
/* 269 */     if (found)
/*     */     {
/* 271 */       MXException ex = new MXApplicationException("iface", this.messages[order], params);
/* 272 */       msg = ex.getMessage(set);
/*     */     }
/*     */     else
/*     */     {
/* 276 */       MXException ex = new MXApplicationException("iface", this.messages[(order + 1)], params);
/* 277 */       msg = ex.getMessage(set);
/* 278 */       success = false;
/*     */     }
/* 280 */     this.adminMsgs.append(msg);
/* 281 */     return success;
/*     */   }
/*     */ }
