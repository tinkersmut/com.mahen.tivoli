/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import psdi.iface.mic.InvokeChannel;
/*     */ import psdi.iface.mic.InvokeChannelCache;
/*     */ import psdi.iface.mic.InvokeInfo;
/*     */ 






























































































/*     */ public final class InteractionInfo
/*     */ {
/*     */   private String description;
/*     */   private String interactionName;
/*     */   private String appName;
/*     */   private boolean applyResponse;
/*     */   private String mapOption;
/*     */   private String intObject;
/*     */   private byte[] obp;
/*     */   private String channelName;
/*     */   private String reqRelation;
/*     */   private String respRelation;
/*     */   private String intMode;
/*     */   private String dialogId;
/*     */   private String requestOSName;
/*     */   private String responseOSName;
/*     */   private boolean commitResponse;
/*     */   private boolean isActive;
/*     */   private boolean genMenuOption;
/*     */   private boolean showSingleResponse;
/*     */   private String requestMappingClass;
/*     */   private String responseMappingClass;
/*  77 */   private Map<String, Map<String, IntMappingInfo>> allOS = new HashMap();
/*     */ 
/*     */   public InteractionInfo(String interactionName, String description, String appName, int applyResponse, String mapOption, String intObject, byte[] obp, String channelName, String reqRelation, String respRelation, String intMode, String dialogId, String requestMappingClass, String responseMappingClass, int commitResponse, int showSingleResponse, int active, int genMenuOption)
/*     */   {
/* 129 */     this.interactionName = interactionName;
/* 130 */     this.description = description;
/* 131 */     this.appName = appName;
/* 132 */     this.applyResponse = (1 == applyResponse);
/* 133 */     this.mapOption = mapOption;
/* 134 */     this.intObject = intObject;
/* 135 */     this.obp = obp;
/* 136 */     this.channelName = channelName;
/* 137 */     this.reqRelation = reqRelation;
/* 138 */     this.respRelation = respRelation;
/* 139 */     this.requestMappingClass = requestMappingClass;
/* 140 */     this.responseMappingClass = responseMappingClass;
/* 141 */     this.intMode = intMode;
/* 142 */     this.dialogId = dialogId;
/* 143 */     this.commitResponse = (1 == commitResponse);
/* 144 */     this.isActive = (1 == active);
/* 145 */     this.genMenuOption = (1 == genMenuOption);
/* 146 */     this.showSingleResponse = (1 == showSingleResponse);
/* 147 */     InvokeChannel invokeChannel = InvokeChannelCache.getInstance().getInvokeChannel(channelName);
/*     */ 
/* 149 */     if (invokeChannel == null)
/*     */       return;
/* 151 */     InvokeInfo invokeInfo = invokeChannel.getInvokeInfo();
/* 152 */     setRequestOSName(invokeInfo.getMosName());
/* 153 */     setResponseOSName(invokeInfo.getReplyMosName());
/* 154 */     Map requestMap = new HashMap();
/* 155 */     Map responseMap = new HashMap();
/* 156 */     this.allOS.put(this.requestOSName, requestMap);
/* 157 */     this.allOS.put(this.responseOSName, responseMap);
/*     */   }







/*     */   public String getChannelName()
/*     */   {
/* 168 */     return this.channelName;
/*     */   }






/*     */   public String getReqRelation()
/*     */   {
/* 178 */     return this.reqRelation;
/*     */   }







/*     */   public String getRespRelation()
/*     */   {
/* 189 */     return this.respRelation;
/*     */   }






/*     */   public String getIntMode()
/*     */   {
/* 199 */     return this.intMode;
/*     */   }






/*     */   public String getDialogId()
/*     */   {
/* 209 */     return this.dialogId;
/*     */   }






/*     */   public String getMapOption()
/*     */   {
/* 219 */     return this.mapOption;
/*     */   }






/*     */   public String getIntMainObject()
/*     */   {
/* 229 */     return this.intObject;
/*     */   }






/*     */   public byte[] getObp()
/*     */   {
/* 239 */     return this.obp;
/*     */   }






/*     */   public String getDescription()
/*     */   {
/* 249 */     return this.description;
/*     */   }






/*     */   public String getRequestOSName()
/*     */   {
/* 259 */     return this.requestOSName;
/*     */   }






/*     */   public String getResponseOSName()
/*     */   {
/* 269 */     return this.responseOSName;
/*     */   }






/*     */   public String getRequestMappingClass()
/*     */   {
/* 279 */     if ((this.requestMappingClass == null) || (this.requestMappingClass.trim().length() == 0))

/*     */     {
/* 282 */       return "com.ibm.tivoli.maximo.interaction.process.InteractionRequestBinder";
/*     */     }
/* 284 */     return this.requestMappingClass;
/*     */   }






/*     */   public String getResponseMappingClass()
/*     */   {
/* 294 */     if ((this.responseMappingClass == null) || (this.responseMappingClass.trim().length() == 0))

/*     */     {
/* 297 */       return "com.ibm.tivoli.maximo.interaction.process.InteractionResponseBinder";
/*     */     }
/* 299 */     return this.responseMappingClass;
/*     */   }






/*     */   public String getAppName()
/*     */   {
/* 309 */     return this.appName;
/*     */   }






/*     */   public String getInteractionName()
/*     */   {
/* 319 */     return this.interactionName;
/*     */   }






/*     */   public boolean applyResponse()
/*     */   {
/* 329 */     return this.applyResponse;
/*     */   }






/*     */   public boolean generateMenuOption()
/*     */   {
/* 339 */     return this.genMenuOption;
/*     */   }






/*     */   public boolean isCommitResponse()
/*     */   {
/* 349 */     return this.commitResponse;
/*     */   }






/*     */   public boolean isActive()
/*     */   {
/* 359 */     return this.isActive;
/*     */   }







/*     */   public boolean showSingleResponse()
/*     */   {
/* 370 */     return this.showSingleResponse;
/*     */   }






/*     */   public Map<String, Map<String, IntMappingInfo>> getObjectStructure()
/*     */   {
/* 380 */     return this.allOS;
/*     */   }









/*     */   public Map<String, IntMappingInfo> getAllObjects(String osName)
/*     */   {
/* 393 */     return ((Map)this.allOS.get(osName));
/*     */   }











/*     */   public IntMappingInfo getObjectMapping(String osName, String hpath)
/*     */   {
/* 408 */     return ((IntMappingInfo)((Map)this.allOS.get(osName)).get(hpath));
/*     */   }





/*     */   public void setRequestOSName(String mosName)
/*     */   {
/* 417 */     this.requestOSName = mosName;
/*     */   }





/*     */   public void setResponseOSName(String mosName)
/*     */   {
/* 426 */     this.responseOSName = mosName;
/*     */   }
/*     */ }
