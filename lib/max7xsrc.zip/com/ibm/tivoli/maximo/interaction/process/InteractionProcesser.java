/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import psdi.iface.mic.IntegrationContext;
/*     */ import psdi.iface.mos.MosDetailInfo;
/*     */ import psdi.iface.mos.MosInfo;
/*     */ import psdi.iface.mos.ObjectStructureCache;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXAccessException;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 

































/*     */ public class InteractionProcesser
/*     */ {
/*  50 */   InteractionInfo info = null;
/*  51 */   String interactionName = null;
/*  52 */   String intMode = null;
/*  53 */   boolean showResponse = true;
/*  54 */   boolean uiInteraction = true;
/*     */ 
/*  59 */   public static final MXLogger INTERACTIONLOGGER = InteractionUtil.INTERACTIONLOGGER;
/*     */ 
/*     */   public InteractionProcesser(String intName)
/*     */     throws MXException, RemoteException
/*     */   {
/*  73 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/*  75 */       INTERACTIONLOGGER.debug("Construct Interaction Processer ");
/*  76 */       INTERACTIONLOGGER.debug("Interaction Name " + intName);
/*     */     }
/*  78 */     this.interactionName = intName.toUpperCase();
/*  79 */     this.uiInteraction = false;
/*  80 */     this.info = InteractionCache.getInstance().getInteractionInfo(this.interactionName);
/*  81 */     if (this.info == null)
/*     */     {
/*  83 */       String[] params = { this.interactionName };
/*  84 */       throw new MXApplicationException("iface", "interaction_not_found", params);
/*     */     }
/*  86 */     this.intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", this.info.getIntMode());
/*     */ 
/*  88 */     if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*     */       return;
/*  90 */     INTERACTIONLOGGER.debug("Interaction Name " + this.interactionName);
/*  91 */     INTERACTIONLOGGER.debug("Interaction mode " + this.intMode);
/*     */   }











/*     */   public InteractionProcesser(String sigoption, String appname)
/*     */     throws MXException, RemoteException
/*     */   {
/* 107 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 109 */       INTERACTIONLOGGER.debug("Construct Interaction Processer ");
/* 110 */       INTERACTIONLOGGER.debug("Sigoption Name " + sigoption);
/* 111 */       INTERACTIONLOGGER.debug("Application Name " + appname);
/*     */     }
/* 113 */     this.uiInteraction = true;
/* 114 */     this.info = InteractionCache.getInstance().getInteractionInfo(sigoption.toUpperCase(), appname.toUpperCase());
/* 115 */     if (this.info == null)
/*     */     {
/* 117 */       String[] params = { sigoption, appname };
/* 118 */       throw new MXApplicationException("iface", "interaction_not_found", params);
/*     */     }
/* 120 */     this.interactionName = this.info.getInteractionName();
/* 121 */     this.intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", this.info.getIntMode());
/*     */ 
/* 123 */     if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*     */       return;
/* 125 */     INTERACTIONLOGGER.debug("Interaction Name " + this.interactionName);
/* 126 */     INTERACTIONLOGGER.debug("Interaction mode " + this.intMode);
/*     */   }












/*     */   public InteractionProcesser(String mainObjectName, String relation, String topObject)
/*     */     throws MXException, RemoteException
/*     */   {
/* 143 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 145 */       INTERACTIONLOGGER.debug("Construct Interaction Processer ");
/* 146 */       INTERACTIONLOGGER.debug("Interaction Main Object Name " + mainObjectName);
/* 147 */       INTERACTIONLOGGER.debug("Relation Name " + relation);
/* 148 */       INTERACTIONLOGGER.debug("Request Top Object Name " + topObject);
/*     */     }
/* 150 */     this.uiInteraction = true;
/* 151 */     this.info = InteractionCache.getInstance().getInteractionInfo(mainObjectName, relation, topObject);
/* 152 */     if (this.info == null)
/*     */     {
/* 154 */       String[] params = { mainObjectName, relation, topObject };
/* 155 */       throw new MXApplicationException("iface", "interaction_not_found", params);
/*     */     }
/* 157 */     this.interactionName = this.info.getInteractionName();
/* 158 */     this.intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", this.info.getIntMode());
/*     */ 
/* 160 */     if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*     */       return;
/* 162 */     INTERACTIONLOGGER.debug("Interaction Name " + this.interactionName);
/* 163 */     INTERACTIONLOGGER.debug("Interaction mode " + this.intMode);
/*     */   }













/*     */   public MboSetRemote processInteraction(MboRemote appMbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 181 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 183 */       INTERACTIONLOGGER.debug("Entering ProcessInteraction " + this.interactionName);
/* 184 */       INTERACTIONLOGGER.debug("Interaction Active " + this.info.isActive());
/* 185 */       INTERACTIONLOGGER.debug("Interaction Main Object " + this.info.getIntMainObject());
/* 186 */       INTERACTIONLOGGER.debug("Application Mbo Name " + appMbo.getName());
/*     */     }
/* 188 */     if (!(this.info.getIntMainObject().equals(appMbo.getName())))
/*     */     {
/* 190 */       String[] params = { this.info.getIntMainObject(), appMbo.getName() };
/* 191 */       throw new MXApplicationException("iface", "intmainobject_mbo_mismatch", params);
/*     */     }
/* 193 */     if (!(this.info.isActive()))
/*     */     {
/* 195 */       String[] params = { this.interactionName };
/* 196 */       throw new MXApplicationException("iface", "interaction_inactive", params);
/*     */     }
/* 198 */     MboSetRemote setReturn = appMbo.getMboSet(this.info.getReqRelation());
/* 199 */     setReturn.clear();
/* 200 */     WSIO top = OBPGenerator.parse(this.info.getObp()).getRequest();
/* 201 */     WSIO processWsio = findWSIO(top, setReturn.getName());
/* 202 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 204 */       INTERACTIONLOGGER.debug("Process WSIO " + processWsio.getName());
/*     */     }
/* 206 */     ((RequestMboSet)setReturn).setWSIO(processWsio);
/* 207 */     fillRequest(setReturn, appMbo);
/* 208 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 210 */       INTERACTIONLOGGER.debug("request Size" + setReturn.getSize());
/*     */     }
/* 212 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 214 */       INTERACTIONLOGGER.debug("Interaction Mode" + this.intMode);
/*     */     }
/* 216 */     if ((this.intMode.equals("SHOWREQONLY")) || (this.intMode.equals("SHOWREQRESP")))
/*     */     {
/* 218 */       return setReturn;
/*     */     }
/* 220 */     if (invokeservice(appMbo))
/*     */     {
/* 222 */       INTERACTIONLOGGER.debug("Leaving ProcessInteraction after invoke ");
/* 223 */       return setReturn;
/*     */     }
/* 225 */     MboRemote requestMbo = setReturn.getMbo(0);
/* 226 */     MboSetRemote responseSet = requestMbo.getMboSet(this.info.getRespRelation());
/* 227 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 229 */       INTERACTIONLOGGER.debug("Response Size is " + responseSet.getSize());
/*     */     }
/* 231 */     if (applychanges(setReturn, appMbo))
/*     */     {
/* 233 */       INTERACTIONLOGGER.debug("Interaction saved ");
/* 234 */       responseSet.save();
/*     */     }
/* 236 */     INTERACTIONLOGGER.debug("Leaving ProcessInteraction after apply ");
/* 237 */     return responseSet;
/*     */   }













/*     */   public void fillRequest(MboSetRemote requestSet, MboRemote mbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 255 */     INTERACTIONLOGGER.debug("Entering fillRequest ");
/* 256 */     InteractionBinder intBinder = getInteractionMapper(this.info.getRequestMappingClass());
/* 257 */     intBinder.bind(requestSet, mbo, false);
/* 258 */     INTERACTIONLOGGER.debug("Leaving fillRequest ");
/*     */   }












/*     */   public boolean invokeservice(MboRemote mbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 275 */     boolean contextOwner = false;
/*     */     try
/*     */     {
/* 278 */       INTERACTIONLOGGER.debug("Entering invokeservice ");
/* 279 */       IntegrationContext cntx = IntegrationContext.getCurrentContext();
/* 280 */       if (cntx == null)
/*     */       {
/* 282 */         cntx = IntegrationContext.createCurrentContext();
/* 283 */         contextOwner = true;
/*     */       }
/* 285 */       cntx.setProperty("accessmodifier", Long.valueOf(6L));
/* 286 */       MboSetRemote requestSet = mbo.getMboSet(this.info.getReqRelation());
/* 287 */       ServiceInvokerInfo serviceInfo = new ServiceInvokerInfo(this.info.getChannelName(), null, this.info.getRespRelation(), 1, null, null, "Invoke");

/*     */ 
/* 290 */       Map metaData = new HashMap();


/*     */ 
/* 294 */       metaData.put("INTERACTION", this.interactionName);
/* 295 */       ExternalServiceInvoker srv = new ExternalServiceInvoker();
/* 296 */       srv.invokeService(requestSet, serviceInfo, metaData);
/* 297 */       MboSetRemote responseSet = requestSet.getMbo(0).getMboSet(this.info.getRespRelation());
/* 298 */       int size = responseSet.getSize();
/* 299 */       if ((size == 0) && (this.uiInteraction))
/*     */       {
/* 301 */         throw new MXApplicationException("iface", "norowsreturned");
/*     */       }
/* 303 */       if ((this.intMode.equals("SHOWRESPONLY")) || (this.intMode.equals("SHOWREQRESP")))
/*     */       {
/* 305 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/* 307 */           INTERACTIONLOGGER.debug("Response Size is " + size);
/* 308 */           INTERACTIONLOGGER.debug("Single Response  " + this.info.showSingleResponse());
/*     */         }
/* 310 */         if ((size == 0) || (size > 1) || (this.info.showSingleResponse()))
/*     */         {
/* 312 */           INTERACTIONLOGGER.debug("Leaving invokeservice no apply");
/* 313 */           primaryInfo = ObjectStructureCache.getInstance().getMosInfo(this.info.getResponseOSName()).getPrimaryMosDetailInfo();
/* 314 */           unselect(primaryInfo, responseSet);
/* 315 */           int i = 1;

/*     */           return i;
/*     */         }
/* 319 */         this.showResponse = false;
/* 320 */         primaryInfo = 0;
/*     */         return primaryInfo;
/*     */       }
/* 323 */       if ((this.intMode.equals("SILENT")) && (!(this.info.applyResponse())))
/*     */       {
/* 325 */         INTERACTIONLOGGER.debug("Leaving invokeservice no apply silent ");
/* 326 */         primaryInfo = 1;
/*     */         return primaryInfo;/*     */       }
/* 328 */       INTERACTIONLOGGER.debug("Leaving invokeservice apply");
/* 329 */       MosDetailInfo primaryInfo = 0;
/*     */     }
/*     */     finally
/*     */     {
/* 333 */       if ((IntegrationContext.getCurrentContext() != null) && (contextOwner))
/*     */ 
/*     */       {/* 335 */       return primaryInfo;/* 335 */         IntegrationContext.destroyCurrentContext();
/*     */       }
/*     */     }
/*     */   }














/*     */   public boolean applychanges(MboSetRemote set, MboRemote mbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 356 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 358 */       INTERACTIONLOGGER.debug("Entering applychanges apply response" + this.info.applyResponse());
/*     */     }
/* 360 */     if (!(this.info.applyResponse()))
/*     */     {
/* 362 */       return false;
/*     */     }
/* 364 */     MboSetRemote responseSet = set.getMbo(0).getMboSet(this.info.getRespRelation());
/* 365 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 367 */       INTERACTIONLOGGER.debug("Apply Mbo is " + mbo.getName());




/*     */     }
/*     */ 
/* 374 */     InteractionBinder intBinder = getInteractionMapper(this.info.getResponseMappingClass());
/* 375 */     intBinder.bind(responseSet, mbo, true);
/* 376 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 378 */       INTERACTIONLOGGER.debug("Leaving applychanges Commit Response " + this.info.isCommitResponse());

/*     */     }
/*     */ 
/* 382 */     return (this.info.isCommitResponse());
/*     */   }















/*     */   private InteractionBinder getInteractionMapper(String className)
/*     */     throws MXException, RemoteException
/*     */   {
/* 402 */     if (className == null)
/*     */     {
/* 404 */       throw new MXSystemException("system", "noclass");
/*     */     }
/*     */     try
/*     */     {
/* 408 */       Class handlerClass = Class.forName(className);
/* 409 */       Class[] paramTypes = { String.class };
/* 410 */       Object[] params = { this.interactionName };
/* 411 */       Constructor mapperConstr = handlerClass.getConstructor(paramTypes);
/* 412 */       InteractionBinder mapper = (InteractionBinder)mapperConstr.newInstance(params);
/* 413 */       return mapper;
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 417 */       throw new MXSystemException("system", "noclass", e);
/*     */     }
/*     */     catch (IllegalAccessException ae)
/*     */     {
/* 421 */       throw new MXAccessException("access", "method", ae);
/*     */     }
/*     */     catch (InstantiationException ie)
/*     */     {
/* 425 */       throw new MXSystemException("system", "access", ie);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 429 */       throw new MXSystemException("system", "unknownerror", e);
/*     */     }
/*     */   }















/*     */   private WSIO findWSIO(WSIO wsio, String name)
/*     */     throws MXException, RemoteException
/*     */   {
/* 450 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 452 */       INTERACTIONLOGGER.debug("Entering findWSIO ");
/* 453 */       INTERACTIONLOGGER.debug("Mbo Name is " + name);
/* 454 */       INTERACTIONLOGGER.debug("WSIO Name is " + wsio.getName());
/*     */     }
/* 456 */     if (wsio.getName().equals(name))
/*     */     {
/* 458 */       return wsio;
/*     */     }
/* 460 */     List wsioList = wsio.getWSIOChildren();
/* 461 */     if (wsioList != null)
/*     */     {
/* 463 */       for (WSIO childWSIO : wsioList)
/*     */       {
/* 465 */         wsio = findWSIO(childWSIO, name);
/* 466 */         if (wsio != null)
/*     */         {
/* 468 */           return wsio;
/*     */         }
/*     */       }
/*     */     }
/* 472 */     return null;
/*     */   }









/*     */   public boolean showResponse()
/*     */     throws MXException, RemoteException
/*     */   {
/* 486 */     return this.showResponse;
/*     */   }










/*     */   public void unselect(MosDetailInfo info, MboSetRemote set)
/*     */     throws MXException, RemoteException
/*     */   {
/* 501 */     set.unselectAll();
/* 502 */     MboRemote mbo = null;
/* 503 */     for (int i = 0; ; ++i)
/*     */     {
/* 505 */       mbo = set.getMbo(i);
/* 506 */       if (mbo == null) {
/*     */         return;
/*     */       }
/*     */ 
/* 510 */       List children = info.getChildren();
/* 511 */       if ((children == null) || (children.isEmpty()))
/*     */       {
/* 513 */         return;
/*     */       }
/* 515 */       Iterator childrenInfoItr = children.iterator();
/* 516 */       while (childrenInfoItr.hasNext())
/*     */       {
/* 518 */         MosDetailInfo childInfo = (MosDetailInfo)childrenInfoItr.next();
/* 519 */         MboSetRemote childSet = mbo.getMboSet(childInfo.getRelation());
/* 520 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/* 522 */           INTERACTIONLOGGER.debug("Unselect object name " + childInfo.getIntObjectName());
/* 523 */           INTERACTIONLOGGER.debug("Unselect Relation " + childInfo.getRelation());
/*     */         }
/* 525 */         if (childSet.isEmpty()) {
/*     */           continue;
/*     */         }
/*     */ 
/* 529 */         unselect(childInfo, childSet);
/*     */       }
/*     */     }
/*     */   }
/*     */ }
