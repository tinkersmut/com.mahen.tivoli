/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import psdi.iface.mos.MosDetailInfo;
/*     */ import psdi.iface.mos.MosInfo;
/*     */ import psdi.iface.mos.ObjectStructureCache;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 



























/*     */ public class InteractionResponseBinder extends InteractionBinder
/*     */ {
/*     */   public InteractionResponseBinder(String interactionName)
/*     */     throws MXException, RemoteException
/*     */   {
/*  51 */     super(interactionName);
/*     */   }















/*     */   public void bind(MboSetRemote interactionSet, MboRemote mainMbo, boolean isResponse)
/*     */     throws MXException, RemoteException
/*     */   {
/*  71 */     INTERACTIONLOGGER.debug("Entering bind ");
/*     */ 
/*  73 */     MosDetailInfo primaryInfo = ObjectStructureCache.getInstance().getMosInfo(this.interactionInfo.getResponseOSName()).getPrimaryMosDetailInfo();
/*  74 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/*  76 */       INTERACTIONLOGGER.debug("Response OS Name " + this.interactionInfo.getResponseOSName());
/*  77 */       INTERACTIONLOGGER.debug("Primary Info Name " + primaryInfo.getObjectName());
/*     */     }
/*  79 */     String intMode = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("INTMODE", this.interactionInfo.getIntMode());
/*     */ 
/*  81 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/*  83 */       INTERACTIONLOGGER.debug("Interaction Mode " + intMode);
/*     */     }
/*  85 */     if (interactionSet.getSize() == 0)
/*     */     {
/*  87 */       return;
/*     */     }
/*  89 */     if ((interactionSet.getSize() == 1) && (intMode.equals("SHOWREQRESP")))
/*     */     {
/*  91 */       interactionSet.selectAll();
/*     */     }
/*  93 */     else if ((intMode.equals("SILENT")) || (intMode.equals("SHOWREQONLY")))
/*     */     {
/*  95 */       interactionSet.selectAll();
/*     */     }
/*  97 */     Vector selected = interactionSet.getSelection();
/*  98 */     if (selected.size() == 0)
/*     */     {
/* 100 */       throw new MXApplicationException("jspmessages", "table_noselectedrows");
/*     */     }
/* 102 */     bindLevel(primaryInfo, interactionSet, mainMbo, intMode);
/*     */ 
/* 104 */     INTERACTIONLOGGER.debug("Leaving bind ");
/*     */   }


















/*     */   protected void bindLevel(MosDetailInfo mosInfo, MboSetRemote sourceSet, MboRemote targetMbo, String intMode)
/*     */     throws MXException, RemoteException
/*     */   {
/* 127 */     INTERACTIONLOGGER.debug("Entering bindLevel ");
/*     */ 
/* 129 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 131 */       INTERACTIONLOGGER.debug("Int object name " + mosInfo.getIntObjectName());
/* 132 */       INTERACTIONLOGGER.debug("Object path name " + mosInfo.getObjectPath());
/*     */     }
/* 134 */     Vector selected = sourceSet.getSelection();
/* 135 */     IntMappingInfo mapping = this.interactionInfo.getObjectMapping(mosInfo.getIntObjectName(), mosInfo.getObjectPath());
/*     */ 
/* 137 */     if ((mapping == null) || (mapping.getMapObject() == null))
/*     */     {
/* 139 */       INTERACTIONLOGGER.debug("No mapping found. Existing ");
/* 140 */       return;
/*     */     }
/* 142 */     List childrenInfo = mosInfo.getChildren();
/* 143 */     String targetRelation = mapping.getRelation();
/* 144 */     MboSetRemote relaltedTargetSet = null;
/* 145 */     if (targetRelation == null)
/*     */     {
/* 147 */       INTERACTIONLOGGER.debug("In use parent logic ");
/* 148 */       if (selected.size() > 1)
/*     */       {
/* 150 */         throw new MXApplicationException("iface", "onlyonetarget");
/*     */       }
/* 152 */       MboRemote sourceMbo = (MboRemote)selected.elementAt(0);
/* 153 */       if ((mapping.getObjectMappings() != null) && (mapping.getObjectMappings().size() > 0))
/*     */       {
/* 155 */         bindInteractionData(sourceMbo, targetMbo, mapping);
/*     */       }
/*     */       else
/*     */       {
/* 159 */         INTERACTIONLOGGER.debug("No mapping attributes found. No binding is performed ");
/*     */       }
/* 161 */       if ((childrenInfo == null) || (childrenInfo.size() == 0))
/*     */       {
/* 163 */         return;
/*     */       }
/* 165 */       Iterator childrenInfoItr = childrenInfo.iterator();
/* 166 */       while (childrenInfoItr.hasNext())
/*     */       {
/* 168 */         MosDetailInfo childInfo = (MosDetailInfo)childrenInfoItr.next();
/* 169 */         MboSetRemote childSet = sourceMbo.getMboSet(childInfo.getRelation());
/* 170 */         if (childSet.getSize() == 0)
/*     */         {
/* 172 */           return;
/*     */         }
/* 174 */         if ((childSet.getSize() == 1) && (intMode.equals("SHOWREQRESP")) && (!(this.interactionInfo.showSingleResponse())))

/*     */         {
/* 177 */           childSet.selectAll();
/*     */         }
/* 179 */         if ((intMode.equals("SILENT")) || (intMode.equals("SHOWREQONLY")))
/*     */         {
/* 181 */           childSet.selectAll();
/*     */         }
/* 183 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/* 185 */           INTERACTIONLOGGER.debug("Child Int object name " + childInfo.getIntObjectName());
/* 186 */           INTERACTIONLOGGER.debug("Child Object path name " + childInfo.getObjectPath());
/* 187 */           INTERACTIONLOGGER.debug("Child Relation " + childInfo.getRelation());
/*     */         }
/* 189 */         bindLevel(childInfo, childSet, targetMbo, intMode);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 194 */       relaltedTargetSet = targetMbo.getMboSet(targetRelation);
/* 195 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 197 */         INTERACTIONLOGGER.debug("In relation logic " + targetRelation);
/* 198 */         INTERACTIONLOGGER.debug("Related sets name " + relaltedTargetSet.getName());
/*     */       }
/* 200 */       for (int x = 0; x < selected.size(); ++x)
/*     */       {
/* 202 */         MboRemote sourceMbo = (MboRemote)selected.elementAt(x);
/* 203 */         targetMbo = findMbo(sourceMbo, relaltedTargetSet, mapping, "");
/* 204 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/* 206 */           INTERACTIONLOGGER.debug("Target Mbo " + targetMbo.getName());
/*     */         }
/* 208 */         if ((mapping.getObjectMappings() != null) && (mapping.getObjectMappings().size() > 0))
/*     */         {
/* 210 */           bindInteractionData(sourceMbo, targetMbo, mapping);
/*     */         }
/*     */         else
/*     */         {
/* 214 */           INTERACTIONLOGGER.debug("No mapping attributes found. No binding is performed ");
/*     */         }
/* 216 */         if ((childrenInfo == null) || (childrenInfo.size() == 0))
/*     */         {
/* 218 */           return;
/*     */         }
/* 220 */         Iterator childrenInfoItr = childrenInfo.iterator();
/* 221 */         while (childrenInfoItr.hasNext())
/*     */         {
/* 223 */           MosDetailInfo childInfo = (MosDetailInfo)childrenInfoItr.next();
/* 224 */           MboSetRemote childSet = sourceMbo.getMboSet(childInfo.getRelation());
/* 225 */           if (childSet.getSize() == 0)
/*     */           {
/* 227 */             return;
/*     */           }
/* 229 */           if ((childSet.getSize() == 1) && (intMode.equals("SHOWREQRESP")) && (!(this.interactionInfo.showSingleResponse())))

/*     */           {
/* 232 */             childSet.selectAll();
/*     */           }
/* 234 */           if ((intMode.equals("SILENT")) || (intMode.equals("SHOWREQONLY")))
/*     */           {
/* 236 */             childSet.selectAll();
/*     */           }
/* 238 */           if (INTERACTIONLOGGER.isDebugEnabled())
/*     */           {
/* 240 */             INTERACTIONLOGGER.debug("Child Int object name " + childInfo.getIntObjectName());
/* 241 */             INTERACTIONLOGGER.debug("Child Object path name " + childInfo.getObjectPath());
/* 242 */             INTERACTIONLOGGER.debug("Child Relation " + childInfo.getRelation());
/*     */           }
/* 244 */           bindLevel(childInfo, childSet, targetMbo, intMode);
/*     */         }
/*     */       }
/*     */     }
/* 248 */     INTERACTIONLOGGER.debug("Leaving bindLevel ");
/*     */   }
/*     */ }
