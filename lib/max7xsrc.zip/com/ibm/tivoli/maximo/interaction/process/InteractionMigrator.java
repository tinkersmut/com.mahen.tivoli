/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import psdi.dm.DMPackageDef;
/*     */ import psdi.dm.pkg.DMPackage;
/*     */ import psdi.iface.mic.IntegrationContext;
/*     */ import psdi.iface.mic.InvokeChannelCache;
/*     */ import psdi.iface.mic.InvokeInfo;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.txn.MXTransaction;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 





























































/*     */ public class InteractionMigrator
/*     */ {
/*     */   public static final String INTERACTION_OBJECT_GROUP = "INTERACTION_OBJ";
/*     */   public static final String INTERACTION_INT_GROUP = "INTERACTION_INT";
/*     */   public static final String INTERACTION_OBJECT_PKGDEF = "INTERACTION_OBJ";
/*     */   public static final String INTERACTION_INT_PKGDEF = "INTERACTION_INT";
/*  80 */   MaximoDD maximoDD = null;
/*     */ 
/*  84 */   InteractionInfo interactionInfo = null;
/*     */ 
/*  88 */   UserInfo ui = null;
/*     */ 
/*  92 */   MXTransaction mxTrans = null;
/*     */ 
/*  96 */   public static final MXLogger INTERACTIONLOGGER = InteractionUtil.INTERACTIONLOGGER;
/*     */ 
/*     */   public InteractionMigrator(String name, MXTransaction trans, UserInfo userInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 111 */     this.maximoDD = MXServer.getMXServer().getMaximoDD();
/* 112 */     this.ui = userInfo;
/* 113 */     this.mxTrans = trans;
/* 114 */     this.interactionInfo = InteractionCache.getInstance().getInteractionInfo(name);
/* 115 */     if (this.interactionInfo != null)
/*     */       return;
/* 117 */     throw new MXApplicationException("iface", "intnotvalidated");
/*     */   }






/*     */   public void migrateInteraction()
/*     */     throws MXException, RemoteException
/*     */   {
/* 128 */     List objectWhereList = buildObjectDMWhereList();
/* 129 */     for (int i = 0; i < objectWhereList.size(); ++i)
/*     */     {
/* 131 */       Map objectWhereMap = (Map)objectWhereList.get(i);
/* 132 */       migrate("INTERACTION_OBJ", "INTERACTION_OBJ", objectWhereMap);
/*     */     }
/* 134 */     Map intWhereMap = buildIntDMWhereClause();
/* 135 */     migrate("INTERACTION_INT", "INTERACTION_INT", intWhereMap);
/*     */   }








/*     */   public void migrate(String groupName, String defName, Map<String, String> whereMap)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 150 */       IntegrationContext.createCurrentContext();
/*     */ 
/* 152 */       MboRemote packageDef = getPackageDef(defName);
/* 153 */       packageDef.setValue("active", true, 1L);
/* 154 */       setDMWhereClause(packageDef, groupName, defName, whereMap);
/* 155 */       if (defName.equals("INTERACTION_INT"))
/*     */       {
/* 157 */         IntegrationContext.getCurrentContext().setProperty("osfilter", buildChildrenWhereClause());
/*     */       }
/*     */ 
/* 160 */       MboSetRemote packageSet = packageDef.getMboSet("DMPACKAGE");
/* 161 */       MboRemote pkg = packageSet.add();
/* 162 */       ((DMPackageDef)packageDef).extractPkgData(pkg);
/* 163 */       String packageName = pkg.getString("package");

/*     */ 
/* 166 */       MboRemote newPackageDef = getPackageDef(defName);
/* 167 */       MboSetRemote newPackageSet = newPackageDef.getMboSet("DMPACKAGE");
/* 168 */       SqlFormat sqf = new SqlFormat("package=:1");
/* 169 */       sqf.setObject(1, "DMPACKAGE", "package", packageName);
/* 170 */       newPackageSet.setWhere(sqf.format());
/* 171 */       MboRemote newPkg = newPackageSet.moveFirst();
/* 172 */       if (newPkg == null)
/*     */       {
/* 174 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/* 176 */           INTERACTIONLOGGER.debug("No distribution is created for the package definition. Package is not distribute. Please create distribution and ditribute package manually");
/*     */         }
/*     */         return;
/*     */       }
/* 180 */       MboSetRemote destSet = newPkg.getMboSet("DMPKGDIST");
/* 181 */       if (!(destSet.isEmpty()))
/*     */       {
/* 183 */         destSet.selectAll();
/*     */       }
/* 185 */       ((DMPackage)newPkg).distributePackage();
/*     */     }
/*     */     finally
/*     */     {
/* 189 */       IntegrationContext.destroyCurrentContext();
/*     */     }
/*     */   }







/*     */   public List<Map<String, String>> buildObjectDMWhereList()
/*     */     throws MXException, RemoteException
/*     */   {
/* 202 */     int whereLength = MXServer.getMXServer().getMaximoDD().getMboSetInfo("DMPKGCFGOBJDEF").getMboValueInfo("whereclause").getLength();
/*     */ 
/* 204 */     WSIO request = OBPGenerator.parse(this.interactionInfo.getObp()).getRequest();
/* 205 */     WSIO response = OBPGenerator.parse(this.interactionInfo.getObp()).getResponse();

/*     */ 
/* 208 */     StringBuffer objectWhereClsBuf = new StringBuffer();
/* 209 */     List objectWhere = new ArrayList();
/* 210 */     objectWhereClsBuf = InteractionUtil.getObjectsWhere(request, objectWhereClsBuf);
/* 211 */     if ((response != null) && (!(response.equals(""))))
/*     */     {
/* 213 */       objectWhereClsBuf.append(",");
/* 214 */       objectWhereClsBuf = InteractionUtil.getObjectsWhere(response, objectWhereClsBuf);
/*     */     }
/* 216 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 218 */       INTERACTIONLOGGER.debug("Object where clause " + objectWhereClsBuf.toString());
/*     */     }
/* 220 */     breakObjectWhere(objectWhereClsBuf.toString(), whereLength, objectWhere);

/*     */ 
/* 223 */     StringBuffer domainBuf = new StringBuffer();
/* 224 */     List domainWhere = new ArrayList();
/* 225 */     StringBuffer objectForDomainBufer = new StringBuffer();
/* 226 */     objectForDomainBufer.append("objectname in (");
/* 227 */     objectForDomainBufer.append(objectWhereClsBuf.toString());
/* 228 */     objectForDomainBufer.append(")");
/* 229 */     Set domIdSet = InteractionUtil.getMaxAttrDomainIds(objectForDomainBufer, this.ui);
/* 230 */     if ((domIdSet != null) && (domIdSet.size() > 0))
/*     */     {
/* 232 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 234 */         INTERACTIONLOGGER.debug("Domain where clause " + domainBuf.toString());
/*     */       }
/* 236 */       domainBuf = InteractionUtil.getDomainListWhere(domIdSet, domainBuf);
/* 237 */       breakObjectWhere(domainBuf.toString(), whereLength, domainWhere);

/*     */     }
/*     */ 
/* 241 */     List relationWhere = new ArrayList();
/* 242 */     StringBuffer reqRelationBuffer = InteractionUtil.getIntrRelationsWhere(request, this.interactionInfo, true);
/* 243 */     StringBuffer respRelationBuffer = InteractionUtil.getIntrRelationsWhere(response, this.interactionInfo, false);
/* 244 */     reqRelationBuffer.append(" or ");
/* 245 */     reqRelationBuffer.append(respRelationBuffer);
/*     */ 
/* 247 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 249 */       INTERACTIONLOGGER.debug("Relation where clause " + reqRelationBuffer.toString());
/*     */     }
/* 251 */     breakRelationWhere(reqRelationBuffer.toString(), whereLength, relationWhere);

/*     */ 
/* 254 */     String intObjectWhere = "intobjectname = '" + this.interactionInfo.getRequestOSName() + "' or intobjectname = '" + this.interactionInfo.getResponseOSName() + "'";

/*     */ 
/* 257 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 259 */       INTERACTIONLOGGER.debug("Object Structure where clause " + intObjectWhere);
/*     */     }
/* 261 */     List dmObjectWhere = buildCombineWhere(domainWhere, objectWhere, relationWhere, intObjectWhere);
/*     */ 
/* 263 */     return dmObjectWhere;
/*     */   }







/*     */   public Map<String, String> buildIntDMWhereClause()
/*     */     throws MXException, RemoteException
/*     */   {
/* 275 */     Map whereMap = new HashMap();

/*     */ 
/* 278 */     String authWhere = getAppAuth();
/* 279 */     if ((authWhere == null) || (authWhere.equals("")))
/*     */     {
/* 281 */       whereMap.put("DMMAXGROUP", "1=2");
/*     */     }
/*     */     else
/*     */     {
/* 285 */       whereMap.put("DMMAXGROUP", authWhere);
/*     */     }
/* 287 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 289 */       INTERACTIONLOGGER.debug("MaxGroup where clause " + ((String)whereMap.get("DMMAXGROUP")));

/*     */     }
/*     */ 
/* 293 */     if (this.interactionInfo.getDialogId() != null)
/*     */     {
/* 295 */       whereMap.put("DMMAXAPPS", "app='" + this.interactionInfo.getAppName() + "'");
/*     */     }
/*     */     else
/*     */     {
/* 299 */       whereMap.put("DMMAXAPPS", "1=2");
/*     */     }
/* 301 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 303 */       INTERACTIONLOGGER.debug("Maxapps where clause " + ((String)whereMap.get("DMMAXAPPS")));

/*     */     }
/*     */ 
/* 307 */     if (this.interactionInfo.generateMenuOption())
/*     */     {
/* 309 */       whereMap.put("DMMAXMENU", "moduleapp='" + this.interactionInfo.getAppName() + "' and (keyvalue='" + this.interactionInfo.getMapOption() + "' or keyvalue = 'AM5980' or keyvalue = 'SM5981')");

/*     */     }
/*     */     else
/*     */     {
/* 314 */       whereMap.put("DMMAXMENU", "1=2");
/*     */     }
/* 316 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 318 */       INTERACTIONLOGGER.debug("Maxmenu where clause " + ((String)whereMap.get("DMMAXMENU")));
/*     */     }
/*     */ 
/* 321 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 323 */       INTERACTIONLOGGER.debug("Invoke Channel where clause " + ((String)whereMap.get("DMACTION")));

/*     */     }
/*     */ 
/* 327 */     String endPointName = InvokeChannelCache.getInstance().getInvokeInfo(this.interactionInfo.getChannelName()).getEndPointName();
/* 328 */     if ((endPointName == null) || (endPointName.equals("")))
/*     */     {
/* 330 */       whereMap.put("DMMAXENDPOINT", "1=2");
/*     */     }
/*     */     else
/*     */     {
/* 334 */       whereMap.put("DMMAXENDPOINT", "endpointname = '" + endPointName + "'");
/*     */     }
/* 336 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 338 */       INTERACTIONLOGGER.debug("End point where clause " + ((String)whereMap.get("DMMAXENDPOINT")));

/*     */     }
/*     */ 
/* 342 */     whereMap.put("DMMAXIFACEINVOKE", "ifacename='" + this.interactionInfo.getChannelName() + "'");
/* 343 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 345 */       INTERACTIONLOGGER.debug("Invoke Channel where clause " + ((String)whereMap.get("DMMAXIFACEINVOKE")));

/*     */     }
/*     */ 
/* 349 */     whereMap.put("DMINTERACTION", "interaction='" + this.interactionInfo.getInteractionName() + "'");
/* 350 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 352 */       INTERACTIONLOGGER.debug("Interaction where clause " + ((String)whereMap.get("DMINTERACTION")));
/*     */     }
/*     */ 
/* 355 */     return whereMap;
/*     */   }







/*     */   public Map<String, Map<String, String>> buildChildrenWhereClause()
/*     */     throws MXException, RemoteException
/*     */   {
/* 367 */     Map whereMap = new HashMap();
/*     */ 
/* 369 */     whereMap.put("APPLICATIONAUTH", "app='" + this.interactionInfo.getAppName() + "' and optionname='" + this.interactionInfo.getMapOption() + "'");
/* 370 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 372 */       INTERACTIONLOGGER.debug("Application where clause " + ((String)whereMap.get("APPLICATIONAUTH")));
/*     */     }
/* 374 */     whereMap.put("SITEAUTH", "1=2");
/* 375 */     whereMap.put("GLAUTH", "1=2");
/* 376 */     whereMap.put("SECURITYRESTRICT", "1=2");
/* 377 */     whereMap.put("L_MAXAPPS", "1=2");
/* 378 */     whereMap.put("APPDOCTYPE", "1=2");
/* 379 */     whereMap.put("SIGOPTION", "app='" + this.interactionInfo.getAppName() + "' and optionname='" + this.interactionInfo.getMapOption() + "'");
/* 380 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 382 */       INTERACTIONLOGGER.debug("Sigoption where clause " + ((String)whereMap.get("SIGOPTION")));
/*     */     }
/* 384 */     whereMap.put("MAXHANDLER", "1=2");
/*     */ 
/* 386 */     Map skipKeys = new HashMap();
/* 387 */     skipKeys.put("FILTERMBO", whereMap);
/*     */ 
/* 389 */     return skipKeys;
/*     */   }











/*     */   public void setDMWhereClause(MboRemote packageDef, String groupName, String defName, Map<String, String> whereMap)
/*     */     throws MXException, RemoteException
/*     */   {
/* 405 */     MboSetRemote pkgCfgGroupDefSet = packageDef.getMboSet("DMPKGCFGGRPDEF");
/*     */ 
/* 407 */     if ((pkgCfgGroupDefSet.isEmpty()) || (pkgCfgGroupDefSet.getSize() > 1))
/*     */     {
/* 409 */       String[] params = { defName };
/* 410 */       throw new MXApplicationException("iface", "onlyonegroup", params);
/*     */     }
/* 412 */     MboRemote pkgCfgGroupDef = pkgCfgGroupDefSet.moveFirst();
/*     */ 
/* 414 */     if (!(pkgCfgGroupDef.getString("cfgobjgroup").equals(groupName)))
/*     */     {
/* 416 */       String[] params = { groupName, defName };
/* 417 */       throw new MXApplicationException("iface", "wronggroup", params);
/*     */     }
/*     */ 
/* 420 */     MboSetRemote pkgCfgObjDetailSet = pkgCfgGroupDef.getMboSet("DMPKGCFGOBJDEF");
/*     */ 
/* 422 */     MboRemote pkgCfgObjDetail = null;
/*     */ 
/* 424 */     if (!(pkgCfgObjDetailSet.isEmpty()))
/*     */     {
/* 426 */       for (int j = 0; ; ++j)
/*     */       {
/* 428 */         pkgCfgObjDetail = pkgCfgObjDetailSet.getMbo(j);
/* 429 */         if (pkgCfgObjDetail == null) {
/*     */           break;
/*     */         }
/*     */ 
/* 433 */         String intObjectName = pkgCfgObjDetail.getString("cfgobject");
/* 434 */         String where = (String)whereMap.get(intObjectName);
/* 435 */         if ((where == null) || (where.equals("")))
/*     */         {
/* 437 */           pkgCfgObjDetail.setValueNull("whereclause");
/*     */         }
/*     */         else
/*     */         {
/* 441 */           pkgCfgObjDetail.setValue("whereclause", where);
/*     */         }
/* 443 */         whereMap.remove(intObjectName);
/*     */       }
/*     */     }
/* 446 */     if (!(whereMap.isEmpty()))
/*     */     {
/* 448 */       Iterator itr = whereMap.keySet().iterator();
/* 449 */       while (itr.hasNext())
/*     */       {
/* 451 */         String intObjectName = (String)itr.next();
/* 452 */         pkgCfgObjDetail = pkgCfgObjDetailSet.add();
/* 453 */         pkgCfgObjDetail.setValue("cfgobject", intObjectName);
/* 454 */         pkgCfgObjDetail.setValue("whereclause", (String)whereMap.get(intObjectName));
/*     */       }
/*     */     }
/* 457 */     pkgCfgObjDetailSet.getMXTransaction().save();
/*     */   }






/*     */   private String getAppAuth()
/*     */     throws RemoteException, MXException
/*     */   {
/* 468 */     String auth = null;
/* 469 */     MboSetRemote existAuth = MXServer.getMXServer().getMboSet("APPLICATIONAUTH", this.ui);
/*     */ 
/* 471 */     SqlFormat sqf = new SqlFormat(this.ui, "app = :1 and optionname = :2");
/* 472 */     sqf.setObject(1, "APPLICATIONAUTH", "APP", this.interactionInfo.getAppName());
/* 473 */     sqf.setObject(2, "APPLICATIONAUTH", "OPTIONNAME", this.interactionInfo.getMapOption());
/* 474 */     existAuth.setWhere(sqf.format());
/* 475 */     if (existAuth.isEmpty())
/*     */     {
/* 477 */       return null;
/*     */     }
/* 479 */     MboRemote authMbo = null;
/* 480 */     for (int j = 0; ; ++j)
/*     */     {
/* 482 */       authMbo = existAuth.getMbo(j);
/* 483 */       if (authMbo == null) {
/*     */         break;
/*     */       }
/*     */ 
/* 487 */       if (auth == null)
/*     */       {
/* 489 */         auth = "groupname = '" + authMbo.getString("groupname") + "'";
/*     */       }
/*     */       else
/*     */       {
/* 493 */         auth = auth + " or groupname = '" + authMbo.getString("groupname") + "'";
/*     */       }
/*     */     }
/* 496 */     return auth;
/*     */   }







/*     */   private MboRemote getPackageDef(String defName)
/*     */     throws RemoteException, MXException
/*     */   {
/* 508 */     MboSetRemote pkgDefSet = MXServer.getMXServer().getMboSet("DMPACKAGEDEF", this.ui);
/* 509 */     pkgDefSet.setMXTransaction(this.mxTrans);
/* 510 */     SqlFormat sqf = new SqlFormat("pkgdefname=:1");
/* 511 */     sqf.setObject(1, "DMPACKAGEDEF", "pkgdefname", defName);
/*     */ 
/* 513 */     pkgDefSet.setWhere(sqf.format());
/* 514 */     MboRemote packageDef = pkgDefSet.moveFirst();
/* 515 */     if (packageDef == null)
/*     */     {
/* 517 */       String[] params = { defName };
/* 518 */       throw new MXApplicationException("iface", "dmpackdefmissing", params);
/*     */     }
/* 520 */     return packageDef;
/*     */   }











/*     */   public List<String> breakRelationWhere(String where, int maxLength, List<String> allWheres)
/*     */     throws MXException, RemoteException
/*     */   {
/* 536 */     if (where.length() < maxLength - 10)
/*     */     {
/* 538 */       allWheres.add(where);
/*     */     }
/*     */     else
/*     */     {
/* 542 */       String first = where.substring(0, maxLength);
/* 543 */       String firstWhere = first.substring(0, first.lastIndexOf(")") + 1);
/* 544 */       allWheres.add(firstWhere);
/* 545 */       String rest = where.substring(firstWhere.length());
/* 546 */       rest = rest.substring(rest.indexOf("("));
/* 547 */       breakRelationWhere(rest, maxLength, allWheres);
/*     */     }
/* 549 */     return allWheres;
/*     */   }











/*     */   public List<String> breakObjectWhere(String where, int maxLength, List<String> allWheres)
/*     */     throws MXException, RemoteException
/*     */   {
/* 565 */     if (where.length() < maxLength - 10)
/*     */     {
/* 567 */       allWheres.add(where);
/*     */     }
/*     */     else
/*     */     {
/* 571 */       String first = where.substring(0, maxLength);
/* 572 */       String firstWhere = first.substring(0, first.lastIndexOf(","));
/* 573 */       allWheres.add(firstWhere);
/* 574 */       String rest = where.substring(firstWhere.length());
/* 575 */       rest = rest.substring(rest.indexOf("'"));
/* 576 */       breakObjectWhere(rest, maxLength, allWheres);
/*     */     }
/* 578 */     return allWheres;
/*     */   }














/*     */   public List<Map<String, String>> buildCombineWhere(List<String> domainWhere, List<String> objectWhere, List<String> relationWhere, String intObjectWhere)
/*     */     throws MXException, RemoteException
/*     */   {
/* 597 */     List allWheres = new ArrayList(relationWhere.size());
/*     */ 
/* 599 */     for (int i = 0; i < relationWhere.size(); ++i)
/*     */     {
/* 601 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 603 */         INTERACTIONLOGGER.debug("Where clause list element " + i);
/*     */       }
/* 605 */       Map whereMap = new HashMap();
/* 606 */       String relWhere = (String)relationWhere.get(i);
/* 607 */       whereMap.put("DMMAXRELATIONSHIP", relWhere);
/* 608 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 610 */         INTERACTIONLOGGER.debug("Relationship where clause " + ((String)whereMap.get("DMMAXRELATIONSHIP")));
/*     */       }
/* 612 */       if ((domainWhere != null) && (domainWhere.size() > i))
/*     */       {
/* 614 */         whereMap.put("DMMAXDOMAIN", "domainid in (" + ((String)domainWhere.get(i)) + ")");
/*     */       }
/*     */       else
/*     */       {
/* 618 */         whereMap.put("DMMAXDOMAIN", "1=2");
/*     */       }
/* 620 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 622 */         INTERACTIONLOGGER.debug("Domain where clause " + ((String)whereMap.get("DMMAXDOMAIN")));
/*     */       }
/* 624 */       if ((objectWhere != null) && (objectWhere.size() > i))
/*     */       {
/* 626 */         whereMap.put("DMMAXOBJECTCFG", "objectname in (" + ((String)objectWhere.get(i)) + ")");
/*     */       }
/*     */       else
/*     */       {
/* 630 */         whereMap.put("DMMAXOBJECTCFG", "1=2");
/*     */       }
/* 632 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 634 */         INTERACTIONLOGGER.debug("Object where clause " + ((String)whereMap.get("DMMAXOBJECTCFG")));
/*     */       }
/* 636 */       if (i == 0)
/*     */       {
/* 638 */         whereMap.put("DMMAXINTOBJECT", intObjectWhere);
/*     */       }
/*     */       else
/*     */       {
/* 642 */         whereMap.put("DMMAXINTOBJECT", "1=2");
/*     */       }
/* 644 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 646 */         INTERACTIONLOGGER.debug("Object Structure where clause " + ((String)whereMap.get("DMMAXINTOBJECT")));
/*     */       }
/* 648 */       allWheres.add(whereMap);
/*     */     }
/* 650 */     return allWheres;
/*     */   }
/*     */ }
