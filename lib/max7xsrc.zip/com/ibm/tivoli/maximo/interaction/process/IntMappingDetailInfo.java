/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXCipher;
/*     */ import psdi.util.MXException;
/*     */ 

































/*     */ public final class IntMappingDetailInfo
/*     */ {
/*     */   private String attributeName;
/*     */   private String value;
/*     */   private byte[] encryptedValue;
/*  38 */   private boolean isEncrypted = false;
/*     */ 
/*     */   public IntMappingDetailInfo(String attributeName, String value, byte[] encryptedValue, int encryptValue)
/*     */   {
/*  50 */     this.attributeName = attributeName;
/*  51 */     this.value = value;
/*  52 */     this.encryptedValue = encryptedValue;
/*  53 */     this.isEncrypted = (1 == encryptValue);
/*     */   }






/*     */   public String getAttributeName()
/*     */   {
/*  63 */     return this.attributeName;
/*     */   }





/*     */   public String getParameter()
/*     */   {
/*  72 */     return this.attributeName;
/*     */   }




/*     */   public String getValue()
/*     */     throws MXException, RemoteException
/*     */   {
/*  81 */     if ((isEncryped()) && 

/*  83 */       (this.encryptedValue != null))
/*     */     {
/*  85 */       String passwordValue = MXServer.getMXServer().getMXCipher().decData(this.encryptedValue);
/*     */ 
/*  87 */       if (!(passwordValue.startsWith("'")))
/*     */       {
/*  89 */         passwordValue = "'" + passwordValue + "'";
/*     */       }
/*  91 */       return passwordValue;
/*     */     }
/*     */ 
/*  94 */     return this.value;
/*     */   }




/*     */   public byte[] getEncryptedValue()
/*     */   {
/* 102 */     return this.encryptedValue;
/*     */   }





/*     */   public boolean isEncryped()
/*     */   {
/* 111 */     return this.isEncrypted;
/*     */   }
/*     */ }
