/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIOAttribute;
/*     */ import java.io.File;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.iface.mos.MosDetailInfo;
/*     */ import psdi.iface.mos.MosInfo;
/*     */ import psdi.iface.mos.ObjectStructureCache;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.Message;
/*     */ import psdi.util.Resolver;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 

















































/*     */ public class InteractionUtil
/*     */ {
/*     */   public static final String INTERACTION_LOGGER = "maximo.interaction";
/*  57 */   public static final MXLogger INTERACTIONLOGGER = MXLoggerFactory.getLogger("maximo.interaction");
/*     */   public static final String INTERACTION_DIR = "interaction";
/*     */   public static final String INTERACTION = "INTERACTION";
/*     */   public static final String DIALOG = "dialog";
/*     */   public static final String OBP = "obp";
/*     */   public static final String MAXTYPE_YORN = "YORN";
/*     */   public static final String MAXTYPE_BLOB = "BLOB";
/*     */   public static final String MAXTYPE_DATETIME = "DATETIME";
/*     */   public static final String MAXTYPE_FLOAT = "FLOAT";
/*     */   public static final String MAXTYPE_DATE = "DATE";
/*     */   public static final String MAXTYPE_TIME = "TIME";
/*     */   public static final String MAXTYPE_ALN = "ALN";
/*     */   public static final String MAXTYPE_INTEGER = "INTEGER";
/*     */   public static final String MAXTYPE_DECIMAL = "DECIMAL";
/*     */ 
/*     */   public static String getMaxType(WSIOAttribute wsioAttr)
/*     */   {
/*  95 */     if (wsioAttr.getType().equals("Boolean"))
/*  96 */       return "YORN";
/*  97 */     if (wsioAttr.getType().equals("Byte"))
/*  98 */       return "BLOB";
/*  99 */     if (wsioAttr.getType().equals("Base64Bytes"))
/* 100 */       return "BLOB";
/* 101 */     if (wsioAttr.getType().equals("HexBytes"))
/* 102 */       return "BLOB";
/* 103 */     if (wsioAttr.getType().equals("DateTime"))
/* 104 */       return "DATETIME";
/* 105 */     if (wsioAttr.getType().equals("Double"))
/* 106 */       return "FLOAT";
/* 107 */     if (wsioAttr.getType().equals("Date"))
/* 108 */       return "DATE";
/* 109 */     if (wsioAttr.getType().equals("Time"))
/* 110 */       return "TIME";
/* 111 */     if (wsioAttr.getType().equals("Float"))
/* 112 */       return "FLOAT";
/* 113 */     if (wsioAttr.getType().equals("Integer"))
/* 114 */       return "INTEGER";
/* 115 */     if (wsioAttr.getType().equals("Long"))
/* 116 */       return "INTEGER";
/* 117 */     if (wsioAttr.getType().equals("Short"))
/* 118 */       return "INTEGER";
/* 119 */     if (wsioAttr.getType().equals("BigDecimal"))
/*     */     {
/* 121 */       if (wsioAttr.getTotalDigits() == -1) {
/* 122 */         return "ALN";
/*     */       }
/* 124 */       return "DECIMAL";
/*     */     }
/* 126 */     if (wsioAttr.getType().equals("BigInteger"))
/*     */     {
/* 128 */       if (wsioAttr.getTotalDigits() == -1) {
/* 129 */         return "ALN";
/*     */       }
/* 131 */       return "INTEGER";
/*     */     }
/* 133 */     if (wsioAttr.getType().equals("String")) {
/* 134 */       return "ALN";
/*     */     }
/* 136 */     return "ALN";
/*     */   }











/*     */   public static String getFileName(String inter, String name)
/*     */   {
/* 151 */     String fileDir = MicUtil.getMeaGlobalDir() + File.separator + "interaction";
/*     */ 
/* 153 */     File dir = new File(fileDir);
/* 154 */     if ((!(dir.exists())) && 

/* 156 */       (!(dir.mkdirs())))
/*     */     {
/* 158 */       MicUtil.INTEGRATIONLOGGER.error(Resolver.getResolver().getMessage("iface", "errorinerror").getMessage());


/*     */     }
/*     */ 
/* 163 */     return fileDir + File.separator + inter + "_" + name + ".xml";
/*     */   }


/*     */   public static void reloadCache(WSIO optimizedRequest, WSIO optimizedResponse)
/*     */     throws MXException, RemoteException
/*     */   {
/* 170 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 172 */       INTERACTIONLOGGER.debug("Entering WSIOMaxArtiCreator -reloadCache()");
/*     */     }
/* 174 */     if (optimizedRequest != null)
/* 175 */       reloadObjectCache(optimizedRequest);
/* 176 */     if (optimizedResponse != null)
/* 177 */       reloadObjectCache(optimizedResponse);
/* 178 */     MXServer.getMXServer().getMaximoDD().reload("RELATIONS");
/* 179 */     MXServer.getMXServer().reloadMaximoCache(ObjectStructureCache.getInstance().getName(), true);
/* 180 */     if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*     */       return;
/* 182 */     INTERACTIONLOGGER.debug("Leaving WSIOMaxArtiCreator -reloadCache()");
/*     */   }

/*     */   private static void reloadObjectCache(WSIO wsio)
/*     */     throws MXException, RemoteException
/*     */   {
/* 188 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 190 */       INTERACTIONLOGGER.debug("Entering WSIOMaxArtiCreator -reloadObjectCache()");
/*     */     }
/* 192 */     MXServer.getMXServer().getMaximoDD().reload("OBJECT:" + wsio.getName());
/* 193 */     List wsioList = wsio.getWSIOChildren();
/* 194 */     if (wsioList != null)
/*     */     {
/* 196 */       for (WSIO childWSIO : wsioList)
/* 197 */         reloadObjectCache(childWSIO);
/*     */     }
/* 199 */     if (!(INTERACTIONLOGGER.isDebugEnabled()))
/*     */       return;
/* 201 */     INTERACTIONLOGGER.debug("Leaving WSIOMaxArtiCreator -reloadObjectCache()");
/*     */   }










/*     */   public static Set<String> getMaxAttrDomainIds(StringBuffer whereclause, UserInfo userInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 216 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 218 */       INTERACTIONLOGGER.debug("Entering WSIOMaxArtifactsRemove - getMaxAttrDomainIds().");
/*     */     }
/*     */     try
/*     */     {
/* 222 */       MboSetRemote maxAttributeCfgSet = MXServer.getMXServer().getMboSet("MAXATTRIBUTECFG", userInfo);
/* 223 */       whereclause.append(" and domainid is not null");
/* 224 */       maxAttributeCfgSet.setWhere(whereclause.toString());
/* 225 */       Set domHashSet = new HashSet();
/* 226 */       if (!(maxAttributeCfgSet.isEmpty()))
/*     */       {
/* 228 */         int i = 0;
/* 229 */         MboRemote objectCfg = maxAttributeCfgSet.getMbo(i);
/* 230 */         while (objectCfg != null)
/*     */         {
/* 232 */           domHashSet.add(objectCfg.getString("domainid"));
/* 233 */           objectCfg = maxAttributeCfgSet.getMbo(++i);
/*     */         }
/*     */       }
/* 236 */       if (INTERACTIONLOGGER.isDebugEnabled())
/*     */       {
/* 238 */         INTERACTIONLOGGER.debug("Leaving WSIOMaxArtifactsRemove - getMaxAttrDomainIds().");
/*     */       }
/* 240 */       return domHashSet;
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 244 */       if (INTERACTIONLOGGER.isErrorEnabled())
/*     */       {
/* 246 */         INTERACTIONLOGGER.error("Error in WSIOMaxArtifactsRemove -getMaxAttrDomainIds()." + e.getMessage());
/*     */       }
/* 248 */       throw e;
/*     */     }
/*     */   }

/*     */   public static StringBuffer getWsioRelationsWhere(WSIO wsio, StringBuffer where) throws MXException, RemoteException
/*     */   {
/* 254 */     StringBuffer bufWhere = where;
/* 255 */     if (wsio.getParent() != null)
/*     */     {
/* 257 */       bufWhere.append(" or ");
/* 258 */       bufWhere.append("(name='");
/* 259 */       bufWhere.append(wsio.getName());
/* 260 */       bufWhere.append("' and parent='");
/* 261 */       bufWhere.append(wsio.getParent().getName());
/* 262 */       bufWhere.append("')");
/*     */     }
/* 264 */     List wsioList = wsio.getWSIOChildren();
/* 265 */     if (wsioList != null)
/*     */     {
/* 267 */       for (WSIO childWSIO : wsioList)
/*     */       {
/* 269 */         bufWhere = getWsioRelationsWhere(childWSIO, bufWhere);
/*     */       }
/*     */     }
/* 272 */     return bufWhere;
/*     */   }

/*     */   public static StringBuffer getObjectsWhere(WSIO wsio, StringBuffer where)
/*     */     throws MXException, RemoteException
/*     */   {
/* 278 */     StringBuffer bufWhere = where;
/* 279 */     bufWhere.append("'");
/* 280 */     bufWhere.append(wsio.getName());
/* 281 */     bufWhere.append("'");
/* 282 */     List wsioList = wsio.getWSIOChildren();
/* 283 */     if (wsioList != null)
/*     */     {
/* 285 */       for (WSIO childWSIO : wsioList)
/*     */       {
/* 287 */         bufWhere.append(" , ");
/* 288 */         bufWhere = getObjectsWhere(childWSIO, bufWhere);
/*     */       }
/*     */     }
/* 291 */     return bufWhere;
/*     */   }

/*     */   public static StringBuffer getIntrRelationsWhere(WSIO wsio, InteractionInfo interactionInfo, boolean isReq) throws MXException, RemoteException
/*     */   {
/* 296 */     StringBuffer buf = new StringBuffer();
/* 297 */     if (isReq)

/*     */     {
/* 300 */       buf.append("(name='");
/* 301 */       buf.append(interactionInfo.getReqRelation());
/* 302 */       buf.append("' and parent='");
/* 303 */       buf.append(interactionInfo.getIntMainObject());
/* 304 */       buf.append("')");

/*     */     }
/*     */     else
/*     */     {
/* 309 */       String responseObject = wsio.getName();
/* 310 */       String requestObject = ObjectStructureCache.getInstance().getMosInfo(interactionInfo.getRequestOSName()).getPrimaryMosDetailInfo().getObjectName();

/*     */ 
/* 313 */       buf.append("(name='");
/* 314 */       buf.append(responseObject);
/* 315 */       buf.append("' and parent='");
/* 316 */       buf.append(requestObject);
/* 317 */       buf.append("')");
/*     */     }
/* 319 */     buf = getWsioRelationsWhere(wsio, buf);
/* 320 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/* 322 */       INTERACTIONLOGGER.debug("WSIOMaxArtifactsRemove - getIntrRelationsWhere() where clause:" + buf.toString());
/*     */     }
/* 324 */     return buf;
/*     */   }

/*     */   public static StringBuffer getDomainsWhere(Set<String> domHashSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 330 */     if (domHashSet.size() == 0)
/*     */     {
/* 332 */       return null;
/*     */     }
/* 334 */     StringBuffer buf = new StringBuffer();
/* 335 */     buf.append("domainid in (");
/*     */ 
/* 337 */     getDomainListWhere(domHashSet, buf);
/* 338 */     buf.append(")");
/* 339 */     return buf;
/*     */   }

/*     */   public static StringBuffer getDomainListWhere(Set<String> domHashSet, StringBuffer buf) throws MXException, RemoteException
/*     */   {
/* 344 */     Iterator itr = domHashSet.iterator();
/* 345 */     while (itr.hasNext())
/*     */     {
/* 347 */       String domName = (String)itr.next();
/* 348 */       buf.append("'");
/* 349 */       buf.append(domName);
/* 350 */       buf.append("'");
/* 351 */       if (itr.hasNext())
/* 352 */         buf.append(" , ");
/*     */     }
/* 354 */     return buf;
/*     */   }
/*     */ }
