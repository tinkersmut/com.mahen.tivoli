/*    */ package com.ibm.tivoli.maximo.interaction.process;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.mbo.MboValueData;
/*    */ import psdi.util.MXException;
/*    */ 






























/*    */ public class FldWSIOAttribute extends MboValueAdapter
/*    */ {
/*    */   public FldWSIOAttribute(MboValue mbv)
/*    */   {
/* 43 */     super(mbv);
/*    */   }







/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 55 */     MboValue value = getMboValue();
/* 56 */     ((RequestMbo)value.getMbo()).validateWSIOAttribute(value.getName(), value.getMboValueData().getDataAsObject());
/*    */   }
/*    */ }
