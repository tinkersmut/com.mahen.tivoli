/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jdom.Namespace;
/*     */ import psdi.iface.migexits.ExternalExit;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 



















/*     */ public class WSIOProcessBaseExit extends ExternalExit
/*     */ {
/*     */   String interactionName;
/*     */ 
/*     */   public WSIOProcessBaseExit()
/*     */   {
/*  37 */     this.interactionName = null;
/*     */   }






/*     */   protected MXLogger getLogger()
/*     */   {
/*  47 */     if ((this.interactionName == null) || (this.interactionName.trim().length() == 0))
/*     */     {
/*  49 */       return MXLoggerFactory.getLogger("maximo.interaction");
/*     */     }
/*  51 */     return MXLoggerFactory.getLogger("maximo.interaction." + this.interactionName);
/*     */   }









/*     */   public Namespace getNamespace(String ns, Map<String, String> nsCtx)
/*     */   {
/*  64 */     if ((nsCtx != null) && (!(nsCtx.isEmpty())))
/*     */     {
/*  66 */       Iterator itr = nsCtx.keySet().iterator();
/*  67 */       while (itr.hasNext())
/*     */       {
/*  69 */         String nsUri = (String)itr.next();
/*  70 */         String nsPrefix = (String)nsCtx.get(nsUri);
/*  71 */         if (getLogger().isDebugEnabled())
/*     */         {
/*  73 */           getLogger().debug("WSIORequestExit getNamespace()-nsUri:" + nsUri + ", nsPrefix:" + nsPrefix);
/*     */         }
/*  75 */         if (ns.equals(nsPrefix))
/*     */         {
/*  77 */           return Namespace.getNamespace(nsPrefix, nsUri);
/*     */         }
/*     */       }
/*     */     }
/*  81 */     return null;
/*     */   }










/*     */   public String removeParentLocation(String strXPath, WSIO wsio, boolean isWsioAttr)
/*     */   {
/*  95 */     if (isWsioAttr)
/*     */     {
/*  97 */       if ((wsio != null) && (strXPath.startsWith(wsio.getXmlLocation())))
/*     */       {
/*  99 */         return strXPath.substring(wsio.getXmlLocation().length() + 1, strXPath.length());


/*     */       }
/*     */ 
/*     */     }
/* 105 */     else if ((wsio.getParent() != null) && (strXPath.startsWith(wsio.getParent().getXmlLocation())))
/*     */     {
/* 107 */       return strXPath.substring(wsio.getParent().getXmlLocation().length() + 1, strXPath.length());

/*     */     }
/*     */ 
/* 111 */     return strXPath;
/*     */   }
/*     */ }
