/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.List;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.NonPersistentMboSet;
/*     */ import psdi.util.MXException;
/*     */ 




























/*     */ public class RequestMboSet extends NonPersistentMboSet
/*     */   implements RequestMboSetRemote
/*     */ {
/*  35 */   private WSIO wsio = null;
/*     */ 
/*     */   public RequestMboSet(MboServerInterface ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  50 */     super(ms);
/*     */   }












/*     */   protected Mbo getMboInstance(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  67 */     return new RequestMbo(ms);
/*     */   }










/*     */   public MboRemote setup()
/*     */     throws MXException, RemoteException
/*     */   {
/*  82 */     return null;
/*     */   }





















/*     */   public MboSetRemote processInteraction(MboRemote interactionMbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 108 */     InteractionProcesser interactionProcesser = new InteractionProcesser(interactionMbo.getName(), getRelationName(), getName());
/* 109 */     return interactionProcesser.processInteraction(interactionMbo);
/*     */   }














/*     */   public MboSetRemote processInteraction(String interactionName, MboRemote interactionMbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 128 */     InteractionProcesser interactionProcesser = new InteractionProcesser(interactionName);
/* 129 */     return interactionProcesser.processInteraction(interactionMbo);
/*     */   }

















/*     */   public MboSetRemote processInteraction(String optionName, String appName, MboRemote interactionMbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 151 */     InteractionProcesser interactionProcesser = new InteractionProcesser(optionName, appName);
/* 152 */     return interactionProcesser.processInteraction(interactionMbo);
/*     */   }








/*     */   public void setWSIO(WSIO wsio)
/*     */     throws MXException, RemoteException
/*     */   {
/* 165 */     this.wsio = wsio;
/*     */   }







/*     */   public WSIO getWSIO()
/*     */     throws MXException, RemoteException
/*     */   {
/* 177 */     if (this.wsio == null)
/*     */     {
/* 179 */       MboRemote owner = getOwner();
/* 180 */       if (owner instanceof RequestMbo)
/*     */       {
/* 182 */         WSIO parentWsio = ((RequestMboSet)owner.getThisMboSet()).getWSIO();
/* 183 */         this.wsio = findWSIO(parentWsio, getName());
/*     */       }
/*     */     }
/* 186 */     return this.wsio;
/*     */   }











/*     */   private WSIO findWSIO(WSIO wsio, String name)
/*     */     throws MXException, RemoteException
/*     */   {
/* 202 */     if (wsio.getName().equals(name))
/*     */     {
/* 204 */       return wsio;
/*     */     }
/* 206 */     List wsioList = wsio.getWSIOChildren();
/* 207 */     if (wsioList != null)
/*     */     {
/* 209 */       for (WSIO childWSIO : wsioList)
/*     */       {
/* 211 */         wsio = findWSIO(childWSIO, name);
/* 212 */         if (wsio != null)
/*     */         {
/* 214 */           return wsio;
/*     */         }
/*     */       }
/*     */     }
/* 218 */     return wsio;
/*     */   }
/*     */ }
