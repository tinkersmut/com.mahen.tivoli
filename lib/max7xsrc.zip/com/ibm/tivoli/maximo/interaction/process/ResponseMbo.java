/*    */ package com.ibm.tivoli.maximo.interaction.process;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.NonPersistentMbo;
/*    */ import psdi.util.MXException;
/*    */ 































/*    */ public class ResponseMbo extends NonPersistentMbo
/*    */ {
/*    */   public ResponseMbo(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 44 */     super(ms);
/*    */   }
/*    */ }
