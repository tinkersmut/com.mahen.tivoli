/*    */ package com.ibm.tivoli.maximo.interaction.process;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.NonPersistentMboSet;
/*    */ import psdi.util.MXException;
/*    */ 






























/*    */ public class ResponseMboSet extends NonPersistentMboSet
/*    */ {
/*    */   public ResponseMboSet(MboServerInterface ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 46 */     super(ms);
/*    */   }












/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 63 */     return new ResponseMbo(ms);
/*    */   }










/*    */   public MboRemote setup()
/*    */     throws MXException, RemoteException
/*    */   {
/* 78 */     return null;
/*    */   }
/*    */ }
