/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import psdi.iface.mos.MosDetailInfo;
/*     */ import psdi.iface.mos.MosInfo;
/*     */ import psdi.iface.mos.ObjectStructureCache;
/*     */ import psdi.mbo.MaximoCache;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.security.SecurityService;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.DBManager;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXFormat;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 




















/*     */ public class InteractionCache
/*     */   implements MaximoCache
/*     */ {
/*  43 */   private Map<String, InteractionInfo> inter = new HashMap();
/*     */   private static InteractionCache singleton;
/*  50 */   private static final MXLogger interactionLogger = InteractionUtil.INTERACTIONLOGGER;
/*     */ 
/*     */   public static InteractionCache getInstance()
/*     */     throws MXException
/*     */   {
/*  59 */     if (singleton == null)
/*     */     {
/*  61 */       singleton = new InteractionCache();
/*     */     }
/*  63 */     return singleton;
/*     */   }





/*     */   private InteractionCache()
/*     */     throws MXException
/*     */   {
/*  73 */     init();
/*     */     try
/*     */     {
/*  76 */       MXServer.getMXServer().addToMaximoCache(getName(), this);
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/*  80 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/*  82 */         interactionLogger.error(re.getMessage(), re);
/*     */       }
/*  84 */       throw new MXSystemException("system", "remoteexception", re);
/*     */     }
/*     */   }





/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  95 */     loadMaxInteraction();
/*     */   }





/*     */   public synchronized void reload()
/*     */     throws MXException
/*     */   {
/* 105 */     this.inter.clear();
/* 106 */     init();
/*     */   }

















/*     */   public String getName()
/*     */   {
/* 127 */     return "MAXINTERACTION";
/*     */   }





/*     */   private void loadMaxInteraction()
/*     */     throws MXException
/*     */   {
/* 137 */     Statement s = null;
/* 138 */     UserInfo systemUserInfo = null;
/*     */     try
/*     */     {
/* 141 */       SecurityService secServ = (SecurityService)MXServer.getMXServer().lookup("SECURITY");
/* 142 */       systemUserInfo = secServ.getSystemUserInfo();
/* 143 */       Connection connection = MXServer.getMXServer().getDBManager().getConnection(systemUserInfo.getConnectionKey());

/*     */ 
/* 146 */       s = connection.createStatement();
/* 147 */       s.execute("select mi.interaction, mi.description, mi.appname, mi.applyresponse, mi.mapoption, mi.intmainobject, mi.obp, mi.channelname, mi.reqrelation, mi.resprelation, mi.intmode, mi.dialogid, mi.reqclassname, mi.respclassname, mi.commitresponse, mi.showsingleresponse, mi.active, mi.genmenuoption from maxinteraction mi");





/*     */ 
/* 154 */       ResultSet rs = s.getResultSet();
/*     */ 
/* 156 */       while (rs.next())
/*     */       {
/* 158 */         String stringObp = null;
/* 159 */         String name = rs.getString(1);
/* 160 */         InteractionInfo info = (InteractionInfo)this.inter.get(name);
/* 161 */         if (info == null)
/*     */         {
/* 163 */           Object obp = rs.getObject(7);
/* 164 */           if (MXServer.getMXServer().getMaximoDD().storeClobAsClob())
/*     */           {
/* 166 */             stringObp = MXFormat.clobToString((Clob)obp);
/*     */           }
/*     */           else
/*     */           {
/* 170 */             stringObp = (String)obp;
/*     */           }
/*     */ 
/* 173 */           info = new InteractionInfo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), stringObp.getBytes("UTF-8"), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getInt(15), rs.getInt(16), rs.getInt(17), rs.getInt(18));


/*     */ 
/* 177 */           this.inter.put(name, info);
/*     */         }
/*     */       }
/* 180 */       loadMaxIntMapping(connection);
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 184 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 186 */         interactionLogger.error(e.getMessage(), e);
/*     */       }
/*     */       Object[] params;
/* 189 */       throw new MXSystemException("system", "sql", params, e);
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/* 193 */       if (interactionLogger.isErrorEnabled());



/* 197 */       throw new MXSystemException("system", "remoteexception", re);
/*     */     }
/*     */     catch (Exception ee)
/*     */     {
/* 201 */       if (interactionLogger.isErrorEnabled());



/* 205 */       throw new MXSystemException("system", "major", ee);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 211 */         if (s != null)
/*     */         {
/* 213 */           s.close();
/*     */         }
/* 215 */         MXServer.getMXServer().getDBManager().freeConnection(systemUserInfo.getConnectionKey());

/*     */       }
/*     */       catch (Exception e1)
/*     */       {
/* 220 */         if (interactionLogger.isErrorEnabled())
/*     */         {
/* 222 */           interactionLogger.error(e1.getMessage(), e1);
/*     */         }
/*     */       }
/*     */     }
/*     */   }





/*     */   private void loadMaxIntMapping(Connection connection)
/*     */     throws MXException
/*     */   {
/* 235 */     Statement s = null;
/*     */     try
/*     */     {
/* 238 */       s = connection.createStatement();
/* 239 */       s.execute("select mp.interaction, mp.intobjectname, mp.mapobject, mp.hierarchypath, mp.objectname, mp.relation, mp.isresponse, mp.processorder, mpd.attributename, mpd.value, mpd.password, mpd.encryptvalue from maxintmapping mp left outer join maxintmappingdetail mpd on mp.interaction=mpd.interaction and mp.hierarchypath=mpd.hierarchypath order by mp.interaction, mp.isresponse, mp.processorder");





/*     */ 
/* 246 */       ResultSet rs = s.getResultSet();
/*     */ 
/* 248 */       while (rs.next())
/*     */       {
/* 250 */         String mapObject = rs.getString(3);
/* 251 */         if (rs.wasNull()) {
/*     */           continue;
/*     */         }
/*     */ 
/* 255 */         String name = rs.getString(1);
/* 256 */         InteractionInfo info = (InteractionInfo)this.inter.get(name);
/*     */ 
/* 258 */         String osName = rs.getString(2);
/* 259 */         Map path = (Map)info.getObjectStructure().get(osName);
/*     */ 
/* 261 */         String hierarchyPath = rs.getString(4);
/*     */ 
/* 263 */         IntMappingInfo mapInfo = (IntMappingInfo)path.get(hierarchyPath);
/* 264 */         if (mapInfo == null)
/*     */         {
/* 266 */           mapInfo = new IntMappingInfo(rs.getString(2), mapObject, rs.getString(4), rs.getString(5), rs.getString(6), rs.getInt(7), rs.getInt(8));

/*     */ 
/* 269 */           path.put(hierarchyPath, mapInfo);
/*     */         }
/* 271 */         String attribute = rs.getString(9);
/*     */ 
/* 273 */         if (rs.wasNull()) {
/*     */           continue;
/*     */         }
/*     */ 
/* 277 */         byte[] encryptedValue = rs.getBytes(11);
/* 278 */         IntMappingDetailInfo detailInfo = new IntMappingDetailInfo(attribute, rs.getString(10), encryptedValue, rs.getInt(12));
/* 279 */         List mapping = mapInfo.getObjectMappings();
/* 280 */         if (mapping == null)
/*     */         {
/* 282 */           mapping = new ArrayList();
/* 283 */           mapInfo.setObjectMappings(mapping);
/*     */         }
/* 285 */         mapping.add(detailInfo);
/*     */       }
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 290 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 292 */         interactionLogger.error(e.getMessage(), e);
/*     */       }
/* 294 */       Object[] params = { new Integer(e.getErrorCode()).toString() };
/* 295 */       throw new MXSystemException("system", "sql", params, e);
/*     */     }
/*     */     catch (Exception ee)
/*     */     {
/* 299 */       if (interactionLogger.isErrorEnabled())
/*     */       {
/* 301 */         interactionLogger.error(ee.getMessage(), ee);
/*     */       }
/* 303 */       throw new MXSystemException("system", "major", ee);
/*     */     }
/*     */   }







/*     */   public Map<String, InteractionInfo> getAllInteractions()
/*     */   {
/* 315 */     return this.inter;
/*     */   }







/*     */   public InteractionInfo getInteractionInfo(String name)
/*     */   {
/* 326 */     return ((InteractionInfo)this.inter.get(name));
/*     */   }








/*     */   public InteractionInfo getInteractionInfo(String sigoption, String appname)
/*     */   {
/* 338 */     Iterator itr = this.inter.keySet().iterator();
/* 339 */     while (itr.hasNext())
/*     */     {
/* 341 */       InteractionInfo intInfo = (InteractionInfo)this.inter.get((String)itr.next());
/* 342 */       if ((intInfo.getMapOption().equals(sigoption)) && (intInfo.getAppName().equals(appname)))
/*     */       {
/* 344 */         return intInfo;
/*     */       }
/*     */     }
/* 347 */     return null;
/*     */   }









/*     */   public InteractionInfo getInteractionInfo(String mainObjectName, String relation, String topObject)
/*     */     throws MXException
/*     */   {
/* 361 */     Iterator itr = this.inter.keySet().iterator();
/* 362 */     while (itr.hasNext())
/*     */     {
/* 364 */       InteractionInfo intInfo = (InteractionInfo)this.inter.get((String)itr.next());
/* 365 */       if ((intInfo.getIntMainObject().equals(mainObjectName)) && (intInfo.getReqRelation().equals(relation)))

/*     */       {
/* 368 */         String top = ObjectStructureCache.getInstance().getMosInfo(intInfo.getRequestOSName()).getPrimaryMosDetailInfo().getObjectName();
/*     */ 
/* 370 */         if (topObject.equals(top))
/*     */         {
/* 372 */           return intInfo;
/*     */         }
/*     */       }
/*     */     }
/* 376 */     return null;
/*     */   }
/*     */ }
