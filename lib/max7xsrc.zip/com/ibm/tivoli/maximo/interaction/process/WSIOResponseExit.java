/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIOAttribute;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jdom.Attribute;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.Namespace;
/*     */ import org.jdom.xpath.XPath;
/*     */ import psdi.iface.mic.IntegrationContext;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.iface.util.XMLUtils;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 






















/*     */ public class WSIOResponseExit extends WSIOProcessBaseExit
/*     */ {
/*     */   private InteractionInfo interactionInfo;
/*     */ 
/*     */   public WSIOResponseExit()
/*     */   {
/*  55 */     this.interactionInfo = null;
/*     */   }















/*     */   public StructureData setDataIn(StructureData userExitData)
/*     */     throws MXException, RemoteException
/*     */   {
/*  75 */     this.interactionInfo = null;






/*     */     try
/*     */     {
/*  84 */       if (getLogger().isDebugEnabled())
/*     */       {
/*  86 */         getLogger().debug("Entering WSIOResponseExit setDataIn():");
/*     */       }
/*  88 */       Document extRespDoc = userExitData.getData();
/*  89 */       this.interactionName = IntegrationContext.getCurrentContext().getStringProperty("INTERACTION");
/*  90 */       this.interactionInfo = InteractionCache.getInstance().getInteractionInfo(this.interactionName);
/*     */ 
/*  92 */       if (this.interactionInfo == null)
/*     */       {
/*  94 */         this.interactionInfo = ((InteractionInfo)IntegrationContext.getCurrentContext().getProperty("INTERACTIONINFO"));

/*     */       }
/*     */ 
/*  98 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 100 */         getLogger().debug("WSIOResponseExit - setDataIn() - Response xml from Service:" + new String(XMLUtils.convertDocumentToBytes(extRespDoc), "utf-8"));
/*     */ 
/* 102 */         getLogger().debug("WSIOResponseExit - setDataIn() - Interaction OBP xml:" + new String(this.interactionInfo.getObp(), "utf-8"));
/*     */       }
/*     */ 
/* 105 */       Document respDoc = mapResponse(extRespDoc, this.interactionInfo.getObp());
/* 106 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 108 */         if (respDoc == null)
/* 109 */           getLogger().debug("WSIOResponseExit - setDataIn() - Mapped document: respDoc is null.");
/*     */         else {
/* 111 */           getLogger().debug("WSIOResponseExit - setDataIn() - Mapped document:" + new String(XMLUtils.convertDocumentToBytes(respDoc), "utf-8"));
/*     */         }
/* 113 */         getLogger().debug("Leaving WSIOResponseExit setDataIn():");
/*     */       }
/*     */ 
/* 116 */       return new StructureData(respDoc);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 120 */       if (e instanceof MXException)
/* 121 */         throw ((MXException)e);
/*     */       try
/*     */       {
/* 124 */         getLogger().error("Error in WSIOResponseExit - setDataIn()-Incoming doc:" + new String(userExitData.getDataAsBytes(), "utf-8"));
/* 125 */         getLogger().error("Error in WSIOResponseExit - setDataIn()-OBP:" + new String(this.interactionInfo.getObp(), "utf-8"));
/*     */       }
/*     */       catch (UnsupportedEncodingException ee) {
/* 128 */         getLogger().error("Error in WSIOResponseExit - setDataIn()-UnsupportedEncodingException while converting bytes to string:" + ee.getMessage());
/*     */       }
/*     */ 
/* 131 */       throw new MXApplicationException("iface", "resp_mapping_Error", e);
/*     */     }
/*     */   }











/*     */   public Document mapResponse(Document responseDoc, byte[] bObp)
/*     */     throws MXException, RemoteException
/*     */   {
/* 148 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 150 */       getLogger().debug("Entering WSIOResponseExit mapResponse():");
/*     */     }
/* 152 */     OBPInfo respOBPInfo = OBPGenerator.parse(bObp);
/* 153 */     Map nsCtx = respOBPInfo.getNsContext();
/*     */ 
/* 155 */     WSIO respWsio = respOBPInfo.getResponse();
/* 156 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 158 */       if (respWsio == null) {
/* 159 */         getLogger().debug(" mapResponse respWsio is null.");
/*     */       }
/*     */       else {
/* 162 */         getLogger().debug(" mapResponse respWsio:" + respWsio.getName() + ", mapResponse Response WSIO isMaxOccursUnbounded:" + respWsio.isMaxOccursUnbounded());

/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 168 */     Element rootElm = responseDoc.getRootElement();
/* 169 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 171 */       if (rootElm == null)
/* 172 */         getLogger().debug(" mapResponse response xml start element: rootElm is null");
/*     */       else
/* 174 */         getLogger().debug(" mapResponse response xml start element:" + rootElm.getName());
/*     */     }
/* 176 */     String name = "Invoke" + this.interactionInfo.getResponseOSName() + "Response";
/*     */ 
/* 178 */     Element setElement = createElement(this.interactionInfo.getResponseOSName() + "Set");
/* 179 */     Element invokeElement = createElement(name);
/* 180 */     invokeElement.addContent(setElement);
/*     */ 
/* 182 */     Element respElem = create(respWsio, setElement, nsCtx, rootElm, true);
/* 183 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 185 */       if (respElem == null)
/* 186 */         getLogger().debug(" mapResponse response element:respElem is null");
/*     */       else
/* 188 */         getLogger().debug(" mapResponse response element:" + respElem.getName());
/*     */     }
/* 190 */     if (respElem != null)
/*     */     {
/* 192 */       while (respElem.getParent() != null)
/*     */       {
/* 194 */         respElem = respElem.getParentElement();
/*     */       }
/* 196 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 198 */         getLogger().debug("Leaving WSIOResponseExit mapResponse():");
/*     */       }
/* 200 */       return new Document(respElem);
/*     */     }
/* 202 */     if (respElem == null)
/* 203 */       throw new MXApplicationException("iface", "resp_mapping_Error");
/* 204 */     return null;
/*     */   }














/*     */   private Element create(WSIO wsio, Element prntElement, Map<String, String> nsCtx, Element respRootElm, boolean firsttime)
/*     */     throws MXException
/*     */   {
/*     */     try
/*     */     {
/* 225 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 227 */         getLogger().debug("WSIORequestExit createXMLElements()-wsio:" + wsio.getName() + ", nsCtx:" + nsCtx.toString() + ",External resp element:" + respRootElm);
/*     */ 
/* 229 */         if (prntElement == null)
/* 230 */           getLogger().debug("WSIORequestExit createXMLElements()-prntElement is null.");
/*     */         else
/* 232 */           getLogger().debug("WSIORequestExit createXMLElements()-prntElement:" + prntElement.getName());
/*     */       }
/* 234 */       String strXPathLoc = wsio.getXmlLocation();
/* 235 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 237 */         if (strXPathLoc == null)
/* 238 */           getLogger().debug("WSIORequestExit create()- XmlLocation:strXPathLoc is null");
/*     */         else
/* 240 */           getLogger().debug("WSIORequestExit create()- XmlLocation:" + strXPathLoc);
/*     */       }
/* 242 */       strXPathLoc = removeParentLocation(strXPathLoc, wsio, false);
/* 243 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 245 */         if (strXPathLoc == null)
/* 246 */           getLogger().debug("WSIORequestExit create()-remove parent XmlLocation:strXPathLoc is null.");
/*     */         else {
/* 248 */           getLogger().debug("WSIORequestExit create()-remove parent XmlLocation:" + strXPathLoc);
/*     */         }
/*     */       }
/* 251 */       XPath xp = getXPath(strXPathLoc, nsCtx);
/* 252 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 254 */         getLogger().debug("WSIORequestExit create()-Xpath:" + xp);
/*     */       }/*     */       List lstRespChildren;
/*     */       List lstRespChildren;
/* 257 */       if (firsttime)
/*     */       {
/* 259 */         lstRespChildren = xp.selectNodes(respRootElm.getDocument());
/*     */       }
/*     */       else
/*     */       {
/* 263 */         lstRespChildren = xp.selectNodes(respRootElm);
/*     */       }
/* 265 */       Element currRespElement = null;
/* 266 */       Element createdElement = null;
/* 267 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 269 */         if (lstRespChildren == null)
/* 270 */           getLogger().debug("WSIORequestExit create()-lstOsChildren size is null.");
/*     */         else {
/* 272 */           getLogger().debug("WSIORequestExit create()-lstOsChildren size:" + lstRespChildren.size());
/*     */         }
/*     */       }
/* 275 */       if ((lstRespChildren != null) && (!(lstRespChildren.isEmpty())))
/*     */       {
/* 277 */         Iterator itr = lstRespChildren.iterator();
/* 278 */         while (itr.hasNext())
/*     */         {
/* 280 */           currRespElement = (Element)itr.next();
/* 281 */           createdElement = createElement(wsio.getName());
/* 282 */           if (getLogger().isDebugEnabled())
/*     */           {
/* 284 */             if (currRespElement == null)
/* 285 */               getLogger().debug("WSIORequestExit create()-External Resp Element - currRespElement is null");
/*     */             else
/* 287 */               getLogger().debug("WSIORequestExit create()-External Resp Element:" + currRespElement.getName());
/* 288 */             if (createdElement == null)
/* 289 */               getLogger().debug("WSIORequestExit create()- createdElement is null.");
/*     */             else
/* 291 */               getLogger().debug("WSIORequestExit create()- createElement:" + createdElement.getName());
/*     */           }
/* 293 */           prntElement.addContent(createdElement);
/*     */ 
/* 295 */           List lstAttr = wsio.getWSIOAttributes();
/* 296 */           for (WSIOAttribute wsioAttr : lstAttr)
/*     */           {
/* 298 */             String strAttrXPathLoc = wsioAttr.getXmlLocation();
/* 299 */             if (getLogger().isDebugEnabled())
/*     */             {
/* 301 */               if (strAttrXPathLoc == null) {
/* 302 */                 getLogger().debug("WSIORequestExit create()- strAttrXPathLoc is null, wsioAttr Name:" + wsioAttr.getName());
/*     */               }
/*     */               else {
/* 305 */                 getLogger().debug("WSIORequestExit create()- strAttrXPathLoc:" + strAttrXPathLoc + ", wsioAttr Name:" + wsioAttr.getName());
/*     */               }
/*     */             }
/* 308 */             if ((strAttrXPathLoc != null) && (strAttrXPathLoc.trim().length() != 0))
/*     */             {
/* 310 */               strAttrXPathLoc = removeParentLocation(strAttrXPathLoc, wsio, true);
/* 311 */               if (getLogger().isDebugEnabled())
/*     */               {
/* 313 */                 if (strAttrXPathLoc == null)
/* 314 */                   getLogger().debug("WSIORequestExit create()- remove parentstrAttrXPathLoc is null.");
/*     */                 else {
/* 316 */                   getLogger().debug("WSIORequestExit create()- remove parentstrAttrXPathLoc:" + strAttrXPathLoc);
/*     */                 }
/*     */               }
/* 319 */               XPath attrXp = getXPath(strAttrXPathLoc, nsCtx);
/* 320 */               if (strAttrXPathLoc.indexOf("@") >= 0)
/*     */               {
/* 322 */                 Attribute attrAttr = (Attribute)attrXp.selectSingleNode(currRespElement);
/* 323 */                 if (getLogger().isDebugEnabled())
/*     */                 {
/* 325 */                   if (attrAttr == null)
/* 326 */                     getLogger().debug("WSIORequestExit create()- @ attrAttr is null.");
/*     */                   else {
/* 328 */                     getLogger().debug("WSIORequestExit create()- @ attrAttr:" + attrAttr.getName() + ", Attr Value:" + attrAttr.getValue());
/*     */                   }
/*     */                 }
/* 331 */                 if (attrAttr == null)
/*     */                   continue;
/* 333 */                 Element attrElem = createElement(wsioAttr.getName());
/* 334 */                 if ((createdElement != null) && (attrAttr.getValue().trim().length() != 0))
/*     */                 {
/* 336 */                   attrElem.setText(attrAttr.getValue().trim());
/* 337 */                   createdElement.addContent(attrElem);
/*     */                 }
/*     */ 
/*     */               }
/*     */               else
/*     */               {
/* 343 */                 Element attrElement = (Element)attrXp.selectSingleNode(currRespElement);
/* 344 */                 if (getLogger().isDebugEnabled())
/*     */                 {
/* 346 */                   if (attrElement == null)
/* 347 */                     getLogger().debug("WSIORequestExit create()- Wsio Attr Element:attrElement is null.");
/*     */                   else {
/* 349 */                     getLogger().debug("WSIORequestExit create()- Wsio Attr Element:" + attrElement.getName() + ", Element Value:" + attrElement.getText());
/*     */                   }
/*     */                 }
/* 352 */                 if (attrElement == null)
/*     */                   continue;
/* 354 */                 Element attrElem = createElement(wsioAttr.getName());
/* 355 */                 if (attrElement.getText().trim().length() != 0)
/*     */                 {
/* 357 */                   attrElem.setText(attrElement.getText().trim());
/*     */                 }
/* 359 */                 createdElement.addContent(attrElem);


/*     */               }
/*     */ 
/*     */             }
/* 365 */             else if (wsioAttr.isMapToParent())
/*     */             {
/* 367 */               Element attrElem = createElement(wsioAttr.getName());
/* 368 */               if (getLogger().isDebugEnabled())
/*     */               {
/* 370 */                 getLogger().debug("WSIORequestExit create()-isMapToParent is true. currRespElement value:" + currRespElement.getText());
/*     */               }
/*     */ 
/* 373 */               if (currRespElement.getText().trim().length() != 0)
/* 374 */                 attrElem.setText(currRespElement.getText().trim());
/* 375 */               createdElement.addContent(attrElem);

/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 381 */           List lstWsio = wsio.getWSIOChildren();
/* 382 */           if (getLogger().isDebugEnabled())
/*     */           {
/* 384 */             if (lstWsio == null)
/* 385 */               getLogger().debug("WSIORequestExit create()-lst Child Wsio size is null.");
/*     */             else {
/* 387 */               getLogger().debug("WSIORequestExit create()-lst Child Wsio size:" + lstWsio.size());
/*     */             }
/*     */           }
/* 390 */           if (lstWsio != null)
/*     */           {
/* 392 */             for (WSIO childWsio : lstWsio)
/*     */             {
/* 394 */               if (getLogger().isDebugEnabled())
/*     */               {
/* 396 */                 getLogger().debug("WSIORequestExit create()-Child Wsio:" + childWsio.getName());
/*     */               }
/* 398 */               create(childWsio, createdElement, nsCtx, currRespElement, false);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 404 */       return prntElement;
/*     */     }
/*     */     catch (JDOMException e)
/*     */     {
/* 408 */       throw new MXApplicationException("iface", "xpath_ctx_Error", e);
/*     */     }
/*     */   }









/*     */   private Element createElement(String xElement)
/*     */     throws MXException
/*     */   {
/*     */     try
/*     */     {
/* 425 */       String nsPrefix = "ns0";
/* 426 */       String nsUri = MXServer.getMXServer().getProperty("mxe.int.xmlnamespace");
/* 427 */       return new Element(xElement, Namespace.getNamespace(nsPrefix, nsUri));
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/* 431 */       throw new MXApplicationException("system", "remote", e);
/*     */     }
/*     */   }









/*     */   private XPath getXPath(String strXPathLoc, Map<String, String> nsCtx)
/*     */     throws JDOMException
/*     */   {
/* 446 */     XPath xp = XPath.newInstance(strXPathLoc);
/* 447 */     if ((nsCtx != null) && (!(nsCtx.isEmpty())))
/*     */     {
/* 449 */       Iterator itr = nsCtx.keySet().iterator();
/* 450 */       while (itr.hasNext())
/*     */       {
/* 452 */         String nsUri = (String)itr.next();
/* 453 */         String nsPrefix = (String)nsCtx.get(nsUri);
/* 454 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 456 */           getLogger().debug("WSIORequestExit getXPath()-nsUri:" + nsUri + ", nsPrefix:" + nsPrefix);
/*     */         }
/* 458 */         xp.addNamespace(nsPrefix, nsUri);
/*     */       }
/*     */     }
/* 461 */     return xp;
/*     */   }
/*     */ }
