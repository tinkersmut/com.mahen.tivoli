/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPGenerator;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.OBPInfo;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIOAttribute;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.Namespace;
/*     */ import psdi.iface.mic.IntegrationContext;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.iface.util.XMLUtils;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXFormat;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 












































/*     */ public class WSIORequestExit extends WSIOProcessBaseExit
/*     */ {
/*     */   public StructureData setDataOut(StructureData userExitData)
/*     */     throws MXException, RemoteException
/*     */   {
/*  73 */     InteractionInfo interactionInfo = null;








/*     */     try
/*     */     {
/*  84 */       if (getLogger().isDebugEnabled())
/*     */       {
/*  86 */         getLogger().debug("Entering WSIORequestExit setDataOut():");
/*     */       }
/*  88 */       Document reqDoc = userExitData.getData();
/*  89 */       this.interactionName = IntegrationContext.getCurrentContext().getStringProperty("INTERACTION");
/*  90 */       interactionInfo = InteractionCache.getInstance().getInteractionInfo(this.interactionName);
/*     */ 
/*  92 */       if (interactionInfo == null)
/*     */       {
/*  94 */         interactionInfo = (InteractionInfo)IntegrationContext.getCurrentContext().getProperty("INTERACTIONINFO");

/*     */       }
/*     */ 
/*  98 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 100 */         getLogger().debug("WSIORequestExit - setDataOut() - Invoke Channel xml:" + new String(XMLUtils.convertDocumentToBytes(reqDoc), "utf-8"));
/*     */ 
/* 102 */         getLogger().debug("WSIORequestExit - setDataOut() - Interaction OBP xml:" + new String(interactionInfo.getObp(), "utf-8"));
/*     */       }
/*     */ 
/* 105 */       Document mapDoc = mapRequest(reqDoc, interactionInfo.getObp());
/*     */ 
/* 107 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 109 */         if (mapDoc == null)
/* 110 */           getLogger().debug("WSIORequestExit - setDataOut() - Mapped xml is null");
/*     */         else {
/* 112 */           getLogger().debug("WSIORequestExit - setDataOut() - Mapped xml:" + new String(XMLUtils.convertDocumentToBytes(mapDoc), "utf-8"));
/*     */         }
/* 114 */         getLogger().debug("Leaving WSIORequestExit setDataOut():");
/*     */       }
/*     */ 
/* 117 */       return new StructureData(mapDoc);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 121 */       if (e instanceof MXException)
/* 122 */         throw ((MXException)e);
/*     */       try
/*     */       {
/* 125 */         getLogger().error("Error in WSIORequestExit - setDataOut()-Incoming doc:" + new String(userExitData.getDataAsBytes(), "utf-8"));
/* 126 */         getLogger().error("Error in WSIORequestExit - setDataOut()-OBP:" + new String(interactionInfo.getObp(), "utf-8"));
/*     */       }
/*     */       catch (UnsupportedEncodingException ee)
/*     */       {
/* 130 */         getLogger().error("Error in WSIORequestExit - setDataOut()-UnsupportedEncodingException while converting bytes to string:" + ee.getMessage());
/*     */       }
/* 132 */       throw new MXApplicationException("iface", "req_mapping_Error", e);
/*     */     }
/*     */   }











/*     */   public Document mapRequest(Document reqDoc, byte[] bObp)
/*     */     throws MXException
/*     */   {
/* 149 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 151 */       getLogger().debug("Entering WSIORequestExit mapRequest():");
/*     */     }
/* 153 */     OBPInfo reqOBPInfo = OBPGenerator.parse(bObp);
/* 154 */     Map nsCtx = reqOBPInfo.getNsContext();
/*     */ 
/* 156 */     WSIO reqWsio = reqOBPInfo.getRequest();
/* 157 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 159 */       if (reqWsio == null)
/*     */       {
/* 161 */         getLogger().debug(" mapRequest reqWsio: is null");
/*     */       }
/*     */       else
/*     */       {
/* 165 */         getLogger().debug(" mapRequest reqWsio:" + reqWsio.getName());
/* 166 */         getLogger().debug(" mapRequest Request WSIO isMaxOccursUnbounded:" + reqWsio.isMaxOccursUnbounded());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 171 */     Element osRootElm = getRequestStartElement(reqDoc);
/* 172 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 174 */       if (osRootElm == null)
/* 175 */         getLogger().debug(" mapRequest mapping start element:osRootElm is null");
/*     */       else {
/* 177 */         getLogger().debug(" mapRequest mapping start element:" + osRootElm.getName());
/*     */       }
/*     */     }
/* 180 */     Element mapElement = create(reqWsio, null, nsCtx, osRootElm);
/* 181 */     Document doc = new Document(mapElement);
/* 182 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 184 */       getLogger().debug("Leaving WSIORequestExit mapRequest():");
/*     */     }
/* 186 */     return doc;
/*     */   }













/*     */   private Element create(WSIO wsio, Element parentElement, Map<String, String> nsCtx, Element osRootElm)
/*     */     throws MXException
/*     */   {
/* 204 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 206 */       getLogger().debug("Entering WSIORequestExit create():" + wsio.getName());
/*     */     }
/* 208 */     String strXPathLoc = wsio.getXmlLocation();
/* 209 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 211 */       if (strXPathLoc == null)
/* 212 */         getLogger().debug("WSIORequestExit create()- XmlLocation: strXPathLoc is null");
/*     */       else
/* 214 */         getLogger().debug("WSIORequestExit create()- XmlLocation:" + strXPathLoc);
/*     */     }
/* 216 */     strXPathLoc = removeParentLocation(strXPathLoc, wsio, false);
/* 217 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 219 */       if (strXPathLoc == null)
/* 220 */         getLogger().debug("WSIORequestExit create()-remove parent XmlLocation: strXPathLoc is null");
/*     */       else
/* 222 */         getLogger().debug("WSIORequestExit create()-remove parent XmlLocation:" + strXPathLoc);
/*     */     }
/* 224 */     String[] xPathElements = parseXPath(strXPathLoc);
/* 225 */     Element currElement = createXMLElements(xPathElements, parentElement, nsCtx, null);
/* 226 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 228 */       if (currElement == null)
/* 229 */         getLogger().debug("WSIORequestExit create()-currElement is null.");
/*     */       else
/* 231 */         getLogger().debug("WSIORequestExit create()-currElement:" + currElement.getName());
/*     */     }
/* 233 */     List lstAttr = wsio.getWSIOAttributes();
/* 234 */     for (WSIOAttribute wsioAttr : lstAttr)
/*     */     {
/* 236 */       String attrName = wsioAttr.getName();
/* 237 */       List lstOsChildren = osRootElm.getChildren(attrName, osRootElm.getNamespace());
/* 238 */       if (getLogger().isDebugEnabled())
/*     */       {
/* 240 */         getLogger().debug("WSIORequestExit create()-attrName:" + attrName);
/* 241 */         if (lstOsChildren == null)
/* 242 */           getLogger().debug("WSIORequestExit create()-lstOsChildren size is null");
/*     */         else
/* 244 */           getLogger().debug("WSIORequestExit create()-lstOsChildren size:" + lstOsChildren.size());
/*     */       }
/* 246 */       if ((lstOsChildren != null) && (!(lstOsChildren.isEmpty())))
/*     */       {
/* 248 */         Iterator itr = lstOsChildren.iterator();
/* 249 */         while (itr.hasNext())
/*     */         {
/* 251 */           Element osElm = (Element)itr.next();
/* 252 */           String strTxt = osElm.getText();
/* 253 */           if (getLogger().isDebugEnabled())
/*     */           {
/* 255 */             if (osElm == null)
/* 256 */               getLogger().debug("WSIORequestExit create()-Invoke Channel Xml Element: osElm is null");
/*     */             else {
/* 258 */               getLogger().debug("WSIORequestExit create()-Invoke Channel Xml Element:" + osElm.getName());
/*     */             }
/* 260 */             getLogger().debug("WSIORequestExit create()-Element Value:" + strTxt);
/*     */           }
/*     */ 
/* 263 */           boolean isChanged = false;
/* 264 */           String attrChangedVal = osElm.getAttributeValue("changed");
/* 265 */           if ((attrChangedVal != null) && (MXFormat.stringToBoolean(attrChangedVal)))
/*     */           {
/* 267 */             isChanged = true;





/*     */           }
/*     */ 
/* 275 */           if (((strTxt != null) && (strTxt.trim().length() != 0) && (wsioAttr.hasDefaultValue())) || (isChanged) || (wsioAttr.isRequired()))
/*     */           {
/* 277 */             String strXPathAttrLoc = wsioAttr.getXmlLocation();
/* 278 */             if (getLogger().isDebugEnabled())
/*     */             {
/* 280 */               if (strXPathAttrLoc == null)
/* 281 */                 getLogger().debug("WSIORequestExit create()- strXPathAttrLoc is null");
/*     */               else {
/* 283 */                 getLogger().debug("WSIORequestExit create()- strXPathAttrLoc:" + strXPathAttrLoc);
/*     */               }
/*     */             }
/* 286 */             if ((strXPathAttrLoc != null) && (strXPathAttrLoc.trim().length() != 0))
/*     */             {
/* 288 */               strXPathAttrLoc = removeParentLocation(strXPathAttrLoc, wsio, true);
/* 289 */               if (getLogger().isDebugEnabled())
/*     */               {
/* 291 */                 if (strXPathAttrLoc == null) {
/* 292 */                   getLogger().debug("WSIORequestExit create()- remove parentstrXPathAttrLoc: strXPathAttrLoc is null");
/*     */                 }
/*     */                 else {
/* 295 */                   getLogger().debug("WSIORequestExit create()- remove parentstrXPathAttrLoc:" + strXPathAttrLoc);
/*     */                 }
/*     */               }
/* 298 */               String[] xPathAttrElements = parseXPath(strXPathAttrLoc);
/* 299 */               createXMLElements(xPathAttrElements, currElement, nsCtx, strTxt);


/*     */             }
/* 303 */             else if (wsioAttr.isMapToParent()) {
/* 304 */               currElement.setText(strTxt);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 311 */     List lstWsio = wsio.getWSIOChildren();
/* 312 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 314 */       if (lstWsio == null)
/* 315 */         getLogger().debug("WSIORequestExit create()-lst Child Wsio size is null.");
/*     */       else {
/* 317 */         getLogger().debug("WSIORequestExit create()-lst Child Wsio size:" + lstWsio.size());
/*     */       }
/*     */     }
/* 320 */     if (lstWsio != null)
/*     */     {
/* 322 */       for (WSIO childWsio : lstWsio)
/*     */       {
/* 324 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 326 */           getLogger().debug("WSIORequestExit create()-Child Wsio:" + childWsio.getName());
/*     */         }
/* 328 */         List lstOsChildElm = osRootElm.getChildren(childWsio.getName(), osRootElm.getNamespace());
/* 329 */         if (getLogger().isDebugEnabled())
/*     */         {
/* 331 */           if (lstOsChildElm == null)
/* 332 */             getLogger().debug("WSIORequestExit create()-lstOsChildElm Invoke Xml Child size: null");
/*     */           else {
/* 334 */             getLogger().debug("WSIORequestExit create()-lstOsChildElm Invoke Xml Child size:" + lstOsChildElm.size());
/*     */           }
/*     */         }
/* 337 */         Iterator itrChildren = lstOsChildElm.iterator();
/* 338 */         while (itrChildren.hasNext())
/*     */         {
/* 340 */           Element osChildElm = (Element)itrChildren.next();
/* 341 */           if (getLogger().isDebugEnabled())
/*     */           {
/* 343 */             if (osChildElm == null)
/* 344 */               getLogger().debug("WSIORequestExit create()-osChildElm Invoke Xml Child Element:osChildElm is null");
/*     */             else {
/* 346 */               getLogger().debug("WSIORequestExit create()-osChildElm Invoke Xml Child Element:" + osChildElm.getName());
/*     */             }
/*     */           }
/* 349 */           create(childWsio, currElement, nsCtx, osChildElm);
/*     */         }
/*     */       }
/*     */     }
/* 353 */     while ((parentElement == null) && 

/* 355 */       (currElement.getParent() != null))
/*     */     {
/* 357 */       currElement = currElement.getParentElement();
/*     */     }
/*     */ 
/* 360 */     return currElement;
/*     */   }














/*     */   private Element createXMLElements(String[] xPathElements, Element prntElement, Map<String, String> nsCtx, String strValue)
/*     */   {
/* 378 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 380 */       getLogger().debug("WSIORequestExit createXMLElements()-xPathElements array:" + xPathElements + ", nsCtx:" + nsCtx.toString() + ", Element value:" + strValue);
/*     */ 
/* 382 */       if (prntElement == null)
/* 383 */         getLogger().debug("WSIORequestExit createXMLElements() prntElement is null.");
/*     */       else
/* 385 */         getLogger().debug("WSIORequestExit createXMLElements()prntElement:" + prntElement.getName());
/*     */     }
/* 387 */     if ((xPathElements != null) && (xPathElements.length > 0))
/*     */     {
/* 389 */       int length = xPathElements.length;
/* 390 */       Element newElm = null;
/* 391 */       for (int i = 0; i < length; ++i)
/*     */       {
/* 393 */         String elementName = xPathElements[i];
/* 394 */         if (elementName.startsWith("@"))
/*     */         {
/* 396 */           if (strValue == null) {
/* 397 */             strValue = "";
/*     */           }
/* 399 */           prntElement.setAttribute(elementName.substring(1, elementName.length()), strValue);
/*     */         }
/*     */         else
/*     */         {
/* 403 */           newElm = createElement(elementName, nsCtx);
/* 404 */           if (getLogger().isDebugEnabled())
/*     */           {
/* 406 */             if (newElm == null)
/* 407 */               getLogger().debug("WSIORequestExit createXMLElements()-new created Element: newElem is null. i:" + i);
/*     */             else {
/* 409 */               getLogger().debug("WSIORequestExit createXMLElements()-new created Element:" + newElm.getName() + ", i:" + i);
/*     */             }
/*     */           }
/* 412 */           if ((newElm != null) && (prntElement != null) && 

/* 414 */             (i != length - 1) && (prntElement.getChild(newElm.getName(), newElm.getNamespace()) != null))
/*     */           {
/* 416 */             prntElement = prntElement.getChild(newElm.getName(), newElm.getNamespace());



/*     */           }
/* 421 */           else if (prntElement == null) {
/* 422 */             prntElement = newElm;
/*     */           }
/*     */           else {
/* 425 */             if ((strValue != null) && (i == length - 1))
/* 426 */               newElm.setText(strValue);
/* 427 */             prntElement.addContent(newElm);
/* 428 */             prntElement = newElm;
/*     */           }
/*     */         }
/*     */       }
/* 432 */       return newElm;
/*     */     }
/* 434 */     return null;
/*     */   }









/*     */   private Element createElement(String xElement, Map<String, String> nsCtx)
/*     */   {
/* 447 */     if (xElement != null)
/*     */     {
/* 449 */       Namespace ns = null;
/* 450 */       if (xElement.indexOf(58) > 0)
/*     */       {
/* 452 */         String prefix = xElement.substring(0, xElement.indexOf(58));
/* 453 */         xElement = xElement.substring(xElement.indexOf(58) + 1, xElement.length());
/* 454 */         ns = getNamespace(prefix, nsCtx);
/*     */       }
/* 456 */       return new Element(xElement, ns);
/*     */     }
/* 458 */     return null;
/*     */   }








/*     */   private String[] parseXPath(String strXPath)
/*     */   {
/* 470 */     String[] elems = { strXPath };
/* 471 */     if (strXPath.indexOf(47) > 0)
/*     */     {
/* 473 */       StringTokenizer strtk = new StringTokenizer(strXPath, "/");
/* 474 */       elems = new String[strtk.countTokens()];
/* 475 */       int i = 0;
/* 476 */       while (strtk.hasMoreTokens())
/*     */       {
/* 478 */         String elemName = strtk.nextToken();
/* 479 */         elems[i] = elemName;
/* 480 */         ++i;
/*     */       }
/*     */     }
/*     */ 
/* 484 */     return elems;
/*     */   }


/*     */   protected Element getRequestStartElement(Document reqDoc)
/*     */   {
/* 490 */     return ((Element)((Element)(Element)reqDoc.getRootElement().getChildren().iterator().next()).getChildren().iterator().next());
/*     */   }
/*     */ }
