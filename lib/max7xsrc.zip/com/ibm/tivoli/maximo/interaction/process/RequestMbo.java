/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIO;
/*     */ import com.ibm.tivoli.maximo.interaction.obp.WSIOAttribute;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.List;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.NonPersistentMbo;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 



































/*     */ public class RequestMbo extends NonPersistentMbo
/*     */ {
/*  40 */   public static final MXLogger INTERACTIONLOGGER = InteractionUtil.INTERACTIONLOGGER;
/*     */ 
/*     */   public RequestMbo(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  54 */     super(ms);
/*     */   }








/*     */   public void validateWSIOAttribute(String name, Object value)
/*     */     throws MXException, RemoteException
/*     */   {
/*  67 */     if (INTERACTIONLOGGER.isDebugEnabled())
/*     */     {
/*  69 */       INTERACTIONLOGGER.debug("Entering validateWSIOAttribute for attribute " + name);
/*     */     }
/*  71 */     WSIO wsio = ((RequestMboSet)getThisMboSet()).getWSIO();
/*  72 */     WSIOAttribute wsioAttr = findWSIOAttribute(wsio, name);
/*  73 */     if (wsioAttr != null)
/*     */     {
/*  75 */       wsioAttr.validate(value);
/*     */     }
/*  77 */     INTERACTIONLOGGER.debug("Leaving validateWSIOAttribute");
/*     */   }









/*     */   private WSIOAttribute findWSIOAttribute(WSIO wsio, String name)
/*     */     throws MXException, RemoteException
/*     */   {
/*  91 */     List wsioAttrList = wsio.getWSIOAttributes();
/*  92 */     for (WSIOAttribute wsioAttr : wsioAttrList)
/*     */     {
/*  94 */       if (wsioAttr.getName().equals(name))
/*     */       {
/*  96 */         if (INTERACTIONLOGGER.isDebugEnabled())
/*     */         {
/*  98 */           INTERACTIONLOGGER.debug("Attribute found in WSIO " + name);
/*     */         }
/* 100 */         return wsioAttr;
/*     */       }
/*     */     }
/* 103 */     return null;
/*     */   }
/*     */ }
