/*    */ package com.ibm.tivoli.maximo.interaction.process;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import psdi.common.action.ActionCustomClass;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXException;
/*    */ 

































/*    */ public class InteractionCustomClass
/*    */   implements ActionCustomClass
/*    */ {
/*    */   public void applyCustomAction(MboRemote mbo, Object[] params)
/*    */     throws MXException, RemoteException
/*    */   {
/* 49 */     Map metaData = new HashMap();
/* 50 */     if (params.length > 0)
/*    */     {
/* 52 */       metaData.put("CUSTOM", params);
/*    */     }
/* 54 */     String interactionName = (String)params[0];
/* 55 */     InteractionProcesser interactionProcesser = new InteractionProcesser(interactionName);
/* 56 */     interactionProcesser.processInteraction(mbo);
/*    */   }
/*    */ }
