/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 
/*     */ import java.util.List;
/*     */ 






































/*     */ public final class IntMappingInfo
/*     */ {
/*  33 */   private String mapObject = null;
/*  34 */   private String intObjectName = null;
/*  35 */   private String hierarchyPath = null;
/*  36 */   private String objectName = null;
/*  37 */   private int processOrder = 0;
/*  38 */   private String relation = null;
/*  39 */   private boolean isResponse = false;
/*  40 */   private List<IntMappingDetailInfo> allMappings = null;
/*     */ 
/*     */   public IntMappingInfo(String intObjectName, String mapObject, String hierarchyPath, String objectName, String relation, int isResponse, int processOrder)
/*     */   {
/*  56 */     this.mapObject = mapObject;
/*  57 */     this.intObjectName = intObjectName;
/*  58 */     this.hierarchyPath = hierarchyPath;
/*  59 */     this.objectName = objectName;
/*  60 */     this.processOrder = processOrder;
/*  61 */     this.relation = relation;
/*  62 */     this.isResponse = (1 == isResponse);
/*     */   }




/*     */   public String getMapObject()
/*     */   {
/*  70 */     return this.mapObject;
/*     */   }




/*     */   public String intObjectName()
/*     */   {
/*  78 */     return this.intObjectName;
/*     */   }




/*     */   public int getProcessOrder()
/*     */   {
/*  86 */     return this.processOrder;
/*     */   }




/*     */   public String getHierarchyPath()
/*     */   {
/*  94 */     return this.hierarchyPath;
/*     */   }




/*     */   public String getSourceObject()
/*     */   {
/* 102 */     return this.objectName;
/*     */   }




/*     */   public String getRelation()
/*     */   {
/* 110 */     return this.relation;
/*     */   }




/*     */   public boolean isResponse()
/*     */   {
/* 118 */     return this.isResponse;
/*     */   }





/*     */   public void setObjectMappings(List<IntMappingDetailInfo> map)
/*     */   {
/* 127 */     this.allMappings = map;
/*     */   }





/*     */   public List<IntMappingDetailInfo> getObjectMappings()
/*     */   {
/* 136 */     return this.allMappings;
/*     */   }
/*     */ }
