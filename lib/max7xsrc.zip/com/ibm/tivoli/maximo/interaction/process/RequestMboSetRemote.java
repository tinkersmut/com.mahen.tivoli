package com.ibm.tivoli.maximo.interaction.process;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.NonPersistentMboSetRemote;
import psdi.util.MXException;

public abstract interface RequestMboSetRemote extends NonPersistentMboSetRemote
{
  public abstract MboSetRemote processInteraction(MboRemote paramMboRemote)
    throws MXException, RemoteException;

  public abstract MboSetRemote processInteraction(String paramString, MboRemote paramMboRemote)
    throws MXException, RemoteException;

  public abstract MboSetRemote processInteraction(String paramString1, String paramString2, MboRemote paramMboRemote)
    throws MXException, RemoteException;
}
