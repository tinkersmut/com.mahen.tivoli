/*     */ package com.ibm.tivoli.maximo.interaction.process;
/*     */ 



















































/*     */ public final class ServiceInvokerInfo
/*     */ {
/*     */   private String channelName;
/*     */   private String reqRelation;
/*     */   private String respRelation;
/*     */   private int action;
/*     */   private String endPointName;
/*  39 */   private String extSystem = null;
/*     */ 
/*  41 */   private String operation = null;
/*     */ 
/*     */   public ServiceInvokerInfo(String channelName, String reqRelation, String respRelation, int action, String endPointName, String extSystem, String operation)
/*     */   {
/*  67 */     this.channelName = channelName;
/*  68 */     this.reqRelation = reqRelation;
/*  69 */     this.respRelation = respRelation;
/*  70 */     this.action = action;
/*  71 */     this.endPointName = endPointName;
/*  72 */     this.extSystem = extSystem;
/*  73 */     this.operation = operation;
/*     */   }






/*     */   public String getChannelName()
/*     */   {
/*  83 */     return this.channelName;
/*     */   }






/*     */   public String getReqRelation()
/*     */   {
/*  93 */     return this.reqRelation;
/*     */   }







/*     */   public String getRespRelation()
/*     */   {
/* 104 */     return this.respRelation;
/*     */   }






/*     */   public int getAction()
/*     */   {
/* 114 */     return this.action;
/*     */   }






/*     */   public String getEndPointName()
/*     */   {
/* 124 */     return this.endPointName;
/*     */   }






/*     */   public String getExtSystem()
/*     */   {
/* 134 */     return this.extSystem;
/*     */   }






/*     */   public String getOperation()
/*     */   {
/* 144 */     return this.operation;
/*     */   }
/*     */ }
