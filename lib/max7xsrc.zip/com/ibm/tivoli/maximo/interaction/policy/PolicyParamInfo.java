/*    */ package com.ibm.tivoli.maximo.interaction.policy;
/*    */ 
































/*    */ public final class PolicyParamInfo
/*    */ {
/*    */   private String param;
/*    */   private String description;
/*    */   private String defaultValue;
/*    */   private String value;
/*    */ 
/*    */   public PolicyParamInfo(String param, String description, String value, String defaultValue)
/*    */   {
/* 44 */     this.param = param;
/* 45 */     this.description = description;
/* 46 */     this.defaultValue = defaultValue;
/* 47 */     this.value = value;
/*    */   }





/*    */   public String getParam()
/*    */   {
/* 56 */     return this.param;
/*    */   }





/*    */   public String getDescription()
/*    */   {
/* 65 */     return this.description;
/*    */   }





/*    */   public String getDefaultValue()
/*    */   {
/* 74 */     return this.defaultValue;
/*    */   }





/*    */   public String getValue()
/*    */   {
/* 83 */     return this.value;
/*    */   }
/*    */ }
