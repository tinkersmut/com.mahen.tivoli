/*     */ package com.ibm.tivoli.maximo.interaction.policy;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 


































/*     */ public final class PolicyInfo
/*     */ {
/*     */   private String policyName;
/*     */   private String policyID;
/*     */   private String description;
/*     */   private String type;
/*  36 */   Map<String, PolicyParamInfo> parameters = new HashMap();
/*     */ 
/*     */   public PolicyInfo(String policyID, String policyName, String description, String type, Map<String, PolicyParamInfo> parameters)
/*     */   {
/*  50 */     this.policyID = policyID;
/*  51 */     this.policyName = policyName;
/*  52 */     this.description = description;
/*  53 */     this.type = type;
/*  54 */     this.parameters = parameters;
/*     */   }





/*     */   public String getPolicyName()
/*     */   {
/*  63 */     return this.policyName;
/*     */   }





/*     */   public String getPolicyID()
/*     */   {
/*  72 */     return this.policyID;
/*     */   }





/*     */   public String getDescription()
/*     */   {
/*  81 */     return this.description;
/*     */   }





/*     */   public String getType()
/*     */   {
/*  90 */     return this.type;
/*     */   }





/*     */   public Map<String, PolicyParamInfo> getParamaters()
/*     */   {
/*  99 */     return this.parameters;
/*     */   }





/*     */   public PolicyParamInfo getParamater(String key)
/*     */   {
/* 108 */     return ((PolicyParamInfo)this.parameters.get(key));
/*     */   }
/*     */ }
