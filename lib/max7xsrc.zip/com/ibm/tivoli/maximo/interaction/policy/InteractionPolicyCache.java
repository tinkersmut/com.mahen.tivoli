/*     */ package com.ibm.tivoli.maximo.interaction.policy;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.mbo.MaximoCache;
/*     */ import psdi.security.SecurityService;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.DBManager;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 






























/*     */ public class InteractionPolicyCache
/*     */   implements MaximoCache
/*     */ {
/*  44 */   private Map<String, PolicyInfo> inter = new HashMap();
/*     */   private static InteractionPolicyCache singleton;
/*  51 */   private static final MXLogger integrationLogger = MicUtil.INTEGRATIONLOGGER;
/*     */ 
/*     */   public static InteractionPolicyCache getInstance()
/*     */     throws MXException
/*     */   {
/*  60 */     if (singleton == null)
/*     */     {
/*  62 */       singleton = new InteractionPolicyCache();
/*     */     }
/*  64 */     return singleton;
/*     */   }





/*     */   private InteractionPolicyCache()
/*     */     throws MXException
/*     */   {
/*  74 */     init();
/*     */     try
/*     */     {
/*  77 */       MXServer.getMXServer().addToMaximoCache(getName(), this);
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/*  81 */       if (integrationLogger.isErrorEnabled())
/*     */       {
/*  83 */         integrationLogger.error(re.getMessage(), re);
/*     */       }
/*  85 */       throw new MXSystemException("system", "remoteexception", re);
/*     */     }
/*     */   }





/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  96 */     loaInteractionPolicy();
/*     */   }





/*     */   public synchronized void reload()
/*     */     throws MXException
/*     */   {
/* 106 */     this.inter.clear();
/* 107 */     init();
/*     */   }


















/*     */   public String getName()
/*     */   {
/* 129 */     return "MAXINTPOLICY";
/*     */   }





/*     */   private void loaInteractionPolicy()
/*     */     throws MXException
/*     */   {
/* 139 */     Statement s = null;
/* 140 */     UserInfo systemUserInfo = null;
/*     */     try
/*     */     {
/* 143 */       SecurityService secServ = (SecurityService)MXServer.getMXServer().lookup("SECURITY");
/* 144 */       systemUserInfo = secServ.getSystemUserInfo();
/* 145 */       Connection connection = MXServer.getMXServer().getDBManager().getConnection(systemUserInfo.getConnectionKey());

/*     */ 
/* 148 */       s = connection.createStatement();
/* 149 */       s.execute("select mp.policyid, mp.policyname, mp.description, mp.policytype, mpd.param, mpd.description, mpd.value, mpd.defaultvalue from maxintpolicy mp, maxintpolicyparam mpd where mp.policyid=mpd.policyid ");



/*     */ 
/* 154 */       ResultSet rs = s.getResultSet();
/*     */ 
/* 156 */       while (rs.next())
/*     */       {
/* 158 */         String id = rs.getString(1);
/* 159 */         String param = rs.getString(5);
/* 160 */         PolicyParamInfo paramInfo = new PolicyParamInfo(rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
/*     */ 
/* 162 */         PolicyInfo info = (PolicyInfo)this.inter.get(id);
/* 163 */         if (info == null)
/*     */         {
/* 165 */           Map params = new HashMap();
/* 166 */           params.put(param, paramInfo);
/* 167 */           info = new PolicyInfo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), params);
/*     */ 
/* 169 */           this.inter.put(id, info);
/*     */         }
/*     */         else
/*     */         {
/* 173 */           Map params = info.getParamaters();
/* 174 */           params.put(param, paramInfo);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 180 */       if (integrationLogger.isErrorEnabled())
/*     */       {
/* 182 */         integrationLogger.error(e.getMessage(), e);
/*     */       }
/*     */       Object[] params;
/* 185 */       throw new MXSystemException("system", "sql", params, e);
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/* 189 */       if (integrationLogger.isErrorEnabled());



/* 193 */       throw new MXSystemException("system", "remoteexception", re);
/*     */     }
/*     */     catch (Exception ee)
/*     */     {
/* 197 */       if (integrationLogger.isErrorEnabled());



/* 201 */       throw new MXSystemException("system", "major", ee);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 207 */         if (s != null)
/*     */         {
/* 209 */           s.close();
/*     */         }
/* 211 */         MXServer.getMXServer().getDBManager().freeConnection(systemUserInfo.getConnectionKey());

/*     */       }
/*     */       catch (Exception e1)
/*     */       {
/* 216 */         if (integrationLogger.isErrorEnabled())
/*     */         {
/* 218 */           integrationLogger.error(e1.getMessage(), e1);
/*     */         }
/*     */       }
/*     */     }
/*     */   }







/*     */   public Map<String, PolicyInfo> getAllPolices()
/*     */   {
/* 232 */     return this.inter;
/*     */   }







/*     */   public PolicyInfo getPolicyInfo(String id)
/*     */   {
/* 243 */     return ((PolicyInfo)this.inter.get(id));
/*     */   }
/*     */ }
