package com.ibm.tivoli.maximo.interaction.policy;

public class PolicyConstants
{
  public static final String GLOBAL_POLICY = "GLOBAL";
  public static final String ATTRIBUTE_EXCLUSION_POLICY = "IATEP";
  public static final String OBJECT_OCCURANCE_POLICY = "IORP";
  public static final String ANY_ELEMENT_POLICY = "IAEP";
  public static final String SIMPLE_TYPE_POLICY = "ISTP";
  public static final String DEFAULT_ATTRIBUTE_LENGTH = "IDALP";
  public static final String TYPE_SCHEMA = "SCHEMA";
  public static final String TYPE_RUNTIME = "RUNTIME";
  public static final String PARAM_SKIP_RECCURRENCE = "SKIP_RECCURRENCE";
  public static final String PARAM_EXCLUDE_ATTRIBUTES = "EXCLUDE_ATTRIBUTES";
  public static final String PARAM_EXCLUDE_ANYELEMENT = "EXCLUDE_ANY_ELEMENT";
  public static final String TREAT_SIMPLE_LISTTYPE_AS_ATOMIC = "TREAT_SIMPLE_LIST_TYPE_AS_ATOMIC";
  public static final String PARAM_DEFAULT_LENGTH = "DEFAULT_LENGTH";
}
