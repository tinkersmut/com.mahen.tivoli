/*     */ package com.ibm.tivoli.maximo.interaction.obp;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaLocalElement;
/*     */ import org.apache.xmlbeans.SchemaParticle;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ 




















/*     */ public class OBPSchemaElement
/*     */   implements OBPSchemaField
/*     */ {
/*  31 */   private SchemaParticle particle = null;
/*  32 */   private SchemaLocalElement element = null;
/*  33 */   private boolean root = false;
/*     */ 
/*  35 */   private int combinedMaxOccurs = 1;
/*  36 */   private int combinedMinOccurs = 1;
/*     */ 
/*  38 */   private boolean hasComMaxOccurs = false;
/*  39 */   private boolean hasComMinOccurs = false;
/*     */   private boolean xmlRequired;
/*     */ 
/*     */   public OBPSchemaElement(SchemaParticle particle)
/*     */   {
/*  45 */     this.particle = particle;
/*     */   }

/*     */   public OBPSchemaElement(SchemaLocalElement element)
/*     */   {
/*  50 */     this.element = element;
/*     */   }

/*     */   public OBPSchemaElement(SchemaLocalElement element, boolean root)
/*     */   {
/*  55 */     this.element = element;
/*  56 */     this.root = root;
/*     */   }


/*     */   public String getDefaultText()
/*     */   {
/*  62 */     return ((this.particle != null) ? this.particle.getDefaultText() : this.element.getDefaultText());
/*     */   }


/*     */   public BigInteger getMaxOccurs()
/*     */   {
/*  68 */     return ((this.particle != null) ? this.particle.getMaxOccurs() : this.element.getMaxOccurs());
/*     */   }

/*     */   public BigInteger getMinOccurs()
/*     */   {
/*  73 */     return ((this.particle != null) ? this.particle.getMinOccurs() : this.element.getMinOccurs());
/*     */   }

/*     */   public QName getName()
/*     */   {
/*  78 */     return ((this.particle != null) ? this.particle.getName() : this.element.getName());
/*     */   }

/*     */   public SchemaType getType()
/*     */   {
/*  83 */     return ((this.particle != null) ? this.particle.getType() : this.element.getType());
/*     */   }

/*     */   public boolean isDefault()
/*     */   {
/*  88 */     return ((this.particle != null) ? this.particle.isDefault() : this.element.isDefault());
/*     */   }

/*     */   public boolean isFixed()
/*     */   {
/*  93 */     return ((this.particle != null) ? this.particle.isFixed() : this.element.isFixed());
/*     */   }

/*     */   public boolean isNillable()
/*     */   {
/*  98 */     return ((this.particle != null) ? this.particle.isNillable() : this.element.isNillable());
/*     */   }

/*     */   public void setCombinedMaxOccurs(int combinedMaxOccurs)
/*     */   {
/* 103 */     this.combinedMaxOccurs = combinedMaxOccurs;
/* 104 */     this.hasComMaxOccurs = true;
/*     */   }

/*     */   public void setCombinedMinOccurs(int combinedMinOccurs)
/*     */   {
/* 109 */     this.combinedMinOccurs = combinedMinOccurs;
/* 110 */     this.hasComMinOccurs = true;
/*     */   }


/*     */   public int getCombinedMaxOccurs()
/*     */   {
/* 116 */     if (this.hasComMaxOccurs)

/*     */     {
/* 119 */       return this.combinedMaxOccurs;
/*     */     }
/* 121 */     if (this.particle != null)
/*     */     {
/* 123 */       return this.particle.getIntMaxOccurs();

/*     */     }
/*     */ 
/* 127 */     return ((this.element.getMaxOccurs() == null) ? -1 : this.element.getMaxOccurs().intValue());
/*     */   }


/*     */   public int getCombinedMinOccurs()
/*     */   {
/* 133 */     if (this.hasComMinOccurs)
/*     */     {
/* 135 */       return this.combinedMinOccurs;
/*     */     }
/* 137 */     if (this.particle != null)
/*     */     {
/* 139 */       return this.particle.getIntMinOccurs();

/*     */     }
/*     */ 
/* 143 */     return ((this.element.getMinOccurs() == null) ? 1 : this.element.getMinOccurs().intValue());
/*     */   }



/*     */   public void setXmlRequired(boolean xmlRequired)
/*     */   {
/* 150 */     this.xmlRequired = xmlRequired;
/*     */   }

/*     */   public boolean isXmlRequired()
/*     */   {
/* 155 */     return this.xmlRequired;
/*     */   }

/*     */   public boolean hasCombinedMaxOccurs()
/*     */   {
/* 160 */     return this.hasComMaxOccurs;
/*     */   }

/*     */   public boolean isRoot()
/*     */   {
/* 165 */     return this.root;
/*     */   }

/*     */   public boolean isAttribute()
/*     */   {
/* 170 */     return false;
/*     */   }
/*     */ }
