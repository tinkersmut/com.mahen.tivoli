/*    */ package com.ibm.tivoli.maximo.interaction.obp;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.xmlbeans.SchemaLocalAttribute;
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ 
















/*    */ public class OBPSchemaAttribute
/*    */   implements OBPSchemaField
/*    */ {
/*    */   private SchemaLocalAttribute attr;
/*    */   private boolean xmlRequired;
/*    */ 
/*    */   public OBPSchemaAttribute(SchemaLocalAttribute attr)
/*    */   {
/* 32 */     this.attr = attr;
/*    */   }

/*    */   public String getDefaultText()
/*    */   {
/* 37 */     return this.attr.getDefaultText();
/*    */   }

/*    */   public BigInteger getMaxOccurs()
/*    */   {
/* 42 */     return this.attr.getMaxOccurs();
/*    */   }

/*    */   public BigInteger getMinOccurs()
/*    */   {
/* 47 */     return this.attr.getMinOccurs();
/*    */   }

/*    */   public QName getName()
/*    */   {
/* 52 */     return this.attr.getName();
/*    */   }

/*    */   public SchemaType getType()
/*    */   {
/* 57 */     return this.attr.getType();
/*    */   }

/*    */   public boolean isAttribute()
/*    */   {
/* 62 */     return true;
/*    */   }

/*    */   public boolean isDefault()
/*    */   {
/* 67 */     return this.attr.isDefault();
/*    */   }

/*    */   public boolean isFixed()
/*    */   {
/* 72 */     return this.attr.isFixed();
/*    */   }

/*    */   public boolean isRoot()
/*    */   {
/* 77 */     return false;
/*    */   }

/*    */   public int getUse()
/*    */   {
/* 82 */     return this.attr.getUse();
/*    */   }

/*    */   public void setXmlRequired(boolean xmlRequired)
/*    */   {
/* 87 */     this.xmlRequired = xmlRequired;
/*    */   }

/*    */   public boolean isXmlRequired()
/*    */   {
/* 92 */     return this.xmlRequired;
/*    */   }

/*    */   public boolean isNillable()
/*    */   {
/* 97 */     return false;
/*    */   }
/*    */ }
