package com.ibm.tivoli.maximo.interaction.obp;

import java.math.BigInteger;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;

public abstract interface OBPSchemaField
{
  public abstract String getDefaultText();

  public abstract BigInteger getMaxOccurs();

  public abstract BigInteger getMinOccurs();

  public abstract QName getName();

  public abstract SchemaType getType();

  public abstract boolean isDefault();

  public abstract boolean isFixed();

  public abstract boolean isAttribute();

  public abstract boolean isRoot();

  public abstract void setXmlRequired(boolean paramBoolean);

  public abstract boolean isXmlRequired();

  public abstract boolean isNillable();
}
