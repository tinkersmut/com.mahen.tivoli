/*     */ package com.ibm.tivoli.maximo.interaction.obp;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ 



















/*     */ public class OBPInfo
/*     */   implements Serializable
/*     */ {
/*     */   private String doc;
/*     */   private WSIO request;
/*     */   private WSIO response;
/*     */   private String wsdlOperation;
/*     */   private String serviceName;
/*     */   private String portName;
/*     */   private Map<String, String> nsContext;
/*     */ 
/*     */   public OBPInfo(String serviceName, String portName, String wsdlOperation, String doc, WSIO request, WSIO response, Map<String, String> nsContext)
/*     */   {
/*  38 */     this.nsContext = nsContext;
/*  39 */     this.doc = doc;
/*  40 */     this.request = request;
/*  41 */     this.response = response;
/*  42 */     this.wsdlOperation = wsdlOperation;
/*  43 */     this.serviceName = serviceName;
/*  44 */     this.portName = portName;
/*     */   }

/*     */   public OBPInfo(String wsdlOperation)
/*     */   {
/*  49 */     this.wsdlOperation = wsdlOperation;
/*     */   }




/*     */   public String getDoc()
/*     */   {
/*  57 */     return this.doc;
/*     */   }




/*     */   public void setDoc(String doc)
/*     */   {
/*  65 */     this.doc = doc;
/*     */   }



/*     */   public String getWsdlOperationName()
/*     */   {
/*  72 */     return this.wsdlOperation;
/*     */   }





/*     */   public WSIO getRequest()
/*     */   {
/*  81 */     return this.request;
/*     */   }




/*     */   public void setRequest(WSIO request)
/*     */   {
/*  89 */     this.request = request;
/*     */   }




/*     */   public WSIO getResponse()
/*     */   {
/*  97 */     return this.response;
/*     */   }




/*     */   public void setResponse(WSIO response)
/*     */   {
/* 105 */     this.response = response;
/*     */   }




/*     */   public Map<String, String> getNsContext()
/*     */   {
/* 113 */     return this.nsContext;
/*     */   }




/*     */   public void setNsContext(Map<String, String> nsContext)
/*     */   {
/* 121 */     this.nsContext = nsContext;
/*     */   }

/*     */   public boolean isRequestMultiple()
/*     */   {
/* 126 */     return ((this.request.getMaxOccurs() > 1) || (this.request.getMaxOccurs() < 0));
/*     */   }

/*     */   public boolean isResponseMultiple()
/*     */   {
/* 131 */     return ((this.response.getMaxOccurs() > 1) || (this.response.getMaxOccurs() < 0));
/*     */   }



/*     */   public String getWsdlOperation()
/*     */   {
/* 138 */     return this.wsdlOperation;
/*     */   }



/*     */   public String getServiceName()
/*     */   {
/* 145 */     return this.serviceName;
/*     */   }



/*     */   public String getPortName()
/*     */   {
/* 152 */     return this.portName;
/*     */   }



/*     */   public OBPInfo createNewInstance(WSIO request, WSIO response)
/*     */   {
/* 159 */     return new OBPInfo(this.serviceName, this.portName, this.wsdlOperation, this.doc, request, response, this.nsContext);
/*     */   }
/*     */ }
