/*     */ package com.ibm.tivoli.maximo.interaction.obp;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.StringTokenizer;
/*     */ 

















/*     */ public class OBPNode
/*     */   implements Serializable
/*     */ {
/*     */   protected String name;
/*  26 */   protected String xmlLocation = null;
/*  27 */   protected String title = null;
/*     */   protected String doc;
/*     */   protected String decsription;
/*  30 */   protected boolean markedForDelete = false;
/*  31 */   protected int id = 0;
/*  32 */   protected boolean required = false;
/*  33 */   protected String xmlLocalPartName = null;
/*     */ 
/*     */   void setId(int id)
/*     */   {
/*  38 */     this.id = id;
/*     */   }

/*     */   public int getId()
/*     */   {
/*  43 */     return this.id;
/*     */   }




/*     */   public String getName()
/*     */   {
/*  51 */     return this.name;
/*     */   }




/*     */   public void setName(String name)
/*     */   {
/*  59 */     this.name = name;
/*  60 */     this.title = name;
/*     */   }





/*     */   public String getXmlLocation()
/*     */   {
/*  69 */     return this.xmlLocation;
/*     */   }




/*     */   public void setXmlLocation(String xmlLocation)
/*     */   {
/*  77 */     this.xmlLocation = (((xmlLocation == null) || (xmlLocation.trim().length() == 0)) ? null : xmlLocation.trim());
/*  78 */     if (this.xmlLocation == null)
/*     */       return;
/*  80 */     StringTokenizer strtk = new StringTokenizer(xmlLocation, "/");
/*  81 */     this.xmlLocalPartName = strtk.nextToken();
/*  82 */     while (strtk.hasMoreTokens())
/*     */     {
/*  84 */       this.xmlLocalPartName = strtk.nextToken();
/*     */     }
/*  86 */     if (this.xmlLocalPartName.indexOf(58) > 0)
/*     */     {
/*  88 */       this.xmlLocalPartName = this.xmlLocalPartName.substring(this.xmlLocalPartName.indexOf(58) + 1);
/*     */     }
/*  90 */     if (!(this.xmlLocalPartName.startsWith("@")))
/*     */       return;
/*  92 */     this.xmlLocalPartName = this.xmlLocalPartName.substring(1);
/*     */   }







/*     */   public String getTitle()
/*     */   {
/* 103 */     return this.title;
/*     */   }




/*     */   public void setTitle(String title)
/*     */   {
/* 111 */     this.title = title;
/*     */   }




/*     */   public String getDoc()
/*     */   {
/* 119 */     return this.doc;
/*     */   }




/*     */   public void setDoc(String doc)
/*     */   {
/* 127 */     this.doc = doc;
/*     */   }




/*     */   public String getDecsription()
/*     */   {
/* 135 */     return this.decsription;
/*     */   }




/*     */   public void setDecsription(String decsription)
/*     */   {
/* 143 */     this.decsription = decsription;
/*     */   }

/*     */   public void markForDelete(boolean deleted)
/*     */   {
/* 148 */     this.markedForDelete = deleted;
/*     */   }

/*     */   public boolean isMarkedForDelete()
/*     */   {
/* 153 */     return this.markedForDelete;
/*     */   }




/*     */   public boolean isRequired()
/*     */   {
/* 161 */     return this.required;
/*     */   }




/*     */   public void setRequired(boolean required)
/*     */   {
/* 169 */     this.required = required;
/*     */   }

/*     */   public String getXMLLocalPartName()
/*     */   {
/* 174 */     return this.xmlLocalPartName;
/*     */   }
/*     */ }
