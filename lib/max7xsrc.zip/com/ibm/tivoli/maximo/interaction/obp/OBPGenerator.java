/*      */ package com.ibm.tivoli.maximo.interaction.obp;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.interaction.process.InteractionUtil;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.OperationInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.PortInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.ServiceInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.WSDLInfo;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.WSDLParser;
/*      */ import com.ibm.tivoli.maximo.interaction.wsdl.WSDLParserFactory;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.SchemaAttributeModel;
/*      */ import org.apache.xmlbeans.SchemaGlobalElement;
/*      */ import org.apache.xmlbeans.SchemaLocalAttribute;
/*      */ import org.apache.xmlbeans.SchemaParticle;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SchemaTypeSystem;
/*      */ import org.apache.xmlbeans.XmlAnySimpleType;
/*      */ import org.apache.xmlbeans.impl.xsd2inst.SampleXmlUtil;
/*      */ import org.jdom.Attribute;
/*      */ import org.jdom.Document;
/*      */ import org.jdom.Element;
/*      */ import org.jdom.Namespace;
/*      */ import psdi.app.configure.ConfigureService;
/*      */ import psdi.iface.util.XMLUtils;
/*      */ import psdi.util.MXApplicationException;
/*      */ import psdi.util.MXException;
/*      */ import psdi.util.MXFormat;
/*      */ import psdi.util.logging.MXLogger;
/*      */ 



/*      */ public class OBPGenerator
/*      */ {
/*   69 */   private static Random random = new Random();
/*      */   private String interactionName;
/*   71 */   public static final int MAX_ATTRNAME_LENGTH = ConfigureService.MAX_NAME_LENGTH - 3;
/*      */   public static final int MAX_OBJNAME_LENGTH = 20;
/*      */   private byte[] sampleReqXml;
/*      */   private byte[] sampleRespXml;
/*   77 */   private static MXLogger logger = InteractionUtil.INTERACTIONLOGGER;
/*      */   private int wsioCount;
/*   81 */   private static Map<Integer, String> wsioAttrTypes = new HashMap();
/*      */   public static final Namespace obpNS;
/*      */   private Map<String, String> nsContext;
/*      */   private int prefixCnt;
/*      */   private boolean ignoreAttributes;
/*      */   protected boolean ignoreWildcards;
/*      */   protected boolean ignoreRecursion;
/*      */   private boolean treatListAsAtomic;
/*      */   private int seedId;
/*      */   private boolean processResponse;
/*      */ 
/*      */   public OBPGenerator(String interactionName, boolean ignoreAttributes, boolean ignoreWildcards, boolean ignoreRecursion, boolean treatListAsAtomic, boolean processResponse)
/*      */   {
/*   74 */     this.sampleReqXml = null;
/*   75 */     this.sampleRespXml = null;


/*      */ 
/*   79 */     this.wsioCount = 1;
































/*      */ 
/*  113 */     this.nsContext = new HashMap();
/*  114 */     this.prefixCnt = 0;
/*      */ 
/*  116 */     this.ignoreAttributes = false;
/*  117 */     this.ignoreWildcards = true;
/*  118 */     this.ignoreRecursion = true;
/*  119 */     this.treatListAsAtomic = false;
/*      */ 
/*  121 */     this.seedId = 0;
/*  122 */     this.processResponse = true;

/*      */   public OBPGenerator(String interactionName)
/*      */   {
/*  126 */     this(interactionName, false);
/*      */   }

/*      */   public OBPGenerator(String interactionName, boolean ignoreAttributes)
/*      */   {
/*  131 */     this(interactionName, ignoreAttributes, true);
/*      */   }


/*      */   public OBPGenerator(String interactionName, boolean ignoreAttributes, boolean ignoreWildcards)
/*      */   {
/*  137 */     this(interactionName, ignoreAttributes, ignoreWildcards, true);
/*      */   }


/*      */   public OBPGenerator(String interactionName, boolean ignoreAttributes, boolean ignoreWildcards, boolean ignoreRecursion)
/*      */   {
/*  143 */     this(interactionName, ignoreAttributes, ignoreWildcards, ignoreRecursion, false);
/*      */   }


/*      */   public OBPGenerator(String interactionName, boolean ignoreAttributes, boolean ignoreWildcards, boolean ignoreRecursion, boolean treatListAsAtomic)
/*      */   {
/*  149 */     this(interactionName, ignoreAttributes, ignoreWildcards, ignoreRecursion, treatListAsAtomic, true);
/*      */   }




/*      */ 
/*  156 */     this.interactionName = interactionName;
/*  157 */     this.ignoreAttributes = ignoreAttributes;
/*  158 */     this.ignoreWildcards = ignoreWildcards;
/*  159 */     this.ignoreRecursion = ignoreRecursion;
/*  160 */     this.treatListAsAtomic = treatListAsAtomic;
/*  161 */     this.processResponse = processResponse;
/*  162 */     this.seedId = 1;
/*      */   }

/*      */   public static OBPInfo cloneOBP(OBPInfo obpInfo)
/*      */   {
/*      */     try
/*      */     {
/*  169 */       ByteArrayOutputStream bo = new ByteArrayOutputStream();
/*  170 */       ObjectOutputStream oo = new ObjectOutputStream(bo);
/*  171 */       oo.writeObject(obpInfo);
/*  172 */       oo.close();
/*  173 */       ObjectInputStream oi = new ObjectInputStream(new ByteArrayInputStream(bo.toByteArray()));
/*  174 */       return ((OBPInfo)oi.readObject());
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  178 */       logger.error(e.getMessage(), e);
/*      */     }
/*  180 */     return null;
/*      */   }

/*      */   public static OBPInfo parse(byte[] obpDoc) throws MXException
/*      */   {
/*  185 */     Document doc = XMLUtils.convertBytesToDocument(obpDoc);
/*  186 */     Element opElem = doc.getRootElement();
/*  187 */     OBPInfo opOBP = createOBPInfo(opElem);
/*      */ 
/*  189 */     Element request = opElem.getChild("REQUEST", obpNS);
/*  190 */     Element response = opElem.getChild("RESPONSE", obpNS);
/*      */ 
/*  192 */     if (request != null)
/*      */     {
/*  194 */       Element wsioRootElem = (Element)request.getChildren().get(0);
/*  195 */       WSIO wsio = createWSIO(wsioRootElem);
/*  196 */       opOBP.setRequest(wsio);
/*      */     }
/*      */ 
/*  199 */     if (response != null)
/*      */     {
/*  201 */       Element wsioRootElem = (Element)response.getChildren().get(0);
/*  202 */       WSIO wsio = createWSIO(wsioRootElem);
/*  203 */       opOBP.setResponse(wsio);
/*      */     }
/*      */ 
/*  206 */     return opOBP;
/*      */   }

/*      */   private static WSIO createWSIO(Element wsioElem) throws MXException
/*      */   {
/*  211 */     String name = wsioElem.getChildText("NAME", obpNS);
/*  212 */     WSIO wsio = new WSIO();
/*  213 */     wsio.setName(name);
/*      */ 
/*  215 */     String title = wsioElem.getChildText("TITLE", obpNS);
/*  216 */     wsio.setTitle(title);
/*      */ 
/*  218 */     String id = wsioElem.getChildText("ID", obpNS);
/*  219 */     wsio.setId(Integer.parseInt(id));
/*      */ 
/*  221 */     String maxOccurs = wsioElem.getChildText("MAXOCCURS", obpNS);
/*  222 */     if (maxOccurs != null) {
/*  223 */       wsio.setMaxOccurs(Integer.parseInt(maxOccurs));
/*      */     }
/*  225 */     String minOccurs = wsioElem.getChildText("MINOCCURS", obpNS);
/*  226 */     if (minOccurs != null) {
/*  227 */       wsio.setMinOccurs(Integer.parseInt(minOccurs));
/*      */     }
/*  229 */     String xmlLocation = wsioElem.getChildText("XMLLOCATION", obpNS);
/*  230 */     wsio.setXmlLocation(xmlLocation);
/*  231 */     List wsioAttrElemList = wsioElem.getChildren("WSIOATTRIBUTE", obpNS);
/*  232 */     for (Element wsioAttrElem : wsioAttrElemList)
/*      */     {
/*  234 */       WSIOAttribute wsioAttribute = createWSIOAttribute(wsioAttrElem);
/*  235 */       wsio.addWSIOAttribute(wsioAttribute);
/*      */     }
/*      */ 
/*  238 */     List childrenWSIOElemList = wsioElem.getChildren("WSIO", obpNS);
/*  239 */     for (Element wsioChildElem : childrenWSIOElemList)
/*      */     {
/*  241 */       WSIO wsioChild = createWSIO(wsioChildElem);
/*  242 */       wsio.addWSIOChild(wsioChild);
/*      */     }
/*      */ 
/*  245 */     return wsio;
/*      */   }

/*      */   private static boolean isNull(String value)
/*      */   {
/*  250 */     return ((value == null) || (value.trim().length() == 0));
/*      */   }

/*      */   private static WSIOAttribute createWSIOAttribute(Element wsioAttrElem) throws MXException
/*      */   {
/*  255 */     WSIOAttribute wsioAttr = new WSIOAttribute();
/*  256 */     String name = wsioAttrElem.getChildText("NAME", obpNS);
/*  257 */     String containerAttrName = wsioAttrElem.getAttributeValue("containerAttr");
/*  258 */     if (!(isNull(containerAttrName)))
/*      */     {
/*  260 */       wsioAttr.setContainerAttributeName(containerAttrName);
/*      */     }
/*  262 */     wsioAttr.setName(name);
/*  263 */     if (logger.isDebugEnabled())
/*      */     {
/*  265 */       logger.debug("createWSIOAttribute attr name=" + name);
/*      */     }
/*      */ 
/*  268 */     String id = wsioAttrElem.getChildText("ID", obpNS);
/*  269 */     wsioAttr.setId(Integer.parseInt(id));
/*      */ 
/*  271 */     String nillable = wsioAttrElem.getChildText("NILLABLE", obpNS);
/*  272 */     wsioAttr.setNillable(Boolean.parseBoolean(nillable));
/*      */ 
/*  274 */     String type = wsioAttrElem.getChildText("TYPE", obpNS);
/*  275 */     wsioAttr.setType(type);
/*  276 */     String title = wsioAttrElem.getChildText("TITLE", obpNS);
/*  277 */     wsioAttr.setTitle(title);
/*  278 */     String parentName = wsioAttrElem.getChildText("PARENTNAME", obpNS);
/*  279 */     wsioAttr.setParentWSIOName(parentName);
/*      */ 
/*  281 */     String xmlLocation = wsioAttrElem.getChildText("XMLLOCATION", obpNS);
/*  282 */     wsioAttr.setXmlLocation(xmlLocation);
/*      */ 
/*  284 */     String mapToParent = wsioAttrElem.getChildText("MAPTOPARENT", obpNS);
/*  285 */     if ((mapToParent != null) && (mapToParent.trim().length() > 0))
/*      */     {
/*  287 */       if (logger.isDebugEnabled())
/*      */       {
/*  289 */         logger.debug("createWSIOAttribute mapToParent =" + mapToParent);
/*      */       }
/*  291 */       wsioAttr.setMapToParent(MXFormat.stringToBoolean(mapToParent));
/*      */     }
/*      */ 
/*  294 */     String defaultValue = wsioAttrElem.getChildText("DEFAULTVALUE", obpNS);
/*  295 */     if ((defaultValue != null) && (defaultValue.trim().length() > 0))
/*      */     {
/*  297 */       if (logger.isDebugEnabled())
/*      */       {
/*  299 */         logger.debug("createWSIOAttribute defaultValue =" + defaultValue);
/*      */       }
/*  301 */       wsioAttr.setDefaultValue(defaultValue);
/*      */     }
/*      */ 
/*  304 */     String required = wsioAttrElem.getChildText("REQUIRED", obpNS);
/*  305 */     if ((required != null) && (required.trim().length() > 0))
/*      */     {
/*  307 */       if (logger.isDebugEnabled())
/*      */       {
/*  309 */         logger.debug("createWSIOAttribute required =" + required);
/*      */       }
/*  311 */       wsioAttr.setRequired(MXFormat.stringToBoolean(required));
/*      */     }
/*      */ 
/*  314 */     String maxLength = wsioAttrElem.getChildText("MAXLENGTH", obpNS);
/*  315 */     if ((maxLength != null) && (maxLength.trim().length() > 0))
/*      */     {
/*  317 */       if (logger.isDebugEnabled())
/*      */       {
/*  319 */         logger.debug("createWSIOAttribute maxLength =" + maxLength);
/*      */       }
/*  321 */       wsioAttr.setMaxLength(Integer.parseInt(maxLength));
/*      */     }
/*      */ 
/*  324 */     String minLength = wsioAttrElem.getChildText("MINLENGTH", obpNS);
/*  325 */     if ((minLength != null) && (minLength.trim().length() > 0))
/*      */     {
/*  327 */       if (logger.isDebugEnabled())
/*      */       {
/*  329 */         logger.debug("createWSIOAttribute minLength =" + minLength);
/*      */       }
/*  331 */       wsioAttr.setMinLength(Integer.parseInt(minLength));
/*      */     }
/*      */ 
/*  334 */     String length = wsioAttrElem.getChildText("LENGTH", obpNS);
/*  335 */     if ((length != null) && (length.trim().length() > 0))
/*      */     {
/*  337 */       if (logger.isDebugEnabled())
/*      */       {
/*  339 */         logger.debug("createWSIOAttribute length =" + length);
/*      */       }
/*  341 */       wsioAttr.setLength(Integer.parseInt(length));
/*      */     }
/*      */ 
/*  344 */     Element patternsElem = wsioAttrElem.getChild("PATTERNS", obpNS);
/*  345 */     if (patternsElem != null)
/*      */     {
/*  347 */       List parrensElemList = patternsElem.getChildren("PATTERN", obpNS);
/*  348 */       String[] patterns = new String[parrensElemList.size()];
/*  349 */       int i = 0;
/*  350 */       for (Element patternElem : parrensElemList)
/*      */       {
/*  352 */         patterns[i] = patternElem.getText();
/*  353 */         ++i;
/*      */       }
/*  355 */       wsioAttr.setPatterns(patterns);
/*      */     }
/*      */ 
/*  358 */     Element valueListElem = wsioAttrElem.getChild("VALUELIST", obpNS);
/*  359 */     if (valueListElem != null)
/*      */     {
/*  361 */       Attribute attr = valueListElem.getAttribute("type");
/*  362 */       if (attr != null)
/*      */       {
/*  364 */         wsioAttr.setEnumType(QName.valueOf(attr.getValue()));
/*      */       }
/*  366 */       List valueElemList = valueListElem.getChildren("VALUE", obpNS);
/*  367 */       List values = new ArrayList(valueElemList.size());
/*  368 */       for (Element valueElem : valueElemList)
/*      */       {
/*  370 */         values.add(valueElem.getText());
/*      */       }
/*  372 */       wsioAttr.setEnumList(values);
/*      */     }
/*      */ 
/*  375 */     String totalDigits = wsioAttrElem.getChildText("TOTALDIGITS", obpNS);
/*  376 */     if ((totalDigits != null) && (totalDigits.trim().length() > 0))
/*      */     {
/*  378 */       if (logger.isDebugEnabled())
/*      */       {
/*  380 */         logger.debug("createWSIOAttribute totalDigits =" + totalDigits);
/*      */       }
/*  382 */       wsioAttr.setTotalDigits(Integer.parseInt(totalDigits));
/*      */     }
/*      */ 
/*  385 */     String fractionDigits = wsioAttrElem.getChildText("FRACTIONDIGITS", obpNS);
/*  386 */     if ((fractionDigits != null) && (fractionDigits.trim().length() > 0))
/*      */     {
/*  388 */       if (logger.isDebugEnabled())
/*      */       {
/*  390 */         logger.debug("createWSIOAttribute fractionDigits =" + fractionDigits);
/*      */       }
/*  392 */       wsioAttr.setFractionDigits(Integer.parseInt(fractionDigits));
/*      */     }
/*      */ 
/*  395 */     String maxExclusive = wsioAttrElem.getChildText("MAXEXCLUSIVE", obpNS);
/*  396 */     if ((maxExclusive != null) && (maxExclusive.trim().length() > 0))
/*      */     {
/*  398 */       if (logger.isDebugEnabled())
/*      */       {
/*  400 */         logger.debug("createWSIOAttribute maxExclusive =" + maxExclusive);
/*      */       }
/*  402 */       wsioAttr.setMaxExclusive(maxExclusive);
/*      */     }
/*  404 */     String minExclusive = wsioAttrElem.getChildText("MINEXCLUSIVE", obpNS);
/*  405 */     if ((minExclusive != null) && (minExclusive.trim().length() > 0))
/*      */     {
/*  407 */       if (logger.isDebugEnabled())
/*      */       {
/*  409 */         logger.debug("createWSIOAttribute minExclusive =" + minExclusive);
/*      */       }
/*  411 */       wsioAttr.setMinExclusive(minExclusive);
/*      */     }
/*  413 */     String maxInclusive = wsioAttrElem.getChildText("MAXINCLUSIVE", obpNS);
/*  414 */     if ((maxInclusive != null) && (maxInclusive.trim().length() > 0))
/*      */     {
/*  416 */       if (logger.isDebugEnabled())
/*      */       {
/*  418 */         logger.debug("createWSIOAttribute maxInclusive =" + maxInclusive);
/*      */       }
/*  420 */       wsioAttr.setMaxInclusive(maxInclusive);
/*      */     }
/*  422 */     String minInclusive = wsioAttrElem.getChildText("MININCLUSIVE", obpNS);
/*  423 */     if ((minInclusive != null) && (minInclusive.trim().length() > 0))
/*      */     {
/*  425 */       if (logger.isDebugEnabled())
/*      */       {
/*  427 */         logger.debug("createWSIOAttribute minInclusive =" + minInclusive);
/*      */       }
/*  429 */       wsioAttr.setMinInclusive(minInclusive);
/*      */     }
/*      */ 
/*  432 */     return wsioAttr;
/*      */   }


/*      */   private static OBPInfo createOBPInfo(Element opElem)
/*      */   {
/*  438 */     String wsdlOperationName = opElem.getAttributeValue("name");
/*  439 */     OBPInfo opOBP = new OBPInfo(wsdlOperationName);
/*      */ 
/*  441 */     List nsList = opElem.getAdditionalNamespaces();
/*  442 */     Map nsContext = new HashMap();
/*  443 */     for (Namespace ns : nsList)
/*      */     {
/*  445 */       nsContext.put(ns.getURI(), ns.getPrefix());
/*      */     }
/*  447 */     opOBP.setNsContext(nsContext);
/*  448 */     return opOBP;
/*      */   }

/*      */   public OBPInfo parse(File file)
/*      */     throws MXException
/*      */   {
/*  454 */     byte[] obpDoc = XMLUtils.readXMLFileToBytes(file.getAbsolutePath());
/*  455 */     return parse(obpDoc);
/*      */   }

/*      */   public static byte[] toBytes(OBPInfo obpInfo) throws MXException
/*      */   {
/*  460 */     Document doc = new Document();
/*  461 */     Element elem = new Element("OPERATION", obpNS);
/*  462 */     doc.setRootElement(elem);
/*  463 */     elem.setAttribute(new Attribute("name", obpInfo.getWsdlOperationName()));
/*  464 */     if (obpInfo.getDoc() != null)
/*      */     {
/*  466 */       elem.setAttribute(new Attribute("doc", obpInfo.getDoc()));
/*      */     }
/*  468 */     Map obpNSContext = obpInfo.getNsContext();
/*  469 */     if (obpNSContext != null)
/*      */     {
/*  471 */       Set nsSet = obpNSContext.entrySet();
/*  472 */       for (Map.Entry entry : nsSet)
/*      */       {
/*  474 */         elem.addNamespaceDeclaration(Namespace.getNamespace((String)entry.getValue(), (String)entry.getKey()));
/*      */       }
/*      */     }
/*  477 */     if (obpInfo.getRequest() != null)
/*      */     {
/*  479 */       Element request = new Element("REQUEST", obpNS);
/*  480 */       elem.addContent(request);
/*  481 */       prepareWSIODocument(obpInfo.getRequest(), request);
/*      */     }
/*  483 */     if (obpInfo.getResponse() != null)
/*      */     {
/*  485 */       Element response = new Element("RESPONSE", obpNS);
/*  486 */       elem.addContent(response);
/*  487 */       prepareWSIODocument(obpInfo.getResponse(), response);
/*      */     }
/*  489 */     return XMLUtils.convertDocumentToBytes(doc);
/*      */   }


/*      */   public OBPInfo create(URL wsdlURL, String serviceName, String portName, String operationName)
/*      */     throws MXException
/*      */   {
/*  496 */     WSDLParser wsdlPasrser = WSDLParserFactory.getWSDLParser();
/*  497 */     WSDLInfo wsdlInfo = wsdlPasrser.parse(wsdlURL);
/*      */ 
/*  499 */     return create(wsdlInfo, serviceName, portName, operationName);
/*      */   }

/*      */   private byte[] getSampleXml(QName rootElementName, SchemaTypeSystem sts) throws MXApplicationException
/*      */   {
/*  504 */     SchemaType[] globalElems = sts.documentTypes();
/*  505 */     SchemaType elem = null;
/*  506 */     for (int i = 0; i < globalElems.length; ++i)
/*      */     {
/*  508 */       if (!(rootElementName.equals(globalElems[i].getDocumentElementName())))
/*      */         continue;
/*  510 */       elem = globalElems[i];
/*  511 */       break;

/*      */     }
/*      */ 
/*  515 */     if (elem == null)
/*      */     {
/*  517 */       throw new RuntimeException("Could not find a global element with name \"" + rootElementName + "\"");

/*      */     }
/*      */ 
/*  521 */     String result = SampleXmlUtil.createSampleForType(elem);

/*      */     try
/*      */     {
/*  525 */       return result.getBytes("UTF-8");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  529 */       throw new MXApplicationException("iface", "errorgensample", e);
/*      */     }
/*      */   }


/*      */   public OBPInfo create(WSDLInfo wsdlInfo, String serviceName, String portName, String operationName)
/*      */     throws MXException
/*      */   {
/*  537 */     ServiceInfo serviceInfo = wsdlInfo.getServiceInfo(serviceName);
/*  538 */     PortInfo portInfo = serviceInfo.getPortInfo(portName);
/*  539 */     OperationInfo operationInfo = portInfo.getOperationInfo(operationName);
/*      */ 
/*  541 */     SchemaTypeSystem sts = wsdlInfo.getCompiledSchema();
/*  542 */     this.sampleReqXml = getSampleXml(operationInfo.getInputElement(), sts);
/*  543 */     WSIO request = parseSchema(sts, operationInfo.getInputElement());
/*  544 */     WSIO response = null;
/*      */ 
/*  546 */     if ((this.processResponse) && (operationInfo.getOutputElement() != null))
/*      */     {
/*  548 */       response = parseSchema(sts, operationInfo.getOutputElement());
/*  549 */       this.sampleRespXml = getSampleXml(operationInfo.getOutputElement(), sts);
/*      */     }
/*      */ 
/*  552 */     if (logger.isDebugEnabled())
/*      */     {
/*  554 */       logger.debug("wsio request=" + request);
/*  555 */       logger.debug("wsio response=" + response);








/*      */     }
/*      */ 
/*  566 */     OBPInfo obpInfo = new OBPInfo(serviceName, portName, operationName, null, request, response, this.nsContext);
/*  567 */     return obpInfo;
/*      */   }

/*      */   public OBPInfo optimizeRequest(OBPInfo obpInfo)
/*      */   {
/*  572 */     obpInfo = cloneOBP(obpInfo);
/*  573 */     WSIO request = optimizeWSIO(obpInfo.getRequest());
/*  574 */     request = resolveInvalidWSIOs(request, true);
/*  575 */     obpInfo.setRequest(request);
/*  576 */     return obpInfo;
/*      */   }

/*      */   public OBPInfo optimizeResponse(OBPInfo obpInfo)
/*      */   {
/*  581 */     if ((!(this.processResponse)) || (obpInfo.getResponse() == null))
/*      */     {
/*  583 */       return null;
/*      */     }
/*  585 */     obpInfo = cloneOBP(obpInfo);
/*  586 */     WSIO response = optimizeWSIO(obpInfo.getResponse());
/*  587 */     response = resolveInvalidWSIOs(response, false);
/*  588 */     obpInfo.setResponse(response);
/*  589 */     return obpInfo;
/*      */   }

/*      */   protected WSIO resolveInvalidWSIOs(WSIO wsio, boolean req)
/*      */   {
/*  594 */     if ((!(req)) && (wsio.isRoot()) && (wsio.getMaxOccurs() == 1) && (wsio.getWSIOAttributes().size() == 1) && (((WSIOAttribute)wsio.getWSIOAttributes().get(0)).getXmlLocation() == null) && (!(((WSIOAttribute)wsio.getWSIOAttributes().get(0)).isMapToParent())))



/*      */     {
/*  599 */       return null;

/*      */     }
/*      */ 
/*  603 */     if (wsio.hasAttributes())
/*      */     {
/*  605 */       List wsioChildrenList = wsio.getWSIOChildren();
/*  606 */       if (wsioChildrenList != null)
/*      */       {
/*  608 */         for (WSIO childWSIO : wsioChildrenList)
/*      */         {
/*  610 */           resolveInvalidWSIOs(childWSIO, req);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*  616 */     else if (!(req))
/*      */     {
/*  618 */       if (wsio.isRoot())
/*      */       {
/*  620 */         return null;

/*      */       }
/*      */ 
/*  624 */       WSIO parentWSIO = wsio.getParent();
/*  625 */       parentWSIO.getWSIOChildren().remove(wsio);

/*      */     }
/*      */     else
/*      */     {
/*  630 */       wsio.createFillerAttribute(getNextId(), false);
/*  631 */       List wsioChildrenList = wsio.getWSIOChildren();
/*  632 */       if (wsioChildrenList != null)
/*      */       {
/*  634 */         for (WSIO childWSIO : wsioChildrenList)
/*      */         {
/*  636 */           resolveInvalidWSIOs(childWSIO, req);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  641 */     return wsio;
/*      */   }

/*      */   public OBPInfo create(InputStream wsdlStream, String operationName)
/*      */   {
/*  646 */     return null;
/*      */   }

/*      */   private static void addContent(Element parentElem, String elemName, String text)
/*      */   {
/*  651 */     Element elem = new Element(elemName, obpNS);
/*  652 */     elem.setText(text);
/*  653 */     parentElem.addContent(elem);
/*      */   }

/*      */   private static void prepareWSIODocument(WSIO wsio, Element parent)
/*      */   {
/*  658 */     Element wsioElem = new Element("WSIO", obpNS);
/*  659 */     addContent(wsioElem, "NAME", wsio.getName());
/*  660 */     addContent(wsioElem, "ID", "" + wsio.getId());
/*  661 */     addContent(wsioElem, "MAXOCCURS", "" + wsio.getMaxOccurs());
/*  662 */     addContent(wsioElem, "MINOCCURS", "" + wsio.getMinOccurs());
/*  663 */     addContent(wsioElem, "TITLE", wsio.getTitle());
/*  664 */     addContent(wsioElem, "XMLLOCATION", wsio.getXmlLocation());
/*  665 */     parent.addContent(wsioElem);
/*  666 */     List wsioAttrList = wsio.getWSIOAttributes();
/*      */     Set deletedWSIOAttrSet;/*  667 */     if (wsioAttrList != null)
/*      */     {
/*  669 */       deletedWSIOAttrSet = new HashSet();
/*  670 */       for (WSIOAttribute wsioAttr : wsioAttrList)
/*      */       {
/*  672 */         if ((wsioAttr.getContainerAttributeName() != null) && (deletedWSIOAttrSet.contains(wsioAttr.getContainerAttributeName())))


/*      */         {
/*  676 */           logger.info("WSIOAttribute " + wsioAttr.getName() + " has container attr " + wsioAttr.getContainerAttributeName() + " marked for delete and hence removing it from the obp doc");


/*      */         }
/*      */ 
/*  681 */         if (wsioAttr.isMarkedForDelete())
/*      */         {
/*  683 */           deletedWSIOAttrSet.add(wsioAttr.getName());
/*  684 */           logger.info("WSIOAttribute " + wsioAttr.getName() + " marked for delete and " + "hence removing it from the obp doc");

/*      */         }
/*      */ 
/*  688 */         Element wsioAttrElem = new Element("WSIOATTRIBUTE", obpNS);
/*  689 */         if (!(isNull(wsioAttr.getContainerAttributeName())))
/*      */         {
/*  691 */           wsioAttrElem.setAttribute("containerAttr", wsioAttr.getContainerAttributeName());
/*      */         }
/*      */ 
/*  694 */         wsioElem.addContent(wsioAttrElem);
/*  695 */         addContent(wsioAttrElem, "NAME", wsioAttr.getName());
/*  696 */         addContent(wsioAttrElem, "PARENTNAME", wsioAttr.getParentWSIOName());
/*  697 */         addContent(wsioAttrElem, "ID", "" + wsioAttr.getId());
/*  698 */         addContent(wsioAttrElem, "TYPE", wsioAttr.getType());
/*  699 */         addContent(wsioAttrElem, "TITLE", wsioAttr.getTitle());
/*  700 */         addContent(wsioAttrElem, "NILLABLE", "" + wsioAttr.isNillable());
/*  701 */         addContent(wsioAttrElem, "XMLLOCATION", wsioAttr.getXmlLocation());
/*  702 */         if (wsioAttr.getXmlLocation() == null)
/*      */         {
/*  704 */           addContent(wsioAttrElem, "MAPTOPARENT", "" + wsioAttr.isMapToParent());
/*      */         }
/*  706 */         if (wsioAttr.isReadOnly())
/*      */         {
/*  708 */           addContent(wsioAttrElem, "READONLY", Boolean.toString(true));
/*      */         }
/*  710 */         if (wsioAttr.isRequired())
/*      */         {
/*  712 */           addContent(wsioAttrElem, "REQUIRED", Boolean.toString(true));
/*      */         }
/*  714 */         if (wsioAttr.hasDefaultValue())
/*      */         {
/*  716 */           addContent(wsioAttrElem, "DEFAULTVALUE", wsioAttr.getDefaultValue());
/*      */         }
/*      */ 
/*  719 */         if (wsioAttr.getType().equals("String"))
/*      */         {
/*  721 */           if (wsioAttr.getMaxLength() > 0)
/*      */           {
/*  723 */             addContent(wsioAttrElem, "MAXLENGTH", String.valueOf(wsioAttr.getMaxLength()));
/*      */           }
/*  725 */           if (wsioAttr.getMinLength() > 0)
/*      */           {
/*  727 */             addContent(wsioAttrElem, "MINLENGTH", String.valueOf(wsioAttr.getMinLength()));
/*      */           }
/*  729 */           if (wsioAttr.getLength() > 0)
/*      */           {
/*  731 */             addContent(wsioAttrElem, "LENGTH", String.valueOf(wsioAttr.getLength()));
/*      */           }
/*      */ 
/*  734 */           if (wsioAttr.getPatterns() != null)
/*      */           {
/*  736 */             Element patternsElem = new Element("PATTERNS", obpNS);
/*  737 */             String[] patterns = wsioAttr.getPatterns();
/*  738 */             for (String pattern : patterns)
/*      */             {
/*  740 */               addContent(patternsElem, "PATTERN", pattern);
/*      */             }
/*      */ 
/*  743 */             wsioAttrElem.addContent(patternsElem);
/*      */           }
/*      */         }
/*      */ 
/*  747 */         if ((wsioAttr.getType().equals("BigDecimal")) || (wsioAttr.getType().equals("BigInteger")))

/*      */         {
/*  750 */           if (wsioAttr.getTotalDigits() > 0)
/*      */           {
/*  752 */             addContent(wsioAttrElem, "TOTALDIGITS", String.valueOf(wsioAttr.getTotalDigits()));
/*      */           }
/*  754 */           if (wsioAttr.getFractionDigits() > 0)
/*      */           {
/*  756 */             addContent(wsioAttrElem, "FRACTIONDIGITS", String.valueOf(wsioAttr.getFractionDigits()));
/*      */           }
/*      */         }
/*      */ 
/*  760 */         if ((wsioAttr.getType().equals("BigDecimal")) || (wsioAttr.getType().equals("BigInteger")) || (wsioAttr.getType().equals("Double")) || (wsioAttr.getType().equals("Float")) || (wsioAttr.getType().equals("Integer")) || (wsioAttr.getType().equals("Long")) || (wsioAttr.getType().equals("Short")))



/*      */         {
/*  765 */           if (wsioAttr.getMaxExclusive() != null)
/*      */           {
/*  767 */             addContent(wsioAttrElem, "MAXEXCLUSIVE", wsioAttr.getMaxExclusive());
/*      */           }
/*  769 */           if (wsioAttr.getMinExclusive() != null)
/*      */           {
/*  771 */             addContent(wsioAttrElem, "MINEXCLUSIVE", wsioAttr.getMinExclusive());
/*      */           }
/*  773 */           if (wsioAttr.getMaxInclusive() != null)
/*      */           {
/*  775 */             addContent(wsioAttrElem, "MAXINCLUSIVE", wsioAttr.getMaxInclusive());
/*      */           }
/*  777 */           if (wsioAttr.getMinInclusive() != null)
/*      */           {
/*  779 */             addContent(wsioAttrElem, "MININCLUSIVE", wsioAttr.getMinInclusive());

/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  785 */         List list = wsioAttr.getEnumList();
/*  786 */         if ((list != null) && (list.size() > 0))
/*      */         {
/*  788 */           attrValueList = new Element("VALUELIST", obpNS);
/*  789 */           if (wsioAttr.getEnumType() != null)
/*      */           {
/*  791 */             attrValueList.setAttribute("type", wsioAttr.getEnumType().toString());
/*      */           }
/*  793 */           wsioAttrElem.addContent(attrValueList);
/*  794 */           for (String value : list)
/*      */           {
/*  796 */             addContent(attrValueList, "VALUE", value);

/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     Element attrValueList;
/*  803 */     List childrenWSIOList = wsio.getWSIOChildren();
/*  804 */     if (childrenWSIOList == null)
/*      */       return;
/*  806 */     for (WSIO childWSIO : childrenWSIOList)
/*      */     {
/*  808 */       if (childWSIO.isMarkedForDelete())
/*      */       {
/*  810 */         logger.info("WSIO " + childWSIO.getName() + " marked for delete and hence removing it from the obp doc");
/*      */       }
/*      */ 
/*  813 */       prepareWSIODocument(childWSIO, wsioElem);
/*      */     }
/*      */   }

/*      */   private SchemaGlobalElement getRootSchemaElement(SchemaTypeSystem sts, QName rootElementName)
/*      */     throws MXException
/*      */   {
/*  820 */     SchemaGlobalElement[] globalElements = sts.globalElements();
/*  821 */     SchemaGlobalElement rootElem = null;
/*  822 */     for (SchemaGlobalElement globalElement : globalElements)
/*      */     {
/*  824 */       if ((!(globalElement.getName().equals(rootElementName))) || (globalElement.isAbstract()) || (globalElement.isAttribute()))
/*      */         continue;
/*  826 */       rootElem = globalElement;

/*      */     }
/*      */ 
/*  830 */     if (rootElem == null)
/*      */     {
/*  832 */       String[] params = { rootElementName.toString() };
/*  833 */       throw new MXApplicationException("iface", "rootnotfound", params);
/*      */     }
/*  835 */     return rootElem;
/*      */   }

/*      */   private void listElements(List<OBPSchemaElement> list, SchemaParticle sp, SchemaParticle parentSp) throws MXException
/*      */   {
/*  840 */     if (logger.isDebugEnabled())
/*      */     {
/*  842 */       logger.debug("in recursion of SchemaParticles with list size " + list.size());
/*      */     }
/*  844 */     int ptype = sp.getParticleType();
/*  845 */     if ((ptype == 3) || (ptype == 1) || (ptype == 2))
/*      */     {
/*  847 */       if (logger.isDebugEnabled())
/*      */       {
/*  849 */         logger.debug("SP type sequence/all/choice");
/*      */       }
/*  851 */       SchemaParticle[] spChildren = sp.getParticleChildren();
/*  852 */       if (spChildren != null)
/*      */       {
/*  854 */         for (SchemaParticle spChild : spChildren)
/*      */         {
/*  856 */           listElements(list, spChild, sp);
/*      */         }
/*      */       }
/*      */     }
/*  860 */     else if (ptype == 4)
/*      */     {
/*  862 */       if (logger.isDebugEnabled())
/*      */       {
/*  864 */         logger.debug("SP type is element with name " + sp.getName().getLocalPart() + " and type " + sp.getType().getName() + " maxOccurs=" + sp.getMaxOccurs());

/*      */       }
/*      */ 
/*  868 */       OBPSchemaElement obpSchemaElem = new OBPSchemaElement(sp);
/*  869 */       if ((obpSchemaElem.getMaxOccurs() != null) && (parentSp != null))
/*      */       {
/*  871 */         if (parentSp.getIntMaxOccurs() > 1)
/*      */         {
/*  873 */           obpSchemaElem.setCombinedMaxOccurs(obpSchemaElem.getMaxOccurs().intValue() * parentSp.getIntMaxOccurs());
/*      */         }
/*  875 */         else if (parentSp.getIntMaxOccurs() < 0)
/*      */         {
/*  877 */           obpSchemaElem.setCombinedMaxOccurs(-1);
/*      */         }
/*  879 */         obpSchemaElem.setCombinedMinOccurs(obpSchemaElem.getMinOccurs().intValue() * parentSp.getIntMinOccurs());
/*      */       }
/*      */ 
/*  882 */       list.add(obpSchemaElem);


/*      */     }
/*  886 */     else if (this.ignoreWildcards)
/*      */     {
/*  888 */       logger.info("SP type is wildcard - ignoring...");
/*      */     }
/*      */     else
/*      */     {
/*  892 */       throw new MXApplicationException("iface", "wildcard");
/*      */     }
/*      */   }



/*      */   private List<OBPSchemaAttribute> listAttributes(SchemaType stype)
/*      */   {
/*  900 */     SchemaAttributeModel sam = stype.getAttributeModel();
/*  901 */     List obpAttrList = null;
/*  902 */     if (sam != null)
/*      */     {
/*  904 */       obpAttrList = new ArrayList();
/*  905 */       SchemaLocalAttribute[] attrs = sam.getAttributes();
/*  906 */       for (SchemaLocalAttribute attr : attrs)
/*      */       {
/*  908 */         logger.info("attribute name = " + attr.getName().getLocalPart());
/*  909 */         obpAttrList.add(new OBPSchemaAttribute(attr));
/*      */       }
/*      */     }
/*  912 */     return obpAttrList;
/*      */   }


/*      */   private WSIOAttribute simpleFieldToWSIOAttribute(WSIO parentWSIO, WSIOAttribute wsioAttr, OBPSchemaField schemaField)
/*      */   {
/*  918 */     if (wsioAttr == null)
/*      */     {
/*  920 */       wsioAttr = new WSIOAttribute();
/*      */     }
/*  922 */     wsioAttr.setNillable(schemaField.isNillable());
/*  923 */     SchemaType attrSchemaType = schemaField.getType();
/*  924 */     if (schemaField.getType().isSimpleType())
/*      */     {
/*  926 */       int simpleVariety = schemaField.getType().getSimpleVariety();
/*  927 */       if (simpleVariety == 2)
/*      */       {
/*  929 */         attrSchemaType = schemaField.getType().getUnionCommonBaseType();
/*  930 */         String type = getWSIOAttributeType(attrSchemaType);
/*  931 */         wsioAttr.setType(type);
/*      */       }
/*  933 */       else if (simpleVariety == 3)
/*      */       {
/*  935 */         if (this.treatListAsAtomic)
/*      */         {
/*  937 */           attrSchemaType = schemaField.getType().getListItemType();
/*  938 */           String type = getWSIOAttributeType(attrSchemaType);
/*  939 */           wsioAttr.setType(type);
/*      */         }
/*      */         else
/*      */         {
/*  943 */           wsioAttr.setType("String");
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  948 */         String type = getWSIOAttributeType(attrSchemaType);
/*  949 */         wsioAttr.setType(type);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  954 */       String type = getWSIOAttributeType(attrSchemaType);
/*  955 */       wsioAttr.setType(type);

/*      */     }
/*      */ 
/*  959 */     wsioAttr.setId(getNextId());
/*  960 */     String nsUri = schemaField.getName().getNamespaceURI();
/*  961 */     String nsPrefix = getPrefix(nsUri);
/*  962 */     String xmlLocation = (nsPrefix != null) ? nsPrefix + ":" + schemaField.getName().getLocalPart() : schemaField.getName().getLocalPart();
/*  963 */     String parentXmlLocation = parentWSIO.getXmlLocation();
/*  964 */     if (schemaField.isAttribute())
/*      */     {
/*  966 */       if (wsioAttr.getContainerAttributeName() != null)

/*      */       {
/*  969 */         WSIOAttribute parentWSIOAttr = parentWSIO.getWSIOAttribute(wsioAttr.getContainerAttributeName());
/*  970 */         parentXmlLocation = parentWSIOAttr.getXmlLocation();
/*      */       }
/*  972 */       xmlLocation = "@" + xmlLocation;
/*      */     }
/*      */ 
/*  975 */     xmlLocation = parentXmlLocation + "/" + xmlLocation;
/*  976 */     wsioAttr.setXmlLocation(xmlLocation);
/*      */ 
/*  978 */     generateWSIOAttributeName(parentWSIO, wsioAttr, false);

/*      */ 
/*  981 */     if (!(schemaField.isAttribute()))
/*      */     {
/*  983 */       if (schemaField.getMinOccurs() == BigInteger.ONE)
/*      */       {
/*  985 */         wsioAttr.setRequired(true);
/*      */       }
/*      */     }
/*  988 */     else if ((schemaField.isAttribute()) && (((OBPSchemaAttribute)schemaField).getUse() == 3))
/*      */     {
/*  990 */       wsioAttr.setRequired(true);

/*      */     }
/*      */ 
/*  994 */     if (schemaField.getType().hasPatternFacet())
/*      */     {
/*  996 */       wsioAttr.setPatterns(schemaField.getType().getPatterns());
/*      */     }
/*      */ 
/*  999 */     if (schemaField.isDefault())
/*      */     {
/* 1001 */       wsioAttr.setDefaultValue(schemaField.getDefaultText());
/* 1002 */       if ((schemaField.isFixed()) && (schemaField.isAttribute()) && 


/* 1005 */         (((OBPSchemaAttribute)schemaField).getUse() == 3))
/*      */       {
/* 1007 */         wsioAttr.setReadOnly(true);
/*      */       }
/*      */     }
/*      */ 
/* 1011 */     parseFacets(schemaField.getType(), wsioAttr);
/* 1012 */     return wsioAttr;
/*      */   }

/*      */   protected void generateWSIOAttributeName(WSIO parentWSIO, WSIOAttribute wsioAttr, boolean rand)
/*      */   {
/* 1017 */     Map attrMap = parentWSIO.getWSIOAttributesMap();
/*      */ 
/* 1019 */     String name = wsioAttr.getName();
/* 1020 */     if (name == null)
/*      */     {
/* 1022 */       String xmlLocalPart = wsioAttr.getXMLLocalPartName();
/* 1023 */       if (wsioAttr.isXmlAttribute())
/*      */       {
/* 1025 */         String containerAttrName = wsioAttr.getContainerAttributeName();
/* 1026 */         if (containerAttrName != null)
/*      */         {
/* 1028 */           name = generatePolicyBasedAttrName(containerAttrName + "_" + xmlLocalPart.toUpperCase(), rand);
/* 1029 */           wsioAttr.setTitle(parentWSIO.getTitle() + "/@" + xmlLocalPart);
/*      */         }
/*      */         else
/*      */         {
/* 1033 */           name = generatePolicyBasedAttrName(parentWSIO.getName() + "_" + xmlLocalPart.toUpperCase(), rand);
/* 1034 */           wsioAttr.setTitle("@" + xmlLocalPart);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1039 */         name = generatePolicyBasedAttrName(xmlLocalPart.toUpperCase(), rand);
/*      */ 
/* 1041 */         wsioAttr.setTitle(xmlLocalPart);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1046 */       name = generatePolicyBasedAttrName(name, true);

/*      */     }
/*      */ 
/* 1050 */     if (attrMap.containsKey(name))

/*      */     {
/* 1053 */       generateWSIOAttributeName(parentWSIO, wsioAttr, true);
/*      */     }
/*      */     else
/*      */     {
/* 1057 */       wsioAttr.setName(name);
/*      */     }
/*      */   }



/*      */   protected String generatePolicyBasedAttrName(String name, boolean rand)
/*      */   {
/* 1065 */     if (name.length() > MAX_ATTRNAME_LENGTH)
/*      */     {
/* 1067 */       name = name.substring(0, MAX_ATTRNAME_LENGTH - 4);
/*      */     }
/*      */ 
/* 1070 */     if (rand)
/*      */     {
/* 1072 */       name = name + random.nextInt(9999);
/*      */     }
/* 1074 */     return name;
/*      */   }

/*      */   private WSIO parseSchema(SchemaTypeSystem sts, QName root) throws MXException
/*      */   {
/* 1079 */     SchemaGlobalElement rootElem = getRootSchemaElement(sts, root);
/* 1080 */     OBPSchemaElement schemaElem = new OBPSchemaElement(rootElem, true);
/*      */ 
/* 1082 */     SchemaType obpSchemaElemType = schemaElem.getType();
/* 1083 */     logger.info("For element " + schemaElem.getName() + " obpSchemaElemType = " + obpSchemaElemType);
/* 1084 */     WSIO rootWSIO = new WSIO();
/* 1085 */     setWSIOMetaData(null, rootWSIO, schemaElem);
/*      */ 
/* 1087 */     if (obpSchemaElemType.isSimpleType())
/*      */     {
/* 1089 */       logger.info("root is simple type");
/* 1090 */       WSIOAttribute attr = simpleFieldToWSIOAttribute(rootWSIO, null, schemaElem);
/* 1091 */       attr.setXmlLocation(null);
/* 1092 */       rootWSIO.addWSIOAttribute(attr);
/*      */     }
/* 1094 */     else if ((obpSchemaElemType.getContentType() == 3) || (obpSchemaElemType.getContentType() == 4))

/*      */     {
/* 1097 */       logger.info("CT-CC Element with Element/mixed content");
/* 1098 */       SchemaParticle sp = obpSchemaElemType.getContentModel();
/* 1099 */       logger.info("sp maxoccurs=" + sp.getMaxOccurs());
/* 1100 */       List attrList = listAttributes(obpSchemaElemType);
/* 1101 */       List elemlist = new ArrayList();
/* 1102 */       if (attrList != null)
/*      */       {
/* 1104 */         logger.info("attr list size ===" + attrList.size());
/* 1105 */         for (OBPSchemaAttribute attr : attrList)
/*      */         {
/* 1107 */           logger.info("attr name=" + attr.getName());
/* 1108 */           if (!(isIgnoreAttribute(attr)))
/*      */           {
/* 1110 */             WSIOAttribute wsioAttr = simpleFieldToWSIOAttribute(rootWSIO, null, attr);
/* 1111 */             rootWSIO.addWSIOAttribute(wsioAttr);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1117 */       listElements(elemlist, sp, null);
/* 1118 */       logger.info("after recursion of SchemaParticles with list size " + elemlist.size());
/* 1119 */       if (obpSchemaElemType.getContentType() == 4)
/*      */       {
/* 1121 */         rootWSIO.createFillerAttribute(getNextId(), true);
/*      */       }
/* 1123 */       for (OBPSchemaElement elem : elemlist)
/*      */       {
/* 1125 */         logger.info("looping the particle list " + elem.getName());
/* 1126 */         parseSchema(rootWSIO, elem);
/*      */       }/*      */     }/*      */     else/*      */     {
/*      */       WSIOAttribute wsioParentAttr;
/* 1129 */       if ((obpSchemaElemType.getContentType() == 2) || (obpSchemaElemType.getContentType() == 1))

/*      */       {
/* 1132 */         logger.info("Root is CT-SC Element with simple content");
/* 1133 */         wsioParentAttr = null;
/* 1134 */         if (obpSchemaElemType.getContentType() == 2)
/*      */         {
/* 1136 */           wsioParentAttr = simpleFieldToWSIOAttribute(rootWSIO, null, schemaElem);
/* 1137 */           wsioParentAttr.setXmlLocation(null);
/* 1138 */           rootWSIO.addWSIOAttribute(wsioParentAttr);
/*      */         }
/*      */         else
/*      */         {
/* 1142 */           rootWSIO.createFillerAttribute(getNextId(), false);
/*      */         }
/* 1144 */         List attrList = listAttributes(obpSchemaElemType);
/* 1145 */         for (OBPSchemaAttribute attr : attrList)
/*      */         {
/* 1147 */           if (!(isIgnoreAttribute(attr)))
/*      */           {
/* 1149 */             WSIOAttribute wsioAttr = new WSIOAttribute();
/* 1150 */             if (wsioParentAttr != null)
/*      */             {
/* 1152 */               wsioAttr.setContainerAttributeName(wsioParentAttr.getName());
/* 1153 */               wsioAttr.setContainerAttrId(wsioParentAttr.getId());
/*      */             }
/*      */ 
/* 1156 */             wsioAttr = simpleFieldToWSIOAttribute(rootWSIO, wsioAttr, attr);
/* 1157 */             rootWSIO.addWSIOAttribute(wsioAttr);
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1163 */         logger.info("unknown type");
/*      */       }
/*      */     }
/* 1166 */     return rootWSIO;
/*      */   }

/*      */   protected boolean isRecursiveDefn(WSIO parentWSIO, SchemaType obpSchemaElemType)
/*      */   {
/* 1171 */     if (parentWSIO == null)
/*      */     {
/* 1173 */       return false;
/*      */     }
/* 1175 */     if ((parentWSIO.getSchemaType() != null) && (parentWSIO.getSchemaType().equals(obpSchemaElemType.getName())))
/*      */     {
/* 1177 */       return true;
/*      */     }
/* 1179 */     return isRecursiveDefn(parentWSIO.getParent(), obpSchemaElemType);
/*      */   }

/*      */   protected void parseSchema(WSIO parentWSIO, OBPSchemaElement schemaElem) throws MXException
/*      */   {
/* 1184 */     SchemaType obpSchemaElemType = schemaElem.getType();
/* 1185 */     boolean resursiveDefn = isRecursiveDefn(parentWSIO, obpSchemaElemType);
/* 1186 */     if (resursiveDefn)
/*      */     {
/* 1188 */       if (this.ignoreRecursion)
/*      */       {
/* 1190 */         return;

/*      */       }
/*      */ 
/* 1194 */       String[] params = { obpSchemaElemType.getName().toString() };
/* 1195 */       throw new MXApplicationException("iface", "recursion", params);
/*      */     }
/*      */ 
/* 1198 */     if (logger.isDebugEnabled())
/*      */     {
/* 1200 */       logger.debug("parseSchema For element " + schemaElem.getName() + " obpSchemaElemType = " + obpSchemaElemType);
/*      */     }
/* 1202 */     if (obpSchemaElemType.isSimpleType())
/*      */     {
/* 1204 */       if (logger.isDebugEnabled())
/*      */       {
/* 1206 */         logger.debug("parseSchema simple type");
/*      */       }
/* 1208 */       WSIOAttribute attr = simpleFieldToWSIOAttribute(parentWSIO, null, schemaElem);
/*      */ 
/* 1210 */       if (!(isWSIO(schemaElem)))
/*      */       {
/* 1212 */         if (logger.isDebugEnabled())
/*      */         {
/* 1214 */           logger.debug("parseSchema simple type not WSIO");
/*      */         }
/* 1216 */         parentWSIO.addWSIOAttribute(attr);
/*      */       }
/*      */       else
/*      */       {
/* 1220 */         if (logger.isDebugEnabled())
/*      */         {
/* 1222 */           logger.debug("parseSchema simple type is WSIO");
/*      */         }
/* 1224 */         WSIO childWSIO = new WSIO();
/* 1225 */         parentWSIO.addWSIOChild(childWSIO);
/* 1226 */         setWSIOMetaData(parentWSIO, childWSIO, schemaElem);
/* 1227 */         attr.setXmlLocation(null);
/* 1228 */         childWSIO.addWSIOAttribute(attr);
/*      */       }/*      */     }/*      */     else/*      */     {
/*      */       WSIO childWSIO;
/* 1231 */       if ((obpSchemaElemType.getContentType() == 3) || (obpSchemaElemType.getContentType() == 4))

/*      */       {
/* 1234 */         if (logger.isDebugEnabled())
/*      */         {
/* 1236 */           logger.debug("CT-CC Element with Element/mixed content");
/*      */         }
/*      */ 
/* 1239 */         childWSIO = new WSIO();
/* 1240 */         setWSIOMetaData(parentWSIO, childWSIO, schemaElem);
/*      */ 
/* 1242 */         if (parentWSIO != null)
/*      */         {
/* 1244 */           parentWSIO.addWSIOChild(childWSIO);
/*      */         }
/* 1246 */         SchemaParticle sp = obpSchemaElemType.getContentModel();
/* 1247 */         if (logger.isDebugEnabled())
/*      */         {
/* 1249 */           logger.debug("sp maxoccurs=" + sp.getMaxOccurs());
/*      */         }
/* 1251 */         List attrList = listAttributes(obpSchemaElemType);
/* 1252 */         List elemlist = new ArrayList();
/* 1253 */         if (attrList != null)
/*      */         {
/* 1255 */           if (logger.isDebugEnabled())
/*      */           {
/* 1257 */             logger.debug("attr list size ===" + attrList.size());
/*      */           }
/* 1259 */           for (OBPSchemaAttribute attr : attrList)
/*      */           {
/* 1261 */             if (logger.isDebugEnabled())
/*      */             {
/* 1263 */               logger.debug("attr name=" + attr.getName());
/*      */             }
/* 1265 */             if (!(isIgnoreAttribute(attr)))
/*      */             {
/* 1267 */               WSIOAttribute wsioAttr = simpleFieldToWSIOAttribute(childWSIO, null, attr);
/* 1268 */               childWSIO.addWSIOAttribute(wsioAttr);
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1274 */         listElements(elemlist, sp, null);
/* 1275 */         if (logger.isDebugEnabled())
/*      */         {
/* 1277 */           logger.debug("after recursion of SchemaParticles with list size " + elemlist.size());
/*      */         }
/*      */ 
/* 1280 */         if (obpSchemaElemType.getContentType() == 4)
/*      */         {
/* 1282 */           childWSIO.createFillerAttribute(getNextId(), true);
/*      */         }
/*      */ 
/* 1285 */         for (OBPSchemaElement elem : elemlist)
/*      */         {
/* 1287 */           if (logger.isDebugEnabled())
/*      */           {
/* 1289 */             logger.debug("looping the particle list " + elem.getName());
/*      */           }
/* 1291 */           parseSchema(childWSIO, elem);
/*      */         }/*      */       }/*      */       else/*      */       {
/*      */         WSIO childWSIO;
/*      */         WSIOAttribute wsioParentAttr;
/* 1295 */         if ((obpSchemaElemType.getContentType() == 2) || (obpSchemaElemType.getContentType() == 1))

/*      */         {
/* 1298 */           logger.debug("CT-SC Element with simple content");
/*      */           WSIOAttribute wsioParentAttr;/* 1299 */           if (!(isWSIO(schemaElem)))
/*      */           {
/* 1301 */             wsioParentAttr = simpleFieldToWSIOAttribute(parentWSIO, null, schemaElem);
/* 1302 */             parentWSIO.addWSIOAttribute(wsioParentAttr);
/*      */ 
/* 1304 */             List attrList = listAttributes(obpSchemaElemType);
/* 1305 */             for (OBPSchemaAttribute attr : attrList)
/*      */             {
/* 1307 */               if (!(isIgnoreAttribute(attr)))
/*      */               {
/* 1309 */                 WSIOAttribute wsioAttr = new WSIOAttribute();
/* 1310 */                 if (wsioParentAttr != null)
/*      */                 {
/* 1312 */                   wsioAttr.setContainerAttributeName(wsioParentAttr.getName());
/* 1313 */                   wsioAttr.setContainerAttrId(wsioParentAttr.getId());
/*      */                 }
/*      */ 
/* 1316 */                 wsioAttr = simpleFieldToWSIOAttribute(parentWSIO, wsioAttr, attr);
/*      */ 
/* 1318 */                 parentWSIO.addWSIOAttribute(wsioAttr);
/*      */               }
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1324 */             childWSIO = new WSIO();
/* 1325 */             parentWSIO.addWSIOChild(childWSIO);
/* 1326 */             setWSIOMetaData(parentWSIO, childWSIO, schemaElem);
/* 1327 */             wsioParentAttr = null;
/* 1328 */             if (obpSchemaElemType.getContentType() == 2)
/*      */             {
/* 1330 */               wsioParentAttr = simpleFieldToWSIOAttribute(childWSIO, null, schemaElem);
/* 1331 */               wsioParentAttr.setXmlLocation(null);
/* 1332 */               childWSIO.addWSIOAttribute(wsioParentAttr);
/*      */             }
/*      */ 
/* 1335 */             List attrList = listAttributes(obpSchemaElemType);
/* 1336 */             for (OBPSchemaAttribute attr : attrList)
/*      */             {
/* 1338 */               if (!(isIgnoreAttribute(attr)))
/*      */               {
/* 1340 */                 WSIOAttribute wsioAttr = new WSIOAttribute();
/* 1341 */                 if (wsioParentAttr != null)
/*      */                 {
/* 1343 */                   wsioAttr.setContainerAttributeName(wsioParentAttr.getName());
/*      */                 }
/*      */ 
/* 1346 */                 wsioAttr = simpleFieldToWSIOAttribute(childWSIO, null, attr);
/* 1347 */                 childWSIO.addWSIOAttribute(wsioAttr);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1354 */           logger.info("unknown type");
/*      */         }
/*      */       }
/*      */     }
/*      */   }


/*      */   protected boolean isWSIO(OBPSchemaElement schemaElem)
/*      */   {
/* 1363 */     return ((schemaElem.getMaxOccurs() == null) || (schemaElem.getMaxOccurs().intValue() > 1) || ((schemaElem.hasCombinedMaxOccurs()) && (schemaElem.getCombinedMaxOccurs() > 1)));
/*      */   }






/*      */   protected void setWSIOMetaData(WSIO parentWSIO, WSIO wsio, OBPSchemaElement schemaElem)
/*      */   {
/* 1373 */     wsio.setName(getWSIOName(schemaElem));
/* 1374 */     wsio.setId(getNextId());
/* 1375 */     QName typeName = schemaElem.getType().getName();
/* 1376 */     wsio.setSchemaType(typeName);
/* 1377 */     logger.info("Actual maxOccurs === " + schemaElem.getMaxOccurs() + " com maxOccurs = " + schemaElem.getCombinedMaxOccurs());
/* 1378 */     if (!(schemaElem.isRoot()))
/*      */     {
/* 1380 */       wsio.setMaxOccurs(schemaElem.getCombinedMaxOccurs());
/* 1381 */       wsio.setMinOccurs(schemaElem.getCombinedMinOccurs());
/*      */     }
/* 1383 */     wsio.setTitle(schemaElem.getName().getLocalPart());
/* 1384 */     String nsUri = schemaElem.getName().getNamespaceURI();
/* 1385 */     String nsPrefix = getPrefix(nsUri);
/* 1386 */     String xmlLocation = (nsPrefix != null) ? nsPrefix + ":" + schemaElem.getName().getLocalPart() : schemaElem.getName().getLocalPart();
/*      */ 
/* 1388 */     if (parentWSIO != null)
/*      */     {
/* 1390 */       xmlLocation = parentWSIO.getXmlLocation() + "/" + xmlLocation;
/* 1391 */       wsio.setXmlLocation(xmlLocation);
/*      */     }
/*      */     else
/*      */     {
/* 1395 */       wsio.setXmlLocation(xmlLocation);
/*      */     }
/*      */   }



/*      */   protected boolean isIgnoreAttribute(OBPSchemaAttribute attr)
/*      */   {
/* 1403 */     if (attr.getUse() == 3) return false;
/* 1404 */     return this.ignoreAttributes;
/*      */   }

/*      */   protected WSIO optimizeWSIO(WSIO rootWSIO)
/*      */   {
/* 1409 */     if (rootWSIO.isMarkedForDelete())
/*      */     {
/* 1411 */       return null;
/*      */     }
/* 1413 */     removeDeletedNodes(rootWSIO);
/* 1414 */     rootWSIO = optimizeUsingRule1(rootWSIO);
/* 1415 */     rootWSIO = optimizeUsingRule2(rootWSIO);
/* 1416 */     return rootWSIO;
/*      */   }

/*      */   protected void removeDeletedNodes(WSIO wsio)
/*      */   {
/* 1421 */     Iterator attrItr = wsio.getWSIOAttributes().iterator();
/* 1422 */     while (attrItr.hasNext())
/*      */     {
/* 1424 */       WSIOAttribute attr = (WSIOAttribute)attrItr.next();
/* 1425 */       if (attr.isMarkedForDelete())
/*      */       {
/* 1427 */         attrItr.remove();
/*      */       }
/*      */     }
/*      */ 
/* 1431 */     Iterator wsioItr = wsio.getWSIOChildren().iterator();
/* 1432 */     while (wsioItr.hasNext())
/*      */     {
/* 1434 */       WSIO wsioChild = (WSIO)wsioItr.next();
/* 1435 */       if (wsioChild.isMarkedForDelete())
/*      */       {
/* 1437 */         wsioItr.remove();
/*      */       }
/*      */       else
/*      */       {
/* 1441 */         removeDeletedNodes(wsioChild);
/*      */       }
/*      */     }
/*      */   }

/*      */   protected void mergeChildrenToParent(WSIO wsio)
/*      */   {
/* 1448 */     List wsioAttributes = wsio.getWSIOAttributes();
/* 1449 */     WSIO parent = wsio.getParent();
/* 1450 */     List wsioChildren = wsio.getWSIOChildren();
/* 1451 */     String wsioTitle = wsio.getTitle();
/* 1452 */     if (wsioAttributes != null)
/*      */     {
/* 1454 */       for (WSIOAttribute wsioAttribute : wsioAttributes)
/*      */       {
/* 1456 */         if (parent.getWSIOAttributesMap().containsKey(wsioAttribute.getName()))
/*      */         {
/* 1458 */           generateWSIOAttributeName(parent, wsioAttribute, false);

/*      */         }
/*      */ 
/* 1462 */         String title = wsioAttribute.getTitle();
/* 1463 */         wsioAttribute.setTitle(wsioTitle + "/" + title);
/* 1464 */         parent.addWSIOAttribute(wsioAttribute);
/*      */       }
/*      */     }
/* 1467 */     for (WSIO childWSIO : wsioChildren)
/*      */     {
/* 1469 */       String title = childWSIO.getTitle();
/* 1470 */       childWSIO.setTitle(wsioTitle + "/" + title);
/* 1471 */       parent.addWSIOChild(childWSIO);
/*      */     }
/*      */   }



/*      */   protected WSIO optimizeUsingRule1(WSIO rootWSIO)
/*      */   {
/* 1479 */     List list = rootWSIO.getWSIOChildren();
/* 1480 */     logger.info("root of recursion = " + rootWSIO.getName() + " xml location = " + rootWSIO.getXmlLocation());
/*      */     int i;/* 1481 */     if (list != null)
/*      */     {
/* 1483 */       for (i = 0; i < list.size(); )
/*      */       {
/* 1485 */         WSIO childWSIO = (WSIO)list.get(i);
/* 1486 */         logger.info("childWSIO = " + childWSIO.getName() + " xml location = " + childWSIO.getXmlLocation());
/* 1487 */         if (childWSIO.getMaxOccurs() == 1)

/*      */         {
/* 1490 */           mergeChildrenToParent(childWSIO);
/* 1491 */           list.remove(childWSIO);
/* 1492 */           logger.info("removed childWSIO = " + childWSIO.getName());

/*      */         }
/*      */         else
/*      */         {
/* 1497 */           optimizeUsingRule1(childWSIO);
/* 1498 */           ++i;
/*      */         }
/*      */       }
/*      */     }
/* 1502 */     return rootWSIO;
/*      */   }

/*      */   protected WSIO optimizeUsingRule2(WSIO rootWSIO)
/*      */   {
/* 1507 */     if (!(rootWSIO.hasAttributes()))
/*      */     {
/* 1509 */       List childrenWSIOList = rootWSIO.getWSIOChildren();
/* 1510 */       if ((childrenWSIOList != null) && (childrenWSIOList.size() == 1))
/*      */       {
/* 1512 */         ((WSIO)childrenWSIOList.get(0)).setParent(null);
/* 1513 */         rootWSIO = (WSIO)childrenWSIOList.get(0);
/*      */       }
/*      */     }
/* 1516 */     return rootWSIO;
/*      */   }


/*      */   protected void parseFacets(SchemaType type, WSIOAttribute attr)
/*      */   {
/* 1522 */     System.out.println(attr.getName() + " in parseFacets witth attr type =" + attr.getType());
/* 1523 */     if (attr.getType().equals("String"))
/*      */     {
/* 1525 */       XmlAnySimpleType facet = type.getFacet(2);
/* 1526 */       if (facet != null)
/*      */       {
/* 1528 */         if (logger.isDebugEnabled())
/*      */         {
/* 1530 */           logger.debug("parseFacets max length=" + facet.getStringValue());
/*      */         }
/* 1532 */         attr.setMaxLength(Integer.parseInt(facet.getStringValue()));
/*      */       }
/* 1534 */       facet = type.getFacet(1);
/* 1535 */       if (facet != null)
/*      */       {
/* 1537 */         if (logger.isDebugEnabled())
/*      */         {
/* 1539 */           logger.debug("parseFacets min length=" + facet.getStringValue());
/*      */         }
/* 1541 */         attr.setMinLength(Integer.parseInt(facet.getStringValue()));
/*      */       }
/* 1543 */       facet = type.getFacet(0);
/* 1544 */       if (facet != null)
/*      */       {
/* 1546 */         if (logger.isDebugEnabled())
/*      */         {
/* 1548 */           logger.debug("parseFacets length=" + facet.getStringValue());
/*      */         }
/* 1550 */         attr.setLength(Integer.parseInt(facet.getStringValue()));

/*      */       }
/*      */ 
/* 1554 */       if (type.hasPatternFacet())
/*      */       {
/* 1556 */         String[] patterns = type.getPatterns();
/* 1557 */         logger.debug("parseFacets pattern=" + patterns);
/* 1558 */         attr.setPatterns(patterns);
/*      */       }
/*      */     }
/* 1561 */     else if ((attr.getType().equals("BigDecimal")) || (attr.getType().equals("BigInteger")))
/*      */     {
/* 1563 */       XmlAnySimpleType facet = type.getFacet(7);
/* 1564 */       System.out.println("FACET_TOTAL_DIGITS in parseFacets =" + facet);
/* 1565 */       if (facet != null)
/*      */       {
/* 1567 */         if (logger.isDebugEnabled())
/*      */         {
/* 1569 */           logger.debug("parseFacets total digits=" + facet.getStringValue());
/*      */         }
/* 1571 */         attr.setTotalDigits(Integer.parseInt(facet.getStringValue()));
/*      */       }
/* 1573 */       facet = type.getFacet(8);
/* 1574 */       if (facet != null)
/*      */       {
/* 1576 */         if (logger.isDebugEnabled())
/*      */         {
/* 1578 */           logger.debug("parseFacets fraction digits=" + facet.getStringValue());
/*      */         }
/* 1580 */         attr.setFractionDigits(Integer.parseInt(facet.getStringValue()));
/*      */       }
/*      */     }
/*      */ 
/* 1584 */     if ((attr.getType().equals("BigDecimal")) || (attr.getType().equals("BigInteger")) || (attr.getType().equals("Double")) || (attr.getType().equals("Float")) || (attr.getType().equals("Integer")) || (attr.getType().equals("Long")) || (attr.getType().equals("Short")))



/*      */     {
/* 1589 */       XmlAnySimpleType facet = type.getFacet(6);
/* 1590 */       if (facet != null)
/*      */       {
/* 1592 */         if (logger.isDebugEnabled())
/*      */         {
/* 1594 */           logger.debug("parseFacets FACET_MAX_EXCLUSIVE=" + facet.getStringValue());
/*      */         }
/* 1596 */         attr.setMaxExclusive(facet.getStringValue());
/*      */       }
/* 1598 */       facet = type.getFacet(3);
/* 1599 */       if (facet != null)
/*      */       {
/* 1601 */         if (logger.isDebugEnabled())
/*      */         {
/* 1603 */           logger.debug("parseFacets FACET_MIN_EXCLUSIVE=" + facet.getStringValue());
/*      */         }
/* 1605 */         attr.setMinExclusive(facet.getStringValue());
/*      */       }
/* 1607 */       facet = type.getFacet(5);
/* 1608 */       if (facet != null)
/*      */       {
/* 1610 */         if (logger.isDebugEnabled())
/*      */         {
/* 1612 */           logger.debug("parseFacets FACET_MAX_INCLUSIVE=" + facet.getStringValue());
/*      */         }
/* 1614 */         attr.setMaxInclusive(facet.getStringValue());
/*      */       }
/* 1616 */       facet = type.getFacet(4);
/* 1617 */       if (facet != null)
/*      */       {
/* 1619 */         if (logger.isDebugEnabled())
/*      */         {
/* 1621 */           logger.debug("parseFacets FACET_MIN_INCLUSIVE=" + facet.getStringValue());
/*      */         }
/* 1623 */         attr.setMinInclusive(facet.getStringValue());
/*      */       }
/*      */     }
/*      */ 
/* 1627 */     if (type.getEnumerationValues() == null)
/*      */       return;
/* 1629 */     XmlAnySimpleType[] se = type.getEnumerationValues();
/* 1630 */     if ((se == null) || (se.length <= 0))
/*      */       return;
/* 1632 */     List enumValues = new ArrayList(se.length);
/* 1633 */     for (XmlAnySimpleType seEntry : se)
/*      */     {
/* 1635 */       enumValues.add(seEntry.getStringValue());
/*      */     }
/* 1637 */     attr.setEnumList(enumValues);
/* 1638 */     attr.setEnumType(type.getName());
/*      */   }



/*      */   private String getPrefix(String nsUri)
/*      */   {
/* 1645 */     if ((nsUri == null) || (nsUri.trim().length() == 0)) return null;
/* 1646 */     if (this.nsContext.containsKey(nsUri)) return ((String)this.nsContext.get(nsUri));
/* 1647 */     String prefix = "ns" + this.prefixCnt;
/* 1648 */     this.prefixCnt += 1;
/* 1649 */     this.nsContext.put(nsUri, prefix);
/* 1650 */     return prefix;
/*      */   }

/*      */   protected String getWSIOAttributeType(SchemaType st)
/*      */   {
/* 1655 */     st = getBuiltinType(st);
/* 1656 */     logger.debug("final simple type ===" + st);
/*      */ 
/* 1658 */     String wsioAttrType = (String)wsioAttrTypes.get(Integer.valueOf(st.getBuiltinTypeCode()));
/* 1659 */     if (wsioAttrType != null)
/*      */     {
/* 1661 */       return wsioAttrType;
/*      */     }
/* 1663 */     return "String";
/*      */   }







/*      */   protected String getWSIOName(OBPSchemaElement elem)
/*      */   {
/* 1674 */     String wsioName = this.interactionName + this.wsioCount;
/* 1675 */     this.wsioCount += 1;
/* 1676 */     return wsioName;
/*      */   }

/*      */   public byte[] getSampleRequestXML()
/*      */   {
/* 1681 */     return this.sampleReqXml;
/*      */   }

/*      */   public byte[] getSampleResponseXML()
/*      */   {
/* 1686 */     return this.sampleRespXml;
/*      */   }

/*      */   private SchemaType getBuiltinType(SchemaType type)
/*      */   {
/* 1691 */     logger.debug("simple type =" + type);
/* 1692 */     if (type.isBuiltinType()) return type;
/* 1693 */     return getBuiltinType(type.getBaseType());
/*      */   }

/*      */   private int getNextId()
/*      */   {
/* 1698 */     return (this.seedId++);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   84 */     wsioAttrTypes.put(Integer.valueOf(12), "String");
/*   85 */     wsioAttrTypes.put(Integer.valueOf(22), "BigInteger");
/*   86 */     wsioAttrTypes.put(Integer.valueOf(11), "BigDecimal");
/*   87 */     wsioAttrTypes.put(Integer.valueOf(24), "Integer");
/*   88 */     wsioAttrTypes.put(Integer.valueOf(10), "Double");
/*   89 */     wsioAttrTypes.put(Integer.valueOf(9), "Float");
/*   90 */     wsioAttrTypes.put(Integer.valueOf(23), "Long");
/*   91 */     wsioAttrTypes.put(Integer.valueOf(32), "Long");
/*   92 */     wsioAttrTypes.put(Integer.valueOf(33), "Integer");
/*   93 */     wsioAttrTypes.put(Integer.valueOf(34), "Short");
/*   94 */     wsioAttrTypes.put(Integer.valueOf(31), "BigInteger");
/*   95 */     wsioAttrTypes.put(Integer.valueOf(30), "BigInteger");
/*   96 */     wsioAttrTypes.put(Integer.valueOf(27), "BigInteger");
/*   97 */     wsioAttrTypes.put(Integer.valueOf(28), "BigInteger");
/*   98 */     wsioAttrTypes.put(Integer.valueOf(29), "BigInteger");
/*   99 */     wsioAttrTypes.put(Integer.valueOf(26), "Byte");
/*  100 */     wsioAttrTypes.put(Integer.valueOf(3), "Boolean");
/*  101 */     wsioAttrTypes.put(Integer.valueOf(25), "Short");
/*  102 */     wsioAttrTypes.put(Integer.valueOf(14), "DateTime");
/*  103 */     wsioAttrTypes.put(Integer.valueOf(16), "Date");
/*  104 */     wsioAttrTypes.put(Integer.valueOf(15), "Time");
/*  105 */     wsioAttrTypes.put(Integer.valueOf(13), "String");
/*  106 */     wsioAttrTypes.put(Integer.valueOf(36), "String");
/*  107 */     wsioAttrTypes.put(Integer.valueOf(45), "String");
/*  108 */     wsioAttrTypes.put(Integer.valueOf(4), "Base64Bytes");
/*  109 */     wsioAttrTypes.put(Integer.valueOf(5), "HexBytes");
/*      */ 
/*  112 */     obpNS = Namespace.getNamespace("http://www.ibm.com/obp10");
/*      */   }
/*      */ }
