/*     */ package com.ibm.tivoli.maximo.interaction.obp;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.xml.namespace.QName;
/*     */ import psdi.util.MXApplicationException;/*     */ import psdi.util.MXException;/*     */ 
/*     */ public class WSIOAttribute extends OBPNode
/*     */ {
/*     */   public static final String TYPE_DATETIME = "DateTime";
/*     */   public static final String TYPE_DATE = "Date";
/*     */   public static final String TYPE_TIME = "Time";
/*     */   public static final String TYPE_STRING = "String";
/*     */   public static final String TYPE_BIGINT = "BigInteger";
/*     */   public static final String TYPE_BIGDEC = "BigDecimal";
/*     */   public static final String TYPE_INTEGER = "Integer";
/*     */   public static final String TYPE_SHORT = "Short";
/*     */   public static final String TYPE_LONG = "Long";
/*     */   public static final String TYPE_B64_BYTES = "Base64Bytes";
/*     */   public static final String TYPE_HEX_BYTES = "HexBytes";
/*     */   public static final String TYPE_BYTE = "Byte";
/*     */   public static final String TYPE_DOUBLE = "Double";
/*     */   public static final String TYPE_FLOAT = "Float";
/*     */   public static final String TYPE_BOOLEAN = "Boolean";
/*     */   private boolean nillable;
/*     */   private int length;
/*     */   private int maxLength;
/*     */   private int minLength;
/*     */   private int totalDigits;
/*     */   private int fractionDigits;
/*     */   private String maxExclusive;
/*     */   private String minExclusive;
/*     */   private String minInclusive;
/*     */   private String maxInclusive;
/*     */   private String[] patterns;
/*     */   private String type;
/*     */   private String defaultValue;
/*     */   private boolean readOnly;
/*     */   private List<String> enumList;
/*     */   private String containerAttrName;
/*     */   private int containerAttrId;
/*     */   private boolean mapToParent;
/*     */   private String parentWSIOName;
/*     */   private QName enumType;
/*     */ 
/*     */   public WSIOAttribute()
/*     */   {
/*  51 */     this.nillable = false;
/*  52 */     this.length = 0;
/*  53 */     this.maxLength = -1;
/*  54 */     this.minLength = 0;
/*  55 */     this.totalDigits = -1;
/*  56 */     this.fractionDigits = -1;
/*  57 */     this.maxExclusive = null;
/*  58 */     this.minExclusive = null;
/*  59 */     this.minInclusive = null;
/*  60 */     this.maxInclusive = null;
/*     */ 
/*  62 */     this.type = "String";
/*     */ 
/*  64 */     this.readOnly = false;
/*  65 */     this.enumList = new ArrayList();
/*     */ 
/*  67 */     this.containerAttrId = -1;
/*     */ 
/*  69 */     this.mapToParent = true;
/*     */ 
/*  71 */     this.parentWSIOName = null;
/*     */   }




/*     */   public int getFractionDigits()
/*     */   {
/*  79 */     return this.fractionDigits;
/*     */   }



/*     */   public void setFractionDigits(int fractionDigits)
/*     */   {
/*  86 */     this.fractionDigits = fractionDigits;
/*     */   }



/*     */   public int getLength()
/*     */   {
/*  93 */     return this.length;
/*     */   }



/*     */   public void setLength(int length)
/*     */   {
/* 100 */     this.length = length;
/*     */   }



/*     */   public int getMaxLength()
/*     */   {
/* 107 */     return this.maxLength;
/*     */   }



/*     */   public void setMaxLength(int maxLength)
/*     */   {
/* 114 */     this.maxLength = maxLength;
/*     */   }



/*     */   public int getMinLength()
/*     */   {
/* 121 */     return this.minLength;
/*     */   }



/*     */   public void setMinLength(int minLength)
/*     */   {
/* 128 */     this.minLength = minLength;
/*     */   }



/*     */   public String getName()
/*     */   {
/* 135 */     return this.name;
/*     */   }



/*     */   public void setName(String name)
/*     */   {
/* 142 */     this.name = name;
/* 143 */     if (this.title != null)
/*     */       return;
/* 145 */     this.title = name;
/*     */   }




/*     */   public boolean isReadOnly()
/*     */   {
/* 153 */     return this.readOnly;
/*     */   }




/*     */   public void setReadOnly(boolean readOnly)
/*     */   {
/* 161 */     this.readOnly = readOnly;
/*     */   }




/*     */   public int getTotalDigits()
/*     */   {
/* 169 */     return this.totalDigits;
/*     */   }




/*     */   public void setTotalDigits(int totalDigits)
/*     */   {
/* 177 */     this.totalDigits = totalDigits;
/*     */   }




/*     */   public String getType()
/*     */   {
/* 185 */     return this.type;
/*     */   }




/*     */   public void setType(String type)
/*     */   {
/* 193 */     this.type = type;
/*     */   }

/*     */   public boolean isGenerated()
/*     */   {
/* 198 */     return (this.xmlLocation == null);
/*     */   }




/*     */   public String getDefaultValue()
/*     */   {
/* 206 */     return this.defaultValue;
/*     */   }




/*     */   public void setDefaultValue(String defaultValue)
/*     */   {
/* 214 */     this.defaultValue = defaultValue;
/*     */   }




/*     */   public List<String> getEnumList()
/*     */   {
/* 222 */     return this.enumList;
/*     */   }




/*     */   public void setEnumList(List<String> enumList)
/*     */   {
/* 230 */     this.enumList = enumList;
/*     */   }

/*     */   public boolean hasDefaultValue()
/*     */   {
/* 235 */     return ((this.defaultValue != null) && (this.defaultValue.trim().length() > 0));
/*     */   }




/*     */   public String[] getPatterns()
/*     */   {
/* 243 */     return this.patterns;
/*     */   }




/*     */   public void setPatterns(String[] patterns)
/*     */   {
/* 251 */     this.patterns = patterns;
/*     */   }

/*     */   public void setContainerAttributeName(String parentAttrName)
/*     */   {
/* 256 */     this.containerAttrName = parentAttrName;
/*     */   }

/*     */   public String getContainerAttributeName()
/*     */   {
/* 261 */     return this.containerAttrName;
/*     */   }




/*     */   public boolean isMapToParent()
/*     */   {
/* 269 */     return this.mapToParent;
/*     */   }




/*     */   public void setMapToParent(boolean mapToParent)
/*     */   {
/* 277 */     this.mapToParent = mapToParent;
/*     */   }

/*     */   public void validate(Object value)
/*     */     throws MXException
/*     */   {
/* 283 */     if (value == null) return;
/* 284 */     if (this.type.equals("String"))
/*     */     {
/* 286 */       String sValue = (String)value;
/*     */ 
/* 288 */       if (this.patterns != null)
/*     */       {
/* 290 */         boolean match = false;
/* 291 */         for (String pattern : this.patterns)
/*     */         {
/* 293 */           Pattern p = Pattern.compile(pattern);
/* 294 */           Matcher m = p.matcher(sValue);
/* 295 */           if (!(m.matches()))
/*     */             continue;
/* 297 */           match = true;
/* 298 */           break;
/*     */         }
/*     */ 
/* 301 */         if (!(match))
/*     */         {
/* 303 */           String[] params = { this.name, sValue };
/* 304 */           throw new MXApplicationException("iface", "pattern_invalidval", params);
/*     */         }
/*     */       }
/*     */ 
/* 308 */       if ((this.minLength > 0) && (sValue.length() < this.minLength))
/*     */       {
/* 310 */         String[] params = { this.name, sValue, "" + this.minLength };
/* 311 */         throw new MXApplicationException("iface", "minlength_invalidval", params);
/*     */       }
/*     */ 
/* 314 */       if ((this.length > 0) && (sValue.length() != this.length))
/*     */       {
/* 316 */         String[] params = { this.name, sValue, "" + this.length };
/* 317 */         throw new MXApplicationException("iface", "length_invalidval", params);
/*     */       }
/*     */     }
/* 320 */     else if ((this.type.equals("Integer")) || (this.type.equals("Long")) || (this.type.equals("Short")) || (this.type.equals("Float")) || (this.type.equals("Double")) || (this.type.equals("Byte")))


/*     */     {
/* 324 */       Double d = Double.valueOf(Double.parseDouble(value.toString()));
/* 325 */       if (this.maxExclusive != null)
/*     */       {
/* 327 */         Double dmaxExclusive = Double.valueOf(Double.parseDouble(this.maxExclusive));
/* 328 */         if (dmaxExclusive.compareTo(d) <= 0)
/*     */         {
/* 330 */           String[] params = { this.name, d.doubleValue() + "", this.maxExclusive };
/* 331 */           throw new MXApplicationException("iface", "maxexclusiveerr", params);
/*     */         }
/*     */       }
/*     */ 
/* 335 */       if (this.minExclusive != null)
/*     */       {
/* 337 */         Double dminExclusive = Double.valueOf(Double.parseDouble(this.minExclusive));
/* 338 */         if (dminExclusive.compareTo(d) >= 0)
/*     */         {
/* 340 */           String[] params = { this.name, d.doubleValue() + "", this.minExclusive };
/* 341 */           throw new MXApplicationException("iface", "minexclusiveerr", params);
/*     */         }
/*     */       }
/* 344 */       if (this.maxInclusive != null)
/*     */       {
/* 346 */         Double dmaxInclusive = Double.valueOf(Double.parseDouble(this.maxInclusive));
/* 347 */         if (dmaxInclusive.compareTo(d) < 0)
/*     */         {
/* 349 */           String[] params = { this.name, d.doubleValue() + "", this.maxInclusive };
/* 350 */           throw new MXApplicationException("iface", "maxinclusiveerr", params);
/*     */         }
/*     */       }
/* 353 */       if (this.minInclusive != null)
/*     */       {
/* 355 */         Double dminInclusive = Double.valueOf(Double.parseDouble(this.minInclusive));
/* 356 */         if (dminInclusive.compareTo(d) > 0)
/*     */         {
/* 358 */           String[] params = { this.name, d.toString(), this.minInclusive };
/* 359 */           throw new MXApplicationException("iface", "mininclusiveerr", params);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/* 364 */     else if (this.type.equals("BigInteger"))
/*     */     {
/* 366 */       String sValue = (String)value;
/* 367 */       BigInteger bigInt = null;

/*     */       try
/*     */       {
/* 371 */         bigInt = new BigInteger((String)value);
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/* 375 */         String[] params = { this.name, sValue };
/*     */ 
/* 377 */         throw new MXApplicationException("iface", "biginterror", params);
/*     */       }
/*     */ 
/* 380 */       if (this.maxExclusive != null)
/*     */       {
/* 382 */         BigInteger bmaxExclusive = new BigInteger(this.maxExclusive);
/* 383 */         if (bmaxExclusive.compareTo(bigInt) <= 0)
/*     */         {
/* 385 */           String[] params = { this.name, sValue, this.maxExclusive };
/* 386 */           throw new MXApplicationException("iface", "maxexclusiveerr", params);
/*     */         }
/*     */       }
/*     */ 
/* 390 */       if (this.minExclusive != null)
/*     */       {
/* 392 */         BigInteger bminExclusive = new BigInteger(this.minExclusive);
/* 393 */         if (bminExclusive.compareTo(bigInt) >= 0)
/*     */         {
/* 395 */           String[] params = { this.name, sValue, this.minExclusive };
/* 396 */           throw new MXApplicationException("iface", "minexclusiveerr", params);
/*     */         }
/*     */       }
/* 399 */       if (this.maxInclusive != null)
/*     */       {
/* 401 */         BigInteger bmaxInclusive = new BigInteger(this.maxInclusive);
/* 402 */         if (bmaxInclusive.compareTo(bigInt) < 0)
/*     */         {
/* 404 */           String[] params = { this.name, sValue, this.maxInclusive };
/* 405 */           throw new MXApplicationException("iface", "maxinclusiveerr", params);
/*     */         }
/*     */       }
/* 408 */       if (this.minInclusive != null)
/*     */       {
/* 410 */         BigInteger bminInclusive = new BigInteger(this.minInclusive);
/* 411 */         if (bminInclusive.compareTo(bigInt) > 0)
/*     */         {
/* 413 */           String[] params = { this.name, sValue, this.minInclusive };
/* 414 */           throw new MXApplicationException("iface", "mininclusiveerr", params);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 420 */       if ((!(this.type.equals("BigDecimal"))) || (!(value instanceof String)))
/*     */         return;
/* 422 */       String sValue = (String)value;
/* 423 */       BigDecimal bigDec = null;
/*     */       try
/*     */       {
/* 426 */         bigDec = new BigDecimal((String)value);
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/* 430 */         String[] params = { this.name, (String)value };
/*     */ 
/* 432 */         throw new MXApplicationException("iface", "bigdecerror", params);
/*     */       }
/*     */ 
/* 435 */       if (this.maxExclusive != null)
/*     */       {
/* 437 */         BigDecimal bmaxExclusive = new BigDecimal(this.maxExclusive);
/* 438 */         if (bmaxExclusive.compareTo(bigDec) <= 0)
/*     */         {
/* 440 */           String[] params = { this.name, sValue, this.maxExclusive };
/* 441 */           throw new MXApplicationException("iface", "maxexclusiveerr", params);
/*     */         }
/*     */       }
/*     */ 
/* 445 */       if (this.minExclusive != null)
/*     */       {
/* 447 */         BigDecimal bminExclusive = new BigDecimal(this.minExclusive);
/* 448 */         if (bminExclusive.compareTo(bigDec) >= 0)
/*     */         {
/* 450 */           String[] params = { this.name, sValue, this.minExclusive };
/* 451 */           throw new MXApplicationException("iface", "minexclusiveerr", params);
/*     */         }
/*     */       }
/* 454 */       if (this.maxInclusive != null)
/*     */       {
/* 456 */         BigDecimal bmaxInclusive = new BigDecimal(this.maxInclusive);
/* 457 */         if (bmaxInclusive.compareTo(bigDec) < 0)
/*     */         {
/* 459 */           String[] params = { this.name, sValue, this.maxInclusive };
/* 460 */           throw new MXApplicationException("iface", "maxinclusiveerr", params);
/*     */         }
/*     */       }
/* 463 */       if (this.minInclusive == null)
/*     */         return;
/* 465 */       BigDecimal bminInclusive = new BigDecimal(this.minInclusive);
/* 466 */       if (bminInclusive.compareTo(bigDec) <= 0)
/*     */         return;
/* 468 */       String[] params = { this.name, sValue, this.minInclusive };
/* 469 */       throw new MXApplicationException("iface", "mininclusiveerr", params);
/*     */     }
/*     */   }








/*     */   public int getContainerAttrId()
/*     */   {
/* 482 */     return this.containerAttrId;
/*     */   }




/*     */   public void setContainerAttrId(int parentAttrId)
/*     */   {
/* 490 */     this.containerAttrId = parentAttrId;
/*     */   }

/*     */   public void setMaxExclusive(String maxExclusive)
/*     */   {
/* 495 */     this.maxExclusive = maxExclusive;
/*     */   }




/*     */   public String getMinExclusive()
/*     */   {
/* 503 */     return this.minExclusive;
/*     */   }




/*     */   public void setMinExclusive(String minExclusive)
/*     */   {
/* 511 */     this.minExclusive = minExclusive;
/*     */   }




/*     */   public String getMinInclusive()
/*     */   {
/* 519 */     return this.minInclusive;
/*     */   }




/*     */   public void setMinInclusive(String minInclusive)
/*     */   {
/* 527 */     this.minInclusive = minInclusive;
/*     */   }




/*     */   public String getMaxInclusive()
/*     */   {
/* 535 */     return this.maxInclusive;
/*     */   }




/*     */   public void setMaxInclusive(String maxInclusive)
/*     */   {
/* 543 */     this.maxInclusive = maxInclusive;
/*     */   }




/*     */   public String getMaxExclusive()
/*     */   {
/* 551 */     return this.maxExclusive;
/*     */   }




/*     */   public boolean isXmlAttribute()
/*     */   {
/* 559 */     return ((this.xmlLocation != null) && (this.xmlLocation.indexOf(64) >= 0));
/*     */   }

/*     */   public boolean isNillable()
/*     */   {
/* 564 */     return this.nillable;
/*     */   }

/*     */   public void setNillable(boolean nillable)
/*     */   {
/* 569 */     this.nillable = nillable;
/*     */   }



/*     */   public String getParentWSIOName()
/*     */   {
/* 576 */     return this.parentWSIOName;
/*     */   }



/*     */   public void setParentWSIOName(String parentWSIOName)
/*     */   {
/* 583 */     this.parentWSIOName = parentWSIOName;
/*     */   }

/*     */   public void setEnumType(QName type)
/*     */   {
/* 588 */     this.enumType = type;
/*     */   }

/*     */   public QName getEnumType()
/*     */   {
/* 593 */     return this.enumType;
/*     */   }
/*     */ }
