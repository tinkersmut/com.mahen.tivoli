/*     */ package com.ibm.tivoli.maximo.interaction.obp;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 





/*     */ public class WSIO extends OBPNode
/*     */ {
/*     */   private int maxOccurs;
/*     */   private int minOccurs;
/*     */   private WSIO parent;
/*     */   private QName schemaType;
/*     */   private List<WSIOAttribute> wsioAttributes;
/*     */   private Map<String, WSIOAttribute> attrMap;
/*     */   private List<WSIO> wsioChildren;
/*     */ 
/*     */   public WSIO()
/*     */   {
/*  26 */     this.maxOccurs = 1;
/*  27 */     this.minOccurs = 1;




/*     */ 
/*  33 */     this.schemaType = null;
/*     */ 
/*  35 */     this.wsioAttributes = new ArrayList();
/*  36 */     this.attrMap = new HashMap();
/*     */ 
/*  38 */     this.wsioChildren = new ArrayList();
/*     */   }


/*     */   public boolean hasAttributes()
/*     */   {
/*  44 */     return ((this.wsioAttributes != null) && (this.wsioAttributes.size() > 0));
/*     */   }

/*     */   public void setSchemaType(QName schemaType)
/*     */   {
/*  49 */     this.schemaType = schemaType;
/*     */   }

/*     */   public QName getSchemaType()
/*     */   {
/*  54 */     return this.schemaType;
/*     */   }




/*     */   public List<WSIOAttribute> getWSIOAttributes()
/*     */   {
/*  62 */     return this.wsioAttributes;
/*     */   }




/*     */   public WSIOAttribute getWSIOAttribute(String attrName)
/*     */   {
/*  70 */     return ((WSIOAttribute)this.attrMap.get(attrName));
/*     */   }

/*     */   void createFillerAttribute(int id, boolean mapToParent)
/*     */   {
/*  75 */     WSIOAttribute wsioAttr = new WSIOAttribute();
/*  76 */     wsioAttr.setName(this.name);
/*  77 */     wsioAttr.setId(id);
/*  78 */     wsioAttr.setTitle(this.title);
/*  79 */     wsioAttr.setRequired(true);
/*  80 */     wsioAttr.setMapToParent(mapToParent);
/*  81 */     addWSIOAttribute(wsioAttr);
/*     */   }

/*     */   public void addWSIOAttribute(WSIOAttribute wsioAttribute)
/*     */   {
/*  86 */     this.wsioAttributes.add(wsioAttribute);
/*  87 */     wsioAttribute.setParentWSIOName(this.name);
/*  88 */     this.attrMap.put(wsioAttribute.getName(), wsioAttribute);
/*     */   }




/*     */   public List<WSIO> getWSIOChildren()
/*     */   {
/*  96 */     return this.wsioChildren;
/*     */   }

/*     */   public void addWSIOChild(WSIO wsioChild)
/*     */   {
/* 101 */     this.wsioChildren.add(wsioChild);
/* 102 */     wsioChild.setParent(this);
/*     */   }

/*     */   public void addWSIOChildren(List<WSIO> addnlWsioChildren)
/*     */   {
/* 107 */     for (WSIO childWsio : addnlWsioChildren)
/*     */     {
/* 109 */       this.wsioChildren.add(childWsio);
/* 110 */       childWsio.setParent(this);
/*     */     }
/*     */   }






/*     */   public void setWSIOChildren(List<WSIO> wsioChildren)
/*     */   {
/* 121 */     for (WSIO childWsio : wsioChildren)

/*     */     {
/* 124 */       childWsio.setParent(this);
/*     */     }
/*     */ 
/* 127 */     this.wsioChildren = wsioChildren;
/*     */   }




/*     */   public int getMaxOccurs()
/*     */   {
/* 135 */     return this.maxOccurs;
/*     */   }




/*     */   public void setMaxOccurs(int maxOccurs)
/*     */   {
/* 143 */     this.maxOccurs = maxOccurs;
/*     */   }




/*     */   public WSIO getParent()
/*     */   {
/* 151 */     return this.parent;
/*     */   }




/*     */   void setParent(WSIO parent)
/*     */   {
/* 159 */     this.parent = parent;
/*     */   }



/*     */   public int getMinOccurs()
/*     */   {
/* 166 */     return this.minOccurs;
/*     */   }



/*     */   public void setMinOccurs(int minOccurs)
/*     */   {
/* 173 */     this.minOccurs = minOccurs;
/*     */   }

/*     */   public boolean canExclude()
/*     */   {
/* 178 */     return (this.minOccurs == 0);
/*     */   }

/*     */   public boolean isWrapper()
/*     */   {
/* 183 */     return ((((this.wsioAttributes == null) || (this.wsioAttributes.size() == 0))) && (this.wsioChildren != null) && (this.wsioChildren.size() > 0));
/*     */   }

/*     */   public boolean isLeaf()
/*     */   {
/* 188 */     return ((this.wsioChildren == null) || (this.wsioChildren.size() == 0));
/*     */   }

/*     */   public boolean isRoot()
/*     */   {
/* 193 */     return (this.parent == null);
/*     */   }

/*     */   public boolean hasSingleChild()
/*     */   {
/* 198 */     return ((this.wsioChildren != null) && (this.wsioChildren.size() == 1));
/*     */   }

/*     */   public WSIO getFirstChild()
/*     */   {
/* 203 */     if ((this.wsioChildren != null) && (this.wsioChildren.size() > 0))
/*     */     {
/* 205 */       return ((WSIO)this.wsioChildren.get(0));
/*     */     }
/* 207 */     return null;
/*     */   }
















/*     */   public boolean isMaxOccursUnbounded()
/*     */   {
/* 227 */     return ((this.maxOccurs < 0) || (this.maxOccurs > 1));
/*     */   }


/*     */   public Map<String, WSIOAttribute> getWSIOAttributesMap()
/*     */   {
/* 233 */     return this.attrMap;
/*     */   }
/*     */ }
