/*     */ package com.ibm.tivoli.maximo.interaction.obp;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaAttributeModel;
/*     */ import org.apache.xmlbeans.SchemaGlobalElement;
/*     */ import org.apache.xmlbeans.SchemaLocalAttribute;
/*     */ import org.apache.xmlbeans.SchemaParticle;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlObject.Factory;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.junit.Test;
/*     */ import psdi.iface.util.XMLUtils;
/*     */ 










































/*     */ public class TestSchema
/*     */ {
/*  45 */   private static Map<Integer, String> wsioAttrTypes = new HashMap();
/*     */ 
/*     */   private static SchemaType getBuiltinType(SchemaType type)
/*     */   {
/*  74 */     if (type.isBuiltinType()) return type;
/*  75 */     return getBuiltinType(type.getBaseType());
/*     */   }



/*     */   @Test
/*     */   public void testSchema()
/*     */   {
/*  83 */     SchemaTypeSystem sts = compileSchema();
/*  84 */     SchemaGlobalElement[] globalElements = sts.globalElements();
/*  85 */     SchemaGlobalElement rootElem = null;
/*  86 */     for (SchemaGlobalElement globalElement : globalElements)
/*     */     {
/*  88 */       System.out.println("root name==" + globalElement.getName());
/*  89 */       SchemaType stype = globalElement.getType();
/*  90 */       System.out.println("simple type = " + stype.isSimpleType() + " abstract " + stype.isAbstract() + " element is abstract " + globalElement.isAbstract());
/*  91 */       if (stype.isSimpleType())
/*     */       {
/*  93 */         SchemaType btype = getBuiltinType(stype);
/*  94 */         System.out.println("built in type====" + ((String)wsioAttrTypes.get(Integer.valueOf(btype.getBuiltinTypeCode()))));
/*  95 */         System.out.println("default text====" + globalElement.getDefaultText() + " is fixed " + globalElement.isFixed());
/*  96 */         System.out.println("enum =" + stype.hasStringEnumValues());
/*     */       }
/*     */       else
/*     */       {
/* 100 */         int contentType = stype.getContentType();
/* 101 */         if (contentType == 3)
/*     */         {
/* 103 */           System.out.println("Element content");

/*     */ 
/* 106 */           SchemaParticle sp = stype.getContentModel();
/* 107 */           System.out.println("sp maxoccurs====" + sp.getMaxOccurs());
/* 108 */           List spList = new ArrayList();
/* 109 */           listElements(spList, sp);
/* 110 */           listAttributes(stype);






























/*     */         }
/* 142 */         else if (contentType == 1)
/*     */         {
/* 144 */           System.out.println("Empty content");
/* 145 */           listAttributes(stype);

/*     */         }
/* 148 */         else if (contentType == 2)
/*     */         {
/* 150 */           System.out.println("Simple content");
/* 151 */           SchemaType btype = getBuiltinType(stype);
/* 152 */           System.out.println("built in type====" + ((String)wsioAttrTypes.get(Integer.valueOf(btype.getBuiltinTypeCode()))));
/*     */ 
/* 154 */           listAttributes(stype);

/*     */         }
/* 157 */         else if (contentType == 4)
/*     */         {
/* 159 */           System.out.println("Mixed content");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 164 */       XmlAnySimpleType[] valueArray = stype.getEnumerationValues();
/* 165 */       if (valueArray == null)
/*     */         continue;
/* 167 */       for (XmlAnySimpleType value : valueArray)
/*     */       {
/* 169 */         System.out.println("enum value=========" + value.getStringValue());
/*     */       }
/*     */     }
/*     */   }


































/*     */   private void listElements(List<SchemaParticle> list, SchemaParticle sp)
/*     */   {
/* 209 */     int ptype = sp.getParticleType();
/* 210 */     if ((ptype == 3) || (ptype == 1) || (ptype == 2))
/*     */     {
/* 212 */       System.out.println("SP type sequence");
/* 213 */       SchemaParticle[] spChildren = sp.getParticleChildren();
/* 214 */       if (spChildren != null)
/*     */       {
/* 216 */         for (SchemaParticle spChild : spChildren)

/*     */         {
/* 219 */           listElements(list, spChild);
/*     */         }
/*     */       }
/*     */     } else {
/* 223 */       if (ptype != 4)
/*     */         return;
/* 225 */       System.out.println("SP type is element with name " + sp.getName().getLocalPart() + " and type " + sp.getType().getName() + " maxOccurs=" + sp.getMaxOccurs());
/*     */ 
/* 227 */       list.add(sp);
/*     */     }
/*     */   }



/*     */   private void listAttributes(SchemaType stype)
/*     */   {
/* 235 */     SchemaAttributeModel sam = stype.getAttributeModel();
/* 236 */     if (sam == null)
/*     */       return;
/* 238 */     SchemaLocalAttribute[] attrs = sam.getAttributes();
/* 239 */     for (SchemaLocalAttribute attr : attrs)
/*     */     {
/* 241 */       System.out.println("attribute name = " + attr.getName().getLocalPart());
/*     */     }
/*     */   }


/*     */   private SchemaTypeSystem compileSchema()
/*     */   {
/*     */     try
/*     */     {
/* 250 */       SchemaTypeSystem sts = null;
/* 251 */       List schemaList = getSchemas();
/* 252 */       XmlObject[] schemas = new XmlObject[schemaList.size()];
/* 253 */       int i = 0;
/* 254 */       for (String schemaDoc : schemaList)

/*     */       {
/* 257 */         schemas[i] = XmlObject.Factory.parse(schemaDoc, new XmlOptions().setLoadLineNumbers().setLoadMessageDigest());
/*     */ 
/* 259 */         ++i;

/*     */       }
/*     */ 
/* 263 */       if (schemas.length > 0)
/*     */       {
/* 265 */         Collection errors = new ArrayList();
/* 266 */         XmlOptions compileOptions = new XmlOptions();
/* 267 */         compileOptions.setCompileDownloadUrls();
/*     */         Iterator itr;
/*     */         try {
/* 270 */           sts = XmlBeans.compileXsd(schemas, XmlBeans.getBuiltinTypeSystem(), compileOptions);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 274 */           if ((errors.isEmpty()) || (!(e instanceof XmlException))) {
/* 275 */             e.printStackTrace();
/*     */           }
/* 277 */           System.out.println("Schema compilation errors: ");
/* 278 */           for (itr = errors.iterator(); itr.hasNext(); ) {
/* 279 */             System.out.println(itr.next());
/*     */           }
/*     */         }
/*     */       }
/* 283 */       if (sts == null)
/*     */       {
/* 285 */         throw new RuntimeException("No Schemas to process.");
/*     */       }
/* 287 */       return sts;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 291 */       e.printStackTrace(); }
/* 292 */     return null;
/*     */   }


/*     */   private List<String> getSchemas()
/*     */     throws Exception
/*     */   {
/* 299 */     List iplist = new ArrayList();
/* 300 */     byte[] doc = XMLUtils.readXMLFileToBytes("C:\\harrier\\obpschematest\\po.xsd");
/* 301 */     iplist.add(new String(doc, "UTF-8"));
/* 302 */     doc = XMLUtils.readXMLFileToBytes("C:\\harrier\\obpschematest\\TestPOService.xsd");
/* 303 */     iplist.add(new String(doc, "UTF-8"));
/* 304 */     doc = XMLUtils.readXMLFileToBytes("C:\\harrier\\obpschematest\\MXMeta.xsd");
/* 305 */     iplist.add(new String(doc, "UTF-8"));
/*     */ 
/* 307 */     return iplist;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  48 */     wsioAttrTypes.put(Integer.valueOf(12), "String");
/*  49 */     wsioAttrTypes.put(Integer.valueOf(22), "Integer");
/*  50 */     wsioAttrTypes.put(Integer.valueOf(11), "Double");
/*  51 */     wsioAttrTypes.put(Integer.valueOf(24), "Integer");
/*  52 */     wsioAttrTypes.put(Integer.valueOf(10), "Double");
/*  53 */     wsioAttrTypes.put(Integer.valueOf(9), "Float");
/*  54 */     wsioAttrTypes.put(Integer.valueOf(23), "Long");
/*  55 */     wsioAttrTypes.put(Integer.valueOf(32), "Long");
/*  56 */     wsioAttrTypes.put(Integer.valueOf(33), "Integer");
/*  57 */     wsioAttrTypes.put(Integer.valueOf(34), "Short");
/*  58 */     wsioAttrTypes.put(Integer.valueOf(26), "Byte");
/*  59 */     wsioAttrTypes.put(Integer.valueOf(3), "Boolean");
/*  60 */     wsioAttrTypes.put(Integer.valueOf(25), "Short");
/*  61 */     wsioAttrTypes.put(Integer.valueOf(14), "DateTime");
/*  62 */     wsioAttrTypes.put(Integer.valueOf(16), "Date");
/*  63 */     wsioAttrTypes.put(Integer.valueOf(15), "Time");
/*  64 */     wsioAttrTypes.put(Integer.valueOf(13), "String");
/*  65 */     wsioAttrTypes.put(Integer.valueOf(36), "String");
/*  66 */     wsioAttrTypes.put(Integer.valueOf(45), "String");
/*  67 */     wsioAttrTypes.put(Integer.valueOf(4), "Base64Bytes");
/*  68 */     wsioAttrTypes.put(Integer.valueOf(5), "HexBytes");
/*     */   }
/*     */ }
