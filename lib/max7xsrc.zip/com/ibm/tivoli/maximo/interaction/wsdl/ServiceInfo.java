/*    */ package com.ibm.tivoli.maximo.interaction.wsdl;
/*    */ 
/*    */ import java.util.List;
/*    */ 



























/*    */ public class ServiceInfo
/*    */ {
/*    */   private String name;
/*    */   private List<PortInfo> ports;
/*    */ 
/*    */   public ServiceInfo(String name, List<PortInfo> ports)
/*    */   {
/* 39 */     this.name = name;
/* 40 */     this.ports = ports;
/*    */   }




/*    */   public String getName()
/*    */   {
/* 48 */     return this.name;
/*    */   }




/*    */   public List<PortInfo> getPorts()
/*    */   {
/* 56 */     return this.ports;
/*    */   }




/*    */   public PortInfo getPortInfo(String name)
/*    */   {
/* 64 */     for (PortInfo port : this.ports)
/*    */     {
/* 66 */       if (port.getName().equals(name))
/*    */       {
/* 68 */         return port;
/*    */       }
/*    */     }
/* 71 */     return null;
/*    */   }


/*    */   public String toString()
/*    */   {
/* 77 */     return this.name + " Ports:: " + this.ports;
/*    */   }
/*    */ }
