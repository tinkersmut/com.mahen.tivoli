/*     */ package com.ibm.tivoli.maximo.interaction.wsdl;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.interaction.process.InteractionUtil;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import javax.wsdl.Binding;
/*     */ import javax.wsdl.BindingOperation;
/*     */ import javax.wsdl.Definition;
/*     */ import javax.wsdl.Import;
/*     */ import javax.wsdl.Input;
/*     */ import javax.wsdl.Message;
/*     */ import javax.wsdl.Operation;
/*     */ import javax.wsdl.Output;
/*     */ import javax.wsdl.Part;
/*     */ import javax.wsdl.Port;
/*     */ import javax.wsdl.PortType;
/*     */ import javax.wsdl.Service;
/*     */ import javax.wsdl.Types;
/*     */ import javax.wsdl.WSDLException;
/*     */ import javax.wsdl.extensions.UnknownExtensibilityElement;
/*     */ import javax.wsdl.extensions.http.HTTPAddress;
/*     */ import javax.wsdl.extensions.http.HTTPBinding;
/*     */ import javax.wsdl.extensions.http.HTTPOperation;
/*     */ import javax.wsdl.extensions.schema.Schema;
/*     */ import javax.wsdl.extensions.soap.SOAPAddress;
/*     */ import javax.wsdl.extensions.soap.SOAPBinding;
/*     */ import javax.wsdl.extensions.soap.SOAPOperation;
/*     */ import javax.wsdl.extensions.soap12.SOAP12Address;
/*     */ import javax.wsdl.extensions.soap12.SOAP12Binding;
/*     */ import javax.wsdl.extensions.soap12.SOAP12Operation;
/*     */ import javax.wsdl.factory.WSDLFactory;
/*     */ import javax.wsdl.xml.WSDLReader;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlObject.Factory;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.xsd2inst.SampleXmlUtil;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.IllegalAddException;
/*     */ import org.jdom.Namespace;
/*     */ import org.jdom.input.DOMBuilder;
/*     */ import org.xml.sax.InputSource;/*     */ import psdi.iface.util.XMLUtils;/*     */ import psdi.util.MXApplicationException;/*     */ import psdi.util.MXException;/*     */ import psdi.util.logging.MXLogger;/*     */ 
/*     */ public class DefaultWSDLParser
/*     */   implements WSDLParser
/*     */ {
/*     */   public static final String SOAP11HTTP_BINDING = "SOAP11/HTTP";
/*     */   public static final String SOAP12HTTP_BINDING = "SOAP12/HTTP";
/*     */   public static final String POSTHTTP_BINDING = "POST/HTTP";
/*     */   public static final String GETHTTP_BINDING = "GET/HTTP";
/*     */   public static final String MEP_REQUEST_RESPONSE = "REQ_RESP";
/*     */   public static final String MEP_REQUEST_VOIDRESPONSE = "REQ_VOID_RESP";
/*     */   public static final String MEP_REQUEST_ONLY = "REQ_ONLY";
/*     */   private Definition interfaceDef;
/*     */   private Definition implDef;
/*     */   private String interfaceTgtNs;
/*     */ 
/*     */   public DefaultWSDLParser()
/*     */   {
/*  71 */     this.interfaceDef = null;
/*  72 */     this.implDef = null;
/*  73 */     this.interfaceTgtNs = null;
/*     */   }



/*     */   public WSDLInfo parse(URL wsdlURL)
/*     */     throws MXException
/*     */   {
/*     */     try
/*     */     {
/*  83 */       WSDLFactory factory = WSDLFactory.newInstance();
/*  84 */       WSDLReader reader = factory.newWSDLReader();
/*  85 */       this.implDef = reader.readWSDL(wsdlURL.toString());
/*  86 */       return parse(this.implDef);
/*     */     }
/*     */     catch (WSDLException e)
/*     */     {
/*  90 */       e.printStackTrace();
/*  91 */       throw new MXApplicationException("iface", "wsdlparseerror", e);
/*     */     }
/*     */     catch (XmlException e)
/*     */     {
/*  95 */       e.printStackTrace();
/*  96 */       throw new MXApplicationException("iface", "schemaparseerror", e);
/*     */     }
/*     */   }

/*     */   private WSDLInfo parse(Definition implDef)
/*     */     throws WSDLException, XmlException, MXException
/*     */   {
/* 103 */     if (implDef == null)
/*     */     {
/* 105 */       throw new WSDLException("OTHER_ERROR", "No WSDL impl definition found.");

/*     */     }
/*     */ 
/* 109 */     Map imports = implDef.getImports();
/* 110 */     Set s = imports.keySet();
/* 111 */     Iterator it = s.iterator();
/* 112 */     while (it.hasNext())
/*     */     {
/* 114 */       Object o = it.next();
/* 115 */       Vector intDoc = (Vector)imports.get(o);
/*     */ 
/* 117 */       for (int i = 0; i < intDoc.size(); ++i)
/*     */       {
/* 119 */         Object obj = intDoc.elementAt(i);
/* 120 */         if (!(obj instanceof Import))
/*     */           continue;
/* 122 */         this.interfaceDef = ((Import)obj).getDefinition();
/*     */       }
/*     */     }
/*     */ 
/* 126 */     if (this.interfaceDef == null)
/*     */     {
/* 128 */       this.interfaceDef = implDef;
/*     */     }
/* 130 */     this.interfaceTgtNs = this.interfaceDef.getTargetNamespace();
/* 131 */     Map nsContext = this.interfaceDef.getNamespaces();
/* 132 */     Set prefixes = nsContext.keySet();
/*     */ 
/* 134 */     if (getLogger().isDebugEnabled())
/*     */     {
/* 136 */       for (String prefix : prefixes)
/*     */       {
/* 138 */         getLogger().debug("prefix=" + prefix + " nsuri=" + ((String)nsContext.get(prefix)));
/*     */       }
/*     */     }
/* 141 */     List services = getServices();
/* 142 */     SchemaTypeSystem sts = compileSchema();
/* 143 */     Map serviceInfoList = createServiceInfos(sts, services);
/*     */ 
/* 145 */     return new WSDLInfo(serviceInfoList, sts);
/*     */   }

/*     */   private Map<String, ServiceInfo> createServiceInfos(SchemaTypeSystem sts, List<Service> services)
/*     */     throws MXException
/*     */   {
/* 151 */     Map serviceInfoMap = new HashMap(services.size());
/* 152 */     for (Service service : services)
/*     */     {
/* 154 */       String serviceName = service.getQName().getLocalPart();
/* 155 */       List portInfos = createPortInfoList(sts, service);
/* 156 */       ServiceInfo serviceInfo = new ServiceInfo(serviceName, portInfos);
/* 157 */       serviceInfoMap.put(serviceName, serviceInfo);
/*     */     }
/* 159 */     return serviceInfoMap;
/*     */   }

/*     */   private List<OperationInfo> createOperationInfoList(SchemaTypeSystem sts, Binding portBinding) throws MXException
/*     */   {
/* 164 */     PortType portType = portBinding.getPortType();
/* 165 */     List bindOps = portBinding.getBindingOperations();
/* 166 */     List ops = new ArrayList(bindOps.size());
/* 167 */     for (BindingOperation bindOp : bindOps)

/*     */     {
/* 170 */       OperationInfo opInfo = new OperationInfo();
/* 171 */       ops.add(opInfo);
/* 172 */       String opName = bindOp.getName();
/* 173 */       opInfo.setName(opName);
/* 174 */       getLogger().debug("opName name=" + opName);
/* 175 */       Operation portTypeOp = getOperation(portType, opName);
/* 176 */       QName inputRootElemName = getInputRootElementName(portTypeOp);
/* 177 */       getLogger().debug("opName inputRootElemName=" + inputRootElemName);
/* 178 */       opInfo.setInputElement(inputRootElemName);
/* 179 */       Document inputSample = instantiateSchema(sts, inputRootElemName.getLocalPart());
/*     */ 
/* 181 */       opInfo.setInputSample(inputSample);
/* 182 */       QName outputRootElemName = getOutputRootElementName(portTypeOp);
/* 183 */       getLogger().debug("opName outputRootElemName=" + outputRootElemName);
/* 184 */       if (outputRootElemName != null)
/*     */       {
/* 186 */         opInfo.setOutputElement(outputRootElemName);
/* 187 */         Document outputSample = instantiateSchema(sts, outputRootElemName.getLocalPart());
/*     */ 
/* 189 */         opInfo.setOutputSample(outputSample);
/*     */       }
/*     */ 
/* 192 */       List bindExtElems = bindOp.getExtensibilityElements();
/* 193 */       for (int i = 0; i < bindExtElems.size(); ++i)
/*     */       {
/* 195 */         if (bindExtElems.get(i) instanceof SOAPOperation)
/*     */         {
/* 197 */           SOAPOperation soapOp = (SOAPOperation)bindExtElems.get(i);



/*     */ 
/* 202 */           String soapAction = soapOp.getSoapActionURI();
/* 203 */           opInfo.setSoapAction(soapAction);
/*     */         }
/* 205 */         else if (bindExtElems.get(i) instanceof SOAP12Operation)
/*     */         {
/* 207 */           SOAP12Operation soapOp = (SOAP12Operation)bindExtElems.get(i);



/*     */ 
/* 212 */           String soapAction = soapOp.getSoapActionURI();
/* 213 */           opInfo.setSoapAction(soapAction);
/*     */         }
/* 215 */         else if (bindExtElems.get(i) instanceof UnknownExtensibilityElement)
/*     */         {
/* 217 */           org.w3c.dom.Element domSchemaElem = ((UnknownExtensibilityElement)bindExtElems.get(i)).getElement();
/*     */ 
/* 219 */           getLogger().debug("soapAction=" + domSchemaElem.getAttribute("soapAction"));
/* 220 */           String soapAction = domSchemaElem.getAttribute("soapAction");
/* 221 */           opInfo.setSoapAction(soapAction);
/*     */         } else {
/* 223 */           if (!(bindExtElems.get(i) instanceof HTTPOperation))
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 234 */     return ops;
/*     */   }

/*     */   private List<Service> getServices()
/*     */   {
/* 239 */     Map serviceMap = this.implDef.getServices();
/* 240 */     List serviceList = new ArrayList(serviceMap.size());
/* 241 */     if (serviceMap.size() > 0)
/*     */     {
/* 243 */       Iterator itr = serviceMap.keySet().iterator();
/* 244 */       while (itr.hasNext())
/*     */       {
/* 246 */         Service service = (Service)serviceMap.get(itr.next());
/* 247 */         getLogger().debug("service name=" + service.getQName().getLocalPart());
/* 248 */         serviceList.add(service);
/*     */       }
/*     */     }
/* 251 */     return serviceList;
/*     */   }

/*     */   private List<PortInfo> createPortInfoList(SchemaTypeSystem sts, Service service) throws MXException
/*     */   {
/* 256 */     Map portsMap = service.getPorts();
/* 257 */     List portsList = new ArrayList(portsMap.size());
/* 258 */     List portInfos = new ArrayList(portsList.size());
/* 259 */     if (portsMap.size() > 0)
/*     */     {
/* 261 */       Iterator itr = portsMap.keySet().iterator();
/*     */ 
/* 263 */       while (itr.hasNext())
/*     */       {
/* 265 */         boolean wsbpPort = true;
/* 266 */         String bindingType = "";
/* 267 */         Port port = (Port)portsMap.get(itr.next());
/*     */ 
/* 269 */         getLogger().debug("port name=" + port.getName());
/*     */ 
/* 271 */         Binding portBinding = port.getBinding();
/*     */ 
/* 273 */         List extElems = portBinding.getExtensibilityElements();
/* 274 */         for (int i = 0; i < extElems.size(); ++i)
/*     */         {
/* 276 */           getLogger().debug("binding elem class type=" + extElems.get(i));
/*     */ 
/* 278 */           if (extElems.get(i) instanceof HTTPBinding)
/*     */           {
/* 280 */             wsbpPort = false;
/* 281 */             break;








/*     */           }
/*     */ 
/* 292 */           if (extElems.get(i) instanceof SOAPBinding)
/*     */           {
/* 294 */             SOAPBinding soapBinding = (SOAPBinding)extElems.get(i);
/* 295 */             getLogger().debug("the soap11 binding ns uri=" + soapBinding.getElementType().getNamespaceURI());
/* 296 */             bindingType = "SOAP11/HTTP";
/*     */           }
/* 298 */           else if (extElems.get(i) instanceof SOAP12Binding)
/*     */           {
/* 300 */             SOAP12Binding soapBinding = (SOAP12Binding)extElems.get(i);
/* 301 */             getLogger().debug("the soap12 binding ns uri=" + soapBinding.getElementType().getNamespaceURI());
/* 302 */             bindingType = "SOAP12/HTTP";
/*     */           } else {
/* 304 */             if (!(extElems.get(i) instanceof UnknownExtensibilityElement))
/*     */               continue;
/* 306 */             org.w3c.dom.Element domSchemaElem = ((UnknownExtensibilityElement)extElems.get(i)).getElement();
/* 307 */             if ((!("http://schemas.xmlsoap.org/wsdl/soap12/".equals(domSchemaElem.getNamespaceURI()))) || (!("binding".equals(domSchemaElem.getLocalName()))))
/*     */               continue;
/* 309 */             bindingType = "SOAP12/HTTP";


/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 316 */         if (wsbpPort)
/*     */         {
/* 318 */           PortInfo portInfo = new PortInfo();
/* 319 */           portInfos.add(portInfo);
/* 320 */           portInfo.setName(port.getName());
/* 321 */           portInfo.setBindingType(bindingType);
/* 322 */           portInfo.setOperationList(createOperationInfoList(sts, portBinding));
/*     */ 
/* 324 */           portInfo.setBindingName(portBinding.getQName().getLocalPart());
/* 325 */           PortType portType = portBinding.getPortType();
/* 326 */           portInfo.setPortTypeName(portType.getQName().getLocalPart());
/* 327 */           prepareEndPointUrlBinding(port, portInfo);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 334 */     return portInfos;
/*     */   }

/*     */   protected MXLogger getLogger()
/*     */   {
/* 339 */     return InteractionUtil.INTERACTIONLOGGER;
/*     */   }

/*     */   private void prepareEndPointUrlBinding(Port port, PortInfo portInfo)
/*     */   {
/* 344 */     List elems = port.getExtensibilityElements();
/* 345 */     for (int i = 0; i < elems.size(); ++i)
/*     */     {
/* 347 */       if (elems.get(i) instanceof SOAPAddress)
/*     */       {
/* 349 */         SOAPAddress addr = (SOAPAddress)elems.get(i);
/* 350 */         portInfo.setEndPointUrl(addr.getLocationURI());
/*     */       }
/* 352 */       else if (elems.get(i) instanceof SOAP12Address)
/*     */       {
/* 354 */         SOAP12Address addr = (SOAP12Address)elems.get(i);
/* 355 */         portInfo.setEndPointUrl(addr.getLocationURI());

/*     */       }
/* 358 */       else if (elems.get(i) instanceof UnknownExtensibilityElement)
/*     */       {
/* 360 */         org.w3c.dom.Element domSchemaElem = ((UnknownExtensibilityElement)elems.get(i)).getElement();
/* 361 */         portInfo.setEndPointUrl(domSchemaElem.getAttribute("location"));
/* 362 */         getLogger().debug("soap address location attr = " + domSchemaElem.getAttribute("location"));
/*     */       }
/*     */       else
/*     */       {
/* 366 */         if (!(elems.get(i) instanceof HTTPAddress))
/*     */           continue;
/*     */       }
/*     */     }
/*     */   }





/*     */   private Operation getOperation(PortType portType, String oper)
/*     */   {
/* 378 */     List opers = portType.getOperations();
/* 379 */     for (int i = 0; i < opers.size(); ++i)
/*     */     {
/* 381 */       Operation o = (Operation)opers.get(i);
/* 382 */       if (o.getName().equals(oper)) return o;
/*     */     }
/* 384 */     return null;
/*     */   }

/*     */   private QName getInputRootElementName(Operation operation)
/*     */   {
/* 389 */     Input in = operation.getInput();
/* 390 */     QName elemName = null;
/* 391 */     if (in != null)
/*     */     {
/* 393 */       Map parts = in.getMessage().getParts();
/* 394 */       Iterator it = parts.keySet().iterator();
/* 395 */       Object key = it.next();
/* 396 */       Part p = (Part)parts.get(key);
/* 397 */       elemName = p.getElementName();
/*     */     }
/* 399 */     return elemName;
/*     */   }

/*     */   private QName getOutputRootElementName(Operation operation)
/*     */   {
/* 404 */     Output out = operation.getOutput();
/* 405 */     QName elemName = null;
/* 406 */     if (out != null)
/*     */     {
/* 408 */       Message msg = out.getMessage();
/* 409 */       if (msg == null) return null;
/* 410 */       Map parts = msg.getParts();
/* 411 */       if ((parts == null) || (parts.size() == 0)) return null;
/* 412 */       Iterator it = parts.keySet().iterator();
/* 413 */       Object key = it.next();
/* 414 */       Part p = (Part)parts.get(key);
/* 415 */       elemName = p.getElementName();
/*     */     }
/* 417 */     return elemName;
/*     */   }

/*     */   private SchemaTypeSystem compileSchema() throws XmlException, MXException
/*     */   {
/* 422 */     SchemaTypeSystem sts = null;
/* 423 */     List schemaList = getSchemas();
/* 424 */     XmlObject[] schemas = new XmlObject[schemaList.size()];
/* 425 */     int i = 0;
/* 426 */     for (String schemaDoc : schemaList)

/*     */     {
/* 429 */       schemas[i] = XmlObject.Factory.parse(schemaDoc, new XmlOptions().setLoadLineNumbers().setLoadMessageDigest());
/*     */ 
/* 431 */       ++i;

/*     */     }
/*     */ 
/* 435 */     if (schemas.length > 0)
/*     */     {
/* 437 */       Collection errors = new ArrayList();
/* 438 */       XmlOptions compileOptions = new XmlOptions();
/* 439 */       compileOptions.setCompileDownloadUrls();
/*     */       try
/*     */       {
/* 442 */         sts = XmlBeans.compileXsd(schemas, XmlBeans.getBuiltinTypeSystem(), compileOptions);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 446 */         e.printStackTrace();
/* 447 */         getLogger().error("Schema compilation errors: ");
/* 448 */         for (Iterator itr = errors.iterator(); itr.hasNext(); )
/* 449 */           getLogger().error(itr.next());
/* 450 */         throw new MXApplicationException("iface", "errschemacompile", e);




/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 459 */     if (sts == null)
/*     */     {
/* 461 */       throw new MXApplicationException("iface", "noschematoprocess");
/*     */     }
/* 463 */     return sts;
/*     */   }

/*     */   private Document instantiateSchema(SchemaTypeSystem sts, String rootElementName)
/*     */     throws MXException
/*     */   {
/* 469 */     SchemaType[] globalElems = sts.documentTypes();
/* 470 */     SchemaType elem = null;
/* 471 */     for (int i = 0; i < globalElems.length; ++i)
/*     */     {
/* 473 */       if (!(rootElementName.equals(globalElems[i].getDocumentElementName().getLocalPart())))
/*     */         continue;
/* 475 */       elem = globalElems[i];
/* 476 */       break;

/*     */     }
/*     */ 
/* 480 */     if (elem == null)
/*     */     {
/* 482 */       String[] params = { rootElementName };
/* 483 */       throw new MXApplicationException("iface", "rootelemnotfound", params);

/*     */     }
/*     */ 
/* 487 */     String result = SampleXmlUtil.createSampleForType(elem);
/*     */     try
/*     */     {
/* 490 */       return XMLUtils.convertBytesToDocument(result.getBytes("UTF-8"));
/*     */     }
/*     */     catch (UnsupportedEncodingException uence)
/*     */     {
/* 494 */       getLogger().error(uence.getMessage(), uence); }
/* 495 */     return null;
/*     */   }



/*     */   private List<String> getSchemas()
/*     */     throws MXException
/*     */   {
/* 503 */     getLogger().debug(this.interfaceDef.getTypes().getClass().getName());
/* 504 */     List schemas = this.interfaceDef.getTypes().getExtensibilityElements();
/* 505 */     List schemaDataList = new ArrayList();
/* 506 */     DOMBuilder domBuilder = new DOMBuilder();
/* 507 */     getLogger().debug("Schema size=" + schemas.size());
/* 508 */     Map wdlNSmap = this.interfaceDef.getNamespaces();
/*     */ 
/* 510 */     for (int i = 0; i < schemas.size(); ++i)
/*     */     {
/* 512 */       org.w3c.dom.Element domSchemaElem = null;
/* 513 */       if (schemas.get(i) instanceof Schema)
/*     */       {
/* 515 */         getLogger().debug("using Schema.....");
/*     */ 
/* 517 */         domSchemaElem = ((Schema)schemas.get(i)).getElement();
/*     */       }
/*     */       else
/*     */       {
/* 521 */         getLogger().debug("using UnknownExtensibilityElement.....");
/* 522 */         domSchemaElem = ((UnknownExtensibilityElement)schemas.get(i)).getElement();
/* 523 */         if (!(domSchemaElem.getNamespaceURI().equals("http://www.w3.org/2001/XMLSchema"))) continue; if (!(domSchemaElem.getLocalName().equals("schema")))

/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 531 */       org.jdom.Element schemaElem = domBuilder.build(domSchemaElem);
/*     */ 
/* 533 */       List listNs = schemaElem.getAdditionalNamespaces();





























/*     */ 
/* 564 */       Set set = wdlNSmap.keySet();
/* 565 */       for (String key : set)
/*     */       {
/*     */         try
/*     */         {
/* 569 */           schemaElem.addNamespaceDeclaration(Namespace.getNamespace(key, (String)wdlNSmap.get(key)));
/*     */         }
/*     */         catch (IllegalAddException iae)
/*     */         {
/* 573 */           getLogger().debug("there was a clash between schema and wsdl in namespace prefix for " + key + " ns " + ((String)wdlNSmap.get(key)));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 578 */       schemaElem.detach();
/* 579 */       Document schemaDoc = new Document(schemaElem);
/* 580 */       byte[] data = XMLUtils.convertDocumentToBytes(schemaDoc);
/*     */       try
/*     */       {
/* 583 */         schemaDataList.add(new String(data, "UTF-8"));
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 587 */         throw new MXApplicationException("iface", "schemaenc", e);
/*     */       }
/*     */     }
/* 590 */     return schemaDataList;
/*     */   }




/*     */   public WSDLInfo parse(InputSource wsdlSource)
/*     */     throws MXException
/*     */   {
/*     */     try
/*     */     {
/* 601 */       WSDLFactory factory = WSDLFactory.newInstance();
/* 602 */       WSDLReader reader = factory.newWSDLReader();
/* 603 */       this.implDef = reader.readWSDL(null, wsdlSource);
/* 604 */       return parse(this.implDef);
/*     */     }
/*     */     catch (WSDLException e)
/*     */     {
/* 608 */       throw new MXApplicationException("iface", "wsdlparseerror", e);
/*     */     }
/*     */     catch (XmlException e)
/*     */     {
/* 612 */       throw new MXApplicationException("iface", "schemaparseerror", e);
/*     */     }
/*     */   }
/*     */ }
