package com.ibm.tivoli.maximo.interaction.wsdl;

import java.net.URL;
import org.xml.sax.InputSource;
import psdi.util.MXException;

public abstract interface WSDLParser
{
  public abstract WSDLInfo parse(URL paramURL)
    throws MXException;

  public abstract WSDLInfo parse(InputSource paramInputSource)
    throws MXException;
}
