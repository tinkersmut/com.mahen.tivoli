/*     */ package com.ibm.tivoli.maximo.interaction.wsdl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 

















/*     */ public class PortInfo
/*     */ {
/*     */   private String name;
/*     */   private String bindingName;
/*     */   private String portTypeName;
/*     */   private String endPointUrl;
/*     */   private String bindingType;
/*     */   private List<OperationInfo> operationList;
/*     */ 
/*     */   public PortInfo()
/*     */   {
/*  34 */     this.operationList = new ArrayList();
/*     */   }




/*     */   public String getBindingName()
/*     */   {
/*  42 */     return this.bindingName;
/*     */   }




/*     */   public String getBindingType()
/*     */   {
/*  50 */     return this.bindingType;
/*     */   }




/*     */   public String getName()
/*     */   {
/*  58 */     return this.name;
/*     */   }




/*     */   public List<OperationInfo> getOperationList()
/*     */   {
/*  66 */     return this.operationList;
/*     */   }




/*     */   public String getPortTypeName()
/*     */   {
/*  74 */     return this.portTypeName;
/*     */   }




/*     */   public String getEndPointUrl()
/*     */   {
/*  82 */     return this.endPointUrl;
/*     */   }




/*     */   void setBindingName(String bindingName)
/*     */   {
/*  90 */     if ((bindingName != null) && (bindingName.trim().length() == 0))
/*     */     {
/*  92 */       this.bindingName = null;
/*     */     }
/*     */     else
/*     */     {
/*  96 */       this.bindingName = bindingName;
/*     */     }
/*     */   }




/*     */   void setBindingType(String bindingType)
/*     */   {
/* 105 */     if ((bindingType != null) && (bindingType.trim().length() == 0))
/*     */     {
/* 107 */       this.bindingType = null;
/*     */     }
/*     */     else
/*     */     {
/* 111 */       this.bindingType = bindingType;
/*     */     }
/*     */   }




/*     */   void setEndPointUrl(String endPointUrl)
/*     */   {
/* 120 */     if ((endPointUrl != null) && (endPointUrl.trim().length() == 0))
/*     */     {
/* 122 */       this.endPointUrl = null;
/*     */     }
/*     */     else
/*     */     {
/* 126 */       this.endPointUrl = endPointUrl;
/*     */     }
/*     */   }




/*     */   void setName(String name)
/*     */   {
/* 135 */     this.name = name;
/*     */   }




/*     */   void setOperationList(List<OperationInfo> operationList)
/*     */   {
/* 143 */     this.operationList = operationList;
/*     */   }




/*     */   void setPortTypeName(String portTypeName)
/*     */   {
/* 151 */     this.portTypeName = portTypeName;
/*     */   }

/*     */   public OperationInfo getOperationInfo(String operationName)
/*     */   {
/* 156 */     for (OperationInfo op : this.operationList)
/*     */     {
/* 158 */       if (op.getName().equals(operationName)) return op;
/*     */     }
/* 160 */     return null;
/*     */   }

/*     */   public String toString()
/*     */   {
/* 165 */     return this.name + " PortType:: " + this.portTypeName + " epurl:: " + this.endPointUrl + " binding:: " + this.bindingType + " Operations:: " + this.operationList;
/*     */   }
/*     */ }
