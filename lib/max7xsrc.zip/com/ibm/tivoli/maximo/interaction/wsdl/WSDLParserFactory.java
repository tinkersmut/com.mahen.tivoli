/*    */ package com.ibm.tivoli.maximo.interaction.wsdl;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.MXSystemException;
/*    */ 






























/*    */ public class WSDLParserFactory
/*    */ {
/*    */   public static WSDLParser getWSDLParser()
/*    */     throws MXException
/*    */   {
/*    */     try
/*    */     {
/* 45 */       String wsdlParserClassName = MXServer.getMXServer().getProperty("mxe.int.wsdlparser");
/* 46 */       wsdlParserClassName = (wsdlParserClassName == null) ? "com.ibm.tivoli.maximo.interaction.wsdl.DefaultWSDLParser" : wsdlParserClassName;
/* 47 */       WSDLParser parser = (WSDLParser)Class.forName(wsdlParserClassName).newInstance();
/* 48 */       return parser;
/*    */     }
/*    */     catch (RemoteException re)
/*    */     {
/* 52 */       throw new MXSystemException("system", "remoteexception", re);
/*    */     }
/*    */     catch (ClassNotFoundException e)
/*    */     {
/* 56 */       throw new MXSystemException("system", "noclass", e);
/*    */     }
/*    */     catch (IllegalAccessException e)
/*    */     {
/* 60 */       throw new MXSystemException("system", "noaccess", e);
/*    */     }
/*    */     catch (InstantiationException e)
/*    */     {
/* 64 */       throw new MXSystemException("system", "noinstance", e);
/*    */     }
/*    */   }
/*    */ }
