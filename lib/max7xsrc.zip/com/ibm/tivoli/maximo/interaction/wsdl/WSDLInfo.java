/*    */ package com.ibm.tivoli.maximo.interaction.wsdl;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.apache.xmlbeans.SchemaTypeSystem;
/*    */ 

























/*    */ public class WSDLInfo
/*    */ {
/*    */   private Map<String, ServiceInfo> map;
/*    */   private SchemaTypeSystem compiledScehma;
/*    */ 
/*    */   public WSDLInfo(Map<String, ServiceInfo> map, SchemaTypeSystem compiledScehma)
/*    */   {
/* 39 */     this.map = map;
/* 40 */     this.compiledScehma = compiledScehma;
/*    */   }





/*    */   public ServiceInfo getServiceInfo(String serviceName)
/*    */   {
/* 49 */     return ((ServiceInfo)this.map.get(serviceName));
/*    */   }




/*    */   public Collection<ServiceInfo> getAllServices()
/*    */   {
/* 57 */     return this.map.values();
/*    */   }





/*    */   public SchemaTypeSystem getCompiledSchema()
/*    */   {
/* 66 */     return this.compiledScehma;
/*    */   }
/*    */ }
