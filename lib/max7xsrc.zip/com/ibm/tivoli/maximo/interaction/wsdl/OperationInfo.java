/*     */ package com.ibm.tivoli.maximo.interaction.wsdl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.jdom.Document;
/*     */ 


















/*     */ public class OperationInfo
/*     */ {
/*     */   private String name;
/*     */   private String soapAction;
/*     */   private QName inputElement;
/*     */   private QName outputElement;
/*     */   private String mep;
/*     */   private Document inputSample;
/*     */   private Document outputSample;
/*     */ 
/*     */   public OperationInfo()
/*     */   {
/*  36 */     this.inputSample = null;
/*  37 */     this.outputSample = null;
/*     */   }



/*     */   public QName getInputElement()
/*     */   {
/*  44 */     return this.inputElement;
/*     */   }



/*     */   void setInputElement(QName inputElement)
/*     */   {
/*  51 */     this.inputElement = inputElement;
/*     */   }



/*     */   public String getMep()
/*     */   {
/*  58 */     return this.mep;
/*     */   }



/*     */   void setMep(String mep)
/*     */   {
/*  65 */     this.mep = mep;
/*     */   }



/*     */   public String getName()
/*     */   {
/*  72 */     return this.name;
/*     */   }



/*     */   void setName(String name)
/*     */   {
/*  79 */     this.name = name;
/*     */   }



/*     */   public QName getOutputElement()
/*     */   {
/*  86 */     return this.outputElement;
/*     */   }



/*     */   void setOutputElement(QName outputElement)
/*     */   {
/*  93 */     this.outputElement = outputElement;
/*     */   }



/*     */   public String getSoapAction()
/*     */   {
/* 100 */     return this.soapAction;
/*     */   }



/*     */   void setSoapAction(String soapAction)
/*     */   {
/* 107 */     this.soapAction = soapAction;
/*     */   }

/*     */   public String toString()
/*     */   {
/* 112 */     return this.name + " soapAction:: " + this.soapAction + " input:: " + this.inputElement.getLocalPart() + " output:: " + this.outputElement.getLocalPart();
/*     */   }



/*     */   public Document getInputSample()
/*     */   {
/* 119 */     return this.inputSample;
/*     */   }



/*     */   void setInputSample(Document inputSample)
/*     */   {
/* 126 */     this.inputSample = inputSample;
/*     */   }



/*     */   public Document getOutputSample()
/*     */   {
/* 133 */     return this.outputSample;
/*     */   }



/*     */   void setOutputSample(Document outputSample)
/*     */   {
/* 140 */     this.outputSample = outputSample;
/*     */   }
/*     */ }
