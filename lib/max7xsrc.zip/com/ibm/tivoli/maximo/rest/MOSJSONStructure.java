/*      */ package com.ibm.tivoli.maximo.rest;
/*      */ 
/*      */ import com.ibm.json.java.JSONArray;
/*      */ import com.ibm.json.java.OrderedJSONObject;
/*      */ import java.rmi.RemoteException;
/*      */ import java.util.Arrays;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.axiom.om.util.Base64;
/*      */ import psdi.iface.mic.MicUtil;
/*      */ import psdi.iface.mos.ConversionUtil;
/*      */ import psdi.iface.mos.IfaceColumnInfo;
/*      */ import psdi.iface.mos.MboIterator;
/*      */ import psdi.iface.mos.MboSetIterator;
/*      */ import psdi.iface.mos.MosConstants;/*      */ import psdi.iface.mos.MosDefinitionImpl;/*      */ import psdi.iface.mos.MosDetailInfo;/*      */ import psdi.iface.mos.MosInfo;/*      */ import psdi.iface.mos.ObjectStructureCache;/*      */ import psdi.iface.util.XMLUtils;/*      */ import psdi.mbo.Mbo;/*      */ import psdi.mbo.MboRemote;/*      */ import psdi.mbo.MboSetInfo;/*      */ import psdi.mbo.MboSetRemote;/*      */ import psdi.mbo.MboValueData;/*      */ import psdi.mbo.MboValueInfo;/*      */ import psdi.server.MXServer;/*      */ import psdi.util.BitFlag;/*      */ import psdi.util.MXApplicationException;/*      */ import psdi.util.MXCipher;/*      */ import psdi.util.MXException;/*      */ import psdi.util.MXFormat;/*      */ import psdi.util.MXSystemException;/*      */ import psdi.util.logging.MXLogger;/*      */ import psdi.util.logging.MXLoggerFactory;/*      */ 
/*      */ public class MOSJSONStructure
/*      */   implements MosConstants
/*      */ {
/*      */   protected String mosName;
/*      */   protected boolean verbose;
/*      */   protected boolean dropNulls;
/*      */   protected boolean locale;
/*      */   protected boolean retainMbos;
/*      */   protected boolean rootOnly;
/*      */   protected boolean metaData;
/*      */   protected String defClassName;
/*      */   private boolean selfRefMos;
/*      */   private MosDefinitionImpl msi;
/*      */   private MosInfo mosInfo;
/*      */   private boolean generic;
/*      */   private boolean keys;
/*      */   private String operation;
/*      */   protected boolean compact;
/*      */   protected boolean calculateEtag;
/*      */   private StringBuilder rsBuffer;
/*      */   protected boolean useTotalCount;
/*      */   private int resolvedTotalCount;
/*      */   private int initialResolvedCount;
/*      */   private int resolvedStartCount;
/*   73 */   private static MXLogger logger = MXLoggerFactory.getLogger("maximo.rest");
/*      */ 
/*      */   public MOSJSONStructure(MosInfo mosInfo, String operation, boolean verbose, boolean dropNulls, boolean locale, boolean retainMbos, boolean generic, boolean keys, boolean rootOnly, boolean metaData, boolean compact, boolean calculateEtag, boolean useTotalCount)
/*      */     throws MXException
/*      */   {
/*   49 */     this.verbose = false;
/*   50 */     this.dropNulls = true;
/*   51 */     this.locale = false;
/*   52 */     this.retainMbos = false;
/*   53 */     this.rootOnly = false;
/*   54 */     this.metaData = false;

/*      */ 
/*   57 */     this.selfRefMos = false;
/*   58 */     this.msi = null;
/*   59 */     this.mosInfo = null;
/*   60 */     this.generic = false;
/*   61 */     this.keys = false;
/*      */ 
/*   63 */     this.compact = false;
/*   64 */     this.calculateEtag = true;
/*   65 */     this.rsBuffer = null;
/*   66 */     this.useTotalCount = true;
/*      */ 
/*   68 */     this.resolvedTotalCount = -1;
/*   69 */     this.initialResolvedCount = -1;
/*   70 */     this.resolvedStartCount = -1;





/*      */   public MOSJSONStructure(String mosName, String operation, boolean verbose, boolean dropNulls, boolean locale, boolean retainMbos, boolean generic, boolean keys, boolean rootOnly, boolean metaData, boolean compact, boolean calculateEtag, boolean useTotalCount)
/*      */     throws MXException
/*      */   {
/*   79 */     this(ObjectStructureCache.getInstance().getMosInfo(mosName), operation, verbose, dropNulls, locale, retainMbos, generic, keys, rootOnly, metaData, compact, calculateEtag, useTotalCount);
/*      */   }






/*      */ 
/*   88 */     this.mosInfo = mosInfo;
/*   89 */     this.mosName = mosInfo.getIntObjectName();
/*   90 */     this.verbose = verbose;
/*   91 */     this.dropNulls = dropNulls;
/*   92 */     this.locale = locale;
/*   93 */     this.retainMbos = retainMbos;
/*   94 */     this.operation = operation;
/*   95 */     this.keys = keys;
/*   96 */     this.rootOnly = rootOnly;
/*   97 */     this.generic = generic;
/*   98 */     this.metaData = metaData;
/*   99 */     this.compact = compact;
/*  100 */     this.calculateEtag = calculateEtag;
/*  101 */     this.useTotalCount = useTotalCount;
/*  102 */     if (compact)
/*      */     {
/*  104 */       metaData = false;
/*  105 */       generic = false;
/*      */     }
/*      */ 
/*  108 */     this.defClassName = mosInfo.getDefClass();
/*  109 */     this.selfRefMos = mosInfo.isSelfReferencing();
/*  110 */     this.defClassName = ((this.defClassName == null) ? "psdi.iface.mos.MosDefinitionImpl" : this.defClassName);
/*      */     try
/*      */     {
/*  113 */       this.msi = ((MosDefinitionImpl)Class.forName(this.defClassName).newInstance());
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  117 */       throw new MXApplicationException("iface", "instclass", e);
/*      */     }
/*  119 */     this.msi.setOSName(this.mosName);
/*  120 */     if (logger.isDebugEnabled())
/*      */     {
/*  122 */       logger.debug("MOSJSONStructure defClassName=" + this.defClassName);
/*      */     }
/*  124 */     if (!(calculateEtag))
/*      */       return;
/*  126 */     this.rsBuffer = new StringBuilder();
/*      */   }



/*      */   public String getCalculatedEtag()
/*      */   {
/*  133 */     if (this.calculateEtag)
/*      */     {
/*  135 */       return String.valueOf(this.rsBuffer.toString().hashCode());
/*      */     }
/*  137 */     return null;
/*      */   }

/*      */   public byte[] serializeMboSet(MboSetRemote mboSet)
/*      */     throws MXException, RemoteException
/*      */   {
/*  143 */     return serializeMboSet(new MboSetIterator(mboSet), 0, mboSet.count());
/*      */   }

/*      */   public byte[] serializeMboSet(MboIterator mboSet) throws MXException, RemoteException
/*      */   {
/*  148 */     return serializeMboSet(mboSet, 0, mboSet.count());
/*      */   }

/*      */   public byte[] serializeMboSet(OrderedJSONObject opOjo, MboIterator mboSet) throws MXException, RemoteException
/*      */   {
/*  153 */     return serializeMboSet(opOjo, mboSet, 0, mboSet.count());
/*      */   }

/*      */   public byte[] serializeMboSet(MboSetRemote mboSet, int startIndex, int maxCount)
/*      */     throws MXException, RemoteException
/*      */   {
/*  159 */     return serializeMboSet(new MboSetIterator(mboSet), startIndex, maxCount);
/*      */   }

/*      */   public OrderedJSONObject serializeMboSetAsJSONObject(MboSetRemote mboSet, int startIndex, int maxCount)
/*      */     throws MXException, RemoteException
/*      */   {
/*  165 */     return serializeMboSetAsJSONObject(null, new MboSetIterator(mboSet), startIndex, maxCount);
/*      */   }

/*      */   public OrderedJSONObject serializeMboSetAsJSONObject(MboIterator mboSet, int startIndex, int maxCount)
/*      */     throws MXException, RemoteException
/*      */   {
/*  171 */     return serializeMboSetAsJSONObject(null, mboSet, startIndex, maxCount);
/*      */   }

/*      */   public byte[] serializeMboSet(MboIterator mboSet, int startIndex, int maxCount)
/*      */     throws MXException, RemoteException
/*      */   {
/*  177 */     return serializeMboSet(null, mboSet, startIndex, maxCount);
/*      */   }

/*      */   public byte[] serializeMboSet(OrderedJSONObject opOjo, MboIterator mboSet, int startIndex, int maxCount)
/*      */     throws MXException, RemoteException
/*      */   {
/*  183 */     OrderedJSONObject ojo = serializeMboSetAsJSONObject(opOjo, mboSet, startIndex, maxCount);
/*  184 */     return ((ojo == null) ? null : covertJSONObjectToBytes(ojo));
/*      */   }

/*      */   public byte[] covertJSONObjectToBytes(OrderedJSONObject ojo) throws MXSystemException
/*      */   {
/*      */     try
/*      */     {
/*  191 */       return ojo.serialize(this.verbose).getBytes("utf-8");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  195 */       throw new MXSystemException("iface", "mbojsonerror", e);
/*      */     }
/*      */   }


/*      */   public OrderedJSONObject serializeMboSetAsJSONObject(OrderedJSONObject opOjo, MboIterator mboSet, int startIndex, int maxCount)
/*      */     throws MXException, RemoteException
/*      */   {
/*      */     try
/*      */     {
/*  205 */       if (logger.isDebugEnabled())
/*      */       {
/*  207 */         logger.debug("MOSJSONStructure serializeMboSet=" + mboSet);
/*      */       }
/*  209 */       OrderedJSONObject ojo = new OrderedJSONObject();
/*  210 */       OrderedJSONObject osRootOjo = null;
/*      */ 
/*  212 */       if (opOjo == null)
/*      */       {
/*  214 */         osRootOjo = new OrderedJSONObject();
/*  215 */         if (!(this.generic))
/*      */         {
/*  217 */           ojo.put(this.operation + this.mosName + "Response", osRootOjo);
/*      */         }
/*      */         else
/*      */         {
/*  221 */           ojo.put("OSResponse", osRootOjo);
/*  222 */           osRootOjo.put("name", this.mosName);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  227 */         osRootOjo = opOjo;
/*  228 */         if (this.generic)





/*      */         {
/*  235 */           osRootOjo.put("name", this.mosName);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  240 */       int rsStart = (startIndex < 0) ? 0 : startIndex;
/*  241 */       int rsTotal = 0;
/*  242 */       int databaseCount = 0;
/*  243 */       int nounSize = 0;
/*  244 */       if (this.useTotalCount)
/*      */       {
/*  246 */         rsTotal = mboSet.count();
/*  247 */         databaseCount = rsTotal - rsStart;
/*  248 */         nounSize = (maxCount > 0) ? Math.min(databaseCount, maxCount) : databaseCount;
/*      */       }
/*      */ 
/*  251 */       int rsCount = nounSize;
/*  252 */       if (this.resolvedStartCount >= 0)
/*      */       {
/*  254 */         osRootOjo.put("rsStart", Integer.valueOf(rsStart));
/*      */       }
/*      */       else
/*      */       {
/*  258 */         osRootOjo.put("rsStart", Integer.valueOf(rsStart));
/*      */       }
/*  260 */       osRootOjo.put("rsCount", Integer.valueOf(rsCount));
/*      */ 
/*  262 */       if (this.useTotalCount)
/*      */       {
/*  264 */         if (this.resolvedTotalCount >= 0)
/*      */         {
/*  266 */           osRootOjo.put("rsTotal", Integer.valueOf(this.resolvedTotalCount));
/*      */         }
/*      */         else
/*      */         {
/*  270 */           osRootOjo.put("rsTotal", Integer.valueOf(rsTotal));
/*      */         }
/*      */       }
/*      */ 
/*  274 */       if (!(this.retainMbos))
/*      */       {
/*  276 */         mboSet.setDiscardable();
/*      */       }
/*      */ 
/*  279 */       MosDetailInfo primaryInfo = this.mosInfo.getPrimaryMosDetailInfo();
/*  280 */       if (logger.isDebugEnabled())
/*      */       {
/*  282 */         logger.debug("MOSJSONStructure serializeMboSet primaryInfo=" + primaryInfo);

/*      */       }
/*      */ 
/*  286 */       OrderedJSONObject osOjo = new OrderedJSONObject();

/*      */ 
/*  289 */       if (!(this.generic))
/*      */       {
/*  291 */         osRootOjo.put(this.mosName + "Set", osOjo);
/*      */       }
/*      */       else
/*      */       {
/*  295 */         osRootOjo.put("OSSet", osOjo);

/*      */       }
/*      */ 
/*  299 */       if (logger.isDebugEnabled())
/*      */       {
/*  301 */         logger.debug("will serialize " + rsStart + " to " + (nounSize + rsStart));
/*  302 */         logger.debug("rsCount=" + rsCount);

/*      */       }
/*      */ 
/*  306 */       JSONArray mboSetArray = new JSONArray();
/*  307 */       int i = rsStart;
/*  308 */       MboRemote mbo = mboSet.get(i);
/*  309 */       int skipCount = 0;
/*  310 */       while (mbo != null)
/*      */       {
/*  312 */         OrderedJSONObject mboOjo = new OrderedJSONObject();
/*  313 */         MosDetailInfo mosDetailInfo = this.mosInfo.getPrimaryMosDetailInfo();
/*  314 */         int retCode = mbo2JSONObject(mbo, mboOjo, mosDetailInfo, true);
/*  315 */         if (retCode != 3)
/*      */         {
/*  317 */           mboSetArray.add(mboOjo);
/*      */         }
/*      */         else
/*      */         {
/*  321 */           ++skipCount;
/*      */         }
/*      */ 
/*  324 */         ++i;



/*      */ 
/*  329 */         if ((maxCount > 0) && (i >= rsStart + maxCount))
/*      */           break;
/*  331 */         mbo = mboSet.get(i);
/*      */       }
/*  333 */       osRootOjo.put("rsCount", Integer.valueOf(i - (rsStart + skipCount)));









/*      */ 
/*  344 */       if (mboSetArray.size() > 0)
/*      */       {
/*  346 */         if (!(this.generic))
/*      */         {
/*  348 */           osOjo.put(primaryInfo.getObjectName(), mboSetArray);
/*      */         }
/*      */         else
/*      */         {
/*  352 */           osOjo.put("Mbo", mboSetArray);
/*      */         }
/*      */       }
/*  355 */       if (opOjo != null) return null;
/*  356 */       return ojo;

/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  361 */       logger.error(t.getMessage(), t); }
/*  362 */     return null;
/*      */   }

/*      */   public byte[] serializeMbo(MboRemote mbo)
/*      */     throws MXException, RemoteException
/*      */   {
/*  368 */     return serializeMbo(null, mbo);
/*      */   }

/*      */   public OrderedJSONObject serializeMboAsJSONObject(MboRemote mbo) throws MXException, RemoteException
/*      */   {
/*  373 */     return serializeMboAsJSONObject(null, mbo);
/*      */   }

/*      */   public byte[] serializeMbo(OrderedJSONObject opOjo, MboRemote mbo) throws MXException, RemoteException
/*      */   {
/*  378 */     OrderedJSONObject ojo = serializeMboAsJSONObject(opOjo, mbo);
/*  379 */     return ((ojo == null) ? null : covertJSONObjectToBytes(ojo));
/*      */   }

/*      */   public OrderedJSONObject serializeMboAsJSONObject(OrderedJSONObject opOjo, MboRemote mbo) throws MXException, RemoteException
/*      */   {
/*  384 */     OrderedJSONObject ojo = new OrderedJSONObject();
/*  385 */     OrderedJSONObject osRootOjo = null;
/*  386 */     if (opOjo == null)
/*      */     {
/*  388 */       osRootOjo = new OrderedJSONObject();
/*  389 */       if (!(this.generic))
/*      */       {
/*  391 */         ojo.put(this.operation + this.mosName + "Response", osRootOjo);
/*      */       }
/*      */       else
/*      */       {
/*  395 */         ojo.put("OSResponse", osRootOjo);
/*  396 */         osRootOjo.put("name", this.mosName);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  401 */       osRootOjo = opOjo;
/*  402 */       if (this.generic)





/*      */       {
/*  409 */         osRootOjo.put("name", this.mosName);
/*      */       }
/*      */     }
/*      */ 
/*  413 */     osRootOjo.put("rsStart", Integer.valueOf(0));
/*  414 */     osRootOjo.put("rsCount", Integer.valueOf(1));
/*  415 */     osRootOjo.put("rsTotal", Integer.valueOf(1));






/*      */ 
/*  423 */     OrderedJSONObject osOjo = new OrderedJSONObject();
/*  424 */     if (!(this.generic))
/*      */     {
/*  426 */       osRootOjo.put(this.mosName + "Set", osOjo);
/*      */     }
/*      */     else
/*      */     {
/*  430 */       osRootOjo.put("OSSet", osOjo);











/*      */     }
/*      */ 
/*  444 */     OrderedJSONObject mboOjo = new OrderedJSONObject();







/*      */ 
/*  453 */     MosDetailInfo mosDetailInfo = this.mosInfo.getPrimaryMosDetailInfo();
/*  454 */     if (!(this.generic))
/*      */     {
/*  456 */       osOjo.put(mosDetailInfo.getObjectName(), mboOjo);
/*      */     }
/*      */     else
/*      */     {
/*  460 */       osOjo.put("Mbo", mboOjo);
/*  461 */       mboOjo.put("name", mosDetailInfo.getObjectName());
/*      */     }
/*  463 */     mbo2JSONObject(mbo, mboOjo, mosDetailInfo, true);
/*  464 */     if (opOjo != null) return null;
/*  465 */     return ojo;
/*      */   }


/*      */   protected int mbo2JSONObject(MboRemote mbo, OrderedJSONObject mboOjo, MosDetailInfo mosDetailInfo, boolean headerObject)
/*      */     throws RemoteException, MXException
/*      */   {
/*  472 */     if ((this.rootOnly) && (!(headerObject)))
/*      */     {
/*  474 */       return 4;
/*      */     }
/*  476 */     if (headerObject)
/*      */     {
/*  478 */       this.msi.setOSPrimaryMbo(mbo);
/*      */     }
/*  480 */     if (this.generic)
/*      */     {
/*  482 */       mboOjo.put("name", mosDetailInfo.getObjectName());
/*      */     }
/*  484 */     Map ovrdColValueMap = new HashMap();
/*  485 */     int retCode = this.msi.checkBusinessRules(mbo, mosDetailInfo, ovrdColValueMap);
/*  486 */     if (retCode == 2)
/*      */     {
/*  488 */       throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*      */     }
/*  490 */     if (retCode == 3)
/*      */     {
/*  492 */       if (headerObject)
/*      */       {
/*  494 */         throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*      */       }
/*  496 */       return 3;
/*      */     }
/*  498 */     if (retCode == 4)
/*      */     {
/*  500 */       return 4;
/*      */     }
/*      */ 
/*  503 */     if (this.calculateEtag)
/*      */     {
/*  505 */       String rs = ((Mbo)mbo).getRowStamp();
/*  506 */       this.rsBuffer.append(rs);
/*      */     }
/*      */ 
/*  509 */     Set colsToSkip = this.msi.getColumnsToSkip(mbo);
/*      */ 
/*  511 */     if (this.metaData)
/*      */     {
/*  513 */       if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(263L))
/*      */       {
/*  515 */         mboOjo.put("hidden", Boolean.valueOf(true));
/*      */       }
/*      */       else
/*      */       {
/*  519 */         mboOjo.put("hidden", Boolean.valueOf(false));
/*      */       }
/*      */ 
/*  522 */       if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(7L))
/*      */       {
/*  524 */         mboOjo.put("readonly", Boolean.valueOf(true));
/*      */       }
/*      */       else
/*      */       {
/*  528 */         mboOjo.put("readonly", Boolean.valueOf(false));
/*      */       }
/*      */     }
/*      */ 
/*  532 */     Map columns = mosDetailInfo.getColumns();
/*  533 */     Set colsSet = columns.keySet();
/*      */     OrderedJSONObject attributesOjo;/*  534 */     if (this.compact)
/*      */     {
/*  536 */       for (String column : colsSet)
/*      */       {
/*  538 */         if ((colsToSkip == null) || (!(colsToSkip.contains(column))));
/*  539 */         IfaceColumnInfo colInfo = (IfaceColumnInfo)columns.get(column);
/*  540 */         MboValueInfo mboValueInfo = colInfo.getMboValueInfo();
/*      */ 
/*  542 */         setJSONObjectAttribute(mboValueInfo, mbo, mboOjo, ovrdColValueMap.get(column), ovrdColValueMap.containsKey(column));
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  548 */       attributesOjo = new OrderedJSONObject();
/*  549 */       mboOjo.put("Attributes", attributesOjo);
/*  550 */       for (String column : colsSet)
/*      */       {
/*  552 */         if ((colsToSkip == null) || (!(colsToSkip.contains(column))));
/*  553 */         IfaceColumnInfo colInfo = (IfaceColumnInfo)columns.get(column);
/*  554 */         MboValueInfo mboValueInfo = colInfo.getMboValueInfo();
/*  555 */         setJSONObjectAttribute(mboValueInfo, mbo, attributesOjo, ovrdColValueMap.get(column), ovrdColValueMap.containsKey(column));
/*      */       }
/*      */     }
/*  558 */     this.msi.postSerializationRules(mbo, mosDetailInfo);
/*      */ 
/*  560 */     List children = mosDetailInfo.getChildren();
/*  561 */     if (logger.isDebugEnabled())
/*      */     {
/*  563 */       logger.debug("children=" + children);
/*      */     }
/*  565 */     if (children != null)
/*      */     {
/*  567 */       OrderedJSONObject relatedMbosOjo = null;
/*  568 */       if (!(this.compact))
/*      */       {
/*  570 */         relatedMbosOjo = new OrderedJSONObject();
/*      */       }
/*      */       else
/*      */       {
/*  574 */         relatedMbosOjo = mboOjo;
/*      */       }
/*      */ 
/*  577 */       JSONArray childJSONArray = null;
/*  578 */       if (this.generic)
/*      */       {
/*  580 */         childJSONArray = new JSONArray();
/*      */       }
/*  582 */       for (int i = 0; i < children.size(); ++i)
/*      */       {
/*  584 */         MosDetailInfo childInfo = (MosDetailInfo)children.get(i);
/*  585 */         if (logger.isDebugEnabled())
/*      */         {
/*  587 */           logger.debug("childInfo=" + childInfo);
/*      */         }
/*      */ 
/*  590 */         MboSetRemote childMboSet = mbo.getMboSet(childInfo.getRelation());
/*  591 */         if (!(this.retainMbos))
/*      */         {
/*  593 */           childMboSet.setFlag(39L, true);
/*      */         }
/*  595 */         int mboIndex = 0;
/*      */ 
/*  597 */         if (!(this.generic))
/*      */         {
/*  599 */           childJSONArray = new JSONArray();
/*      */         }
/*      */ 
/*  602 */         MboRemote childMbo = childMboSet.getMbo(mboIndex);
/*  603 */         if (logger.isDebugEnabled())
/*      */         {
/*  605 */           logger.debug(childMboSet.getName() + " the mbo for mboIndex=" + mboIndex + " is=" + childMbo);
/*      */         }
/*  607 */         while (childMbo != null)
/*      */         {
/*  609 */           OrderedJSONObject childMboOjo = new OrderedJSONObject();
/*  610 */           retCode = mbo2JSONObject(childMbo, childMboOjo, childInfo, false);
/*  611 */           if (retCode != 3)
/*      */           {
/*  613 */             childJSONArray.add(childMboOjo);
/*  614 */             if (retCode == 4)
/*      */             {
/*  616 */               return retCode;
/*      */             }
/*      */           }
/*  619 */           childMbo = childMboSet.getMbo(++mboIndex);
/*      */         }
/*  621 */         if ((childJSONArray.size() <= 0) || (this.generic))
/*      */           continue;
/*  623 */         relatedMbosOjo.put(childInfo.getObjectName(), childJSONArray);
/*      */       }
/*      */ 
/*  626 */       if ((childJSONArray.size() > 0) && (this.generic))
/*      */       {
/*  628 */         relatedMbosOjo.put("Mbo", childJSONArray);
/*      */       }
/*  630 */       if ((!(this.compact)) && (!(relatedMbosOjo.isEmpty())))
/*      */       {
/*  632 */         mboOjo.put("RelatedMbos", relatedMbosOjo);
/*      */       }
/*      */     }
/*      */ 
/*  636 */     if ((this.selfRefMos) && (mosDetailInfo.isPrimaryTable()))

/*      */     {
/*  639 */       OrderedJSONObject childrenMbosOjo = null;
/*  640 */       if (!(this.compact))
/*      */       {
/*  642 */         childrenMbosOjo = new OrderedJSONObject();
/*      */       }
/*      */       else
/*      */       {
/*  646 */         childrenMbosOjo = mboOjo;
/*      */       }
/*      */ 
/*  649 */       MboSetRemote selfRefChildSet = mbo.getMboSet(mosDetailInfo.getRelation());




/*      */ 
/*  655 */       JSONArray hierchChildrenArray = (JSONArray)childrenMbosOjo.get(mosDetailInfo.getObjectName());
/*  656 */       if (hierchChildrenArray == null)
/*      */       {
/*  658 */         hierchChildrenArray = new JSONArray();
/*      */ 
/*  660 */         if (!(this.generic))
/*      */         {
/*  662 */           childrenMbosOjo.put(mosDetailInfo.getObjectName(), hierchChildrenArray);
/*      */         }
/*      */         else
/*      */         {
/*  666 */           childrenMbosOjo.put("Mbo", hierchChildrenArray);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  671 */       MboRemote cmbo = selfRefChildSet.moveFirst();
/*      */ 
/*  673 */       while (cmbo != null)
/*      */       {
/*  675 */         OrderedJSONObject hierchChildMboOjo = new OrderedJSONObject();
/*      */ 
/*  677 */         int hierchChildRetCode = mbo2JSONObject(cmbo, hierchChildMboOjo, mosDetailInfo, false);
/*  678 */         if (hierchChildRetCode != 3)
/*      */         {
/*  680 */           hierchChildrenArray.add(hierchChildMboOjo);
/*  681 */           if (hierchChildRetCode == 4)
/*      */           {
/*  683 */             return hierchChildRetCode;
/*      */           }
/*      */         }
/*  686 */         cmbo = selfRefChildSet.moveNext();
/*      */       }
/*  688 */       if ((!(this.compact)) && (hierchChildrenArray.size() > 0) && (!(childrenMbosOjo.isEmpty())))
/*      */       {
/*  690 */         mboOjo.put("ChildrenMbos", childrenMbosOjo);
/*      */       }
/*      */     }
/*  693 */     return 1;
/*      */   }

/*      */   public boolean isKey(MboRemote mbo, String mboAttrName)
/*      */     throws RemoteException, MXException
/*      */   {
/*  699 */     MboSetInfo mboSetInfo = mbo.getThisMboSet().getMboSetInfo();
/*  700 */     if (mboSetInfo.isPersistent())
/*      */     {
/*  702 */       MboValueInfo mboValueInfo = mboSetInfo.getMboValueInfo(mboAttrName);
/*  703 */       String uniqueIdColName = mbo.getThisMboSet().getMboSetInfo().getUniqueIDName();
/*  704 */       String[] altkeys = MicUtil.getKeyArray(mbo.getName());


/*      */ 
/*  708 */       return ((mboValueInfo.isKey()) || (uniqueIdColName.equalsIgnoreCase(mboAttrName)) || (Arrays.binarySearch(altkeys, mboAttrName) >= 0));

/*      */     }
/*      */ 
/*  712 */     return true;
/*      */   }



/*      */   protected void setJSONObjectAttribute(MboValueInfo mboValueInfo, MboRemote mbo, OrderedJSONObject mboOjo, Object ovrdColValue, boolean overridden)
/*      */     throws RemoteException, MXException
/*      */   {
/*  720 */     String attributeName = mboValueInfo.getName();
/*  721 */     if ((this.keys) && (!(isKey(mbo, attributeName))))
/*      */     {
/*  723 */       return;
/*      */     }
/*      */ 
/*  726 */     if (attributeName.endsWith("_BASELANGUAGE")) return;
/*      */ 
/*  728 */     byte[] attachedDoc = null;
/*  729 */     boolean attachmentCol = false;
/*  730 */     if ((mbo.getName().equals("DOCLINKS")) && (mbo.getString("urltype").equals("FILE")) && (attributeName.equalsIgnoreCase("DOCUMENTDATA")))
/*      */     {
/*  732 */       attachmentCol = true;
/*  733 */       attachedDoc = XMLUtils.readXMLFileToBytes(mbo.getString("urlname"));
/*      */     }
/*      */ 
/*  736 */     if (this.dropNulls)
/*      */     {
/*  738 */       if (overridden)
/*      */       {
/*  740 */         if (ovrdColValue == null)
/*      */         {
/*  742 */           if (logger.isDebugEnabled())
/*      */           {
/*  744 */             logger.debug("dropping null column " + attributeName + " for mbo " + mbo.getName() + " due to override as null");
/*      */           }
/*  746 */           return;
/*      */         }
/*      */       }
/*  749 */       else if (((attachmentCol) && (attachedDoc == null)) || (mbo.isNull(attributeName)))
/*      */       {
/*  751 */         if (logger.isDebugEnabled())
/*      */         {
/*  753 */           logger.debug("dropping null column " + attributeName + " for mbo " + mbo.getName());
/*      */         }
/*  755 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  760 */     int maxType = mboValueInfo.getTypeAsInt();
/*  761 */     if (maxType == 16)
/*      */     {
/*  763 */       return;
/*      */     }
/*      */ 
/*  766 */     OrderedJSONObject attrObject = new OrderedJSONObject();
/*  767 */     if (!(this.generic))
/*      */     {
/*  769 */       if (!(this.compact))
/*      */       {
/*  771 */         mboOjo.put(attributeName, attrObject);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  776 */       JSONArray jsonArray = (JSONArray)mboOjo.get("Attribute");
/*  777 */       if (jsonArray == null)
/*      */       {
/*  779 */         jsonArray = new JSONArray();
/*  780 */         mboOjo.put("Attribute", jsonArray);
/*      */       }
/*  782 */       attrObject.put("name", attributeName);
/*  783 */       jsonArray.add(attrObject);
/*      */     }
/*  785 */     if (this.metaData)
/*      */     {
/*  787 */       if (((Mbo)mbo).getAttrRestrictionFlag(attributeName).isFlagSet(263L))
/*      */       {
/*  789 */         attrObject.put("hidden", Boolean.valueOf(true));
/*      */       }
/*      */       else
/*      */       {
/*  793 */         attrObject.put("hidden", Boolean.valueOf(false));
/*      */       }
/*      */ 
/*  796 */       if (((Mbo)mbo).getAttrRestrictionFlag(attributeName).isFlagSet(7L))
/*      */       {
/*  798 */         attrObject.put("readonly", Boolean.valueOf(true));
/*      */       }
/*      */       else
/*      */       {
/*  802 */         attrObject.put("readonly", Boolean.valueOf(false));
/*      */       }
/*      */ 
/*  805 */       if ((((Mbo)mbo).getAttrRestrictionFlag(attributeName).isFlagSet(128L)) || (mboValueInfo.isRequired()))
/*      */       {
/*  807 */         attrObject.put("required", Boolean.valueOf(true));
/*      */       }
/*      */       else
/*      */       {
/*  811 */         attrObject.put("required", Boolean.valueOf(false));
/*      */       }
/*      */     }
/*      */ 
/*  815 */     boolean uniqueId = false;
/*  816 */     if (mbo.getUniqueIDName().equals(attributeName))
/*      */     {
/*  818 */       uniqueId = true;
/*      */     }
/*  820 */     if (logger.isDebugEnabled())
/*      */     {
/*  822 */       logger.debug("attribute name==" + attributeName + " value =" + mbo.getMboValueData(attributeName).getDataAsObject());
/*      */     }
/*  824 */     Locale clientLocale = ((Mbo)mbo).getClientLocale();
/*  825 */     switch (maxType)
/*      */     {
/*      */     case 0:
/*      */     case 1:
/*      */     case 2:
/*      */     case 13:
/*      */     case 14:
/*      */     case 17:
/*  833 */       String jsonData = (overridden) ? (String)ovrdColValue : mbo.getString(attributeName);
/*  834 */       if (!(this.compact))
/*      */       {
/*  836 */         attrObject.put("content", jsonData);
/*  837 */         if (!(this.locale))
/*      */           return;
/*  839 */         attrObject.put("localecontent", jsonData); return;


/*      */       }
/*      */ 
/*  844 */       mboOjo.put(attributeName, jsonData);
/*      */ 
/*  846 */       break;
/*      */     case 15:
/*  848 */       String base64PasswordData = null;
/*      */ 
/*  850 */       String clearTextVal = (overridden) ? (String)ovrdColValue : mbo.getString(attributeName);
/*  851 */       if (clearTextVal != null)
/*      */       {
/*  853 */         byte[] encData = MXServer.getMXServer().getMXCipher().encData(clearTextVal);
/*  854 */         base64PasswordData = Base64.encode(encData);
/*      */       }
/*      */ 
/*  857 */       if (!(this.compact))
/*      */       {
/*  859 */         attrObject.put("content", base64PasswordData);
/*  860 */         if (!(this.locale))
/*      */           return;
/*  862 */         attrObject.put("localecontent", base64PasswordData); return;


/*      */       }
/*      */ 
/*  867 */       mboOjo.put(attributeName, base64PasswordData);
/*      */ 
/*  869 */       break;
/*      */     case 6:
/*      */     case 7:
/*      */     case 19:
/*  873 */       long jsonLData = (overridden) ? ((Long)ovrdColValue).longValue() : mbo.getLong(attributeName);
/*  874 */       if (!(this.compact))
/*      */       {
/*  876 */         if (!(uniqueId))
/*      */         {
/*  878 */           attrObject.put("content", Long.valueOf(jsonLData));
/*      */         }
/*      */         else
/*      */         {
/*  882 */           attrObject.put("content", Long.valueOf(jsonLData));
/*  883 */           attrObject.put("resourceid", Boolean.valueOf(true));
/*      */         }
/*      */ 
/*  886 */         if (!(this.locale))
/*      */           return;
/*  888 */         String localeData = MXFormat.longToString(jsonLData, clientLocale);
/*  889 */         attrObject.put("localecontent", localeData);
/*  890 */         return;

/*      */       }
/*      */ 
/*  894 */       if (this.locale)
/*      */       {
/*  896 */         mboOjo.put(attributeName, MXFormat.longToString(jsonLData, clientLocale)); return;

/*      */       }
/*      */ 
/*  900 */       mboOjo.put(attributeName, Long.valueOf(jsonLData));

/*      */ 
/*  903 */       break;
/*      */     case 8:
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*  908 */       double jsonDData = (overridden) ? ((Double)ovrdColValue).doubleValue() : mbo.getDouble(attributeName);
/*  909 */       if (!(this.compact))
/*      */       {
/*  911 */         attrObject.put("content", Double.valueOf(jsonDData));
/*  912 */         if (!(this.locale))
/*      */           return;
/*  914 */         attrObject.put("localecontent", MXFormat.doubleToString(jsonDData, clientLocale)); return;


/*      */       }
/*      */ 
/*  919 */       if (this.locale)
/*      */       {
/*  921 */         mboOjo.put(attributeName, MXFormat.doubleToString(jsonDData, clientLocale)); return;

/*      */       }
/*      */ 
/*  925 */       mboOjo.put(attributeName, Double.valueOf(jsonDData));

/*      */ 
/*  928 */       break;
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*  932 */       Date jsonDTData = (overridden) ? (Date)ovrdColValue : mbo.getDate(attributeName);
/*  933 */       if (!(this.compact))
/*      */       {
/*  935 */         attrObject.put("content", (mbo.isNull(attributeName)) ? null : ConversionUtil.dateToString(jsonDTData));
/*  936 */         if (!(this.locale))
/*      */           return;
/*  938 */         attrObject.put("localecontent", MXFormat.dateToString(jsonDTData, clientLocale, ((Mbo)mbo).getClientTimeZone())); return;


/*      */       }
/*      */ 
/*  943 */       if (this.locale)
/*      */       {
/*  945 */         mboOjo.put(attributeName, MXFormat.dateToString(jsonDTData, clientLocale, ((Mbo)mbo).getClientTimeZone())); return;

/*      */       }
/*      */ 
/*  949 */       mboOjo.put(attributeName, (mbo.isNull(attributeName)) ? null : ConversionUtil.dateToString(jsonDTData));

/*      */ 
/*  952 */       break;
/*      */     case 12:
/*  954 */       boolean jsonBool = (overridden) ? ((Boolean)ovrdColValue).booleanValue() : mbo.getBoolean(attributeName);
/*  955 */       if (!(this.compact))
/*      */       {
/*  957 */         attrObject.put("content", Boolean.valueOf(jsonBool));
/*  958 */         if (!(this.locale))
/*      */           return;
/*  960 */         attrObject.put("localecontent", MXFormat.booleanToString(jsonBool, clientLocale)); return;


/*      */       }
/*      */ 
/*  965 */       if (this.locale)
/*      */       {
/*  967 */         mboOjo.put(attributeName, MXFormat.booleanToString(jsonBool, clientLocale)); return;

/*      */       }
/*      */ 
/*  971 */       mboOjo.put(attributeName, Boolean.valueOf(jsonBool));

/*      */ 
/*  974 */       break;
/*      */     case 18:
/*  976 */       byte[] data = null;
/*  977 */       if (attachmentCol)
/*      */       {
/*  979 */         data = (overridden) ? (byte[])(byte[])ovrdColValue : attachedDoc;
/*      */       }
/*      */       else
/*      */       {
/*  983 */         data = (overridden) ? (byte[])(byte[])ovrdColValue : mbo.getBytes(attributeName);
/*      */       }
/*  985 */       String base64Data = Base64.encode(data);
/*  986 */       if (!(this.compact))
/*      */       {
/*  988 */         attrObject.put("content", base64Data);
/*  989 */         if (!(this.locale))
/*      */           return;
/*  991 */         attrObject.put("localecontent", base64Data); return;


/*      */       }
/*      */ 
/*  996 */       mboOjo.put(attributeName, base64Data);
/*      */     case 16:
/*      */     }
/*      */   }



/*      */   public void setResolvedTotalCount(int resolvedTotalCount)
/*      */   {
/* 1005 */     this.resolvedTotalCount = resolvedTotalCount;
/*      */   }

/*      */   public void setInitialResolvedCount(int initialResolvedCount)
/*      */   {
/* 1010 */     this.initialResolvedCount = initialResolvedCount;
/*      */   }

/*      */   public void setResolvedStartCount(int resolvedStartCount)
/*      */   {
/* 1015 */     this.resolvedStartCount = resolvedStartCount;
/*      */   }
/*      */ }
