/*     */ package com.ibm.tivoli.maximo.rest;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.iface.mos.MOSStAXStructure;
/*     */ import psdi.iface.mos.MosDetailInfo;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.util.BitFlag;
/*     */ import psdi.util.MXException;
/*     */ 




























/*     */ public class RESTOSStAXStructure extends MOSStAXStructure
/*     */ {
/*  43 */   protected boolean locale = false;
/*  44 */   protected boolean keys = false;
/*  45 */   protected boolean rootOnly = false;
/*  46 */   protected boolean metaData = false;
/*  47 */   private boolean glcomp = false;
/*  48 */   private boolean validateXmlTextFromReq = true;
/*  49 */   private boolean calculateEtag = true;
/*  50 */   private StringBuilder rsBuffer = null;
/*  51 */   private boolean useTotalCount = true;
/*     */ 
/*     */   public RESTOSStAXStructure(String defClassName, Map<String, ?> defnMetaData, String mosName, boolean event, boolean retainMbos, boolean ignoreActions, String operationName, boolean response, boolean updatesOnly, String inputAction, boolean dropNullCols, boolean locale, boolean rootOnly, boolean keys, boolean metaData, boolean calculateEtag, boolean glcomp, boolean validateXmlTextFromReq, boolean useTotalCount)
/*     */     throws MXException
/*     */   {
/*  62 */     super(defClassName, defnMetaData, mosName, event, retainMbos, ignoreActions, operationName, response, updatesOnly, inputAction, dropNullCols);
/*     */ 
/*  64 */     this.locale = locale;
/*  65 */     this.keys = keys;
/*  66 */     this.rootOnly = rootOnly;
/*  67 */     this.metaData = metaData;
/*  68 */     this.calculateEtag = calculateEtag;
/*  69 */     this.glcomp = glcomp;
/*  70 */     this.useTotalCount = useTotalCount;
/*  71 */     this.validateXmlTextFromReq = validateXmlTextFromReq;
/*  72 */     if (!(calculateEtag))
/*     */       return;
/*  74 */     this.rsBuffer = new StringBuilder();
/*     */   }





/*     */   protected boolean isUseTotalCount()
/*     */   {
/*  83 */     return this.useTotalCount;
/*     */   }



/*     */   protected boolean isValidateXMLText(String mboAttrName, MboRemote mbo)
/*     */   {
/*  90 */     return this.validateXmlTextFromReq;
/*     */   }


/*     */   protected boolean useMboValueForSendersysid()
/*     */   {
/*  96 */     return true;
/*     */   }


/*     */   protected boolean isMaxValueRequired(String mboAttrName, MboRemote mbo)
/*     */   {
/* 102 */     return false;
/*     */   }


/*     */   protected boolean isGLCompRequired(String mboAttrName, MboRemote mbo)
/*     */   {
/* 108 */     return this.glcomp;
/*     */   }


/*     */   protected boolean isRequiresChangeIndicator(String mboAttrName, MboRemote mbo)
/*     */   {
/* 114 */     return false;
/*     */   }

/*     */   public String getCalculatedEtag()
/*     */   {
/* 119 */     if (this.calculateEtag)
/*     */     {
/* 121 */       return String.valueOf(this.rsBuffer.toString().hashCode());
/*     */     }
/* 123 */     return null;
/*     */   }

/*     */   protected int createStructure(MboRemote mbo, MosDetailInfo info, boolean headerObject)
/*     */     throws MXException, RemoteException
/*     */   {
/* 129 */     if ((this.rootOnly) && (!(headerObject)))
/*     */     {
/* 131 */       return 4;
/*     */     }
/*     */ 
/* 134 */     if (this.keys)
/*     */     {
/* 136 */       if (headerObject)
/*     */       {
/* 138 */         return super.createStructure(mbo, info, headerObject);

/*     */       }
/*     */ 
/* 142 */       return 4;
/*     */     }
/*     */ 
/* 145 */     return super.createStructure(mbo, info, headerObject);
/*     */   }

/*     */   public boolean isKey(MboRemote mbo, String mboAttrName)
/*     */     throws RemoteException, MXException
/*     */   {
/* 151 */     MboSetInfo mboSetInfo = mbo.getThisMboSet().getMboSetInfo();
/* 152 */     if (mboSetInfo.isPersistent())
/*     */     {
/* 154 */       MboValueInfo mboValueInfo = mbo.getThisMboSet().getMboSetInfo().getMboValueInfo(mboAttrName);
/* 155 */       String uniqueIdColName = mbo.getThisMboSet().getMboSetInfo().getUniqueIDName();
/* 156 */       String[] altkeys = MicUtil.getKeyArray(mbo.getName());


/*     */ 
/* 160 */       return ((mboValueInfo.isKey()) || (uniqueIdColName.equalsIgnoreCase(mboAttrName)) || (Arrays.binarySearch(altkeys, mboAttrName) >= 0));

/*     */     }
/*     */ 
/* 164 */     return true;
/*     */   }






/*     */   protected void setMboColumnElement(String mboAttrName, MboRemote mbo, Object ovrdColValue, boolean overridden)
/*     */     throws RemoteException, MXException, XMLStreamException
/*     */   {
/* 175 */     if (this.keys)
/*     */     {
/* 177 */       if (isKey(mbo, mboAttrName))
/*     */       {
/* 179 */         super.setMboColumnElement(mboAttrName, mboAttrName, null, mbo, ovrdColValue, overridden);
/*     */       }
/* 181 */       return;
/*     */     }
/* 183 */     super.setMboColumnElement(mboAttrName, mboAttrName, null, mbo, ovrdColValue, overridden);
/*     */   }


/*     */   protected void writeCharacters(String mboAttrName, MboValueInfo mboValueInfo, MboRemote mbo, String xmlTagName, String tagValue)
/*     */     throws RemoteException, MXException, XMLStreamException
/*     */   {
/* 190 */     int maxType = mboValueInfo.getTypeAsInt();
/* 191 */     if ((this.locale) && (((maxType == 6) || (maxType == 7) || (maxType == 19) || (maxType == 9) || (maxType == 8) || (maxType == 10) || (maxType == 11) || (maxType == 3) || (maxType == 4) || (maxType == 5) || (maxType == 12))))



/*     */     {
/* 196 */       String localizedValue = mbo.getString(mboAttrName);
/* 197 */       this.writer.writeAttribute("localecontent", localizedValue);
/*     */     }
/* 199 */     super.writeCharacters(mboAttrName, mboValueInfo, mbo, xmlTagName, tagValue);
/*     */   }


/*     */   protected boolean isAnyOwnerHidden(MboRemote mbo)
/*     */     throws RemoteException
/*     */   {
/* 206 */     Mbo owner = (Mbo)mbo.getOwner();
/* 207 */     if (owner == null) return false;
/* 208 */     if (owner.getRowRestrictionFlag().isFlagSet(263L))
/*     */     {
/* 210 */       return true;

/*     */     }
/*     */ 
/* 214 */     return isAnyOwnerHidden(owner);
/*     */   }


/*     */   protected void addObjectExtensibilityAttributes(MboRemote mbo)
/*     */     throws RemoteException, MXException, XMLStreamException
/*     */   {
/* 221 */     if (this.calculateEtag)
/*     */     {
/* 223 */       String rs = ((Mbo)mbo).getRowStamp();
/* 224 */       this.rsBuffer.append(rs);
/*     */     }
/*     */ 
/* 227 */     if (!(this.metaData))
/*     */       return;
/* 229 */     if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(263L))
/*     */     {
/* 231 */       this.writer.writeAttribute("hidden", "1");
/*     */     }
/*     */     else
/*     */     {
/* 235 */       this.writer.writeAttribute("hidden", "0");
/*     */     }
/*     */ 
/* 238 */     if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(7L))
/*     */     {
/* 240 */       this.writer.writeAttribute("readonly", "1");
/*     */     }
/*     */     else
/*     */     {
/* 244 */       this.writer.writeAttribute("readonly", "0");
/*     */     }
/*     */   }



/*     */   protected void addExtensibilityAttributes(String name, MboRemote mbo, Object ovrdColValue, boolean overridden)
/*     */     throws RemoteException, MXException, XMLStreamException
/*     */   {
/* 253 */     MboValueInfo mboValueInfo = mbo.getThisMboSet().getMboSetInfo().getMboValueInfo(name);
/* 254 */     if (mboValueInfo == null) return;
/* 255 */     if (this.metaData)
/*     */     {
/* 257 */       if (name.equalsIgnoreCase(mbo.getUniqueIDName()))
/*     */       {
/* 259 */         this.writer.writeAttribute("resourceid", "1");
/*     */       }
/* 261 */       if (((Mbo)mbo).getAttrRestrictionFlag(name).isFlagSet(263L))
/*     */       {
/* 263 */         this.writer.writeAttribute("hidden", "1");
/*     */       }
/*     */       else
/*     */       {
/* 267 */         this.writer.writeAttribute("hidden", "0");
/*     */       }
/*     */ 
/* 270 */       if (((Mbo)mbo).getAttrRestrictionFlag(name).isFlagSet(7L))
/*     */       {
/* 272 */         this.writer.writeAttribute("readonly", "1");
/*     */       }
/*     */       else
/*     */       {
/* 276 */         this.writer.writeAttribute("readonly", "0");
/*     */       }
/*     */ 
/* 279 */       if ((((Mbo)mbo).getAttrRestrictionFlag(name).isFlagSet(128L)) || (mboValueInfo.isRequired()))
/*     */       {
/* 281 */         this.writer.writeAttribute("required", "1");
/*     */       }
/*     */       else
/*     */       {
/* 285 */         this.writer.writeAttribute("required", "0");
/*     */       }
/*     */     }
/*     */ 
/* 289 */     super.addExtensibilityAttributes(name, mbo, ovrdColValue, overridden);
/*     */   }
/*     */ }
