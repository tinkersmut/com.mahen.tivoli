package com.ibm.tivoli.maximo.rest;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jdom.Element;
import psdi.mbo.DomainInfo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.security.UserInfo;
import psdi.server.AppServiceRemote;
import psdi.txn.MXTransaction;
import psdi.util.MXException;

public abstract interface RestServiceRemote extends AppServiceRemote
{
  public static final String XML_FORMAT = "XML";
  public static final String JSON_FORMAT = "JSON";
  public static final String REST_LOGGER = "maximo.rest";

  public abstract DomainInfo getDomainInfo(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException;

  public abstract MboSetRemote xmlToMboSet(UserInfo paramUserInfo, List<Element> paramList, Map<String, String> paramMap, MXTransaction paramMXTransaction, String paramString)
    throws RemoteException, MXException;

  public abstract void xmlToMbo(MboRemote paramMboRemote, Element paramElement)
    throws RemoteException, MXException;

  public abstract byte[] serializeMbo(MboRemote paramMboRemote, boolean paramBoolean1, boolean paramBoolean2, Set<String> paramSet, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, String paramString, boolean paramBoolean7, boolean paramBoolean8)
    throws RemoteException, MXException;

  public abstract byte[] serializeMboSet(MboSetRemote paramMboSetRemote, boolean paramBoolean1, boolean paramBoolean2, Set<String> paramSet, boolean paramBoolean3, int paramInt1, int paramInt2, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, String paramString, boolean paramBoolean7, boolean paramBoolean8)
    throws RemoteException, MXException;

  public abstract byte[] serializeOSMboSet(MboSetRemote paramMboSetRemote, String paramString1, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, String paramString2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7, String paramString3, boolean paramBoolean8, boolean paramBoolean9)
    throws RemoteException, MXException;

  public abstract byte[] serializeOSMbo(MboRemote paramMboRemote, String paramString1, boolean paramBoolean1, String paramString2, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, String paramString3, boolean paramBoolean7, boolean paramBoolean8)
    throws RemoteException, MXException;

  public abstract boolean isKey(MboRemote paramMboRemote, String paramString)
    throws RemoteException, MXException;
}
