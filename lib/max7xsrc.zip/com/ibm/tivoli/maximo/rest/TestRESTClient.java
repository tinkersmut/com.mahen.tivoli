/*     */ package com.ibm.tivoli.maximo.rest;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.axiom.om.util.Base64;
/*     */ import psdi.iface.router.Util;
/*     */ import psdi.iface.util.XMLUtils;
/*     */ 




/*     */ public class TestRESTClient
/*     */ {
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  31 */     String user = "wilson";
/*  32 */     String httpMethod = "GET";
/*  33 */     String pass = "wilson";
/*  34 */     String uri = null;
/*  35 */     String qpFile = null;
/*  36 */     String fpFile = null;
/*  37 */     String format = "json";
/*  38 */     String queryParams = null;
/*  39 */     String formParams = null;
/*  40 */     String authType = "maximo";
/*  41 */     String action = null;
/*  42 */     String url = null;
/*  43 */     boolean ucn = true;
/*  44 */     File opDir = null;
/*  45 */     String fileName = null;
/*  46 */     for (String arg : args)
/*     */     {
/*  48 */       if (arg.startsWith("-user:"))
/*     */       {
/*  50 */         user = arg.substring("-user:".length());
/*     */       }
/*  52 */       else if (arg.startsWith("-httpm:"))
/*     */       {
/*  54 */         httpMethod = arg.substring("-httpm:".length());
/*     */       }
/*  56 */       else if (arg.startsWith("-pwd:"))
/*     */       {
/*  58 */         pass = arg.substring("-pwd:".length());
/*     */       }
/*  60 */       else if (arg.startsWith("-urlpath:"))
/*     */       {
/*  62 */         uri = arg.substring("-urlpath:".length());
/*     */       }
/*  64 */       else if (arg.startsWith("-urlqp:"))
/*     */       {
/*  66 */         qpFile = arg.substring("-urlqp:".length());
/*  67 */         Properties props = loadParamsFromFile(qpFile);
/*  68 */         queryParams = propsAsString(props);
/*     */       }
/*  70 */       else if (arg.startsWith("-fp:"))
/*     */       {
/*  72 */         fpFile = arg.substring("-fp:".length());
/*  73 */         Properties props = loadParamsFromFile(fpFile);
/*  74 */         formParams = propsAsString(props);
/*     */       }
/*  76 */       else if (arg.startsWith("-fmt:"))
/*     */       {
/*  78 */         format = arg.substring("-fmt:".length());
/*     */       }
/*  80 */       else if (arg.startsWith("-auth:"))
/*     */       {
/*  82 */         authType = arg.substring("-auth:".length());
/*     */       }
/*  84 */       else if (arg.startsWith("-action:"))
/*     */       {
/*  86 */         action = arg.substring("-action:".length());
/*     */       }
/*  88 */       else if (arg.startsWith("-ucn:"))
/*     */       {
/*  90 */         ucn = Boolean.parseBoolean(arg.substring("-ucn:".length()));
/*     */       } else {
/*  92 */         if (!(arg.startsWith("-opdir:")))
/*     */           continue;
/*  94 */         opDir = new File(arg.substring("-opdir:".length()));
/*  95 */         if (!(opDir.exists()))
/*     */         {
/*  97 */           opDir.mkdirs();
/*     */         }
/*  99 */         fileName = System.currentTimeMillis() + ".txt";
/*     */       }
/*     */     }
/*     */ 
/* 103 */     url = uri;
/* 104 */     if (!(ucn))
/*     */     {
/* 106 */       if (queryParams == null)
/*     */       {
/* 108 */         queryParams = "_format=" + format;
/*     */       }
/*     */       else
/*     */       {
/* 112 */         queryParams = queryParams + "&_format=" + format;
/*     */       }
/*     */     }
/*     */ 
/* 116 */     if (queryParams != null)
/*     */     {
/* 118 */       url = url + "?" + queryParams;
/*     */     }
/*     */ 
/* 121 */     URL httpURL = new URL(url);
/*     */ 
/* 123 */     long t1 = System.currentTimeMillis();
/* 124 */     URLConnection con = httpURL.openConnection();
/*     */ 
/* 126 */     String encodedUserPwd = "";
/*     */ 
/* 128 */     if (httpMethod.equalsIgnoreCase("POST"))
/*     */     {
/* 130 */       con.setRequestProperty("Content-Type", (formParams != null) ? "application/x-www-form-urlencoded" : "application/xml");
/*     */     }
/*     */ 
/* 133 */     if (action != null)
/*     */     {
/* 135 */       con.setRequestProperty("x-http-method-override", action);
/*     */     }
/*     */ 
/* 138 */     if (ucn)
/*     */     {
/* 140 */       if (format.equalsIgnoreCase("json"))
/*     */       {
/* 142 */         con.setRequestProperty("accept", "application/json");
/*     */       }
/*     */       else
/*     */       {
/* 146 */         con.setRequestProperty("accept", "application/xml");
/*     */       }
/*     */     }
/*     */ 
/* 150 */     if ((user != null) && (pass != null))
/*     */     {
/* 152 */       encodedUserPwd = encode(user, pass);
/* 153 */       if (authType.equals("basic"))
/*     */       {
/* 155 */         con.setRequestProperty("Authorization", "Basic " + encodedUserPwd);
/*     */       }
/*     */       else
/*     */       {
/* 159 */         con.setRequestProperty("MAXAUTH", encodedUserPwd);
/*     */       }
/*     */     }
/*     */ 
/* 163 */     if (httpMethod.equalsIgnoreCase("post"))
/*     */     {
/* 165 */       con.setRequestProperty("Content-Length", Integer.toString(formParams.length()));
/* 166 */       con.setDoOutput(true);
/*     */     }
/* 168 */     con.setUseCaches(false);
/* 169 */     con.setAllowUserInteraction(false);
/*     */ 
/* 171 */     BufferedOutputStream outStream = null;
/* 172 */     InputStream inStream = null;

/*     */ 
/* 175 */     if (httpMethod.equalsIgnoreCase("post"))
/*     */     {
/* 177 */       outStream = new BufferedOutputStream(con.getOutputStream());
/* 178 */       outStream.write(formParams.getBytes("UTF-8"));
/* 179 */       outStream.flush();
/*     */     }
/*     */ 
/* 182 */     inStream = con.getInputStream();
/* 183 */     byte[] responseBody = Util.getByteArrayFromInputStream(inStream);
/* 184 */     long t2 = System.currentTimeMillis();
/*     */ 
/* 186 */     System.out.println("total time " + ((t2 - t1) / 1000.0D));
/* 187 */     if (fileName == null)
/*     */       return;
/* 189 */     XMLUtils.writeBytesToXMLFile(responseBody, opDir.getAbsolutePath() + File.separator + fileName, false);
/*     */   }














/*     */   public static String encode(String userName, String password)
/*     */     throws Exception
/*     */   {
/* 208 */     return Base64.encode(userName + ":" + password.getBytes("UTF-8"));
/*     */   }

/*     */   private static Properties loadParamsFromFile(String fileName)
/*     */     throws FileNotFoundException, IOException
/*     */   {
/* 214 */     Properties props = new Properties();
/* 215 */     if (fileName.endsWith(".txt"))
/*     */     {
/* 217 */       File f = new File(fileName);
/*     */ 
/* 219 */       props.load(new FileInputStream(f));

/*     */     }
/*     */     else
/*     */     {
/* 224 */       StringTokenizer strtk = new StringTokenizer(fileName, "|");
/* 225 */       while (strtk.hasMoreTokens())
/*     */       {
/* 227 */         String tok = strtk.nextToken();
/* 228 */         StringTokenizer strtk2 = new StringTokenizer(tok, "=");
/* 229 */         props.put(strtk2.nextToken(), (strtk2.hasMoreTokens()) ? strtk2.nextToken() : null);
/*     */       }
/*     */     }
/* 232 */     return props;
/*     */   }

/*     */   private static String propsAsString(Properties props) throws UnsupportedEncodingException
/*     */   {
/* 237 */     Iterator itr = props.keySet().iterator();
/* 238 */     StringBuffer paramStringBuffer = new StringBuffer();
/* 239 */     while (itr.hasNext())
/*     */     {
/* 241 */       String paramName = (String)itr.next();
/* 242 */       paramStringBuffer.append(paramName + "=");
/* 243 */       String paramValue = (String)props.get(paramName);
/* 244 */       paramValue = URLEncoder.encode(paramValue, "UTF-8");
/* 245 */       paramStringBuffer.append(paramValue);
/* 246 */       if (itr.hasNext())
/*     */       {
/* 248 */         paramStringBuffer.append("&");
/*     */       }
/*     */     }
/* 251 */     return paramStringBuffer.toString();
/*     */   }
/*     */ }
