/*     */ package com.ibm.tivoli.maximo.rest;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.jdom.Element;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.iface.mic.ObjectList;
/*     */ import psdi.iface.mic.StructureObject;
/*     */ import psdi.iface.mos.MboXMLUtil;
/*     */ import psdi.mbo.DomainInfo;
/*     */ import psdi.mbo.MAXTABLEDomainInfo;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.AppService;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.txn.MXTransaction;
/*     */ import psdi.util.MXException;
/*     */ 



















/*     */ public class RestService extends AppService
/*     */   implements RestServiceRemote
/*     */ {
/*     */   public RestService()
/*     */     throws RemoteException
/*     */   {
/*     */   }
/*     */ 
/*     */   public RestService(MXServer mxServer)
/*     */     throws RemoteException
/*     */   {
/*  56 */     super(mxServer);
/*     */   }

/*     */   public DomainInfo getDomainInfo(String objectName, String domainName, String siteid, String orgid) throws RemoteException
/*     */   {
/*  61 */     DomainInfo domainInfo = MXServer.getMXServer().getMaximoDD().getDomainInfo(domainName);
/*  62 */     if (domainInfo instanceof MAXTABLEDomainInfo)
/*     */     {
/*  64 */       MAXTABLEDomainInfo tableDom = (MAXTABLEDomainInfo)domainInfo;
/*  65 */       String[] signature = { siteid, orgid };
/*  66 */       if ((siteid == null) && (orgid == null))
/*     */       {
/*  68 */         signature = null;
/*     */       }
/*     */ 
/*  71 */       String domObjName = tableDom.getObjectName(signature);
/*  72 */       if (domObjName.equalsIgnoreCase(objectName))
/*     */       {
/*  74 */         return domainInfo;
/*     */       }
/*     */     }
/*  77 */     return null;
/*     */   }


/*     */   public boolean isKey(MboRemote mbo, String mboAttrName)
/*     */     throws RemoteException, MXException
/*     */   {
/*  84 */     MboSetInfo mboSetInfo = mbo.getThisMboSet().getMboSetInfo();
/*  85 */     if (mboSetInfo.isPersistent())
/*     */     {
/*  87 */       MboValueInfo mboValueInfo = mbo.getThisMboSet().getMboSetInfo().getMboValueInfo(mboAttrName);
/*  88 */       String uniqueIdColName = mbo.getThisMboSet().getMboSetInfo().getUniqueIDName();
/*  89 */       String[] altkeys = MicUtil.getKeyArray(mbo.getName());


/*     */ 
/*  93 */       return ((mboValueInfo.isKey()) || (uniqueIdColName.equalsIgnoreCase(mboAttrName)) || (Arrays.binarySearch(altkeys, mboAttrName) >= 0));

/*     */     }
/*     */ 
/*  97 */     return true;
/*     */   }


/*     */   public MboSetRemote xmlToMboSet(UserInfo info, List<Element> data, Map<String, String> params, MXTransaction trans, String appName)
/*     */     throws RemoteException, MXException
/*     */   {
/* 104 */     ObjectList oList = new ObjectList(data);
/* 105 */     return MboXMLUtil.xmlToMboSet(info, oList, params, trans, appName);
/*     */   }

/*     */   public void xmlToMbo(MboRemote mbo, Element data)
/*     */     throws RemoteException, MXException
/*     */   {
/* 111 */     StructureObject str = new StructureObject(data);
/* 112 */     MboXMLUtil.xmlToMbo(mbo, str);
/*     */   }




/*     */   public byte[] serializeMbo(MboRemote mbo, boolean dropnulls, boolean retainmbos, Set<String> colsSet, boolean exclude, boolean locale, boolean generic, boolean verbose, String format, boolean metaData, boolean compact)
/*     */     throws RemoteException, MXException
/*     */   {
/* 121 */     return null;
/*     */   }




/*     */   public byte[] serializeMboSet(MboSetRemote mboSet, boolean dropnulls, boolean retainmbos, Set<String> colsSet, boolean exclude, int rsStart, int maxItems, boolean locale, boolean generic, boolean verbose, String format, boolean metaData, boolean compact)
/*     */     throws RemoteException, MXException
/*     */   {
/* 130 */     return null;
/*     */   }






/*     */   public byte[] serializeOSMboSet(MboSetRemote mboSet, String mosName, boolean dropnulls, boolean retainmbos, int rsStart, int maxItems, String operation, boolean locale, boolean generic, boolean verbose, boolean rootOnly, boolean keys, String format, boolean metaData, boolean compact)
/*     */     throws RemoteException, MXException
/*     */   {
/* 141 */     return null;
/*     */   }





/*     */   public byte[] serializeOSMbo(MboRemote mbo, String mosName, boolean dropnulls, String operation, boolean locale, boolean generic, boolean verbose, boolean rootOnly, boolean keys, String format, boolean metaData, boolean compact)
/*     */     throws RemoteException, MXException
/*     */   {
/* 151 */     return null;
/*     */   }
/*     */ }
