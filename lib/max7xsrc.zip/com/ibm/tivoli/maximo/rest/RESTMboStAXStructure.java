/*     */ package com.ibm.tivoli.maximo.rest;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import psdi.iface.mos.MBOStAXStructure;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueData;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.util.BitFlag;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 

























/*     */ public class RESTMboStAXStructure extends MBOStAXStructure
/*     */ {
/*  43 */   private boolean locale = false;
/*  44 */   private boolean metaData = false;
/*  45 */   private boolean calculateEtag = false;
/*  46 */   private StringBuilder rsBuffer = null;
/*  47 */   private boolean glcomp = false;
/*  48 */   private boolean validateXmlTextFromReq = true;
/*  49 */   private Map<String, String> relatedAttributes = null;
/*  50 */   private boolean useTotalCount = true;
/*  51 */   private int resolvedTotalCount = -1;
/*  52 */   private int initialResolvedCount = -1;
/*  53 */   private int resolvedStartCount = -1;
/*     */ 
/*  57 */   private static MXLogger logger = MXLoggerFactory.getLogger("maximo.rest");
/*     */ 
/*     */   public RESTMboStAXStructure(boolean dropNullCols, boolean retainMbos, Set<String> cols, boolean exclude, boolean locale, boolean metaData, boolean calculateEtag, boolean glcomp, boolean validateXmlTextFromReq, Map<String, String> relatedAttributes, boolean useTotalCount)
/*     */   {
/*  65 */     super(dropNullCols, retainMbos, true, exclude, cols, true);
/*  66 */     if (logger.isDebugEnabled())
/*     */     {
/*  68 */       logger.debug("columns " + cols + " exclude=" + exclude);
/*     */     }
/*     */ 
/*  71 */     this.locale = locale;
/*  72 */     this.metaData = metaData;
/*  73 */     this.calculateEtag = calculateEtag;
/*  74 */     this.relatedAttributes = relatedAttributes;
/*  75 */     this.glcomp = glcomp;
/*  76 */     this.useTotalCount = useTotalCount;
/*  77 */     this.validateXmlTextFromReq = validateXmlTextFromReq;
/*  78 */     if (!(calculateEtag))
/*     */       return;
/*  80 */     this.rsBuffer = new StringBuilder();
/*     */   }


/*     */   public MboValueInfo getMboValueInfoForAttribute(Mbo mbo, String attributeName)
/*     */     throws RemoteException, MXException
/*     */   {
/*  87 */     MboRemote mboAttrOwner = mbo.getMboForAttribute(attributeName);
/*  88 */     int index = attributeName.indexOf(".");
/*  89 */     String attr = attributeName.substring(index + 1);
/*  90 */     MboValueInfo mboValueInfo = mboAttrOwner.getThisMboSet().getMboSetInfo().getMboValueInfo(attr);
/*  91 */     return mboValueInfo;
/*     */   }

/*     */   public void setResolvedTotalCount(int resolvedTotalCount)
/*     */   {
/*  96 */     this.resolvedTotalCount = resolvedTotalCount;
/*     */   }

/*     */   public void setResolvedStartCount(int resolvedStartCount)
/*     */   {
/* 101 */     this.resolvedStartCount = resolvedStartCount;
/*     */   }


/*     */   public void setInitialResolvedCount(int initialResolvedCount)
/*     */   {
/* 107 */     this.initialResolvedCount = initialResolvedCount;
/*     */   }


/*     */   protected boolean isValidateXMLText(String mboAttrName, MboRemote mbo)
/*     */   {
/* 113 */     return this.validateXmlTextFromReq;
/*     */   }



/*     */   protected boolean useMboValueForSendersysid()
/*     */   {
/* 120 */     return true;
/*     */   }



/*     */   protected boolean isMaxValueRequired(String mboAttrName, MboRemote mbo)
/*     */   {
/* 127 */     return false;
/*     */   }


/*     */   protected boolean isGLCompRequired(String mboAttrName, MboRemote mbo)
/*     */   {
/* 133 */     return this.glcomp;
/*     */   }


/*     */   protected boolean isRequiresChangeIndicator(String mboAttrName, MboRemote mbo)
/*     */   {
/* 139 */     return false;
/*     */   }


/*     */   public String getCalculatedEtag()
/*     */   {
/* 145 */     if (this.calculateEtag)
/*     */     {
/* 147 */       return String.valueOf(this.rsBuffer.toString().hashCode());
/*     */     }
/* 149 */     return null;
/*     */   }


/*     */   protected void writeCharacters(String mboAttrName, MboValueInfo mboValueInfo, MboRemote mbo, String xmlTagName, String tagValue)
/*     */     throws RemoteException, MXException, XMLStreamException
/*     */   {
/* 156 */     int maxType = mboValueInfo.getTypeAsInt();
/* 157 */     if ((this.locale) && (((maxType == 6) || (maxType == 7) || (maxType == 19) || (maxType == 9) || (maxType == 8) || (maxType == 10) || (maxType == 11) || (maxType == 3) || (maxType == 4) || (maxType == 5) || (maxType == 12))))



/*     */     {
/* 162 */       String localizedValue = mbo.getString(mboAttrName);
/* 163 */       this.writer.writeAttribute("localecontent", localizedValue);
/*     */     }
/* 165 */     super.writeCharacters(mboAttrName, mboValueInfo, mbo, xmlTagName, tagValue);
/*     */   }

/*     */   protected void addObjectExtensibilityAttributes(MboRemote mbo)
/*     */     throws RemoteException, MXException, XMLStreamException
/*     */   {
/* 171 */     if (this.calculateEtag)
/*     */     {
/* 173 */       String rs = ((Mbo)mbo).getRowStamp();
/* 174 */       this.rsBuffer.append(rs);
/*     */     }
/*     */ 
/* 177 */     if (!(this.metaData))
/*     */       return;
/* 179 */     if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(263L))
/*     */     {
/* 181 */       this.writer.writeAttribute("hidden", "1");
/*     */     }
/*     */     else
/*     */     {
/* 185 */       this.writer.writeAttribute("hidden", "0");
/*     */     }
/* 187 */     if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(7L))
/*     */     {
/* 189 */       this.writer.writeAttribute("readonly", "1");
/*     */     }
/*     */     else
/*     */     {
/* 193 */       this.writer.writeAttribute("readonly", "0");
/*     */     }
/*     */   }


/*     */   protected void addRootExtensibilityAttributes()
/*     */     throws RemoteException, MXException, XMLStreamException
/*     */   {
/* 201 */     if (this.resolvedStartCount >= 0)
/*     */     {
/* 203 */       this.writer.writeAttribute("rsStart", "" + this.resolvedStartCount);
/*     */     }
/*     */     else
/*     */     {
/* 207 */       this.writer.writeAttribute("rsStart", "" + this.rsStart);
/*     */     }
/* 209 */     if (!(isUseTotalCount()))
/*     */       return;
/* 211 */     if (this.resolvedTotalCount < 0)
/*     */     {
/* 213 */       this.writer.writeAttribute("rsTotal", "" + this.rsTotal);
/* 214 */       this.writer.writeAttribute("rsCount", "" + this.rsCount);
/*     */     }
/*     */     else
/*     */     {
/* 218 */       this.writer.writeAttribute("rsTotal", "" + this.resolvedTotalCount);
/* 219 */       this.writer.writeAttribute("rsCount", "" + this.initialResolvedCount);
/*     */     }
/*     */   }



/*     */   protected void addExtensibilityAttributes(String name, MboRemote mbo, Object ovrdColValue, boolean overridden)
/*     */     throws RemoteException, MXException, XMLStreamException
/*     */   {
/* 228 */     MboValueInfo mboValueInfo = mbo.getThisMboSet().getMboSetInfo().getMboValueInfo(name);
/* 229 */     if (mboValueInfo == null) return;
/* 230 */     if (this.metaData)

/*     */     {
/* 233 */       if (name.equalsIgnoreCase(mbo.getUniqueIDName()))
/*     */       {
/* 235 */         this.writer.writeAttribute("resourceid", "1");
/*     */       }
/* 237 */       if (((Mbo)mbo).getAttrRestrictionFlag(name).isFlagSet(263L))
/*     */       {
/* 239 */         this.writer.writeAttribute("hidden", "1");
/*     */       }
/*     */       else
/*     */       {
/* 243 */         this.writer.writeAttribute("hidden", "0");
/*     */       }
/*     */ 
/* 246 */       if (((Mbo)mbo).getAttrRestrictionFlag(name).isFlagSet(7L))
/*     */       {
/* 248 */         this.writer.writeAttribute("readonly", "1");
/*     */       }
/*     */       else
/*     */       {
/* 252 */         this.writer.writeAttribute("readonly", "0");
/*     */       }
/*     */ 
/* 255 */       if ((((Mbo)mbo).getAttrRestrictionFlag(name).isFlagSet(128L)) || (mboValueInfo.isRequired()))

/*     */       {
/* 258 */         this.writer.writeAttribute("required", "1");
/*     */       }
/*     */       else
/*     */       {
/* 262 */         this.writer.writeAttribute("required", "0");
/*     */       }
/*     */     }
/* 265 */     super.addExtensibilityAttributes(name, mbo, ovrdColValue, overridden);
/*     */   }

/*     */   protected void setAdditionalData(MboRemote mbo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 271 */     if (this.relatedAttributes == null)
/*     */       return;
/* 273 */     Set set = this.relatedAttributes.entrySet();
/* 274 */     for (Map.Entry entry : set)
/*     */     {
/*     */       try
/*     */       {
/* 278 */         setMboColumnElement((String)entry.getKey(), (String)entry.getValue(), getMboValueInfoForAttribute((Mbo)mbo, (String)entry.getValue()), mbo, mbo.getMboValueData((String)entry.getValue()).getDataAsObject(), true);
/*     */       }
/*     */       catch (XMLStreamException stre)
/*     */       {
/* 282 */         throw new MXSystemException("system", "major", stre);
/*     */       }
/*     */     }
/*     */   }



/*     */   protected boolean isUseTotalCount()
/*     */   {
/* 291 */     return this.useTotalCount;
/*     */   }
/*     */ }
