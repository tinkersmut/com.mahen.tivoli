/*     */ package com.ibm.tivoli.maximo.rest;
/*     */ 
/*     */ import com.ibm.json.java.JSONArray;
/*     */ import com.ibm.json.java.OrderedJSONObject;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.apache.axiom.om.util.Base64;
/*     */ import psdi.iface.mos.ConversionUtil;
/*     */ import psdi.iface.mos.MboIterator;
/*     */ import psdi.iface.mos.MboSetIterator;
/*     */ import psdi.iface.util.XMLUtils;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueData;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.BitFlag;
/*     */ import psdi.util.MXCipher;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXFormat;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 




















/*     */ public class MboJSONStructure
/*     */ {
/*  41 */   private static MXLogger logger = MXLoggerFactory.getLogger("maximo.rest");
/*     */ 
/*  43 */   protected boolean verbose = false;
/*  44 */   protected boolean dropNulls = true;
/*  45 */   protected boolean locale = false;
/*  46 */   protected Set<String> cols = null;
/*  47 */   protected boolean exclude = false;
/*  48 */   protected boolean retainMbos = false;
/*  49 */   protected boolean generic = false;
/*  50 */   protected boolean calculateEtag = true;
/*  51 */   private StringBuilder rsBuffer = null;
/*     */ 
/*  53 */   private boolean metaData = false;
/*  54 */   private boolean compact = false;
/*  55 */   private boolean useTotalCount = true;
/*     */ 
/*  57 */   private int resolvedTotalCount = -1;
/*  58 */   private int initialResolvedCount = -1;
/*  59 */   private int resolvedStartCount = -1;
/*     */ 
/*     */   public MboJSONStructure(boolean verbose, boolean dropNulls, boolean locale, Set<String> cols, boolean exclude, boolean retainMbos, boolean generic, boolean metaData, boolean compact, boolean calculateEtag, boolean useTotalCount)
/*     */   {
/*  74 */     this.verbose = verbose;
/*  75 */     this.dropNulls = dropNulls;
/*  76 */     this.locale = locale;
/*  77 */     this.exclude = exclude;
/*  78 */     this.cols = cols;
/*  79 */     this.retainMbos = retainMbos;
/*  80 */     this.generic = generic;
/*  81 */     this.metaData = metaData;
/*  82 */     this.compact = compact;
/*  83 */     this.useTotalCount = useTotalCount;
/*  84 */     if (compact)
/*     */     {
/*  86 */       metaData = false;
/*  87 */       generic = false;
/*     */     }
/*  89 */     this.calculateEtag = calculateEtag;
/*  90 */     if (!(calculateEtag))
/*     */       return;
/*  92 */     this.rsBuffer = new StringBuilder();
/*     */   }


/*     */   public byte[] serializeMboSet(MboSetRemote mboSet)
/*     */     throws RemoteException, MXException
/*     */   {
/*  99 */     return serializeMboSet(new MboSetIterator(mboSet), 0, mboSet.count());
/*     */   }

/*     */   public byte[] serializeMboSet(MboIterator mboSet) throws RemoteException, MXException
/*     */   {
/* 104 */     return serializeMboSet(mboSet, 0, mboSet.count());
/*     */   }

/*     */   public byte[] serializeMboSet(OrderedJSONObject opOjo, MboIterator mboSet) throws RemoteException, MXException
/*     */   {
/* 109 */     return serializeMboSet(opOjo, mboSet, 0, mboSet.count());
/*     */   }

/*     */   public byte[] serializeMboSet(MboSetRemote mboSet, int startIndex, int maxCount)
/*     */     throws RemoteException, MXException
/*     */   {
/* 115 */     return serializeMboSet(new MboSetIterator(mboSet), startIndex, maxCount);
/*     */   }

/*     */   public OrderedJSONObject serializeMboSetAsJSONObject(MboSetRemote mboSet, int startIndex, int maxCount)
/*     */     throws RemoteException, MXException
/*     */   {
/* 121 */     return serializeMboSetAsJSONObject(null, new MboSetIterator(mboSet), startIndex, maxCount);
/*     */   }

/*     */   public OrderedJSONObject serializeMboSetAsJSONObject(MboIterator mboSet, int startIndex, int maxCount)
/*     */     throws RemoteException, MXException
/*     */   {
/* 127 */     return serializeMboSetAsJSONObject(null, mboSet, startIndex, maxCount);
/*     */   }

/*     */   public byte[] serializeMboSet(MboIterator mboSet, int startIndex, int maxCount)
/*     */     throws RemoteException, MXException
/*     */   {
/* 133 */     return serializeMboSet(null, mboSet, startIndex, maxCount);
/*     */   }

/*     */   public String getCalculatedEtag()
/*     */   {
/* 138 */     if (this.calculateEtag)
/*     */     {
/* 140 */       return String.valueOf(this.rsBuffer.toString().hashCode());
/*     */     }
/* 142 */     return null;
/*     */   }

/*     */   public byte[] serializeMboSet(OrderedJSONObject opOjo, MboIterator mboSet, int startIndex, int maxCount)
/*     */     throws RemoteException, MXException
/*     */   {
/* 148 */     OrderedJSONObject ojo = serializeMboSetAsJSONObject(opOjo, mboSet, startIndex, maxCount);
/* 149 */     return ((ojo == null) ? null : covertJSONObjectToBytes(ojo));
/*     */   }


/*     */   public OrderedJSONObject serializeMboSetAsJSONObject(OrderedJSONObject opOjo, MboIterator mboSet, int startIndex, int maxCount)
/*     */     throws RemoteException, MXException
/*     */   {
/* 156 */     int rsStart = (startIndex < 0) ? 0 : startIndex;
/*     */ 
/* 158 */     int rsTotal = 0;
/* 159 */     int databaseCount = 0;
/* 160 */     int objSize = 0;
/* 161 */     if (this.useTotalCount)
/*     */     {
/* 163 */       rsTotal = mboSet.count();
/* 164 */       databaseCount = rsTotal - rsStart;
/* 165 */       if (maxCount < 0)
/*     */       {
/* 167 */         maxCount = databaseCount;
/*     */       }
/* 169 */       objSize = Math.min(databaseCount, maxCount);
/*     */     }
/*     */ 
/* 172 */     OrderedJSONObject ojo = (opOjo == null) ? new OrderedJSONObject() : opOjo;
/* 173 */     OrderedJSONObject mboSetRootOjo = new OrderedJSONObject();
/*     */ 
/* 175 */     String mboName = mboSet.getName();
/* 176 */     if (!(this.generic))
/*     */     {
/* 178 */       ojo.put(mboName + "MboSet", mboSetRootOjo);
/*     */     }
/*     */     else
/*     */     {
/* 182 */       ojo.put("MboSet", mboSetRootOjo);

/*     */     }
/*     */ 
/* 186 */     JSONArray mboOjoArray = new JSONArray();
/* 187 */     if (this.resolvedStartCount >= 0)
/*     */     {
/* 189 */       mboSetRootOjo.put("rsStart", Integer.valueOf(this.resolvedStartCount));
/*     */     }
/*     */     else
/*     */     {
/* 193 */       mboSetRootOjo.put("rsStart", Integer.valueOf(rsStart));
/*     */     }
/* 195 */     mboSetRootOjo.put("rsCount", Integer.valueOf(objSize));
/* 196 */     if (this.useTotalCount)
/*     */     {
/* 198 */       if (this.resolvedTotalCount > 0)
/*     */       {
/* 200 */         mboSetRootOjo.put("rsTotal", Integer.valueOf(this.resolvedTotalCount));
/*     */       }
/*     */       else
/*     */       {
/* 204 */         mboSetRootOjo.put("rsTotal", Integer.valueOf(rsTotal));
/*     */       }
/*     */     }
/*     */ 
/* 208 */     if (!(this.generic))
/*     */     {
/* 210 */       mboSetRootOjo.put(mboName, mboOjoArray);
/*     */     }
/*     */     else
/*     */     {
/* 214 */       mboSetRootOjo.put("Mbo", mboOjoArray);
/*     */     }
/*     */ 
/* 217 */     if (!(this.retainMbos))
/*     */     {
/* 219 */       mboSet.setDiscardable();
/*     */     }
/*     */ 
/* 222 */     int i = rsStart;
/* 223 */     MboRemote mbo = mboSet.get(i);
/* 224 */     while (mbo != null)
/*     */     {
/* 226 */       OrderedJSONObject mboOjo = new OrderedJSONObject();
/* 227 */       if (this.generic)
/*     */       {
/* 229 */         mboOjo.put("name", mboName);
/*     */       }
/* 231 */       if (this.metaData)
/*     */       {
/* 233 */         if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(263L))
/*     */         {
/* 235 */           mboOjo.put("hidden", Boolean.valueOf(true));
/*     */         }
/*     */         else
/*     */         {
/* 239 */           mboOjo.put("hidden", Boolean.valueOf(false));
/*     */         }
/* 241 */         if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(7L))
/*     */         {
/* 243 */           mboOjo.put("readonly", Boolean.valueOf(true));
/*     */         }
/*     */         else
/*     */         {
/* 247 */           mboOjo.put("readonly", Boolean.valueOf(false));
/*     */         }
/*     */       }
/*     */ 
/* 251 */       mboOjoArray.add(mboOjo);
/* 252 */       mbo2JSONObject(mbo, mboOjo);
/* 253 */       ++i;
/* 254 */       if ((maxCount > 0) && (i >= rsStart + maxCount)) break;
/* 255 */       mbo = mboSet.get(i);
/*     */     }
/* 257 */     mboSetRootOjo.put("rsCount", Integer.valueOf(i - rsStart));











































/*     */ 
/* 302 */     if (opOjo != null) return null;
/* 303 */     return ojo;
/*     */   }

/*     */   public byte[] covertJSONObjectToBytes(OrderedJSONObject ojo) throws MXSystemException
/*     */   {
/*     */     try
/*     */     {
/* 310 */       return ojo.serialize(this.verbose).getBytes("utf-8");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 314 */       throw new MXSystemException("iface", "mbojsonerror", e);
/*     */     }
/*     */   }

/*     */   public byte[] serializeMbo(MboRemote mbo)
/*     */     throws RemoteException, MXException
/*     */   {
/* 321 */     return serializeMbo(null, mbo);
/*     */   }

/*     */   public byte[] serializeMbo(OrderedJSONObject opOjo, MboRemote mbo) throws RemoteException, MXException
/*     */   {
/* 326 */     if (logger.isDebugEnabled())
/*     */     {
/* 328 */       logger.debug("serializeMbo mbo=" + mbo);
/*     */     }
/*     */ 
/* 331 */     String mboName = mbo.getName();
/*     */ 
/* 333 */     OrderedJSONObject ojo = (opOjo == null) ? new OrderedJSONObject() : opOjo;
/* 334 */     OrderedJSONObject mboRootOjo = new OrderedJSONObject();
/* 335 */     if (!(this.generic))
/*     */     {
/* 337 */       ojo.put(mboName, mboRootOjo);
/*     */     }
/*     */     else
/*     */     {
/* 341 */       ojo.put("Mbo", mboRootOjo);
/*     */     }
/* 343 */     if (logger.isDebugEnabled())
/*     */     {
/* 345 */       logger.debug("serializeMbo mboname=" + mboName);
/*     */     }
/*     */ 
/* 348 */     if (this.generic)
/*     */     {
/* 350 */       mboRootOjo.put("name", mboName);
/*     */     }
/* 352 */     if (this.metaData)
/*     */     {
/* 354 */       if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(263L))
/*     */       {
/* 356 */         mboRootOjo.put("hidden", Boolean.valueOf(true));
/*     */       }
/*     */       else
/*     */       {
/* 360 */         mboRootOjo.put("hidden", Boolean.valueOf(false));
/*     */       }
/* 362 */       if (((Mbo)mbo).getRowRestrictionFlag().isFlagSet(7L))
/*     */       {
/* 364 */         mboRootOjo.put("readonly", Boolean.valueOf(true));
/*     */       }
/*     */       else
/*     */       {
/* 368 */         mboRootOjo.put("readonly", Boolean.valueOf(false));







/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 380 */     if (logger.isDebugEnabled())
/*     */     {
/* 382 */       logger.debug("serializeMbo for MboJSONStructure calling mbo2JSONObject for mbo " + mbo.getName());
/*     */     }
/* 384 */     mbo2JSONObject(mbo, mboRootOjo);
/*     */     try
/*     */     {
/* 387 */       return ((opOjo == null) ? ojo.serialize(this.verbose).getBytes("utf-8") : null);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 391 */       logger.error(e.getMessage(), e);
/* 392 */       throw new MXSystemException("iface", "mbojsonerror", e);
/*     */     }
/*     */   }

/*     */   protected void mbo2JSONObject(MboRemote mbo, OrderedJSONObject mboOjo) throws RemoteException, MXException
/*     */   {
/* 398 */     if (this.calculateEtag)
/*     */     {
/* 400 */       String rs = ((Mbo)mbo).getRowStamp();
/* 401 */       this.rsBuffer.append(rs);
/*     */     }
/*     */ 
/* 404 */     OrderedJSONObject mboAttributesOjo = null;
/* 405 */     if (!(this.compact))
/*     */     {
/* 407 */       mboAttributesOjo = new OrderedJSONObject();
/*     */     }
/*     */     else
/*     */     {
/* 411 */       mboAttributesOjo = mboOjo;
/*     */     }
/*     */ 
/* 414 */     if (!(this.compact))
/*     */     {
/* 416 */       mboOjo.put("Attributes", mboAttributesOjo);
/*     */     }
/* 418 */     if ((!(this.exclude)) && (this.cols != null) && (this.cols.size() > 0))
/*     */     {
/* 420 */       for (String attributeName : this.cols)
/*     */       {
/* 422 */         MboValueInfo mboValueInfo = mbo.getThisMboSet().getMboSetInfo().getAttribute(attributeName);
/* 423 */         setJSONObjectAttribute(mboValueInfo, mbo, mboAttributesOjo, null, false);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 428 */       Enumeration mboValueInfos = mbo.getThisMboSet().getMboSetInfo().getMboValuesInfo();
/*     */ 
/* 430 */       while (mboValueInfos.hasMoreElements())
/*     */       {
/* 432 */         MboValueInfo mboValueInfo = (MboValueInfo)mboValueInfos.nextElement();
/* 433 */         if ((this.exclude) && (this.cols != null) && (this.cols.contains(mboValueInfo.getAttributeName())))

/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 439 */         setJSONObjectAttribute(mboValueInfo, mbo, mboAttributesOjo, null, false);
/*     */       }
/*     */     }
/*     */   }


/*     */   protected void setJSONObjectAttribute(MboValueInfo mboValueInfo, MboRemote mbo, OrderedJSONObject mboOjo, Object ovrdColValue, boolean overridden)
/*     */     throws RemoteException, MXException
/*     */   {
/* 448 */     String attributeName = mboValueInfo.getName();
/* 449 */     if (attributeName.endsWith("_BASELANGUAGE")) return;
/*     */ 
/* 451 */     byte[] attachedDoc = null;
/* 452 */     boolean attachmentCol = false;
/* 453 */     if ((mbo.getName().equals("DOCLINKS")) && (mbo.getString("urltype").equals("FILE")) && (attributeName.equalsIgnoreCase("DOCUMENTDATA")))
/*     */     {
/* 455 */       attachmentCol = true;
/* 456 */       attachedDoc = XMLUtils.readXMLFileToBytes(mbo.getString("urlname"));
/*     */     }
/*     */ 
/* 459 */     if (this.dropNulls)
/*     */     {
/* 461 */       if (overridden)
/*     */       {
/* 463 */         if (ovrdColValue == null)
/*     */         {
/* 465 */           if (logger.isDebugEnabled())
/*     */           {
/* 467 */             logger.debug("dropping null column " + attributeName + " for mbo " + mbo.getName() + " due to override as null");
/*     */           }
/* 469 */           return;
/*     */         }
/*     */       }
/* 472 */       else if (((attachmentCol) && (attachedDoc == null)) || (mbo.isNull(attributeName)))
/*     */       {
/* 474 */         if (logger.isDebugEnabled())
/*     */         {
/* 476 */           logger.debug("dropping null column " + attributeName + " for mbo " + mbo.getName());
/*     */         }
/* 478 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 483 */     int maxType = mboValueInfo.getTypeAsInt();
/* 484 */     if (maxType == 16)
/*     */     {
/* 486 */       return;

/*     */     }
/*     */ 
/* 490 */     OrderedJSONObject attrObject = null;
/* 491 */     if (!(this.compact))
/*     */     {
/* 493 */       attrObject = new OrderedJSONObject();
/*     */     }
/* 495 */     if (!(this.generic))
/*     */     {
/* 497 */       if (!(this.compact))
/*     */       {
/* 499 */         mboOjo.put(attributeName, attrObject);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 504 */       JSONArray jsonArray = (JSONArray)mboOjo.get("Attribute");
/* 505 */       if (jsonArray == null)
/*     */       {
/* 507 */         jsonArray = new JSONArray();
/* 508 */         mboOjo.put("Attribute", jsonArray);
/*     */       }
/* 510 */       attrObject.put("name", attributeName);
/* 511 */       jsonArray.add(attrObject);
/*     */     }
/*     */ 
/* 514 */     if (this.metaData)
/*     */     {
/* 516 */       if (((Mbo)mbo).getAttrRestrictionFlag(attributeName).isFlagSet(263L))
/*     */       {
/* 518 */         attrObject.put("hidden", Boolean.valueOf(true));
/*     */       }
/*     */       else
/*     */       {
/* 522 */         attrObject.put("hidden", Boolean.valueOf(false));
/*     */       }
/* 524 */       if (((Mbo)mbo).getAttrRestrictionFlag(attributeName).isFlagSet(7L))
/*     */       {
/* 526 */         attrObject.put("readonly", Boolean.valueOf(true));
/*     */       }
/*     */       else
/*     */       {
/* 530 */         attrObject.put("readonly", Boolean.valueOf(false));
/*     */       }
/* 532 */       if ((((Mbo)mbo).getAttrRestrictionFlag(attributeName).isFlagSet(128L)) || (mboValueInfo.isRequired()))
/*     */       {
/* 534 */         attrObject.put("required", Boolean.valueOf(true));
/*     */       }
/*     */       else
/*     */       {
/* 538 */         attrObject.put("required", Boolean.valueOf(false));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 543 */     boolean uniqueId = false;
/* 544 */     if (mbo.getUniqueIDName().equals(attributeName))
/*     */     {
/* 546 */       uniqueId = true;
/*     */     }
/* 548 */     if (logger.isDebugEnabled())
/*     */     {
/* 550 */       logger.debug("attribute name==" + attributeName + " value =" + mbo.getMboValueData(attributeName).getDataAsObject());
/*     */     }
/* 552 */     Locale clientLocale = ((Mbo)mbo).getClientLocale();
/* 553 */     switch (maxType)
/*     */     {
/*     */     case 0:
/*     */     case 1:
/*     */     case 2:
/*     */     case 13:
/*     */     case 14:
/*     */     case 17:
/* 561 */       String jsonData = (overridden) ? (String)ovrdColValue : mbo.getString(attributeName);
/* 562 */       if (!(this.compact))
/*     */       {
/* 564 */         attrObject.put("content", jsonData);
/* 565 */         if (!(this.locale))
/*     */           return;
/* 567 */         attrObject.put("localecontent", jsonData); return;


/*     */       }
/*     */ 
/* 572 */       mboOjo.put(attributeName, jsonData);
/*     */ 
/* 574 */       break;
/*     */     case 15:
/* 576 */       String base64PasswordData = null;
/*     */ 
/* 578 */       String clearTextVal = (overridden) ? (String)ovrdColValue : mbo.getString(attributeName);
/* 579 */       if (clearTextVal != null)
/*     */       {
/* 581 */         byte[] encData = MXServer.getMXServer().getMXCipher().encData(clearTextVal);
/* 582 */         base64PasswordData = Base64.encode(encData);
/*     */       }
/*     */ 
/* 585 */       if (!(this.compact))
/*     */       {
/* 587 */         attrObject.put("content", base64PasswordData);
/* 588 */         if (!(this.locale))
/*     */           return;
/* 590 */         attrObject.put("localecontent", base64PasswordData); return;


/*     */       }
/*     */ 
/* 595 */       mboOjo.put(attributeName, base64PasswordData);
/*     */ 
/* 597 */       break;
/*     */     case 6:
/*     */     case 7:
/*     */     case 19:
/* 601 */       long jsonLData = (overridden) ? ((Long)ovrdColValue).longValue() : mbo.getLong(attributeName);
/* 602 */       if (!(this.compact))
/*     */       {
/* 604 */         if (!(uniqueId))
/*     */         {
/* 606 */           attrObject.put("content", Long.valueOf(jsonLData));
/*     */         }
/*     */         else
/*     */         {
/* 610 */           attrObject.put("content", Long.valueOf(jsonLData));
/* 611 */           attrObject.put("resourceid", Boolean.valueOf(true));
/*     */         }
/*     */ 
/* 614 */         if (!(this.locale))
/*     */           return;
/* 616 */         String localeData = MXFormat.longToString(jsonLData, clientLocale);
/* 617 */         attrObject.put("localecontent", localeData);
/* 618 */         return;

/*     */       }
/*     */ 
/* 622 */       if (this.locale)
/*     */       {
/* 624 */         mboOjo.put(attributeName, MXFormat.longToString(jsonLData, clientLocale)); return;

/*     */       }
/*     */ 
/* 628 */       mboOjo.put(attributeName, Long.valueOf(jsonLData));

/*     */ 
/* 631 */       break;
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/* 636 */       double jsonDData = (overridden) ? ((Double)ovrdColValue).doubleValue() : mbo.getDouble(attributeName);
/* 637 */       if (!(this.compact))
/*     */       {
/* 639 */         attrObject.put("content", Double.valueOf(jsonDData));
/* 640 */         if (!(this.locale))
/*     */           return;
/* 642 */         attrObject.put("localecontent", MXFormat.doubleToString(jsonDData, clientLocale)); return;


/*     */       }
/*     */ 
/* 647 */       if (this.locale)
/*     */       {
/* 649 */         mboOjo.put(attributeName, MXFormat.doubleToString(jsonDData, clientLocale)); return;

/*     */       }
/*     */ 
/* 653 */       mboOjo.put(attributeName, Double.valueOf(jsonDData));

/*     */ 
/* 656 */       break;
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/* 660 */       Date jsonDTData = (overridden) ? (Date)ovrdColValue : mbo.getDate(attributeName);
/* 661 */       if (!(this.compact))
/*     */       {
/* 663 */         attrObject.put("content", (mbo.isNull(attributeName)) ? null : ConversionUtil.dateToString(jsonDTData));
/* 664 */         if (!(this.locale))
/*     */           return;
/* 666 */         attrObject.put("localecontent", MXFormat.dateToString(jsonDTData, clientLocale, ((Mbo)mbo).getClientTimeZone())); return;


/*     */       }
/*     */ 
/* 671 */       if (this.locale)
/*     */       {
/* 673 */         mboOjo.put(attributeName, MXFormat.dateToString(jsonDTData, clientLocale, ((Mbo)mbo).getClientTimeZone())); return;

/*     */       }
/*     */ 
/* 677 */       mboOjo.put(attributeName, (mbo.isNull(attributeName)) ? null : ConversionUtil.dateToString(jsonDTData));

/*     */ 
/* 680 */       break;
/*     */     case 12:
/* 682 */       boolean jsonBool = (overridden) ? ((Boolean)ovrdColValue).booleanValue() : mbo.getBoolean(attributeName);
/* 683 */       if (!(this.compact))
/*     */       {
/* 685 */         attrObject.put("content", Boolean.valueOf(jsonBool));
/* 686 */         if (!(this.locale))
/*     */           return;
/* 688 */         attrObject.put("localecontent", MXFormat.booleanToString(jsonBool, clientLocale)); return;


/*     */       }
/*     */ 
/* 693 */       if (this.locale)
/*     */       {
/* 695 */         mboOjo.put(attributeName, MXFormat.booleanToString(jsonBool, clientLocale)); return;

/*     */       }
/*     */ 
/* 699 */       mboOjo.put(attributeName, Boolean.valueOf(jsonBool));

/*     */ 
/* 702 */       break;
/*     */     case 18:
/* 704 */       byte[] data = null;
/* 705 */       if (attachmentCol)
/*     */       {
/* 707 */         data = (overridden) ? (byte[])(byte[])ovrdColValue : attachedDoc;
/*     */       }
/*     */       else
/*     */       {
/* 711 */         data = (overridden) ? (byte[])(byte[])ovrdColValue : mbo.getBytes(attributeName);
/*     */       }
/* 713 */       String base64Data = Base64.encode(data);
/* 714 */       if (!(this.compact))
/*     */       {
/* 716 */         attrObject.put("content", base64Data);
/* 717 */         if (!(this.locale))
/*     */           return;
/* 719 */         attrObject.put("localecontent", base64Data); return;


/*     */       }
/*     */ 
/* 724 */       mboOjo.put(attributeName, base64Data);
/*     */     case 16:
/*     */     }
/*     */   }



/*     */   public void setResolvedTotalCount(int resolvedTotalCount)
/*     */   {
/* 733 */     this.resolvedTotalCount = resolvedTotalCount;
/*     */   }

/*     */   public void setResolvedStartCount(int resolvedStartCount)
/*     */   {
/* 738 */     this.resolvedStartCount = resolvedStartCount;
/*     */   }

/*     */   public void setInitialResolvedCount(int initialResolvedCount)
/*     */   {
/* 743 */     this.initialResolvedCount = initialResolvedCount;
/*     */   }
/*     */ }
