package com.ibm.tivoli.maximo.rest;

public abstract interface RestConstants
{
  public static final String RESTSESSION = "restsession";
  public static final String SESSION_OSMSGTYPE = "session_osmsgtype";
  public static final String EXACTMATCH = "_exactmatch";
  public static final String ORDERBYASC = "_orderbyasc";
  public static final String ORDERBYDESC = "_orderbydesc";
  public static final String OPMODEOR = "_opmodeor";
  public static final String GRATERTHAN = "~gt~";
  public static final String GRATERTHANEQUALS = "~gteq~";
  public static final String LESSTHAN = "~lt~";
  public static final String LESSTHANEQUALS = "~lteq~";
  public static final String ENDSWITH = "~ew~";
  public static final String STARTSSWITH = "~sw~";
  public static final String EQUALS = "~eq~";
  public static final String NOTEQUALS = "~neq~";
  public static final String DROPNULLS = "_dropnulls";
  public static final String GENERIC = "_generic";
  public static final String ROOTONLY = "_rootonly";
  public static final String LOCALE = "_locale";
  public static final String RETAINMBOS = "_retainmbos";
  public static final String KEYS = "_keys";
  public static final String VERBOSE = "_verbose";
  public static final String RSSTART = "_rsStart";
  public static final String MAXITEMS = "_maxItems";
  public static final String INCLUDECOLS = "_includecols";
  public static final String EXCLUDECOLS = "_excludecols";
  public static final String LANGCODE = "_lang";
  public static final String TIMEZONE = "_tz";
  public static final String FILTERDOMAIN = "_fd";
  public static final String FILTERDOMAIN_SITE = "_fdsite";
  public static final String FILTERDOMAIN_ORG = "_fdorg";
  public static final String LOGINID = "_lid";
  public static final String LOGINPASSWORD = "_lpwd";
  public static final String METADATA = "_md";
  public static final String COMPACT = "_compact";
  public static final String MXRESTSESSION = "MXRESTSession";
  public static final String MAXAUTHTOKEN = "__mxtoken";
  public static final String MAXUSER = "__mxuser";
  public static final String QUERY_OPERATION = "_qop";
  public static final String PRODUCT_ID = "_pid";
  public static final String OPERATION_PARAM_NS = "~";
  public static final String GLCOMP = "_glc";
  public static final String VALIDATE_XML_TEXT = "_vt";
  public static final String RELATED_ATTRBUTE = "_rcol";
  public static final String USE_TOTAL_COUNT = "_tc";
}
