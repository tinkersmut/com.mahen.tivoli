/*     */ package com.ibm.tivoli.maximo.authsync;
/*     */ 
/*     */ import com.collation.platform.model.Guid;
/*     */ import com.collation.platform.model.GuidFormatException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import psdi.iface.mic.MaxExtIfaceOut;
/*     */ import psdi.iface.mic.MaxExtIfaceOutInfo;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.iface.migexits.ExternalExit;
/*     */ import psdi.iface.router.Router;
/*     */ import psdi.iface.router.RouterHandler;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
















/*     */ public class AuthSyncColExit extends ExternalExit
/*     */ {
/*     */   public StructureData setDataOut(StructureData userExitData)
/*     */     throws MXException, RemoteException
/*     */   {
/*  43 */     integrationLogger.info("AuthSyncColExit: Entering setDataOut ");
/*     */ 
/*  45 */     Map taddmData = new HashMap();
/*     */ 
/*  47 */     String collectionName = userExitData.getCurrentData("COLLECTIONNUM");
/*  48 */     String action = userExitData.getAction();
/*     */ 
/*  50 */     if (action == null) {
/*  51 */       if (integrationLogger.isDebugEnabled()) {
/*  52 */         integrationLogger.debug("Action is null. Skipping transaction");
/*     */       }
/*  54 */       throw new MXApplicationException("iface", "skip_transaction");
/*     */     }
/*     */ 
/*  57 */     taddmData.put("TYPE", "COLLECTION");
/*  58 */     taddmData.put("ACTION", action);
/*  59 */     taddmData.put("COLLECTIONNUM", collectionName);
/*     */ 
/*  61 */     int actualCICount = 0;
/*  62 */     int authorizedCICount = 0;
/*  63 */     int topLevelActualCICount = 0;
/*     */ 
/*  65 */     List topLevelActualCIList = new ArrayList();
/*     */ 
/*  67 */     if (!(action.equalsIgnoreCase("Delete"))) {
/*  68 */       MboSetRemote collectLineSet = userExitData.getCurrentMbo().getMboSet("COLLECTDETAILS");

/*     */ 
/*  71 */       if (!(collectLineSet.isEmpty())) {
/*  72 */         int i = 0;
/*     */         while (true)
/*     */         {
/*  75 */           MboRemote collectDetailsMbo = null;
/*  76 */           collectDetailsMbo = collectLineSet.getMbo(i);
/*     */ 
/*  78 */           if (collectDetailsMbo == null) {
/*     */             break;
/*     */           }
/*     */ 
/*  82 */           ++i;
/*  83 */           boolean deleteFlag = false;
/*  84 */           deleteFlag = collectDetailsMbo.toBeDeleted();
/*  85 */           if (!(deleteFlag))
/*     */           {
/*  87 */             MboSetRemote ciSet = collectDetailsMbo.getMboSet("CI");
/*     */ 
/*  89 */             if (!(ciSet.isEmpty()))
/*     */             {
/*  91 */               ++authorizedCICount;
/*     */ 
/*  93 */               ciSet.getMbo(0).getString("cinum");
/*     */ 
/*  95 */               MboSetRemote actualCISet = ciSet.getMbo(0).getMboSet("ACTUALCI");

/*     */ 
/*  98 */               if (!(actualCISet.isEmpty()))
/*     */               {
/* 100 */                 ++actualCICount;



/*     */ 
/* 105 */                 String ciguid = actualCISet.getMbo(0).getString("GUID");

/*     */ 
/* 108 */                 integrationLogger.info("Authorized CI linked to Actual CI with GUID " + ciguid);


/*     */ 
/* 112 */                 if (integrationLogger.isDebugEnabled()) {
/* 113 */                   integrationLogger.debug("Authorized CI linked to Actual CI with GUID " + ciguid);


/*     */                 }
/*     */ 
/* 118 */                 ++topLevelActualCICount;
/* 119 */                 topLevelActualCIList.add(ciguid);





/*     */               }
/*     */ 
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 135 */       if (integrationLogger.isDebugEnabled()) {
/* 136 */         integrationLogger.debug("Authorized CI count : " + authorizedCICount + ". Actual CI count : " + actualCICount + ". Top Level Actual CI count : " + topLevelActualCICount);



/*     */       }
/*     */ 
/* 142 */       if (topLevelActualCICount > 0) {
/* 143 */         Guid[] members = new Guid[topLevelActualCICount];
/* 144 */         for (int i = 0; i < topLevelActualCICount; ++i) {
/*     */           try {
/* 146 */             members[i] = new Guid((String)topLevelActualCIList.get(i));
/*     */           }
/*     */           catch (GuidFormatException ex)
/*     */           {
/* 150 */             throw new MXApplicationException("iface", "skip_transaction");
/*     */           }
/*     */         }
/*     */ 
/* 154 */         taddmData.put("COLLECTIONMEMBERS", members);
/*     */       }
/*     */     }
/*     */ 
/* 158 */     String extsystem = getExtSystem();
/* 159 */     String ifaceName = getIfaceName();
/*     */ 
/* 161 */     MaxExtIfaceOutInfo info = MaxExtIfaceOut.getMaxExtIfaceOut().getExtIfaceOutInfo(extsystem, ifaceName);

/*     */ 
/* 164 */     String endPointName = info.getEndPoint();
/* 165 */     Router.getHandler(endPointName).invoke(taddmData, null);
/*     */ 
/* 167 */     integrationLogger.info("AuthSyncColExit: Leaving setDataOut ");
/*     */ 
/* 169 */     throw new MXApplicationException("iface", "skip_transaction");
/*     */   }
/*     */ }
