/*     */ package com.ibm.tivoli.maximo.authsync;
/*     */ 
/*     */ import com.collation.authorizationmgr.auth.GroupPrincipal;
/*     */ import com.collation.authorizationmgr.client.Resource;
/*     */ import com.collation.platform.model.Guid;
/*     */ import com.collation.platform.model.ModelObject;
/*     */ import com.collation.platform.model.topology.process.AccessCollection;
/*     */ import com.collation.proxy.api.client.ApiConnection;
/*     */ import com.collation.proxy.api.client.ApiSession;
/*     */ import com.collation.proxy.api.client.CMDBApi;
/*     */ import com.collation.proxy.api.client.DataResultSet;
/*     */ import com.collation.proxy.api.util.ModelObjectFactory;
/*     */ import com.ibm.cdb.api.ApiFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import psdi.iface.mic.MaxEndPointInfo;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.iface.router.BaseRouterHandler;
/*     */ import psdi.iface.router.RouterPropsInfo;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 




































/*     */ public class TADDMHandler extends BaseRouterHandler
/*     */ {
/*     */   public static final String HOSTNAME = "HOSTNAME";
/*     */   public static final String PORT = "PORT";
/*     */   public static final String USERNAME = "USERNAME";
/*     */   public static final String PASSWORD = "PASSWORD";
/*  61 */   public CMDBApi api = null;
/*     */ 
/*  63 */   private static List<RouterPropsInfo> props = new ArrayList(4);
/*     */ 
/*     */   public TADDMHandler(MaxEndPointInfo endPointInfo)
/*     */   {
/*  74 */     super(endPointInfo);
/*     */   }











/*     */   public byte[] invoke(Map<String, ?> metaData, byte[] data)
/*     */     throws MXException
/*     */   {
/*  90 */     MicUtil.INTEGRATIONLOGGER.info("TADDMHandler: Entering invoke ");

/*     */ 
/*  93 */     data = super.invoke(metaData, data);
/*     */ 
/*  95 */     if ((metaData == null) && (this.endPointPropVals == null)) {
/*  96 */       throw new MXApplicationException("iface", "noendpointprops");
/*     */     }
/*     */     try
/*     */     {
/* 100 */       ApiSession sess = null;
/* 101 */       Guid guid = null;
/* 102 */       int port = Integer.parseInt(getPort());
/* 103 */       ApiConnection conn = null;















/*     */ 
/* 120 */       if (port == 9531) {
/* 121 */         conn = ApiFactory.getInstance().getApiConnection(getHostname(), port, System.getProperty("com.collation.home") + "/etc/jssecacerts.cert", true);


/*     */       }
/*     */       else
/*     */       {
/* 127 */         conn = ApiFactory.getInstance().getApiConnection(getHostname(), port, null, false);





/*     */       }
/*     */ 
/* 135 */       sess = ApiFactory.getInstance().getSession(conn, getUsername(), getPassword(), 0L);



/*     */ 
/* 140 */       this.api = sess.createCMDBApi();
/*     */ 
/* 142 */       this.metaData = metaData;
/*     */ 
/* 144 */       String type = (String)metaData.get("TYPE");
/* 145 */       String colName = (String)metaData.get("COLLECTIONNUM");
/* 146 */       String action = (String)metaData.get("ACTION");
/*     */ 
/* 148 */       if (type.equalsIgnoreCase("COLLECTION"))
/*     */       {
/* 150 */         if (action.equalsIgnoreCase("Add"))
/*     */         {
/* 152 */           Guid[] members = (Guid[])(Guid[])metaData.get("COLLECTIONMEMBERS");
/* 153 */           if (members != null)
/*     */           {
/* 155 */             Guid acguid = addAccessCollection(null, colName);
/*     */ 
/* 157 */             if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 158 */               MicUtil.INTEGRATIONLOGGER.debug("Added collection " + colName);
/*     */             }
/*     */ 
/* 161 */             addMembersToCollection(acguid, members);




/*     */ 
/* 167 */             if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 168 */               MicUtil.INTEGRATIONLOGGER.debug("Added " + members.length + " members to collection " + colName);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/* 174 */         else if (action.equalsIgnoreCase("Delete"))
/*     */         {
/* 176 */           Guid acguid = getCollectionGuidByName(colName);
/*     */ 
/* 178 */           if (acguid != null) {
/* 179 */             deleteAccessCollection(null, acguid);



/*     */ 
/* 184 */             if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 185 */               MicUtil.INTEGRATIONLOGGER.debug("Deleted collection " + colName);






/*     */             }
/*     */ 
/*     */           }
/* 195 */           else if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 196 */             MicUtil.INTEGRATIONLOGGER.debug("Cannot delete collection " + colName + ". Not present in TADDM server.");



/*     */           }
/*     */ 
/*     */         }
/* 203 */         else if (action.equalsIgnoreCase("Replace"))






/*     */         {
/* 211 */           Guid acguid = getCollectionGuidByName(colName);
/*     */ 
/* 213 */           if (acguid != null) {
/* 214 */             deleteAccessCollection(null, getCollectionGuidByName(colName));







/*     */           }
/* 223 */           else if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 224 */             MicUtil.INTEGRATIONLOGGER.debug("Cannot delete collection " + colName + ". Not present in TADDM server.");



/*     */           }
/*     */ 
/* 230 */           Guid[] members = (Guid[])(Guid[])metaData.get("COLLECTIONMEMBERS");
/* 231 */           if (members != null) {
/* 232 */             acguid = addAccessCollection(null, colName);
/* 233 */             addMembersToCollection(acguid, members);



/*     */           }
/*     */ 
/* 239 */           if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 240 */             MicUtil.INTEGRATIONLOGGER.debug("Updated collection " + colName);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 245 */       else if (type.equalsIgnoreCase("COLLECTIONAUTH")) {
/* 246 */         groupName = (String)metaData.get("GROUPNAME");
/* 247 */         GroupPrincipal groupPrincipal = new GroupPrincipal(groupName);
/* 248 */         Guid acguid = getCollectionGuidByName(colName);
/*     */ 
/* 250 */         if (acguid != null) {
/* 251 */           Resource resource = new Resource(colName, acguid.toString());
/*     */ 
/* 253 */           if (action.equalsIgnoreCase("Add"))
/*     */           {
/* 255 */             this.api.addAccess(groupPrincipal, resource, "operator", new String[] { "Read" });






/*     */ 
/* 263 */             if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 264 */               MicUtil.INTEGRATIONLOGGER.debug("Adding security group " + groupName + " to collection " + colName);

/*     */             }
/*     */ 
/*     */           }
/* 269 */           else if (action.equalsIgnoreCase("Delete"))
/*     */           {
/* 271 */             this.api.deleteAccess(groupPrincipal, resource, "operator", new String[] { "Read" });







/*     */ 
/* 280 */             if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 281 */               MicUtil.INTEGRATIONLOGGER.debug("Removing security group " + groupName + " from collection " + colName);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 290 */       this.api.close();


/*     */ 
/* 294 */       String groupName = null;
/*     */     }/*     */     catch (Exception e)
/*     */     {
/* 297 */       MicUtil.INTEGRATIONLOGGER.error(e);
/* 298 */       if (e instanceof MXException);

/* 300 */       throw new MXSystemException("iface", "could_not_send", e);
/*     */     } finally {
/*     */       try {
/* 303 */         if (this.api != null)
/* 304 */           this.api.close();
/*     */ 
/*     */       } catch (Exception apiex) {/* 306 */       return groupName;/* 306 */         throw new MXSystemException("iface", "could_not_send", apiex);
/*     */       }
/*     */     }
/*     */   }

/*     */   public List<RouterPropsInfo> getProperties() {
/* 312 */     return props;
/*     */   }



/*     */   private String getHostname()
/*     */   {
/* 319 */     return getPropertyValue("HOSTNAME");
/*     */   }



/*     */   private String getPort()
/*     */   {
/* 326 */     return getPropertyValue("PORT");
/*     */   }





/*     */   private String getUsername()
/*     */   {
/* 335 */     return getPropertyValue("USERNAME");
/*     */   }



/*     */   private String getPassword()
/*     */   {
/* 342 */     return getPropertyValue("PASSWORD");
/*     */   }

/*     */   public Guid getCollectionGuidByName(String colName) throws MXException {
/* 346 */     ModelObject mo = null;
/* 347 */     Guid collectionGuid = null;
/*     */     try {
/* 349 */       String query = "SELECT * from AccessCollection where name=='" + colName + "'";

/*     */ 
/* 352 */       MicUtil.INTEGRATIONLOGGER.info("TADDMHandler: Entering getCollectionGuidByName ");
/*     */ 
/* 354 */       MicUtil.INTEGRATIONLOGGER.debug("getCollectionGuidByName: executeQuery(before) ");
/*     */ 
/* 356 */       DataResultSet results = this.api.executeQuery(query, null, null);
/*     */ 
/* 358 */       MicUtil.INTEGRATIONLOGGER.debug("results = " + results);
/* 359 */       MicUtil.INTEGRATIONLOGGER.debug("getCollectionGuidByName: executeQuery(after) ");
/*     */ 
/* 361 */       if (results.next())
/*     */       {
/* 363 */         MicUtil.INTEGRATIONLOGGER.debug("getCollectionGuidByName: getModelObject(before) ");
/*     */ 
/* 365 */         mo = results.getModelObject(1);
/*     */ 
/* 367 */         MicUtil.INTEGRATIONLOGGER.debug("mo = " + mo);
/* 368 */         MicUtil.INTEGRATIONLOGGER.debug("getCollectionGuidByName: getModelObject(after) ");
/*     */ 
/* 370 */         if (mo != null) {
/* 371 */           collectionGuid = mo.getGuid();
/*     */ 
/* 373 */           MicUtil.INTEGRATIONLOGGER.debug("mo.getGuid() = " + collectionGuid);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 378 */       MicUtil.INTEGRATIONLOGGER.error(ex);
/* 379 */       throw new MXSystemException("iface", "could_not_send", ex);
/*     */     }
/*     */ 
/* 382 */     MicUtil.INTEGRATIONLOGGER.info("TADDMHandler: Leaving getCollectionGuidByName ");
/*     */ 
/* 384 */     return collectionGuid;
/*     */   }

/*     */   public void addMembersToCollection(Guid collection, Guid[] members) throws MXException
/*     */   {
/*     */     try
/*     */     {
/* 391 */       this.api.addCollectionMembers(collection, members);
/*     */     } catch (Exception ex) {
/* 393 */       MicUtil.INTEGRATIONLOGGER.error(ex);
/* 394 */       throw new MXSystemException("iface", "could_not_send", ex);
/*     */     }
/*     */   }

/*     */   public void removeMembersToCollection(Guid collection, Guid[] members) throws MXException
/*     */   {
/*     */     try
/*     */     {
/* 402 */       this.api.removeCollectionMembers(collection, members);
/*     */     } catch (Exception ex) {
/* 404 */       MicUtil.INTEGRATIONLOGGER.error(ex);
/* 405 */       throw new MXSystemException("iface", "could_not_send", ex);
/*     */     }
/*     */   }

/*     */   public Guid addAccessCollection(Guid mssGuid, String collectionName) throws MXException
/*     */   {
/*     */     try {
/* 412 */       AccessCollection c = (AccessCollection)ModelObjectFactory.newInstance(AccessCollection.class);
/*     */ 
/* 414 */       c.setName(collectionName);
/* 415 */       c.setSourceToken(collectionName);
/* 416 */       c.setLabel(collectionName + " Maximo Collection");
/* 417 */       c.setDescription(collectionName + " Collection created in Maximo");
/* 418 */       Guid cGuid = this.api.update(c, mssGuid);
/* 419 */       c.setGuid(cGuid);
/*     */ 
/* 421 */       return cGuid;
/*     */     } catch (Exception ex) {
/* 423 */       MicUtil.INTEGRATIONLOGGER.error(ex);
/* 424 */       throw new MXSystemException("iface", "could_not_send", ex);
/*     */     }
/*     */   }

/*     */   public int deleteAccessCollection(Guid mssGuid, Guid collectionGuid)
/*     */     throws MXException
/*     */   {
/* 431 */     int num = 0;
/*     */     try
/*     */     {
/* 434 */       Guid[] acGuids = new Guid[1];
/* 435 */       acGuids[0] = collectionGuid;
/*     */ 
/* 437 */       num = this.api.delete(acGuids, mssGuid);
/* 438 */       return num;
/*     */     } catch (Exception ex) {
/* 440 */       MicUtil.INTEGRATIONLOGGER.error(ex);
/* 441 */       throw new MXSystemException("iface", "could_not_send", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  67 */     props.add(new RouterPropsInfo("HOSTNAME"));
/*  68 */     props.add(new RouterPropsInfo("PORT"));
/*  69 */     props.add(new RouterPropsInfo("USERNAME"));
/*  70 */     props.add(new RouterPropsInfo("PASSWORD", true));
/*     */   }
/*     */ }
