/*    */ package com.ibm.tivoli.maximo.authsync;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import psdi.iface.mic.MaxExtIfaceOut;
/*    */ import psdi.iface.mic.MaxExtIfaceOutInfo;
/*    */ import psdi.iface.mic.StructureData;
/*    */ import psdi.iface.migexits.ExternalExit;
/*    */ import psdi.iface.router.Router;
/*    */ import psdi.iface.router.RouterHandler;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.logging.MXLogger;
/*    */ 




















/*    */ public class AuthSyncColAuthExit extends ExternalExit
/*    */ {
/*    */   public StructureData setDataOut(StructureData userExitData)
/*    */     throws MXException, RemoteException
/*    */   {
/* 41 */     integrationLogger.info("AuthSyncColAuthExit: Entering setDataOut ");
/*    */ 
/* 43 */     Map taddmData = new HashMap();
/*    */ 
/* 45 */     String collectionName = userExitData.getCurrentData("COLLECTIONNUM");
/* 46 */     String groupName = userExitData.getCurrentData("GROUPNAME");
/* 47 */     String action = userExitData.getAction();
/*    */ 
/* 49 */     if (action == null) {
/* 50 */       if (integrationLogger.isDebugEnabled()) {
/* 51 */         integrationLogger.debug("Action is null. Skipping transaction");
/*    */       }
/* 53 */       throw new MXApplicationException("iface", "skip_transaction");
/*    */     }
/*    */ 
/* 56 */     taddmData.put("TYPE", "COLLECTIONAUTH");
/* 57 */     taddmData.put("ACTION", action);
/* 58 */     taddmData.put("COLLECTIONNUM", collectionName);
/* 59 */     taddmData.put("GROUPNAME", groupName);


/*    */ 
/* 63 */     String extsystem = getExtSystem();
/* 64 */     String ifaceName = getIfaceName();
/*    */ 
/* 66 */     MaxExtIfaceOutInfo info = MaxExtIfaceOut.getMaxExtIfaceOut().getExtIfaceOutInfo(extsystem, ifaceName);

/*    */ 
/* 69 */     String endPointName = info.getEndPoint();
/*    */ 
/* 71 */     Router.getHandler(endPointName).invoke(taddmData, null);
/*    */ 
/* 73 */     integrationLogger.info("AuthSyncColAuthExit: Exiting setDataOut ");
/*    */ 
/* 75 */     throw new MXApplicationException("iface", "skip_transaction");
/*    */   }
/*    */ }
