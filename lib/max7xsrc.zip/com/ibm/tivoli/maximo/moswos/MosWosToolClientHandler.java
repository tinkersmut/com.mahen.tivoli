/*     */ package com.ibm.tivoli.maximo.moswos;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.RuntimeMXBean;
/*     */ import java.net.MalformedURLException;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.DBManager;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.MXServerRemote;
/*     */ import psdi.server.SrvCommRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.ToolClientHandler;
/*     */ import psdi.util.Version;
/*     */ import psdi.util.logging.FixedLoggers;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 

























/*     */ public class MosWosToolClientHandler
/*     */   implements ToolClientHandler
/*     */ {
/*  58 */   private static MXLogger logger = FixedLoggers.MAXIMOLOGGER;
/*     */ 
/*  60 */   final String handle1 = "handleforDataBaseInfo";
/*  61 */   final String handle2 = "handleforInstalledApps";
/*  62 */   final String handle3 = "handleforCronTasks";
/*  63 */   final String handle4 = "handleforLicense";
/*  64 */   final String handle5 = "handleforMemory";
/*  65 */   final String handle6 = "handleforInstalledProducts";
/*  66 */   final String handle7 = "handleforMemoryGauge";
/*  67 */   final String handle8 = "handleforUsersPerServerGauge";
/*  68 */   final String handle9 = "handleforRuntimeMXBean";
/*  69 */   final String handle10 = "handleforSysInfo";
/*  70 */   final String handle11 = "handleforDBConnections";
/*  71 */   final String handle12 = "handleforMemGaugeForAllSrvrs";
/*  72 */   final String handle13 = "handleforMBOCountGauge";
/*  73 */   final String handle14 = "handleforEscalationErrorLog";
/*  74 */   final String handle15 = "handleforMemoryBean";
/*  75 */   final String handle16 = "handleforGarbageCollectorBean";
/*  76 */   final String serverlist = "handleforServerList";
/*     */ 
/*     */   public Object dispatchRequest(MXSession mxSession, String command, Object[] params)
/*     */     throws MXException, RemoteException
/*     */   {
/*  87 */     MXServerRemote msr = mxSession.getMXServerRemote();
/*  88 */     if (command != null)
/*     */     {
/*  90 */       if (command.equalsIgnoreCase("handleforDataBaseInfo"))
/*     */       {
/*  92 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/*  93 */         String[] data = { msr.getAppServerNameandVersion(), msr.getDatabaseProductName(), msr.getBaseLang() };

/*     */ 
/*  96 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/*  97 */         return data;
/*     */       }
/*  99 */       if (command.equalsIgnoreCase("handleforInstalledApps"))
/*     */       {
/* 101 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 102 */         String[] data = msr.getLocalAppList();
/* 103 */         Arrays.sort(data);
/* 104 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 105 */         return data;
/*     */       }
/* 107 */       if (command.equalsIgnoreCase("handleforCronTasks"))
/*     */       {
/* 109 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 110 */         MboSetRemote ci = msr.getMboSet("CRONTASKINSTANCE", mxSession.getUserInfo());
/* 111 */         MboSetRemote ts = msr.getMboSet("TASKSCHEDULER", mxSession.getUserInfo());
/* 112 */         int count = ci.count();
/* 113 */         ArrayList data = new ArrayList();
/* 114 */         for (int i = 0; i < count; ++i)
/*     */         {
/* 116 */           MboRemote mr = ci.getMbo(i);
/* 117 */           String task = mr.getString("CRONTASKNAME") + "." + mr.getString("INSTANCENAME");
/* 118 */           String where = "taskname = '" + task + "'";
/* 119 */           SqlFormat sqlFormat = new SqlFormat(where);
/* 120 */           where = sqlFormat.format();
/* 121 */           ts.setWhere(where);
/* 122 */           ts.reset();
/* 123 */           String[] mydata = { mr.getString("CRONTASKNAME"), mr.getString("INSTANCENAME"), mr.getString("ACTIVE"), (ts.getMbo(0) != null) ? ts.getMbo(0).getString("LASTRUN") : "" };


/*     */ 
/* 127 */           data.add(mydata);
/*     */         }
/* 129 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 130 */         return data;
/*     */       }
/* 132 */       if (command.equalsIgnoreCase("handleforLicense"))
/*     */       {
/* 134 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 135 */         String[] mydata = { msr.getUserLicenseKey(), new Boolean(msr.isPermanentLicense()).toString() };
/*     */ 
/* 137 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 138 */         return mydata;
/*     */       }
/* 140 */       if ((command.equalsIgnoreCase("handleforMemory")) || (command.equalsIgnoreCase("handleforMemoryGauge")))
/*     */       {
/* 142 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 143 */         Runtime runtime = Runtime.getRuntime();
/* 144 */         String[] mydata = { new Long(runtime.totalMemory()).toString(), new Long(runtime.freeMemory()).toString(), new Long(runtime.maxMemory()).toString() };

/*     */ 
/* 147 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 148 */         return mydata;
/*     */       }
/* 150 */       if (command.equalsIgnoreCase("handleforInstalledProducts"))
/*     */       {
/* 152 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 153 */         String[] version = Version.getStringForHelpAboutDialog();
/* 154 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 155 */         return version;
/*     */       }
/*     */ 
/* 158 */       if (command.equalsIgnoreCase("handleforServerList"))
/*     */       {
/* 160 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 161 */         DBManager dbm = MXServer.getMXServer().getDBManager();
/* 162 */         Connection con = dbm.getConnection(mxSession.getUserInfo().getConnectionKey());
/* 163 */         Vector servers = getAllServerNames(con);
/* 164 */         dbm.freeConnection(mxSession.getUserInfo().getConnectionKey());
/* 165 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 166 */         return servers;
/*     */       }
/* 168 */       if (command.equalsIgnoreCase("handleforSysInfo"))
/*     */       {
/* 170 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 171 */         DBManager dbm = MXServer.getMXServer().getDBManager();
/* 172 */         Connection con = dbm.getConnection(mxSession.getUserInfo().getConnectionKey());
/* 173 */         Vector servers = getAllServerNames(con);
/* 174 */         Vector allServersData = new Vector();
/* 175 */         dbm.freeConnection(mxSession.getUserInfo().getConnectionKey());
/* 176 */         for (int i = 0; i < servers.size(); ++i)
/*     */         {
/* 178 */           ArrayList data = new ArrayList();
/* 179 */           String[] server = (String[])(String[])servers.get(i);

/*     */           try
/*     */           {
/* 183 */             MXServerRemote mxs = getRemoteServer(server);
/*     */ 
/* 185 */             Properties props = mxs.getSystemProperties();

/*     */ 
/* 188 */             String[] serverdata1 = { server[1], "Server OS", props.getProperty("os.name") };
/* 189 */             data.add(serverdata1);
/* 190 */             String[] serverdata2 = { "", "Server OS Version", props.getProperty("os.version") };
/* 191 */             data.add(serverdata2);
/* 192 */             String[] serverdata3 = { "", "Application Server Name and Version", mxs.getAppServerNameandVersion() };
/* 193 */             data.add(serverdata3);
/* 194 */             String[] serverdata4 = { "", "Database and Version", mxs.getDatabaseProductName() };
/* 195 */             data.add(serverdata4);
/* 196 */             String[] serverdata5 = { "", "Base Language", mxs.getBaseLang() };
/* 197 */             data.add(serverdata5);
/* 198 */             String[] serverdata6 = { "", "User License Key", mxs.getUserLicenseKey() };
/* 199 */             data.add(serverdata6);
/* 200 */             allServersData.add(data);
/*     */           }
/*     */           catch (RemoteException e)
/*     */           {
/* 204 */             String[] error = { "", e.getMessage(), "" };
/* 205 */             data.add(error);
/* 206 */             allServersData.add(data);
/* 207 */             logger.info("MosWosToolClientHandler: Exception " + e.getMessage());
/*     */           }
/*     */         }
/*     */ 
/* 211 */         logger.info("MosWosToolClientHandler: Ending Handle" + command);
/* 212 */         return allServersData;
/*     */       }
/* 214 */       if (command.equalsIgnoreCase("handleforUsersPerServerGauge"))
/*     */       {
/* 216 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 217 */         MboSetRemote maxsession = msr.getMboSet("MAXSESSION", mxSession.getUserInfo());
/* 218 */         String where = "active = 1";
/* 219 */         SqlFormat sqlFormat = new SqlFormat(where);
/* 220 */         where = sqlFormat.format();
/* 221 */         maxsession.setWhere(where);
/* 222 */         maxsession.reset();
/* 223 */         MboRemote mr = maxsession.getMbo(0);
/* 224 */         HashMap hm = new HashMap();
/* 225 */         int counter = 0;
/* 226 */         while (mr != null)
/*     */         {
/* 228 */           if (hm.containsKey(mr.getString("SERVERNAME")))
/*     */           {
/* 230 */             if (!(mr.getBoolean("ISSYSTEM")))
/*     */             {
/* 232 */               counter = ((Integer)hm.get(mr.getString("SERVERNAME"))).intValue();
/* 233 */               ++counter;
/* 234 */               hm.put(mr.getString("SERVERNAME"), Integer.valueOf(counter));
/*     */             }
/*     */           }
/*     */           else {
/* 238 */             hm.put(mr.getString("SERVERNAME"), Integer.valueOf(counter));
/*     */           }
/* 240 */           mr = maxsession.fetchNext();
/*     */         }
/* 242 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 243 */         return hm;
/*     */       }
/* 245 */       if (command.equalsIgnoreCase("handleforRuntimeMXBean"))
/*     */       {
/* 247 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 248 */         RuntimeMXBean mxbean = ManagementFactory.getRuntimeMXBean();
/*     */ 
/* 250 */         Vector allServersData = new Vector();
/* 251 */         Calendar cal = Calendar.getInstance();
/* 252 */         cal.setTimeInMillis(mxbean.getUptime());
/*     */ 
/* 254 */         String hr = new Integer(cal.get(10)).toString();
/* 255 */         String mn = new Integer(cal.get(12)).toString();
/* 256 */         String sc = new Integer(cal.get(13)).toString();
/*     */ 
/* 258 */         String[] mydata = { "JVM Uptime", hr + ":" + mn + ":" + sc };
/* 259 */         allServersData.add(mydata);
/* 260 */         long starttime = mxbean.getStartTime();
/* 261 */         Date resultdate = new Date(starttime);
/* 262 */         String[] mydata1 = { "JVM Start Time", resultdate.toString() };
/* 263 */         allServersData.add(mydata1);
/* 264 */         String[] mydata2 = { "JVM Name", mxbean.getVmName() };
/* 265 */         allServersData.add(mydata2);
/* 266 */         String[] mydata3 = { "JVM Vendor", mxbean.getVmVendor() };
/* 267 */         allServersData.add(mydata3);
/* 268 */         String[] mydata4 = { "JVM Version", mxbean.getVmVersion() };
/* 269 */         allServersData.add(mydata4);
/* 270 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 271 */         return allServersData;
/*     */       }
/* 273 */       if (command.equalsIgnoreCase("handleforDBConnections"))
/*     */       {
/* 275 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 276 */         DBManager dbm = MXServer.getMXServer().getDBManager();
/* 277 */         Connection con = dbm.getConnection(mxSession.getUserInfo().getConnectionKey());
/* 278 */         Vector servers = getAllServerNames(con);
/* 279 */         dbm.freeConnection(mxSession.getUserInfo().getConnectionKey());
/* 280 */         Vector allServersData = new Vector();
/*     */ 
/* 282 */         Properties configProp = MXServer.getMXServer().getConfig();
/* 283 */         String adminPwd = configProp.getProperty("mxe.adminPasswd").toLowerCase();
/* 284 */         String adminId = configProp.getProperty("mxe.adminuserid").toLowerCase();
/*     */ 
/* 286 */         for (int i = 0; i < servers.size(); ++i)
/*     */         {
/*     */           try
/*     */           {
/* 290 */             String[] server = (String[])(String[])servers.get(i);
/*     */ 
/* 292 */             MXServerRemote mxs = getRemoteServer(server);


/*     */ 
/* 296 */             String[] serverdata1 = { server[1], new Integer(mxs.getDBConnUsed()).toString() };

/*     */ 
/* 299 */             allServersData.add(serverdata1);
/*     */           }
/*     */           catch (RemoteException e)
/*     */           {
/* 303 */             String[] serverdata1 = { e.getMessage(), "" };
/*     */ 
/* 305 */             allServersData.add(serverdata1);
/* 306 */             logger.info("MosWosToolClientHandler: Exception " + e.getMessage());
/*     */           }
/*     */         }
/* 309 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 310 */         return allServersData;
/*     */       }
/* 312 */       if (command.equalsIgnoreCase("handleforMemGaugeForAllSrvrs"))
/*     */       {
/* 314 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 315 */         DBManager dbm = MXServer.getMXServer().getDBManager();
/* 316 */         Connection con = dbm.getConnection(mxSession.getUserInfo().getConnectionKey());
/* 317 */         Vector servers = getAllServerNames(con);
/* 318 */         dbm.freeConnection(mxSession.getUserInfo().getConnectionKey());
/* 319 */         Vector allServersData = new Vector();
/*     */ 
/* 321 */         Properties configProp = MXServer.getMXServer().getConfig();
/* 322 */         String adminPwd = configProp.getProperty("mxe.adminPasswd").toLowerCase();
/* 323 */         String adminId = configProp.getProperty("mxe.adminuserid").toLowerCase();
/*     */ 
/* 325 */         for (int i = 0; i < servers.size(); ++i)
/*     */         {
/*     */           try
/*     */           {
/* 329 */             String[] server = (String[])(String[])servers.get(i);
/*     */ 
/* 331 */             MXServerRemote mxs = getRemoteServer(server);

/*     */ 
/* 334 */             String[] memdata = mxs.getFreeMemory();
/* 335 */             allServersData.add(memdata);
/*     */           }
/*     */           catch (RemoteException e)
/*     */           {
/* 339 */             String[] error = { e.getMessage(), "" };
/*     */ 
/* 341 */             allServersData.add(error);
/* 342 */             logger.info("MosWosToolClientHandler: Exception " + e.getMessage());
/*     */           }
/*     */         }
/* 345 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 346 */         return allServersData;
/*     */       }
/* 348 */       if (command.equalsIgnoreCase("handleforMBOCountGauge"))
/*     */       {
/* 350 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 351 */         DBManager dbm = MXServer.getMXServer().getDBManager();
/* 352 */         Connection con = dbm.getConnection(mxSession.getUserInfo().getConnectionKey());
/* 353 */         Vector servers = getAllServerNames(con);
/* 354 */         dbm.freeConnection(mxSession.getUserInfo().getConnectionKey());
/* 355 */         Vector allServersData = new Vector();
/* 356 */         for (int i = 0; i < servers.size(); ++i)
/*     */         {
/*     */           try
/*     */           {
/* 360 */             String[] server = (String[])(String[])servers.get(i);
/*     */ 
/* 362 */             MXServerRemote mxs = getRemoteServer(server);
/*     */ 
/* 364 */             ArrayList counts = mxs.getMboCounts();
/* 365 */             allServersData.add(counts);
/*     */           }
/*     */           catch (RemoteException e)
/*     */           {
/* 369 */             logger.info("MosWosToolClientHandler: Exception " + e.getMessage());
/*     */           }
/*     */         }
/* 372 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 373 */         return allServersData;
/*     */       }
/* 375 */       if (command.equalsIgnoreCase("handleforEscalationErrorLog"))
/*     */       {
/* 377 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 378 */         MboSetRemote escstatus = msr.getMboSet("ESCSTATUS", mxSession.getUserInfo());
/* 379 */         String where = "status = 'ERROR'";
/* 380 */         SqlFormat sqlFormat = new SqlFormat(where);
/* 381 */         where = sqlFormat.format();
/* 382 */         escstatus.setWhere(where);
/* 383 */         escstatus.reset();
/* 384 */         int count = escstatus.count();
/* 385 */         ArrayList data = new ArrayList();
/* 386 */         for (int i = 0; i < count; ++i)
/*     */         {
/* 388 */           MboRemote mr = escstatus.getMbo(i);
/* 389 */           String[] mydata = { mr.getString("OBJECTNAME"), mr.getString("STATUSMEMO"), mr.getString("ESCALATION"), mr.getString("STATUSDATE") };


/*     */ 
/* 393 */           data.add(mydata);
/*     */         }
/* 395 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 396 */         return data;
/*     */       }
/* 398 */       if (command.equalsIgnoreCase("handleforMemoryBean"))
/*     */       {
/* 400 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 401 */         DBManager dbm = MXServer.getMXServer().getDBManager();
/* 402 */         Connection con = dbm.getConnection(mxSession.getUserInfo().getConnectionKey());
/* 403 */         Vector servers = getAllServerNames(con);
/* 404 */         dbm.freeConnection(mxSession.getUserInfo().getConnectionKey());
/* 405 */         Vector allServersData = new Vector();
/*     */ 
/* 407 */         Properties configProp = MXServer.getMXServer().getConfig();
/* 408 */         String adminPwd = configProp.getProperty("mxe.adminPasswd").toLowerCase();
/* 409 */         String adminId = configProp.getProperty("mxe.adminuserid").toLowerCase();
/*     */ 
/* 411 */         for (int i = 0; i < servers.size(); ++i)
/*     */         {
/*     */           try
/*     */           {
/* 415 */             String[] server = (String[])(String[])servers.get(i);
/* 416 */             MXSession session = getMXSession(server);
/* 417 */             MXServerRemote mxs = session.getMXServerRemote();
/* 418 */             SrvCommRemote scr = mxs.getServerCommandRemote(adminId, adminPwd);
/* 419 */             String[] hu = scr.getHeapUsage();
/* 420 */             HashMap serverl = new HashMap();
/* 421 */             serverl.put(mxs.getName(), hu);
/* 422 */             allServersData.add(serverl);
/* 423 */             session.disconnect();
/*     */           }
/*     */           catch (RemoteException e) {
/* 426 */             logger.info("MosWosToolClientHandler: Exception " + e.getMessage());
/*     */           }
/*     */         }
/* 429 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 430 */         return allServersData;
/*     */       }
/* 432 */       if (command.equalsIgnoreCase("handleforGarbageCollectorBean"))
/*     */       {
/* 434 */         logger.info("MosWosToolClientHandler: Current Handle is " + command);
/* 435 */         DBManager dbm = MXServer.getMXServer().getDBManager();
/* 436 */         Connection con = dbm.getConnection(mxSession.getUserInfo().getConnectionKey());
/* 437 */         Vector servers = getAllServerNames(con);
/* 438 */         dbm.freeConnection(mxSession.getUserInfo().getConnectionKey());
/* 439 */         Vector allServersData = new Vector();
/*     */ 
/* 441 */         Properties configProp = MXServer.getMXServer().getConfig();
/* 442 */         String adminPwd = configProp.getProperty("mxe.adminPasswd").toLowerCase();
/* 443 */         String adminId = configProp.getProperty("mxe.adminuserid").toLowerCase();
/*     */ 
/* 445 */         for (int i = 0; i < servers.size(); ++i)
/*     */         {
/*     */           try
/*     */           {
/* 449 */             String[] server = (String[])(String[])servers.get(i);
/* 450 */             MXSession session = getMXSession(server);
/* 451 */             MXServerRemote mxs = session.getMXServerRemote();
/* 452 */             SrvCommRemote scr = mxs.getServerCommandRemote(adminId, adminPwd);
/* 453 */             Vector gcb = scr.getGarbageCollectors();
/* 454 */             HashMap serverl = new HashMap();
/* 455 */             serverl.put(mxs.getName(), gcb);
/* 456 */             allServersData.add(serverl);
/* 457 */             session.disconnect();
/*     */           }
/*     */           catch (RemoteException e) {
/* 460 */             logger.info("MosWosToolClientHandler: Exception " + e.getMessage());
/*     */           }
/*     */         }
/* 463 */         logger.info("MosWosToolClientHandler: Ending Handle " + command);
/* 464 */         return allServersData;
/*     */       }
/*     */     }
/*     */ 
/* 468 */     throw new MXApplicationException("system", "failed", new Object[] { command });
/*     */   }


/*     */   private MXServerRemote getRemoteServer(String[] server)
/*     */   {
/*     */     try
/*     */     {
/* 476 */       Properties configProp = MXServer.getMXServer().getConfig();
/* 477 */       String registryPort = configProp.getProperty("mxe.registry.port");
/* 478 */       logger.info("MosWosToolClientHandler: RMI Registry Port is " + registryPort);
/* 479 */       String port = ((registryPort != null) && (registryPort != "")) ? ":" + registryPort : null;
/*     */ 
/* 481 */       String hostName = server[0] + port + "/" + server[1];
/* 482 */       logger.info("MosWosToolClientHandler: HostName is " + hostName);
/* 483 */       return ((MXServerRemote)Naming.lookup("//" + hostName));

/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/* 488 */       e.printStackTrace();

/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/* 493 */       e.printStackTrace();

/*     */     }
/*     */     catch (NotBoundException e)
/*     */     {
/* 498 */       e.printStackTrace();
/*     */     }
/* 500 */     return null;
/*     */   }

/*     */   private MXSession getMXSession(String[] server) throws MXException, RemoteException
/*     */   {
/* 505 */     MXSession session = MXSession.getSession();
/*     */     try
/*     */     {
/* 508 */       Properties configProp = MXServer.getMXServer().getConfig();
/* 509 */       String adminPwd = configProp.getProperty("mxe.adminPasswd").toLowerCase();
/* 510 */       String adminId = configProp.getProperty("mxe.adminuserid").toLowerCase();
/* 511 */       String registryPort = configProp.getProperty("mxe.registry.port");
/* 512 */       logger.info("MosWosToolClientHandler: RMI Registry Port is " + registryPort);
/* 513 */       String port = ((registryPort != null) && (registryPort != "")) ? ":" + registryPort : null;
/* 514 */       String hostName = server[0] + port + "/" + server[1];
/* 515 */       logger.info("MosWosToolClientHandler: HostName is " + hostName);
/* 516 */       session.setHost(hostName);
/* 517 */       session.setUserName(adminId);
/* 518 */       session.setPassword(adminPwd);
/* 519 */       session.connect();
/*     */     }
/*     */     catch (RemoteException e) {
/* 522 */       logger.info("MosWosToolClientHandler.getMXSession(): Exception " + e.getMessage());
/* 523 */       throw e;
/*     */     }
/* 525 */     return session;
/*     */   }





/*     */   public Object[] packageParam(String command, String[] args)
/*     */   {
/* 534 */     return null;
/*     */   }





/*     */   public String processReturn(String command, Object retObject)
/*     */   {
/* 543 */     return retObject.toString();
/*     */   }

/*     */   private Vector getAllServerNames(Connection con) throws MXException
/*     */   {
/* 548 */     Statement s = null;
/* 549 */     ResultSet rs = null;
/* 550 */     Vector v = new Vector();

/*     */     try
/*     */     {
/* 554 */       if (con != null)
/*     */       {
/* 556 */         s = con.createStatement();
/* 557 */         s.execute("select serverhost,servername,userid from maxsession where issystem = 1");
/* 558 */         rs = s.getResultSet();
/* 559 */         while (rs.next())
/*     */         {
/* 561 */           String[] str = new String[3];
/* 562 */           str[0] = rs.getString(1);
/* 563 */           str[1] = rs.getString(2);
/* 564 */           str[2] = rs.getString(3);
/* 565 */           v.add(str);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       try {
/* 572 */         if (con != null)
/* 573 */           con.rollback();
/*     */       } catch (Exception ex1) {
/*     */       }
/* 576 */       if (FixedLoggers.MAXIMOLOGGER.isErrorEnabled());










/*     */       String msg;
/* 588 */       throw new MXSystemException("system", "major", e);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 593 */         if (rs != null)
/* 594 */           rs.close();
/*     */       } catch (Exception ex) {
/*     */       }
/*     */       try {
/* 598 */         if (s != null)
/* 599 */           s.close();
/*     */       } catch (Exception ex) {
/*     */       }
/*     */     }
/* 603 */     return v;
/*     */   }
/*     */ }
