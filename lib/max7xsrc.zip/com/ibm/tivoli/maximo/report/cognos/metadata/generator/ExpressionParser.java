/*     */ package com.ibm.tivoli.maximo.report.cognos.metadata.generator;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.exception.CognosTransformationException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 










































/*     */ public class ExpressionParser
/*     */ {
/*     */   public static Expression parseExpression(String childName, String parentName, String relationshipName, String whereClause, String databaseType)
/*     */     throws CognosTransformationException
/*     */   {
/*  56 */     List joinPredicates = new ArrayList();
/*  57 */     generateWhereClausePredicate(whereClause.toUpperCase(), joinPredicates, childName, parentName, relationshipName);

/*     */ 
/*  60 */     Expression expression = new Expression();
/*  61 */     for (String predicate : joinPredicates) {
/*  62 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  63 */         MicUtil.INTEGRATIONLOGGER.debug("generateRelationship: predicate = " + predicate);
/*     */       }
/*  65 */       generateJoinPredicateExpression(predicate, expression, childName, parentName, relationshipName, databaseType);
/*     */     }
/*     */ 
/*  68 */     return expression;
/*     */   }


















/*     */   private static void generateWhereClausePredicate(String whereClause, List<String> joinPredicates, String objectName, String parentName, String relationshipName)
/*     */     throws CognosTransformationException
/*     */   {
/*  91 */     whereClause = whereClause.trim();
/*  92 */     checkRelationshipComplexity(whereClause, objectName, parentName, relationshipName);
/*     */ 
/*  94 */     int colonIndex = whereClause.indexOf(":");
/*  95 */     if (colonIndex != -1) {
/*  96 */       String temp = whereClause.substring(0, colonIndex);
/*  97 */       int previousAndIndex = temp.indexOf("AND");
/*  98 */       if (previousAndIndex == -1)
/*     */       {
/* 100 */         int nextAndIndex = whereClause.indexOf("AND");
/* 101 */         if (nextAndIndex == -1)
/*     */         {
/* 103 */           joinPredicates.add(whereClause);
/*     */         } else {
/* 105 */           String predicate = whereClause.substring(0, nextAndIndex);
/* 106 */           whereClause = whereClause.substring(nextAndIndex + 3, whereClause.length());
/* 107 */           joinPredicates.add(predicate);
/* 108 */           generateWhereClausePredicate(whereClause, joinPredicates, objectName, parentName, relationshipName);
/*     */         }
/*     */       }
/*     */       else {
/* 112 */         String firstPart = temp.substring(0, previousAndIndex);
/* 113 */         String secondPart = whereClause.substring(previousAndIndex + 3, whereClause.length());
/* 114 */         generateWhereClausePredicate(firstPart, joinPredicates, objectName, parentName, relationshipName);
/* 115 */         generateWhereClausePredicate(secondPart, joinPredicates, objectName, parentName, relationshipName);
/*     */       }
/*     */     } else {
/* 118 */       MicUtil.INTEGRATIONLOGGER.error("generateWhereClausePredicate: Error occured during parsing the where clause expression:  " + whereClause + ". 0nly simple expressions are supported");

/*     */ 
/* 121 */       throw new CognosTransformationException("cognos_not_supported_complex_expression", new String[] { objectName, parentName, relationshipName, whereClause });
/*     */     }
/*     */   }


















/*     */   private static void checkRelationshipComplexity(String whereClause, String objectName, String parentName, String relationshipName)
/*     */     throws CognosTransformationException
/*     */   {
/* 145 */     if ((whereClause.indexOf("SELECT ") == -1) && (whereClause.indexOf("(") == -1) && (whereClause.indexOf(")") == -1) && (whereClause.indexOf(" OR ") == -1) && (whereClause.indexOf(">") == -1) && (whereClause.indexOf("<") == -1) && (whereClause.indexOf("<=") == -1) && (whereClause.indexOf(">=") == -1) && (whereClause.indexOf("<>") == -1) && (whereClause.indexOf(" NOT ") == -1))

/*     */     {
/*     */       return;
/*     */     }
/*     */ 
/* 151 */     MicUtil.INTEGRATIONLOGGER.error("generateWhereClausePredicate: Error occured during parsing the where clause expression:  " + whereClause + ". 0nly simple expressions are supported");

/*     */ 
/* 154 */     throw new CognosTransformationException("cognos_not_supported_complex_expression", new String[] { objectName, parentName, relationshipName, whereClause });
/*     */   }





























/*     */   private static void generateJoinPredicateExpression(String predicate, Expression expression, String childName, String parentName, String relationshipName, String databaseType)
/*     */     throws CognosTransformationException
/*     */   {
/* 188 */     int equalIndex = predicate.indexOf("=");
/* 189 */     if (equalIndex != -1)
/*     */     {
/* 191 */       String leftColumn = null;
/* 192 */       String rightColumn = null;
/* 193 */       String firstPart = predicate.substring(0, equalIndex).trim();
/* 194 */       String secondPart = predicate.substring(equalIndex + 1, predicate.length()).trim();
/* 195 */       int colonIndex = firstPart.indexOf(":");
/* 196 */       if (colonIndex != -1)
/*     */       {
/* 198 */         leftColumn = firstPart.substring(1, firstPart.length()).trim();
/* 199 */         rightColumn = secondPart.trim();
/*     */       }
/*     */       else
/*     */       {
/* 203 */         leftColumn = secondPart.substring(1, secondPart.length()).trim();
/* 204 */         rightColumn = firstPart.trim();
/*     */       }
/* 206 */       if ("SS".equals(databaseType)) {
/* 207 */         leftColumn = leftColumn.toLowerCase();
/* 208 */         rightColumn = rightColumn.toLowerCase();
/*     */       }
/* 210 */       expression.addLeftColumn(leftColumn);
/* 211 */       expression.addRightColumn(rightColumn);
/* 212 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 213 */         MicUtil.INTEGRATIONLOGGER.debug("generateJoinPredicateExpression: leftColumn: " + leftColumn + ", rightColumn: " + rightColumn);
/*     */     }
/*     */     else
/*     */     {
/* 217 */       MicUtil.INTEGRATIONLOGGER.error("generateWhereClausePredicate: Error occured during parsing the where clause expression:  " + predicate + ". 0nly simple expressions are supported");

/*     */ 
/* 220 */       throw new CognosTransformationException("cognos_not_supported_complex_expression", new String[] { childName, parentName, relationshipName, predicate });
/*     */     }
/*     */   }
/*     */ }
