/*     */ package com.ibm.tivoli.maximo.report.cognos.metadata.adapter;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.exception.CognosTransformationException;
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.generator.ActionLogBuilder;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.iface.migexits.ExternalExit;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 




















































/*     */ public class CognosExternalExit extends ExternalExit
/*     */ {
/*     */   private static final String PROP_DB_NAME = "mxe.report.cognos.db.sql.name";
/*     */   private static final String PROP_DB_SCHEMA = "mxe.report.cognos.db.schemaName";
/*     */   private static final String PROP_DB_TYPE = "mxe.report.cognos.db.type";
/*     */   private static final String PROP_DATA_SOURCE_NAME = "mxe.report.cognos.datasource";
/*     */   private static final String PROP_CONTENT_STORE_PACKAGE_LOCATION = "mxe.report.cognos.content.store.package.location";
/*     */   private static final String UTF8 = "UTF-8";
/*     */ 
/*     */   public StructureData setDataOut(StructureData userExitData)
/*     */     throws MXException, RemoteException
/*     */   {
/*  77 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  78 */       MicUtil.INTEGRATIONLOGGER.debug("START---mapping maximo structure to cognos stucture\n");
/*  79 */       MicUtil.INTEGRATIONLOGGER.debug("Property 'mxe.report.cognos.db.schemaName' value =" + getDatabaseSchema());
/*     */ 
/*  81 */       MicUtil.INTEGRATIONLOGGER.debug("Property 'mxe.report.cognos.db.type' value =" + getDatabaseType());
/*     */ 
/*  83 */       MicUtil.INTEGRATIONLOGGER.debug("Property 'mxe.report.cognos.db.sql.name' value =" + getDatabaseName());


/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  90 */       String objStructure = new String(userExitData.getDataAsBytes(), "UTF-8");
/*  91 */       String cognosActionLogsStr = ActionLogBuilder.build(objStructure, getDatabaseType(), getDatabaseSchema(), getDatabaseName(), getDataSourceName(), getContentStorePackageLocation());
/*     */ 
/*  93 */       MicUtil.INTEGRATIONLOGGER.info("\nTransformation of Maximo Object Structure to Cognos Action Logs was done successfully");



/*     */ 
/*  98 */       StructureData localStructureData = new StructureData(cognosActionLogsStr.getBytes("UTF-8"));









/*     */     }
/*     */     catch (CognosTransformationException exCT)
/*     */     {
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*     */ /* 117 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 118 */       return localStructureData;/* 118 */         MicUtil.INTEGRATIONLOGGER.debug("END---mapping maximo structure to cognos structure");
/*     */     }
/*     */   }





/*     */   private String getDatabaseType()
/*     */     throws RemoteException
/*     */   {
/* 129 */     return MXServer.getMXServer().getProperty("mxe.report.cognos.db.type");
/*     */   }




/*     */   private String getDatabaseName()
/*     */     throws RemoteException
/*     */   {
/* 138 */     return MXServer.getMXServer().getProperty("mxe.report.cognos.db.sql.name");
/*     */   }




/*     */   private String getDatabaseSchema()
/*     */     throws RemoteException
/*     */   {
/* 147 */     return MXServer.getMXServer().getProperty("mxe.report.cognos.db.schemaName");
/*     */   }




/*     */   private String getDataSourceName()
/*     */     throws RemoteException
/*     */   {
/* 156 */     return MXServer.getMXServer().getProperty("mxe.report.cognos.datasource");
/*     */   }




/*     */   private String getContentStorePackageLocation()
/*     */     throws RemoteException
/*     */   {
/* 165 */     return MXServer.getMXServer().getProperty("mxe.report.cognos.content.store.package.location");
/*     */   }
/*     */ }
