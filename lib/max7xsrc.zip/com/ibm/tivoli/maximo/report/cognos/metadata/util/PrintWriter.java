/*    */ package com.ibm.tivoli.maximo.report.cognos.metadata.util;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ import java.io.Writer;
/*    */ 



















/*    */ public class PrintWriter extends java.io.PrintWriter
/*    */ {
/* 27 */   private int fIndent = 0;
/* 28 */   private int fIndentPending = 0;
/* 29 */   private boolean fNewLine = false;
/*    */ 
/*    */   public PrintWriter(OutputStream out) {
/* 32 */     super(out, true);
/*    */   }

/*    */   public PrintWriter(Writer out) {
/* 36 */     super(out, true);
/*    */   }

/*    */   public void indent(int steps) {
/* 40 */     this.fIndent += steps;
/* 41 */     this.fIndentPending += 1;
/* 42 */     this.fNewLine = true;
/*    */   }

/*    */   public void unIndent(int steps) {
/* 46 */     this.fIndent -= steps;
/* 47 */     if (this.fIndent < 0) this.fIndent = 0;
/* 48 */     this.fIndentPending -= 1;
/*    */   }

/*    */   public void println() {
/* 52 */     super.println();
/* 53 */     this.fNewLine = true;
/*    */   }

/*    */   public void write(char[] buf, int off, int len) {
/* 57 */     printIndent();
/* 58 */     super.write(buf, off, len);
/*    */   }

/*    */   public void write(int c) {
/* 62 */     printIndent();
/* 63 */     super.write(c);
/*    */   }

/*    */   public void write(String s, int off, int len) {
/* 67 */     printIndent();
/* 68 */     super.write(s, off, len);
/*    */   }

/*    */   private void printIndent() {
/* 72 */     if ((this.fNewLine) && (this.fIndentPending > 0)) {
/* 73 */       for (int i = 0; i < this.fIndent; ++i) {
/* 74 */         super.write(32);
/*    */       }
/* 76 */       this.fNewLine = false;
/*    */     }
/*    */   }
/*    */ }
