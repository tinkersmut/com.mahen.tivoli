/*      */ package com.ibm.tivoli.maximo.report.cognos.metadata.generator;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.report.cognos.metadata.exception.CognosTransformationException;
/*      */ import com.ibm.tivoli.maximo.report.cognos.metadata.util.ActionLogUtil;
/*      */ import com.ibm.tivoli.maximo.report.cognos.metadata.util.PrintWriter;
/*      */ import com.ibm.tivoli.maximo.report.cognos.metadata.util.XMLElement;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import javax.xml.xpath.XPathException;
/*      */ import org.jdom.Element;
/*      */ import org.jdom.output.XMLOutputter;
/*      */ import psdi.iface.mic.MicUtil;
/*      */ import psdi.util.logging.MXLogger;
/*      */ 









































































/*      */ public class ActionLogBuilder
/*      */ {
/*      */   private static final String DATA_SOURCE_VIEW_NAMESPACE = "Data Source View";
/*      */   private static final String BUSINESS_LOGIC_VIEW_NAMESPACE = "Business Logic View";
/*      */   private static final String MODEL_SUFFIX = " Model";
/*      */   private static final String PACKAGE_NAME_SUFFIX = "Package";
/*      */   private static final String PERSISTENT_COLUMN = "1";
/*      */   private static final String NOT_PERSISTENT_COLUMN = "0";
/*      */   private static final String EXCLUDED_COLUMN = "EXCLUDE";
/*      */   private static final String IS_VIEW = "1";
/*      */   private static final String IS_TABLE = "0";
/*   77 */   private static XMLOutputter outputter = new XMLOutputter();
/*      */ 
/*      */   public static String build(String inputModel, String databaseType, String databaseSchema, String databaseName, String dataSourceName, String contentStorePackageLocation)
/*      */     throws CognosTransformationException
/*      */   {
/*  111 */     StringWriter output = new StringWriter();
/*  112 */     build(new StringReader(inputModel), output, databaseType, databaseSchema, databaseName, dataSourceName, contentStorePackageLocation);

/*      */ 
/*  115 */     return output.toString();
/*      */   }






























/*      */   public static void build(Reader in, Writer writer, String databaseType, String databaseSchema, String databaseName, String dataSourceName, String contentStorePackageLocation)
/*      */     throws CognosTransformationException
/*      */   {
/*  150 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  151 */       MicUtil.INTEGRATIONLOGGER.debug("Started Maximo xml transformation to Cognos Action Log xml...");
/*      */     }
/*  153 */     XMLElement inputModel = parseXMLInput(in);
/*  154 */     XMLElement intObject = parseIntegrationObject(inputModel);
/*  155 */     String projectName = parseProjectName(intObject);
/*  156 */     String modelName = projectName + " Model";
/*  157 */     String packageName = parsePackageName(intObject);
/*      */ 
/*  159 */     String baseLanguage = "";
/*      */     try
/*      */     {
/*  162 */       baseLanguage = MicUtil.getMaxVar("BASELANGUAGE").toLowerCase();
/*      */     }
/*      */     catch (Exception e) {
/*  165 */       MicUtil.INTEGRATIONLOGGER.error("generatePackageLocales: Unable to determine base language.");
/*  166 */       throw new CognosTransformationException("cognos_transform_failed", e);



/*      */     }
/*      */ 
/*  172 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  173 */       MicUtil.INTEGRATIONLOGGER.debug("Get project languages...");
/*      */     }
/*  175 */     List languages = getLanguages(intObject, "L_MAXINTOBJECT", "DESCRIPTION");
/*      */ 
/*  177 */     PrintWriter out = new PrintWriter(writer);
/*  178 */     ActionLogGen generator = new ActionLogGen(out);
/*      */ 
/*  180 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  181 */       MicUtil.INTEGRATIONLOGGER.debug("Start script generation...");
/*      */     }
/*  183 */     generator.generateScriptHeader();
/*      */ 
/*  185 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  186 */       MicUtil.INTEGRATIONLOGGER.debug("Generate the project and views...");
/*      */     }
/*      */ 
/*  189 */     generator.generateTransactionHeader();
/*      */ 
/*  191 */     generateProject(generator, projectName, modelName, baseLanguage, languages);
/*  192 */     generator.generateTransactionTail();
/*      */ 
/*  194 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  195 */       MicUtil.INTEGRATIONLOGGER.debug("Generate the data source view...");
/*      */     }
/*      */ 
/*  198 */     generator.generateTransactionHeader();
/*  199 */     generateDataSourceView(generator, intObject, databaseType, databaseSchema, databaseName, dataSourceName);
/*  200 */     generator.generateTransactionTail();
/*      */ 
/*  202 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  203 */       MicUtil.INTEGRATIONLOGGER.debug("Generate the relationships...");
/*      */     }
/*      */ 
/*  206 */     generator.generateTransactionHeader();
/*  207 */     generateRelationships(generator, intObject, projectName, modelName, databaseType);
/*  208 */     generator.generateTransactionTail();
/*      */ 
/*  210 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  211 */       MicUtil.INTEGRATIONLOGGER.debug("Generate the buisness logic view...");
/*      */     }
/*      */ 
/*  214 */     generateBusinessLogicView(generator, intObject, databaseType, baseLanguage, languages);
/*      */ 
/*  216 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  217 */       MicUtil.INTEGRATIONLOGGER.debug("Generate the package creation and publishing...");
/*      */     }
/*  219 */     generator.generateTransactionHeader();
/*      */ 
/*  221 */     generateCreateAndPublishPackage(generator, intObject, packageName, modelName, contentStorePackageLocation, baseLanguage, languages);
/*      */ 
/*  223 */     generator.generateTransactionTail();
/*      */ 
/*  225 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  226 */       MicUtil.INTEGRATIONLOGGER.debug("End script generation...");
/*      */     }
/*  228 */     generator.generateScriptTail();
/*      */   }









/*      */   private static XMLElement parseXMLInput(Reader in)
/*      */     throws CognosTransformationException
/*      */   {
/*  242 */     XMLElement model = null;
/*      */     try {
/*  244 */       model = XMLElement.parse(in);
/*      */     } catch (Exception e) {
/*  246 */       MicUtil.INTEGRATIONLOGGER.error("Error occured during parsing the maximo input xml...", e);
/*  247 */       throw new CognosTransformationException("cognos_transform_failed", e);
/*      */     }
/*  249 */     return model;
/*      */   }








/*      */   private static XMLElement parseIntegrationObject(XMLElement inputModel)
/*      */     throws CognosTransformationException
/*      */   {
/*  262 */     XMLElement intObject = null;
/*      */     try {
/*  264 */       intObject = inputModel.findElement("//MAXINTOBJECT");
/*  265 */       if (intObject == null) {
/*  266 */         MicUtil.INTEGRATIONLOGGER.error("parseIntegrationObject: Maximo integration object not found...");
/*  267 */         throw new CognosTransformationException("cognos_transform_failed");
/*      */       }
/*      */     } catch (XPathException e) {
/*  270 */       MicUtil.INTEGRATIONLOGGER.error("Error occured during parsing the maximo integration object...", e);
/*  271 */       throw new CognosTransformationException("cognos_transform_failed", e);
/*      */     }
/*  273 */     return intObject;
/*      */   }








/*      */   private static String parseProjectName(XMLElement intObject)
/*      */     throws CognosTransformationException
/*      */   {
/*  286 */     String projectName = intObject.getChildValue("INTOBJECTNAME");
/*  287 */     if (projectName == null) {
/*  288 */       MicUtil.INTEGRATIONLOGGER.error("generateProject: Error occured during parsing the project name from the attribute INTOBJECTNAME of the //MAXINTOBJECT element...");

/*      */ 
/*  291 */       throw new CognosTransformationException("cognos_transform_failed");
/*      */     }
/*  293 */     return projectName;
/*      */   }








/*      */   private static String parsePackageName(XMLElement intObject)
/*      */     throws CognosTransformationException
/*      */   {
/*  306 */     String packageName = intObject.getChildValue("DESCRIPTION");
/*  307 */     if ((packageName == null) || ("".equals(packageName))) {
/*  308 */       packageName = intObject.getChildValue("INTOBJECTNAME");
/*  309 */       if ((packageName == null) || ("".equals(packageName))) {
/*  310 */         MicUtil.INTEGRATIONLOGGER.error("generateProject: Error occured during parsing the package name from the attributes DESCRIPTION and INTOBJECTNAME of the //MAXINTOBJECT element...");

/*      */ 
/*  313 */         throw new CognosTransformationException("cognos_transform_failed");
/*      */       }
/*      */     }
/*  316 */     return makeSafe(packageName);
/*      */   }























/*      */   private static void generateProject(ActionLogGen generator, String projectName, String modelName, String baseLanguage, List<String> languages)
/*      */     throws CognosTransformationException
/*      */   {
/*  344 */     generator.generateProjectInitialization(projectName, modelName, baseLanguage);
/*      */ 
/*  346 */     generator.generateCreateNamespace("Data Source View", modelName);
/*  347 */     generator.generateCreateNamespace("Business Logic View", modelName);
/*      */ 
/*  349 */     for (int i = 0; i < languages.size(); ++i)
/*      */     {
/*  351 */       generator.generateAddProjectLocale((String)languages.get(i), baseLanguage);



/*      */ 
/*  356 */       generator.generateNamespaceTranslation("Business Logic View", "Business Logic View", i + 1);
/*      */     }
/*      */   }






























/*      */   private static void generateDataSourceView(ActionLogGen generator, XMLElement intObject, String databaseType, String databaseSchema, String databaseName, String dataSourceName)
/*      */     throws CognosTransformationException
/*      */   {
/*  392 */     Set tables = new HashSet();
/*  393 */     Set views = new HashSet();
/*      */ 
/*  395 */     for (XMLElement objDetail : intObject.getChildren("MAXINTOBJDETAIL")) {
/*  396 */       String name = objDetail.getChildValue("OBJECTNAME");
/*  397 */       if ("SS".equals(databaseType)) {
/*  398 */         name = name.toLowerCase();
/*      */       }
/*  400 */       XMLElement maxObject = objDetail.getChild("MAXOBJECT");
/*  401 */       if (maxObject == null) {
/*  402 */         MicUtil.INTEGRATIONLOGGER.error("generateDataSourceView: the object " + name + " has no MAXOBJECT element ...");
/*  403 */         throw new CognosTransformationException("cognos_transform_failed");
/*      */       }
/*      */ 
/*  406 */       String isView = maxObject.getChildValue("ISVIEW");
/*  407 */       if ("1".equals(isView)) {
/*  408 */         views.add(name);
/*  409 */         if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/*  410 */           MicUtil.INTEGRATIONLOGGER.debug("generateDataSourceView: " + name + " is a view...");
/*      */       }
/*  412 */       else if ("0".equals(isView)) {
/*  413 */         tables.add(name);
/*      */       } else {
/*  415 */         MicUtil.INTEGRATIONLOGGER.error("generateDataSourceView: the object " + name + " is not identified if it is a view or a table ...");

/*      */ 
/*  418 */         throw new CognosTransformationException("cognos_transform_failed");
/*      */       }
/*      */     }
/*  421 */     if ((tables.size() == 0) && (views.size() == 0)) {
/*  422 */       MicUtil.INTEGRATIONLOGGER.error("generateDataSourceView: Error occured during parsing the tables and views names from the //MAXINTOBJECT/MAXINTOBJDETAIL element. No tables or views found ...");


/*      */ 
/*  426 */       throw new CognosTransformationException("cognos_transform_failed");
/*      */     }
/*  428 */     if ((dataSourceName == null) || ("".equals(dataSourceName))) {
/*  429 */       dataSourceName = "##COGNOS_DATA_SOURCE_NAME##";
/*  430 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  431 */         MicUtil.INTEGRATIONLOGGER.debug("generateDataSourceView:  dataSourceName  is not provided...");
/*      */       }
/*      */     }
/*  434 */     generator.generateDBImport("Data Source View", databaseType, dataSourceName, databaseSchema, tables, views, databaseName);

/*      */ 
/*  437 */     generator.generateSetQueryProcessingToLocal(dataSourceName);
/*      */   }
























/*      */   private static void generateRelationships(ActionLogGen generator, XMLElement intObject, String projectName, String modelName, String databaseType)
/*      */     throws CognosTransformationException
/*      */   {
/*  466 */     Set objects = new HashSet();
/*  467 */     int relationCount = 0;
/*  468 */     for (XMLElement objDetail : intObject.getChildren("MAXINTOBJDETAIL")) {
/*  469 */       String objectName = objDetail.getChildValue("OBJECTNAME");
/*  470 */       if ("SS".equals(databaseType)) {
/*  471 */         objectName = objectName.toLowerCase();
/*      */       }
/*  473 */       if (!(objects.contains(objectName))) {
/*  474 */         objects.add(objectName);
/*  475 */         relationCount = generateObjectRelationships(generator, modelName, objDetail, objectName, relationCount, databaseType);
/*      */       }
/*      */     }
/*      */ 
/*  479 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/*  480 */       MicUtil.INTEGRATIONLOGGER.debug("generateRelationships: relationships count = " + relationCount + " ...");
/*      */   }




























/*      */   private static int generateObjectRelationships(ActionLogGen generator, String modelName, XMLElement objDetail, String objectName, int relationCount, String databaseType)
/*      */     throws CognosTransformationException
/*      */   {
/*  513 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  514 */       MicUtil.INTEGRATIONLOGGER.debug("######################################################################");
/*  515 */       MicUtil.INTEGRATIONLOGGER.debug("generateObjectRelationships: object name = " + objectName);
/*      */     }
/*  517 */     for (XMLElement objRelationship : objDetail.getChildren("MAXRELATIONSHIP")) {
/*  518 */       String parentName = objRelationship.getChildValue("PARENT");
/*  519 */       String relationshipName = objRelationship.getChildValue("NAME").toLowerCase();
/*  520 */       if ("SS".equals(databaseType)) {
/*  521 */         parentName = parentName.toLowerCase();
/*  522 */         relationshipName = relationshipName.toUpperCase();
/*      */       }
/*      */ 
/*  525 */       String whereClause = objRelationship.getChildValue("WHERECLAUSE");
/*  526 */       ++relationCount;
/*  527 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  528 */         MicUtil.INTEGRATIONLOGGER.debug("######################################################################");
/*  529 */         MicUtil.INTEGRATIONLOGGER.debug("Relation #" + relationCount);
/*  530 */         MicUtil.INTEGRATIONLOGGER.debug("parentName = " + parentName);
/*  531 */         MicUtil.INTEGRATIONLOGGER.debug("relationshipName = " + relationshipName);
/*  532 */         MicUtil.INTEGRATIONLOGGER.debug("whereClause = " + whereClause);
/*      */       }
/*      */ 
/*  535 */       generateRelationship(generator, modelName, objectName, parentName, relationshipName, whereClause, objRelationship, databaseType);
/*      */     }
/*      */ 
/*  538 */     return relationCount;
/*      */   }





























/*      */   private static void generateRelationship(ActionLogGen generator, String modelName, String childName, String parentName, String relationshipName, String whereClause, XMLElement objRelationship, String databaseType)
/*      */     throws CognosTransformationException
/*      */   {
/*  572 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  573 */       MicUtil.INTEGRATIONLOGGER.debug("generateRelationship: adjust relationship cardinality ...");
/*      */     }
/*  575 */     String rightMaxCardinality = getRightMaxCardinality(relationshipName, objRelationship);
/*  576 */     String rightMinCardinality = getRightMinCardinality(relationshipName, objRelationship);
/*      */ 
/*  578 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  579 */       MicUtil.INTEGRATIONLOGGER.debug("generateRelationship: parse columns ...");
/*      */     }
/*  581 */     Expression expression = ExpressionParser.parseExpression(childName, parentName, relationshipName, whereClause, databaseType);

/*      */ 
/*  584 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  585 */       MicUtil.INTEGRATIONLOGGER.debug("generateRelationship: generate relationship ...");
/*      */     }
/*      */ 
/*  588 */     relationshipName = makeSafe(relationshipName);
/*  589 */     generator.generateRelationship(modelName, "Data Source View", parentName, "one", "one", childName, rightMinCardinality, rightMaxCardinality, relationshipName, expression.getLeftColumns(), expression.getRightColumns());
/*      */   }













/*      */   private static String getRightMinCardinality(String relationshipName, XMLElement objRelationship)
/*      */     throws CognosTransformationException
/*      */   {
/*  607 */     String rightMinCardinality = null;
/*  608 */     String dbJoinRequired = objRelationship.getChildValue("DBJOINREQUIRED");
/*  609 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  610 */       MicUtil.INTEGRATIONLOGGER.debug("getRightMinCardinality: dbJoinRequired = " + dbJoinRequired);
/*      */     }
/*  612 */     if ("0".equals(dbJoinRequired)) {
/*  613 */       rightMinCardinality = "zero";
/*  614 */     } else if ("1".equals(dbJoinRequired)) {
/*  615 */       rightMinCardinality = "one";
/*      */     } else {
/*  617 */       rightMinCardinality = "zero";
/*  618 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  619 */         MicUtil.INTEGRATIONLOGGER.debug("getRightMinCardinality: DBJOINREQUIRED doesn't have the value \"0\" or \"1\". relationship name:  " + relationshipName + ", dbJoinRequired: " + dbJoinRequired);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  624 */     return rightMinCardinality;
/*      */   }












/*      */   private static String getRightMaxCardinality(String relationshipName, XMLElement objRelationship)
/*      */     throws CognosTransformationException
/*      */   {
/*  641 */     String rightMaxCardinality = null;
/*  642 */     String relationshipCardinality = objRelationship.getChildValue("CARDINALITY");
/*  643 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  644 */       MicUtil.INTEGRATIONLOGGER.debug("getRightMaxCardinality: relationshipCardinality = " + relationshipCardinality);
/*      */     }
/*  646 */     if ("SINGLE".equals(relationshipCardinality)) {
/*  647 */       rightMaxCardinality = "one";
/*  648 */     } else if (("UNDEFINED".equals(relationshipCardinality)) || ("MULTIPLE".equals(relationshipCardinality)))

/*      */     {
/*  651 */       rightMaxCardinality = "many";
/*      */     } else {
/*  653 */       rightMaxCardinality = "many";
/*  654 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  655 */         MicUtil.INTEGRATIONLOGGER.debug("getRightMaxCardinality: CARDINALITY doesn't have the value  SINGLE, MULTIPLE or UNDEFINED. relationship name:  " + relationshipName + ", cardinality: " + relationshipCardinality);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  660 */     return rightMaxCardinality;
/*      */   }






























/*      */   private static void generateBusinessLogicView(ActionLogGen generator, XMLElement intObject, String databaseType, String baseLanguage, List<String> languages)
/*      */     throws CognosTransformationException
/*      */   {
/*  695 */     Set objects = new HashSet();
/*  696 */     for (XMLElement objDetail : intObject.getChildren("MAXINTOBJDETAIL")) {
/*  697 */       String objectName = objDetail.getChildValue("OBJECTNAME");
/*  698 */       if ("SS".equals(databaseType)) {
/*  699 */         objectName = objectName.toLowerCase();
/*      */       }
/*  701 */       if (!(objects.contains(objectName))) {
/*  702 */         objects.add(objectName);
/*  703 */         generator.generateTransactionHeader();
/*  704 */         generateBusinessObject(generator, objDetail, objectName, databaseType, baseLanguage, languages);
/*      */ 
/*  706 */         generator.generateTransactionTail();
/*      */       }
/*      */     }
/*      */   }

























/*      */   private static void generateBusinessObject(ActionLogGen generator, XMLElement objDetail, String objectName, String databaseType, String baseLanguage, List<String> languages)
/*      */     throws CognosTransformationException
/*      */   {
/*  738 */     String businessObjectName = objectName.substring(0, 1) + objectName.substring(1).toLowerCase();
/*  739 */     if ("SS".equals(databaseType)) {
/*  740 */       businessObjectName = objectName.substring(0, 1).toUpperCase() + objectName.substring(1);
/*      */     }
/*  742 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  743 */       MicUtil.INTEGRATIONLOGGER.debug("generateBusinessObject: model query subject " + businessObjectName + "...");
/*      */     }
/*      */ 
/*  746 */     generator.generateModelQuerySubject("Business Logic View", businessObjectName, baseLanguage);
/*  747 */     for (int i = 0; i < languages.size(); ++i)


/*      */     {
/*  751 */       generator.generateModelQuerySubjectTranslations("Business Logic View", businessObjectName, businessObjectName, i + 1);
/*      */     }
/*      */ 
/*  754 */     generateAtributes(generator, objDetail, objectName, businessObjectName, databaseType, baseLanguage, languages);
/*      */ 
/*  756 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  757 */       MicUtil.INTEGRATIONLOGGER.debug("generateBusinessObject: generate re-order by name " + objectName + "...");
/*      */     }
/*  759 */     generator.generateReorderByNameQuerySubject("Data Source View", objectName);
/*  760 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  761 */       MicUtil.INTEGRATIONLOGGER.debug("generateBusinessObject: generate re-order by name " + businessObjectName + "...");
/*      */     }
/*  763 */     generator.generateReorderByNameQuerySubject("Business Logic View", businessObjectName);
/*  764 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  765 */       MicUtil.INTEGRATIONLOGGER.debug("generateBusinessObject: generate evaluate object " + businessObjectName + "...");
/*      */     }
/*  767 */     generator.generateEvaluateQuerySubject("Business Logic View", businessObjectName);
/*      */   }


























/*      */   private static void generateAtributes(ActionLogGen generator, XMLElement objDetail, String objectName, String businessObjectName, String databaseType, String baseLanguage, List<String> languages)
/*      */     throws CognosTransformationException
/*      */   {
/*  798 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  799 */       MicUtil.INTEGRATIONLOGGER.debug("generateAtributes: generate attributes for object: " + businessObjectName + " ...");
/*      */     }
/*      */ 
/*  802 */     Set columns = getExcludedColumns(objDetail);
/*      */ 
/*  804 */     for (XMLElement objAttribute : objDetail.getChildren("MAXATTRIBUTE")) {
/*  805 */       String attributeName = objAttribute.getChildValue("ATTRIBUTENAME");
/*  806 */       String dataSourceAttributeName = attributeName;
/*  807 */       if ("SS".equals(databaseType)) {
/*  808 */         dataSourceAttributeName = attributeName.toLowerCase();
/*      */       }
/*  810 */       String persitent = objAttribute.getChildValue("PERSISTENT");
/*  811 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  812 */         MicUtil.INTEGRATIONLOGGER.debug("generateAtributes: attribute name: " + attributeName + "...");
/*      */       }
/*  814 */       if ("1".equals(persitent)) {
/*  815 */         String description = objAttribute.getChildValue("TITLE");
/*  816 */         if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  817 */           MicUtil.INTEGRATIONLOGGER.debug("generateAtributes: attribute description: " + description + "...");
/*      */         }
/*      */ 
/*  820 */         description = makeSafe(description);
/*  821 */         generator.generateModelQueryItem("Business Logic View", businessObjectName, attributeName, "Data Source View", objectName, description, dataSourceAttributeName, baseLanguage);

/*      */ 
/*  824 */         List attributeTranslations = getTranslations(objAttribute, "L_MAXATTRIBUTE", "TITLE", languages, description);
/*      */ 
/*  826 */         for (int i = 0; i < attributeTranslations.size(); ++i)


/*      */         {
/*  830 */           generator.generateModelQueryItemNameTranslation("Business Logic View", businessObjectName, attributeName, attributeName, i + 1);

/*      */ 
/*  833 */           generator.generateModelQueryItemDescTranslation("Business Logic View", businessObjectName, attributeName, ((Translation)attributeTranslations.get(i)).getValue(), i + 1);

/*      */         }
/*      */ 
/*  837 */         if (columns.contains(attributeName)) {
/*  838 */           if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  839 */             MicUtil.INTEGRATIONLOGGER.debug("generateAtributes: hide attribute: " + attributeName + "...");
/*      */           }
/*  841 */           generator.generateHideQueryItem("Business Logic View", businessObjectName, attributeName);
/*      */         }
/*  843 */       } else if ("0".equals(persitent)) {
/*  844 */         if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/*  845 */           MicUtil.INTEGRATIONLOGGER.debug("generateAtributes: attribute " + attributeName + " is non-persistent attribute. Ignore attribute in model generation ...");
/*      */       }
/*      */       else
/*      */       {
/*  849 */         MicUtil.INTEGRATIONLOGGER.error("generateAtributes: Error occured during parsing the attribute PERSISTENT value. attribute name:  " + attributeName + ", PERSISTENT: " + persitent);


/*      */ 
/*  853 */         throw new CognosTransformationException("cognos_transform_failed");
/*      */       }
/*      */     }
/*      */   }







/*      */   private static Set<String> getExcludedColumns(XMLElement objDetail)
/*      */   {
/*  866 */     Set columns = new HashSet();
/*  867 */     for (XMLElement objColumn : objDetail.getChildren("MAXINTOBJCOLS")) {
/*  868 */       String columnType = objColumn.getChildValue("INTOBJFLDTYPE");
/*  869 */       if ("EXCLUDE".equals(columnType)) {
/*  870 */         String columnName = objColumn.getChildValue("NAME");
/*  871 */         columns.add(columnName);
/*  872 */         if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  873 */           MicUtil.INTEGRATIONLOGGER.debug("getExcludedColumns: column " + columnName + " is excluded...");
/*      */         }
/*      */       }
/*      */     }
/*  877 */     return columns;
/*      */   }
















/*      */   private static void generateCreateAndPublishPackage(ActionLogGen generator, XMLElement intObject, String packageName, String modelName, String contentStorePackageLocation, String baseLanguage, List<String> languages)
/*      */   {
/*  897 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  898 */       MicUtil.INTEGRATIONLOGGER.debug("generateCreateAndPublishPackage: generate allow cross product join ...");
/*      */     }
/*  900 */     generator.generateAllowCrossProductJoin();
/*  901 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  902 */       MicUtil.INTEGRATIONLOGGER.debug("generateCreateAndPublishPackage: generate create pacakge" + packageName + " ...");

/*      */     }
/*      */ 
/*  906 */     generator.generateCreatePackage(packageName, "Data Source View", modelName, baseLanguage, languages);
/*  907 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  908 */       MicUtil.INTEGRATIONLOGGER.debug("generateCreateAndPublishPackage: generate publish pacakge" + packageName + " ...");
/*      */     }
/*      */ 
/*  911 */     List packageNameTranslations = getTranslations(intObject, "L_MAXINTOBJECT", "DESCRIPTION", languages, packageName);
/*      */ 
/*  913 */     for (int i = 0; i < packageNameTranslations.size(); ++i)
/*      */     {
/*  915 */       generator.generatePackageNameTranslations(packageName, ((Translation)packageNameTranslations.get(i)).getValue(), i + 1);
/*      */     }
/*      */ 
/*  918 */     String cognosContentStorePackageLocation = ActionLogUtil.getContentStorePackageLocation(contentStorePackageLocation);
/*      */ 
/*  920 */     generator.generatePublishPackage(packageName, cognosContentStorePackageLocation);
/*      */   }





















/*      */   private static List<Translation> getTranslations(XMLElement parent, String child, String childValue, List<String> languages, String defaultValue)
/*      */   {
/*  945 */     Translation[] translations = new Translation[languages.size()];
/*      */ 
/*  947 */     for (XMLElement translation : parent.getChildren(child)) {
/*  948 */       for (int i = 0; i < translations.length; ++i)
/*      */       {
/*  950 */         String language = translation.getChildValue("LANGCODE");
/*  951 */         if (!(language.equalsIgnoreCase((String)languages.get(i))))
/*      */           continue;
/*  953 */         String value = makeSafe(translation.getChildValue(childValue));
/*  954 */         translations[i] = new Translation(language, value);

/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  960 */     for (int i = 0; i < translations.length; ++i)
/*      */     {
/*  962 */       String value = translations[i].getValue();
/*  963 */       if (value != null)
/*      */         continue;
/*  965 */       translations[i].setValue(makeSafe(defaultValue));

/*      */     }
/*      */ 
/*  969 */     return Arrays.asList(translations);
/*      */   }














/*      */   private static List<String> getLanguages(XMLElement parent, String child, String childValue)
/*      */   {
/*  987 */     List languages = new ArrayList();
/*  988 */     for (XMLElement translation : parent.getChildren(child))
/*      */     {
/*  990 */       String value = translation.getChildValue(childValue);
/*  991 */       if ((value != null) && (!(value.equals(""))))
/*      */       {
/*  993 */         languages.add(translation.getChildValue("LANGCODE").toLowerCase());
/*      */       }
/*      */     }
/*      */ 
/*  997 */     return languages;
/*      */   }







/*      */   private static String makeSafe(String value)
/*      */   {
/* 1008 */     StringWriter writer = new StringWriter();
/*      */     try
/*      */     {
/* 1011 */       Element element = new Element("temp");
/* 1012 */       element.setText(value);
/* 1013 */       outputter.outputElementContent(element, writer);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1017 */       return value;
/*      */     }
/*      */ 
/* 1020 */     return writer.toString();
/*      */   }
/*      */ 
/*      */   private class RelationshipCardinality
/*      */   {
/*      */     private static final String MULTIPLE = "MULTIPLE";
/*      */     private static final String SINGLE = "SINGLE";
/*      */     private static final String UNDEFINED = "UNDEFINED";
/*      */     private static final String ONE = "one";
/*      */     private static final String ZERO = "zero";
/*      */     private static final String MANY = "many";
/*      */     private static final String DB_JOIN_NOT_REQUIRED = "0";
/*      */     private static final String DB_JOIN_REQUIRED = "1";
/*      */   }
/*      */ }
