/*      */ package com.ibm.tivoli.maximo.report.cognos.metadata.generator;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.report.cognos.metadata.util.PrintWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ 
























/*      */ public class ActionLogGen
/*      */ {
/*   30 */   private PrintWriter out = null;
/*   31 */   private int transactionsSequence = 0;
/*   32 */   private int actionsSequence = 0;
/*      */   private static final String LOCALE_EN = "en";
/*      */ 
/*      */   public ActionLogGen(PrintWriter out)
/*      */   {
/*   42 */     this.out = out;
/*      */   }





/*      */   public void generateScriptHeader()
/*      */   {
/*   51 */     this.out.println("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
/*   52 */     this.out.println("<bmtactionlog version=\"8.4.2230.0\">");
/*      */ 
/*   54 */     this.out.indent(2);
/*      */   }




/*      */   public void generateScriptTail()
/*      */   {
/*   62 */     this.out.unIndent(2);
/*      */ 
/*   64 */     this.out.println();
/*   65 */     this.out.println("</bmtactionlog>");
/*      */   }





/*      */   public void generateTransactionHeader()
/*      */   {
/*   74 */     this.out.println();
/*   75 */     this.out.print("<transaction seq=\""); this.out.print(getTransactionsSequence()); this.out.println("\" saved=\"true\">");
/*      */ 
/*   77 */     this.out.indent(2);
/*      */   }



/*      */   public void generateTransactionTail()
/*      */   {
/*   84 */     this.out.unIndent(2);
/*      */ 
/*   86 */     this.out.println();
/*   87 */     this.out.println("</transaction>");
/*      */   }


/*      */   /** @deprecated */
/*      */   public void generateProjectInitialization(String projectName, String topLevelNamespace)
/*      */   {
/*   94 */     generateProjectInitialization(projectName, topLevelNamespace, "en");
/*      */   }
















/*      */   public void generateProjectInitialization(String projectName, String topLevelNamespace, String defaultLocale)
/*      */   {
/*  114 */     this.out.println();
/*  115 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetDefaultLocale\">");
/*  116 */     this.out.println("  <inputparams>");
/*  117 */     this.out.print("    <param seq=\"1\" type=\"i18nstring\"><value>"); this.out.print(defaultLocale); this.out.print("</value></param>");
/*  118 */     this.out.println("  </inputparams>");
/*  119 */     this.out.println("</action>");
/*  120 */     this.out.println();
/*  121 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetActiveLocale\">");
/*  122 */     this.out.println("  <inputparams>");
/*  123 */     this.out.print("    <param seq=\"1\" type=\"i18nstring\"><value>"); this.out.print(defaultLocale); this.out.print("</value></param>");
/*  124 */     this.out.println("  </inputparams>");
/*  125 */     this.out.println("</action>");
/*  126 */     this.out.println();
/*  127 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  128 */     this.out.println("  <inputparams>");
/*  129 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  130 */     this.out.println("      <mappingpath>project/name</mappingpath>");
/*  131 */     this.out.println("      <value>/O/name[0]/O/[]</value>");
/*  132 */     this.out.println("    </param>");
/*  133 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(projectName); this.out.println("</value></param>");
/*  134 */     this.out.println("  </inputparams>");
/*  135 */     this.out.println("</action>");
/*  136 */     this.out.println();
/*  137 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  138 */     this.out.println("  <inputparams>");
/*  139 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  140 */     this.out.println("      <mappingpath>namespace/name</mappingpath>");
/*  141 */     this.out.println("      <value>/O/name[0]/O/[Model]</value>");
/*  142 */     this.out.println("    </param>");
/*  143 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(topLevelNamespace); this.out.println("</value></param>");
/*  144 */     this.out.println("  </inputparams>");
/*  145 */     this.out.println("</action>");
/*      */   }











/*      */   public void generateCreateNamespace(String namespace, String parentNamespace)
/*      */   {
/*  160 */     this.out.println();
/*  161 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Create\">");
/*  162 */     this.out.println("  <inputparams>");
/*  163 */     this.out.println("    <param seq=\"1\" type=\"integer\"><value>19</value></param>");
/*  164 */     this.out.println("    <param seq=\"2\" type=\"handle\">");
/*  165 */     this.out.println("      <mappingpath>namespace</mappingpath>");
/*  166 */     this.out.print("      <value>["); this.out.print(parentNamespace); this.out.println("]</value>");
/*  167 */     this.out.println("    </param>");
/*  168 */     this.out.print("    <param seq=\"3\" type=\"i18nstring\"><value>"); this.out.print(namespace); this.out.println("</value></param>");
/*  169 */     this.out.println("    <param seq=\"4\" type=\"integer\"><value>1</value></param>");
/*  170 */     this.out.println("  </inputparams>");
/*  171 */     this.out.println("</action>");
/*      */   }






















/*      */   public void generateDBImport(String parentNamespace, String databaseType, String dataSourceName, String schema, Set<String> tables, Set<String> views, String databaseName)
/*      */   {
/*  197 */     this.out.println();
/*  198 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"DBImport\">");
/*  199 */     this.out.println("  <inputparams>");
/*  200 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  201 */     this.out.println("      <mappingpath>namespace</mappingpath>");
/*  202 */     this.out.print("      <value>["); this.out.print(parentNamespace); this.out.println("]</value>");
/*  203 */     this.out.println("    </param>");
/*  204 */     this.out.println("    <param seq=\"2\" type=\"cclnode\">");
/*  205 */     this.out.print("      <value><![CDATA[ ");
/*  206 */     this.out.print("<item Name=\""); this.out.print(dataSourceName); this.out.print("\" Type=\"database\" Value=\"partial\" ");
/*  207 */     this.out.print("dbType=\""); this.out.print(databaseType); this.out.print("\" isSystem=\"false\">");
/*  208 */     if ("SS".equals(databaseType)) {
/*  209 */       this.out.print("<item Name=\""); this.out.print(databaseName); this.out.print("\" Type=\"catalog\" Value=\"partial\">");
/*      */     }
/*  211 */     this.out.print("<item Name=\""); this.out.print(schema); this.out.print("\" Type=\"schema\" Value=\"partial\">");
/*  212 */     if (tables.size() > 0) {
/*  213 */       this.out.print("<item Name=\"Tables\" Type=\"tables\" Value=\"partial\">");
/*  214 */       for (Iterator iterator = tables.iterator(); iterator.hasNext(); ) {
/*  215 */         this.out.print("<item Name=\""); this.out.print((String)iterator.next()); this.out.print("\" Type=\"table\" Value=\"true\"/>");
/*      */       }
/*  217 */       this.out.print("</item>");
/*      */     }
/*  219 */     if (views.size() > 0) {
/*  220 */       this.out.print("<item Name=\"Views\" Type=\"views\" Value=\"partial\">");
/*  221 */       for (Iterator iterator = views.iterator(); iterator.hasNext(); ) {
/*  222 */         this.out.print("<item Name=\""); this.out.print((String)iterator.next()); this.out.print("\" Type=\"view\" Value=\"true\"/>");
/*      */       }
/*  224 */       this.out.print("</item>");
/*      */     }
/*  226 */     this.out.print("</item>");
/*  227 */     if ("SS".equals(databaseType)) {
/*  228 */       this.out.print("</item>");
/*      */     }
/*  230 */     this.out.println("</item>]]></value>");
/*  231 */     this.out.println("    </param>");
/*  232 */     this.out.println("    <param seq=\"3\" type=\"integer\"><value>0</value></param>");
/*  233 */     this.out.println("    <param seq=\"4\" type=\"integer\"><value>0</value></param>");
/*  234 */     this.out.println("    <param seq=\"5\" type=\"integer\"><value>0</value></param>");
/*  235 */     this.out.println("    <param seq=\"6\" type=\"integer\"><value>0</value></param>");
/*  236 */     this.out.println("    <param seq=\"7\" type=\"integer\"><value>0</value></param>");
/*  237 */     this.out.println("    <param seq=\"8\" type=\"integer\"><value>0</value></param>");
/*  238 */     this.out.println("    <param seq=\"9\" type=\"integer\"><value>0</value></param>");
/*  239 */     this.out.println("    <param seq=\"10\" type=\"integer\"><value>1</value></param>");
/*  240 */     this.out.println("    <param seq=\"11\" type=\"integer\"><value>0</value></param>");
/*  241 */     this.out.println("    <param seq=\"12\" type=\"integer\"><value>0</value></param>");
/*  242 */     this.out.println("  </inputparams>");
/*  243 */     this.out.println("</action>");
/*  244 */     this.out.println();
/*  245 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"DBRelease\">");
/*  246 */     this.out.println("  <inputparams/>");
/*  247 */     this.out.println("</action>");
/*      */   }



/*      */   /** @deprecated */
/*      */   public void generateModelQuerySubject(String parentNamespace, String querySubjectName)
/*      */   {
/*  255 */     generateModelQuerySubject(parentNamespace, querySubjectName, "en");
/*      */   }












/*      */   public void generateModelQuerySubject(String parentNamespace, String querySubjectName, String defaultLocale)
/*      */   {
/*  271 */     this.out.println();
/*  272 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"UpdateObject\">");
/*  273 */     this.out.println("  <inputparams>");
/*  274 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  275 */     this.out.println("      <mappingpath>namespace</mappingpath>");
/*  276 */     this.out.print("      <value>["); this.out.print(parentNamespace); this.out.println("]</value>");
/*  277 */     this.out.println("    </param>");
/*  278 */     this.out.println("    <param seq=\"2\" type=\"cclnode\">");
/*  279 */     this.out.print("      <value><![CDATA[ <updateObjectRequest><tasks><task name=\"addObject\">");
/*  280 */     this.out.print("<parameters>");
/*  281 */     this.out.print("<param locale=\""); this.out.print(defaultLocale); this.out.print("\" name=\"objectName\" value=\""); this.out.print(querySubjectName); this.out.print("\"/>");
/*  282 */     this.out.print("<param name=\"objectType\" value=\"querySubject\"/>");
/*  283 */     this.out.print("<param name=\"makeNameUnique\" value=\"false\"/>");
/*  284 */     this.out.print("<param name=\"definitionType\" value=\"modelQuery\"/>");
/*  285 */     this.out.print("</parameters>");
/*  286 */     this.out.println("</task></tasks></updateObjectRequest>]]></value>");
/*  287 */     this.out.println("    </param>");
/*  288 */     this.out.println("  </inputparams>");
/*  289 */     this.out.println("</action>");
/*      */   }






/*      */   /** @deprecated */
/*      */   public void generateModelQueryItem(String parentNamespace, String querySubjectName, String queryItemName, String basedOnNamespace, String sourceQuerySubjectName, String queryItemDescription, String dataSourceQueryItemName)
/*      */   {
/*  300 */     generateModelQueryItem(parentNamespace, querySubjectName, queryItemName, basedOnNamespace, sourceQuerySubjectName, queryItemDescription, dataSourceQueryItemName, "en");
/*      */   }























/*      */   public void generateModelQueryItem(String parentNamespace, String querySubjectName, String queryItemName, String basedOnNamespace, String sourceQuerySubjectName, String queryItemDescription, String dataSourceQueryItemName, String defaultLocale)
/*      */   {
/*  327 */     this.out.println();
/*  328 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"UpdateObject\">");
/*  329 */     this.out.println("    <inputparams>");
/*  330 */     this.out.println("      <param seq=\"1\" type=\"handle\">");
/*  331 */     this.out.println("        <mappingpath>querySubject</mappingpath>");
/*  332 */     this.out.print("        <value>["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.println("]</value>");
/*  333 */     this.out.println("      </param>");
/*  334 */     this.out.println("      <param seq=\"2\" type=\"cclnode\">");
/*  335 */     this.out.print("        <value><![CDATA[ <updateObjectRequest><tasks><task name=\"addObject\">");
/*  336 */     this.out.print("<parameters>");
/*  337 */     this.out.print("<param locale=\""); this.out.print(defaultLocale); this.out.print("\" name=\"objectName\" value=\""); this.out.print(queryItemName); this.out.print("\"/>");
/*  338 */     this.out.print("<param name=\"objectType\" value=\"queryItem\"/>");
/*  339 */     this.out.print("<param name=\"makeNameUnique\" value=\"false\"/>");
/*  340 */     this.out.println("<param name=\"basedOn\"><expression>");
/*  341 */     this.out.print("              <refobj>["); this.out.print(basedOnNamespace); this.out.print("].["); this.out.print(sourceQuerySubjectName); this.out.print("].["); this.out.print(dataSourceQueryItemName); this.out.print("]</refobj>");
/*  342 */     this.out.print("</expression></param>");
/*  343 */     this.out.print("</parameters>");
/*  344 */     this.out.println("</task></tasks></updateObjectRequest>]]></value>");
/*  345 */     this.out.println("      </param>");
/*  346 */     this.out.println("    </inputparams>");
/*  347 */     this.out.println("  </action>");
/*  348 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  349 */     this.out.println("  <inputparams>");
/*  350 */     this.out.println("    <param seq=\"1\" type=\"handle\"><mappingpath>queryItem/description</mappingpath>");
/*  351 */     this.out.print("      <value>/O/description[0]/O/["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.print("].["); this.out.print(queryItemName); this.out.println("]</value>");
/*  352 */     this.out.println("    </param>");
/*  353 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\">");
/*  354 */     this.out.print("      <value>"); this.out.print(queryItemDescription); this.out.println("</value>");
/*  355 */     this.out.println("    </param>");
/*  356 */     this.out.println("  </inputparams>");
/*  357 */     this.out.println("</action>");
/*  358 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  359 */     this.out.println("  <inputparams>");
/*  360 */     this.out.println("    <param seq=\"1\" type=\"handle\"><mappingpath>queryItem/screenTip</mappingpath>");
/*  361 */     this.out.print("      <value>/O/screenTip[0]/O/["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.print("].["); this.out.print(queryItemName); this.out.println("]</value>");
/*  362 */     this.out.println("    </param>");
/*  363 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\">");
/*  364 */     this.out.print("      <value>"); this.out.print(queryItemDescription); this.out.println("</value>");
/*  365 */     this.out.println("    </param>");
/*  366 */     this.out.println("  </inputparams>");
/*  367 */     this.out.println("</action>");
/*      */   }













/*      */   public void generateHideQueryItem(String parentNamespace, String querySubjectName, String queryItemName)
/*      */   {
/*  384 */     this.out.println();
/*  385 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  386 */     this.out.println("  <inputparams>");
/*  387 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  388 */     this.out.println("      <mappingpath>queryItem/hidden</mappingpath>");
/*  389 */     this.out.print("      <value>/O/hidden[0]/O/["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.print("].["); this.out.print(queryItemName); this.out.println("]</value>");
/*  390 */     this.out.println("    </param>");
/*  391 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\"><value>true</value></param>");
/*  392 */     this.out.println("  </inputparams>");
/*  393 */     this.out.println("</action>");
/*      */   }











/*      */   public void generateEvaluateQuerySubject(String parentNamespace, String querySubjectName)
/*      */   {
/*  408 */     this.out.println();
/*  409 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"EvaluateObject\">");
/*  410 */     this.out.println("  <inputparams>");
/*  411 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  412 */     this.out.println("      <mappingpath>querySubject</mappingpath>");
/*  413 */     this.out.print("      <value>["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.println("]</value>");
/*  414 */     this.out.println("    </param>");
/*  415 */     this.out.println("  </inputparams>");
/*  416 */     this.out.println("</action>");
/*      */   }











/*      */   public void generateReorderByNameQuerySubject(String parentNamespace, String querySubjectName)
/*      */   {
/*  431 */     this.out.println();
/*  432 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"ReorderByName\">");
/*  433 */     this.out.println("  <inputparams>");
/*  434 */     this.out.println("    <param seq=\"1\" type=\"integer\"><value>1</value></param>");
/*  435 */     this.out.println("    <param seq=\"2\" type=\"integer\"><value>0</value></param>");
/*  436 */     this.out.println("    <param seq=\"3\" type=\"integer\"><value>1</value></param>");
/*  437 */     this.out.println("    <param seq=\"4\" type=\"integer\"><value>0</value></param>");
/*  438 */     this.out.println("    <param seq=\"5\" type=\"handle\">");
/*  439 */     this.out.println("      <mappingpath>querySubject</mappingpath>");
/*  440 */     this.out.print("      <value>["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.println("]</value>");
/*  441 */     this.out.println("    </param>");
/*  442 */     this.out.println("  </inputparams>");
/*  443 */     this.out.println("</action>");
/*      */   }































/*      */   public void generateRelationship(String topLevelNamespace, String parentNamespace, String leftQuerySubjectName, String leftMinCardinality, String leftMaxCardinality, String rightQuerySubjectName, String rightMinCardinality, String rightMaxCardinality, String relationshipName, List<String> leftQueryItems, List<String> rightQueryItems)
/*      */   {
/*  478 */     this.out.println();
/*  479 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Create\">");
/*  480 */     this.out.println("  <inputparams>");
/*  481 */     this.out.println("    <param seq=\"1\" type=\"integer\"><value>3</value></param>");
/*  482 */     this.out.println("    <param seq=\"2\" type=\"handle\"><mappingpath>project</mappingpath><value>[]</value></param>");
/*  483 */     this.out.println("    <param seq=\"3\" type=\"i18nstring\"><value>New Relationship</value></param>");
/*  484 */     this.out.println("  </inputparams>");
/*  485 */     this.out.println("</action>");
/*  486 */     this.out.println();
/*  487 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  488 */     this.out.println("  <inputparams>");
/*  489 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  490 */     this.out.println("      <mappingpath>relationship/left/refobj</mappingpath>");
/*  491 */     this.out.print("      <value>/O/left[0]/refobj[0]/O/["); this.out.print(topLevelNamespace); this.out.println("].[New Relationship]</value>");
/*  492 */     this.out.println("    </param>");
/*  493 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(leftQuerySubjectName); this.out.println("]</value>");
/*  494 */     this.out.println("    </param>");
/*  495 */     this.out.println("  </inputparams>");
/*  496 */     this.out.println("</action>");
/*  497 */     this.out.println();
/*  498 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  499 */     this.out.println("  <inputparams>");
/*  500 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  501 */     this.out.println("      <mappingpath>relationship/left/mincard</mappingpath>");
/*  502 */     this.out.print("      <value>/O/left[0]/mincard[0]/O/["); this.out.print(topLevelNamespace); this.out.println("].[New Relationship]</value>");
/*  503 */     this.out.println("    </param>");
/*  504 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(leftMinCardinality); this.out.println("</value></param>");
/*  505 */     this.out.println("  </inputparams>");
/*  506 */     this.out.println("</action>");
/*  507 */     this.out.println();
/*  508 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  509 */     this.out.println("  <inputparams>");
/*  510 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  511 */     this.out.println("      <mappingpath>relationship/left/maxcard</mappingpath>");
/*  512 */     this.out.print("      <value>/O/left[0]/maxcard[0]/O/["); this.out.print(topLevelNamespace); this.out.println("].[New Relationship]</value>");
/*  513 */     this.out.println("    </param>");
/*  514 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(leftMaxCardinality); this.out.println("</value></param>");
/*  515 */     this.out.println("  </inputparams>");
/*  516 */     this.out.println("</action>");
/*  517 */     this.out.println();
/*  518 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  519 */     this.out.println("  <inputparams>");
/*  520 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  521 */     this.out.println("      <mappingpath>relationship/right/refobj</mappingpath>");
/*  522 */     this.out.print("      <value>/O/right[0]/refobj[0]/O/["); this.out.print(topLevelNamespace); this.out.println("].[New Relationship]</value>");
/*  523 */     this.out.println("    </param>");
/*  524 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(rightQuerySubjectName); this.out.println("]</value></param>");
/*  525 */     this.out.println("  </inputparams>");
/*  526 */     this.out.println("</action>");
/*  527 */     this.out.println();
/*  528 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  529 */     this.out.println("  <inputparams>");
/*  530 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  531 */     this.out.println("      <mappingpath>relationship/right/mincard</mappingpath>");
/*  532 */     this.out.print("      <value>/O/right[0]/mincard[0]/O/["); this.out.print(parentNamespace); this.out.println("].[New Relationship]</value>");
/*  533 */     this.out.println("    </param>");
/*  534 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(rightMinCardinality); this.out.println("</value></param>");
/*  535 */     this.out.println("  </inputparams>");
/*  536 */     this.out.println("</action>");
/*  537 */     this.out.println();
/*  538 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  539 */     this.out.println("  <inputparams>");
/*  540 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  541 */     this.out.println("      <mappingpath>relationship/right/maxcard</mappingpath>");
/*  542 */     this.out.print("      <value>/O/right[0]/maxcard[0]/O/["); this.out.print(parentNamespace); this.out.println("].[New Relationship]</value>");
/*  543 */     this.out.println("    </param>");
/*  544 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(rightMaxCardinality); this.out.println("</value></param>");
/*  545 */     this.out.println("  </inputparams>");
/*  546 */     this.out.println("</action>");
/*  547 */     this.out.println();
/*  548 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  549 */     this.out.println("  <inputparams>");
/*  550 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  551 */     this.out.println("      <mappingpath>relationship/name</mappingpath>");
/*  552 */     this.out.print("      <value>/O/name[0]/O/["); this.out.print(parentNamespace); this.out.println("].[New Relationship]</value>");
/*  553 */     this.out.println("    </param>");
/*  554 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(relationshipName); this.out.println("</value></param>");
/*  555 */     this.out.println("  </inputparams>");
/*  556 */     this.out.println("</action>");
/*  557 */     this.out.println();
/*  558 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"ModifyComplex\">");
/*  559 */     this.out.println("  <inputparams>");
/*  560 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  561 */     this.out.println("      <mappingpath>relationship/expression</mappingpath>");
/*  562 */     this.out.print("      <value>/O/expression[0]/O/["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(relationshipName); this.out.println("]</value>");
/*  563 */     this.out.println("    </param>");
/*  564 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\">");
/*  565 */     this.out.print("      <value>");
/*  566 */     for (int i = 0; i < leftQueryItems.size(); ++i) {
/*  567 */       String leftQueryItemName = (String)leftQueryItems.get(i);
/*  568 */       String rightQueryItemName = (String)rightQueryItems.get(i);
/*  569 */       this.out.print("&lt;refobj&gt;["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(leftQuerySubjectName); this.out.print("].["); this.out.print(leftQueryItemName); this.out.print("]&lt;/refobj&gt;=");
/*  570 */       this.out.print("&lt;refobj&gt;["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(rightQuerySubjectName); this.out.print("].["); this.out.print(rightQueryItemName); this.out.print("]&lt;/refobj&gt;");
/*  571 */       if (i != leftQueryItems.size() - 1) {
/*  572 */         this.out.print("AND");
/*      */       }
/*      */     }
/*  575 */     this.out.println("</value>");
/*  576 */     this.out.println("    </param>");
/*  577 */     this.out.println("    <param seq=\"3\" type=\"integer\"><value>0</value></param>");
/*  578 */     this.out.println("  </inputparams>");
/*  579 */     this.out.println("</action>");
/*  580 */     this.out.println();
/*  581 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"EvaluateObject\">");
/*  582 */     this.out.println("  <inputparams>");
/*  583 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  584 */     this.out.println("      <mappingpath>relationship</mappingpath>");
/*  585 */     this.out.print("      <value>["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(relationshipName); this.out.println("]</value>");
/*  586 */     this.out.println("    </param>");
/*  587 */     this.out.println("  </inputparams>");
/*  588 */     this.out.println("</action>");
/*  589 */     this.out.println();
/*  590 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"CreateRemainingRelationships\">");
/*  591 */     this.out.println("  <inputparams>");
/*  592 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  593 */     this.out.println("      <mappingpath>relationship</mappingpath>");
/*  594 */     this.out.print("      <value>["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(relationshipName); this.out.println("]</value>");
/*  595 */     this.out.println("    </param>");
/*  596 */     this.out.println("    <param seq=\"2\" type=\"integer\"><value>1</value></param>");
/*  597 */     this.out.println("  </inputparams>");
/*  598 */     this.out.println("</action>");
/*      */   }





/*      */   public void generateAllowCrossProductJoin()
/*      */   {
/*  607 */     this.out.println();
/*  608 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Create\">");
/*  609 */     this.out.println("  <inputparams>");
/*  610 */     this.out.println("    <param seq=\"1\" type=\"integer\"><value>15</value></param>");
/*  611 */     this.out.println("    <param seq=\"2\" type=\"handle\">");
/*  612 */     this.out.println("      <mappingpath>parameterMap/[@hidden=true]</mappingpath>");
/*  613 */     this.out.println("      <value>[].[parameterMaps].[_governor]</value>");
/*  614 */     this.out.println("    </param>");
/*  615 */     this.out.println("    <param seq=\"3\" type=\"i18nstring\"><value>crossProductAllowed</value></param>");
/*  616 */     this.out.println("    <param seq=\"4\" type=\"integer\"><value>0</value></param>");
/*  617 */     this.out.println("  </inputparams>");
/*  618 */     this.out.println("</action>");
/*  619 */     this.out.println();
/*  620 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  621 */     this.out.println("  <inputparams>");
/*  622 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  623 */     this.out.println("      <mappingpath>parameterMapEntry/value</mappingpath>");
/*  624 */     this.out.println("      <value>/O/value[0]/O/[].[parameterMaps].[_governor].[crossProductAllowed]</value>");
/*  625 */     this.out.println("    </param>");
/*  626 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\"><value>0</value></param>");
/*  627 */     this.out.println("  </inputparams>");
/*  628 */     this.out.println("</action>");
/*      */   }





/*      */   public void generateSetQueryProcessingToLocal(String dataSourceName)
/*      */   {
/*  637 */     this.out.println();
/*  638 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  639 */     this.out.println("  <inputparams>");
/*  640 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  641 */     this.out.println("      <mappingpath>dataSource/queryProcessing</mappingpath>");
/*  642 */     this.out.print("      <value>/O/queryProcessing[0]/O/[].[dataSources].["); this.out.print(dataSourceName); this.out.println("]</value>");
/*  643 */     this.out.println("    </param>");
/*  644 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\"><value>limitedLocal</value></param>");
/*  645 */     this.out.println("  </inputparams><domchanges/>");
/*  646 */     this.out.println("</action>");
/*      */   }




/*      */   /** @deprecated */
/*      */   public void generateCreatePackage(String packageName, String excludedNamespace, String topLevelNamespace)
/*      */   {
/*  655 */     generateCreatePackage(packageName, excludedNamespace, topLevelNamespace, "en", new ArrayList());
/*      */   }











/*      */   public void generateCreatePackage(String packageName, String excludedNamespace, String topLevelNamespace, String defaultLocale, List<String> languages)
/*      */   {
/*  670 */     this.out.println();
/*  671 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Create\">");
/*  672 */     this.out.println("  <inputparams>");
/*  673 */     this.out.println("    <param seq=\"1\" type=\"integer\"><value>16</value></param>");
/*  674 */     this.out.println("    <param seq=\"2\" type=\"handle\">");
/*  675 */     this.out.println("      <mappingpath>securityViews</mappingpath>");
/*  676 */     this.out.println("      <value>[].[securityViews]</value>");
/*  677 */     this.out.println("    </param>");
/*  678 */     this.out.print("    <param seq=\"3\" type=\"i18nstring\"><value>"); this.out.print(packageName); this.out.println("</value></param>");
/*  679 */     this.out.println("    <param seq=\"4\" type=\"integer\"><value>1</value></param>");
/*  680 */     this.out.println("  </inputparams>");
/*  681 */     this.out.println("</action>");
/*  682 */     this.out.println();
/*  683 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetSecurityViewDefinition\">");
/*  684 */     this.out.println("  <inputparams>");
/*  685 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  686 */     this.out.println("      <mappingpath>securityView</mappingpath>");
/*  687 */     this.out.print("      <value>[].[securityViews].["); this.out.print(packageName); this.out.println("]</value>");
/*  688 */     this.out.println("    </param>");
/*  689 */     this.out.println("    <param seq=\"2\" type=\"handle\">");
/*  690 */     this.out.println("      <mappingpath>namespace</mappingpath>");
/*  691 */     this.out.print("      <value>["); this.out.print(excludedNamespace); this.out.println("]</value>");
/*  692 */     this.out.println("    </param>");
/*  693 */     this.out.println("    <param seq=\"3\" type=\"integer\"><value>0</value></param>");
/*  694 */     this.out.println("    <param seq=\"4\" type=\"handle\">");
/*  695 */     this.out.println("      <mappingpath>namespace</mappingpath>");
/*  696 */     this.out.print("      <value>["); this.out.print(topLevelNamespace); this.out.println("]</value>");
/*  697 */     this.out.println("    </param>");
/*  698 */     this.out.println("    <param seq=\"5\" type=\"integer\"><value>2</value></param>");
/*  699 */     this.out.println("  </inputparams>");
/*  700 */     this.out.println("</action>");
/*  701 */     this.out.println();
/*  702 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Create\">");
/*  703 */     this.out.println("  <inputparams>");
/*  704 */     this.out.println("    <param seq=\"1\" type=\"integer\"><value>6</value></param>");
/*  705 */     this.out.println("    <param seq=\"2\" type=\"handle\">");
/*  706 */     this.out.println("      <mappingpath>packages</mappingpath>");
/*  707 */     this.out.println("      <value>[].[packages]</value>");
/*  708 */     this.out.println("    </param>");
/*  709 */     this.out.print("    <param seq=\"3\" type=\"i18nstring\"><value>"); this.out.print(packageName); this.out.println("</value></param>");
/*  710 */     this.out.println("    <param seq=\"4\" type=\"integer\"><value>1</value></param>");
/*  711 */     this.out.println("  </inputparams>");
/*  712 */     this.out.println("</action>");
/*  713 */     this.out.println();
/*  714 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetSecurityViewDefinition\">");
/*  715 */     this.out.println("  <inputparams>");
/*  716 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  717 */     this.out.println("      <mappingpath>package</mappingpath>");
/*  718 */     this.out.print("      <value>[].[packages].["); this.out.print(packageName); this.out.println("]</value>");
/*  719 */     this.out.println("    </param>");
/*  720 */     this.out.println("    <param seq=\"2\" type=\"handle\">");
/*  721 */     this.out.println("      <mappingpath>securityView</mappingpath>");
/*  722 */     this.out.print("      <value>[].[securityViews].["); this.out.print(packageName); this.out.println("]</value>");
/*  723 */     this.out.println("    </param>");
/*  724 */     this.out.println("    <param seq=\"3\" type=\"integer\"><value>2</value></param>");
/*  725 */     this.out.println("  </inputparams>");
/*  726 */     this.out.println("</action>");
/*  727 */     this.out.println();
/*  728 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetPackageLocales\">");
/*  729 */     this.out.println("  <inputparams>");
/*  730 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  731 */     this.out.println("      <mappingpath>package</mappingpath>");
/*  732 */     this.out.print("      <value>[].[packages].["); this.out.print(packageName); this.out.println("]</value>");
/*  733 */     this.out.println("    </param>");
/*  734 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(defaultLocale); this.out.println("</value></param>");

/*      */ 
/*  737 */     int paramSeq = 3;
/*  738 */     for (Iterator iterator = languages.iterator(); iterator.hasNext(); )
/*      */     {
/*  740 */       this.out.print("    <param seq=\""); this.out.print(paramSeq); this.out.print("\" type=\"i18nstring\"><value>");
/*  741 */       this.out.print((String)iterator.next()); this.out.println("</value></param>");
/*  742 */       ++paramSeq;
/*      */     }
/*      */ 
/*  745 */     this.out.println("  </inputparams>");
/*  746 */     this.out.println("</action>");
/*  747 */     this.out.println();
/*      */ 
/*  749 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  750 */     this.out.println("  <inputparams>");
/*  751 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  752 */     this.out.println("      <mappingpath>package/description</mappingpath>");
/*  753 */     this.out.print("      <value>/O/description[0]/O/[].[packages].["); this.out.print(packageName); this.out.println("]</value>");
/*  754 */     this.out.println("    </param>");
/*  755 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\"><value /></param>");
/*  756 */     this.out.println("  </inputparams>");
/*  757 */     this.out.println("</action>");
/*  758 */     this.out.println();
/*  759 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  760 */     this.out.println("  <inputparams>");
/*  761 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  762 */     this.out.println("      <mappingpath>package/screenTip</mappingpath>");
/*  763 */     this.out.print("      <value>/O/screenTip[0]/O/[].[packages].["); this.out.print(packageName); this.out.println("]</value>");
/*  764 */     this.out.println("    </param>");
/*  765 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\"><value /></param>");
/*  766 */     this.out.println("  </inputparams>");
/*  767 */     this.out.println("</action>");
/*  768 */     this.out.println();
/*  769 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetSecurityViewAccess\">");
/*  770 */     this.out.println("  <inputparams>");
/*  771 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  772 */     this.out.println("      <mappingpath>securityView</mappingpath>");
/*  773 */     this.out.print("      <value>[].[securityViews].["); this.out.print(packageName); this.out.println("]</value>");
/*  774 */     this.out.println("    </param>");
/*  775 */     this.out.println("    <param seq=\"2\" type=\"integer\"><value>1</value></param>");
/*  776 */     this.out.println("    <param seq=\"3\" type=\"cclnode\"><value><![CDATA[ <securityObjects/>]]></value></param>");
/*  777 */     this.out.println("  </inputparams>");
/*  778 */     this.out.println("</action>");
/*  779 */     this.out.println();
/*  780 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetSecurityViewAccess\">");
/*  781 */     this.out.println("  <inputparams>");
/*  782 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  783 */     this.out.println("      <mappingpath>package</mappingpath>");
/*  784 */     this.out.print("      <value>[].[packages].["); this.out.print(packageName); this.out.println("]</value>");
/*  785 */     this.out.println("    </param>");
/*  786 */     this.out.println("    <param seq=\"2\" type=\"integer\"><value>1</value></param>");
/*  787 */     this.out.println("    <param seq=\"3\" type=\"cclnode\"><value><![CDATA[ <securityObjects/>]]></value></param>");
/*  788 */     this.out.println("  </inputparams>");
/*  789 */     this.out.println("</action>");
/*  790 */     this.out.println();
/*  791 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"UpdateObject\">");
/*  792 */     this.out.println("  <inputparams>");
/*  793 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  794 */     this.out.println("      <mappingpath>securityView</mappingpath>");
/*  795 */     this.out.print("      <value>[].[securityViews].["); this.out.print(packageName); this.out.println("]</value>");
/*  796 */     this.out.println("    </param>");
/*  797 */     this.out.println("    <param seq=\"2\" type=\"cclnode\">");
/*  798 */     this.out.println("      <value><![CDATA[ <updateObjectRequest><tasks>");
/*  799 */     this.out.print("        <task name=\"addProperty\"><parameters>");
/*  800 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  801 */     this.out.print("<param name=\"propertyValue\" value=\"V_DB2\"/>");
/*  802 */     this.out.print("</parameters></task>");
/*  803 */     this.out.print("<task name=\"addProperty\"><parameters>");
/*  804 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  805 */     this.out.print("<param name=\"propertyValue\" value=\"V_Informix\"/>");
/*  806 */     this.out.print("</parameters></task>");
/*  807 */     this.out.print("<task name=\"addProperty\"><parameters>");
/*  808 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  809 */     this.out.print("<param name=\"propertyValue\" value=\"V_MSAccess\"/>");
/*  810 */     this.out.print("</parameters></task>");
/*  811 */     this.out.print("<task name=\"addProperty\"><parameters>");
/*  812 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  813 */     this.out.print("<param name=\"propertyValue\" value=\"V_Oracle\"/>");
/*  814 */     this.out.print("</parameters></task>");
/*  815 */     this.out.print("<task name=\"addProperty\"><parameters>");
/*  816 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  817 */     this.out.print("<param name=\"propertyValue\" value=\"V_Redbrick\"/>");
/*  818 */     this.out.print("</parameters></task>");
/*  819 */     this.out.print("<task name=\"addProperty\"><parameters>");
/*  820 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  821 */     this.out.print("<param name=\"propertyValue\" value=\"V_SQLServer\"/>");
/*  822 */     this.out.print("</parameters></task>");
/*  823 */     this.out.print("<task name=\"addProperty\"><parameters>");
/*  824 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  825 */     this.out.print("<param name=\"propertyValue\" value=\"V_Teradata\"/>");
/*  826 */     this.out.print("</parameters></task>");
/*  827 */     this.out.print("<task name=\"addProperty\"><parameters>");
/*  828 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  829 */     this.out.print("<param name=\"propertyValue\" value=\"V_SAPBW\"/>");
/*  830 */     this.out.print("</parameters></task>");
/*  831 */     this.out.print("<task name=\"addProperty\"><parameters>");
/*  832 */     this.out.print("<param name=\"propertyType\" value=\"functionSet\"/>");
/*  833 */     this.out.print("<param name=\"propertyValue\" value=\"V_Sybase\"/>");
/*  834 */     this.out.print("</parameters></task>");
/*  835 */     this.out.println("</tasks></updateObjectRequest>]]></value>");
/*  836 */     this.out.println("    </param>");
/*  837 */     this.out.println("  </inputparams>");
/*  838 */     this.out.println("</action>");
/*  839 */     this.out.println();
/*  840 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetSecurityViewAccess\">");
/*  841 */     this.out.println("  <inputparams>");
/*  842 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  843 */     this.out.println("      <mappingpath>securityView</mappingpath>");
/*  844 */     this.out.print("      <value>[].[securityViews].["); this.out.print(packageName); this.out.println("]</value>");
/*  845 */     this.out.println("    </param>");
/*  846 */     this.out.println("    <param seq=\"2\" type=\"integer\"><value>1</value></param>");
/*  847 */     this.out.println("    <param seq=\"3\" type=\"cclnode\"><value><![CDATA[ <securityObjects/>]]></value></param>");
/*  848 */     this.out.println("  </inputparams>");
/*  849 */     this.out.println("</action>");
/*  850 */     this.out.println();
/*  851 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"SetSecurityViewAccess\">");
/*  852 */     this.out.println("  <inputparams>");
/*  853 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  854 */     this.out.println("      <mappingpath>package</mappingpath>");
/*  855 */     this.out.print("      <value>[].[packages].["); this.out.print(packageName); this.out.println("]</value>");
/*  856 */     this.out.println("    </param>");
/*  857 */     this.out.println("    <param seq=\"2\" type=\"integer\"><value>1</value></param>");
/*  858 */     this.out.println("    <param seq=\"3\" type=\"cclnode\"><value><![CDATA[ <securityObjects/>]]></value></param>");
/*  859 */     this.out.println("  </inputparams>");
/*  860 */     this.out.println("</action>");
/*      */   }







/*      */   public void generatePublishPackage(String packageName, String contentStorePackageLocation)
/*      */   {
/*  871 */     this.out.println();
/*  872 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Publish\">");
/*  873 */     this.out.println("  <inputparams>");
/*  874 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  875 */     this.out.println("      <mappingpath>package</mappingpath>");
/*  876 */     this.out.print("      <value>[].[packages].["); this.out.print(packageName); this.out.println("]</value>");
/*  877 */     this.out.println("    </param>");
/*  878 */     this.out.println("    <param seq=\"2\" type=\"integer\"><value>2</value></param>");
/*  879 */     this.out.print("    <param seq=\"3\" type=\"i18nstring\"><value>/content"); this.out.print(contentStorePackageLocation); this.out.println("</value></param>");
/*  880 */     this.out.print("    <param seq=\"4\" type=\"i18nstring\"><value>"); this.out.print(packageName); this.out.println("</value></param>");
/*  881 */     this.out.println("    <param seq=\"5\" type=\"integer\"><value>1</value></param>");
/*  882 */     this.out.println("    <param seq=\"6\" type=\"integer\"><value>0</value></param>");
/*  883 */     this.out.println("    <param seq=\"7\" type=\"integer\"><value>0</value></param>");
/*  884 */     this.out.println("  </inputparams>");
/*  885 */     this.out.println("</action>");
/*      */   }







/*      */   public void generateAddProjectLocale(String locale, String defaultLocale)
/*      */   {
/*  896 */     this.out.println();
/*  897 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"AddLocale\">");
/*  898 */     this.out.println("  <inputparams>");
/*  899 */     this.out.println("    <param seq=\"1\" type=\"stringCollection\">");
/*  900 */     this.out.print("      <value>&lt;stringCollection&gt;&lt;item&gt;"); this.out.print(locale); this.out.print("&lt;/item&gt;&lt;/stringCollection&gt;</value>");
/*  901 */     this.out.println("    </param>");
/*  902 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(defaultLocale); this.out.print("</value></param>");
/*  903 */     this.out.println("  </inputparams>");
/*  904 */     this.out.println("</action>");
/*      */   }












/*      */   public void generatePackageNameTranslations(String packageName, String nameTranslation, int localeIndex)
/*      */   {
/*  920 */     this.out.println();
/*  921 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  922 */     this.out.println("  <inputparams>");
/*  923 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  924 */     this.out.println("      <mappingpath>package/name</mappingpath>");
/*  925 */     this.out.print("      <value>/O/name["); this.out.print(localeIndex); this.out.print("]/O/[].[packages].["); this.out.print(packageName); this.out.print("]</value>");
/*  926 */     this.out.println("    </param>");
/*  927 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value><![CDATA["); this.out.print(nameTranslation); this.out.println("]]></value></param>");
/*      */ 
/*  929 */     this.out.println("  </inputparams>");
/*  930 */     this.out.println("</action>");
/*      */   }












/*      */   public void generateModelNameTranslation(String modelName, String nameTranslation, int localeIndex)
/*      */   {
/*  946 */     this.out.println();
/*  947 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  948 */     this.out.println("  <inputparams>");
/*  949 */     this.out.println("    <param seq=\"1\" type=\"handle\">");
/*  950 */     this.out.println("      <mappingpath>namespace/name</mappingpath>");
/*  951 */     this.out.print("      <value>/O/name["); this.out.print(localeIndex); this.out.print("]/O/[Model]</value>");
/*  952 */     this.out.println("    </param>");
/*  953 */     this.out.print("    <param seq=\"2\" type=\"i18nstring\"><value>"); this.out.print(nameTranslation); this.out.println("</value></param>");
/*  954 */     this.out.println("  </inputparams>");
/*  955 */     this.out.println("</action>");
/*      */   }












/*      */   public void generateNamespaceTranslation(String namespace, String nameTranslation, int localeIndex)
/*      */   {
/*  971 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  972 */     this.out.println("  <inputparams>");
/*  973 */     this.out.println("    <param seq=\"1\" type=\"handle\"><mappingpath>namespace/name</mappingpath>");
/*  974 */     this.out.print("        <value>/O/name["); this.out.print(localeIndex); this.out.print("]/O/["); this.out.print(namespace); this.out.print("]</value>");
/*  975 */     this.out.println("    </param>");
/*  976 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\">");
/*  977 */     this.out.print("        <value>"); this.out.print(nameTranslation); this.out.println("</value>");
/*  978 */     this.out.println("    </param>");
/*  979 */     this.out.println("  </inputparams>");
/*  980 */     this.out.println("</action>");
/*      */   }














/*      */   public void generateModelQuerySubjectTranslations(String parentNamespace, String querySubjectName, String nameTranslation, int localeIndex)
/*      */   {
/*  998 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/*  999 */     this.out.println("  <inputparams>");
/* 1000 */     this.out.println("    <param seq=\"1\" type=\"handle\"><mappingpath>queryItem/name</mappingpath>");
/* 1001 */     this.out.print("        <value>/O/name["); this.out.print(localeIndex); this.out.print("]/O/["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.print("]</value>");
/* 1002 */     this.out.println("    </param>");
/* 1003 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\">");
/* 1004 */     this.out.print("        <value>"); this.out.print(nameTranslation); this.out.println("</value>");
/* 1005 */     this.out.println("    </param>");
/* 1006 */     this.out.println("  </inputparams>");
/* 1007 */     this.out.println("</action>");
/*      */   }


















/*      */   public void generateModelQueryItemNameTranslation(String parentNamespace, String querySubjectName, String queryItemName, String nameTranslation, int localeIndex)
/*      */   {
/* 1029 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/* 1030 */     this.out.println("  <inputparams>");
/* 1031 */     this.out.println("    <param seq=\"1\" type=\"handle\"><mappingpath>queryItem/name</mappingpath>");
/* 1032 */     this.out.print("        <value>/O/name["); this.out.print(localeIndex); this.out.print("]/O/["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.print("].["); this.out.print(queryItemName); this.out.println("]</value>");
/* 1033 */     this.out.println("    </param>");
/* 1034 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\">");
/* 1035 */     this.out.print("        <value>"); this.out.print(nameTranslation); this.out.println("</value>");
/* 1036 */     this.out.println("    </param>");
/* 1037 */     this.out.println("  </inputparams>");
/* 1038 */     this.out.println("</action>");
/*      */   }

















/*      */   public void generateModelQueryItemDescTranslation(String parentNamespace, String querySubjectName, String queryItemName, String descTranslation, int localeIndex)
/*      */   {
/* 1059 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/* 1060 */     this.out.println("  <inputparams>");
/* 1061 */     this.out.println("    <param seq=\"1\" type=\"handle\"><mappingpath>queryItem/description</mappingpath>");
/* 1062 */     this.out.print("        <value>/O/description["); this.out.print(localeIndex); this.out.print("]/O/["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.print("].["); this.out.print(queryItemName); this.out.println("]</value>");
/* 1063 */     this.out.println("    </param>");
/* 1064 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\">");
/* 1065 */     this.out.print("        <value>"); this.out.print(descTranslation); this.out.println("</value>");
/* 1066 */     this.out.println("    </param>");
/* 1067 */     this.out.println("  </inputparams>");
/* 1068 */     this.out.println("</action>");
/* 1069 */     this.out.print("<action seq=\""); this.out.print(getActionsSequence()); this.out.println("\" type=\"Modify\">");
/* 1070 */     this.out.println("  <inputparams>");
/* 1071 */     this.out.println("    <param seq=\"1\" type=\"handle\"><mappingpath>queryItem/screenTip</mappingpath>");
/* 1072 */     this.out.print("        <value>/O/screenTip["); this.out.print(localeIndex); this.out.print("]/O/["); this.out.print(parentNamespace); this.out.print("].["); this.out.print(querySubjectName); this.out.print("].["); this.out.print(queryItemName); this.out.println("]</value>");
/* 1073 */     this.out.println("    </param>");
/* 1074 */     this.out.println("    <param seq=\"2\" type=\"i18nstring\">");
/* 1075 */     this.out.print("        <value>"); this.out.print(descTranslation); this.out.println("</value>");
/* 1076 */     this.out.println("    </param>");
/* 1077 */     this.out.println("  </inputparams>");
/* 1078 */     this.out.println("</action>");
/*      */   }






/*      */   private int getTransactionsSequence()
/*      */   {
/* 1088 */     this.actionsSequence = 0;
/* 1089 */     return (++this.transactionsSequence);
/*      */   }





/*      */   private int getActionsSequence()
/*      */   {
/* 1098 */     return (++this.actionsSequence);
/*      */   }
/*      */ }
