/*     */ package com.ibm.tivoli.maximo.report.cognos.metadata.player;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.exception.CognosHandlerException;
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.util.ActionLogUtil;
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.util.XMLElement;
/*     */ import java.io.File;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 





































/*     */ public class ActionLogPlayer
/*     */ {
/*     */   private CognosManager manager;
/*     */   private static final String FILE_NAME_EXTENSION = ".cpf";
/*     */   private static final String DATE_TIME_FORMAT = "yyyyMMMMdd_kkmmss_SSS";
/*     */ 
/*     */   public ActionLogPlayer(String url, String namespaeId, String userName, String password)
/*     */     throws CognosHandlerException
/*     */   {
/*  62 */     long time = 0L;
/*  63 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  64 */       time = System.currentTimeMillis();
/*  65 */       MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: Setup Cognos Server Connection ...");
/*     */     }
/*  67 */     this.manager = new CognosManager(url, namespaeId, userName, password);
/*  68 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/*  69 */       MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: Cognos Server Connection setup completed in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }





























/*     */   public void playScript(String projectBaseDir, String script, String dataSourceName, String contentStorePackageLocation)
/*     */     throws CognosHandlerException
/*     */   {
/* 103 */     playScript(projectBaseDir, new StringReader(script), dataSourceName, contentStorePackageLocation);
/*     */   }



























/*     */   public void playScript(String projectBaseDir, Reader in, String dataSourceName, String contentStorePackageLocation)
/*     */     throws CognosHandlerException
/*     */   {
/* 135 */     long time = 0L;
/* 136 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 137 */       time = System.currentTimeMillis();
/* 138 */       MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: Start script playing ...");
/*     */     }
/* 140 */     XMLElement script = parseXMLInput(in);
/* 141 */     String projectLocation = getProjectLocation(projectBaseDir, script);
/* 142 */     String cognosContentStorePackageLocation = ActionLogUtil.getContentStorePackageLocation(contentStorePackageLocation);

/*     */ 
/* 145 */     this.manager.createModel(projectLocation);
/* 146 */     this.manager.openModel(projectLocation);

/*     */     try
/*     */     {
/* 150 */       for (XMLElement transaction : script.getChildren("transaction")) {
/* 151 */         this.manager.executeTransaction(projectLocation, parseTransaction(transaction, dataSourceName, cognosContentStorePackageLocation));

/*     */       }
/*     */ 
/*     */     }
/*     */     catch (CognosHandlerException che)
/*     */     {
/* 158 */       File folder = new File(projectLocation).getParentFile();
/* 159 */       if (folder.exists())
/*     */       {
/* 161 */         File[] files = folder.listFiles();
/* 162 */         for (int i = 0; i < files.length; ++i)
/*     */         {
/* 164 */           File f = files[i];
/* 165 */           f.delete();
/*     */         }
/* 167 */         folder.delete();
/*     */       }
/*     */ 
/* 170 */       throw che;
/*     */     }
/*     */ 
/* 173 */     this.manager.saveModel(projectLocation);
/* 174 */     this.manager.closeModel(projectLocation);
/* 175 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 176 */       MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: Script playing completed in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }
















/*     */   private String parseTransaction(XMLElement transaction, String dataSourceName, String cognosContentStorePackageLocation)
/*     */     throws CognosHandlerException
/*     */   {
/* 197 */     String transactionXML = null;
/*     */     try {
/* 199 */       transactionXML = transaction.getXML();
/* 200 */       if ((dataSourceName != null) && (!("".equals(dataSourceName)))) {
/* 201 */         transactionXML = replaceDataSourceName(transaction, transactionXML, dataSourceName);
/*     */       }
/* 203 */       transactionXML = replaceContentStorePackageLocation(transaction, transactionXML, cognosContentStorePackageLocation);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 207 */       MicUtil.INTEGRATIONLOGGER.error("Error occured during getting the xml from the transaction...", e);
/* 208 */       throw new CognosHandlerException("cognos_publish_failed", e);
/*     */     }
/* 210 */     return transactionXML;
/*     */   }











/*     */   private String replaceDataSourceName(XMLElement transaction, String transactionXML, String dataSourceName)
/*     */   {
/* 225 */     for (XMLElement action : transaction.getChildren("action")) {
/* 226 */       if ("DBImport".equals(action.getAttribute("type"))) {
/* 227 */         for (XMLElement param : action.getChild("inputparams").getChildren("param")) {
/* 228 */           if ("2".equals(param.getAttribute("seq"))) {
/* 229 */             String dbImportStringOriginal = param.getChildValue("value");
/* 230 */             if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 231 */               MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: original dbimport: " + dbImportStringOriginal + "...");

/*     */             }
/*     */ 
/* 235 */             int dataSourceBeginIndex = dbImportStringOriginal.indexOf("\"");
/* 236 */             int dataSourceEndIndex = dbImportStringOriginal.indexOf("\"", dataSourceBeginIndex + 1);
/* 237 */             String dataSourceNameOriginal = dbImportStringOriginal.substring(dataSourceBeginIndex + 1, dataSourceEndIndex);

/*     */ 
/* 240 */             if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 241 */               MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: original data source name: " + dataSourceNameOriginal + "...");
/*     */             }
/*     */ 
/* 244 */             String dbImportString = new String(dbImportStringOriginal);
/* 245 */             dbImportString = dbImportString.replaceFirst(dataSourceNameOriginal, dataSourceName);
/* 246 */             transactionXML = transactionXML.replaceFirst(dbImportStringOriginal, dbImportString);
/*     */ 
/* 248 */             if (!(MicUtil.INTEGRATIONLOGGER.isDebugEnabled())) break;
/* 249 */             MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: dbimport after change " + dbImportString + "..."); break;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 254 */       else if (transactionXML.contains("<value>/O/queryProcessing[0]/O/[].[dataSources].[")) {
/* 255 */         int dataSourceBeginIndex = transactionXML.indexOf("<value>/O/queryProcessing[0]/O/[].[dataSources].[") + "<value>/O/queryProcessing[0]/O/[].[dataSources].[".length() - 1;

/*     */ 
/* 258 */         int dataSourceEndIndex = transactionXML.indexOf("]", dataSourceBeginIndex + 1);
/* 259 */         String dataSourceNameOriginal = transactionXML.substring(dataSourceBeginIndex + 1, dataSourceEndIndex);
/*     */ 
/* 261 */         if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 262 */           MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: original data source name: " + dataSourceNameOriginal + "...");

/*     */         }
/*     */ 
/* 266 */         transactionXML = transactionXML.replaceFirst(dataSourceNameOriginal, dataSourceName);
/*     */ 
/* 268 */         if (!(MicUtil.INTEGRATIONLOGGER.isDebugEnabled())) break;
/* 269 */         MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: transactionXML after change " + transactionXML + "..."); break;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 274 */     return transactionXML;
/*     */   }












/*     */   private String replaceContentStorePackageLocation(XMLElement transaction, String transactionXML, String cognosContentStorePackageLocation)
/*     */   {
/* 290 */     for (XMLElement action : transaction.getChildren("action")) {
/* 291 */       if ("Publish".equals(action.getAttribute("type"))) {
/* 292 */         for (XMLElement param : action.getChild("inputparams").getChildren("param")) {
/* 293 */           if ("3".equals(param.getAttribute("seq"))) {
/* 294 */             String contentStorePackageLocationOriginal = param.getChildValue("value");
/* 295 */             if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 296 */               MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: original package location: " + contentStorePackageLocationOriginal + ", new package location: " + cognosContentStorePackageLocation + "...");

/*     */             }
/*     */ 
/* 300 */             transactionXML = transactionXML.replace(contentStorePackageLocationOriginal, "/content" + cognosContentStorePackageLocation);
/*     */ 
/* 302 */             break;
/*     */           }
/*     */         }
/* 305 */         break;
/*     */       }
/*     */     }
/* 308 */     return transactionXML;
/*     */   }








/*     */   private static XMLElement parseXMLInput(Reader in)
/*     */     throws CognosHandlerException
/*     */   {
/* 321 */     XMLElement model = null;
/*     */     try {
/* 323 */       model = XMLElement.parse(in);
/*     */     } catch (Exception e) {
/* 325 */       MicUtil.INTEGRATIONLOGGER.error("Error occured during parsing the maximo input xml...", e);
/* 326 */       throw new CognosHandlerException("cognos_publish_failed", e);
/*     */     }
/* 328 */     return model;
/*     */   }















/*     */   private String getProjectLocation(String projectBaseDir, XMLElement script)
/*     */   {
/* 347 */     String projectName = parseProjectName(script);
/*     */ 
/* 349 */     SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMMMdd_kkmmss_SSS");
/* 350 */     String currentDateTime = dateFormat.format(new Date(System.currentTimeMillis()));
/* 351 */     String projectLocation = projectBaseDir + "/" + projectName + "_" + currentDateTime + "/" + projectName + ".cpf";

/*     */ 
/* 354 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 355 */       MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: Project location: " + projectLocation + "...");
/*     */     }
/* 357 */     return projectLocation;
/*     */   }







/*     */   private String parseProjectName(XMLElement script)
/*     */   {
/* 368 */     String projectName = null;
/* 369 */     Iterator i$ = script.getChildren("transaction").iterator(); if (i$.hasNext()) { XMLElement transaction = (XMLElement)i$.next();
/* 370 */       if ("1".equals(transaction.getAttribute("seq"))) {
/* 371 */         for (XMLElement action : transaction.getChildren("action")) {
/* 372 */           if ("3".equals(action.getAttribute("seq"))) {
/* 373 */             for (XMLElement param : action.getChild("inputparams").getChildren("param")) {
/* 374 */               if ("2".equals(param.getAttribute("seq"))) {
/* 375 */                 projectName = param.getChildValue("value");
/* 376 */                 break;
/*     */               }
/*     */             }
/* 379 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 385 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 386 */       MicUtil.INTEGRATIONLOGGER.debug("ActionLogPlayer: Project name: " + projectName + "...");
/*     */     }
/* 388 */     return projectName;
/*     */   }
/*     */ }
