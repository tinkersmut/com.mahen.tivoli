/*     */ package com.ibm.tivoli.maximo.report.cognos.metadata.adapter;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.exception.CognosHandlerException;
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.player.ActionLogPlayer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import psdi.iface.mic.MaxEndPointInfo;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.iface.router.BaseRouterHandler;
/*     */ import psdi.iface.router.RouterPropsInfo;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 























































































/*     */ public class CognosHandler extends BaseRouterHandler
/*     */ {
/*     */   public static final String URL = "URL";
/*     */   public static final String NAMESPACE_ID = "NAMESPACE_ID";
/*     */   public static final String PROJECT_BASE_DIR = "PROJECT_BASE_DIR";
/*     */   public static final String DATA_SOURCE_NAME = "DATA_SOURCE_NAME";
/*     */   public static final String CONTENT_STORE_PACKAGE_LOCATION = "CONTENT_STORE_PACKAGE_LOCATION";
/* 101 */   private static List<RouterPropsInfo> properties = new ArrayList(5);
/*     */   private static final String UTF8 = "UTF-8";
/*     */ 
/*     */   public CognosHandler()
/*     */   {
/* 115 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 116 */       MicUtil.INTEGRATIONLOGGER.debug("Initialized Cognos Handler");
/*     */   }






/*     */   public CognosHandler(MaxEndPointInfo endPointInfo)
/*     */   {
/* 126 */     super(endPointInfo);
/* 127 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 128 */       MicUtil.INTEGRATIONLOGGER.debug("Initialized Cognos Handler with endpoint info");
/*     */   }






/*     */   public List<RouterPropsInfo> getProperties()
/*     */   {
/* 138 */     return properties;
/*     */   }












/*     */   public byte[] invoke(Map<String, ?> metadata, byte[] data)
/*     */     throws MXException
/*     */   {
/* 155 */     data = super.invoke(metadata, data);
/*     */ 
/* 157 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 158 */       MicUtil.INTEGRATIONLOGGER.debug("START---cognos invocation from Cognos Handler");

/*     */     }
/*     */ 
/* 162 */     if ((metadata == null) && (this.endPointPropVals == null)) {
/* 163 */       throw new MXApplicationException("iface", "noendpointprops");

/*     */     }
/*     */ 
/* 167 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 168 */       MicUtil.INTEGRATIONLOGGER.debug("url=" + getURL());
/* 169 */       MicUtil.INTEGRATIONLOGGER.debug("namespaceId=" + getNamespaceId());
/* 170 */       MicUtil.INTEGRATIONLOGGER.debug("projectLocation=" + getProjectBaseDir());
/* 171 */       MicUtil.INTEGRATIONLOGGER.debug("dataSourceName=" + getDataSourceName());
/* 172 */       MicUtil.INTEGRATIONLOGGER.debug("contentStorePackageLocation=" + getContentStorePackageLocation());
/* 173 */       MicUtil.INTEGRATIONLOGGER.debug("username=" + getUsername());




/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 182 */       String dataOut = new String(data, "UTF-8");
/*     */ 
/* 184 */       ActionLogPlayer player = new ActionLogPlayer(getURL(), getNamespaceId(), getUsername(), getPassword());
/* 185 */       player.playScript(getProjectBaseDir(), dataOut, getDataSourceName(), getContentStorePackageLocation());
/* 186 */       MicUtil.INTEGRATIONLOGGER.info("Publishing of Maximo Object Structures as Cognos Packages was done successfully");


/*     */     }
/*     */     catch (CognosHandlerException exCH)
/*     */     {
/* 192 */       MicUtil.INTEGRATIONLOGGER.error("Error while invoking the Cognos Player class \"ActionLogPlayer\"", exCH);
/* 193 */       throw exCH;

/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 198 */       MicUtil.INTEGRATIONLOGGER.error("Error while invoking the Cognos Player class \"ActionLogPlayer\"", t);
/* 199 */       throw new CognosHandlerException("cognos_publish_failed", t);
/*     */     }
/*     */ 
/* 202 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 203 */       MicUtil.INTEGRATIONLOGGER.debug("END---cognos invocation from Cognos Handler");



/*     */     }
/*     */ 
/* 209 */     throw new MXApplicationException("iface", "cognos_publish_succeeded");
/*     */   }





/*     */   private String getURL()
/*     */   {
/* 218 */     return getPropertyValue("URL");
/*     */   }





/*     */   private String getNamespaceId()
/*     */   {
/* 227 */     return getPropertyValue("NAMESPACE_ID");
/*     */   }





/*     */   private String getProjectBaseDir()
/*     */   {
/* 236 */     return getPropertyValue("PROJECT_BASE_DIR");
/*     */   }





/*     */   private String getDataSourceName()
/*     */   {
/* 245 */     return getPropertyValue("DATA_SOURCE_NAME");
/*     */   }





/*     */   private String getContentStorePackageLocation()
/*     */   {
/* 254 */     return getPropertyValue("CONTENT_STORE_PACKAGE_LOCATION");
/*     */   }





/*     */   private String getUsername()
/*     */   {
/* 263 */     return getPropertyValue("USERNAME");
/*     */   }





/*     */   private String getPassword()
/*     */   {
/* 272 */     return getPropertyValue("PASSWORD");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 102 */     properties.add(new RouterPropsInfo("URL", false));
/* 103 */     properties.add(new RouterPropsInfo("NAMESPACE_ID", false));
/* 104 */     properties.add(new RouterPropsInfo("PROJECT_BASE_DIR", false));
/* 105 */     properties.add(new RouterPropsInfo("DATA_SOURCE_NAME", false));
/* 106 */     properties.add(new RouterPropsInfo("USERNAME", false));
/* 107 */     properties.add(new RouterPropsInfo("PASSWORD", true));
/*     */   }
/*     */ }
