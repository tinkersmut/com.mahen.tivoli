/*    */ package com.ibm.tivoli.maximo.report.cognos.metadata.exception;
/*    */ 
/*    */ import psdi.util.MXSystemException;
/*    */ 





























/*    */ public class CognosHandlerException extends MXSystemException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public CognosHandlerException(String errorKey, Throwable throwable)
/*    */   {
/* 40 */     super("iface", errorKey, throwable);
/*    */   }







/*    */   public CognosHandlerException(String errorKey)
/*    */   {
/* 51 */     super("iface", errorKey);
/*    */   }
/*    */ }
