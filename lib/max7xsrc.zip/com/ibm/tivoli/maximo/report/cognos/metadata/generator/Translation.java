/*    */ package com.ibm.tivoli.maximo.report.cognos.metadata.generator;
/*    */ 


























/*    */ public class Translation
/*    */ {
/* 26 */   private String language = "";
/* 27 */   private String value = "";
/*    */ 
/*    */   public Translation(String language, String value)
/*    */   {
/* 36 */     this.language = language.toLowerCase();
/* 37 */     this.value = value;
/*    */   }




/*    */   public Translation(String language)
/*    */   {
/* 45 */     this.language = language.toLowerCase();
/*    */   }




/*    */   public String getLanguage()
/*    */   {
/* 53 */     return this.language;
/*    */   }



/*    */   public String getValue()
/*    */   {
/* 60 */     return this.value;
/*    */   }




/*    */   public void setLanguage(String language)
/*    */   {
/* 68 */     this.language = language.toLowerCase();
/*    */   }



/*    */   public void setValue(String value)
/*    */   {
/* 75 */     this.value = value;
/*    */   }
/*    */ }
