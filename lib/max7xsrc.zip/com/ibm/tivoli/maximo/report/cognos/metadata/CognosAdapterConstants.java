package com.ibm.tivoli.maximo.report.cognos.metadata;

public abstract interface CognosAdapterConstants
{
  public static final String COGNOS_DATA_SOURCE_NAME_PLACE_HOLDER = "##COGNOS_DATA_SOURCE_NAME##";
  public static final String COGNOS_CONTENT_STORE_PACKAGE_LOCATION_PLACE_HOLDER = "##COGNOS_CONTENT_STORE_PACKAGE_LOCATION##";
}
