/*    */ package com.ibm.tivoli.maximo.report.cognos.metadata.util;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ import psdi.iface.mic.MicUtil;
/*    */ import psdi.util.logging.MXLogger;
/*    */ 




















/*    */ public class ActionLogUtil
/*    */ {
/*    */   public static String getContentStorePackageLocation(String contentStorePackageLocation)
/*    */   {
/* 31 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 32 */       MicUtil.INTEGRATIONLOGGER.debug("ActionLogUtil: content store package location: " + contentStorePackageLocation + "...");
/*    */     }
/*    */ 
/* 35 */     if ((contentStorePackageLocation == null) || ("".equals(contentStorePackageLocation))) {
/* 36 */       if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 37 */         MicUtil.INTEGRATIONLOGGER.debug("ActionLogUtil: no content store package location specified. The package will be published in the public folders ...");
/*    */       }
/*    */ 
/* 40 */       return "";
/*    */     }
/*    */ 
/* 43 */     String cognosContentStorePackageLocation = "";
/* 44 */     StringTokenizer st = new StringTokenizer(contentStorePackageLocation, "/ \\");
/* 45 */     while (st.hasMoreTokens()) {
/* 46 */       String folder = st.nextToken();
/* 47 */       cognosContentStorePackageLocation = cognosContentStorePackageLocation + "/folder[@name=&apos;" + folder + "&apos;]";
/*    */     }
/* 49 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 50 */       MicUtil.INTEGRATIONLOGGER.debug("ActionLogUtil: cognos content store package location: " + cognosContentStorePackageLocation + "...");
/*    */     }
/*    */ 
/* 53 */     return cognosContentStorePackageLocation;
/*    */   }
/*    */ }
