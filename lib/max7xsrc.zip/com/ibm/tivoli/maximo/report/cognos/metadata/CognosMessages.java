package com.ibm.tivoli.maximo.report.cognos.metadata;

public abstract interface CognosMessages
{
  public static final String MSG_KEY_COGNOS_TRANSFORM_FAILURE = "cognos_transform_failed";
  public static final String MSG_KEY_COGNOS_PUBLISH_FAILURE = "cognos_publish_failed";
  public static final String MSG_KEY_NOT_SUPPORTED_COMPLEX_EXPRESSION = "cognos_not_supported_complex_expression";
  public static final String MSG_KEY_COGNOS_URL_PROBLEM = "cognos_url_problem";
  public static final String MSG_KEY_COGNOS_CONNECTION_PROBLEM = "cognos_connection_problem";
  public static final String MSG_KEY_COGNOS_LOGON_FAILURE = "cognos_logon_failure";
  public static final String MSG_KEY_PUBLISH_SUCCEEDED = "cognos_publish_succeeded";
  public static final String MSG_GROUP = "iface";
}
