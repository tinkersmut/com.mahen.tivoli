/*    */ package com.ibm.tivoli.maximo.report.cognos.metadata.exception;
/*    */ 
/*    */ import psdi.util.MXApplicationException;
/*    */ 





























/*    */ public class CognosTransformationException extends MXApplicationException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public CognosTransformationException(String errorKey, Throwable throwable)
/*    */   {
/* 40 */     super("iface", errorKey, throwable);
/*    */   }







/*    */   public CognosTransformationException(String errorKey)
/*    */   {
/* 51 */     super("iface", errorKey);
/*    */   }










/*    */   public CognosTransformationException(String errorKey, Object[] params)
/*    */   {
/* 65 */     super("iface", errorKey, params);
/*    */   }
/*    */ }
