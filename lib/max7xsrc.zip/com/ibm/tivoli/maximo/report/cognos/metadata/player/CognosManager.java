/*     */ package com.ibm.tivoli.maximo.report.cognos.metadata.player;
/*     */ 
/*     */ import com.cognos.developer.schemas.bibus._3.BaseClass;
/*     */ import com.cognos.developer.schemas.bibus._3.BiBusHeader;
/*     */ import com.cognos.developer.schemas.bibus._3.ContentManagerService_Port;
/*     */ import com.cognos.developer.schemas.bibus._3.ContentManagerService_ServiceLocator;
/*     */ import com.cognos.developer.schemas.bibus._3.MetadataService_Port;
/*     */ import com.cognos.developer.schemas.bibus._3.MetadataService_ServiceLocator;
/*     */ import com.cognos.developer.schemas.bibus._3.PropEnum;
/*     */ import com.cognos.developer.schemas.bibus._3.QueryOptions;
/*     */ import com.cognos.developer.schemas.bibus._3.SearchPathMultipleObject;
/*     */ import com.cognos.developer.schemas.bibus._3.SearchPathSingleObject;
/*     */ import com.cognos.developer.schemas.bibus._3.Sort;
/*     */ import com.cognos.developer.schemas.bibus._3.XmlEncodedXML;
/*     */ import com.cognos.org.apache.axis.client.Stub;
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.exception.CognosHandlerException;
/*     */ import com.ibm.tivoli.maximo.report.cognos.metadata.util.XMLElement;
/*     */ import java.io.StringReader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 







































/*     */ public class CognosManager
/*     */ {
/*  49 */   private MetadataService_Port metadataService = null;
/*  50 */   private ContentManagerService_Port cmService = null;
/*     */ 
/*     */   public CognosManager(String url, String namespaeId, String userName, String password)
/*     */     throws CognosHandlerException
/*     */   {
/*  73 */     connectToCognosServer(url);
/*  74 */     if ((userName == null) || ("".equals(userName)))
/*  75 */       doTestForAnonymous();
/*     */     else {
/*  77 */       logon(namespaeId, userName, password);
/*     */     }
/*  79 */     initializeMetadataService();
/*     */   }







/*     */   private void connectToCognosServer(String url)
/*     */     throws CognosHandlerException
/*     */   {
/*  91 */     long time = 0L;
/*  92 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/*  93 */       time = System.currentTimeMillis();
/*  94 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: Connecting to Cognos Server  " + url + " ...");
/*     */     }
/*  96 */     MetadataService_ServiceLocator metadataServiceLocator = new MetadataService_ServiceLocator();
/*  97 */     ContentManagerService_ServiceLocator cmServiceLocator = new ContentManagerService_ServiceLocator();
/*     */     try
/*     */     {
/* 100 */       URL serverURL = new URL(url);
/* 101 */       this.metadataService = metadataServiceLocator.getmetadataService(serverURL);
/* 102 */       this.cmService = cmServiceLocator.getcontentManagerService(serverURL);
/*     */     } catch (MalformedURLException e) {
/* 104 */       MicUtil.INTEGRATIONLOGGER.error("connectToCognosServer: Error occured during parsing the cognos url: " + url + "...", e);

/*     */ 
/* 107 */       throw new CognosHandlerException("cognos_url_problem", e);
/*     */     } catch (ServiceException e) {
/* 109 */       MicUtil.INTEGRATIONLOGGER.error("connectToCognosServer: Error occured connecting to Cognos server using url: " + url + ". Please make sure the url is correct and the Cognos Server is up and running...", e);

/*     */ 
/* 112 */       throw new CognosHandlerException("cognos_connection_problem", e);
/*     */     }
/*     */ 
/* 115 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 116 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: Connected to Cognos Server  " + url + " in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }













/*     */   private void logon(String namespaceId, String userName, String password)
/*     */     throws CognosHandlerException
/*     */   {
/* 134 */     long time = 0L;
/* 135 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 136 */       time = System.currentTimeMillis();
/* 137 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: trying to logon to Cognos Server with namespace id  " + namespaceId + ", username " + userName + " ...");
/*     */     }
/*     */ 
/* 140 */     StringBuffer credentialXML = new StringBuffer();
/*     */ 
/* 142 */     credentialXML.append("<credential>");
/* 143 */     credentialXML.append("<namespace>");
/* 144 */     credentialXML.append(namespaceId);
/* 145 */     credentialXML.append("</namespace>");
/* 146 */     credentialXML.append("<username>");
/* 147 */     credentialXML.append(userName);
/* 148 */     credentialXML.append("</username>");
/* 149 */     credentialXML.append("<password>");
/* 150 */     credentialXML.append(password);
/* 151 */     credentialXML.append("</password>");
/* 152 */     credentialXML.append("</credential>");
/*     */     try
/*     */     {
/* 155 */       this.cmService.logon(new XmlEncodedXML(credentialXML.toString()), new SearchPathSingleObject[0]);
/*     */     } catch (RemoteException e) {
/* 157 */       MicUtil.INTEGRATIONLOGGER.error("logon: Error occured during logon to Cognos server using namespace id " + namespaceId + " and username: " + userName + ". Please make sure the URL and the credentials are correct...", e);


/*     */ 
/* 161 */       throw new CognosHandlerException("cognos_connection_problem", e);
/*     */     }
/* 163 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 164 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: logon successfully to Cognos Server with namespace id  " + namespaceId + ", username " + userName + " in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }






/*     */   private void initializeMetadataService()
/*     */   {
/* 174 */     BiBusHeader cmbibus = (BiBusHeader)((Stub)this.cmService).getHeaderObject("", "biBusHeader");
/* 175 */     ((Stub)this.metadataService).setHeader("", "biBusHeader", cmbibus);

/*     */ 
/* 178 */     ((Stub)this.cmService).setTimeout(0);
/* 179 */     ((Stub)this.metadataService).setTimeout(0);
/*     */   }





/*     */   private void doTestForAnonymous()
/*     */     throws CognosHandlerException
/*     */   {
/*     */     try
/*     */     {
/* 191 */       BaseClass[] bc = this.cmService.query(new SearchPathMultipleObject("/"), new PropEnum[0], new Sort[0], new QueryOptions());
/*     */ 
/* 193 */       if (bc != null) {
/* 194 */         if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 195 */           MicUtil.INTEGRATIONLOGGER.debug("CognosManager: anonymous access is enabled ...");
/*     */       }
/*     */       else {
/* 198 */         MicUtil.INTEGRATIONLOGGER.error("logon: Anonymous user logon is not enabled on the Cognos server ... ");
/* 199 */         throw new CognosHandlerException("cognos_logon_failure");
/*     */       }
/*     */     } catch (RemoteException e) {
/* 202 */       MicUtil.INTEGRATIONLOGGER.error("logon: Anonymous user logon is not enabled on the Cognos server ... ", e);
/* 203 */       throw new CognosHandlerException("cognos_logon_failure", e);
/*     */     }
/*     */   }








/*     */   public void createModel(String projectLocation)
/*     */     throws CognosHandlerException
/*     */   {
/* 217 */     long time = 0L;
/* 218 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 219 */       time = System.currentTimeMillis();
/* 220 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: Creating Framework Manager Project in " + projectLocation + " ...");
/*     */     }
/* 222 */     updateMetadata("<mdprovider type=\"generic\" action=\"createModel\" model=\"" + projectLocation + "\"/>");
/*     */ 
/* 224 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 225 */       MicUtil.INTEGRATIONLOGGER.debug("Project created in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }








/*     */   public void openModel(String projectLocation)
/*     */     throws CognosHandlerException
/*     */   {
/* 238 */     long time = 0L;
/* 239 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 240 */       time = System.currentTimeMillis();
/* 241 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: Opening Framework Manager Project in " + projectLocation + " ...");
/*     */     }
/* 243 */     updateMetadata("<mdprovider type=\"generic\" action=\"openModel\" model=\"" + projectLocation + "\"/>");
/*     */ 
/* 245 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 246 */       MicUtil.INTEGRATIONLOGGER.debug("Project opened in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }








/*     */   public void saveModel(String projectLocation)
/*     */     throws CognosHandlerException
/*     */   {
/* 259 */     long time = 0L;
/* 260 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 261 */       time = System.currentTimeMillis();
/* 262 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: Saving Framework Manager Project in " + projectLocation + " ...");
/*     */     }
/* 264 */     updateMetadata("<mdprovider type=\"generic\" action=\"saveModel\" model=\"" + projectLocation + "\"/>");
/*     */ 
/* 266 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 267 */       MicUtil.INTEGRATIONLOGGER.debug("Project saved in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }








/*     */   public void closeModel(String projectLocation)
/*     */     throws CognosHandlerException
/*     */   {
/* 280 */     long time = 0L;
/* 281 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 282 */       time = System.currentTimeMillis();
/* 283 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: Closing Framework Manager Project in " + projectLocation + " ...");
/*     */     }
/* 285 */     updateMetadata("<mdprovider type=\"generic\" action=\"closeModel\" model=\"" + projectLocation + "\"/>");
/*     */ 
/* 287 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 288 */       MicUtil.INTEGRATIONLOGGER.debug("Project closed in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }











/*     */   public void executeTransaction(String projectLocation, String transaction)
/*     */     throws CognosHandlerException
/*     */   {
/* 304 */     long time = 0L;
/* 305 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled()) {
/* 306 */       time = System.currentTimeMillis();
/* 307 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: Executing transaction in " + projectLocation + " ...");
/*     */     }
/* 309 */     updateMetadata("<mdprovider type=\"action\" action=\"execute\" model=\"" + projectLocation + "\">" + transaction + "</mdprovider>");

/*     */ 
/* 312 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 313 */       MicUtil.INTEGRATIONLOGGER.debug("Transaction executed in " + (System.currentTimeMillis() - time) + " ms ...");
/*     */   }








/*     */   private void updateMetadata(String metaData)
/*     */     throws CognosHandlerException
/*     */   {
/* 326 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 327 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: start update metadata with request " + metaData);
/*     */     String response;
/*     */     try
/*     */     {
/* 331 */       response = this.metadataService.updateMetadata(new XmlEncodedXML(metaData)).toString();
/*     */     } catch (RemoteException e) {
/* 333 */       MicUtil.INTEGRATIONLOGGER.error("updateMetadata: Error occured during updating metadata: " + metaData + " ...", e);
/* 334 */       throw new CognosHandlerException("cognos_publish_failed", e);
/*     */     }
/* 336 */     if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
/* 337 */       MicUtil.INTEGRATIONLOGGER.debug("CognosManager: update metadata request completed with response: " + response);
/*     */     try
/*     */     {
/* 340 */       XMLElement responseElement = XMLElement.parse(new StringReader(response));
/* 341 */       String status = responseElement.getChild("status").getAttribute("success");
/* 342 */       boolean success = Boolean.parseBoolean(status);
/* 343 */       if (!(success)) {
/* 344 */         MicUtil.INTEGRATIONLOGGER.error("updateMetadata: Error occured during updating metadata: " + metaData + " ...");
/* 345 */         throw new CognosHandlerException("cognos_publish_failed");
/*     */       }
/*     */     } catch (Exception e) {
/* 348 */       MicUtil.INTEGRATIONLOGGER.error("CognosManager: Couldn't parse response: " + response, e);
/*     */     }
/*     */   }
/*     */ }
