package com.ibm.tivoli.maximo.report.cognos.metadata.generator;

public abstract interface DatabaseTypes
{
  public static final String ORACLE = "OR";
  public static final String DB2 = "DB2";
  public static final String SQL_SERVER = "SS";
}
