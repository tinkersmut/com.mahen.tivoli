/*     */ package com.ibm.tivoli.maximo.report.cognos.metadata.util;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.xpath.XPath;
/*     */ import javax.xml.xpath.XPathConstants;
/*     */ import javax.xml.xpath.XPathException;
/*     */ import javax.xml.xpath.XPathFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 





















/*     */ public class XMLElement
/*     */ {
/*     */   private Element fElement;
/*     */ 
/*     */   public static XMLElement parse(Reader in)
/*     */     throws Exception
/*     */   {
/*  54 */     return parse(new InputSource(in));
/*     */   }







/*     */   public static XMLElement parse(InputStream in)
/*     */     throws Exception
/*     */   {
/*  66 */     return parse(new InputSource(in));
/*     */   }








/*     */   public static XMLElement parse(InputSource in)
/*     */     throws Exception
/*     */   {
/*  79 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

/*     */ 
/*  82 */     factory.setValidating(false);
/*  83 */     factory.setNamespaceAware(false);
/*     */ 
/*  85 */     DocumentBuilder builder = factory.newDocumentBuilder();
/*  86 */     Document doc = builder.parse(in);
/*     */ 
/*  88 */     return new XMLElement(doc.getDocumentElement());
/*     */   }


/*     */   private XMLElement(Element element)
/*     */   {
/*  94 */     this.fElement = element;
/*     */   }










/*     */   public XMLElement getChild(String name)
/*     */   {
/* 108 */     if (name == null) return null;
/* 109 */     NodeList nodeList = this.fElement.getElementsByTagName(name);
/* 110 */     return ((nodeList.getLength() > 0) ? new XMLElement((Element)nodeList.item(0)) : null);
/*     */   }







/*     */   public List<XMLElement> getChildren()
/*     */   {
/* 121 */     return getChildren("*");
/*     */   }








/*     */   public List<XMLElement> getChildren(String name)
/*     */   {
/* 133 */     List childNodes = new ArrayList();
/* 134 */     if (name == null) return childNodes;
/*     */ 
/* 136 */     NodeList nodeList = this.fElement.getElementsByTagName(name);
/* 137 */     int count = nodeList.getLength();
/* 138 */     for (int i = 0; i < count; ++i) {
/* 139 */       Element e = (Element)nodeList.item(i);
/* 140 */       if (e.getParentNode() == this.fElement) {
/* 141 */         childNodes.add(new XMLElement(e));
/*     */       }
/*     */     }
/* 144 */     return childNodes;
/*     */   }

/*     */   public List<XMLElement> find(String query) throws XPathException {
/* 148 */     List childNodes = new ArrayList();
/*     */ 
/* 150 */     XPath xPath = XPathFactory.newInstance().newXPath();
/*     */ 
/* 152 */     NodeList nodeList = (NodeList)xPath.evaluate(query, this.fElement, XPathConstants.NODESET);
/* 153 */     int count = nodeList.getLength();
/* 154 */     for (int i = 0; i < count; ++i) {
/* 155 */       childNodes.add(new XMLElement((Element)nodeList.item(i)));
/*     */     }
/* 157 */     return childNodes;
/*     */   }

/*     */   public XMLElement findElement(String query) throws XPathException {
/* 161 */     XPath xPath = XPathFactory.newInstance().newXPath();
/*     */ 
/* 163 */     Node result = (Node)xPath.evaluate(query, this.fElement, XPathConstants.NODE);
/* 164 */     return ((result != null) ? new XMLElement((Element)result) : null);
/*     */   }








/*     */   public String getAttribute(String attrName)
/*     */   {
/* 176 */     String value = this.fElement.getAttribute(attrName);
/* 177 */     return (((value != null) && (value.length() == 0)) ? null : value);
/*     */   }








/*     */   public String getChildValue(String childName)
/*     */   {
/* 189 */     XMLElement childNode = getChild(childName);
/* 190 */     return ((childNode != null) ? childNode.fElement.getTextContent() : null);
/*     */   }

/*     */   public String getName() {
/* 194 */     return this.fElement.getTagName();
/*     */   }

/*     */   public String getXML() throws TransformerException, TransformerConfigurationException {
/* 198 */     Transformer transformer = TransformerFactory.newInstance().newTransformer();
/* 199 */     transformer.setOutputProperty("omit-xml-declaration", "yes");
/* 200 */     transformer.setOutputProperty("indent", "no");

/*     */ 
/* 203 */     StringWriter result = new StringWriter();
/* 204 */     transformer.transform(new DOMSource(this.fElement), new StreamResult(result));
/* 205 */     return result.toString();
/*     */   }
/*     */ }
