/*    */ package com.ibm.tivoli.maximo.report.cognos.metadata.generator;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 















/*    */ public class Expression
/*    */ {
/*    */   List<String> leftColumns;
/*    */   List<String> rightColumns;
/*    */ 
/*    */   public Expression()
/*    */   {
/* 28 */     this.leftColumns = new ArrayList();
/* 29 */     this.rightColumns = new ArrayList(); }

/*    */   public List<String> getLeftColumns() {
/* 32 */     return this.leftColumns;
/*    */   }

/*    */   public void addLeftColumn(String leftColumn) {
/* 36 */     this.leftColumns.add(leftColumn);
/*    */   }

/*    */   public List<String> getRightColumns() {
/* 40 */     return this.rightColumns;
/*    */   }

/*    */   public void addRightColumn(String rightColumn) {
/* 44 */     this.rightColumns.add(rightColumn);
/*    */   }
/*    */ }
