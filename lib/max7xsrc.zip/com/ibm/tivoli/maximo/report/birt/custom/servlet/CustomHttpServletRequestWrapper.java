/*    */ package com.ibm.tivoli.maximo.report.birt.custom.servlet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.servlet.ReportRequestWrapper;
/*    */ import java.util.HashMap;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
















/*    */ public class CustomHttpServletRequestWrapper extends ReportRequestWrapper
/*    */ {
/* 32 */   String qString = null;
/*    */ 
/*    */   public CustomHttpServletRequestWrapper(HttpServletRequest request, HashMap additionalParams)
/*    */   {
/* 29 */     super(request, additionalParams);
/*    */   }


/*    */   public void setXQueryString(String qString)
/*    */   {
/* 35 */     this.qString = qString;
/*    */   }



/*    */   public String getQueryString()
/*    */   {
/* 42 */     String qStr = super.getQueryString();
/* 43 */     if (qStr == null)
/*    */     {
/* 45 */       return this.qString;
/*    */     }
/*    */ 
/* 48 */     return qStr;
/*    */   }
/*    */ }
