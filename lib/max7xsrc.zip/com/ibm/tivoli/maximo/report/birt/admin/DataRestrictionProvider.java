package com.ibm.tivoli.maximo.report.birt.admin;

import java.rmi.RemoteException;
import psdi.util.MXException;

public abstract interface DataRestrictionProvider
{
  public abstract String getDataRestrictionWhere()
    throws MXException, RemoteException;
}
