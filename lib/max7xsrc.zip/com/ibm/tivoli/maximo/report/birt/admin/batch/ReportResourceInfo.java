/*    */ package com.ibm.tivoli.maximo.report.birt.admin.batch;
/*    */ 












/*    */ public class ReportResourceInfo
/*    */ {
/*    */   private String reference;
/*    */   private String fileName;
/*    */ 
/*    */   public ReportResourceInfo()
/*    */   {
/* 22 */     this.reference = null;
/* 23 */     this.fileName = null;
/*    */   }

/*    */   public String getFileName() {
/* 27 */     return this.fileName;
/*    */   }

/*    */   public void setFileName(String fileName)
/*    */   {
/* 32 */     this.fileName = fileName;
/*    */   }

/*    */   public String getReference()
/*    */   {
/* 37 */     return this.reference;
/*    */   }

/*    */   public void setReference(String reference)
/*    */   {
/* 42 */     this.reference = reference;
/*    */   }
/*    */ }
