/*     */ package com.ibm.tivoli.maximo.report.birt.admin;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 





/*     */ public class ReportUsageLogInfo
/*     */   implements Serializable
/*     */ {
/*     */   private String appName;
/*     */   private String reportName;
/*     */   private Date enterDate;
/*     */   private Date startDate;
/*     */   private Date endDate;
/*     */   private boolean immediateJob;
/*     */   private boolean transientReport;
/*     */   private long runtime;
/*     */   private boolean success;
/*     */   private String userId;
/*     */   private String hostName;
/*     */   private String serverName;
/*     */   private boolean reportExecuted;
/*     */   private boolean cancelled;
/*     */   private String emailFileType;
/*     */ 
/*     */   public ReportUsageLogInfo()
/*     */   {
/*  32 */     this.success = true;


/*     */ 
/*  36 */     this.reportExecuted = false;
/*  37 */     this.cancelled = false;
/*  38 */     this.emailFileType = null;
/*     */   }

/*     */   public String getAppName() {
/*  42 */     return this.appName;
/*     */   }

/*     */   public void setAppName(String appName)
/*     */   {
/*  47 */     this.appName = appName;
/*     */   }

/*     */   public Date getEndDate()
/*     */   {
/*  52 */     return this.endDate;
/*     */   }

/*     */   public void setEndDate(Date endDate)
/*     */   {
/*  57 */     this.endDate = endDate;
/*     */   }

/*     */   public Date getEnterDate()
/*     */   {
/*  62 */     return this.enterDate;
/*     */   }

/*     */   public void setEnterDate(Date enterDate)
/*     */   {
/*  67 */     this.enterDate = enterDate;
/*     */   }

/*     */   public String getHostName()
/*     */   {
/*  72 */     return this.hostName;
/*     */   }

/*     */   public void setHostName(String hostName)
/*     */   {
/*  77 */     this.hostName = hostName;
/*     */   }

/*     */   public boolean isImmediateJob()
/*     */   {
/*  82 */     return this.immediateJob;
/*     */   }

/*     */   public void setImmediateJob(boolean immediateJob)
/*     */   {
/*  87 */     this.immediateJob = immediateJob;
/*     */   }

/*     */   public boolean isTransientReport()
/*     */   {
/*  92 */     return this.transientReport;
/*     */   }

/*     */   public void setTransientReport(boolean isTransientReport)
/*     */   {
/*  97 */     this.transientReport = isTransientReport;
/*     */   }

/*     */   public String getReportName()
/*     */   {
/* 102 */     return this.reportName;
/*     */   }

/*     */   public void setReportName(String reportName)
/*     */   {
/* 107 */     this.reportName = reportName;
/*     */   }

/*     */   public long getRuntime()
/*     */   {
/* 112 */     return this.runtime;
/*     */   }

/*     */   public void setRuntime(long runtime)
/*     */   {
/* 117 */     this.runtime = runtime;
/*     */   }

/*     */   public String getServerName()
/*     */   {
/* 122 */     return this.serverName;
/*     */   }

/*     */   public void setServerName(String serverName)
/*     */   {
/* 127 */     this.serverName = serverName;
/*     */   }

/*     */   public Date getStartDate()
/*     */   {
/* 132 */     return this.startDate;
/*     */   }

/*     */   public void setStartDate(Date startDate)
/*     */   {
/* 137 */     this.startDate = startDate;
/*     */   }

/*     */   public boolean isSuccess()
/*     */   {
/* 142 */     return this.success;
/*     */   }

/*     */   public void setSuccess(boolean success)
/*     */   {
/* 147 */     this.success = success;
/*     */   }

/*     */   public String getUserId()
/*     */   {
/* 152 */     return this.userId;
/*     */   }

/*     */   public void setUserId(String userId)
/*     */   {
/* 157 */     this.userId = userId;
/*     */   }

/*     */   public boolean isReportExecuted()
/*     */   {
/* 162 */     return this.reportExecuted;
/*     */   }

/*     */   public void setReportExecuted(boolean reportExecuted)
/*     */   {
/* 167 */     this.reportExecuted = reportExecuted;
/*     */   }

/*     */   public boolean isCancelled()
/*     */   {
/* 172 */     return this.cancelled;
/*     */   }

/*     */   public void setCancelled(boolean cancelled)
/*     */   {
/* 177 */     this.cancelled = cancelled;
/*     */   }

/*     */   public void setEmailFileType(String emailFileType)
/*     */   {
/* 182 */     this.emailFileType = emailFileType;
/*     */   }

/*     */   public String getEmailFileType()
/*     */   {
/* 187 */     return this.emailFileType;
/*     */   }
/*     */ }
