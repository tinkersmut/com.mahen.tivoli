/*    */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*    */ 
/*    */ import java.io.File;
/*    */ 


























/*    */ public class ReportRuntimeTempLocation
/*    */ {
/*    */   private static final String TEMP_REPORTFOLDER = "reports";
/*    */   private static final String TEMP_IMAGESFOLDER = "images";
/*    */   private static final String TEMP_LOGSFOLDER = "logs";
/*    */   private static final String TEMP_RESOURCESFOLDER = "resources";
/*    */   private static final String TEMP_SCRIPTSLIBFOLDER = "scripts";
/* 32 */   private static String location = null;
/* 33 */   private static String reportsLocation = null;
/* 34 */   private static String imagesLocation = null;
/* 35 */   private static String logsLocation = null;
/* 36 */   private static String resourcesLocation = null;
/* 37 */   private static String scriptsLibLocation = null;
/*    */ 
/*    */   public static void setReportRuntimeTempLocation(String loc)
/*    */   {
/* 47 */     location = loc;
/* 48 */     reportsLocation = createSubFolder("reports");
/* 49 */     imagesLocation = createSubFolder("images");
/* 50 */     logsLocation = createSubFolder("logs");
/* 51 */     resourcesLocation = createSubFolder("resources");
/* 52 */     scriptsLibLocation = createSubFolder("scripts");
/*    */   }

/*    */   private static String createSubFolder(String folderName)
/*    */   {
/* 57 */     String folder = location + File.separator + folderName;
/* 58 */     File fDir = new File(folder);
/* 59 */     if (!(fDir.exists()))
/*    */     {
/* 61 */       fDir.mkdirs();
/*    */     }
/*    */ 
/* 64 */     return folder;
/*    */   }

/*    */   public static String getReportsLocation()
/*    */   {
/* 69 */     return reportsLocation;
/*    */   }

/*    */   public static String getImagesLocation()
/*    */   {
/* 74 */     return imagesLocation;
/*    */   }

/*    */   public static String getLogsLocation()
/*    */   {
/* 79 */     return logsLocation;
/*    */   }

/*    */   public static String getResourcesLocation()
/*    */   {
/* 84 */     return resourcesLocation;
/*    */   }

/*    */   public static String getScriptsLibLocation()
/*    */   {
/* 89 */     return scriptsLibLocation;
/*    */   }
/*    */ }
