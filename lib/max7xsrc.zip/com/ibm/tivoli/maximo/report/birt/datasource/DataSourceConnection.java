package com.ibm.tivoli.maximo.report.birt.datasource;

import java.sql.Connection;

public abstract interface DataSourceConnection
{
  public abstract Connection getConnection();
}
