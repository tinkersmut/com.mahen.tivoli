/*    */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.engine.MXReportEngine;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ 













/*    */ public class ReportEngineStartupServlet extends HttpServlet
/*    */ {
/*    */   private MXReportEngine reportEngine;
/*    */ 
/*    */   public ReportEngineStartupServlet()
/*    */   {
/* 27 */     this.reportEngine = null;
/*    */   }

/*    */   public void init(ServletConfig config) throws ServletException {
/* 31 */     super.init(config);
/*    */ 
/* 33 */     this.reportEngine = MXReportEngine.getReportEngine();
/*    */   }

/*    */   public void destroy()
/*    */   {
/* 38 */     if (this.reportEngine == null)
/*    */       return;
/* 40 */     this.reportEngine.stop();
/*    */   }
/*    */ }
