/*     */ package com.ibm.tivoli.maximo.report.birt.servlet.tool;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminServiceRemote;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportImportInfo;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.webclient.system.websession.WebAppSessionProvider;
/*     */ 





















/*     */ public class ReportToolServlet extends HttpServlet
/*     */ {
/*     */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  48 */     InputStream is = request.getInputStream();
/*  49 */     ObjectInputStream dis = new ObjectInputStream(is);
/*     */ 
/*  51 */     String operationName = null;
/*  52 */     Object[] parameters = null;
/*  53 */     MXSession mxSession = null;



/*     */     try
/*     */     {
/*  59 */       String userName = dis.readUTF();
/*  60 */       String password = dis.readUTF();
/*  61 */       operationName = dis.readUTF();
/*  62 */       parameters = (Object[])(Object[])dis.readObject();




/*     */       try
/*     */       {
/*  69 */         mxSession = WebAppSessionProvider.getNewWebAppSession();
/*  70 */         mxSession.setUserName(userName);
/*  71 */         mxSession.setPassword(password);
/*  72 */         mxSession.connect();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  76 */         String servletName = getServletConfig().getServletName();
/*     */ 
/*  78 */         if (e instanceof MXException)
/*     */         {
/*  80 */           throw e;
/*     */         }
/*     */ 
/*  83 */         throw new Exception(servletName + ": Failed to Initialize Session" + e.getMessage());
/*     */       }
/*     */ 
/*  86 */       Object returnVal = performOperation(mxSession, operationName, parameters);
/*     */ 
/*  88 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  89 */       ObjectOutputStream dos = new ObjectOutputStream(bos);
/*  90 */       dos.writeInt(1);
/*  91 */       dos.writeInt((returnVal == null) ? 0 : 1);
/*  92 */       if (returnVal != null)
/*     */       {
/*  94 */         dos.writeObject(returnVal);
/*     */       }
/*  96 */       dos.flush();
/*  97 */       bos.flush();

/*     */ 
/* 100 */       response.setContentType("application/octet-stream");
/*     */ 
/* 102 */       ObjectOutputStream respDos = new ObjectOutputStream(response.getOutputStream());
/* 103 */       respDos.writeInt(1);
/* 104 */       respDos.writeInt((returnVal == null) ? 0 : 1);
/* 105 */       if (returnVal != null)
/*     */       {
/* 107 */         respDos.writeObject(returnVal);
/*     */       }
/* 109 */       respDos.flush();
/*     */     }
/*     */     catch (MXException ex)
/*     */     {
/* 113 */       String exceptionMessage = ex.getMessage();
/* 114 */       writeException(exceptionMessage, response);


/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*     */       String servletName;
/* 124 */       if (mxSession != null)
/*     */         try
/*     */         {
/*     */ /* 127 */           mxSession.disconnect();/*     */         }/*     */         catch (Throwable t)/*     */         {/*     */         }/*     */     }/*     */   }
/* 128 */       return;






/*     */   protected Object performOperation(MXSession mxSession, String operationName, Object[] parameters) throws Exception {
/* 136 */     if (operationName != null)
/*     */     {
/* 138 */       if (operationName.equalsIgnoreCase("importreport"))
/*     */       {
/* 140 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 141 */         reportAdminService.importReport(mxSession.getUserInfo(), (ReportImportInfo)parameters[0], false);
/* 142 */         return null;
/*     */       }
/* 144 */       if (operationName.equalsIgnoreCase("importReportLibrary"))
/*     */       {
/* 146 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 147 */         reportAdminService.importReportLibrary(mxSession.getUserInfo(), (ReportImportInfo)parameters[0]);
/* 148 */         return null;
/*     */       }
/* 150 */       if (operationName.equalsIgnoreCase("getReportNameList"))
/*     */       {
/* 152 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 153 */         return reportAdminService.getReportNameList(mxSession.getUserInfo());
/*     */       }
/* 155 */       if (operationName.equalsIgnoreCase("getExportReportFolder"))
/*     */       {
/* 157 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 158 */         return reportAdminService.getExportReportFolder(mxSession.getUserInfo(), (String)parameters[0], (String)parameters[1]);
/*     */       }
/* 160 */       if (operationName.equalsIgnoreCase("exportReport"))
/*     */       {
/* 162 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 163 */         return reportAdminService.exportReport(mxSession.getUserInfo(), (String)parameters[0], (String)parameters[1]);
/*     */       }
/* 165 */       if (operationName.equalsIgnoreCase("exportReportLibrary"))
/*     */       {
/* 167 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 168 */         return reportAdminService.exportReportLibrary(mxSession.getUserInfo(), (String)parameters[0]);
/*     */       }
/* 170 */       if (operationName.equalsIgnoreCase("getReportLibraryNameList"))
/*     */       {
/* 172 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 173 */         return reportAdminService.getReportLibraryNameList(mxSession.getUserInfo());
/*     */       }
/* 175 */       if (operationName.equalsIgnoreCase("exportReportImportInputInfo"))
/*     */       {
/* 177 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 178 */         return reportAdminService.exportReportImportInputInfo(mxSession.getUserInfo(), (String)parameters[0], (String)parameters[1]);
/*     */       }
/* 180 */       if (operationName.equalsIgnoreCase("exportLibraryImportInputInfo"))
/*     */       {
/* 182 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 183 */         return reportAdminService.exportLibraryImportInputInfo(mxSession.getUserInfo(), (String)parameters[0]);
/*     */       }
/* 185 */       if (operationName.equalsIgnoreCase("updateReportDesign"))
/*     */       {
/* 187 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 188 */         return reportAdminService.updateReportDesign(mxSession.getUserInfo(), (String)parameters[0], (String)parameters[1], ((Boolean)parameters[2]).booleanValue());
/*     */       }
/*     */ 
/* 191 */       if (operationName.equalsIgnoreCase("getReportNameListOfType"))
/*     */       {
/* 193 */         ReportAdminServiceRemote reportAdminService = getReportAdminService(mxSession);
/* 194 */         return reportAdminService.getReportNameList(mxSession.getUserInfo(), ((Integer)parameters[0]).intValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 199 */     throw new MXApplicationException("reports", "failedtoextractreport", new Object[] { operationName });
/*     */   }

/*     */   protected ReportAdminServiceRemote getReportAdminService(MXSession mxSession)
/*     */     throws MXException, RemoteException
/*     */   {
/* 205 */     ReportAdminServiceRemote reportAdminService = (ReportAdminServiceRemote)mxSession.lookup("BIRTREPORT");
/* 206 */     return reportAdminService;
/*     */   }

/*     */   protected void writeException(String exceptionMessage, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 212 */     if (exceptionMessage == null)
/*     */       return;
/* 214 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 215 */     DataOutputStream dos = new DataOutputStream(bos);
/* 216 */     dos.writeInt(0);
/* 217 */     dos.writeUTF(exceptionMessage);
/* 218 */     dos.flush();
/* 219 */     bos.flush();
/*     */ 
/* 221 */     response.setContentType("application/octet-stream");
/*     */ 
/* 223 */     ObjectOutputStream respDos = new ObjectOutputStream(response.getOutputStream());
/*     */ 
/* 225 */     respDos.writeInt(0);
/* 226 */     respDos.writeUTF(exceptionMessage);
/* 227 */     respDos.flush();
/*     */   }
/*     */ }
