/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminService;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportRunInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.HashMap;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.util.MXSession;
/*     */ 









/*     */ public class ReportExtractProcessServlet extends HttpServlet
/*     */ {
/*     */   private ServletContext servletContext;
/*     */   private ReportLogger reportLogger;
/*     */   private String bridgeServletMapping;
/*     */ 
/*     */   public ReportExtractProcessServlet()
/*     */   {
/*  39 */     this.servletContext = null;
/*  40 */     this.reportLogger = null;
/*     */ 
/*  42 */     this.bridgeServletMapping = null;
/*     */   }

/*     */   public void init(ServletConfig config) throws ServletException {
/*  46 */     this.reportLogger = ReportLoggerFactory.getLogger("maximo.report.birt");
/*     */ 
/*  48 */     ReportViewerServletConfigAdaptor configAdapter = new ReportViewerServletConfigAdaptor(this, null, config.getServletContext());
/*     */ 
/*  50 */     super.init(configAdapter);
/*     */ 
/*  52 */     this.servletContext = configAdapter.getServletContext();
/*     */ 
/*  54 */     this.bridgeServletMapping = config.getInitParameter("bridgeservletmap");
/*  55 */     if (this.bridgeServletMapping == null)
/*     */     {
/*  57 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/*  59 */         this.reportLogger.error("ReportExtractProcessServlet init-param bridgeservletmap not defined.");
/*     */       }
/*  61 */       throw new ServletException("ReportExtractProcessServlet init-param bridgeservletmap not defined.");
/*     */     }
/*     */ 
/*  64 */     if (!(this.reportLogger.isDebugEnabled()))
/*     */       return;
/*  66 */     this.reportLogger.debug("ReportExtractProcessServlet using bridgeservletmap = " + this.bridgeServletMapping);
/*     */   }


/*     */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  73 */     processReportRequest(request, response);
/*     */   }

/*     */   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*     */   {
/*  78 */     processReportRequest(request, response);
/*     */   }


/*     */   protected void processReportRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  85 */     Object objSession = request.getSession().getAttribute("MXSession");
/*  86 */     Object objSessionReport = request.getSession().getAttribute("MXSessionReport");
/*  87 */     if ((((objSessionReport == null) || (!(((MXSession)objSessionReport).isConnected())))) && (((objSession == null) || (!(((MXSession)objSession).isConnected())))))


/*     */     {
/*  91 */       response.getWriter().write("Invalid request. The request must only come from maximo session.");
/*  92 */       response.sendError(401);
/*  93 */       return;
/*     */     }
/*     */ 
/*  96 */     MXSession session = (MXSession)objSession;
/*  97 */     if (session == null)
/*     */     {
/*  99 */       session = (MXSession)objSessionReport;

/*     */     }
/*     */ 
/* 103 */     if (!(session.isConnected()))
/*     */     {
/* 105 */       response.getWriter().write("Invalid request. The request must only come from maximo session.");
/* 106 */       response.sendError(401);
/* 107 */       return;
/*     */     }
/*     */ 
/* 110 */     String reportDesign = request.getParameter("__report");






/*     */ 
/* 118 */     int slashIndex = reportDesign.lastIndexOf("/");
/* 119 */     if (slashIndex >= 0)
/*     */     {
/* 121 */       reportDesign = reportDesign.substring(slashIndex + 1);
/*     */     }
/*     */     else
/*     */     {
/* 125 */       slashIndex = reportDesign.lastIndexOf("\\");
/* 126 */       if (slashIndex >= 0)
/*     */       {
/* 128 */         reportDesign = reportDesign.substring(slashIndex + 1);
/*     */       }
/*     */     }
/*     */ 
/* 132 */     String appName = request.getParameter("appname");
/*     */ 
/* 134 */     String requestId1 = request.getParameter("__requestid");
/* 135 */     String reportRunInfoKey = reportDesign + "_" + appName + "_" + requestId1;

/*     */ 
/* 138 */     if (!(isAuthorizedToRunReport(session, reportDesign, appName)))
/*     */     {
/* 140 */       response.getWriter().write("Unauthorized to run the report.");
/* 141 */       response.getWriter().flush();
/* 142 */       return;
/*     */     }
/*     */ 
/* 145 */     SessionReportRunInfo sessionReportRunInfo = (SessionReportRunInfo)request.getSession().getAttribute(reportRunInfoKey);
/* 146 */     if (sessionReportRunInfo == null)
/*     */     {
/* 148 */       response.getWriter().write("Invalid request. Report cannot be downloaded, as it is not executed.");
/* 149 */       response.getWriter().flush();
/* 150 */       return;
/*     */     }
/*     */ 
/* 153 */     ReportRunInfo reportRunInfo = sessionReportRunInfo.getReportRunInfo();
/*     */ 
/* 155 */     String reportOutputFolder = reportRunInfo.getReportOutputFolderName();

/*     */ 
/* 158 */     HashMap additionalParams = new HashMap();
/* 159 */     additionalParams.put("__report", new String[] { reportRunInfo.getReportRelativePath() + File.separator + reportDesign });
/*     */ 
/* 161 */     String reportName = reportDesign.substring(0, reportDesign.lastIndexOf("."));
/* 162 */     String reportDocument = reportName + ".rptdocument";
/*     */ 
/* 164 */     String docFileName = reportRunInfo.getTempRunFolder() + File.separator + reportOutputFolder + File.separator + reportDocument;
/* 165 */     additionalParams.put("__document", new String[] { docFileName });
/*     */ 
/* 167 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 169 */       this.reportLogger.debug("ReportExtractProcessServlet using document: " + docFileName);
/*     */     }
/*     */ 
/* 172 */     ReportRequestWrapper rw = new ReportRequestWrapper(request, additionalParams);
/* 173 */     this.servletContext.getRequestDispatcher(this.bridgeServletMapping + "extract").forward(rw, response);
/*     */   }

/*     */   protected boolean isAuthorizedToRunReport(MXSession session, String reportName, String appName)
/*     */     throws ServletException
/*     */   {
/*     */     try
/*     */     {
/* 181 */       UserInfo userInfo = session.getUserInfo();
/* 182 */       ReportAdminService reportService = (ReportAdminService)session.lookup("BIRTREPORT");
/*     */ 
/* 184 */       boolean authorized = reportService.isAuthorizedToRunReport(userInfo, reportName, appName);
/* 185 */       return authorized;

/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*     */     }
/*     */ 
/* 192 */     return false;
/*     */   }
/*     */ }
