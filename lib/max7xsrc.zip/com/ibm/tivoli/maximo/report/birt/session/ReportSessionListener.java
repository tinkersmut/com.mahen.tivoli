/*    */ package com.ibm.tivoli.maximo.report.birt.session;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.servlet.http.HttpSessionBindingEvent;
/*    */ import javax.servlet.http.HttpSessionBindingListener;
/*    */ import psdi.util.MXSession;
/*    */ 

















/*    */ public class ReportSessionListener
/*    */   implements HttpSessionBindingListener, Serializable
/*    */ {
/* 28 */   private MXSession mxSession = null;
/*    */ 
/*    */   public ReportSessionListener(MXSession mxSession)
/*    */   {
/* 32 */     this.mxSession = mxSession;
/*    */   }











/*    */   public void valueUnbound(HttpSessionBindingEvent arg0)
/*    */   {
/* 47 */     if (this.mxSession == null)
/*    */       return;
/*    */     try
/*    */     {
/* 51 */       this.mxSession.disconnect();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/*    */   }
/*    */ }
