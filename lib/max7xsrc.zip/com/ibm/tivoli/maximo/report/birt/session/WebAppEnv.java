/*     */ package com.ibm.tivoli.maximo.report.birt.session;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ 






























/*     */ public class WebAppEnv
/*     */ {
/*     */   private static final String ENV_USEAPPSERVERSECURITY = "useAppServerSecurity";
/*  40 */   private static final WebAppEnv webAppEnv = new WebAppEnv();
/*     */   private HashMap envEntries;
/*     */ 
/*     */   public WebAppEnv()
/*     */   {
/*  45 */     this.envEntries = new HashMap();
/*     */   }














/*     */   public static String getEnvEntryValue(String envEntryName)
/*     */   {
/*  63 */     String envEntryValue = webAppEnv.getValue(envEntryName);
/*     */ 
/*  65 */     if (envEntryValue == null)
/*     */     {
/*  67 */       InitialContext ctx = null;

/*     */       try
/*     */       {
/*  71 */         ctx = new InitialContext();
/*  72 */         envEntryValue = (String)ctx.lookup("java:comp/env/" + envEntryName);
/*  73 */         webAppEnv.putValue(envEntryName, envEntryValue);
/*     */       }
/*     */       catch (NamingException ex)
/*     */       {
/*     */       }
/*     */       finally
/*     */       {
/*     */         try {
/*  81 */           if (ctx != null) ctx.close();
/*     */         } catch (Exception ex) {
/*     */         }
/*     */       }
/*     */     }
/*  86 */     return envEntryValue;
/*     */   }








/*     */   public static boolean useAppServerSecurity()
/*     */   {
/*  98 */     boolean useAppServerSecurity = getEnvEntryValue("useAppServerSecurity").equals("1");
/*     */ 
/* 100 */     return useAppServerSecurity;
/*     */   }








/*     */   private String getValue(String name)
/*     */   {
/* 112 */     String value = (String)this.envEntries.get(name);
/* 113 */     return value;
/*     */   }







/*     */   private void putValue(String name, String value)
/*     */   {
/* 124 */     synchronized (this.envEntries)
/*     */     {
/* 126 */       this.envEntries.put(name, value);
/*     */     }
/*     */   }
/*     */ }
