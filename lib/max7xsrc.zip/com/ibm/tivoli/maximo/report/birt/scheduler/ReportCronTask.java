/*     */ package com.ibm.tivoli.maximo.report.birt.scheduler;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.queue.ReportQueueService;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportParameterData;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.app.report.ReportSched;
/*     */ import psdi.app.report.ReportSchedRemote;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.SimpleCronTask;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 

























/*     */ public class ReportCronTask extends SimpleCronTask
/*     */ {
/*     */   public void cronAction()
/*     */   {
/*  46 */     MXLogger reportCronTaskLogger = getCronTaskLogger();
/*     */ 
/*  48 */     if (reportCronTaskLogger.isDebugEnabled())
/*     */     {
/*  50 */       reportCronTaskLogger.debug("ReportCronTask cronAction called....");
/*  51 */       reportCronTaskLogger.debug("ReportCronTask starting work");
/*     */     }
/*     */ 
/*  54 */     queueReport();
/*     */ 
/*  56 */     if (!(reportCronTaskLogger.isDebugEnabled()))
/*     */       return;
/*  58 */     reportCronTaskLogger.debug("ReportCronTask done with work");
/*     */   }






/*     */   public void beforeRemoval()
/*     */     throws MXException, RemoteException
/*     */   {
/*  69 */     MXLogger reportCronTaskLogger = getCronTaskLogger();
/*  70 */     MboSetRemote reportScheduleSetRemote = null;
/*  71 */     ReportSchedRemote reportScheduleRemote = null;
/*  72 */     MboRemote cronTaskInstanceRemote = null;

/*     */     try
/*     */     {
/*  76 */       cronTaskInstanceRemote = getCrontaskInstance();
/*  77 */       long cronInstanceId = cronTaskInstanceRemote.getUniqueIDValue();
/*  78 */       String cronTaskName = cronTaskInstanceRemote.getString("crontaskname");
/*  79 */       String instanceName = cronTaskInstanceRemote.getString("instancename");

/*     */ 
/*  82 */       reportScheduleSetRemote = cronTaskInstanceRemote.getMboSet("$REPORTSCHED", "REPORTSCHED", "crontaskname = '" + cronTaskName + "' and instancename = '" + instanceName + "'");
/*     */ 
/*  84 */       reportScheduleRemote = (ReportSchedRemote)reportScheduleSetRemote.getMbo(0);
/*  85 */       if (reportScheduleRemote == null)
/*     */       {
/*  87 */         if (reportCronTaskLogger.isErrorEnabled())
/*     */         {
/*  89 */           reportCronTaskLogger.error("Report Schedule Information does not exist for CronTaskName " + cronTaskName + " and InstanceName " + instanceName + " so it cannot be deleted.");
/*     */         }
/*     */ 
/*  92 */         throw new MXApplicationException("reports", "noMatchingReportSchedError", new String[] { cronTaskInstanceRemote.getString("instancename") });



/*     */       }
/*     */ 
/*  98 */       if (reportScheduleRemote.getString("type").equalsIgnoreCase("ONCE"))
/*     */       {
/* 100 */         ((ReportSched)reportScheduleRemote).setCronTaskMgrCalledDelete(true);
/* 101 */         reportScheduleRemote.delete(2L);
/*     */       }
/*     */ 
/* 104 */       if (reportCronTaskLogger.isDebugEnabled())
/* 105 */         reportCronTaskLogger.debug("ReportCronTask deleting report schedule for crontaskinstanceid " + cronInstanceId + " cron task name " + cronTaskName + " and cron task instance name " + instanceName);
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/* 109 */       re.printStackTrace();
/* 110 */       throw new MXApplicationException("system", "remoteexception", re);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 114 */       if (reportCronTaskLogger.isErrorEnabled())
/*     */       {
/* 116 */         reportCronTaskLogger.error("Failed to remove report schedule: [" + reportScheduleRemote.getString("reportname") + "] app: [" + reportScheduleRemote.getString("appname") + "]", e);
/*     */       }
/*     */ 
/* 119 */       e.printStackTrace();
/* 120 */       throw new MXApplicationException("system", "failReportSchedAutoRemoval", new String[] { reportScheduleRemote.getString("REPORTNAME"), cronTaskInstanceRemote.getString("INSTANCENAME") });
/*     */     }
/*     */   }




/*     */   protected void queueReport()
/*     */   {
/* 129 */     MXLogger reportCronTaskLogger = getCronTaskLogger();
/* 130 */     String reportName = null;
/* 131 */     String appName = null;
/* 132 */     MboSetRemote reportScheduleSetRemote = null;

/*     */     try
/*     */     {
/* 136 */       MboRemote cronTaskInstanceRemote = getCrontaskInstance();
/* 137 */       long cronInstanceId = cronTaskInstanceRemote.getUniqueIDValue();
/* 138 */       String cronTaskName = cronTaskInstanceRemote.getString("crontaskname");
/* 139 */       String instanceName = cronTaskInstanceRemote.getString("instancename");


/*     */ 
/* 143 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/* 145 */       reportScheduleSetRemote = mxServer.getMboSet("REPORTSCHED", getUserInfo());
/* 146 */       reportScheduleSetRemote.setQbeExactMatch(true);
/* 147 */       reportScheduleSetRemote.setQbe(new String[] { "CRONTASKNAME", "INSTANCENAME" }, new String[] { cronTaskName, instanceName });
/* 148 */       reportScheduleSetRemote.reset();
/*     */ 
/* 150 */       MboRemote reportScheduleRemote = reportScheduleSetRemote.getMbo(0);
/* 151 */       if (reportScheduleRemote == null)
/*     */       {
/* 153 */         if (reportCronTaskLogger.isErrorEnabled())
/*     */         {
/* 155 */           reportCronTaskLogger.error("Report Schedule Information does not exist for CronTaskInstanceId " + cronInstanceId + " cron task name " + cronTaskName + " and cron task instance name " + instanceName);
/*     */         }
/*     */ 
/*     */         return;
/*     */       }
/*     */ 
/* 161 */       reportName = reportScheduleRemote.getString("REPORTNAME");
/* 162 */       appName = reportScheduleRemote.getString("APPNAME");
/* 163 */       String userId = reportScheduleRemote.getString("USERID");
/* 164 */       String emailSubject = reportScheduleRemote.getString("EMAILSUBJECT");
/* 165 */       String emailAddresses = reportScheduleRemote.getString("EMAILUSERS");
/* 166 */       String emailComments = reportScheduleRemote.getString("EMAILCOMMENTS");
/* 167 */       String emailFileType = reportScheduleRemote.getString("EMAILFILETYPE");
/* 168 */       String emailType = reportScheduleRemote.getString("EMAILTYPE");
/* 169 */       String maximoUrl = reportScheduleRemote.getString("MAXIMOURL");
/* 170 */       String country = reportScheduleRemote.getString("COUNTRY");
/* 171 */       String language = reportScheduleRemote.getString("LANGUAGE");
/* 172 */       String variant = reportScheduleRemote.getString("VARIANT");
/* 173 */       String timeZone = reportScheduleRemote.getString("TIMEZONE");
/* 174 */       String langCode = reportScheduleRemote.getString("LANGCODE");
/* 175 */       long reportScheduleId = reportScheduleRemote.getUniqueIDValue();

/*     */ 
/* 178 */       ReportParameterData parameterData = new ReportParameterData();
/*     */ 
/* 180 */       MboSetRemote parameterSetRemote = cronTaskInstanceRemote.getMboSet("PARAMETER");
/*     */ 
/* 182 */       int i = 0;
/*     */       while (true)
/*     */       {
/* 185 */         MboRemote parameterRemote = parameterSetRemote.getMbo(i);
/* 186 */         if (parameterRemote == null)
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/* 191 */         String parameterName = parameterRemote.getString("parameter");
/* 192 */         String parameterValue = parameterRemote.getString("value");
/*     */ 
/* 194 */         parameterData.addParameter(parameterName, parameterValue);
/* 195 */         ++i;


/*     */       }
/*     */ 
/* 200 */       ReportQueueService queueManager = ReportQueueService.getQueueService();
/* 201 */       queueManager.queueReport(reportName, appName, userId, emailAddresses, emailSubject, emailComments, emailFileType, emailType, maximoUrl, parameterData, country, language, variant, timeZone, langCode, reportScheduleId, getRunasUserInfo());



/*     */ 
/* 206 */       if (reportCronTaskLogger.isDebugEnabled())
/*     */       {
/* 208 */         reportCronTaskLogger.debug("ReportCronTask placed report in queue. report: [" + reportName + "] app: [" + appName + "]");



/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 217 */       if (reportCronTaskLogger.isErrorEnabled())
/*     */       {
/* 219 */         reportCronTaskLogger.error("Failed to queue the report: [" + reportName + "] app: [" + appName + "]", t);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 225 */         if (reportScheduleSetRemote != null)
/*     */         {
/* 227 */           reportScheduleSetRemote.reset();
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {
/*     */       }
/*     */     }
/*     */   }

/*     */   private UserInfo getUserInfo() {
/* 236 */     UserInfo userInfo = null;

/*     */     try
/*     */     {
/* 240 */       userInfo = getRunasUserInfo();
/* 241 */       if (userInfo == null)
/*     */       {
/* 243 */         userInfo = MXServer.getMXServer().getSystemUserInfo();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 248 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 251 */     return userInfo;
/*     */   }
/*     */ }
