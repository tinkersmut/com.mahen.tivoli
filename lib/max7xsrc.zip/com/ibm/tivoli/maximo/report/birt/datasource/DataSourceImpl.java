/*    */ package com.ibm.tivoli.maximo.report.birt.datasource;
/*    */ 















/*    */ public class DataSourceImpl
/*    */   implements DataSource
/*    */ {
/* 21 */   private DataSourceConnectionPool dsConnectionPool = null;
/*    */ 
/*    */   public DataSourceImpl(DataSourceConnectionPool dsConnectionPool)
/*    */   {
/* 25 */     this.dsConnectionPool = dsConnectionPool;
/*    */   }

/*    */   public DataSourceConnection getNewConnection()
/*    */   {
/* 30 */     return this.dsConnectionPool.getNewConnection();
/*    */   }

/*    */   public void freeConnection(DataSourceConnection connection)
/*    */   {
/* 35 */     this.dsConnectionPool.freeConnection(connection);
/*    */   }
/*    */ }
