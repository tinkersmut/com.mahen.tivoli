/*     */ package com.ibm.tivoli.maximo.report.birt.design;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
















/*     */ public class ReportParameterInfo
/*     */   implements Serializable
/*     */ {
/*     */   private String name;
/*     */   private boolean hidden;
/*     */   private String dataType;
/*     */   private String promptText;
/*     */   private String promptTextKey;
/*     */   private String helpText;
/*     */   private String helpTextKey;
/*     */   private boolean concealValue;
/*     */   private boolean allowBlank;
/*     */   private boolean allowNull;
/*     */   private String controlType;
/*     */   private String defaultValue;
/*     */   private String formatCategory;
/*     */   private String formatPattern;
/*     */ 
/*     */   public boolean isAllowBlank()
/*     */   {
/*  41 */     return this.allowBlank;
/*     */   }

/*     */   public void setAllowBlank(boolean allowBlank)
/*     */   {
/*  46 */     this.allowBlank = allowBlank;
/*     */   }

/*     */   public boolean isAllowNull()
/*     */   {
/*  51 */     return this.allowNull;
/*     */   }

/*     */   public void setAllowNull(boolean allowNull)
/*     */   {
/*  56 */     this.allowNull = allowNull;
/*     */   }

/*     */   public boolean isConcealValue()
/*     */   {
/*  61 */     return this.concealValue;
/*     */   }

/*     */   public void setConcealValue(boolean concealValue)
/*     */   {
/*  66 */     this.concealValue = concealValue;
/*     */   }

/*     */   public String getControlType()
/*     */   {
/*  71 */     return this.controlType;
/*     */   }

/*     */   public void setControlType(String controlType)
/*     */   {
/*  76 */     this.controlType = controlType;
/*     */   }

/*     */   public String getDataType()
/*     */   {
/*  81 */     return this.dataType;
/*     */   }

/*     */   public void setDataType(String dataType)
/*     */   {
/*  86 */     this.dataType = dataType;
/*     */   }

/*     */   public String getDefaultValue()
/*     */   {
/*  91 */     return this.defaultValue;
/*     */   }

/*     */   public void setDefaultValue(String defaultValue)
/*     */   {
/*  96 */     this.defaultValue = defaultValue;
/*     */   }

/*     */   public String getFormatCategory()
/*     */   {
/* 101 */     return this.formatCategory;
/*     */   }

/*     */   public void setFormatCategory(String formatCategory)
/*     */   {
/* 106 */     this.formatCategory = formatCategory;
/*     */   }

/*     */   public String getFormatPattern()
/*     */   {
/* 111 */     return this.formatPattern;
/*     */   }

/*     */   public void setFormatPattern(String formatPattern)
/*     */   {
/* 116 */     this.formatPattern = formatPattern;
/*     */   }

/*     */   public String getHelpText()
/*     */   {
/* 121 */     return this.helpText;
/*     */   }

/*     */   public void setHelpText(String helpText)
/*     */   {
/* 126 */     this.helpText = helpText;
/*     */   }

/*     */   public boolean isHidden()
/*     */   {
/* 131 */     return this.hidden;
/*     */   }

/*     */   public void setHidden(boolean hidden)
/*     */   {
/* 136 */     this.hidden = hidden;
/*     */   }

/*     */   public String getName()
/*     */   {
/* 141 */     return this.name;
/*     */   }

/*     */   public void setName(String name)
/*     */   {
/* 146 */     this.name = name;
/*     */   }

/*     */   public String getPromptText()
/*     */   {
/* 151 */     return this.promptText;
/*     */   }

/*     */   public void setPromptText(String promptText)
/*     */   {
/* 156 */     this.promptText = promptText;
/*     */   }

/*     */   public String getHelpTextKey()
/*     */   {
/* 161 */     return this.helpTextKey;
/*     */   }

/*     */   public void setHelpTextKey(String helpTextKey)
/*     */   {
/* 166 */     this.helpTextKey = helpTextKey;
/*     */   }

/*     */   public String getPromptTextKey()
/*     */   {
/* 171 */     return this.promptTextKey;
/*     */   }

/*     */   public void setPromptTextKey(String promptTextKey)
/*     */   {
/* 176 */     this.promptTextKey = promptTextKey;
/*     */   }
/*     */ }
