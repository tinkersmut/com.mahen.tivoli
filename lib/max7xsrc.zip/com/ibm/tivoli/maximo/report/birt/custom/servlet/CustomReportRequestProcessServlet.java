/*     */ package com.ibm.tivoli.maximo.report.birt.custom.servlet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.custom.admin.CustomReportAdminServiceRemote;
/*     */ import com.ibm.tivoli.maximo.report.birt.servlet.ReportRequestProcessServlet;
/*     */ import com.ibm.tivoli.maximo.report.birt.session.ReportSessionListener;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.util.CipherPlusBase64;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.webclient.system.websession.WebAppSessionProvider;
/*     */ 




















/*     */ public class CustomReportRequestProcessServlet extends ReportRequestProcessServlet
/*     */ {
/*     */   private static final String REPORT_DATARESTRICTIONPROVIDER = "DATARESTRICTIONPROVIDER";
/*     */   private static final String REPORT_ENCRYPTIONPROVIDER = "ENCRYPTIONPROVIDER";
/*     */ 
/*     */   protected void processReportRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  48 */     request.setCharacterEncoding("UTF-8");
/*     */ 
/*  50 */     HashMap reportParams = null;
/*  51 */     String reportRunRequestKey = null;
/*  52 */     String where = "";
/*  53 */     String validateWhere = "";
/*  54 */     String validateReportName = "";
/*     */ 
/*  56 */     String reportName = getRequestParameterValue(request, "__report");
/*  57 */     String appName = getRequestParameterValue(request, "appname");
/*  58 */     String requestId = getRequestParameterValue(request, "__requestid");
/*  59 */     if ((reportName != null) && (appName != null) && (requestId != null))


/*     */     {
/*  63 */       int slashIndex = reportName.lastIndexOf("/");
/*  64 */       if (slashIndex >= 0)
/*     */       {
/*  66 */         reportName = reportName.substring(slashIndex + 1);
/*     */       }
/*     */       else
/*     */       {
/*  70 */         slashIndex = reportName.lastIndexOf("\\");
/*  71 */         if (slashIndex >= 0)
/*     */         {
/*  73 */           reportName = reportName.substring(slashIndex + 1);
/*     */         }
/*     */       }
/*  76 */       reportRunRequestKey = "reportRequestId" + reportName + "_" + appName + "_" + requestId;
/*  77 */       reportParams = (HashMap)request.getSession().getAttribute(reportRunRequestKey);
/*     */     }
/*     */ 
/*  80 */     if (reportParams == null)


/*     */     {
/*  84 */       validateWhere = getRequestParameterValue(request, "custom1");
/*  85 */       validateReportName = getRequestParameterValue(request, "custom2");
/*  86 */       if ((validateWhere == null) || (validateWhere.equals("")) || (validateReportName == null) || (validateReportName.equals("")))

/*     */       {
/*  89 */         response.getWriter().write("");
/*  90 */         response.sendError(200);
/*  91 */         return;


/*     */       }
/*     */ 
/*  96 */       if (reportName == null)
/*     */       {
/*  98 */         reportName = getRequestParameterValue(request, "reportname");
/*     */       }
/* 100 */       where = getRequestParameterValue(request, "where");


/*     */       try
/*     */       {
/* 105 */         String testWhere = CipherPlusBase64.encrypt(where, true);
/* 106 */         testWhere = CipherPlusBase64.decrypt(testWhere, true);
/*     */ 
/* 108 */         validateWhere = CipherPlusBase64.decrypt(validateWhere, true);
/* 109 */         validateReportName = CipherPlusBase64.decrypt(validateReportName, true);
/*     */       } catch (Throwable t) {
/* 111 */         t.printStackTrace();
/*     */       }
/*     */     }
/*     */     else {
/* 115 */       validateWhere = ((String[])(String[])reportParams.get("custom1"))[0];
/* 116 */       validateReportName = ((String[])(String[])reportParams.get("custom2"))[0];
/* 117 */       if ((validateWhere == null) || (validateWhere.equals("")) || (validateReportName == null) || (validateReportName.equals("")))

/*     */       {
/* 120 */         response.getWriter().write("");
/* 121 */         response.sendError(200);
/* 122 */         return;
/*     */       }
/*     */ 
/* 125 */       where = ((String[])(String[])reportParams.get("where"))[0];

/*     */       try
/*     */       {
/* 129 */         validateWhere = CipherPlusBase64.decrypt(validateWhere, true);
/* 130 */         validateReportName = CipherPlusBase64.decrypt(validateReportName, true);
/*     */       } catch (Throwable t) {
/* 132 */         t.printStackTrace();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 137 */     if (where == null) {
/* 138 */       where = "";

/*     */     }
/*     */ 
/* 142 */     if ((!(where.equals(validateWhere))) || (!(reportName.equals(validateReportName))))
/*     */     {
/* 144 */       response.getWriter().write("");
/* 145 */       response.sendError(200);
/* 146 */       return;
/*     */     }
/*     */ 
/* 149 */     ArrayList dateParams = new ArrayList();

/*     */ 
/* 152 */     Object objSession = request.getSession().getAttribute("MXSession");
/* 153 */     MXSession mxSession = null;
/* 154 */     if (objSession == null)

/*     */     {
/* 157 */       String customrptServerLogon = getRequestParameterValue(request, "customrptServerLogon");
/* 158 */       String customrptServerLogonPass = getRequestParameterValue(request, "customrptServerLogonPass");
/*     */       try
/*     */       {
/* 161 */         if (!(customrptServerLogonPass.equals("")))
/*     */         {
/* 163 */           customrptServerLogonPass = CipherPlusBase64.decrypt(customrptServerLogonPass, true);

/*     */         }
/*     */ 
/* 167 */         mxSession = getMXSession(request.getSession());
/*     */ 
/* 169 */         mxSession.setUserName(customrptServerLogon);
/* 170 */         mxSession.setPassword(customrptServerLogonPass);
/* 171 */         mxSession.connect();


/*     */ 
/* 175 */         String userLocale = getRequestParameterValue(request, "locale");
/* 176 */         if ((userLocale != null) && (!(userLocale.equals(""))))
/*     */         {
/* 178 */           mxSession.getUserInfo().setLocale(userLocale);
/*     */         }
/* 180 */         String userTZ = getRequestParameterValue(request, "localTZ");
/* 181 */         if ((userTZ != null) && (!(userTZ.equals(""))))
/*     */         {
/* 183 */           mxSession.getUserInfo().setTimeZone(userTZ);
/*     */         }
/* 185 */         String userLangCode = getRequestParameterValue(request, "mroLangCode");
/* 186 */         if ((userLangCode != null) && (!(userLangCode.equals(""))))
/*     */         {
/* 188 */           mxSession.getUserInfo().setLangCode(userLangCode);
/*     */         }
/*     */ 
/* 191 */         request.getSession().setAttribute("MXSession", mxSession);
/*     */ 
/* 193 */         request.getSession().setAttribute("reportSessionListener", new ReportSessionListener(mxSession));
/*     */       } catch (Throwable t) {
/* 195 */         t.printStackTrace();
/*     */       }
/* 197 */       if ((customrptServerLogonPass == null) || (mxSession == null) || (!(mxSession.isConnected())))
/*     */       {
/* 199 */         response.getWriter().write("Invalid request. The request is not authorized.");
/* 200 */         response.sendError(401);
/* 201 */         return;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 206 */       mxSession = (MXSession)objSession;




/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 215 */       CustomReportAdminServiceRemote birtAdminService = (CustomReportAdminServiceRemote)mxSession.lookup("BIRTREPORT");
/* 216 */       dateParams = birtAdminService.getReportDateParams(mxSession.getUserInfo(), reportName, appName);
/*     */     } catch (Throwable t) {
/* 218 */       t.printStackTrace();
/*     */     }
/*     */ 
/* 221 */     if (reportParams != null)
/*     */     {
/* 223 */       if (dateParams.size() > 0)

/*     */       {
/* 226 */         Iterator i = dateParams.iterator();
/* 227 */         while (i.hasNext())
/*     */         {
/* 229 */           String paramName = (String)i.next();
/* 230 */           if ((reportParams.containsKey(paramName)) && (((String[])(String[])reportParams.get(paramName))[0].equals("")))

/*     */           {
/* 233 */             reportParams.remove(paramName);


/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 242 */       request.getSession().setAttribute(reportRunRequestKey, reportParams);
/*     */     }
/*     */ 
/* 245 */     String queryString = "";

/*     */ 
/* 248 */     HashMap additionalParams = new HashMap();
/*     */ 
/* 250 */     String reportName1 = getRequestParameterValue(request, "reportname");
/* 251 */     String birtReportParamValue = getRequestParameterValue(request, "__report");
/* 252 */     if ((birtReportParamValue == null) && (reportName1 != null))
/*     */     {
/* 254 */       String qReportName = reportName1;
/* 255 */       additionalParams.put("__report", new String[] { reportName1 });
/*     */ 
/* 257 */       String newRun = getRequestParameterValue(request, "__newrun");
/* 258 */       if (newRun == null)
/*     */       {
/* 260 */         additionalParams.put("__newrun", new String[] { "true" });

/*     */       }
/*     */ 
/* 264 */       String appName1 = getRequestParameterValue(request, "mroApp");
/* 265 */       String birtAppName = getRequestParameterValue(request, "appname");
/* 266 */       if ((birtAppName == null) && (appName1 != null))
/*     */       {
/* 268 */         birtAppName = appName1;
/* 269 */         additionalParams.put("appname", new String[] { appName1 });
/*     */       }
/*     */ 
/* 272 */       String requestId1 = getRequestParameterValue(request, "__requestid");
/* 273 */       if (requestId1 == null)

/*     */       {
/* 276 */         requestId1 = "" + System.currentTimeMillis();
/* 277 */         additionalParams.put("__requestid", new String[] { requestId1 });
/*     */       }
/*     */ 
/* 280 */       queryString = "__report=" + qReportName + "&appname=" + appName1 + "&__requestid=" + requestId1;
/*     */ 
/* 282 */       if (dateParams.size() > 0)
/*     */       {
/* 284 */         String[] dateParamStr = (String[])(String[])dateParams.toArray(new String[dateParams.size()]);
/* 285 */         additionalParams.put("__islocale", dateParamStr);
/*     */       }
/*     */     }
/*     */ 
/* 289 */     CustomHttpServletRequestWrapper requestWrapper = new CustomHttpServletRequestWrapper(request, additionalParams);
/* 290 */     requestWrapper.setXQueryString(queryString);
/*     */ 
/* 292 */     super.processReportRequest(requestWrapper, response);
/*     */   }

/*     */   public static MXSession getMXSession(HttpSession session)
/*     */   {
/* 297 */     MXSession s = null;
/* 298 */     if (session != null)
/*     */     {
/* 300 */       s = (MXSession)session.getAttribute("MXSession");
/* 301 */       if (s == null)
/*     */       {
/* 303 */         MXSession mxs = WebAppSessionProvider.getNewWebAppSession();
/* 304 */         if (mxs != null)
/*     */         {
/* 306 */           mxs.setInteractive(true);
/*     */ 
/* 308 */           session.setAttribute("MXSession", mxs);
/* 309 */           s = mxs;
/*     */         }
/*     */       }
/*     */     }
/* 313 */     return s;
/*     */   }








/*     */   protected void setMXReportContext(HttpServletRequest request, UserInfo userInfo, String reportName, String appName, boolean isTransient, String reportContextKey, MXSession session, String reportRunInfoKey)
/*     */     throws Exception
/*     */   {
/* 326 */     super.setMXReportContext(request, userInfo, reportName, appName, isTransient, reportContextKey, session, reportRunInfoKey);
/*     */ 
/* 328 */     HashMap mxReportContext = null;
/* 329 */     mxReportContext = (HashMap)request.getSession().getAttribute(reportContextKey);

/*     */ 
/* 332 */     CustomImmediateReportDataRestrictionProvider dp = new CustomImmediateReportDataRestrictionProvider();
/* 333 */     mxReportContext.put("DATARESTRICTIONPROVIDER", dp);
/*     */ 
/* 335 */     CustomEncryptionProvider ep = new CustomEncryptionProvider();
/* 336 */     mxReportContext.put("ENCRYPTIONPROVIDER", ep);
/*     */   }
/*     */ }
