/*    */ package com.ibm.tivoli.maximo.report.birt.design;
/*    */ 



















/*    */ public class ReportLibraryInfo
/*    */ {
/*    */   private String name;
/*    */   private String fileName;
/*    */ 
/*    */   public ReportLibraryInfo()
/*    */   {
/* 29 */     this.name = null;



/*    */ 
/* 34 */     this.fileName = null;
/*    */   }







/*    */   public String getFileName()
/*    */   {
/* 45 */     return this.fileName;
/*    */   }






/*    */   public void setFileName(String fileName)
/*    */   {
/* 55 */     this.fileName = fileName;
/*    */   }






/*    */   public String getName()
/*    */   {
/* 65 */     return this.name;
/*    */   }






/*    */   public void setName(String name)
/*    */   {
/* 75 */     this.name = name;
/*    */   }
/*    */ }
