/*     */ package com.ibm.tivoli.maximo.report.birt.admin.batch;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
















/*     */ public class ReportInfo
/*     */ {
/*  26 */   private String name = null;
/*  27 */   private HashMap<String, String> attributeMap = new HashMap();
/*  28 */   private ArrayList<ReportResourceInfo> resources = new ArrayList();
/*  29 */   private HashMap<String, ReportParameterInfo> parameterMap = new HashMap();
/*  30 */   private byte[] content = null;
/*  31 */   private byte[] resourcesZipData = null;
/*     */ 
/*     */   public ReportInfo(String name)
/*     */   {
/*  35 */     this.name = name;
/*     */   }

/*     */   public String getName()
/*     */   {
/*  40 */     return this.name;
/*     */   }

/*     */   public void setAttribute(String attributeName, String attributeValue)
/*     */   {
/*  45 */     this.attributeMap.put(attributeName, attributeValue);
/*     */   }

/*     */   public String getAttribute(String attributeName)
/*     */   {
/*  50 */     return ((String)this.attributeMap.get(attributeName));
/*     */   }

/*     */   public void removeAttribute(String attributeName)
/*     */   {
/*  55 */     this.attributeMap.remove(attributeName);
/*     */   }

/*     */   public void reset()
/*     */   {
/*  60 */     this.attributeMap = new HashMap();
/*     */   }

/*     */   public Iterator getAttributes()
/*     */   {
/*  65 */     return this.attributeMap.keySet().iterator();
/*     */   }

/*     */   public void addReportResourceInfo(ReportResourceInfo rsInfo)
/*     */   {
/*  70 */     this.resources.add(rsInfo);
/*     */   }

/*     */   public Iterator getReportResources()
/*     */   {
/*  75 */     return this.resources.iterator();
/*     */   }

/*     */   public int getReportResourcesSize()
/*     */   {
/*  80 */     return this.resources.size();
/*     */   }

/*     */   public byte[] getReportResourcesZipData()
/*     */   {
/*  85 */     return this.resourcesZipData;
/*     */   }

/*     */   public void setReportResourcesZipData(byte[] resourcesZipData)
/*     */   {
/*  90 */     this.resourcesZipData = resourcesZipData;
/*     */   }

/*     */   public byte[] getContent()
/*     */   {
/*  95 */     return this.content;
/*     */   }

/*     */   public void setReportContent(byte[] reportContent)
/*     */   {
/* 100 */     this.content = reportContent;
/*     */   }

/*     */   public void setParameter(String paramName, ReportParameterInfo paramInfo)
/*     */   {
/* 105 */     this.parameterMap.put(paramName, paramInfo);
/*     */   }

/*     */   public ReportParameterInfo getParameter(String paramName)
/*     */   {
/* 110 */     return ((ReportParameterInfo)this.parameterMap.get(paramName));
/*     */   }

/*     */   public void removeParameter(String paramName)
/*     */   {
/* 115 */     this.parameterMap.remove(paramName);
/*     */   }

/*     */   public Iterator getParameters()
/*     */   {
/* 120 */     return this.parameterMap.keySet().iterator();
/*     */   }

/*     */   public int getReportParametersSize()
/*     */   {
/* 125 */     return this.resources.size();
/*     */   }
/*     */ }
