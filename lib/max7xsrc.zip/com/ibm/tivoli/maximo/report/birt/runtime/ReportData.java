/*     */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
















/*     */ public class ReportData
/*     */   implements Serializable
/*     */ {
/*     */   private String reportName;
/*     */   private String appName;
/*     */   private ReportInfo reportInfo;
/*     */   private ReportParameterData reportParameterData;
/*     */ 
/*     */   public ReportData()
/*     */   {
/*  31 */     this.reportName = null;



/*     */ 
/*  36 */     this.appName = null;



/*     */ 
/*  41 */     this.reportInfo = null;



/*     */ 
/*  46 */     this.reportParameterData = null;
/*     */   }








/*     */   public ReportInfo getReportInfo()
/*     */   {
/*  58 */     return this.reportInfo;
/*     */   }






/*     */   public void setReportInfo(ReportInfo reportInfo)
/*     */   {
/*  68 */     this.reportInfo = reportInfo;
/*     */   }






/*     */   public String getReportName()
/*     */   {
/*  78 */     return this.reportName;
/*     */   }






/*     */   public void setReportName(String reportName)
/*     */   {
/*  88 */     this.reportName = reportName;
/*     */   }






/*     */   public String getAppName()
/*     */   {
/*  98 */     return this.appName;
/*     */   }





/*     */   public void setAppName(String appName)
/*     */   {
/* 107 */     this.appName = appName;
/*     */   }






/*     */   public ReportParameterData getReportParameterData()
/*     */   {
/* 117 */     return this.reportParameterData;
/*     */   }






/*     */   public void setReportParameterData(ReportParameterData reportParameterData)
/*     */   {
/* 127 */     this.reportParameterData = reportParameterData;
/*     */   }
/*     */ }
