/*    */ package com.ibm.tivoli.maximo.report.birt.design;
/*    */ 
































/*    */ public class ReportDesignTaskProvider
/*    */ {
/* 32 */   private static ReportDesignTask reportDesignTask = null;
/*    */ 
/*    */   public static ReportDesignTask getReportDesignTask()
/*    */   {
/* 41 */     return reportDesignTask;
/*    */   }









/*    */   public static void setReportDesignTask(ReportDesignTask rdTask)
/*    */   {
/* 54 */     reportDesignTask = rdTask;
/*    */   }
/*    */ }
