/*     */ package com.ibm.tivoli.maximo.report.birt;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportRunInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportData;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportRuntimeTempLocation;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ 












/*     */ public class ReportUtil
/*     */ {
/* 187 */   private static Object tempFolderLockObj = new Object();
/*     */ 
/*     */   public static ReportRunInfo prepareReportForRun(ReportData reportData)
/*     */     throws ReportException
/*     */   {
/*  39 */     String tempRunFolder = ReportRuntimeTempLocation.getReportsLocation();
/*  40 */     String uniqueFolder = createUniqueTempFolder(tempRunFolder);
/*     */ 
/*  42 */     String tempReportFolder = uniqueFolder + File.separator + "workorder";
/*     */ 
/*  44 */     String tempReportFolderPath = tempRunFolder + File.separator + tempReportFolder;
/*  45 */     File fRun = new File(tempReportFolderPath);
/*  46 */     fRun.mkdirs();
/*     */ 
/*  48 */     System.out.println("*** prepareReportForRun tempFolder = " + tempRunFolder);
/*  49 */     System.out.println("*** prepareReportForRun tempReportFolder = " + tempReportFolder);
/*     */ 
/*  51 */     String tempOutFolder = uniqueFolder + File.separator + "_output";
/*     */ 
/*  53 */     String tempOutputFolderPath = tempRunFolder + File.separator + tempOutFolder;
/*  54 */     File fOut = new File(tempOutputFolderPath);
/*  55 */     fOut.mkdirs();

/*     */     try
/*     */     {
/*  59 */       extractReport(reportData.getReportInfo(), tempReportFolderPath);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  63 */       throw new ReportException(e.getMessage(), e);
/*     */     }
/*     */ 
/*  66 */     ReportRunInfo reportRunInfo = new ReportRunInfo();
/*  67 */     reportRunInfo.setReportName(reportData.getReportName());
/*  68 */     reportRunInfo.setAppName(reportData.getAppName());
/*  69 */     reportRunInfo.setReportFolderName(tempReportFolder);
/*  70 */     reportRunInfo.setReportOutputFolderName(tempOutFolder);
/*  71 */     reportRunInfo.setTempRunFolder(tempRunFolder);
/*     */ 
/*  73 */     return reportRunInfo;
/*     */   }



/*     */   private static void extractReport(ReportInfo reportInfo, String tempReportFolder)
/*     */     throws Exception
/*     */   {
/*  81 */     String reportName = reportInfo.getReportName();
/*  82 */     byte[] resources = reportInfo.getReportResources();
/*  83 */     String reportDesign = reportInfo.getReportDesign();
/*     */ 
/*  85 */     if ((resources != null) && (resources.length > 0))

/*     */     {
/*  88 */       FileOutputStream fos1 = new FileOutputStream(tempReportFolder + File.separator + reportName + ".zip");
/*  89 */       fos1.write(resources);
/*  90 */       fos1.close();
/*     */ 
/*  92 */       File zipFile = new File(tempReportFolder + File.separator + reportName + ".zip");
/*  93 */       extractResources(zipFile, tempReportFolder);

/*     */ 
/*  96 */       zipFile.delete();

/*     */     }
/*     */ 
/* 100 */     FileOutputStream fos = new FileOutputStream(tempReportFolder + File.separator + reportName);
/* 101 */     PrintWriter pw = new PrintWriter(fos);
/* 102 */     pw.print(reportDesign);
/* 103 */     pw.flush();
/* 104 */     pw.close();

/*     */ 
/* 107 */     String propertiesFileName = reportInfo.getPropertiesFileName();
/* 108 */     if (propertiesFileName != null)
/*     */     {
/* 110 */       FileOutputStream fosProp = new FileOutputStream(tempReportFolder + File.separator + propertiesFileName);
/* 111 */       PrintWriter pwProp = new PrintWriter(fosProp);
/*     */ 
/* 113 */       HashMap properties = reportInfo.getProperties();
/* 114 */       Iterator keyIterator = properties.keySet().iterator();
/* 115 */       while (keyIterator.hasNext())
/*     */       {
/* 117 */         String propertyName = (String)keyIterator.next();
/* 118 */         String propertyValue = (String)properties.get(propertyName);
/* 119 */         pwProp.println(propertyName + "=" + propertyValue);
/*     */       }
/*     */ 
/* 122 */       pwProp.flush();
/* 123 */       pwProp.close();
/*     */     }
/*     */ 
/* 126 */     Iterator libIterator = reportInfo.getLibraries();
/* 127 */     while (libIterator.hasNext())
/*     */     {
/* 129 */       ReportInfo libReportInfo = (ReportInfo)libIterator.next();
/* 130 */       extractReport(libReportInfo, tempReportFolder);
/*     */     }
/*     */   }

/*     */   private static void extractResources(File resourcesZipFile, String reportFolder)
/*     */     throws IOException
/*     */   {
/* 137 */     ZipFile zFile = new ZipFile(resourcesZipFile);
/* 138 */     Enumeration zipEnum = zFile.entries();
/*     */ 
/* 140 */     String outputFolder = reportFolder;
/* 141 */     while (zipEnum.hasMoreElements())
/*     */     {
/* 143 */       ZipEntry zipEntry = (ZipEntry)zipEnum.nextElement();
/* 144 */       InputStream zipEntryInputStream = zFile.getInputStream(zipEntry);
/*     */ 
/* 146 */       String zipEntryName = zipEntry.getName();
/* 147 */       boolean isDir = zipEntry.isDirectory();
/*     */ 
/* 149 */       if (isDir)
/*     */       {
/* 151 */         File f = new File(outputFolder + File.separator + zipEntryName);
/* 152 */         f.mkdirs();
/*     */       }
/*     */       else
/*     */       {
/* 156 */         File f = new File(outputFolder + File.separator + zipEntryName);
/* 157 */         f.getParentFile().mkdirs();
/*     */ 
/* 159 */         createFileFromStream(f, zipEntryInputStream);
/*     */       }
/*     */     }
/*     */ 
/* 163 */     zFile.close();
/*     */   }

/*     */   private static void createFileFromStream(File file, InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 169 */     FileOutputStream fos = new FileOutputStream(file);
/*     */ 
/* 171 */     byte[] buf = new byte[1024];
/*     */     while (true)
/*     */     {
/* 174 */       int bytesRead = inputStream.read(buf);
/* 175 */       if (bytesRead <= 0) {
/*     */         break;
/*     */       }
/*     */ 
/* 179 */       fos.write(buf, 0, bytesRead);
/*     */     }
/*     */ 
/* 182 */     fos.flush();
/* 183 */     fos.close();
/*     */   }





/*     */   private static String createUniqueTempFolder(String parentFolderName)
/*     */   {
/* 192 */     String uniqueTempFolder = null;
/*     */ 
/* 194 */     File parentFolderFile = new File(parentFolderName);
/*     */ 
/* 196 */     synchronized (tempFolderLockObj)
/*     */     {
/* 198 */       long curTime = System.currentTimeMillis();
/*     */ 
/* 200 */       int noOfAttempts = 0;

/*     */       while (true)
/*     */       {
/* 204 */         String folderToCheck = parentFolderName + File.separator + curTime;
/* 205 */         File f = new File(folderToCheck);
/* 206 */         if (!(f.exists()))
/*     */         {
/* 208 */           f.mkdirs();
/* 209 */           uniqueTempFolder = "" + curTime;
/* 210 */           break;
/*     */         }
/*     */ 
/* 213 */         curTime += 1L;
/* 214 */         ++noOfAttempts;
/* 215 */         if (noOfAttempts > 1000) {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 222 */     return uniqueTempFolder;
/*     */   }
/*     */ }
