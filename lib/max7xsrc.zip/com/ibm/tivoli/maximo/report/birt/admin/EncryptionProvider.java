package com.ibm.tivoli.maximo.report.birt.admin;

import java.rmi.RemoteException;
import psdi.util.MXException;

public abstract interface EncryptionProvider
{
  public abstract String encrypt(String paramString)
    throws MXException, RemoteException;
}
