package com.ibm.tivoli.maximo.report.birt.admin;

public abstract interface ReportUsageLogNotifier
{
  public abstract void setReportExecuted();

  public abstract void setReportFailed();

  public abstract void setReportCancelled();

  public abstract void createUsageLog();
}
