/*    */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportMessageProvider;
/*    */ import psdi.server.MXServerRemote;
/*    */ 






















/*    */ public class ReportMessageProviderImpl
/*    */   implements ReportMessageProvider
/*    */ {
/* 31 */   private MXServerRemote mxServerRemote = null;
/* 32 */   private String langCode = null;
/*    */ 
/*    */   public ReportMessageProviderImpl(String langCode, MXServerRemote mxServerRemote)
/*    */   {
/* 36 */     this.langCode = langCode;
/* 37 */     this.mxServerRemote = mxServerRemote;
/*    */   }

/*    */   public String getMessage(String key)
/*    */   {
/*    */     try
/*    */     {
/* 44 */       String msg = this.mxServerRemote.getMessage("reports", key, this.langCode);
/* 45 */       return msg;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/* 50 */     return "reports#" + key;
/*    */   }
/*    */ }
