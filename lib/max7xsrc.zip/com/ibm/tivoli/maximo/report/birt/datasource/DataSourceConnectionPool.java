/*     */ package com.ibm.tivoli.maximo.report.birt.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Properties;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 
















/*     */ public class DataSourceConnectionPool
/*     */ {
/*  36 */   private DataSourceInfo dataSourceInfo = null;
/*     */ 
/*  38 */   private MXLogger reportDataSourceLogger = null;
/*     */ 
/*  48 */   private ArrayList<Connection> used = new ArrayList();
/*  49 */   private ArrayList<Connection> free = new ArrayList();
/*     */ 
/*  51 */   private boolean destroyed = false;
/*     */ 
/*     */   public DataSourceConnectionPool(DataSourceInfo dataSourceInfo)
/*     */   {
/*  42 */     this.dataSourceInfo = dataSourceInfo;
/*     */ 
/*  44 */     this.reportDataSourceLogger = MXLoggerFactory.getLogger("maximo.report.birt.datasource");
/*     */   }








/*     */   public DataSourceConnection getNewConnection()
/*     */   {
/*  56 */     Connection c = null;
/*  57 */     synchronized (this)
/*     */     {
/*     */       while (true)
/*     */       {
/*  61 */         c = null;
/*  62 */         int freeSize = this.free.size();
/*  63 */         if (freeSize <= 0)
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/*  68 */         c = (Connection)this.free.remove(0);
/*  69 */         if (isValidConnection(c))
/*     */         {
/*  71 */           this.used.add(c);
/*  72 */           break;

/*     */         }
/*     */ 
/*  76 */         closeConnection(c);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  81 */     if (c != null)
/*     */     {
/*  83 */       DataSourceConnection dsConnection = new DataSourceConnectionImpl(c);
/*  84 */       return dsConnection;
/*     */     }
/*     */ 
/*  87 */     Connection connection = createConnection();
/*     */ 
/*  89 */     synchronized (this)
/*     */     {
/*  91 */       this.used.add(connection);
/*     */     }
/*     */ 
/*  94 */     DataSourceConnection dsConnection = new DataSourceConnectionImpl(connection);
/*  95 */     return dsConnection;
/*     */   }

/*     */   private Connection createConnection()
/*     */   {
/* 100 */     String driver = this.dataSourceInfo.getDriver();
/* 101 */     String url = this.dataSourceInfo.getUrl();
/* 102 */     String userName = this.dataSourceInfo.getUserName();
/* 103 */     String password = this.dataSourceInfo.getPassword();
/* 104 */     String schemaOwner = this.dataSourceInfo.getSchemaOwner();

/*     */     try
/*     */     {
/* 108 */       Class.forName(driver);


/*     */ 
/* 112 */       Connection connection = null;
/* 113 */       if (url.indexOf("jdbc:db2") != -1)
/*     */       {
/* 115 */         String sslConnection = this.dataSourceInfo.getSslConnection();
/* 116 */         String sslTrustStoreLocation = this.dataSourceInfo.getSslTrustStoreLocation();
/* 117 */         String sslTrustStorePassword = this.dataSourceInfo.getSslTrustStorePassword();
/*     */ 
/* 119 */         Properties properties = new Properties();
/* 120 */         properties.put("user", userName);
/* 121 */         properties.put("password", password);
/* 122 */         properties.put("retrieveMessagesFromServerOnGetMessage", "true");
/* 123 */         if ((sslConnection != null) && (sslConnection.equals("true")))
/*     */         {
/* 125 */           properties.put("sslConnection", sslConnection);
/* 126 */           properties.put("sslTrustStoreLocation", sslTrustStoreLocation);
/* 127 */           properties.put("sslTrustStorePassword", sslTrustStorePassword);
/*     */         }
/* 129 */         connection = DriverManager.getConnection(url, properties);
/*     */       }
/*     */       else
/*     */       {
/* 133 */         connection = DriverManager.getConnection(url, userName, password);
/*     */       }
/* 135 */       setupDefaultConnectionProperties(connection, schemaOwner);
/*     */ 
/* 137 */       return connection;
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 141 */       if (this.reportDataSourceLogger.isErrorEnabled())
/*     */       {
/* 143 */         this.reportDataSourceLogger.error("Failed to create connection for datasource: [" + this.dataSourceInfo.getName() + "]", t);
/*     */       }
/* 145 */       throw new RuntimeException("Failed to create connection for datasource: [" + this.dataSourceInfo.getName() + "]");
/*     */     }
/*     */   }

/*     */   private void setupDefaultConnectionProperties(Connection connection, String schemaOwner)
/*     */   {
/* 151 */     Statement s = null;
/*     */     try
/*     */     {
/* 154 */       if ((schemaOwner != null) && (schemaOwner.trim().length() > 0))
/*     */       {
/* 156 */         schemaOwner = schemaOwner.trim();
/*     */ 
/* 158 */         s = connection.createStatement();
/*     */ 
/* 160 */         String dbProductName = connection.getMetaData().getDatabaseProductName();
/* 161 */         if (dbProductName.toUpperCase().indexOf("ORACLE") >= 0)
/*     */         {
/* 163 */           s.execute("alter session set current_schema=" + schemaOwner);
/*     */         }
/* 165 */         else if (dbProductName.toUpperCase().indexOf("MICROSOFT") < 0)



/*     */         {
/* 170 */           if (dbProductName.toUpperCase().indexOf("DB2") >= 0)
/*     */           {
/* 172 */             s.execute("SET SCHEMA " + schemaOwner);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 177 */       connection.setAutoCommit(false);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 181 */       if (this.reportDataSourceLogger.isErrorEnabled())
/*     */       {
/* 183 */         this.reportDataSourceLogger.error("Failed to set the default connection properties like SchemaOwner and auto commit.", t);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 189 */         if (s != null)
/*     */         {
/* 191 */           s.close();
/*     */         }
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */       }
/*     */     }
/*     */   }

/*     */   public void freeConnection(DataSourceConnection connection) {
/* 201 */     Connection c = connection.getConnection();
/*     */ 
/* 203 */     synchronized (this)
/*     */     {
/* 205 */       this.used.remove(c);
/*     */     }
/*     */ 
/* 208 */     if (this.destroyed)
/*     */     {
/* 210 */       closeConnection(c);
/* 211 */       return;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 216 */       c.rollback();
/* 217 */       synchronized (this)
/*     */       {
/* 219 */         this.free.add(c);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 225 */       closeConnection(c);
/*     */     }
/*     */   }



/*     */   public void destroy()
/*     */   {
/* 233 */     this.destroyed = true;
/*     */ 
/* 235 */     synchronized (this)


/*     */     {
/* 239 */       while (this.free.size() > 0)



/*     */       {
/* 244 */         Connection c = (Connection)this.free.remove(0);
/* 245 */         closeConnection(c);
/*     */       }
/*     */     }
/*     */   }


/*     */   public void adjustPool()
/*     */   {
/* 253 */     int usedSize = this.used.size();
/* 254 */     int freeSize = this.free.size();
/*     */ 
/* 256 */     int totalPoolSize = usedSize + freeSize;
/*     */ 
/* 258 */     int maxConnections = getMaxAllowedActiveReportThreads();

/*     */ 
/* 261 */     if (totalPoolSize < 1)

/*     */     {
/* 264 */       for (int i = 0; i < maxConnections; ++i)
/*     */       {
/* 266 */         Connection c = createConnection();
/* 267 */         if (c == null) {
/*     */           continue;
/*     */         }
/*     */ 
/* 271 */         synchronized (this)
/*     */         {
/* 273 */           this.free.add(c);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 279 */     synchronized (this)
/*     */     {
/* 281 */       freeSize = this.free.size();
/*     */ 
/* 283 */       if (freeSize > maxConnections)
/*     */       {
/* 285 */         int noOfConnectionsToRelease = freeSize - maxConnections;
/* 286 */         for (int i = 0; i < noOfConnectionsToRelease; ++i)
/*     */         {
/* 288 */           Connection c = null;
/*     */ 
/* 290 */           c = (Connection)this.free.remove(0);
/*     */ 
/* 292 */           closeConnection(c);
/*     */         }
/*     */       }
/*     */     }
/*     */   }

/*     */   private boolean isValidConnection(Connection c)
/*     */   {
/* 300 */     boolean validConnection = true;

/*     */     try
/*     */     {
/* 304 */       c.rollback();
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 308 */       validConnection = false;
/*     */     }
/*     */ 
/* 311 */     return validConnection;
/*     */   }

/*     */   private void closeConnection(Connection c)
/*     */   {
/*     */     try
/*     */     {
/* 318 */       c.close();
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*     */     }
/*     */   }

/*     */   public int getMaxAllowedActiveReportThreads()
/*     */   {
/*     */     try
/*     */     {
/* 329 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/* 331 */       String maxCRunStr = mxServer.getProperty("mxe.report.birt.maxconcurrentrun");
/* 332 */       if (maxCRunStr == null)
/*     */       {
/* 334 */         return 3;
/*     */       }
/*     */ 
/* 337 */       int maxAllowed = Integer.valueOf(maxCRunStr).intValue();
/*     */ 
/* 339 */       return maxAllowed;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 343 */       if (this.reportDataSourceLogger.isErrorEnabled())
/*     */       {
/* 345 */         this.reportDataSourceLogger.error("Failed to obtain [mxe.report.birt.maxconcurrentrun] property value. Assuming default [3].", e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 350 */     return 3;
/*     */   }
/*     */ }
