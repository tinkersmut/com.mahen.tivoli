/*     */ package com.ibm.tivoli.maximo.report.birt.bridge.launcher;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 


























/*     */ public class BridgeServlet extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 2825667412474494674L;
/*     */   private static BridgeServlet instance;
/*     */   private HttpServlet delegate;
/*     */   private FrameworkLauncher framework;
/*     */   private int delegateReferenceCount;
/*     */   private boolean enableFrameworkControls;
/*     */ 
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/*  50 */     super.init();
/*  51 */     setInstance(this);
/*     */ 
/*  53 */     String enableFrameworkControlsParameter = getServletConfig().getInitParameter("enableFrameworkControls");
/*  54 */     this.enableFrameworkControls = ((enableFrameworkControlsParameter != null) && (enableFrameworkControlsParameter.equals("true")));
/*     */ 
/*  56 */     String frameworkLauncherClassParameter = getServletConfig().getInitParameter("frameworkLauncherClass");
/*  57 */     if (frameworkLauncherClassParameter != null)
/*     */       try {
/*  59 */         Class frameworkLauncherClass = super.getClass().getClassLoader().loadClass(frameworkLauncherClassParameter);
/*  60 */         this.framework = ((FrameworkLauncher)frameworkLauncherClass.newInstance());
/*     */       } catch (Exception e) {
/*  62 */         throw new ServletException(e);
/*     */       }
/*     */     else {
/*  65 */       this.framework = new FrameworkLauncher();
/*     */     }
/*     */ 
/*  68 */     this.framework.init(getServletConfig());
/*  69 */     this.framework.deploy();
/*  70 */     this.framework.start();
/*     */   }



/*     */   public void destroy()
/*     */   {
/*  77 */     this.framework.stop();
/*  78 */     this.framework.destroy();
/*  79 */     setInstance(null);
/*  80 */     super.destroy();
/*     */   }




/*     */   protected void service(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws ServletException, IOException
/*     */   {
/*  89 */     if (this.enableFrameworkControls) {
/*  90 */       String pathInfo = req.getPathInfo();
/*  91 */       if ((pathInfo != null) && (pathInfo.startsWith("/sp_")) && 
/*  92 */         (serviceFrameworkControls(req, resp))) {
/*  93 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  98 */     ClassLoader original = Thread.currentThread().getContextClassLoader();
/*  99 */     HttpServlet servletReference = acquireDelegateReference();
/* 100 */     if (servletReference == null) {
/* 101 */       resp.sendError(404, "BridgeServlet: " + req.getRequestURI());
/* 102 */       return;
/*     */     }
/*     */     try {
/* 105 */       Thread.currentThread().setContextClassLoader(this.framework.getFrameworkContextClassLoader());
/* 106 */       servletReference.service(req, resp);
/*     */     } finally {
/* 108 */       releaseDelegateReference();
/* 109 */       Thread.currentThread().setContextClassLoader(original);
/*     */     }
/*     */   }







/*     */   private boolean serviceFrameworkControls(HttpServletRequest req, HttpServletResponse resp)
/*     */     throws IOException
/*     */   {
/* 122 */     String pathInfo = req.getPathInfo();
/* 123 */     if (pathInfo.equals("/sp_start")) {
/* 124 */       this.framework.start();
/* 125 */       resp.getWriter().write("Platform Started");
/* 126 */       return true; }
/* 127 */     if (pathInfo.equals("/sp_stop")) {
/* 128 */       this.framework.stop();
/* 129 */       resp.getWriter().write("Platform Stopped");
/* 130 */       return true; }
/* 131 */     if (pathInfo.equals("/sp_deploy")) {
/* 132 */       this.framework.deploy();
/* 133 */       resp.getWriter().write("Platform Deployed");
/* 134 */       return true; }
/* 135 */     if (pathInfo.equals("/sp_undeploy")) {
/* 136 */       this.framework.undeploy();
/* 137 */       resp.getWriter().write("Platform Undeployed");
/* 138 */       return true; }
/* 139 */     if (pathInfo.equals("/sp_reset")) {
/* 140 */       this.framework.stop();
/* 141 */       this.framework.start();
/* 142 */       resp.getWriter().write("Platform Reset");
/* 143 */       return true; }
/* 144 */     if (pathInfo.equals("/sp_redeploy")) {
/* 145 */       this.framework.stop();
/* 146 */       this.framework.undeploy();
/* 147 */       this.framework.deploy();
/* 148 */       this.framework.start();
/* 149 */       resp.getWriter().write("Platform Redeployed");
/* 150 */       return true;
/*     */     }
/* 152 */     return false;
/*     */   }

/*     */   private static synchronized void setInstance(BridgeServlet servlet) {
/* 156 */     if ((instance != null) && (servlet != null))
/* 157 */       throw new IllegalStateException("instance already set");
/* 158 */     instance = servlet;
/*     */   }

/*     */   private synchronized void releaseDelegateReference() {
/* 162 */     this.delegateReferenceCount -= 1;
/* 163 */     super.notifyAll();
/*     */   }

/*     */   private synchronized HttpServlet acquireDelegateReference() {
/* 167 */     if (this.delegate != null)
/* 168 */       this.delegateReferenceCount += 1;
/* 169 */     return this.delegate;
/*     */   }







/*     */   public static synchronized void registerServletDelegate(HttpServlet servletDelegate)
/*     */   {
/* 180 */     if (instance == null)
/*     */     {
/* 182 */       return;
/*     */     }
/*     */ 
/* 185 */     if (servletDelegate == null) {
/* 186 */       throw new NullPointerException("cannot register a null servlet delegate");
/*     */     }
/* 188 */     synchronized (instance) {
/* 189 */       if (instance.delegate != null)
/* 190 */         throw new IllegalStateException("A Servlet Proxy is already registered");
/*     */       try
/*     */       {
/* 193 */         servletDelegate.init(instance.getServletConfig());
/*     */       } catch (ServletException e) {
/* 195 */         instance.getServletContext().log("Error initializing servlet delegate", e);
/* 196 */         return;
/*     */       }
/* 198 */       instance.delegate = servletDelegate;
/*     */     }
/*     */   }






/*     */   public static synchronized void unregisterServletDelegate(HttpServlet servletDelegate)
/*     */   {
/* 209 */     if (instance == null)
/*     */     {
/* 211 */       return;
/*     */     }
/*     */ 
/* 214 */     synchronized (instance) {
/* 215 */       if (instance.delegate == null) {
/* 216 */         throw new IllegalStateException("No servlet delegate is registered");
/*     */       }
/* 218 */       if (instance.delegate != servletDelegate) {
/* 219 */         throw new IllegalStateException("Servlet delegate does not match registered servlet delegate");
/*     */       }
/* 221 */       HttpServlet oldProxy = instance.delegate;
/* 222 */       instance.delegate = null;
/* 223 */       while (instance.delegateReferenceCount != 0)
/*     */         try {
/* 225 */           instance.wait();
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/*     */         }
/* 230 */       oldProxy.destroy();
/*     */     }
/*     */   }
/*     */ }
