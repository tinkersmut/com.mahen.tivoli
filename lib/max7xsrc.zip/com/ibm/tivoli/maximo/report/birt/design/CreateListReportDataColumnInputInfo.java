/*     */ package com.ibm.tivoli.maximo.report.birt.design;/*     */ /*     */ import java.io.Serializable;/*     */ 
/*     */ public class CreateListReportDataColumnInputInfo
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private int objectID;
/*     */   private String mboName;
/*     */   private String mboAttributeName;
/*     */   private String entityName;
/*     */   private String entityUIDColumnName;
/*     */   private String columnName;
/*     */   private String columnAlias;
/*     */   private int columnLength;
/*     */   private String title;
/*     */   private String mxDataType;
/*     */   private String birtDataType;
/*     */   private String width;
/*     */   private int sortLevel;
/*     */   private boolean sortAscending;
/*     */   private int groupLevel;
/*     */   private boolean groupAscending;
/*     */   private boolean visible;
/*     */   private boolean localized;
/*     */   private boolean richText;
/*     */ 
/*     */   public CreateListReportDataColumnInputInfo()
/*     */   {
/*  27 */     this.mboName = null;

/*     */ 
/*  30 */     this.mboAttributeName = null;


/*     */ 
/*  34 */     this.entityName = null;

/*     */ 
/*  37 */     this.entityUIDColumnName = null;


/*     */ 
/*  41 */     this.columnName = null;



/*     */ 
/*  46 */     this.columnAlias = null;


/*     */ 
/*  50 */     this.columnLength = 0;

/*     */ 
/*  53 */     this.title = null;


/*     */ 
/*  57 */     this.mxDataType = null;


/*     */ 
/*  61 */     this.birtDataType = null;


/*     */ 
/*  65 */     this.width = null;


/*     */ 
/*  69 */     this.sortLevel = 0;

/*     */ 
/*  72 */     this.sortAscending = true;


/*     */ 
/*  76 */     this.groupLevel = 0;

/*     */ 
/*  79 */     this.groupAscending = true;


/*     */ 
/*  83 */     this.visible = true;

/*     */ 
/*  86 */     this.localized = false;

/*     */ 
/*  89 */     this.richText = false;
/*     */   }





/*     */   public String getEntityName()
/*     */   {
/*  98 */     return this.entityName;
/*     */   }

/*     */   public void setEntityName(String name) {
/* 102 */     this.entityName = name;
/*     */   }

/*     */   public String getEntityUIDColumnName() {
/* 106 */     return this.entityUIDColumnName;
/*     */   }

/*     */   public void setEntityUIDColumnName(String name) {
/* 110 */     this.entityUIDColumnName = name;
/*     */   }

/*     */   public String getColumnName() {
/* 114 */     return this.columnName;
/*     */   }

/*     */   public void setColumnName(String name) {
/* 118 */     this.columnName = name;
/*     */   }

/*     */   public String getColumnAlias() {
/* 122 */     return this.columnAlias;
/*     */   }

/*     */   public void setColumnAlias(String alias) {
/* 126 */     this.columnAlias = alias;
/*     */   }

/*     */   public int getColumnLength() {
/* 130 */     return this.columnLength;
/*     */   }

/*     */   public void setColumnLength(int columnLength) {
/* 134 */     this.columnLength = columnLength;
/*     */   }

/*     */   public String getWidth() {
/* 138 */     return this.width;
/*     */   }

/*     */   public void setWidth(String width) {
/* 142 */     this.width = width;
/*     */   }

/*     */   public String getTitle() {
/* 146 */     return this.title;
/*     */   }

/*     */   public void setTitle(String title) {
/* 150 */     this.title = title;
/*     */   }

/*     */   public String getBirtDataType() {
/* 154 */     return this.birtDataType;
/*     */   }

/*     */   public void setBirtDataType(String birtDataType) {
/* 158 */     this.birtDataType = birtDataType;
/*     */   }

/*     */   public String getMxDataType() {
/* 162 */     return this.mxDataType;
/*     */   }

/*     */   public void setMxDataType(String mxDataType) {
/* 166 */     this.mxDataType = mxDataType;
/*     */   }

/*     */   public int getObjectID() {
/* 170 */     return this.objectID;
/*     */   }

/*     */   public void setObjectID(int objectID) {
/* 174 */     this.objectID = objectID;
/*     */   }

/*     */   public String getMboName() {
/* 178 */     return this.mboName;
/*     */   }

/*     */   public void setMboName(String mboName) {
/* 182 */     this.mboName = mboName;
/*     */   }

/*     */   public String getMboAttributeName() {
/* 186 */     return this.mboAttributeName;
/*     */   }

/*     */   public void setMboAttributeName(String mboAttributeName) {
/* 190 */     this.mboAttributeName = mboAttributeName;
/*     */   }

/*     */   public int getSortLevel() {
/* 194 */     return this.sortLevel;
/*     */   }

/*     */   public void setSortLevel(int sortLevel) {
/* 198 */     this.sortLevel = sortLevel;
/*     */   }

/*     */   public boolean isSortAscending() {
/* 202 */     return this.sortAscending;
/*     */   }

/*     */   public void setSortAscending(boolean sortAscending) {
/* 206 */     this.sortAscending = sortAscending;
/*     */   }

/*     */   public boolean isGroupAscending() {
/* 210 */     return this.groupAscending;
/*     */   }

/*     */   public void setGroupAscending(boolean groupAscending) {
/* 214 */     this.groupAscending = groupAscending;
/*     */   }

/*     */   public int getGroupLevel() {
/* 218 */     return this.groupLevel;
/*     */   }

/*     */   public void setGroupLevel(int groupLevel) {
/* 222 */     this.groupLevel = groupLevel;
/*     */   }

/*     */   public void setVisible(boolean displayField) {
/* 226 */     this.visible = displayField;
/*     */   }

/*     */   public boolean isVisible() {
/* 230 */     return this.visible;
/*     */   }

/*     */   public void setLocalized(boolean localized) {
/* 234 */     this.localized = localized;
/*     */   }

/*     */   public boolean isLocalized() {
/* 238 */     return this.localized;
/*     */   }

/*     */   public void setRichText(boolean richText) {
/* 242 */     this.richText = richText;
/*     */   }

/*     */   public boolean hasRichText() {
/* 246 */     return this.richText;
/*     */   }

/*     */   public Object clone()
/*     */   {
/* 251 */     CreateListReportDataColumnInputInfo clone = new CreateListReportDataColumnInputInfo();
/*     */ 
/* 253 */     clone.birtDataType = this.birtDataType;
/* 254 */     clone.entityName = this.entityName;
/* 255 */     clone.entityUIDColumnName = this.entityUIDColumnName;
/* 256 */     clone.columnName = this.columnName;
/* 257 */     clone.columnAlias = this.columnName;
/* 258 */     clone.columnLength = this.columnLength;
/* 259 */     clone.objectID = this.objectID;
/* 260 */     clone.mboName = this.mboName;
/* 261 */     clone.mboAttributeName = this.mboAttributeName;
/* 262 */     clone.mxDataType = this.mxDataType;
/* 263 */     clone.title = this.title;
/* 264 */     clone.width = this.width;
/* 265 */     clone.groupLevel = this.groupLevel;
/* 266 */     clone.groupAscending = this.groupAscending;
/* 267 */     clone.sortLevel = this.sortLevel;
/* 268 */     clone.sortAscending = this.sortAscending;
/* 269 */     clone.visible = this.visible;
/* 270 */     clone.localized = this.localized;
/* 271 */     clone.richText = this.richText;
/* 272 */     return clone;
/*     */   }
/*     */ }
