/*     */ package com.ibm.tivoli.maximo.report.birt.session;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.ejb.AccessLocalException;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.security.ejb.AccessTokenProviderHomeLocal;
/*     */ import psdi.security.ejb.AccessTokenProviderHomeRemote;
/*     */ import psdi.security.ejb.AccessTokenProviderLocal;
/*     */ import psdi.security.ejb.AccessTokenProviderRemote;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.MXServerInfo;
/*     */ import psdi.server.MXServerRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.RMISession;
/*     */ 






























/*     */ public class SimpleWebAppSession extends RMISession
/*     */ {
/*     */   private static final String ACCESSTOKENPROVIDER_LOCAL_REFNAME = "ejb/maximo/local/accesstokenprovider";
/*     */   private static final String ACCESSTOKENPROVIDER_REMOTE_REFNAME = "ejb/maximo/remote/accesstokenprovider";
/*     */   private MXServerInfo mxServerInfo;
/*     */   private String bindingName;
/*     */ 
/*     */   public SimpleWebAppSession()
/*     */   {
/*  62 */     this.mxServerInfo = MXServerInfo.getMXServerInfo();



/*     */ 
/*  67 */     this.bindingName = null;
/*     */   }







/*     */   protected MXServerRemote getMXServer()
/*     */     throws MXException, MalformedURLException, NotBoundException, RemoteException, UnknownHostException
/*     */   {
/*  79 */     if (this.remoteServer != null)
/*     */     {
/*  81 */       return this.remoteServer;


/*     */     }
/*     */ 
/*  86 */     if ((this.mxServerInfo.allowLocalObjects()) && (this.mxServerInfo.isStartedInProcess()))
/*     */     {
/*  88 */       this.remoteServer = MXServer.getMXServer();
/*  89 */       return this.remoteServer;


/*     */     }
/*     */ 
/*  94 */     this.bindingName = getBindingName();
/*     */ 
/*  96 */     if (this.bindingName == null)
/*     */     {
/*  98 */       throw new MXSystemException("system", "notboundexception");
/*     */     }
/*     */ 
/* 101 */     this.remoteServer = ((MXServerRemote)Naming.lookup(this.bindingName));
/*     */ 
/* 103 */     return this.remoteServer;
/*     */   }









/*     */   private String getBindingName()
/*     */     throws MXException
/*     */   {
/* 117 */     if (this.bindingName != null)
/*     */     {
/* 119 */       return this.bindingName;
/*     */     }
/*     */ 
/* 122 */     String bName = null;
/*     */ 
/* 124 */     InitialContext initCtx = null;

/*     */     try
/*     */     {
/* 128 */       initCtx = new InitialContext();


/*     */ 
/* 132 */       if (this.mxServerInfo.isStartedInProcess())
/*     */       {
/* 134 */         Object obj = initCtx.lookup("java:comp/env/ejb/maximo/local/accesstokenprovider");
/*     */ 
/* 136 */         AccessTokenProviderHomeLocal atkProviderHomeLocal = (AccessTokenProviderHomeLocal)obj;
/* 137 */         AccessTokenProviderLocal atkProviderLocal = atkProviderHomeLocal.create();
/* 138 */         bName = atkProviderLocal.getBindingName();
/*     */       }
/*     */       else
/*     */       {
/* 142 */         Object obj = initCtx.lookup("java:comp/env/ejb/maximo/remote/accesstokenprovider");
/*     */ 
/* 144 */         AccessTokenProviderHomeRemote atkProviderHomeRemote = null;
/* 145 */         atkProviderHomeRemote = (AccessTokenProviderHomeRemote)PortableRemoteObject.narrow(obj, AccessTokenProviderHomeRemote.class);
/*     */ 
/* 147 */         AccessTokenProviderRemote atkProviderRemote = atkProviderHomeRemote.create();
/* 148 */         bName = atkProviderRemote.getBindingName();

/*     */       }
/*     */ 
/*     */     }
/*     */     catch (AccessLocalException ex)
/*     */     {
/*     */     }
/*     */     catch (Throwable ne)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 163 */         initCtx.close();
/*     */       }
/*     */       catch (Exception ex) {
/*     */       }
/*     */     }
/* 168 */     return bName;
/*     */   }



/*     */   public synchronized void connect()
/*     */     throws MXException, RemoteException
/*     */   {
/* 176 */     super.connect();
/* 177 */     if ((!(this.mxServerInfo.allowLocalObjects())) || (!(this.mxServerInfo.isStartedInProcess())))
/*     */       return;
/* 179 */     super.getUserInfo().setLocalSession(true);
/*     */   }
/*     */ }
