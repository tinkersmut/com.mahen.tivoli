/*    */ package com.ibm.tivoli.maximo.report.birt.admin.batch;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 












/*    */ public class ReportParameterInfo
/*    */ {
/*    */   private HashMap<String, String> attributeMap;
/*    */ 
/*    */   public ReportParameterInfo()
/*    */   {
/* 25 */     this.attributeMap = new HashMap();
/*    */   }

/*    */   public void setAttribute(String attributeName, String attributeValue) {
/* 29 */     this.attributeMap.put(attributeName, attributeValue);
/*    */   }

/*    */   public String getAttribute(String attributeName)
/*    */   {
/* 34 */     return ((String)this.attributeMap.get(attributeName));
/*    */   }

/*    */   public void removeAttribute(String attributeName)
/*    */   {
/* 39 */     this.attributeMap.remove(attributeName);
/*    */   }

/*    */   public void reset()
/*    */   {
/* 44 */     this.attributeMap = new HashMap();
/*    */   }

/*    */   public Iterator getAttributes()
/*    */   {
/* 49 */     return this.attributeMap.keySet().iterator();
/*    */   }
/*    */ }
