/*    */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 















/*    */ public class ReportParameterData
/*    */   implements Serializable
/*    */ {
/*    */   private HashMap reportParameterDetails;
/*    */ 
/*    */   public ReportParameterData()
/*    */   {
/* 30 */     this.reportParameterDetails = new HashMap();
/*    */   }

/*    */   public void addParameter(String paramName, String value) {
/* 34 */     this.reportParameterDetails.put(paramName, value);
/*    */   }

/*    */   public String getParameter(String paramName)
/*    */   {
/* 39 */     return ((String)this.reportParameterDetails.get(paramName));
/*    */   }

/*    */   public void clearParameter(String paramName)
/*    */   {
/* 44 */     this.reportParameterDetails.remove(paramName);
/*    */   }

/*    */   public void clearAllParameters()
/*    */   {
/* 49 */     this.reportParameterDetails.clear();
/*    */   }

/*    */   public Iterator getParameters()
/*    */   {
/* 54 */     return this.reportParameterDetails.keySet().iterator();
/*    */   }
/*    */ }
