/*     */ package com.ibm.tivoli.maximo.report.birt.datasource;
/*     */ 




/*     */ public class DataSourceInfo
/*     */ {
/*     */   private String name;
/*     */   private String url;
/*     */   private String driver;
/*     */   private String userName;
/*     */   private String password;
/*     */   private String schemaOwner;
/*     */   protected String sslConnection;
/*     */   protected String sslTrustStoreLocation;
/*     */   protected String sslTrustStorePassword;
/*     */ 
/*     */   public DataSourceInfo()
/*     */   {
/*  21 */     this.name = null;
/*  22 */     this.url = null;
/*  23 */     this.driver = null;
/*  24 */     this.userName = null;
/*  25 */     this.password = null;
/*  26 */     this.schemaOwner = null;


/*     */ 
/*  30 */     this.sslConnection = null;
/*  31 */     this.sslTrustStoreLocation = null;
/*  32 */     this.sslTrustStorePassword = null;
/*     */   }

/*     */   public String getDriver()
/*     */   {
/*  37 */     return this.driver;
/*     */   }

/*     */   public void setDriver(String driver)
/*     */   {
/*  42 */     this.driver = driver;
/*     */   }

/*     */   public String getName()
/*     */   {
/*  47 */     return this.name;
/*     */   }

/*     */   public void setName(String name)
/*     */   {
/*  52 */     this.name = name;
/*     */   }

/*     */   public String getPassword()
/*     */   {
/*  57 */     return this.password;
/*     */   }

/*     */   public void setPassword(String password)
/*     */   {
/*  62 */     this.password = password;
/*     */   }

/*     */   public String getSchemaOwner()
/*     */   {
/*  67 */     return this.schemaOwner;
/*     */   }

/*     */   public void setSchemaOwner(String schemaOwner)
/*     */   {
/*  72 */     this.schemaOwner = schemaOwner;
/*     */   }

/*     */   public String getUrl()
/*     */   {
/*  77 */     return this.url;
/*     */   }

/*     */   public void setUrl(String url)
/*     */   {
/*  82 */     this.url = url;
/*     */   }

/*     */   public String getUserName()
/*     */   {
/*  87 */     return this.userName;
/*     */   }

/*     */   public void setUserName(String userName)
/*     */   {
/*  92 */     this.userName = userName;
/*     */   }

/*     */   public String getSslConnection() {
/*  96 */     return this.sslConnection;
/*     */   }

/*     */   public void setSslConnection(String sslConnection) {
/* 100 */     this.sslConnection = sslConnection;
/*     */   }

/*     */   public String getSslTrustStoreLocation() {
/* 104 */     return this.sslTrustStoreLocation;
/*     */   }

/*     */   public void setSslTrustStoreLocation(String sslTrustStoreLocation) {
/* 108 */     this.sslTrustStoreLocation = sslTrustStoreLocation;
/*     */   }

/*     */   public String getSslTrustStorePassword() {
/* 112 */     return this.sslTrustStorePassword;
/*     */   }

/*     */   public void setSslTrustStorePassword(String sslTrustStorePassword) {
/* 116 */     this.sslTrustStorePassword = sslTrustStorePassword;
/*     */   }
/*     */ }
