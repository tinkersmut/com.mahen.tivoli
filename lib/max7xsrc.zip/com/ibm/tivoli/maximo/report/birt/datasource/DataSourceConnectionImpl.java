/*    */ package com.ibm.tivoli.maximo.report.birt.datasource;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ 















/*    */ public class DataSourceConnectionImpl
/*    */   implements DataSourceConnection
/*    */ {
/* 23 */   private Connection connection = null;
/*    */ 
/*    */   public DataSourceConnectionImpl(Connection connection)
/*    */   {
/* 27 */     this.connection = connection;
/*    */   }

/*    */   public Connection getConnection()
/*    */   {
/* 32 */     return this.connection;
/*    */   }
/*    */ }
