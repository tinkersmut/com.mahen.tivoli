/*     */ package com.ibm.tivoli.maximo.report.birt.engine;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportRuntimeTempLocation;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 





















/*     */ public class MXSystemOSGiFrameworkLauncher
/*     */ {
/*     */   protected static final String FILE_SCHEME = "file:";
/*     */   protected static final String FRAMEWORK_BUNDLE_NAME = "org.eclipse.osgi";
/*     */   protected static final String STARTER = "org.eclipse.core.runtime.adaptor.EclipseStarter";
/*     */   protected static final String NULL_IDENTIFIER = "@null";
/*     */   protected static final String OSGI_FRAMEWORK = "osgi.framework";
/*     */   protected static final String OSGI_INSTANCE_AREA = "osgi.instance.area";
/*     */   protected static final String OSGI_CONFIGURATION_AREA = "osgi.configuration.area";
/*     */   protected static final String OSGI_INSTALL_AREA = "osgi.install.area";
/*     */   protected static final String LAUNCH_INI = "launch.ini";
/*     */   private File platformDirectory;
/*     */   private ClassLoader frameworkContextClassLoader;
/*     */   private URLClassLoader frameworkClassLoader;
/*  62 */   private ReportLogger reportLogger = null;
/*     */ 
/*     */   public MXSystemOSGiFrameworkLauncher()
/*     */   {
/*  66 */     this.reportLogger = ReportLoggerFactory.getLogger("maximo.report.birt");
/*     */   }












/*     */   public synchronized void deploy()
/*     */   {
/*  82 */     if (this.platformDirectory != null)
/*     */     {
/*  84 */       return;
/*     */     }
/*     */ 
/*  87 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/*  89 */       this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (deploying)");
/*     */     }
/*     */ 
/*  92 */     String dir = PlatformLocation.getPlatformLocation();
/*  93 */     this.platformDirectory = new File(dir);
/*     */ 
/*  95 */     if (!(this.reportLogger.isDebugEnabled()))
/*     */       return;
/*  97 */     this.reportLogger.debug(new StringBuilder().append("MXSystemOSGiFrameworkLauncher (platform) = ").append(this.platformDirectory).toString());
/*  98 */     this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (deployed)");
/*     */   }





/*     */   public synchronized void undeploy()
/*     */   {
/* 107 */     if (this.platformDirectory == null)
/*     */     {
/* 109 */       return;
/*     */     }
/*     */ 
/* 112 */     if (this.frameworkClassLoader != null)
/*     */     {
/* 114 */       throw new IllegalStateException("Could not undeploy Framework - (not stopped)");
/*     */     }
/*     */ 
/* 117 */     deleteDirectory(new File(this.platformDirectory, "configuration-system"));
/* 118 */     deleteDirectory(new File(this.platformDirectory, "features"));
/* 119 */     deleteDirectory(new File(this.platformDirectory, "plugins"));
/* 120 */     deleteDirectory(new File(this.platformDirectory, "workspace-system"));
/*     */ 
/* 122 */     new File(this.platformDirectory, ".eclipseproduct").delete();
/*     */ 
/* 124 */     this.platformDirectory = null;
/*     */   }







/*     */   public synchronized void start()
/*     */   {
/* 135 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 137 */       this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (starting)");
/*     */     }
/*     */ 
/* 140 */     if (this.platformDirectory == null)
/*     */     {
/* 142 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 144 */         this.reportLogger.error("MXSystemOSGiFrameworkLauncher - Could not start the Framework - (it is not deployed)");
/*     */       }
/*     */ 
/* 147 */       throw new IllegalStateException("Could not start the Framework - (not deployed)");
/*     */     }
/*     */ 
/* 150 */     if (this.frameworkClassLoader != null)
/*     */     {
/* 152 */       return;
/*     */     }
/*     */ 
/* 155 */     System.setProperty("user.projectclasspath", ReportRuntimeTempLocation.getScriptsLibLocation());
/*     */ 
/* 157 */     Map initalPropertyMap = buildInitialPropertyMap();
/* 158 */     String[] args = buildCommandLineArguments();
/* 159 */     String oldValue = null;
/* 160 */     boolean setProperty = false;
/*     */ 
/* 162 */     ClassLoader original = Thread.currentThread().getContextClassLoader();
/*     */     try
/*     */     {
/* 165 */       oldValue = System.getProperty("osgi.framework.useSystemProperties");
/*     */ 
/* 167 */       System.setProperty("osgi.framework.useSystemProperties", "false");
/* 168 */       setProperty = true;
/*     */ 
/* 170 */       URL[] osgiURLArray = { new URL((String)initalPropertyMap.get("osgi.framework")) };
/* 171 */       this.frameworkClassLoader = new ChildFirstURLClassLoader(osgiURLArray, super.getClass().getClassLoader());
/*     */ 
/* 173 */       Properties fPro = getFrameworkInternalProperties(this.frameworkClassLoader);
/* 174 */       Properties sysPro = System.getProperties();
/* 175 */       if (sysPro != fPro)
/*     */       {
/* 177 */         if (this.reportLogger.isDebugEnabled())
/*     */         {
/* 179 */           this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (starting) using custom properties");
/*     */         }
/*     */ 
/* 182 */         Vector osgiProperties = new Vector();
/* 183 */         Enumeration keyEnum = fPro.keys();
/* 184 */         while (keyEnum.hasMoreElements()) {
/* 185 */           String key = (String)keyEnum.nextElement();
/* 186 */           if (key.indexOf("osgi.") >= 0)
/*     */           {
/* 188 */             if (key.equalsIgnoreCase("osgi.framework.useSystemProperties"))
/*     */             {
/*     */               continue;
/*     */             }
/*     */ 
/* 193 */             osgiProperties.add(key);
/* 194 */             if (this.reportLogger.isDebugEnabled())
/*     */             {
/* 196 */               this.reportLogger.debug(new StringBuilder().append("MXSystemOSGiFrameworkLauncher (starting) removing system property from our list: ").append(key).toString());
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 201 */         int pSize = osgiProperties.size();
/* 202 */         for (int i = 0; i < pSize; ++i) {
/* 203 */           fPro.remove(osgiProperties.elementAt(i));
/*     */         }
/*     */ 
/* 206 */         if (this.reportLogger.isDebugEnabled())
/*     */         {
/* 208 */           this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (starting) removing eclipse.security property from our list");
/*     */         }
/*     */ 
/* 211 */         fPro.remove("eclipse.security");



/*     */       }
/* 216 */       else if (this.reportLogger.isDebugEnabled())
/*     */       {
/* 218 */         this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (starting) using system properties");


/*     */       }
/*     */ 
/* 223 */       Class clazz = this.frameworkClassLoader.loadClass("org.eclipse.core.runtime.adaptor.EclipseStarter");
/*     */ 
/* 225 */       Method setInitialProperties = clazz.getMethod("setInitialProperties", new Class[] { Map.class });
/* 226 */       setInitialProperties.invoke(null, new Object[] { initalPropertyMap });
/*     */ 
/* 228 */       Method runMethod = clazz.getMethod("run", new Class[] { [Ljava.lang.String.class, Runnable.class });
/* 229 */       runMethod.invoke(null, new Object[] { args, null });
/* 230 */       this.frameworkContextClassLoader = Thread.currentThread().getContextClassLoader();






/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 243 */       Thread.currentThread().setContextClassLoader(original);
/*     */ 
/* 245 */       if (setProperty)
/*     */       {
/* 247 */         if (oldValue == null)
/*     */         {
/* 249 */           System.clearProperty("osgi.framework.useSystemProperties");
/*     */         }
/*     */         else
/*     */         {
/* 253 */           System.setProperty("osgi.framework.useSystemProperties", "true");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 258 */     if (!(this.reportLogger.isDebugEnabled()))
/*     */       return;
/* 260 */     this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (started)");
/*     */   }


/*     */   public Properties getFrameworkInternalProperties(ClassLoader cl)
/*     */   {
/*     */     try
/*     */     {
/* 268 */       Class clazz = cl.loadClass("org.eclipse.osgi.framework.internal.core.FrameworkProperties");
/*     */ 
/* 270 */       Method runMethod = clazz.getMethod("getProperties", new Class[0]);
/* 271 */       Properties p = (Properties)runMethod.invoke(null, new Object[0]);
/* 272 */       return p;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 276 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 278 */         this.reportLogger.error("Failed to get properties from org.eclipse.osgi.framework.internal.core.FrameworkProperties", e);
/*     */       }
/*     */     }
/* 281 */     return null;
/*     */   }







/*     */   protected Map buildInitialPropertyMap()
/*     */   {
/* 292 */     Map initialPropertyMap = new HashMap();
/*     */ 
/* 294 */     String launchIniFile = new StringBuilder().append(this.platformDirectory).append(File.separator).append("launch-system").append(File.separator).append("launch.ini").toString();
/* 295 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 297 */       this.reportLogger.debug(new StringBuilder().append("MXSystemOSGiFrameworkLauncher (starting) launching from: ").append(launchIniFile).toString());
/*     */     }
/*     */ 
/* 300 */     Properties launchProperties = loadProperties(launchIniFile);
/* 301 */     for (Iterator it = launchProperties.entrySet().iterator(); it.hasNext(); )
/*     */     {
/* 303 */       Map.Entry entry = (Map.Entry)it.next();
/* 304 */       if (entry.getValue().equals("@null"))
/*     */       {
/* 306 */         initialPropertyMap.remove(entry.getKey());
/*     */       }
/*     */       else
/*     */       {
/* 310 */         initialPropertyMap.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 317 */       if (!(initialPropertyMap.containsKey("osgi.install.area")))
/*     */       {
/* 319 */         initialPropertyMap.put("osgi.install.area", this.platformDirectory.toURL().toExternalForm());

/*     */       }
/*     */ 
/* 323 */       if (initialPropertyMap.get("osgi.configuration.area") == null)
/*     */       {
/* 325 */         File configurationDirectory = new File(this.platformDirectory, "configuration-system");
/* 326 */         if (!(configurationDirectory.exists()))
/*     */         {
/* 328 */           configurationDirectory.mkdirs();
/*     */         }
/*     */ 
/* 331 */         initialPropertyMap.put("osgi.configuration.area", configurationDirectory.toURL().toExternalForm());

/*     */       }
/*     */ 
/* 335 */       if (initialPropertyMap.get("osgi.instance.area") == null)
/*     */       {
/* 337 */         File workspaceDirectory = new File(this.platformDirectory, "workspace-system");
/* 338 */         if (!(workspaceDirectory.exists()))
/*     */         {
/* 340 */           workspaceDirectory.mkdirs();
/*     */         }
/*     */ 
/* 343 */         initialPropertyMap.put("osgi.instance.area", workspaceDirectory.toURL().toExternalForm());

/*     */       }
/*     */ 
/* 347 */       if (!(initialPropertyMap.containsKey("osgi.framework")))

/*     */       {
/* 350 */         String installArea = (String)initialPropertyMap.get("osgi.install.area");

/*     */ 
/* 353 */         if (installArea.startsWith("file:"))
/*     */         {
/* 355 */           installArea = installArea.substring("file:".length());
/*     */         }
/*     */ 
/* 358 */         String path = new File(installArea, "plugins").toString();
/* 359 */         path = searchFor("org.eclipse.osgi", path);
/* 360 */         if (path == null)
/*     */         {
/* 362 */           throw new RuntimeException("Could not find framework");
/*     */         }
/*     */ 
/* 365 */         initialPropertyMap.put("osgi.framework", new File(path).toURL().toExternalForm());
/*     */       }
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/* 370 */       throw new RuntimeException("Error establishing location");
/*     */     }
/*     */ 
/* 373 */     return initialPropertyMap;
/*     */   }

/*     */   protected String[] buildCommandLineArguments()
/*     */   {
/* 378 */     List args = new ArrayList();
/* 379 */     args.add("-nosplash");
/*     */ 
/* 381 */     return ((String[])(String[])args.toArray(new String[0]));
/*     */   }






/*     */   public synchronized void stop()
/*     */   {
/* 391 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 393 */       this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (stopping)");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 398 */       if (this.platformDirectory == null)
/*     */       {
/*     */         return;
/*     */       }
/*     */ 
/* 403 */       if (this.frameworkClassLoader == null)
/*     */       {
/*     */         return;
/*     */       }
/*     */ 
/* 408 */       ClassLoader original = Thread.currentThread().getContextClassLoader();
/*     */       try
/*     */       {
/* 411 */         Class clazz = this.frameworkClassLoader.loadClass("org.eclipse.core.runtime.adaptor.EclipseStarter");
/* 412 */         Method method = clazz.getDeclaredMethod("shutdown", (Class[])null);
/* 413 */         Thread.currentThread().setContextClassLoader(this.frameworkContextClassLoader);
/* 414 */         method.invoke(clazz, (Object[])null);



/*     */         try
/*     */         {
/* 420 */           clazz = super.getClass().getClassLoader().loadClass("org.apache.commons.logging.LogFactory");
/* 421 */           method = clazz.getDeclaredMethod("release", new Class[] { ClassLoader.class });
/* 422 */           method.invoke(clazz, new Object[] { this.frameworkContextClassLoader });
/*     */         }
/*     */         catch (ClassNotFoundException e)
/*     */         {
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 431 */         if (this.reportLogger.isErrorEnabled())
/*     */         {
/* 433 */           this.reportLogger.error("Failed to stop OSGi framework.", e);



/*     */         }
/*     */ 
/*     */       }/*     */       finally/*     */       {/* 439 */         this.frameworkClassLoader = null;/* 439 */         this.frameworkClassLoader = null;
/* 440 */         this.frameworkContextClassLoader = null;/* 440 */         this.frameworkContextClassLoader = null;
/* 441 */         Thread.currentThread().setContextClassLoader(original);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 446 */       if (this.reportLogger.isDebugEnabled())
/*     */ 
/*     */       {/* 448 */         return;/* 448 */         this.reportLogger.debug("MXSystemOSGiFrameworkLauncher (stopped)");
/*     */       }
/*     */     }
/*     */   }







/*     */   protected static boolean deleteDirectory(File directory)
/*     */   {
/* 461 */     if ((directory.exists()) && (directory.isDirectory()))
/*     */     {
/* 463 */       File[] files = directory.listFiles();
/* 464 */       for (int i = 0; i < files.length; ++i)
/*     */       {
/* 466 */         if (files[i].isDirectory())
/*     */         {
/* 468 */           deleteDirectory(files[i]);
/*     */         }
/*     */         else
/*     */         {
/* 472 */           files[i].delete();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 477 */     return directory.delete();
/*     */   }






/*     */   public synchronized ClassLoader getFrameworkContextClassLoader()
/*     */   {
/* 487 */     return this.frameworkContextClassLoader;
/*     */   }






/*     */   public synchronized ClassLoader getFrameworkClassLoader()
/*     */   {
/* 497 */     return this.frameworkClassLoader;
/*     */   }





/*     */   protected synchronized File getPlatformDirectory()
/*     */   {
/* 506 */     return this.platformDirectory;
/*     */   }







/*     */   protected Properties loadProperties(String resource)
/*     */   {
/* 517 */     Properties result = new Properties();
/* 518 */     InputStream in = null;
/*     */     try
/*     */     {
/* 521 */       URL location = new File(resource).toURL();
/* 522 */       if (location != null)
/*     */       {
/* 524 */         in = location.openStream();
/* 525 */         result.load(in);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 537 */       if (in != null)
/*     */         try {
/* 539 */           in.close();
/*     */         }
/*     */         catch (IOException e) {
/*     */         }
/*     */     }
/* 544 */     return result;
/*     */   }










/*     */   protected String searchFor(String target, String start)
/*     */   {
/* 558 */     FileFilter filter = new FileFilter(target)
/*     */     {
/*     */       public boolean accept(File candidate)
/*     */       {
/* 562 */         return ((candidate.getName().equals(this.val$target)) || (candidate.getName().startsWith(this.val$target + "_")));

/*     */       }
/*     */     };
/* 566 */     File[] candidates = new File(start).listFiles(filter);
/* 567 */     if (candidates == null)
/*     */     {
/* 569 */       return null;
/*     */     }
/*     */ 
/* 572 */     String[] arrays = new String[candidates.length];
/* 573 */     for (int i = 0; i < arrays.length; ++i)
/*     */     {
/* 575 */       arrays[i] = candidates[i].getName();
/*     */     }
/*     */ 
/* 578 */     int result = findMax(arrays);
/* 579 */     if (result == -1)
/*     */     {
/* 581 */       return null;
/*     */     }
/*     */ 
/* 584 */     return new StringBuilder().append(candidates[result].getAbsolutePath().replace(File.separatorChar, '/')).append((candidates[result].isDirectory()) ? "/" : "").toString();
/*     */   }

/*     */   protected int findMax(String[] candidates)
/*     */   {
/* 589 */     int result = -1;
/* 590 */     Object maxVersion = null;
/* 591 */     for (int i = 0; i < candidates.length; ++i)
/*     */     {
/* 593 */       String name = candidates[i];
/* 594 */       String version = "";
/*     */ 
/* 596 */       int index = name.indexOf(95);
/* 597 */       if (index != -1)
/*     */       {
/* 599 */         version = name.substring(index + 1);
/*     */       }
/*     */ 
/* 602 */       Object currentVersion = getVersionElements(version);
/* 603 */       if (maxVersion == null)
/*     */       {
/* 605 */         result = i;
/* 606 */         maxVersion = currentVersion;
/*     */       }
/*     */       else
/*     */       {
/* 610 */         if (compareVersion((Object[])(Object[])maxVersion, (Object[])(Object[])currentVersion) >= 0)
/*     */           continue;
/* 612 */         result = i;
/* 613 */         maxVersion = currentVersion;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 618 */     return result;
/*     */   }











/*     */   private int compareVersion(Object[] left, Object[] right)
/*     */   {
/* 633 */     int result = ((Integer)left[0]).compareTo((Integer)right[0]);
/* 634 */     if (result != 0)
/*     */     {
/* 636 */       return result;
/*     */     }
/*     */ 
/* 639 */     result = ((Integer)left[1]).compareTo((Integer)right[1]);
/* 640 */     if (result != 0)
/*     */     {
/* 642 */       return result;
/*     */     }
/*     */ 
/* 645 */     result = ((Integer)left[2]).compareTo((Integer)right[2]);
/* 646 */     if (result != 0)
/*     */     {
/* 648 */       return result;
/*     */     }
/*     */ 
/* 651 */     return ((String)left[3]).compareTo((String)right[3]);
/*     */   }










/*     */   private Object[] getVersionElements(String version)
/*     */   {
/* 665 */     if (version.endsWith(".jar"))
/*     */     {
/* 667 */       version = version.substring(0, version.length() - 4);
/*     */     }
/*     */ 
/* 670 */     Object[] result = { new Integer(0), new Integer(0), new Integer(0), "" };
/* 671 */     StringTokenizer t = new StringTokenizer(version, ".");
/*     */ 
/* 673 */     int i = 0;
/* 674 */     while ((t.hasMoreTokens()) && (i < 4))
/*     */     {
/* 676 */       String token = t.nextToken();
/* 677 */       if (i < 3);


/*     */       try
/*     */       {
/* 682 */         result[(i++)] = new Integer(token);

/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 687 */         break label139:




/*     */ 
/* 693 */         result[(i++)] = token;
/*     */       }
/*     */     }
/*     */ 
/* 697 */     label139: return result;
/*     */   }





/*     */   protected class ChildFirstURLClassLoader extends URLClassLoader
/*     */   {
/*     */     public ChildFirstURLClassLoader(URL[] paramArrayOfURL)
/*     */     {
/* 708 */       super(paramArrayOfURL);
/*     */     }

/*     */     public ChildFirstURLClassLoader(URL[] paramArrayOfURL, ClassLoader paramClassLoader)
/*     */     {
/* 713 */       super(paramArrayOfURL, parent);
/*     */     }

/*     */     public ChildFirstURLClassLoader(URL[] paramArrayOfURL, ClassLoader paramClassLoader, URLStreamHandlerFactory paramURLStreamHandlerFactory)
/*     */     {
/* 718 */       super(paramArrayOfURL, paramClassLoader, paramURLStreamHandlerFactory);
/*     */     }

/*     */     public URL getResource(String name)
/*     */     {
/* 723 */       URL resource = findResource(name);
/* 724 */       if (resource == null)
/*     */       {
/* 726 */         ClassLoader parent = getParent();
/* 727 */         if (parent != null)
/*     */         {
/* 729 */           resource = parent.getResource(name);
/*     */         }
/*     */       }
/*     */ 
/* 733 */       return resource;
/*     */     }

/*     */     protected synchronized Class loadClass(String name, boolean resolve) throws ClassNotFoundException
/*     */     {
/* 738 */       Class clazz = findLoadedClass(name);
/* 739 */       if (clazz == null)
/*     */       {
/*     */         try
/*     */         {
/* 743 */           clazz = findClass(name);
/*     */         }
/*     */         catch (ClassNotFoundException e)
/*     */         {
/* 747 */           ClassLoader parent = getParent();
/* 748 */           if (parent != null)
/*     */           {
/* 750 */             synchronized (parent)
/*     */             {
/* 752 */               clazz = parent.loadClass(name);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 757 */             ClassLoader sysClassLoader = getSystemClassLoader();
/* 758 */             synchronized (sysClassLoader)
/*     */             {
/* 760 */               clazz = getSystemClassLoader().loadClass(name);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 766 */       if (resolve)
/*     */       {
/* 768 */         resolveClass(clazz);
/*     */       }
/*     */ 
/* 771 */       return ((Class)clazz);
/*     */     }
/*     */   }
/*     */ }
