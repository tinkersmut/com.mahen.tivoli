/*    */ package com.ibm.tivoli.maximo.report.birt.queue;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.admin.ActiveReportThreadManager;
/*    */ import com.ibm.tivoli.maximo.report.birt.admin.ActiveReportThreadNotifier;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.util.MXException;
/*    */ 


















/*    */ public class ScheduledActiveReportThreadNotifier
/*    */   implements ActiveReportThreadNotifier
/*    */ {
/*    */   private String threadName;
/*    */   private String reportName;
/*    */   private String appName;
/*    */   private String userName;
/* 33 */   private ActiveReportThreadManager activeReportThreadManager = null;
/*    */ 
/*    */   public ScheduledActiveReportThreadNotifier()
/*    */   {
/* 37 */     this.activeReportThreadManager = ActiveReportThreadManager.getActiveReportThreadManager();
/*    */   }

/*    */   public String getAppName()
/*    */   {
/* 42 */     return this.appName;
/*    */   }

/*    */   public void setAppName(String appName)
/*    */   {
/* 47 */     this.appName = appName;
/*    */   }

/*    */   public String getReportName()
/*    */   {
/* 52 */     return this.reportName;
/*    */   }

/*    */   public void setReportName(String reportName)
/*    */   {
/* 57 */     this.reportName = reportName;
/*    */   }

/*    */   public String getThreadName()
/*    */   {
/* 62 */     return this.threadName;
/*    */   }

/*    */   public void setThreadName(String threadName)
/*    */   {
/* 67 */     this.threadName = threadName;
/*    */   }

/*    */   public String getUserName()
/*    */   {
/* 72 */     return this.userName;
/*    */   }

/*    */   public void setUserName(String userName)
/*    */   {
/* 77 */     this.userName = userName;
/*    */   }

/*    */   public Long addActiveThread() throws MXException, RemoteException
/*    */   {
/* 82 */     return this.activeReportThreadManager.addActiveThread(this.threadName, this.reportName, this.appName, this.userName, true);
/*    */   }

/*    */   public void removeActiveThread() throws MXException, RemoteException
/*    */   {
/* 87 */     this.activeReportThreadManager.removeActiveThread(this.threadName);
/*    */   }

/*    */   public void renewActiveThread() throws MXException, RemoteException
/*    */   {
/* 92 */     this.activeReportThreadManager.renewActiveThread(this.threadName);
/*    */   }

/*    */   public Boolean isReportJobCancelled(Long reportJobId) throws MXException, RemoteException
/*    */   {
/* 97 */     return new Boolean(this.activeReportThreadManager.isReportJobCancelled(reportJobId.longValue()));
/*    */   }
/*    */ }
