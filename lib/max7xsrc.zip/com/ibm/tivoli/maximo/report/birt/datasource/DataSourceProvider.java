/*    */ package com.ibm.tivoli.maximo.report.birt.datasource;
/*    */ 















/*    */ public class DataSourceProvider
/*    */ {
/* 21 */   private static DataSourceProvider dsProvider = new DataSourceProvider();
/*    */   private DataSourceCache dataSourceCache;
/*    */ 
/*    */   public static DataSourceProvider getDataSourceProvider()
/*    */   {
/* 25 */     return dsProvider;/*    */   }
/*    */   public DataSourceProvider()
/*    */   {
/* 28 */     this.dataSourceCache = DataSourceCache.getDataSourceCache();
/*    */   }
/*    */   public DataSource getDataSource(String name)
/*    */   {
/* 32 */     DataSourceConnectionPool dsPool = this.dataSourceCache.getDataSourceConnectionPool(name);
/*    */ 
/* 34 */     DataSource ds = new DataSourceImpl(dsPool);
/* 35 */     return ds;
/*    */   }
/*    */ }
