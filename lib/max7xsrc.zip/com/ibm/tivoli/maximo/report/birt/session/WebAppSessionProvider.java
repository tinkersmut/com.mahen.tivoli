/*     */ package com.ibm.tivoli.maximo.report.birt.session;
/*     */ 
/*     */ import psdi.util.MXSession;
/*     */ import psdi.util.MXSessionImplFactory;
/*     */ 














































/*     */ public class WebAppSessionProvider
/*     */ {
/*  32 */   private static WebAppSessionProvider webAppSessionProvider = new WebAppSessionProvider();
/*     */ 
/*  38 */   private boolean useAppServerSecurity = false;
/*     */ 
/*  44 */   private MXSessionImplFactory sessionFactory = null;
/*     */ 
/*     */   public static MXSession getNewWebAppSession()
/*     */   {
/*  62 */     return webAppSessionProvider.getNewSession();
/*     */   }






/*     */   private WebAppSessionProvider()
/*     */   {
/*  72 */     this.useAppServerSecurity = WebAppEnv.useAppServerSecurity();
/*     */   }







/*     */   private MXSession getNewSession()
/*     */   {
/*  83 */     if (this.sessionFactory == null)
/*     */     {
/*  85 */       if (this.useAppServerSecurity)
/*     */       {
/*  87 */         synchronized (this)
/*     */         {
/*  89 */           this.sessionFactory = new SecuredWebAppSessionFactory();
/*     */         }
/*     */ 
/*     */       }
/*     */       else {
/*  94 */         synchronized (this)
/*     */         {
/*  96 */           this.sessionFactory = new SimpleWebAppSessionFactory();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 101 */     return this.sessionFactory.getNewSession();
/*     */   }
/*     */ }
