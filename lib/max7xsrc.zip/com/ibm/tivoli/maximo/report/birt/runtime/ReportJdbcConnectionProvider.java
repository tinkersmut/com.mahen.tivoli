package com.ibm.tivoli.maximo.report.birt.runtime;

import java.sql.Connection;

public abstract interface ReportJdbcConnectionProvider
{
  public abstract Connection getConnection();

  public abstract void freeConnection();
}
