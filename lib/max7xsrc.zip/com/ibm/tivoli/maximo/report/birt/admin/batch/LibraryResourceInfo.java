package com.ibm.tivoli.maximo.report.birt.admin.batch;

public class LibraryResourceInfo extends ReportResourceInfo
{
}
