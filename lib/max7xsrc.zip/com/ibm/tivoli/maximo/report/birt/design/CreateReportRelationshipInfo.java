/*     */ package com.ibm.tivoli.maximo.report.birt.design;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 








/*     */ public class CreateReportRelationshipInfo
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private int parentObjectID;
/*     */   private String parentObjectName;
/*     */   private int childObjectID;
/*     */   private String childObjectName;
/*     */   private String parentEntityName;
/*     */   private String childEntityName;
/*     */   private String whereClause;
/*     */   private boolean required;
/*     */ 
/*     */   public CreateReportRelationshipInfo()
/*     */   {
/*  27 */     this.parentObjectName = null;




/*     */ 
/*  33 */     this.childObjectName = null;

/*     */ 
/*  36 */     this.parentEntityName = null;

/*     */ 
/*  39 */     this.childEntityName = null;

/*     */ 
/*  42 */     this.whereClause = null;

/*     */ 
/*  45 */     this.required = true;
/*     */   }




/*     */   public int getParentObjectID()
/*     */   {
/*  53 */     return this.parentObjectID;
/*     */   }

/*     */   public void setParentObjectID(int parentObjectID) {
/*  57 */     this.parentObjectID = parentObjectID;
/*     */   }

/*     */   public String getParentObjectName() {
/*  61 */     return this.parentObjectName;
/*     */   }

/*     */   public void setParentObjectName(String mboName) {
/*  65 */     this.parentObjectName = mboName;
/*     */   }

/*     */   public int getChildObjectID() {
/*  69 */     return this.childObjectID;
/*     */   }

/*     */   public void setChildObjectID(int childObjectID) {
/*  73 */     this.childObjectID = childObjectID;
/*     */   }

/*     */   public String getChildObjectName() {
/*  77 */     return this.childObjectName;
/*     */   }

/*     */   public void setChildObjectName(String mboName) {
/*  81 */     this.childObjectName = mboName;
/*     */   }

/*     */   public String getParentEntityName() {
/*  85 */     return this.parentEntityName;
/*     */   }

/*     */   public void setParentEntityName(String entityName) {
/*  89 */     this.parentEntityName = entityName;
/*     */   }

/*     */   public String getChildEntityName() {
/*  93 */     return this.childEntityName;
/*     */   }

/*     */   public void setChildEntityName(String entityName) {
/*  97 */     this.childEntityName = entityName;
/*     */   }

/*     */   public String getWhereClause() {
/* 101 */     return this.whereClause;
/*     */   }

/*     */   public void setWhereClause(String whereClause) {
/* 105 */     this.whereClause = whereClause;
/*     */   }

/*     */   public boolean isRequired() {
/* 109 */     return this.required;
/*     */   }

/*     */   public void setRequired(boolean required) {
/* 113 */     this.required = required;
/*     */   }

/*     */   public Object clone()
/*     */   {
/* 118 */     CreateReportRelationshipInfo clone = new CreateReportRelationshipInfo();
/*     */ 
/* 120 */     clone.parentObjectID = this.parentObjectID;
/* 121 */     clone.parentObjectName = this.parentObjectName;
/* 122 */     clone.childObjectID = this.childObjectID;
/* 123 */     clone.childObjectName = this.childObjectName;
/* 124 */     clone.parentEntityName = this.parentEntityName;
/* 125 */     clone.childEntityName = this.childEntityName;
/* 126 */     clone.whereClause = this.whereClause;
/* 127 */     clone.required = this.required;
/*     */ 
/* 129 */     return clone;
/*     */   }
/*     */ }
