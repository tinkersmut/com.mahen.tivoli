/*    */ package com.ibm.tivoli.maximo.report.birt.engine;
/*    */ 






























/*    */ public class PlatformLocation
/*    */ {
/* 28 */   private static String location = null;
/*    */ 
/*    */   public static void setPlatformLocation(String loc)
/*    */   {
/* 39 */     location = loc;
/*    */   }

/*    */   public static String getPlatformLocation()
/*    */   {
/* 44 */     return location;
/*    */   }
/*    */ }
