package com.ibm.tivoli.maximo.report.birt.design;

public abstract interface ReportDesign
{
  public abstract String getTitle();

  public abstract String getDescription();

  public abstract String getReportFolder();

  public abstract ReportParameterInfo[] getParameterInfo()
    throws BirtReportDesignException;

  public abstract ReportLibraryInfo[] getLibraryInfo()
    throws BirtReportDesignException;

  public abstract ReportLabelInfo[] getLabelInfo()
    throws BirtReportDesignException;

  public abstract String getIncludedResourceFileName()
    throws BirtReportDesignException;

  public abstract void close()
    throws BirtReportDesignException;

  public abstract void changeParameterPattern(String paramString1, String paramString2, String paramString3)
    throws BirtReportDesignException;

  public abstract void save()
    throws BirtReportDesignException;

  public abstract boolean changeBidiProperties(String paramString1, String paramString2);
}
