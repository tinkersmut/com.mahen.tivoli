/*     */ package com.ibm.tivoli.maximo.report.birt.admin.batch;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
















/*     */ public class ReportsLoader
/*     */ {
/*     */   public static final String LIBRARYFOLDER = "${libraryfolder}";
/*     */   private String libraryFolderName;
/*     */ 
/*     */   public ReportsLoader()
/*     */   {
/*  51 */     this.libraryFolderName = null;
/*     */   }

/*     */   public void setLibraryFolder(String folderName) {
/*  55 */     this.libraryFolderName = folderName;
/*     */   }

/*     */   public ArrayList loadReports(String reportsXMLFile) throws Exception
/*     */   {
/*  60 */     ArrayList reportList = new ArrayList();
/*     */ 
/*  62 */     FileInputStream fis = null;

/*     */     try
/*     */     {
/*  66 */       fis = new FileInputStream(reportsXMLFile);
/*  67 */       InputStream inputStream = fis;
/*     */ 
/*  69 */       DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
/*  70 */       DocumentBuilder db = df.newDocumentBuilder();

/*     */ 
/*  73 */       db.setErrorHandler(new ReportXMLErrorHandler());
/*  74 */       db.setEntityResolver(new ReportXMLEntityResolver());
/*  75 */       Document d = db.parse(inputStream);
/*  76 */       reportList = processDocument(d);
/*     */ 
/*  78 */       File f = new File(reportsXMLFile);
/*  79 */       String folderName = f.getParentFile().getAbsolutePath();
/*     */ 
/*  81 */       int noOfReports = reportList.size();
/*  82 */       for (int i = 0; i < noOfReports; ++i)
/*     */       {
/*  84 */         ReportInfo reportInfo = (ReportInfo)reportList.get(i);
/*     */ 
/*  86 */         if (reportInfo.getReportResourcesSize() > 0)
/*     */         {
/*  88 */           byte[] resourcesZipData = createResourcesZip(folderName, reportInfo);
/*  89 */           reportInfo.setReportResourcesZipData(resourcesZipData);
/*     */         }
/*     */ 
/*  92 */         String fileName = reportInfo.getAttribute("filename");
/*     */ 
/*  94 */         String libraryFile = new File(reportsXMLFile).getParentFile().getAbsolutePath() + File.separator + fileName;
/*  95 */         reportInfo.setReportContent(getFileContent(libraryFile));
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 101 */         if (fis != null)
/* 102 */           fis.close();
/*     */       } catch (Throwable t) {
/*     */       }
/*     */     }
/* 106 */     return reportList;
/*     */   }

/*     */   private byte[] createResourcesZip(String currentFolderName, ReportInfo reportInfo) throws Exception
/*     */   {
/* 111 */     byte[] data = new byte[2048];
/*     */ 
/* 113 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 114 */     ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(bos));
/*     */ 
/* 116 */     Iterator resourcesIterator = reportInfo.getReportResources();
/* 117 */     while (resourcesIterator.hasNext())
/*     */     {
/* 119 */       ReportResourceInfo rsInfo = (ReportResourceInfo)resourcesIterator.next();
/*     */ 
/* 121 */       ZipEntry entry = new ZipEntry(rsInfo.getReference());
/* 122 */       out.putNextEntry(entry);
/*     */ 
/* 124 */       String fileName = rsInfo.getFileName();
/* 125 */       int index = fileName.indexOf("${libraryfolder}");
/* 126 */       if (index >= 0)
/*     */       {
/* 128 */         if (this.libraryFolderName == null)
/*     */         {
/* 130 */           throw new Exception("${libraryfolder}  used in the XXML, but it's not being set.");
/*     */         }
/*     */ 
/* 133 */         String prefix = fileName.substring(0, index);
/* 134 */         String postfix = fileName.substring(index + "${libraryfolder}".length());
/*     */ 
/* 136 */         fileName = prefix + this.libraryFolderName + postfix;
/*     */       }
/*     */ 
/* 139 */       File f = new File(fileName);
/* 140 */       if (!(f.isAbsolute()))

/*     */       {
/* 143 */         fileName = currentFolderName + File.separator + fileName;
/*     */       }
/*     */ 
/* 146 */       FileInputStream fis = new FileInputStream(fileName);
/* 147 */       BufferedInputStream origin = null;

/*     */       try
/*     */       {
/* 151 */         origin = new BufferedInputStream(fis, 2048);

/*     */ 
/* 154 */         while ((count = origin.read(data, 0, 2048)) != -1)
/*     */         {/*     */           int count;
/* 156 */           out.write(data, 0, count);
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/*     */         try {
/* 162 */           if (origin != null)
/* 163 */             origin.close();
/*     */         } catch (Throwable t) {
/*     */         }
/*     */       }
/*     */     }
/* 168 */     out.flush();
/* 169 */     out.finish();
/* 170 */     out.close();
/*     */ 
/* 172 */     return bos.toByteArray();
/*     */   }

/*     */   private byte[] getFileContent(String fileName) throws IOException
/*     */   {
/* 177 */     if (fileName == null)
/*     */     {
/* 179 */       return null;
/*     */     }
/*     */ 
/* 182 */     BufferedReader bfr = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF8"));
/*     */ 
/* 184 */     StringBuffer fileContentBuf = new StringBuffer();
/*     */ 
/* 186 */     char[] charBuf = new char[1024];
/*     */     while (true)
/*     */     {
/* 189 */       int charsRead = bfr.read(charBuf);
/* 190 */       if (charsRead < 0)

/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 196 */       fileContentBuf.append(charBuf, 0, charsRead);
/*     */     }
/*     */ 
/* 199 */     String fileContent = fileContentBuf.toString();
/* 200 */     byte[] data = fileContent.getBytes("UTF-8");
/*     */ 
/* 202 */     return data;
/*     */   }




/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 212 */       ReportsLoader reports = new ReportsLoader();
/* 213 */       reports.setLibraryFolder("C:/MyProjects/MAXIMO/HARRIER/reports/birt/libraries");
/* 214 */       reports.loadReports("C:/MyProjects/MAXIMO/HARRIER/reports/birt/reports/WOTRACK/reports.xml");

/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 219 */       e.printStackTrace();
/*     */     }
/*     */   }








/*     */   private ArrayList processDocument(Node node)
/*     */   {
/* 232 */     ArrayList reportList = new ArrayList();
/*     */ 
/* 234 */     NodeList list = node.getChildNodes();
/*     */ 
/* 236 */     int count = list.getLength();
/*     */ 
/* 238 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 240 */       Node n = list.item(i);
/*     */ 
/* 242 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 244 */       String element = n.getNodeName();
/* 245 */       if (!(element.equalsIgnoreCase("reports")))
/*     */         continue;
/* 247 */       reportList = processReportsNode(n);


/*     */     }
/*     */ 
/* 252 */     return reportList;
/*     */   }




/*     */   private ArrayList processReportsNode(Node node)
/*     */   {
/* 260 */     ArrayList reportList = new ArrayList();
/*     */ 
/* 262 */     NodeList list = node.getChildNodes();
/*     */ 
/* 264 */     int count = list.getLength();
/*     */ 
/* 266 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 268 */       Node n = list.item(i);
/*     */ 
/* 270 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 272 */       String element = n.getNodeName();
/*     */ 
/* 274 */       if (!(element.equalsIgnoreCase("report")))
/*     */         continue;
/* 276 */       NamedNodeMap amap = n.getAttributes();
/* 277 */       String reportName = amap.getNamedItem("name").getNodeValue().trim();
/*     */ 
/* 279 */       ReportInfo reportInfo = new ReportInfo(reportName);
/*     */ 
/* 281 */       processReportNode(n, reportInfo);
/*     */ 
/* 283 */       reportList.add(reportInfo);


/*     */     }
/*     */ 
/* 288 */     return reportList;
/*     */   }




/*     */   private void processReportNode(Node node, ReportInfo reportInfo)
/*     */   {
/* 296 */     NodeList list = node.getChildNodes();
/*     */ 
/* 298 */     int count = list.getLength();
/*     */ 
/* 300 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 302 */       Node n = list.item(i);
/*     */ 
/* 304 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 306 */       String element = n.getNodeName();
/*     */ 
/* 308 */       if (element.equalsIgnoreCase("resources"))
/*     */       {
/* 310 */         processResourcesNode(n, reportInfo);
/*     */       }
/* 312 */       else if (element.equalsIgnoreCase("attribute"))
/*     */       {
/* 314 */         NamedNodeMap amap = n.getAttributes();
/* 315 */         String attributeName = amap.getNamedItem("name").getNodeValue().trim();
/* 316 */         String attributeValue = getTextValue(n);
/* 317 */         reportInfo.setAttribute(attributeName, attributeValue);
/*     */       } else {
/* 319 */         if (!(element.equalsIgnoreCase("parameters")))
/*     */           continue;
/* 321 */         processParametersNode(n, reportInfo);
/*     */       }
/*     */     }
/*     */   }


/*     */   private void processResourcesNode(Node node, ReportInfo reportInfo)
/*     */   {
/* 329 */     NodeList list = node.getChildNodes();
/*     */ 
/* 331 */     int count = list.getLength();
/*     */ 
/* 333 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 335 */       Node n = list.item(i);
/*     */ 
/* 337 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 339 */       String element = n.getNodeName();
/*     */ 
/* 341 */       if (!(element.equalsIgnoreCase("resource")))
/*     */         continue;
/* 343 */       ReportResourceInfo rsInfo = processResourceNode(n);
/* 344 */       reportInfo.addReportResourceInfo(rsInfo);
/*     */     }
/*     */   }



/*     */   private ReportResourceInfo processResourceNode(Node node)
/*     */   {
/* 352 */     ReportResourceInfo rsInfo = new ReportResourceInfo();
/*     */ 
/* 354 */     NodeList list = node.getChildNodes();
/*     */ 
/* 356 */     int count = list.getLength();
/*     */ 
/* 358 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 360 */       Node n = list.item(i);
/*     */ 
/* 362 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 364 */       String element = n.getNodeName();
/*     */ 
/* 366 */       if (element.equalsIgnoreCase("reference"))
/*     */       {
/* 368 */         String reference = getTextValue(n);
/* 369 */         rsInfo.setReference(reference);
/*     */       } else {
/* 371 */         if (!(element.equalsIgnoreCase("filename")))
/*     */           continue;
/* 373 */         String fileName = getTextValue(n);
/* 374 */         rsInfo.setFileName(fileName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 379 */     return rsInfo;
/*     */   }

/*     */   private void processParametersNode(Node node, ReportInfo reportInfo)
/*     */   {
/* 384 */     NodeList list = node.getChildNodes();
/*     */ 
/* 386 */     int count = list.getLength();
/*     */ 
/* 388 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 390 */       Node n = list.item(i);
/*     */ 
/* 392 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 394 */       String element = n.getNodeName();
/*     */ 
/* 396 */       if (!(element.equalsIgnoreCase("parameter")))
/*     */         continue;
/* 398 */       NamedNodeMap amap = n.getAttributes();
/* 399 */       String paramName = amap.getNamedItem("name").getNodeValue().trim();
/*     */ 
/* 401 */       ReportParameterInfo paramInfo = processParameterNode(n);
/* 402 */       reportInfo.setParameter(paramName, paramInfo);
/*     */     }
/*     */   }



/*     */   private ReportParameterInfo processParameterNode(Node node)
/*     */   {
/* 410 */     ReportParameterInfo paramInfo = new ReportParameterInfo();
/*     */ 
/* 412 */     NodeList list = node.getChildNodes();
/*     */ 
/* 414 */     int count = list.getLength();
/*     */ 
/* 416 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 418 */       Node n = list.item(i);
/*     */ 
/* 420 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 422 */       String element = n.getNodeName();
/*     */ 
/* 424 */       if (!(element.equalsIgnoreCase("attribute")))
/*     */         continue;
/* 426 */       NamedNodeMap amap = n.getAttributes();
/* 427 */       String attributeName = amap.getNamedItem("name").getNodeValue().trim();
/* 428 */       String attributeValue = getTextValue(n);
/* 429 */       paramInfo.setAttribute(attributeName, attributeValue);


/*     */     }
/*     */ 
/* 434 */     return paramInfo;
/*     */   }









/*     */   private String getTextValue(Node node)
/*     */   {
/* 447 */     String textValue = "";
/* 448 */     NodeList list = node.getChildNodes();
/*     */ 
/* 450 */     int count = list.getLength();
/*     */ 
/* 452 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 454 */       Node n = list.item(i);
/*     */ 
/* 456 */       if (n.getNodeType() != 3)
/*     */         continue;
/* 458 */       textValue = n.getNodeValue();
/* 459 */       if (textValue != null)
/*     */         break;
/* 461 */       textValue = ""; break;




/*     */     }
/*     */ 
/* 468 */     return textValue.trim();
/*     */   }






/*     */   class ReportXMLEntityResolver
/*     */     implements EntityResolver
/*     */   {
/*     */     public InputSource resolveEntity(String publicId, String systemId)
/*     */       throws SAXException, IOException
/*     */     {
/* 482 */       if ((systemId != null) && (systemId.endsWith("reports.dtd")))
/*     */       {
/* 484 */         InputStream dtdStream = super.getClass().getResourceAsStream("/reports.dtd");
/* 485 */         return new InputSource(dtdStream);
/*     */       }
/*     */ 
/* 488 */       return null;
/*     */     }
/*     */   }






/*     */   class ReportXMLErrorHandler
/*     */     implements ErrorHandler
/*     */   {
/*     */     public void error(SAXParseException e)
/*     */       throws SAXException
/*     */     {
/* 503 */       throw e;
/*     */     }




/*     */     public void fatalError(SAXParseException e)
/*     */       throws SAXException
/*     */     {
/* 512 */       throw e;
/*     */     }
/*     */ 
/*     */     public void warning(SAXParseException exception)
/*     */       throws SAXException
/*     */     {
/*     */     }
/*     */   }
/*     */ }
