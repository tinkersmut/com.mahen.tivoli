/*    */ package com.ibm.tivoli.maximo.report.birt.admin.batch;
/*    */ 

















/*    */ public class LibraryInfo extends ReportInfo
/*    */ {
/*    */   public LibraryInfo(String name)
/*    */   {
/* 24 */     super(name);
/*    */   }
/*    */ }
