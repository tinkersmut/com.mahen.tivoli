/*    */ package com.ibm.tivoli.maximo.report.birt.admin;
/*    */ 
/*    */ import java.io.File;
/*    */ 










































/*    */ public class AdminServiceTempLocation
/*    */ {
/*    */   private static final String TEMP_IMPORTFOLDER = "importbirtreport";
/*    */   private static final String TEMP_CREATEREPORTFOLDER = "createbirtreport";
/* 41 */   private static String location = null;
/*    */ 
/* 45 */   private static String importLocation = null;
/*    */ 
/* 49 */   private static String createReportLocation = null;
/*    */ 
/*    */   public static void setAdminServiceTempLocation(String loc)
/*    */   {
/* 59 */     location = loc;
/* 60 */     importLocation = location + File.separator + "importbirtreport";
/* 61 */     createReportLocation = location + File.separator + "createbirtreport";
/*    */   }

/*    */   public static String getAdminServiceTempLocation()
/*    */   {
/* 66 */     return location;
/*    */   }

/*    */   public static String getTemporaryImportLocation()
/*    */   {
/* 71 */     return importLocation;
/*    */   }

/*    */   public static String getTemporaryCreateReportLocation()
/*    */   {
/* 76 */     return createReportLocation;
/*    */   }
/*    */ }
