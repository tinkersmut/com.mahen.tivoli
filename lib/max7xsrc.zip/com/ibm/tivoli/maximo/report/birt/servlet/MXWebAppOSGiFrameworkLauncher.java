/*    */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.bridge.launcher.FrameworkLauncher;
/*    */ import com.ibm.tivoli.maximo.report.birt.engine.PlatformLocation;
/*    */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*    */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*    */ import java.io.File;
/*    */ 


















/*    */ public class MXWebAppOSGiFrameworkLauncher extends FrameworkLauncher
/*    */ {
/* 29 */   private ReportLogger reportLogger = null;
/*    */ 
/*    */   public MXWebAppOSGiFrameworkLauncher()
/*    */   {
/* 33 */     this.reportLogger = ReportLoggerFactory.getLogger("maximo.report.birt");
/*    */   }

/*    */   public synchronized void deploy()
/*    */   {
/* 38 */     if (this.reportLogger.isDebugEnabled())
/*    */     {
/* 40 */       this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (deploying)");
/*    */     }
/*    */ 
/* 43 */     super.deploy();
/*    */ 
/* 45 */     super.copyResource("/WEB-INF/birt/platform/configuration/webapp/", new File(super.getPlatformDirectory() + File.separator + "configuration", "webapp"));
/* 46 */     super.copyResource("/WEB-INF/birt/platform/workspace/webapp/", new File(super.getPlatformDirectory() + File.separator + "workspace", "webapp"));
/*    */ 
/* 48 */     File platformDir = super.getPlatformDirectory();
/*    */ 
/* 50 */     if (this.reportLogger.isDebugEnabled())
/*    */     {
/* 52 */       this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher Platform directory = " + platformDir.getAbsolutePath());
/*    */     }
/*    */ 
/* 55 */     PlatformLocation.setPlatformLocation(platformDir.getAbsolutePath());
/*    */ 
/* 57 */     if (!(this.reportLogger.isDebugEnabled()))
/*    */       return;
/* 59 */     this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (deployed)");
/*    */   }


/*    */   public synchronized void start()
/*    */   {
/* 65 */     if (this.reportLogger.isDebugEnabled())
/*    */     {
/* 67 */       this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (starting)");
/*    */     }
/*    */ 
/* 70 */     super.start();
/*    */ 
/* 72 */     if (!(this.reportLogger.isDebugEnabled()))
/*    */       return;
/* 74 */     this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (started)");
/*    */   }


/*    */   public synchronized void stop()
/*    */   {
/* 80 */     if (this.reportLogger.isDebugEnabled())
/*    */     {
/* 82 */       this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (stopping)");
/*    */     }
/*    */ 
/* 85 */     super.stop();
/*    */ 
/* 87 */     if (!(this.reportLogger.isDebugEnabled()))
/*    */       return;
/* 89 */     this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (stopped)");
/*    */   }
/*    */ }
