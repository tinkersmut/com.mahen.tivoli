/*    */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*    */ 






















/*    */ public class ReportExecutionTaskProvider
/*    */ {
/* 22 */   private static ReportExecutionTask reportExecutionTask = null;
/*    */ 
/*    */   public static ReportExecutionTask getReportExecutionTask()
/*    */   {
/* 31 */     return reportExecutionTask;
/*    */   }









/*    */   public static void setReportExecutionTask(ReportExecutionTask eTask)
/*    */   {
/* 44 */     reportExecutionTask = eTask;
/*    */   }
/*    */ }
