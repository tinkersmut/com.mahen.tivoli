/*     */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
















/*     */ public class ReportExecutionInputInfo
/*     */ {
/*     */   public static final String OUTPUT_FORMAT_HTML = "html";
/*     */   public static final String OUTPUT_FORMAT_PDF = "pdf";
/*     */   public static final String OUTPUT_FORMAT_XLS = "xls";
/*     */   public static final String OUTPUT_FORMAT_CSV = "csv";
/*     */   private String reportFileName;
/*     */   private String outputFolderName;
/*     */   private String outputFileName;
/*     */   private String outputFormat;
/*     */   private ReportExecutionParameterData reportParameterData;
/*     */   private Map mxReportContext;
/*     */   private Locale locale;
/*     */   private ReportJdbcConnectionProvider jdbcConnectionProvider;
/*     */   private long reportJobId;
/*     */ 
/*     */   public ReportExecutionInputInfo()
/*     */   {
/*  40 */     this.reportFileName = null;



/*     */ 
/*  45 */     this.outputFolderName = null;






/*     */ 
/*  53 */     this.outputFileName = null;



/*     */ 
/*  58 */     this.outputFormat = null;



/*     */ 
/*  63 */     this.reportParameterData = new ReportExecutionParameterData();



/*     */ 
/*  68 */     this.mxReportContext = null;



/*     */ 
/*  73 */     this.locale = null;

/*     */ 
/*  76 */     this.jdbcConnectionProvider = null;
/*     */ 
/*  78 */     this.reportJobId = 0L;
/*     */   }

/*     */   public String getOutputFileName() {
/*  82 */     return this.outputFileName;
/*     */   }

/*     */   public void setOutputFileName(String outputFileName)
/*     */   {
/*  87 */     this.outputFileName = outputFileName;
/*     */   }

/*     */   public String getOutputFolderName()
/*     */   {
/*  92 */     return this.outputFolderName;
/*     */   }

/*     */   public void setOutputFolderName(String outputFolderName)
/*     */   {
/*  97 */     this.outputFolderName = outputFolderName;
/*     */   }

/*     */   public String getOutputFormat()
/*     */   {
/* 102 */     return this.outputFormat;
/*     */   }

/*     */   public void setOutputFormat(String outputFormat)
/*     */   {
/* 107 */     this.outputFormat = outputFormat;
/*     */   }

/*     */   public String getReportFileName()
/*     */   {
/* 112 */     return this.reportFileName;
/*     */   }

/*     */   public void setReportFileName(String reportFileName)
/*     */   {
/* 117 */     this.reportFileName = reportFileName;
/*     */   }

/*     */   public ReportJdbcConnectionProvider getJdbcConnectionProvider()
/*     */   {
/* 122 */     return this.jdbcConnectionProvider;
/*     */   }

/*     */   public void setJdbcConnectionProvider(ReportJdbcConnectionProvider jdbcConnectionProvider)
/*     */   {
/* 127 */     this.jdbcConnectionProvider = jdbcConnectionProvider;
/*     */   }

/*     */   public ReportExecutionParameterData getReportExecutionParameterData()
/*     */   {
/* 132 */     return this.reportParameterData;
/*     */   }

/*     */   public void setReportExecutionParameterData(ReportExecutionParameterData reportParameterData)
/*     */   {
/* 137 */     this.reportParameterData = reportParameterData;
/*     */   }

/*     */   public Map getMxReportContext()
/*     */   {
/* 142 */     return this.mxReportContext;
/*     */   }

/*     */   public void setMxReportContext(Map mxReportContext)
/*     */   {
/* 147 */     this.mxReportContext = mxReportContext;
/*     */   }

/*     */   public Locale getLocale()
/*     */   {
/* 152 */     return this.locale;
/*     */   }

/*     */   public void setLocale(Locale locale)
/*     */   {
/* 157 */     this.locale = locale;
/*     */   }

/*     */   public long getReportJobId()
/*     */   {
/* 162 */     return this.reportJobId;
/*     */   }

/*     */   public void setReportJobId(long reportJobId)
/*     */   {
/* 167 */     this.reportJobId = reportJobId;
/*     */   }
/*     */ }
