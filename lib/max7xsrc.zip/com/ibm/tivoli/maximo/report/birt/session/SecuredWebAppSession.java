/*     */ package com.ibm.tivoli.maximo.report.birt.session;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.ejb.AccessLocalException;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import psdi.security.AuthenticatedAccessToken;
/*     */ import psdi.security.SecurityServiceRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.security.ejb.AccessToken;
/*     */ import psdi.security.ejb.AccessTokenProviderHomeLocal;
/*     */ import psdi.security.ejb.AccessTokenProviderHomeRemote;
/*     */ import psdi.security.ejb.AccessTokenProviderLocal;
/*     */ import psdi.security.ejb.AccessTokenProviderRemote;
/*     */ import psdi.security.ejb.SessionKey;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.MXServerInfo;
/*     */ import psdi.server.MXServerRemote;
/*     */ import psdi.util.MXAccessException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.RMISession;
/*     */ 

















































/*     */ public class SecuredWebAppSession extends RMISession
/*     */ {
/*     */   private static final String ACCESSTOKENPROVIDER_LOCAL_REFNAME = "ejb/maximo/local/accesstokenprovider";
/*     */   private static final String ACCESSTOKENPROVIDER_REMOTE_REFNAME = "ejb/maximo/remote/accesstokenprovider";
/*  65 */   private MXServerInfo mxServerInfo = MXServerInfo.getMXServerInfo();
/*     */ 
/*  70 */   private AccessToken accessToken = null;
/*     */ 
/*     */   public boolean isConnected()
/*     */   {
/*  87 */     if (!(this.connected))
/*     */     {
/*     */       try
/*     */       {
/*  91 */         connect();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  95 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/*  99 */     return this.connected;
/*     */   }







/*     */   protected MXServerRemote getMXServer()
/*     */     throws MXException, MalformedURLException, NotBoundException, RemoteException, UnknownHostException
/*     */   {
/* 111 */     if (this.remoteServer != null)
/*     */     {
/* 113 */       return this.remoteServer;


/*     */     }
/*     */ 
/* 118 */     if ((this.mxServerInfo.allowLocalObjects()) && (this.mxServerInfo.isStartedInProcess()))
/*     */     {
/* 120 */       this.remoteServer = MXServer.getMXServer();
/* 121 */       return this.remoteServer;


/*     */     }
/*     */ 
/* 126 */     this.accessToken = getAccessToken();
/* 127 */     String maximoBindingName = this.accessToken.getMaximoBindingName();
/*     */ 
/* 129 */     if (maximoBindingName == null)
/*     */     {
/* 131 */       throw new MXSystemException("system", "notboundexception");
/*     */     }
/*     */ 
/* 134 */     this.remoteServer = ((MXServerRemote)Naming.lookup(maximoBindingName));
/*     */ 
/* 136 */     return this.remoteServer;
/*     */   }






/*     */   private AccessToken getAccessToken()
/*     */     throws MXException
/*     */   {
/* 147 */     if (this.accessToken != null)
/*     */     {
/* 149 */       return this.accessToken;
/*     */     }
/*     */ 
/* 152 */     AccessToken token = null;
/*     */ 
/* 154 */     InitialContext initCtx = null;

/*     */     try
/*     */     {
/* 158 */       initCtx = new InitialContext();


/*     */ 
/* 162 */       if (this.mxServerInfo.isStartedInProcess())
/*     */       {
/* 164 */         Object obj = initCtx.lookup("java:comp/env/ejb/maximo/local/accesstokenprovider");
/*     */ 
/* 166 */         AccessTokenProviderHomeLocal atkProviderHomeLocal = (AccessTokenProviderHomeLocal)obj;
/* 167 */         AccessTokenProviderLocal atkProviderLocal = atkProviderHomeLocal.create();
/* 168 */         token = atkProviderLocal.getAccessToken();
/*     */       }
/*     */       else
/*     */       {
/* 172 */         Object obj = initCtx.lookup("java:comp/env/ejb/maximo/remote/accesstokenprovider");
/*     */ 
/* 174 */         AccessTokenProviderHomeRemote atkProviderHomeRemote = null;
/* 175 */         atkProviderHomeRemote = (AccessTokenProviderHomeRemote)PortableRemoteObject.narrow(obj, AccessTokenProviderHomeRemote.class);
/*     */ 
/* 177 */         AccessTokenProviderRemote atkProviderRemote = atkProviderHomeRemote.create();
/* 178 */         token = atkProviderRemote.getAccessToken();

/*     */       }
/*     */ 
/*     */     }
/*     */     catch (AccessLocalException ex)
/*     */     {
/*     */     }
/*     */     catch (Throwable ne)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 193 */         initCtx.close();
/*     */       }
/*     */       catch (Exception ex) {
/*     */       }
/*     */     }
/* 198 */     return token;
/*     */   }



/*     */   protected UserInfo loadUserInfo()
/*     */     throws MXException, RemoteException
/*     */   {
/* 206 */     UserInfo uInfo = null;
/* 207 */     AccessToken token = null;
/*     */ 
/* 209 */     token = getAccessToken();
/*     */ 
/* 211 */     SecurityServiceRemote securityServiceRemote = (SecurityServiceRemote)this.remoteServer.lookup("SECURITY");
/*     */ 
/* 213 */     if (securityServiceRemote == null) {
/* 214 */       throw new MXAccessException("access", "noservice");
/*     */     }
/* 216 */     AuthenticatedAccessToken authAccessToken = new AuthenticatedAccessToken();
/* 217 */     authAccessToken.setMaximoBindingName(token.getMaximoBindingName());
/* 218 */     authAccessToken.setSessionCreationTime(token.getSessionCreationTime());
/* 219 */     authAccessToken.setSessionData(token.getSessionKey().getSessionData());
/* 220 */     authAccessToken.setUserName(token.getUserName());




/*     */ 
/* 226 */     setUserName(token.getUserName());



/*     */ 
/* 231 */     Object cert = getCredential();
/* 232 */     if (cert == null)
/* 233 */       uInfo = securityServiceRemote.getUserInfo(authAccessToken, null, getLocale(), getTimeZone());
/*     */     else
/* 235 */       uInfo = securityServiceRemote.getUserInfo(authAccessToken, cert, getLocale(), getTimeZone());
/* 236 */     return uInfo;
/*     */   }




/*     */   public synchronized void connect()
/*     */     throws MXException, RemoteException
/*     */   {
/* 245 */     super.connect();
/* 246 */     if ((!(this.mxServerInfo.allowLocalObjects())) || (!(this.mxServerInfo.isStartedInProcess())))
/*     */       return;
/* 248 */     super.getUserInfo().setLocalSession(true);
/*     */   }
/*     */ }
