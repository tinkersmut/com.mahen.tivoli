/*      */ package com.ibm.tivoli.maximo.report.birt.queue;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.report.birt.admin.ActiveReportThreadManager;
/*      */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminService;
/*      */ import com.ibm.tivoli.maximo.report.birt.admin.ReportUsageLogInfo;
/*      */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportParameterData;
/*      */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportRuntimeTempLocation;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URLEncoder;
/*      */ import java.rmi.RemoteException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import javax.mail.MessagingException;
/*      */ import psdi.app.report.ReportConstants.EmailFileTypes;
/*      */ import psdi.app.report.ReportConstants.EmailType;
/*      */ import psdi.app.report.ReportOutputAuthSetRemote;
/*      */ import psdi.mbo.MaxMessageCache;
/*      */ import psdi.mbo.MboRemote;
/*      */ import psdi.mbo.MboSetRemote;
/*      */ import psdi.security.SecurityService;
/*      */ import psdi.security.UserInfo;
/*      */ import psdi.server.MXServer;
/*      */ import psdi.server.MXServerInfo;
/*      */ import psdi.server.MaximoThread;
/*      */ import psdi.util.MXApplicationException;
/*      */ import psdi.util.MXException;
/*      */ import psdi.util.MXRowUpdateException;
/*      */ import psdi.util.MXSystemException;
/*      */ import psdi.util.Message;
/*      */ import psdi.util.logging.MXLogger;
/*      */ import psdi.util.logging.MXLoggerFactory;
/*      */ 

















































/*      */ public class ReportQueueManager extends MaximoThread
/*      */ {
/*      */   public static final int DEFAULT_QUEUE_IDLETIME_SECONDS = 60;
/*      */   public static final String PROPERTY_QUEUEIDLETIMESECONDS = "mxe.report.birt.queueidletimeseconds";
/*      */   public static final String PROPERTY_DISABLEQUEUEMANAGER = "mxe.report.birt.disablequeuemanager";
/*      */   public static final int DEFAULT_MAX_CONCURRENT_THREADCOUNT = 3;
/*      */   public static final String PROPERTY_MAXCONCURRENTRUN = "mxe.report.birt.maxconcurrentrun";
/*      */   private static final String REPORTRUNQUEUE_MBONAME = "REPORTRUNQUEUE";
/*      */   private static final String REPORTRUNQUEUE_RUNNING = "RUNNING";
/*      */   private static final String REPORTRUNQUEUE_REPORTRUNQUEUEID = "REPORTRUNQUEUEID";
/*      */   private static final String REPORTRUNQUEUE_PRIORITY = "PRIORITY";
/*      */   private static final String REPORTRUNQUEUE_SUBMITTIME = "SUBMITTIME";
/*      */   private static final String REPORTRUNQUEUE_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORTRUNQUEUE_APPNAME = "APPNAME";
/*      */   private static final String REPORTRUNQUEUE_USERID = "USERID";
/*      */   private static final String REPORTRUNQUEUE_EMAILUSERS = "EMAILUSERS";
/*      */   private static final String REPORTRUNQUEUE_EMAILSUBJECT = "EMAILSUBJECT";
/*      */   private static final String REPORTRUNQUEUE_EMAILCOMMENTS = "EMAILCOMMENTS";
/*      */   private static final String REPORTRUNQUEUE_EMAILTYPE = "EMAILTYPE";
/*      */   private static final String REPORTRUNQUEUE_MAXIMOURL = "MAXIMOURL";
/*      */   private static final String REPORTRUNQUEUE_EMAILFILETYPE = "EMAILFILETYPE";
/*      */   private static final String REPORTRUNQUEUE_COUNTRY = "COUNTRY";
/*      */   private static final String REPORTRUNQUEUE_LANGUAGE = "LANGUAGE";
/*      */   private static final String REPORTRUNQUEUE_VARIANT = "VARIANT";
/*      */   private static final String REPORTRUNQUEUE_TIMEZONE = "TIMEZONE";
/*      */   private static final String REPORTRUNQUEUE_LANGCODE = "LANGCODE";
/*      */   private static final String REPORTRUNPARAMS_RELATIONSHIPNAME = "REPORTRUNPARAM";
/*      */   private static final String REPORTRUNPARAMS_PARAMNAME = "PARAMNAME";
/*      */   private static final String REPORTRUNPARAMS_PARAMVALUE = "PARAMVALUE";
/*      */   private static final String REPORTRUNLOCK_RELATIONSHIPNAME = "REPORTRUNLOCK";
/*      */   private static final String REPORTRUNLOCK_REPORTRUNQUEUEID = "REPORTRUNQUEUEID";
/*      */   private static final String REPORTRUNLOCK_LOCKTIME = "LOCKTIME";
/*      */   private static final String REPORT_MBONAME = "REPORT";
/*      */   private static final String REPORT_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORT_APPNAME = "APPNAME";
/*      */   private static final String REPORT_DESCRIPTION = "DESCRIPTION";
/*  126 */   private MXLogger reportQueueLogger = null;
/*      */ 
/*  128 */   private ArrayList<ReportRunThread> runThreads = new ArrayList();
/*      */ 
/*  130 */   ActiveReportThreadManager activeReportThreadManager = null;
/*      */ 
/*  134 */   private boolean jobsAvailableToRun = false;
/*      */ 
/*  372 */   private static int runThreadIdCounter = 1;
/*      */ 
/*      */   public ReportQueueManager()
/*      */   {
/*  142 */     super("ReportQueueManagerTask");
/*      */ 
/*  144 */     this.reportQueueLogger = MXLoggerFactory.getLogger("maximo.report.birt.queue");
/*  145 */     this.activeReportThreadManager = ActiveReportThreadManager.getActiveReportThreadManager();
/*      */   }

/*      */   public void run()
/*      */   {
/*      */     label189: 
/*      */     while (true)
/*      */       try
/*      */       {
/*  154 */         boolean queueManagerDisabled = isQueueManagerDisabled();
/*      */ 
/*  156 */         if ((isReady()) && (!(queueManagerDisabled)))
/*      */         {
/*  158 */           if (!(this.activeReportThreadManager.isOverloaded()))
/*      */           {
/*  160 */             if (this.reportQueueLogger.isDebugEnabled())
/*      */             {
/*  162 */               this.reportQueueLogger.debug("Report Queue Manager about to execute queued Jobs");





/*      */             }
/*      */ 
/*  170 */             this.jobsAvailableToRun = areJobsAvailableToRun();
/*  171 */             if (this.jobsAvailableToRun)
/*      */             {
/*  173 */               runJobs();

/*      */             }
/*      */ 
/*      */           }
/*  178 */           else if (this.reportQueueLogger.isDebugEnabled())
/*      */           {
/*  180 */             this.reportQueueLogger.debug("Report Queue Manager threads are overloaded.");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  185 */         if ((!(queueManagerDisabled)) && 

/*  187 */           (this.reportQueueLogger.isDebugEnabled()))
/*      */         {
/*  189 */           this.reportQueueLogger.debug("Report Queue Manager is idle");

/*      */         }
/*      */ 
/*  193 */         int queueIdleTimeSeconds = getQueueIdleTime();

/*      */ 
/*  196 */         Thread.sleep(queueIdleTimeSeconds * 1000);
/*      */       }
/*      */       catch (InterruptedException iex)
/*      */       {
/*  200 */         if (isMarkedForShutDown())
/*      */         {
/*  202 */           return;
/*      */         }
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*  207 */         if (this.reportQueueLogger.isErrorEnabled())
/*      */         {
/*  209 */           this.reportQueueLogger.error(t.getMessage(), t);
/*      */         }
/*      */ 
/*  212 */         if (!(isMarkedForShutDown()))
/*      */           break label189;
/*      */       }
/*      */   }




/*      */   protected boolean isQueueManagerDisabled()
/*      */   {
/*  222 */     boolean disableQueueManager = false;
/*  223 */     String diableQueueManagerSetting = System.getProperty("mxe.report.birt.disablequeuemanager");
/*  224 */     if ((diableQueueManagerSetting != null) && ((

/*  226 */       (diableQueueManagerSetting.equalsIgnoreCase("true")) || (diableQueueManagerSetting.equalsIgnoreCase("1")))))
/*      */     {
/*  228 */       disableQueueManager = true;
/*      */ 
/*  230 */       if (this.reportQueueLogger.isDebugEnabled())
/*      */       {
/*  232 */         this.reportQueueLogger.debug("Report Queue Manager is not active. Scheduled Reports will not be processed on this instance.");

/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  238 */     if (!(disableQueueManager))
/*      */     {
/*      */       try
/*      */       {
/*  242 */         MXServer mxServer = MXServer.getMXServer();
/*      */ 
/*  244 */         diableQueueManagerSetting = mxServer.getProperty("mxe.report.birt.disablequeuemanager");
/*  245 */         if ((diableQueueManagerSetting != null) && ((

/*  247 */           (diableQueueManagerSetting.equalsIgnoreCase("true")) || (diableQueueManagerSetting.equalsIgnoreCase("1")))))
/*      */         {
/*  249 */           disableQueueManager = true;
/*      */ 
/*  251 */           if (this.reportQueueLogger.isDebugEnabled())
/*      */           {
/*  253 */             this.reportQueueLogger.debug("Report Queue Manager is not active. Scheduled Reports will not be processed on this instance.");
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  260 */         if (this.reportQueueLogger.isErrorEnabled())
/*      */         {
/*  262 */           this.reportQueueLogger.error("Failed to obtain [mxe.report.birt.disablequeuemanager] property value. Assuming default. Report Queue Manager will be active.", e);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  269 */     return disableQueueManager;
/*      */   }






/*      */   protected boolean areJobsAvailableToRun()
/*      */   {
/*  279 */     MboSetRemote runQueueSet = null;
/*  280 */     MboRemote runQueue = null;

/*      */     try
/*      */     {
/*  284 */       runQueueSet = MXServer.getMXServer().getMboSet("REPORTRUNQUEUE", getSystemUserInfo());
/*  285 */       runQueueSet.setQbe("RUNNING", "false");
/*  286 */       runQueueSet.setOrderBy("PRIORITY asc, SUBMITTIME desc");
/*      */ 
/*  288 */       runQueue = runQueueSet.getMbo(0);

/*      */ 
/*  291 */       if (runQueue == null)
/*      */       {
/*  293 */         i = 0;
/*      */         return i;
/*      */       }
/*  296 */       int i = 1;



/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  308 */         if (runQueueSet != null)
/*      */         {
/*  310 */           runQueueSet.reset();
/*      */ 
/*  312 */       return i;
/*      */         }/*      */       } catch (Throwable t) {/*      */       }
/*      */     }
/*  315 */     return false;
/*      */   }

/*      */   protected boolean isReady()
/*      */   {
/*  320 */     MXServerInfo serverInfo = MXServerInfo.getMXServerInfo();
/*      */ 
/*  322 */     boolean ready = serverInfo.isRunning();
/*      */ 
/*  324 */     return ready;
/*      */   }






/*      */   protected void runJobs()
/*      */   {
/*  334 */     int maxAllowed = getMaxAllowedActiveReportThreads();
/*  335 */     int noOfReportThreads = this.runThreads.size();
/*      */ 
/*  337 */     if (noOfReportThreads > maxAllowed)

/*      */     {
/*  340 */       int noOfThreadsToRelease = noOfReportThreads - maxAllowed;
/*  341 */       for (int i = 0; i < noOfThreadsToRelease; ++i)
/*      */       {
/*  343 */         ReportRunThread runThread = (ReportRunThread)this.runThreads.remove(0);
/*  344 */         runThread.markShutdown();
/*      */       }
/*      */     }
/*  347 */     else if (noOfReportThreads < maxAllowed)

/*      */     {
/*  350 */       int noOfThreadsToAdd = maxAllowed - noOfReportThreads;
/*  351 */       for (int i = 0; i < noOfThreadsToAdd; ++i)
/*      */       {
/*  353 */         ReportRunThread runThread = new ReportRunThread();
/*  354 */         this.runThreads.add(runThread);
/*  355 */         runThread.start();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  360 */     int noOfRunThreads = this.runThreads.size();
/*  361 */     for (int i = 0; i < noOfRunThreads; ++i)
/*      */     {
/*  363 */       ReportRunThread runThread = (ReportRunThread)this.runThreads.get(i);
/*  364 */       if (!(runThread.isWaitingForWork()))
/*      */         continue;
/*  366 */       runThread.startDoingWork();
/*      */     }
/*      */   }







/*      */   class ReportRunThread extends MaximoThread
/*      */   {
/*  378 */     private Object waitObject = new Object();
/*  379 */     private boolean waitingForWork = true;
/*      */ 
/*  381 */     int myCounter = 0;
/*      */ 
/*      */     public ReportRunThread()
/*      */     {
/*  385 */       super("ReportRunThread-" + ReportQueueManager.runThreadIdCounter);
/*  386 */       this.myCounter = ReportQueueManager.runThreadIdCounter;
/*  387 */       ReportQueueManager.access$008();
/*      */     }

/*      */     public void run()
/*      */     {
/*      */       label319: 
/*      */       while (true) {
/*      */         try
/*      */         {
/*  396 */           if (ReportQueueManager.this.reportQueueLogger.isDebugEnabled())
/*      */           {
/*  398 */             ReportQueueManager.this.reportQueueLogger.debug("Report Run Thread [" + getName() + "] waiting for work.");
/*      */           }
/*      */ 
/*  401 */           this.waitingForWork = true;
/*  402 */           synchronized (this.waitObject)
/*      */           {
/*  404 */             this.waitObject.wait();
/*      */           }
/*      */ 
/*  407 */           this.waitingForWork = false;
/*      */ 
/*  409 */           if (ReportQueueManager.this.reportQueueLogger.isDebugEnabled())
/*      */           {
/*  411 */             ReportQueueManager.this.reportQueueLogger.debug("Report Run Thread [" + getName() + "] wokeup for work.");
/*      */           }
/*      */ 
/*  414 */           if (isMarkedForShutDown())





/*      */           {
/*      */             break label322;
/*      */           }
/*      */ 
/*  424 */           if (!(ReportQueueManager.this.jobsAvailableToRun))
/*      */           {
/*  426 */             if (ReportQueueManager.this.reportQueueLogger.isDebugEnabled())
/*      */             {
/*  428 */               ReportQueueManager.this.reportQueueLogger.debug("Report Run Thread [" + getName() + "] noticed Queue is Empty.");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  433 */           if (ReportQueueManager.this.reportQueueLogger.isDebugEnabled())
/*      */           {
/*  435 */             ReportQueueManager.this.reportQueueLogger.debug("Report Run Thread [" + getName() + "] going to run report (if possible).");

/*      */           }
/*      */ 
/*  439 */           attemptToRunReport();
/*      */ 
/*  441 */           if (isMarkedForShutDown())
/*      */           {
/*  443 */             break label322:
/*      */           }
/*      */         }
/*      */         catch (InterruptedException ex)
/*      */         {
/*  448 */           if (isMarkedForShutDown())
/*      */           {
/*  450 */             break label322:
/*      */           }
/*      */         }
/*      */         catch (Throwable t)
/*      */         {
/*  455 */           t.printStackTrace();
/*  456 */           if (!(isMarkedForShutDown())) {
/*      */             break label319;
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  463 */       if (!(ReportQueueManager.this.reportQueueLogger.isDebugEnabled()))
/*      */         label322: return;
/*  465 */       ReportQueueManager.this.reportQueueLogger.debug("Report Run Thread [" + getName() + "] terminated.");
/*      */     }


/*      */     public void startDoingWork()
/*      */     {
/*  471 */       synchronized (this.waitObject)
/*      */       {
/*  473 */         this.waitObject.notify();
/*      */       }
/*      */     }

/*      */     public void markShutdown()
/*      */     {
/*  479 */       super.markShutdown();
/*  480 */       synchronized (this.waitObject)
/*      */       {
/*  482 */         this.waitObject.notify();
/*      */       }
/*      */     }


/*      */     private void attemptToRunReport()
/*      */     {
/*  489 */       ReportQueueManager.this.activeReportThreadManager.addActiveThread(getName(), null, null, null, true);
/*      */ 
/*  491 */       ScheduledReportUsageLogNotifier sReportUsageLogNotifier = new ScheduledReportUsageLogNotifier();
/*  492 */       sReportUsageLogNotifier.setReportLogger(ReportQueueManager.this.reportQueueLogger);
/*      */ 
/*  494 */       long startTimeInMillis = ReportQueueManager.this.getCurrentTime();
/*  495 */       sReportUsageLogNotifier.setStartDate(new Date(startTimeInMillis));
/*      */ 
/*  497 */       long endTimeInMillis = 0L;
/*      */       try
/*      */       {
/*  500 */         ReportQueueManager.this.doWork(sReportUsageLogNotifier);
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/*  504 */         if (ReportQueueManager.this.reportQueueLogger.isErrorEnabled())
/*      */         {
/*  506 */           ReportQueueManager.this.reportQueueLogger.error("Failed to run queued report.", e);
/*      */         }
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*  512 */         ReportQueueManager.this.activeReportThreadManager.removeActiveThread(getName());
/*      */ 
/*  514 */         endTimeInMillis = ReportQueueManager.this.getCurrentTime();
/*      */       }
/*      */ 
/*  517 */       long runTimeInSeconds = (endTimeInMillis - startTimeInMillis) / 1000L;
/*  518 */       sReportUsageLogNotifier.setEndDate(new Date(endTimeInMillis));
/*  519 */       sReportUsageLogNotifier.setRuntime(runTimeInSeconds);
/*      */ 
/*  521 */       sReportUsageLogNotifier.createUsageLog();
/*      */     }

/*      */     public boolean isWaitingForWork()
/*      */     {
/*  526 */       return this.waitingForWork;
/*      */     }
/*      */   }

/*      */   protected long getCurrentTime()
/*      */   {
/*      */     try
/*      */     {
/*  534 */       Date currentDate = MXServer.getMXServer().getDate();
/*  535 */       return currentDate.getTime();

/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*      */     }
/*      */ 
/*  542 */     return System.currentTimeMillis();
/*      */   }

/*      */   protected void createReportUsageLog(ReportUsageLogInfo usageLogInfo)
/*      */   {
/*      */     try
/*      */     {
/*  549 */       ReportAdminService reportAdminService = (ReportAdminService)MXServer.getMXServer().lookup("BIRTREPORT");
/*  550 */       reportAdminService.createReportUsageLog(getSystemUserInfo(), usageLogInfo);
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  554 */       if (!(this.reportQueueLogger.isErrorEnabled()))
/*      */         return;
/*  556 */       this.reportQueueLogger.error("Failed to write usage log.", t); }  } 







































































































/*      */   public boolean acquireLock(long runQueueId) { boolean acquiredLock = false;
/*      */ 
/*  662 */     MboSetRemote runQueueSet = null;

/*      */     try
/*      */     {
/*  666 */       runQueueSet = MXServer.getMXServer().getMboSet("REPORTRUNQUEUE", getSystemUserInfo());
/*  667 */       runQueueSet.setQbe("RUNNING", "false");
/*  668 */       runQueueSet.setQbe("REPORTRUNQUEUEID", "" + runQueueId);
/*      */ 
/*  670 */       MboRemote runQueue = runQueueSet.getMbo(0);
/*  671 */       if (runQueue == null)
/*      */       {
/*  673 */         boolean bool1 = acquiredLock;
/*      */         return bool1;
/*      */       }
/*  676 */       runQueue.setValue("RUNNING", true);
/*  677 */       runQueue.setValue("SERVERHOST", MXServer.getMXServer().getServerHost());
/*  678 */       runQueue.setValue("SERVERNAME", MXServer.getMXServer().getName());

/*      */ 
/*  681 */       MboSetRemote reportLockSet = runQueue.getMboSet("REPORTRUNLOCK");
/*  682 */       MboRemote reportLock = reportLockSet.getMbo(0);
/*  683 */       if (reportLock != null)

/*      */       {
/*  686 */         boolean bool2 = acquiredLock;
/*      */         return bool2;
/*      */       }
/*  689 */       reportLock = reportLockSet.add();
/*  690 */       reportLock.setValue("REPORTRUNQUEUEID", runQueueId);
/*  691 */       reportLock.setValue("LOCKTIME", MXServer.getMXServer().getDate());
/*      */ 
/*  693 */       runQueueSet.save();
/*      */ 
/*  695 */       acquiredLock = true;


/*      */     }
/*      */     catch (MXRowUpdateException t)
/*      */     {
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  704 */       if ((!(t instanceof MXException)) && 

/*  706 */         (this.reportQueueLogger.isErrorEnabled()))
/*      */       {
/*  708 */         this.reportQueueLogger.error("Failed to acquire lock on queued report.", t);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  715 */         if (runQueueSet != null)
/*      */         {
/*  717 */           runQueueSet.reset();
/*      */         }
/*      */       } catch (Throwable t) {
/*      */       }
/*      */     }
/*  722 */     return acquiredLock;
/*      */   }

/*      */   public void removeRunReport(long runQueueId)
/*      */   {
/*  727 */     MboSetRemote runQueueSet = null;

/*      */     try
/*      */     {
/*  731 */       runQueueSet = MXServer.getMXServer().getMboSet("REPORTRUNQUEUE", getSystemUserInfo());
/*  732 */       runQueueSet.setQbe("RUNNING", "true");
/*  733 */       runQueueSet.setQbe("REPORTRUNQUEUEID", "" + runQueueId);
/*      */ 
/*  735 */       MboRemote runQueue = runQueueSet.getMbo(0);
/*  736 */       if (runQueue == null)

/*      */       {
/*      */         return;
/*      */       }
/*      */ 
/*  742 */       MboSetRemote reportLockSet = runQueue.getMboSet("REPORTRUNLOCK");
/*  743 */       MboRemote reportLock = reportLockSet.getMbo(0);
/*  744 */       if (reportLock == null)

/*      */       {
/*      */         return;
/*      */       }
/*      */ 
/*  750 */       MboSetRemote runParamSet = runQueue.getMboSet("REPORTRUNPARAM");
/*  751 */       runParamSet.deleteAll();
/*      */ 
/*  753 */       runQueue.delete();
/*  754 */       reportLock.delete();
/*      */ 
/*  756 */       runQueueSet.save();
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  760 */       if (this.reportQueueLogger.isErrorEnabled())
/*      */       {
/*  762 */         this.reportQueueLogger.error("Failed to remove the run queued report.", t);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try {
/*  768 */         if (runQueueSet != null)
/*      */         {
/*  770 */           runQueueSet.reset();
/*      */         }
/*      */       }
/*      */       catch (Throwable t) {
/*      */       }
/*      */     }
/*      */   }

/*      */   protected void runQueuedReport(MboRemote runQueue, ScheduledReportUsageLogNotifier sReportUsageLogNotifier) {
/*      */     try {
/*  780 */       String userId = runQueue.getString("USERID");
/*  781 */       String reportName = runQueue.getString("REPORTNAME");
/*  782 */       String appName = runQueue.getString("APPNAME");
/*  783 */       String emailAddresses = runQueue.getString("EMAILUSERS");
/*  784 */       String emailSubject = runQueue.getString("EMAILSUBJECT");
/*  785 */       String emailComments = runQueue.getString("EMAILCOMMENTS");
/*  786 */       String emailType = runQueue.getString("EMAILTYPE");
/*  787 */       String maximoUrl = runQueue.getString("MAXIMOURL");
/*  788 */       String emailFileType = runQueue.getString("EMAILFILETYPE");
/*  789 */       long uid = runQueue.getUniqueIDValue();
/*      */ 
/*  791 */       String emailAddress = getEmailAddress(userId);

/*      */ 
/*  794 */       String country = runQueue.getString("COUNTRY");
/*  795 */       String language = runQueue.getString("LANGUAGE");
/*  796 */       String variant = runQueue.getString("VARIANT");
/*  797 */       String timeZoneId = runQueue.getString("TIMEZONE");
/*  798 */       String langCode = runQueue.getString("LANGCODE");
/*      */ 
/*  800 */       Locale locale = new Locale(language, country, variant);
/*  801 */       TimeZone timeZone = TimeZone.getTimeZone(timeZoneId);
/*      */ 
/*  803 */       sReportUsageLogNotifier.setHostName(MXServer.getMXServer().getServerHost());
/*  804 */       sReportUsageLogNotifier.setServerName(MXServer.getMXServer().getName());
/*  805 */       sReportUsageLogNotifier.setAppName(appName);
/*  806 */       sReportUsageLogNotifier.setReportName(reportName);
/*  807 */       sReportUsageLogNotifier.setEnterDate(runQueue.getDate("SUBMITTIME"));
/*  808 */       sReportUsageLogNotifier.setUserId(userId);
/*  809 */       sReportUsageLogNotifier.setEmailFileType(emailFileType);

/*      */ 
/*  812 */       this.activeReportThreadManager.updateActiveThread(Thread.currentThread().getName(), reportName, appName, userId, true, uid);

/*      */ 
/*  815 */       MboSetRemote reportRunParamsSet = runQueue.getMboSet("REPORTRUNPARAM");
/*      */ 
/*  817 */       ReportParameterData parameterData = new ReportParameterData();
/*      */ 
/*  819 */       int i = 0;
/*      */       while (true)
/*      */       {
/*  822 */         MboRemote reportRunParam = reportRunParamsSet.getMbo(i);
/*  823 */         if (reportRunParam == null)
/*      */         {
/*      */           break;
/*      */         }
/*      */ 
/*  828 */         String paramName = reportRunParam.getString("PARAMNAME");
/*  829 */         String paramValue = reportRunParam.getString("PARAMVALUE");
/*      */ 
/*  831 */         if (reportRunParam.isNull("PARAMVALUE"))
/*      */         {
/*  833 */           parameterData.addParameter(paramName, null);
/*      */         }
/*      */         else
/*      */         {
/*  837 */           parameterData.addParameter(paramName, paramValue);
/*      */         }
/*      */ 
/*  840 */         ++i;
/*      */       }
/*      */ 
/*  843 */       runQueuedReport(userId, reportName, appName, parameterData, emailAddress, emailAddresses, emailSubject, emailComments, emailFileType, emailType, maximoUrl, locale, timeZone, langCode, sReportUsageLogNotifier);




/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  851 */       if (!(this.reportQueueLogger.isErrorEnabled()))
/*      */         return;
/*  853 */       this.reportQueueLogger.error("Failed to run queued report.", t);
/*      */     }
/*      */   }







/*      */   protected void runQueuedReport(String userId, String reportName, String appName, ReportParameterData parameterData, String emailAddress, String emailAddresses, String emailSubject, String emailComments, String emailFileType, String emailType, String maximoUrl, Locale locale, TimeZone timeZone, String langCode, ScheduledReportUsageLogNotifier sReportUsageLogNotifier)
/*      */   {
/*      */     try
/*      */     {
/*  867 */       MXServer mxServer = MXServer.getMXServer();

/*      */ 
/*  870 */       SecurityService securityServiceRemote = (SecurityService)mxServer.lookup("SECURITY");
/*  871 */       UserInfo reportScheduledUserInfo = securityServiceRemote.authenticateUser(userId, true);


/*      */ 
/*  875 */       reportScheduledUserInfo.setLocale(locale);
/*  876 */       reportScheduledUserInfo.setTimeZone(timeZone);
/*  877 */       reportScheduledUserInfo.setLangCode(langCode);
/*      */ 
/*  879 */       HashMap additionalInfoMap = new HashMap();
/*      */ 
/*  881 */       sReportUsageLogNotifier.setUserInfo(reportScheduledUserInfo);
/*  882 */       additionalInfoMap.put("USAGELOGNOTIFIER", sReportUsageLogNotifier);
/*      */ 
/*  884 */       ReportAdminService reportAdminService = (ReportAdminService)mxServer.lookup("BIRTREPORT");
/*      */ 
/*  886 */       String tempFolder = null;
/*      */       try
/*      */       {
/*  889 */         String tempRunFolder = ReportRuntimeTempLocation.getReportsLocation();
/*  890 */         String uniqueFolder = ReportAdminService.createUniqueTempFolder(tempRunFolder);
/*      */ 
/*  892 */         tempFolder = tempRunFolder + File.separator + uniqueFolder;
/*      */ 
/*  894 */         String reportOutputFileName = getReportOutputFileName(tempFolder, reportName, appName, locale);
/*      */ 
/*  896 */         if (emailFileType.equalsIgnoreCase("XLS"))
/*      */         {
/*  898 */           emailFileType = "xls";
/*  899 */           reportOutputFileName = reportOutputFileName + ".xls";
/*      */         }
/*      */         else
/*      */         {
/*  903 */           emailFileType = "pdf";
/*  904 */           reportOutputFileName = reportOutputFileName + ".pdf";
/*      */         }
/*      */ 
/*  907 */         File f = new File(tempFolder + File.separator + reportOutputFileName);
/*  908 */         f.getParentFile().mkdirs();
/*      */ 
/*  910 */         byte[] reportOutput = reportAdminService.runReport(reportScheduledUserInfo, reportName, appName, parameterData, reportOutputFileName, emailFileType, additionalInfoMap);



/*      */ 
/*  915 */         long reportJobId = this.activeReportThreadManager.getReportJobId(Thread.currentThread().getName());
/*  916 */         if (this.activeReportThreadManager.isReportJobCancelled(reportJobId))
/*      */         {
/*  918 */           sReportUsageLogNotifier.setReportCancelled();
/*      */           return;
/*      */         }
/*      */ 
/*  922 */         ByteArrayInputStream bis = new ByteArrayInputStream(reportOutput);

/*      */ 
/*  925 */         if (ReportConstants.EmailType.ATTACH.isType(emailType)) {
/*  926 */           this.reportQueueLogger.debug("Found scheduled report is of type attach");
/*  927 */           createFileFromStream(f, bis);
/*      */ 
/*  929 */           String subject = emailSubject;
/*  930 */           if (subject == null) {
/*  931 */             subject = "Report " + reportName;

/*      */           }
/*      */ 
/*  935 */           MXServer.sendEMail(emailAddresses, null, null, emailAddress, subject, emailComments, null, new String[] { f.getAbsolutePath() }, (String[])null);


/*      */         }
/*  939 */         else if (ReportConstants.EmailType.URL.isType(emailType)) {
/*  940 */           this.reportQueueLogger.debug("Found scheduled report is of type url");
/*  941 */           MboRemote rptOutput = createReportOutput(userId, reportName, appName, emailAddress, emailAddresses, emailFileType, reportOutput);
/*  942 */           sendUrlEmail(rptOutput, maximoUrl, emailSubject, emailComments);
/*      */         }
/*      */         else {
/*  945 */           String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "InvalidScheduledEmailType").getMessage();

/*      */ 
/*  948 */           this.reportQueueLogger.error(message);
/*  949 */           throw new MXSystemException("reports", "InvalidScheduledEmailType");


/*      */         }
/*      */ 
/*  954 */         if (!(sReportUsageLogNotifier.isSuccess()))
/*      */         {
/*  956 */           sReportUsageLogNotifier.setSuccess(true);
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*  962 */         sReportUsageLogNotifier.setSuccess(false);



/*      */         try
/*      */         {
/*  968 */           ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  969 */           PrintStream ps = new PrintStream(bos);

/*      */ 
/*  972 */           t.printStackTrace(ps);
/*  973 */           ps.flush();
/*  974 */           bos.flush();
/*      */ 
/*  976 */           String errorStackTrace = bos.toString();
/*      */ 
/*  978 */           emailComments = "[" + appName + "] " + reportName + "\n\n" + errorStackTrace;
/*      */ 
/*  980 */           String subject = emailSubject + " [FAILED TO RUN]";
/*  981 */           if (subject == null)
/*      */           {
/*  983 */             subject = "Report " + reportName + " [FAILED TO RUN]";
/*      */           }
/*  985 */           MXServer.sendEMail(emailAddress, null, null, emailAddress, subject, emailComments, null, (String[])null, (String[])null);
/*      */         }
/*      */         catch (Throwable ex)
/*      */         {
/*      */         }
/*      */ 
/*  991 */         if (this.reportQueueLogger.isErrorEnabled())
/*      */         {
/*  993 */           this.reportQueueLogger.error("Failed to run queued report.", t);
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/*  998 */         if (tempFolder != null)
/*      */         {
/* 1000 */           deleteFolder(tempFolder);


/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1010 */       if (!(this.reportQueueLogger.isErrorEnabled()))
/*      */         return;
/* 1012 */       this.reportQueueLogger.error("Failed to run queued report.", t);
/*      */     }
/*      */   }














/*      */   private void sendUrlEmail(MboRemote rptOutput, String maximoUrl, String emailSubject, String emailComments)
/*      */     throws RemoteException, MXException, MessagingException, UnsupportedEncodingException
/*      */   {
/* 1032 */     String fromAddress = rptOutput.getString("EMAILADDRESS");
/* 1033 */     ReportOutputAuthSetRemote rptOutputAuthSet = (ReportOutputAuthSetRemote)rptOutput.getMboSet("REPORTOUTPUTAUTH");
/* 1034 */     String[] recipientsArray = (String[])rptOutputAuthSet.getRecipients().toArray(new String[0]);
/*      */ 
/* 1036 */     StringBuffer emailContent = new StringBuffer("<html><body>");
/* 1037 */     emailContent.append("<pre>").append(emailComments).append("</pre>");

/*      */ 
/* 1040 */     Message msg = MXServer.getMXServer().getMaxMessageCache().getMessage("reports", "emailurl_body_text");
/* 1041 */     emailContent.append("<hr/> <p>");
/* 1042 */     if (msg == null) {
/* 1043 */       emailContent.append("You have received access to a scheduled Maximo Report. Click on the URL below to access the report within the Maximo applications.");
/*      */     }
/*      */     else {
/* 1046 */       emailContent.append(msg.getMessage());
/*      */     }
/* 1048 */     emailContent.append("</p><br/> \n");




/*      */ 
/* 1054 */     StringBuffer urlSB = new StringBuffer(maximoUrl);
/* 1055 */     urlSB.append("/ui/login?event=loadapp&value=rptoutput");
/* 1056 */     urlSB.append("&additionalevent=sqlwhere&additionaleventvalue=");
/* 1057 */     urlSB.append("(jobnum='").append(URLEncoder.encode(rptOutput.getString("JOBNUM"), "UTF-8")).append("')");
/* 1058 */     urlSB.append("&forcereload=true&uisessionid=LIC");
/*      */ 
/* 1060 */     emailContent.append("\n <p><a href=\"").append(urlSB).append("\" target=\"_blank\" >").append(urlSB).append("</a></p>");
/*      */ 
/* 1062 */     emailContent.append("</body></html>");
/*      */ 
/* 1064 */     MXServer.sendEMail(recipientsArray, fromAddress, emailSubject, emailContent.toString());
/*      */   }















/*      */   private MboRemote createReportOutput(String userId, String reportName, String appName, String emailAddress, String emailAddresses, String fileType, byte[] reportContent)
/*      */     throws RemoteException, MXException
/*      */   {
/* 1084 */     ReportConstants.EmailFileTypes myFileType = null;
/* 1085 */     for (ReportConstants.EmailFileTypes emailFileType : ReportConstants.EmailFileTypes.values()) {
/* 1086 */       if (emailFileType.isType(fileType)) {
/* 1087 */         myFileType = emailFileType;
/*      */       }
/*      */     }
/*      */ 
/* 1091 */     if (myFileType == null) {
/* 1092 */       throw new MXApplicationException("reports", "InvalidScheduledEmailType");
/*      */     }
/*      */ 
/* 1095 */     String newFileName = reportName.substring(0, reportName.lastIndexOf(46));
/*      */ 
/* 1097 */     MboSetRemote reportOutputSet = MXServer.getMXServer().getMboSet("REPORTOUTPUT", getSystemUserInfo());
/* 1098 */     MboRemote reportOutput = reportOutputSet.add();
/* 1099 */     reportOutput.setValue("APPNAME", appName, 11L);
/* 1100 */     reportOutput.setValue("REPORTNAME", reportName, 11L);
/* 1101 */     reportOutput.setValue("USERID", userId, 11L);
/* 1102 */     reportOutput.setValue("EMAILADDRESS", emailAddress, 11L);
/* 1103 */     reportOutput.setValue("CREATEDDATE", MXServer.getMXServer().getDate(), 11L);
/*      */ 
/* 1105 */     String[] recipients = emailAddresses.split(",");
/* 1106 */     List badRecipients = new ArrayList();
/*      */ 
/* 1108 */     for (String recipient : recipients) {
/*      */       try {
/* 1110 */         MboRemote email = checkEmailForUser(recipient.trim());
/* 1111 */         createReportOutputAuth(reportOutput, email);
/*      */       }
/*      */       catch (MXApplicationException e) {
/* 1114 */         if ((e.getErrorGroup().equals("reports")) && (e.getErrorKey().equals("NotMaximoUserEmailAddress"))) {
/* 1115 */           badRecipients.add(recipient);
/*      */         }
/*      */         else {
/* 1118 */           throw e;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1123 */     if (badRecipients.size() > 0) {
/* 1124 */       String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "InvalidEmailForUser").getMessage(badRecipients);

/*      */ 
/* 1127 */       this.reportQueueLogger.error(message);
/*      */     }
/* 1129 */     MboSetRemote reportOutputCntSet = reportOutput.getMboSet("REPORTOUTPUTCNT");
/* 1130 */     MboRemote reportOutputCnt = reportOutputCntSet.add();
/* 1131 */     reportOutputCnt.setValue("CONTENT", reportContent, 11L);
/* 1132 */     reportOutputCnt.setValue("FILETYPE", myFileType.getName(), 11L);
/*      */ 
/* 1134 */     reportOutputCnt.setValue("FILENAME", newFileName, 11L);
/*      */ 
/* 1136 */     reportOutputSet.save();
/*      */ 
/* 1138 */     return reportOutput;
/*      */   }








/*      */   private void createReportOutputAuth(MboRemote reportOutput, MboRemote email)
/*      */     throws RemoteException, MXException
/*      */   {
/* 1151 */     MboSetRemote reportOutputAuthSet = reportOutput.getMboSet("REPORTOUTPUTAUTH");
/* 1152 */     MboRemote reportOutputAuth = reportOutputAuthSet.add();
/*      */ 
/* 1154 */     reportOutputAuth.setValue("USERID", email.getString("PERSONID"), 11L);
/* 1155 */     reportOutputAuth.setValue("EMAILADDRESS", email.getString("EMAILADDRESS"), 11L);
/*      */   }








/*      */   private MboRemote checkEmailForUser(String recipient)
/*      */     throws MXException, RemoteException, MXApplicationException
/*      */   {
/* 1168 */     MboSetRemote emailSet = MXServer.getMXServer().getMboSet("EMAIL", getSystemUserInfo());
/* 1169 */     emailSet.setQbeExactMatch(true);
/* 1170 */     emailSet.setQbeCaseSensitive(false);
/* 1171 */     emailSet.setQbe("EMAILADDRESS", recipient.trim().toLowerCase());
/* 1172 */     emailSet.reset();
/*      */ 
/* 1174 */     if (emailSet.count() == 0) {
/* 1175 */       String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "InvalidEmailForUser").getMessage(recipient);

/*      */ 
/* 1178 */       this.reportQueueLogger.error(message);
/* 1179 */       throw new MXApplicationException("reports", "InvalidEmailForUser");
/*      */     }
/*      */ 
/* 1182 */     MboRemote email = emailSet.getMbo(0);
/* 1183 */     return email;
/*      */   }





/*      */   protected String getReportOutputFileName(String tempFolder, String reportName, String appName, Locale locale)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1193 */     SimpleDateFormat df = new SimpleDateFormat("ddMMMyyyy_hhmmaaa", locale);
/* 1194 */     String curTime = df.format(MXServer.getMXServer().getDate());

/*      */ 
/* 1197 */     MboSetRemote reportSet = MXServer.getMXServer().getMboSet("REPORT", getSystemUserInfo());
/* 1198 */     reportSet.setQbe("REPORTNAME", reportName);
/* 1199 */     reportSet.setQbe("APPNAME", appName);
/* 1200 */     reportSet.reset();
/*      */ 
/* 1202 */     MboRemote report = reportSet.getMbo(0);
/* 1203 */     String reportDescription = report.getString("DESCRIPTION");



/*      */     String outputFileName;
/* 1208 */     if ((reportDescription != null) && (!(reportDescription.equals(""))))
/*      */     {
/* 1210 */       int spacePos = reportDescription.indexOf(" ");
/* 1211 */       while (spacePos > 0)
/*      */       {
/* 1213 */         reportDescription = reportDescription.substring(0, spacePos) + "_" + reportDescription.substring(spacePos + 1);
/*      */ 
/* 1215 */         spacePos = reportDescription.indexOf(" ");
/*      */       }
/*      */ 
/* 1218 */       String outputFileName = reportDescription + "_" + curTime;



/*      */       try
/*      */       {
/* 1224 */         File f = new File(tempFolder + File.separator + outputFileName);
/* 1225 */         f.getParentFile().mkdirs();
/* 1226 */         f.createNewFile();
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/* 1230 */         outputFileName = reportName + "_" + curTime;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1235 */       outputFileName = reportName + "_" + curTime;
/*      */     }
/*      */ 
/* 1238 */     return outputFileName;
/*      */   }

/*      */   protected String getEmailAddress(String userId) throws MXException, RemoteException
/*      */   {
/* 1243 */     MboSetRemote maxUserSetRemote = null;
/*      */     try
/*      */     {
/* 1246 */       MXServer mxServer = MXServer.getMXServer();


/*      */ 
/* 1250 */       maxUserSetRemote = mxServer.getMboSet("MAXUSER", getSystemUserInfo());
/* 1251 */       maxUserSetRemote.setQbeExactMatch(true);
/* 1252 */       maxUserSetRemote.setQbe("USERID", userId);
/* 1253 */       maxUserSetRemote.reset();
/*      */ 
/* 1255 */       MboRemote maxUserRemote = maxUserSetRemote.getMbo(0);
/* 1256 */       if (maxUserRemote == null)
/*      */       {
/* 1258 */         if (this.reportQueueLogger.isErrorEnabled())
/*      */         {
/* 1260 */           this.reportQueueLogger.error("UserId [" + userId + "] used to schedule the report does not exist.");
/*      */         }
/*      */ 
/* 1263 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/* 1266 */       MboSetRemote personSetRemote = maxUserRemote.getMboSet("PERSON");
/* 1267 */       MboRemote personRemote = personSetRemote.getMbo(0);
/* 1268 */       if (personRemote == null)
/*      */       {
/* 1270 */         if (this.reportQueueLogger.isErrorEnabled())
/*      */         {
/* 1272 */           this.reportQueueLogger.error("UserId [" + userId + "] used to schedule the report does not have a person record. May not include from address.");
/*      */         }
/*      */ 
/* 1275 */         Object localObject2 = null;
/*      */         return localObject2;
/*      */       }
/* 1278 */       MboSetRemote emailSetRemote = personRemote.getMboSet("PRIMARYEMAIL");
/* 1279 */       MboRemote emailRemote = emailSetRemote.getMbo(0);
/* 1280 */       if (emailRemote == null)
/*      */       {
/* 1282 */         if (this.reportQueueLogger.isErrorEnabled())
/*      */         {
/* 1284 */           this.reportQueueLogger.error("UserId [" + userId + "] used to schedule the report does not have a primary email accout.");
/*      */         }
/*      */ 
/* 1287 */         Object localObject3 = null;
/*      */         return localObject3;
/*      */       }
/* 1290 */       String emailAddress = emailRemote.getString("EMAILADDRESS");
/*      */ 
/* 1292 */       t = emailAddress;
/*      */     }/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1297 */         if (maxUserSetRemote != null)
/*      */         {
/* 1299 */           maxUserSetRemote.reset();/*      */         }/*      */       }/*      */       catch (Throwable t)/*      */       {/*      */       }/*      */     }/*      */   }
/*      */ 
/* 1301 */       return t;






/*      */   public int getMaxAllowedActiveReportThreads()
/*      */   {
/*      */     try {
/* 1311 */       MXServer mxServer = MXServer.getMXServer();
/*      */ 
/* 1313 */       String maxCRunStr = mxServer.getProperty("mxe.report.birt.maxconcurrentrun");
/* 1314 */       if (maxCRunStr == null)
/*      */       {
/* 1316 */         return 3;
/*      */       }
/*      */ 
/* 1319 */       int maxAllowed = Integer.valueOf(maxCRunStr).intValue();
/*      */ 
/* 1321 */       return maxAllowed;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1325 */       if (this.reportQueueLogger.isErrorEnabled())
/*      */       {
/* 1327 */         this.reportQueueLogger.error("Failed to obtain [mxe.report.birt.maxconcurrentrun] property value. Assuming default [3].", e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1332 */     return 3;
/*      */   }



/*      */   public int getQueueIdleTime()
/*      */   {
/*      */     try
/*      */     {
/* 1341 */       MXServer mxServer = MXServer.getMXServer();
/*      */ 
/* 1343 */       String idleTimeStr = mxServer.getProperty("mxe.report.birt.queueidletimeseconds");
/* 1344 */       if (idleTimeStr == null)
/*      */       {
/* 1346 */         return 60;
/*      */       }
/*      */ 
/* 1349 */       int idleTimeSeconds = Integer.valueOf(idleTimeStr).intValue();
/*      */ 
/* 1351 */       return idleTimeSeconds;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1355 */       if (this.reportQueueLogger.isErrorEnabled())
/*      */       {
/* 1357 */         this.reportQueueLogger.error("Failed to obtain [mxe.report.birt.queueidletimeseconds] property value. Assuming default [60].", e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1362 */     return 60;
/*      */   }

/*      */   private void deleteFolder(String folderName)
/*      */   {
/* 1367 */     if (folderName == null)
/*      */     {
/* 1369 */       return;
/*      */     }
/*      */ 
/* 1372 */     File folder = new File(folderName);
/* 1373 */     deleteAllFilesFromFolder(folder);
/* 1374 */     folder.delete();
/*      */   }

/*      */   private void deleteAllFilesFromFolder(File folder)
/*      */   {
/* 1379 */     File[] files = folder.listFiles();
/* 1380 */     for (int i = 0; i < files.length; ++i)
/*      */     {
/* 1382 */       File f = files[i];
/* 1383 */       if (f.isDirectory())
/*      */       {
/* 1385 */         deleteAllFilesFromFolder(f);
/* 1386 */         f.delete();
/*      */       }
/*      */       else
/*      */       {
/* 1390 */         f.delete();
/*      */       }
/*      */     }
/*      */   }

/*      */   public void createFileFromStream(File file, InputStream inputStream)
/*      */     throws IOException
/*      */   {
/* 1398 */     FileOutputStream fos = new FileOutputStream(file);
/*      */ 
/* 1400 */     byte[] buf = new byte[1024];
/*      */     while (true)
/*      */     {
/* 1403 */       int bytesRead = inputStream.read(buf);
/* 1404 */       if (bytesRead <= 0) {
/*      */         break;
/*      */       }
/*      */ 
/* 1408 */       fos.write(buf, 0, bytesRead);
/*      */     }
/*      */ 
/* 1411 */     fos.flush();
/* 1412 */     fos.close();
/*      */   }

/*      */   private UserInfo getSystemUserInfo() throws MXException, RemoteException
/*      */   {
/* 1417 */     MXServer mxServer = MXServer.getMXServer();
/*      */ 
/* 1419 */     return mxServer.getSystemUserInfo();
/*      */   }
/*      */ }
