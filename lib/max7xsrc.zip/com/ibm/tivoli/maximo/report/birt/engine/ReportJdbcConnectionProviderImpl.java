/*    */ package com.ibm.tivoli.maximo.report.birt.engine;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportJdbcConnectionProvider;
/*    */ import java.sql.Connection;
/*    */ import psdi.security.UserInfo;
/*    */ import psdi.server.DBManager;
/*    */ 


















/*    */ public class ReportJdbcConnectionProviderImpl
/*    */   implements ReportJdbcConnectionProvider
/*    */ {
/* 29 */   private UserInfo userInfo = null;
/* 30 */   private Connection connection = null;
/* 31 */   private DBManager dbManager = null;
/*    */ 
/*    */   public ReportJdbcConnectionProviderImpl(UserInfo userInfo, DBManager dbManager)
/*    */   {
/* 35 */     this.userInfo = userInfo;
/* 36 */     this.dbManager = dbManager;
/*    */   }

/*    */   public Connection getConnection()
/*    */   {
/* 41 */     if (this.connection == null)
/*    */     {
/* 43 */       this.connection = this.dbManager.getConnection(this.userInfo.getConnectionKey());
/*    */     }
/*    */ 
/* 46 */     return this.connection;
/*    */   }

/*    */   public void freeConnection()
/*    */   {
/* 51 */     if (this.connection == null)
/*    */       return;
/* 53 */     this.dbManager.freeConnection(this.userInfo.getConnectionKey());
/* 54 */     this.connection = null;
/*    */   }
/*    */ }
