/*    */ package com.ibm.tivoli.maximo.report.birt.custom.servlet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.admin.DataRestrictionProvider;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.util.MXException;
/*    */ 

















/*    */ public class CustomImmediateReportDataRestrictionProvider
/*    */   implements DataRestrictionProvider
/*    */ {
/*    */   public String getDataRestrictionWhere()
/*    */     throws MXException, RemoteException
/*    */   {
/* 30 */     return "";
/*    */   }
/*    */ }
