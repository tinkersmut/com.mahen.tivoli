/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminServiceRemote;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportUsageLogInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportUsageLogNotifier;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import java.util.Date;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServerRemote;
/*     */ 

















/*     */ public class ImmediateReportUsageLogNotifier
/*     */   implements ReportUsageLogNotifier
/*     */ {
/*     */   private ReportAdminServiceRemote birtAdminService;
/*  32 */   private UserInfo userInfo = null;
/*  33 */   private ReportUsageLogInfo usageLogInfo = new ReportUsageLogInfo();
/*  34 */   private ReportLogger reportLogger = null;
/*  35 */   private MXServerRemote mxServerRemote = null;
/*     */ 
/*     */   public ImmediateReportUsageLogNotifier()
/*     */   {
/*  39 */     this.usageLogInfo.setImmediateJob(true);
/*     */   }

/*     */   public void setMXServerRemote(MXServerRemote mxServerRemote)
/*     */   {
/*  44 */     this.mxServerRemote = mxServerRemote;
/*     */   }

/*     */   public void setUserInfo(UserInfo userInfo)
/*     */   {
/*  49 */     this.userInfo = userInfo;
/*     */   }

/*     */   public void setReportLogger(ReportLogger reportLogger)
/*     */   {
/*  54 */     this.reportLogger = reportLogger;
/*     */   }

/*     */   public ReportAdminServiceRemote getBirtAdminService()
/*     */   {
/*  59 */     return this.birtAdminService;
/*     */   }

/*     */   public void setBirtAdminService(ReportAdminServiceRemote birtAdminService)
/*     */   {
/*  64 */     this.birtAdminService = birtAdminService;
/*     */   }

/*     */   public void setAppName(String appName)
/*     */   {
/*  69 */     this.usageLogInfo.setAppName(appName);
/*     */   }

/*     */   public void setReportName(String reportName)
/*     */   {
/*  74 */     this.usageLogInfo.setReportName(reportName);
/*     */   }

/*     */   public void setEnterDate(Date enterDate)
/*     */   {
/*  79 */     this.usageLogInfo.setEnterDate(enterDate);
/*     */   }

/*     */   public void setStartDate(Date startDate)
/*     */   {
/*  84 */     this.usageLogInfo.setStartDate(startDate);
/*     */   }

/*     */   public void setEndDate(Date endDate)
/*     */   {
/*  89 */     this.usageLogInfo.setEndDate(endDate);
/*     */   }

/*     */   public void setRuntime(long runtime)
/*     */   {
/*  94 */     this.usageLogInfo.setRuntime(runtime);
/*     */   }

/*     */   public void setSuccess(boolean success)
/*     */   {
/*  99 */     this.usageLogInfo.setSuccess(success);
/*     */   }

/*     */   public void setReportFailed()
/*     */   {
/* 104 */     this.usageLogInfo.setSuccess(false);
/*     */   }

/*     */   public void setUserId(String userId)
/*     */   {
/* 109 */     this.usageLogInfo.setUserId(userId);
/*     */   }

/*     */   public void setHostName(String hostName)
/*     */   {
/* 114 */     this.usageLogInfo.setHostName(hostName);
/*     */   }

/*     */   public void setServerName(String serverName)
/*     */   {
/* 119 */     this.usageLogInfo.setServerName(serverName);
/*     */   }

/*     */   public void setTransientReport(boolean isTransientReport)
/*     */   {
/* 124 */     this.usageLogInfo.setTransientReport(isTransientReport);
/*     */   }

/*     */   public void setReportExecuted()
/*     */   {
/* 129 */     this.usageLogInfo.setReportExecuted(true);
/*     */   }

/*     */   public void createUsageLog()
/*     */   {
/*     */     try
/*     */     {
/* 136 */       this.usageLogInfo.setEndDate(this.mxServerRemote.getDate());
/*     */ 
/* 138 */       long startTime = this.usageLogInfo.getStartDate().getTime();
/* 139 */       long endTime = this.usageLogInfo.getEndDate().getTime();
/*     */ 
/* 141 */       long runtime = endTime - startTime;
/* 142 */       this.usageLogInfo.setRuntime(runtime);
/*     */ 
/* 144 */       this.birtAdminService.createReportUsageLog(this.userInfo, this.usageLogInfo);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 148 */       if ((this.reportLogger == null) || 

/* 150 */         (!(this.reportLogger.isErrorEnabled())))
/*     */         return;
/* 152 */       this.reportLogger.error("Failed to write report usage log", t);
/*     */     }
/*     */   }



/*     */   public void setReportCancelled()
/*     */   {
/* 160 */     this.usageLogInfo.setCancelled(true);
/* 161 */     this.usageLogInfo.setSuccess(false);
/*     */   }
/*     */ }
