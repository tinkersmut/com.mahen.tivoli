/*     */ package com.ibm.tivoli.maximo.report.birt.design;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportImportParamInfo;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 






/*     */ public class CreateReportInputInfo
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private String name;
/*     */   private String description;
/*     */   private String displayName;
/*     */   private String appName;
/*     */   private String userName;
/*     */   private String mboName;
/*     */   private String entityName;
/*     */   private boolean fixedQuery;
/*     */   private List<CreateListReportInputInfo> listReportInputInfoList;
/*     */   private boolean toBeSaved;
/*     */   private boolean isPublic;
/*     */   private HashMap<String, String> messages;
/*     */   private String[] bidiProperties;
/*     */   private ArrayList<ReportImportParamInfo> importParamInfoList;
/*     */   private ArrayList<ReportParameterInfo> designParamInfoList;
/*     */ 
/*     */   public CreateReportInputInfo()
/*     */   {
/*  37 */     this.name = null;
/*     */ 
/*  39 */     this.description = null;
/*     */ 
/*  41 */     this.displayName = null;
/*     */ 
/*  43 */     this.appName = null;
/*     */ 
/*  45 */     this.userName = null;

/*     */ 
/*  48 */     this.mboName = null;

/*     */ 
/*  51 */     this.entityName = null;

/*     */ 
/*  54 */     this.fixedQuery = false;

/*     */ 
/*  57 */     this.listReportInputInfoList = new ArrayList();
/*     */ 
/*  59 */     this.toBeSaved = false;
/*     */ 
/*  61 */     this.isPublic = false;
/*     */ 
/*  63 */     this.messages = new HashMap();
/*     */ 
/*  65 */     this.bidiProperties = new String[] { "", "" };

/*     */ 
/*  68 */     this.importParamInfoList = new ArrayList();

/*     */ 
/*  71 */     this.designParamInfoList = new ArrayList();
/*     */   }







/*     */   public String getName()
/*     */   {
/*  82 */     return this.name;
/*     */   }

/*     */   public void setName(String name)
/*     */   {
/*  87 */     this.name = name;
/*     */   }

/*     */   public String getDescription()
/*     */   {
/*  92 */     return this.description;
/*     */   }

/*     */   public void setDescription(String description)
/*     */   {
/*  97 */     this.description = description;
/*     */   }

/*     */   public String getDisplayName()
/*     */   {
/* 102 */     return this.displayName;
/*     */   }

/*     */   public void setDisplayName(String displayName)
/*     */   {
/* 107 */     this.displayName = displayName;
/*     */   }

/*     */   public String getAppName()
/*     */   {
/* 112 */     return this.appName;
/*     */   }

/*     */   public void setAppName(String appName)
/*     */   {
/* 117 */     this.appName = appName;
/*     */   }

/*     */   public String getUserName()
/*     */   {
/* 122 */     return this.userName;
/*     */   }

/*     */   public void setUserName(String userName)
/*     */   {
/* 127 */     this.userName = userName;
/*     */   }

/*     */   public String getMboName()
/*     */   {
/* 132 */     return this.mboName;
/*     */   }

/*     */   public void setMboName(String mboName)
/*     */   {
/* 137 */     this.mboName = mboName;
/*     */   }

/*     */   public String getEntityName()
/*     */   {
/* 142 */     return this.entityName;
/*     */   }

/*     */   public void setEntityName(String entityName)
/*     */   {
/* 147 */     this.entityName = entityName;
/*     */   }

/*     */   public boolean hasFixedQuery()
/*     */   {
/* 152 */     return this.fixedQuery;
/*     */   }

/*     */   public void setFixedQuery(boolean fixedQuery)
/*     */   {
/* 157 */     this.fixedQuery = fixedQuery;
/*     */   }

/*     */   public boolean isToBeSaved()
/*     */   {
/* 162 */     return this.toBeSaved;
/*     */   }

/*     */   public void setToBeSaved(boolean toBeSaved)
/*     */   {
/* 167 */     this.toBeSaved = toBeSaved;
/*     */   }

/*     */   public boolean isPublic()
/*     */   {
/* 172 */     return this.isPublic;
/*     */   }

/*     */   public void setIsPublic(boolean isPublic)
/*     */   {
/* 177 */     this.isPublic = isPublic;
/*     */   }

/*     */   public HashMap<String, String> getMessages()
/*     */   {
/* 182 */     return this.messages;
/*     */   }

/*     */   public void setMessages(HashMap<String, String> messages)
/*     */   {
/* 187 */     this.messages = messages;
/*     */   }

/*     */   public void addListReportInputInfo(CreateListReportInputInfo listReportInfo)
/*     */   {
/* 192 */     this.listReportInputInfoList.add(listReportInfo);
/*     */   }

/*     */   public Iterator getAllListReportInputInfo()
/*     */   {
/* 197 */     return this.listReportInputInfoList.iterator();
/*     */   }

/*     */   public void setBidiProperties(String layoutOrient, String textDir) {
/* 201 */     this.bidiProperties[0] = layoutOrient;
/* 202 */     this.bidiProperties[1] = textDir;
/*     */   }

/*     */   public String[] getBidiProperties() {
/* 206 */     return this.bidiProperties;
/*     */   }

/*     */   public int getListReportCount()
/*     */   {
/* 211 */     return this.listReportInputInfoList.size();
/*     */   }

/*     */   public void addImportParamInfo(ReportImportParamInfo designParamInfo)
/*     */   {
/* 216 */     this.importParamInfoList.add(designParamInfo);
/*     */   }

/*     */   public Iterator getAllImportParamInfo()
/*     */   {
/* 221 */     return this.importParamInfoList.iterator();
/*     */   }

/*     */   public void addDesignParamInfo(ReportParameterInfo importParamInfo)
/*     */   {
/* 226 */     this.designParamInfoList.add(importParamInfo);
/*     */   }

/*     */   public Iterator getAllDesignParamInfo()
/*     */   {
/* 231 */     return this.designParamInfoList.iterator();
/*     */   }

/*     */   public Object clone()
/*     */   {
/* 236 */     CreateReportInputInfo clone = new CreateReportInputInfo();
/*     */ 
/* 238 */     clone.appName = this.appName;
/* 239 */     clone.description = this.description;
/* 240 */     clone.displayName = this.displayName;
/* 241 */     clone.fixedQuery = this.fixedQuery;
/* 242 */     clone.mboName = this.mboName;
/* 243 */     clone.entityName = this.entityName;
/* 244 */     clone.name = this.name;
/* 245 */     clone.userName = this.userName;
/* 246 */     clone.toBeSaved = this.toBeSaved;
/* 247 */     clone.isPublic = this.isPublic;
/* 248 */     clone.messages = this.messages;
/* 249 */     clone.bidiProperties[0] = this.bidiProperties[0];
/* 250 */     clone.bidiProperties[1] = this.bidiProperties[1];
/* 251 */     clone.importParamInfoList = this.importParamInfoList;
/* 252 */     clone.designParamInfoList = this.designParamInfoList;
/*     */ 
/* 254 */     int size = this.listReportInputInfoList.size();
/* 255 */     for (int i = 0; i < size; ++i)
/*     */     {
/* 257 */       CreateListReportInputInfo listReportInfo = (CreateListReportInputInfo)this.listReportInputInfoList.get(i);
/* 258 */       CreateListReportInputInfo clonelistReportInfo = (CreateListReportInputInfo)listReportInfo.clone();
/*     */ 
/* 260 */       clone.addListReportInputInfo(clonelistReportInfo);
/*     */     }
/*     */ 
/* 263 */     return clone;
/*     */   }
/*     */ }
