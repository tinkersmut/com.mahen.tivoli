/*     */ package com.ibm.tivoli.maximo.report.birt.admin.batch;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.AdminServiceTempLocation;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminServiceRemote;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportImportInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportImportParamInfo;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.MXServerInfo;
/*     */ import psdi.server.MaximoThread;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.FixedLoggers;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 

















/*     */ public class BatchImport
/*     */ {
/*     */   public static final String BIRTREPORTS_ZIPFILENAME = "reports.zip";
/*     */   public static final String BIRTREPORTS_BATCHIMPORTFOLDER = "batchimport";
/*  53 */   private ReportAdminServiceRemote birtAdminService = null;
/*  54 */   private UserInfo userInfo = null;
/*  55 */   private MXLogger reportAdminServiceLogger = null;
/*  56 */   private int noOfReportsImported = 0;
/*     */ 
/* 429 */   private HashMap<String, String> librariesImported = null;
/*     */ 
/* 474 */   private HashMap<String, String> reportsImported = null;
/*     */ 
/*     */   public BatchImport(ReportAdminServiceRemote birtAdminService, UserInfo userInfo, MXLogger reportAdminServiceLogger)
/*     */   {
/*  60 */     this.birtAdminService = birtAdminService;
/*  61 */     this.userInfo = userInfo;
/*  62 */     this.reportAdminServiceLogger = reportAdminServiceLogger;
/*     */   }

/*     */   public void start() throws Exception
/*     */   {
/*  67 */     BatchImportThread importThread = new BatchImportThread();
/*  68 */     String tempReportsRoot = extract();
/*  69 */     if (tempReportsRoot == null)
/*     */     {
/*  71 */       return;
/*     */     }
/*     */ 
/*  74 */     importThread.setReportRoot(tempReportsRoot);
/*  75 */     importThread.start();
/*     */   }

/*     */   protected boolean isReady()
/*     */   {
/*  80 */     MXServerInfo serverInfo = MXServerInfo.getMXServerInfo();
/*     */ 
/*  82 */     boolean ready = serverInfo.isRunning();
/*     */ 
/*  84 */     return ready;
/*     */   }

/*     */   class BatchImportThread extends MaximoThread
/*     */   {
/*  89 */     private String tempReportsRoot = null;
/*     */ 
/*     */     public BatchImportThread()
/*     */     {
/*  93 */       super("BirtReportsBatchImport");
/*     */     }

/*     */     public void setReportRoot(String root)
/*     */     {
/*  98 */       this.tempReportsRoot = root;
/*     */     }

/*     */     public void run()
/*     */     {
/*     */       try {
/*     */         while (true) {
/* 105 */           label0: if (BatchImport.this.isReady()) {
/*     */             break label33;
/*     */           }
/*     */           try
/*     */           {
/* 110 */             Thread.sleep(10000L);
/*     */           }
/*     */           catch (InterruptedException e)
/*     */           {
/* 114 */             if (!(isMarkedForShutDown()))
/*     */               break label30;
/*     */           }
/*     */         }
/* 118 */         label30: break label0:

/*     */ 
/* 121 */         if (isMarkedForShutDown())
/*     */         {
/*     */           label33: return;
/*     */         }
/*     */ 
/* 126 */         MXLogger maximoLogger = FixedLoggers.MAXIMOLOGGER;
/* 127 */         if (maximoLogger.isInfoEnabled())
/*     */         {
/* 129 */           maximoLogger.info("Trying to determine if any reports need to be imported.");
/*     */         }
/*     */ 
/* 132 */         BatchImport.this.extractZipContents(this.tempReportsRoot);
/*     */ 
/* 134 */         long start = System.currentTimeMillis();
/* 135 */         BatchImport.this.importAll(this.tempReportsRoot);
/* 136 */         long end = System.currentTimeMillis();
/*     */ 
/* 138 */         if ((BatchImport.this.noOfReportsImported == 0) && 

/* 140 */           (maximoLogger.isInfoEnabled()))
/*     */         {
/* 142 */           maximoLogger.info("No reports need to be imported.");

/*     */         }
/*     */ 
/* 146 */         if ((BatchImport.this.noOfReportsImported > 0) && 

/* 148 */           (maximoLogger.isInfoEnabled()))
/*     */         {
/* 150 */           maximoLogger.info("Reports imported (took: " + ((end - start) / 1000L) + " seconds).");
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 156 */         if (BatchImport.this.reportAdminServiceLogger.isErrorEnabled())
/*     */         {
/* 158 */           BatchImport.this.reportAdminServiceLogger.error("Failed to import reports.", ex);
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 163 */         BatchImport.this.deleteFolder(this.tempReportsRoot);
/*     */       }
/*     */     }
/*     */   }

/*     */   protected String extract()
/*     */     throws IOException
/*     */   {
/* 171 */     String tempFolder = AdminServiceTempLocation.getTemporaryImportLocation();
/* 172 */     String tempReportFolder = tempFolder + File.separator + "batchimport";
/*     */ 
/* 174 */     InputStream inputStream = super.getClass().getResourceAsStream("/importreports/reports.zip");
/*     */ 
/* 176 */     if (inputStream == null)
/*     */     {
/* 178 */       return null;
/*     */     }
/*     */ 
/* 181 */     File f = new File(tempReportFolder + File.separator + "reports.zip");
/* 182 */     new File(tempReportFolder).mkdirs();
/* 183 */     createFileFromStream(f, inputStream);
/*     */ 
/* 185 */     return tempReportFolder;
/*     */   }

/*     */   protected void extractZipContents(String tempReportFolder) throws IOException
/*     */   {
/* 190 */     File f = new File(tempReportFolder + File.separator + "reports.zip");
/* 191 */     extractReportsZipFile(f, tempReportFolder);
/*     */   }

/*     */   protected void importAll(String reportFolder)
/*     */   {
/* 196 */     String librariesRootFolder = reportFolder + File.separator + "libraries";
/* 197 */     String reportsRootFolder = reportFolder + File.separator + "reports";

/*     */ 
/* 200 */     importLibraries(librariesRootFolder);

/*     */ 
/* 203 */     importReports(reportsRootFolder, librariesRootFolder);
/*     */   }

/*     */   protected void importLibraries(String librariesRootFolder)
/*     */   {
/* 208 */     LibrariesLoader libraries = new LibrariesLoader();
/*     */ 
/* 210 */     String libraryPath = librariesRootFolder;
/*     */ 
/* 212 */     File fLibrary = new File(libraryPath);
/* 213 */     File[] xmlFiles = fLibrary.listFiles(new XMLFileNameFilter());
/* 214 */     for (int i = 0; i < xmlFiles.length; ++i)
/*     */     {
/* 216 */       File reportsXML = xmlFiles[i];
/*     */ 
/* 218 */       if (!(reportsXML.exists()))
/*     */         continue;
/* 220 */       ArrayList librariesList = null;

/*     */       try
/*     */       {
/* 224 */         librariesList = libraries.loadLibraries(reportsXML.getAbsolutePath());
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 228 */         if (this.reportAdminServiceLogger.isErrorEnabled())
/*     */         {
/* 230 */           this.reportAdminServiceLogger.error("Failed to get libraries list.");
/*     */         }
/*     */       }
/*     */ 
/* 234 */       if (librariesList == null)
/*     */       {
/* 236 */         return;
/*     */       }
/*     */ 
/* 239 */       Iterator reportInfoIterator = librariesList.iterator();
/* 240 */       while (reportInfoIterator.hasNext())
/*     */       {
/* 242 */         LibraryInfo libraryInfo = (LibraryInfo)reportInfoIterator.next();

/*     */         try
/*     */         {
/* 246 */           if (!(isReportLibraryAlreadyPresent(libraryInfo.getName())));




/* 251 */           ReportImportInfo reportImportInfo = new ReportImportInfo();
/*     */ 
/* 253 */           reportImportInfo.setLibrary(true);
/* 254 */           reportImportInfo.setName(libraryInfo.getName());
/* 255 */           reportImportInfo.setFileName(libraryInfo.getAttribute("filename"));
/* 256 */           reportImportInfo.setResources(libraryInfo.getReportResourcesZipData());
/* 257 */           reportImportInfo.setXmlReportData(libraryInfo.getContent());

/*     */ 
/* 260 */           Iterator attrIterator = libraryInfo.getAttributes();
/* 261 */           while (attrIterator.hasNext())
/*     */           {
/* 263 */             String attributeName = (String)attrIterator.next();
/* 264 */             String attributeValue = libraryInfo.getAttribute(attributeName);
/* 265 */             reportImportInfo.setAttribute(attributeName, attributeValue);
/*     */           }
/*     */ 
/* 268 */           getReportAdminService().importReportLibrary(getUserInfo(), reportImportInfo);
/* 269 */           this.noOfReportsImported += 1;
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 273 */           if (this.reportAdminServiceLogger.isErrorEnabled())
/*     */           {
/* 275 */             this.reportAdminServiceLogger.error("Failed to import library: " + libraryInfo.getName());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }


/*     */   protected void importReports(String reportsRootFolder, String librariesRootFolder)
/*     */   {
/* 285 */     File f = new File(reportsRootFolder);
/* 286 */     File[] files = f.listFiles();

/*     */     try
/*     */     {
/* 290 */       for (int i = 0; i < files.length; ++i)
/*     */       {
/* 292 */         File fApp = files[i];
/*     */ 
/* 294 */         if (!(fApp.isDirectory()))
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 299 */         String appName = fApp.getName();
/*     */ 
/* 301 */         boolean licensedApp = MXServer.getMXServer().isValidApp(appName);
/* 302 */         if (!(licensedApp))
/*     */           continue;
/* 304 */         importReportsOfApp(reportsRootFolder, librariesRootFolder, appName, fApp);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 310 */       if (!(this.reportAdminServiceLogger.isErrorEnabled()))
/*     */         return;
/* 312 */       this.reportAdminServiceLogger.error("Failed to import reports.", ex);
/*     */     }
/*     */   }



/*     */   protected void importReportsOfApp(String reportsRootFolder, String librariesRootFolder, String appName, File fApp)
/*     */   {
/* 320 */     ReportsLoader reports = new ReportsLoader();
/*     */ 
/* 322 */     String libraryPath = librariesRootFolder;
/* 323 */     reports.setLibraryFolder(libraryPath);

/*     */ 
/* 326 */     File[] xmlFiles = fApp.listFiles(new XMLFileNameFilter());
/* 327 */     for (int i = 0; i < xmlFiles.length; ++i)
/*     */     {
/* 329 */       File reportsXML = xmlFiles[i];
/*     */ 
/* 331 */       if (!(reportsXML.exists())) {
/*     */         continue;
/*     */       }
/* 334 */       ArrayList reportsList = null;
/*     */       try
/*     */       {
/* 337 */         reportsList = reports.loadReports(reportsXML.getAbsolutePath());
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 341 */         if (this.reportAdminServiceLogger.isErrorEnabled())
/*     */         {
/* 343 */           this.reportAdminServiceLogger.error("Failed to get reports list for application [" + appName + "]");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 348 */       if (reportsList == null)
/*     */       {
/* 350 */         return;
/*     */       }
/*     */ 
/* 353 */       Iterator reportInfoIterator = reportsList.iterator();
/* 354 */       while (reportInfoIterator.hasNext())
/*     */       {
/* 356 */         ReportInfo reportInfo = (ReportInfo)reportInfoIterator.next();

/*     */         try
/*     */         {
/* 360 */           if (!(isReportAlreadyPresent(reportInfo.getName(), appName)));




/* 365 */           ReportImportInfo reportImportInfo = new ReportImportInfo();
/*     */ 
/* 367 */           reportImportInfo.setName(reportInfo.getName());

/*     */ 
/* 370 */           String fullFileName = reportInfo.getAttribute("filename");
/*     */ 
/* 372 */           File ff = new File(fullFileName);
/* 373 */           String justFileName = ff.getName();
/*     */ 
/* 375 */           reportImportInfo.setFileName(justFileName);
/* 376 */           reportImportInfo.setAppName(appName.toUpperCase());
/* 377 */           reportImportInfo.setResources(reportInfo.getReportResourcesZipData());
/* 378 */           reportImportInfo.setXmlReportData(reportInfo.getContent());

/*     */ 
/* 381 */           Iterator attrIterator = reportInfo.getAttributes();
/* 382 */           while (attrIterator.hasNext())
/*     */           {
/* 384 */             String attributeName = (String)attrIterator.next();
/* 385 */             String attributeValue = reportInfo.getAttribute(attributeName);
/* 386 */             reportImportInfo.setAttribute(attributeName, attributeValue);

/*     */           }
/*     */ 
/* 390 */           Iterator paramIterator = reportInfo.getParameters();
/* 391 */           while (paramIterator.hasNext())
/*     */           {
/* 393 */             String paramName = (String)paramIterator.next();

/*     */ 
/* 396 */             ReportImportParamInfo importParamInfo = new ReportImportParamInfo();
/*     */ 
/* 398 */             ReportParameterInfo paramInfo = reportInfo.getParameter(paramName);
/* 399 */             Iterator paramAttributeIterator = paramInfo.getAttributes();
/* 400 */             while (paramAttributeIterator.hasNext())
/*     */             {
/* 402 */               String paramAttrName = (String)paramAttributeIterator.next();
/* 403 */               String paramAttrValue = paramInfo.getAttribute(paramAttrName);
/*     */ 
/* 405 */               importParamInfo.setAttribute(paramAttrName, paramAttrValue);
/*     */             }
/*     */ 
/* 408 */             reportImportInfo.setParameter(paramName, importParamInfo);
/*     */           }
/*     */ 
/* 411 */           getReportAdminService().importReport(getUserInfo(), reportImportInfo, false);
/* 412 */           this.noOfReportsImported += 1;
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 416 */           if (this.reportAdminServiceLogger.isErrorEnabled())
/*     */           {
/* 418 */             this.reportAdminServiceLogger.error("Failed to import report [" + reportInfo.getName() + "] for application [" + appName + "]", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }






/*     */   protected boolean isReportLibraryAlreadyPresent(String libraryName)
/*     */     throws MXException, RemoteException
/*     */   {
/* 433 */     if (this.librariesImported == null)
/*     */     {
/* 435 */       this.librariesImported = new HashMap();
/*     */ 
/* 437 */       MboSetRemote reportDesignSet = getReportAdminService().getMboSet("REPORTDESIGN", getUserInfo());
/*     */       try
/*     */       {
/* 440 */         reportDesignSet.setFlag(39L, true);
/*     */ 
/* 442 */         int i = 0;
/*     */         while (true)
/*     */         {
/* 445 */           MboRemote reportDesign = reportDesignSet.getMbo(i);
/* 446 */           if (reportDesign == null)
/*     */           {
/*     */             break;
/*     */           }
/*     */ 
/* 451 */           String reportName = reportDesign.getString("reportname");
/* 452 */           this.librariesImported.put(reportName, reportName);
/* 453 */           ++i;
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 458 */         if (reportDesignSet != null)
/*     */         {
/* 460 */           reportDesignSet.reset();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 465 */     Object obj = this.librariesImported.get(libraryName);

/*     */ 
/* 468 */     return (obj != null);
/*     */   }





/*     */   protected boolean isReportAlreadyPresent(String reportName, String appName)
/*     */     throws MXException, RemoteException
/*     */   {
/* 478 */     if (this.reportsImported == null)
/*     */     {
/* 480 */       this.reportsImported = new HashMap();
/*     */ 
/* 482 */       MboSetRemote reportSet = getReportAdminService().getMboSet("REPORT", getUserInfo());
/*     */       try
/*     */       {
/* 485 */         reportSet.setFlag(39L, true);
/*     */ 
/* 487 */         int i = 0;
/*     */         while (true)
/*     */         {
/* 490 */           MboRemote report = reportSet.getMbo(i);
/* 491 */           if (report == null)
/*     */           {
/*     */             break;
/*     */           }
/*     */ 
/* 496 */           String reportNameInDB = report.getString("reportname");
/* 497 */           String appNameInDB = report.getString("appname");
/* 498 */           if (report.getMboSet("REPORT_DESIGN").getMbo(0) != null)
/*     */           {
/* 500 */             this.reportsImported.put(reportNameInDB + "$" + appNameInDB, reportNameInDB);
/*     */           }
/* 502 */           ++i;
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 507 */         if (reportSet != null)
/*     */         {
/* 509 */           reportSet.reset();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 514 */     Object obj = this.reportsImported.get(reportName + "$" + appName);

/*     */ 
/* 517 */     return (obj != null);
/*     */   }




/*     */   protected ReportAdminServiceRemote getReportAdminService()
/*     */   {
/* 525 */     return this.birtAdminService;
/*     */   }

/*     */   protected UserInfo getUserInfo()
/*     */   {
/* 530 */     return this.userInfo;
/*     */   }


/*     */   protected void extractReportsZipFile(File reportsZipFile, String reportFolder)
/*     */     throws IOException
/*     */   {
/* 537 */     ZipFile zFile = new ZipFile(reportsZipFile);
/* 538 */     Enumeration zipEnum = zFile.entries();
/*     */ 
/* 540 */     String outputFolder = reportFolder;
/* 541 */     while (zipEnum.hasMoreElements())
/*     */     {
/* 543 */       ZipEntry zipEntry = (ZipEntry)zipEnum.nextElement();
/* 544 */       InputStream zipEntryInputStream = zFile.getInputStream(zipEntry);
/*     */ 
/* 546 */       String zipEntryName = zipEntry.getName();
/* 547 */       boolean isDir = zipEntry.isDirectory();
/*     */ 
/* 549 */       if (isDir)
/*     */       {
/* 551 */         File f = new File(outputFolder + File.separator + zipEntryName);
/* 552 */         f.mkdirs();
/*     */       }
/*     */       else
/*     */       {
/* 556 */         File f = new File(outputFolder + File.separator + zipEntryName);
/* 557 */         f.getParentFile().mkdirs();
/*     */ 
/* 559 */         createFileFromStream(f, zipEntryInputStream);
/*     */       }
/*     */     }
/*     */ 
/* 563 */     zFile.close();
/*     */   }

/*     */   private void createFileFromStream(File file, InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 569 */     FileOutputStream fos = new FileOutputStream(file);
/*     */ 
/* 571 */     byte[] buf = new byte[1024];
/*     */     while (true)
/*     */     {
/* 574 */       int bytesRead = inputStream.read(buf);
/* 575 */       if (bytesRead <= 0) {
/*     */         break;
/*     */       }
/*     */ 
/* 579 */       fos.write(buf, 0, bytesRead);
/*     */     }
/*     */ 
/* 582 */     fos.flush();
/* 583 */     fos.close();
/*     */   }


/*     */   private void deleteFolder(String folderName)
/*     */   {
/* 589 */     if (folderName == null)
/*     */     {
/* 591 */       return;
/*     */     }
/*     */ 
/* 594 */     File folder = new File(folderName);
/* 595 */     deleteAllFilesFromFolder(folder);
/* 596 */     folder.delete();
/*     */   }

/*     */   private void deleteAllFilesFromFolder(File folder)
/*     */   {
/* 601 */     File[] files = folder.listFiles();
/* 602 */     for (int i = 0; i < files.length; ++i)
/*     */     {
/* 604 */       File f = files[i];
/* 605 */       if (f.isDirectory())
/*     */       {
/* 607 */         deleteAllFilesFromFolder(f);
/* 608 */         f.delete();
/*     */       }
/*     */       else
/*     */       {
/* 612 */         f.delete();
/*     */       }
/*     */     }
/*     */   }
/*     */ }
