/*     */ package com.ibm.tivoli.maximo.report.birt.admin.batch;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 


















/*     */ public class LibrariesLoader
/*     */ {
/*     */   public ArrayList loadLibraries(String reportsXMLFile)
/*     */     throws Exception
/*     */   {
/*  51 */     ArrayList libraryList = new ArrayList();
/*     */ 
/*  53 */     FileInputStream fis = null;

/*     */     try
/*     */     {
/*  57 */       fis = new FileInputStream(reportsXMLFile);
/*  58 */       InputStream inputStream = fis;
/*     */ 
/*  60 */       DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
/*  61 */       DocumentBuilder db = df.newDocumentBuilder();

/*     */ 
/*  64 */       db.setErrorHandler(new ReportXMLErrorHandler());
/*  65 */       db.setEntityResolver(new ReportXMLEntityResolver());
/*  66 */       Document d = db.parse(inputStream);
/*  67 */       libraryList = processDocument(d);
/*     */ 
/*  69 */       File f = new File(reportsXMLFile);
/*  70 */       String folderName = f.getParentFile().getAbsolutePath();
/*     */ 
/*  72 */       int noOfLibraries = libraryList.size();
/*  73 */       for (int i = 0; i < noOfLibraries; ++i)
/*     */       {
/*  75 */         LibraryInfo libraryInfo = (LibraryInfo)libraryList.get(i);
/*     */ 
/*  77 */         if (libraryInfo.getReportResourcesSize() > 0)
/*     */         {
/*  79 */           byte[] resourcesZipData = createResourcesZip(folderName, libraryInfo);
/*     */ 
/*  81 */           libraryInfo.setReportResourcesZipData(resourcesZipData);
/*     */         }
/*     */ 
/*  84 */         String fileName = libraryInfo.getAttribute("filename");
/*     */ 
/*  86 */         String libraryFile = new File(reportsXMLFile).getParentFile().getAbsolutePath() + File.separator + fileName;
/*     */ 
/*  88 */         libraryInfo.setReportContent(getFileContent(libraryFile));
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/*  94 */         if (fis != null)
/*  95 */           fis.close();
/*     */       } catch (Throwable t) {
/*     */       }
/*     */     }
/*  99 */     return libraryList;
/*     */   }

/*     */   private byte[] createResourcesZip(String currentFolderName, LibraryInfo libraryInfo) throws Exception
/*     */   {
/* 104 */     byte[] data = new byte[2048];
/*     */ 
/* 106 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 107 */     ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(bos));
/*     */ 
/* 109 */     Iterator resourcesIterator = libraryInfo.getReportResources();
/* 110 */     while (resourcesIterator.hasNext())
/*     */     {
/* 112 */       ReportResourceInfo rsInfo = (ReportResourceInfo)resourcesIterator.next();
/*     */ 
/* 114 */       ZipEntry entry = new ZipEntry(rsInfo.getReference());
/* 115 */       out.putNextEntry(entry);
/*     */ 
/* 117 */       String fileName = rsInfo.getFileName();
/* 118 */       File f = new File(fileName);
/* 119 */       if (!(f.isAbsolute()))

/*     */       {
/* 122 */         fileName = currentFolderName + File.separator + fileName;
/*     */       }
/*     */ 
/* 125 */       FileInputStream fis = new FileInputStream(fileName);
/* 126 */       BufferedInputStream origin = null;

/*     */       try
/*     */       {
/* 130 */         origin = new BufferedInputStream(fis, 2048);

/*     */ 
/* 133 */         while ((count = origin.read(data, 0, 2048)) != -1)
/*     */         {/*     */           int count;
/* 135 */           out.write(data, 0, count);
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/*     */         try {
/* 141 */           if (origin != null)
/* 142 */             origin.close();
/*     */         } catch (Throwable t) {
/*     */         }
/*     */       }
/*     */     }
/* 147 */     out.flush();
/* 148 */     out.finish();
/* 149 */     out.close();
/*     */ 
/* 151 */     return bos.toByteArray();
/*     */   }

/*     */   private byte[] getFileContent(String fileName) throws IOException
/*     */   {
/* 156 */     if (fileName == null)
/*     */     {
/* 158 */       return null;
/*     */     }
/*     */ 
/* 161 */     BufferedReader bfr = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF8"));
/*     */ 
/* 163 */     StringBuffer fileContentBuf = new StringBuffer();
/*     */ 
/* 165 */     char[] charBuf = new char[1024];
/*     */     while (true)
/*     */     {
/* 168 */       int charsRead = bfr.read(charBuf);
/* 169 */       if (charsRead < 0)

/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 175 */       fileContentBuf.append(charBuf, 0, charsRead);
/*     */     }
/*     */ 
/* 178 */     String fileContent = fileContentBuf.toString();
/* 179 */     byte[] data = fileContent.getBytes("UTF-8");
/*     */ 
/* 181 */     return data;
/*     */   }




/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 191 */       LibrariesLoader reports = new LibrariesLoader();
/* 192 */       reports.loadLibraries("C:/MyProjects/MAXIMO/HARRIER/reports/birt/libraries/oracle/libraries.xml");

/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 197 */       e.printStackTrace();
/*     */     }
/*     */   }








/*     */   private ArrayList processDocument(Node node)
/*     */   {
/* 210 */     ArrayList reportList = new ArrayList();
/*     */ 
/* 212 */     NodeList list = node.getChildNodes();
/*     */ 
/* 214 */     int count = list.getLength();
/*     */ 
/* 216 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 218 */       Node n = list.item(i);
/*     */ 
/* 220 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 222 */       String element = n.getNodeName();
/* 223 */       if (!(element.equalsIgnoreCase("libraries")))
/*     */         continue;
/* 225 */       reportList = processLibrariesNode(n);


/*     */     }
/*     */ 
/* 230 */     return reportList;
/*     */   }




/*     */   private ArrayList processLibrariesNode(Node node)
/*     */   {
/* 238 */     ArrayList libraryList = new ArrayList();
/*     */ 
/* 240 */     NodeList list = node.getChildNodes();
/*     */ 
/* 242 */     int count = list.getLength();
/*     */ 
/* 244 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 246 */       Node n = list.item(i);
/*     */ 
/* 248 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 250 */       String element = n.getNodeName();
/*     */ 
/* 252 */       if (!(element.equalsIgnoreCase("library")))
/*     */         continue;
/* 254 */       NamedNodeMap amap = n.getAttributes();
/* 255 */       String reportName = amap.getNamedItem("name").getNodeValue().trim();
/*     */ 
/* 257 */       LibraryInfo libraryInfo = new LibraryInfo(reportName);
/*     */ 
/* 259 */       processLibraryNode(n, libraryInfo);
/*     */ 
/* 261 */       libraryList.add(libraryInfo);


/*     */     }
/*     */ 
/* 266 */     return libraryList;
/*     */   }




/*     */   private void processLibraryNode(Node node, LibraryInfo libraryInfo)
/*     */   {
/* 274 */     NodeList list = node.getChildNodes();
/*     */ 
/* 276 */     int count = list.getLength();
/*     */ 
/* 278 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 280 */       Node n = list.item(i);
/*     */ 
/* 282 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 284 */       String element = n.getNodeName();
/*     */ 
/* 286 */       if (element.equalsIgnoreCase("resources"))
/*     */       {
/* 288 */         processResourcesNode(n, libraryInfo);
/*     */       } else {
/* 290 */         if (!(element.equalsIgnoreCase("attribute")))
/*     */           continue;
/* 292 */         NamedNodeMap amap = n.getAttributes();
/* 293 */         String attributeName = amap.getNamedItem("name").getNodeValue().trim();
/* 294 */         String attributeValue = getTextValue(n);
/* 295 */         libraryInfo.setAttribute(attributeName, attributeValue);
/*     */       }
/*     */     }
/*     */   }


/*     */   private void processResourcesNode(Node node, LibraryInfo libraryInfo)
/*     */   {
/* 303 */     NodeList list = node.getChildNodes();
/*     */ 
/* 305 */     int count = list.getLength();
/*     */ 
/* 307 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 309 */       Node n = list.item(i);
/*     */ 
/* 311 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 313 */       String element = n.getNodeName();
/*     */ 
/* 315 */       if (!(element.equalsIgnoreCase("resource")))
/*     */         continue;
/* 317 */       ReportResourceInfo rsInfo = processResourceNode(n);
/* 318 */       libraryInfo.addReportResourceInfo(rsInfo);
/*     */     }
/*     */   }



/*     */   private ReportResourceInfo processResourceNode(Node node)
/*     */   {
/* 326 */     ReportResourceInfo rsInfo = new ReportResourceInfo();
/*     */ 
/* 328 */     NodeList list = node.getChildNodes();
/*     */ 
/* 330 */     int count = list.getLength();
/*     */ 
/* 332 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 334 */       Node n = list.item(i);
/*     */ 
/* 336 */       if (n.getNodeType() != 1)
/*     */         continue;
/* 338 */       String element = n.getNodeName();
/*     */ 
/* 340 */       if (element.equalsIgnoreCase("reference"))
/*     */       {
/* 342 */         String reference = getTextValue(n);
/* 343 */         rsInfo.setReference(reference);
/*     */       } else {
/* 345 */         if (!(element.equalsIgnoreCase("filename")))
/*     */           continue;
/* 347 */         String fileName = getTextValue(n);
/* 348 */         rsInfo.setFileName(fileName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 353 */     return rsInfo;
/*     */   }








/*     */   private String getTextValue(Node node)
/*     */   {
/* 365 */     String textValue = "";
/* 366 */     NodeList list = node.getChildNodes();
/*     */ 
/* 368 */     int count = list.getLength();
/*     */ 
/* 370 */     for (int i = 0; i < count; ++i)
/*     */     {
/* 372 */       Node n = list.item(i);
/*     */ 
/* 374 */       if (n.getNodeType() != 3)
/*     */         continue;
/* 376 */       textValue = n.getNodeValue();
/* 377 */       if (textValue != null)
/*     */         break;
/* 379 */       textValue = ""; break;




/*     */     }
/*     */ 
/* 386 */     return textValue.trim();
/*     */   }






/*     */   class ReportXMLEntityResolver
/*     */     implements EntityResolver
/*     */   {
/*     */     public InputSource resolveEntity(String publicId, String systemId)
/*     */       throws SAXException, IOException
/*     */     {
/* 400 */       if ((systemId != null) && (systemId.endsWith("reports.dtd")))
/*     */       {
/* 402 */         InputStream dtdStream = super.getClass().getResourceAsStream("/reports.dtd");
/* 403 */         return new InputSource(dtdStream);
/*     */       }
/*     */ 
/* 406 */       return null;
/*     */     }
/*     */   }






/*     */   class ReportXMLErrorHandler
/*     */     implements ErrorHandler
/*     */   {
/*     */     public void error(SAXParseException e)
/*     */       throws SAXException
/*     */     {
/* 421 */       throw e;
/*     */     }




/*     */     public void fatalError(SAXParseException e)
/*     */       throws SAXException
/*     */     {
/* 430 */       throw e;
/*     */     }
/*     */ 
/*     */     public void warning(SAXParseException exception)
/*     */       throws SAXException
/*     */     {
/*     */     }
/*     */   }
/*     */ }
