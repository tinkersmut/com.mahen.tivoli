/*    */ package com.ibm.tivoli.maximo.report.birt.design;
/*    */ 



















/*    */ public class ReportLabelInfo
/*    */ {
/*    */   private String key;
/*    */   private String value;
/*    */ 
/*    */   public ReportLabelInfo()
/*    */   {
/* 29 */     this.key = null;



/*    */ 
/* 34 */     this.value = null;
/*    */   }







/*    */   public String getKey()
/*    */   {
/* 45 */     return this.key;
/*    */   }






/*    */   public void setKey(String key)
/*    */   {
/* 55 */     this.key = key;
/*    */   }






/*    */   public String getValue()
/*    */   {
/* 65 */     return this.value;
/*    */   }






/*    */   public void setValue(String value)
/*    */   {
/* 75 */     this.value = value;
/*    */   }
/*    */ }
