/*     */ package com.ibm.tivoli.maximo.report.birt.bridge.launcher;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ 




































/*     */ public class FrameworkLauncher
/*     */ {
/*     */   private static final String SERVLET_BRIDGE_ENABLED = "org.eclipse.equinox.servlet.bridge.enabled";
/*     */   private static final String WS_DELIM = " \t\n\r\f";
/*     */   protected static final String FILE_SCHEME = "file:";
/*     */   protected static final String FRAMEWORK_BUNDLE_NAME = "org.eclipse.osgi";
/*     */   protected static final String STARTER = "org.eclipse.core.runtime.adaptor.EclipseStarter";
/*     */   protected static final String NULL_IDENTIFIER = "@null";
/*     */   protected static final String OSGI_FRAMEWORK = "osgi.framework";
/*     */   protected static final String OSGI_INSTANCE_AREA = "osgi.instance.area";
/*     */   protected static final String OSGI_CONFIGURATION_AREA = "osgi.configuration.area";
/*     */   protected static final String OSGI_INSTALL_AREA = "osgi.install.area";
/*     */   protected static final String RESOURCE_BASE = "/WEB-INF/birt/platform/";
/*     */   protected static final String LAUNCH_INI = "launch.ini";
/*     */   protected ServletConfig config;
/*     */   protected ServletContext context;
/*     */   private File platformDirectory;
/*     */   private ClassLoader frameworkContextClassLoader;
/*     */   private URLClassLoader frameworkClassLoader;
/*  85 */   private ReportLogger reportLogger = null;
/*     */ 
/*     */   public FrameworkLauncher()
/*     */   {
/*  89 */     this.reportLogger = ReportLoggerFactory.getLogger("maximo.report.birt");
/*     */   }

/*     */   public void init(ServletConfig servletConfig)
/*     */   {
/*  94 */     this.config = servletConfig;
/*  95 */     this.context = servletConfig.getServletContext();
/*  96 */     init();
/*     */   }














/*     */   public synchronized void deploy()
/*     */   {
/* 114 */     if (this.platformDirectory != null)
/*     */     {
/* 116 */       return;
/*     */     }
/*     */ 
/* 119 */     File servletTemp = null;
/*     */ 
/* 121 */     if (System.getProperty("mxe.report.birt.tempfolder") != null)
/*     */     {
/* 123 */       servletTemp = new File(System.getProperty("mxe.report.birt.tempfolder"));
/*     */     }
/*     */     else
/*     */     {
/* 127 */       servletTemp = (File)this.context.getAttribute("javax.servlet.context.tempdir");
/*     */ 
/* 129 */       String filePath = servletTemp.getAbsolutePath();
/* 130 */       int index = filePath.indexOf(" ");
/* 131 */       if (index > -1)
/*     */       {
/* 133 */         filePath = filePath.replaceAll(" ", "_");
/* 134 */         servletTemp = new File(filePath);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 139 */     this.platformDirectory = new File(servletTemp, "birtplatform");
/* 140 */     this.platformDirectory.mkdirs();
/*     */ 
/* 142 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 144 */       this.reportLogger.debug(new StringBuilder().append("MXWebAppOSGiFrameworkLauncher (platform) = ").append(this.platformDirectory).toString());
/*     */     }
/*     */ 
/* 147 */     copyResource("/WEB-INF/birt/platform/launch-system/", new File(this.platformDirectory, "launch-system"));
/* 148 */     copyResource("/WEB-INF/birt/platform/configuration-system/", new File(this.platformDirectory, "configuration-system"));
/* 149 */     copyResource("/WEB-INF/birt/platform/workspace-system/", new File(this.platformDirectory, "workspace-system"));
/*     */ 
/* 151 */     copyResource("/WEB-INF/birt/platform/launch-webapp/", new File(this.platformDirectory, "launch-webapp"));
/* 152 */     copyResource("/WEB-INF/birt/platform/configuration-webapp/", new File(this.platformDirectory, "configuration-webapp"));
/* 153 */     copyResource("/WEB-INF/birt/platform/workspace-webapp/", new File(this.platformDirectory, "workspace-webapp"));
/* 154 */     copyResource("/WEB-INF/birt/platform/features/", new File(this.platformDirectory, "features"));
/* 155 */     copyResource("/WEB-INF/birt/platform/plugins/", new File(this.platformDirectory, "plugins"));
/* 156 */     copyResource("/WEB-INF/birt/platform/.eclipseproduct", new File(this.platformDirectory, ".eclipseproduct"));
/*     */   }




/*     */   public synchronized void undeploy()
/*     */   {
/* 164 */     if (this.platformDirectory == null)
/*     */     {
/* 166 */       return;
/*     */     }
/*     */ 
/* 169 */     if (this.frameworkClassLoader != null) {
/* 170 */       throw new IllegalStateException("Could not undeploy Framework - (not stopped)");
/*     */     }
/*     */ 
/* 173 */     deleteDirectory(new File(this.platformDirectory, "launch-webapp"));
/* 174 */     deleteDirectory(new File(this.platformDirectory, "configuration-webapp"));
/* 175 */     deleteDirectory(new File(this.platformDirectory, "features"));
/* 176 */     deleteDirectory(new File(this.platformDirectory, "plugins"));
/* 177 */     deleteDirectory(new File(this.platformDirectory, "workspace-webapp"));
/*     */ 
/* 179 */     new File(this.platformDirectory, ".eclipseproduct").delete();
/* 180 */     this.platformDirectory = null;
/*     */   }







/*     */   public synchronized void start()
/*     */   {
/* 191 */     if (this.platformDirectory == null)
/*     */     {
/* 193 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 195 */         this.reportLogger.error("MXWebAppOSGiFrameworkLauncher - Could not start the Framework - (it is not deployed)");
/*     */       }
/*     */ 
/* 198 */       throw new IllegalStateException("Could not start the Framework - (not deployed)");
/*     */     }
/*     */ 
/* 201 */     if (this.frameworkClassLoader != null)
/*     */     {
/* 203 */       return;
/*     */     }
/*     */ 
/* 206 */     Map initalPropertyMap = buildInitialPropertyMap();
/* 207 */     String[] args = buildCommandLineArguments();
/* 208 */     String oldValue = null;
/* 209 */     boolean setProperty = false;
/*     */ 
/* 211 */     ClassLoader original = Thread.currentThread().getContextClassLoader();
/*     */     try
/*     */     {
/* 214 */       oldValue = System.getProperty("osgi.framework.useSystemProperties");
/*     */ 
/* 216 */       System.setProperty("osgi.framework.useSystemProperties", "false");
/* 217 */       setProperty = true;
/*     */ 
/* 219 */       URL[] osgiURLArray = { new URL((String)initalPropertyMap.get("osgi.framework")) };
/* 220 */       this.frameworkClassLoader = new ChildFirstURLClassLoader(osgiURLArray, super.getClass().getClassLoader());
/*     */ 
/* 222 */       Properties fPro = getFrameworkInternalProperties(this.frameworkClassLoader);
/* 223 */       Properties sysPro = System.getProperties();
/* 224 */       if (sysPro != fPro)
/*     */       {
/* 226 */         if (this.reportLogger.isDebugEnabled())
/*     */         {
/* 228 */           this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (starting) using Custom properties");

/*     */         }
/*     */ 
/* 232 */         Vector osgiProperties = new Vector();
/* 233 */         Enumeration keyEnum = fPro.keys();
/* 234 */         while (keyEnum.hasMoreElements()) {
/* 235 */           String key = (String)keyEnum.nextElement();
/* 236 */           if (key.indexOf("osgi.") >= 0)
/*     */           {
/* 238 */             if (key.equalsIgnoreCase("osgi.framework.useSystemProperties")) {
/*     */               continue;
/*     */             }
/*     */ 
/* 242 */             osgiProperties.add(key);
/* 243 */             if (this.reportLogger.isDebugEnabled())
/*     */             {
/* 245 */               this.reportLogger.debug(new StringBuilder().append("MXWebAppOSGiFrameworkLauncher (starting) removing system property from our list: ").append(key).toString());
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 250 */         int pSize = osgiProperties.size();
/* 251 */         for (int i = 0; i < pSize; ++i) {
/* 252 */           fPro.remove(osgiProperties.elementAt(i));
/*     */         }
/*     */ 
/* 255 */         if (this.reportLogger.isDebugEnabled())
/*     */         {
/* 257 */           this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (starting) removing eclipse.security property from our list");
/*     */         }
/*     */ 
/* 260 */         fPro.remove("eclipse.security");


/*     */       }
/* 264 */       else if (this.reportLogger.isDebugEnabled())
/*     */       {
/* 266 */         this.reportLogger.debug("MXWebAppOSGiFrameworkLauncher (starting) using System properties");

/*     */       }
/*     */ 
/* 270 */       Class clazz = this.frameworkClassLoader.loadClass("org.eclipse.core.runtime.adaptor.EclipseStarter");
/*     */ 
/* 272 */       Method setInitialProperties = clazz.getMethod("setInitialProperties", new Class[] { Map.class });
/* 273 */       setInitialProperties.invoke(null, new Object[] { initalPropertyMap });
/*     */ 
/* 275 */       Method runMethod = clazz.getMethod("run", new Class[] { [Ljava.lang.String.class, Runnable.class });
/* 276 */       runMethod.invoke(null, new Object[] { args, null });
/* 277 */       this.frameworkContextClassLoader = Thread.currentThread().getContextClassLoader();






/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 290 */       Thread.currentThread().setContextClassLoader(original);
/*     */ 
/* 292 */       if (setProperty)
/*     */       {
/* 294 */         if (oldValue == null)
/*     */         {
/* 296 */           System.clearProperty("osgi.framework.useSystemProperties");
/*     */         }
/*     */         else
/*     */         {
/* 300 */           System.setProperty("osgi.framework.useSystemProperties", "true");
/*     */         }
/*     */       }
/*     */     }
/*     */   }

/*     */   public Properties getFrameworkInternalProperties(ClassLoader cl)
/*     */   {
/*     */     try
/*     */     {
/* 310 */       Class clazz = cl.loadClass("org.eclipse.osgi.framework.internal.core.FrameworkProperties");
/*     */ 
/* 312 */       Method runMethod = clazz.getMethod("getProperties", new Class[0]);
/* 313 */       Properties p = (Properties)runMethod.invoke(null, new Object[0]);
/* 314 */       return p;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 318 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 320 */         this.reportLogger.error("Failed to get properties from org.eclipse.osgi.framework.internal.core.FrameworkProperties", e);
/*     */       }
/*     */     }
/* 323 */     return null;
/*     */   }







/*     */   protected Map buildInitialPropertyMap()
/*     */   {
/* 334 */     Map initialPropertyMap = new HashMap();
/*     */ 
/* 336 */     String launchIniFile = new StringBuilder().append(this.platformDirectory).append(File.separator).append("launch-webapp").append(File.separator).append("launch.ini").toString();
/* 337 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 339 */       this.reportLogger.debug(new StringBuilder().append("MXSystemOSGiFrameworkLauncher (starting) launching from: ").append(launchIniFile).toString());
/*     */     }
/*     */ 
/* 342 */     Properties launchProperties = loadProperties(launchIniFile);
/* 343 */     for (Iterator it = launchProperties.entrySet().iterator(); it.hasNext(); )
/*     */     {
/* 345 */       Map.Entry entry = (Map.Entry)it.next();
/* 346 */       if (entry.getValue().equals("@null"))
/*     */       {
/* 348 */         initialPropertyMap.remove(entry.getKey());
/*     */       }
/*     */       else
/*     */       {
/* 352 */         initialPropertyMap.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 359 */       if (!(initialPropertyMap.containsKey("osgi.install.area")))
/*     */       {
/* 361 */         initialPropertyMap.put("osgi.install.area", this.platformDirectory.toURL().toExternalForm());

/*     */       }
/*     */ 
/* 365 */       if (!(initialPropertyMap.containsKey("osgi.configuration.area")))
/*     */       {
/* 367 */         File configurationDirectory = new File(this.platformDirectory, "configuration-webapp");
/* 368 */         if (!(configurationDirectory.exists()))
/*     */         {
/* 370 */           configurationDirectory.mkdirs();
/*     */         }
/*     */ 
/* 373 */         initialPropertyMap.put("osgi.configuration.area", configurationDirectory.toURL().toExternalForm());

/*     */       }
/*     */ 
/* 377 */       if (!(initialPropertyMap.containsKey("osgi.instance.area")))
/*     */       {
/* 379 */         File workspaceDirectory = new File(this.platformDirectory, "workspace-webapp");
/* 380 */         if (!(workspaceDirectory.exists()))
/*     */         {
/* 382 */           workspaceDirectory.mkdirs();
/*     */         }
/*     */ 
/* 385 */         initialPropertyMap.put("osgi.instance.area", workspaceDirectory.toURL().toExternalForm());

/*     */       }
/*     */ 
/* 389 */       if (!(initialPropertyMap.containsKey("osgi.framework")))

/*     */       {
/* 392 */         String installArea = (String)initialPropertyMap.get("osgi.install.area");

/*     */ 
/* 395 */         if (installArea.startsWith("file:")) {
/* 396 */           installArea = installArea.substring("file:".length());
/*     */         }
/* 398 */         String path = new File(installArea, "plugins").toString();
/* 399 */         path = searchFor("org.eclipse.osgi", path);
/* 400 */         if (path == null)
/*     */         {
/* 402 */           throw new RuntimeException("Could not find framework");
/*     */         }
/*     */ 
/* 405 */         initialPropertyMap.put("osgi.framework", new File(path).toURL().toExternalForm());


/*     */       }
/*     */ 
/* 410 */       if (!(initialPropertyMap.containsKey("org.eclipse.equinox.servlet.bridge.enabled")))
/*     */       {
/* 412 */         initialPropertyMap.put("org.eclipse.equinox.servlet.bridge.enabled", Boolean.TRUE.toString());
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/* 418 */       throw new RuntimeException("Error establishing location");
/*     */     }
/*     */ 
/* 421 */     return initialPropertyMap;
/*     */   }





/*     */   protected String[] buildCommandLineArguments()
/*     */   {
/* 430 */     List args = new ArrayList();
/* 431 */     args.add("-nosplash");
/* 432 */     String commandLine = this.config.getInitParameter("commandline");
/*     */ 
/* 434 */     if (commandLine != null)
/*     */     {
/* 436 */       StringTokenizer tokenizer = new StringTokenizer(commandLine, " \t\n\r\f");
/* 437 */       while (tokenizer.hasMoreTokens())
/*     */       {
/* 439 */         String arg = tokenizer.nextToken();
/* 440 */         if (arg.startsWith("\""))
/*     */         {
/* 442 */           String remainingArg = tokenizer.nextToken("\"");
/* 443 */           arg = new StringBuilder().append(arg.substring(1)).append(remainingArg).toString();
/*     */ 
/* 445 */           tokenizer.nextToken(" \t\n\r\f");
/*     */         }
/* 447 */         else if (arg.startsWith("'"))
/*     */         {
/* 449 */           String remainingArg = tokenizer.nextToken("'");
/* 450 */           arg = new StringBuilder().append(arg.substring(1)).append(remainingArg).toString();
/*     */ 
/* 452 */           tokenizer.nextToken(" \t\n\r\f");
/*     */         }
/*     */ 
/* 455 */         args.add(arg);
/*     */       }
/*     */     }
/*     */ 
/* 459 */     return ((String[])(String[])args.toArray(new String[0]));
/*     */   }






/*     */   public synchronized void stop()
/*     */   {
/* 469 */     if (this.platformDirectory == null)
/*     */     {
/* 471 */       return;
/*     */     }
/*     */ 
/* 474 */     if (this.frameworkClassLoader == null)
/*     */     {
/* 476 */       return;
/*     */     }
/*     */ 
/* 479 */     ClassLoader original = Thread.currentThread().getContextClassLoader();
/*     */     try
/*     */     {
/* 482 */       Class clazz = this.frameworkClassLoader.loadClass("org.eclipse.core.runtime.adaptor.EclipseStarter");
/* 483 */       Method method = clazz.getDeclaredMethod("shutdown", (Class[])null);
/* 484 */       Thread.currentThread().setContextClassLoader(this.frameworkContextClassLoader);
/* 485 */       method.invoke(clazz, (Object[])null);



/*     */       try
/*     */       {
/* 491 */         clazz = super.getClass().getClassLoader().loadClass("org.apache.commons.logging.LogFactory");
/* 492 */         method = clazz.getDeclaredMethod("release", new Class[] { ClassLoader.class });
/* 493 */         method.invoke(clazz, new Object[] { this.frameworkContextClassLoader });
/*     */       }
/*     */       catch (ClassNotFoundException e)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 502 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 504 */         this.reportLogger.error("Failed to stop OSGi framework.", e);


/*     */     }
/*     */     finally
/*     */     {
/*     */       }/* 510 */       this.frameworkClassLoader = null;
/*     */ /* 511 */       this.frameworkContextClassLoader = null;
/* 512 */       return;/* 512 */       Thread.currentThread().setContextClassLoader(original);
/*     */     }
/*     */   }







/*     */   protected void copyResource(String resourcePath, File target)
/*     */   {
/*     */     Iterator it;
/* 525 */     if (resourcePath.endsWith("/"))
/*     */     {
/* 527 */       target.mkdir();
/* 528 */       Set paths = this.context.getResourcePaths(resourcePath);
/* 529 */       if (paths == null)
/*     */       {
/* 531 */         return;
/*     */       }
/*     */ 
/* 534 */       for (it = paths.iterator(); it.hasNext(); )
/*     */       {
/* 536 */         String path = (String)it.next();
/* 537 */         File newFile = new File(target, path.substring(resourcePath.length()));
/* 538 */         copyResource(path, newFile);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 545 */         if (target.createNewFile())
/*     */         {
/* 547 */           InputStream is = null;
/* 548 */           OutputStream os = null;
/*     */           try
/*     */           {
/* 551 */             is = this.context.getResourceAsStream(resourcePath);
/* 552 */             if (is == null)
/*     */               return;
/* 554 */             os = new FileOutputStream(target);
/* 555 */             byte[] buffer = new byte[8192];
/* 556 */             int bytesRead = is.read(buffer);
/* 557 */             while (bytesRead != -1)
/*     */             {
/* 559 */               os.write(buffer, 0, bytesRead);
/* 560 */               bytesRead = is.read(buffer);
/*     */             }
/*     */           }
/*     */           finally
/*     */           {
/* 565 */             if (is != null) {
/* 566 */               is.close();
/*     */             }
/* 568 */             if (os != null)
/* 569 */               os.close();
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 575 */         if (!(this.reportLogger.isErrorEnabled()))
/*     */           return;
/* 577 */         this.reportLogger.error(new StringBuilder().append("Failed to copy resources from ").append(resourcePath).append(" to ").append(target.getAbsolutePath()).toString(), e);
/*     */       }
/*     */     }
/*     */   }







/*     */   protected static boolean deleteDirectory(File directory)
/*     */   {
/* 590 */     if ((directory.exists()) && (directory.isDirectory()))
/*     */     {
/* 592 */       File[] files = directory.listFiles();
/* 593 */       for (int i = 0; i < files.length; ++i)
/*     */       {
/* 595 */         if (files[i].isDirectory())
/*     */         {
/* 597 */           deleteDirectory(files[i]);
/*     */         }
/*     */         else
/*     */         {
/* 601 */           files[i].delete();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 606 */     return directory.delete();
/*     */   }






/*     */   public synchronized ClassLoader getFrameworkContextClassLoader()
/*     */   {
/* 616 */     return this.frameworkContextClassLoader;
/*     */   }





/*     */   protected synchronized File getPlatformDirectory()
/*     */   {
/* 625 */     return this.platformDirectory;
/*     */   }






/*     */   protected Properties loadProperties(String resource)
/*     */   {
/* 635 */     Properties result = new Properties();
/* 636 */     InputStream in = null;
/*     */     try {
/* 638 */       URL location = new File(resource).toURL();
/* 639 */       if (location != null)
/*     */       {
/* 641 */         in = location.openStream();
/* 642 */         result.load(in);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 654 */       if (in != null) {
/*     */         try {
/* 656 */           in.close();
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/* 663 */     return result;
/*     */   }










/*     */   protected String searchFor(String target, String start)
/*     */   {
/* 677 */     FileFilter filter = new FileFilter(target)
/*     */     {
/*     */       public boolean accept(File candidate)
/*     */       {
/* 681 */         return ((candidate.getName().equals(this.val$target)) || (candidate.getName().startsWith(this.val$target + "_")));

/*     */       }
/*     */     };
/* 685 */     File[] candidates = new File(start).listFiles(filter);
/* 686 */     if (candidates == null)
/*     */     {
/* 688 */       return null;
/*     */     }
/*     */ 
/* 691 */     String[] arrays = new String[candidates.length];
/* 692 */     for (int i = 0; i < arrays.length; ++i)
/*     */     {
/* 694 */       arrays[i] = candidates[i].getName();
/*     */     }
/*     */ 
/* 697 */     int result = findMax(arrays);
/* 698 */     if (result == -1)
/*     */     {
/* 700 */       return null;
/*     */     }
/*     */ 
/* 703 */     return new StringBuilder().append(candidates[result].getAbsolutePath().replace(File.separatorChar, '/')).append((candidates[result].isDirectory()) ? "/" : "").toString();
/*     */   }

/*     */   protected int findMax(String[] candidates)
/*     */   {
/* 708 */     int result = -1;
/* 709 */     Object maxVersion = null;
/* 710 */     for (int i = 0; i < candidates.length; ++i)
/*     */     {
/* 712 */       String name = candidates[i];
/* 713 */       String version = "";

/*     */ 
/* 716 */       int index = name.indexOf(95);
/* 717 */       if (index != -1)
/*     */       {
/* 719 */         version = name.substring(index + 1);
/*     */       }
/*     */ 
/* 722 */       Object currentVersion = getVersionElements(version);
/* 723 */       if (maxVersion == null)
/*     */       {
/* 725 */         result = i;
/* 726 */         maxVersion = currentVersion;
/*     */       }
/*     */       else
/*     */       {
/* 730 */         if (compareVersion((Object[])(Object[])maxVersion, (Object[])(Object[])currentVersion) >= 0)
/*     */           continue;
/* 732 */         result = i;
/* 733 */         maxVersion = currentVersion;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 738 */     return result;
/*     */   }











/*     */   private int compareVersion(Object[] left, Object[] right)
/*     */   {
/* 753 */     int result = ((Integer)left[0]).compareTo((Integer)right[0]);
/* 754 */     if (result != 0) {
/* 755 */       return result;
/*     */     }
/* 757 */     result = ((Integer)left[1]).compareTo((Integer)right[1]);
/* 758 */     if (result != 0) {
/* 759 */       return result;
/*     */     }
/* 761 */     result = ((Integer)left[2]).compareTo((Integer)right[2]);
/* 762 */     if (result != 0) {
/* 763 */       return result;
/*     */     }
/* 765 */     return ((String)left[3]).compareTo((String)right[3]);
/*     */   }










/*     */   private Object[] getVersionElements(String version)
/*     */   {
/* 779 */     if (version.endsWith(".jar"))
/*     */     {
/* 781 */       version = version.substring(0, version.length() - 4);
/*     */     }
/*     */ 
/* 784 */     Object[] result = { new Integer(0), new Integer(0), new Integer(0), "" };
/* 785 */     StringTokenizer t = new StringTokenizer(version, ".");
/*     */ 
/* 787 */     int i = 0;
/* 788 */     while ((t.hasMoreTokens()) && (i < 4))
/*     */     {
/* 790 */       String token = t.nextToken();
/* 791 */       if (i < 3);


/*     */       try
/*     */       {
/* 796 */         result[(i++)] = new Integer(token);

/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 801 */         break label139:




/*     */ 
/* 807 */         result[(i++)] = token;
/*     */       }
/*     */     }
/*     */ 
/* 811 */     label139: return result;
/*     */   }






/*     */   protected class ChildFirstURLClassLoader extends URLClassLoader
/*     */   {
/*     */     public ChildFirstURLClassLoader(URL[] paramArrayOfURL)
/*     */     {
/* 823 */       super(paramArrayOfURL);
/*     */     }

/*     */     public ChildFirstURLClassLoader(URL[] paramArrayOfURL, ClassLoader paramClassLoader)
/*     */     {
/* 828 */       super(paramArrayOfURL, parent);
/*     */     }

/*     */     public ChildFirstURLClassLoader(URL[] paramArrayOfURL, ClassLoader paramClassLoader, URLStreamHandlerFactory paramURLStreamHandlerFactory)
/*     */     {
/* 833 */       super(paramArrayOfURL, paramClassLoader, paramURLStreamHandlerFactory);
/*     */     }

/*     */     public URL getResource(String name)
/*     */     {
/* 838 */       URL resource = findResource(name);
/* 839 */       if (resource == null)
/*     */       {
/* 841 */         ClassLoader parent = getParent();
/* 842 */         if (parent != null) {
/* 843 */           resource = parent.getResource(name);
/*     */         }
/*     */       }
/* 846 */       return resource;
/*     */     }

/*     */     protected synchronized Class loadClass(String name, boolean resolve) throws ClassNotFoundException
/*     */     {
/* 851 */       Class clazz = findLoadedClass(name);
/* 852 */       if (clazz == null)
/*     */       {
/*     */         try
/*     */         {
/* 856 */           clazz = findClass(name);
/*     */         }
/*     */         catch (ClassNotFoundException e)
/*     */         {
/* 860 */           ClassLoader parent = getParent();
/* 861 */           if (parent != null)
/*     */           {
/* 863 */             clazz = parent.loadClass(name);
/*     */           }
/*     */           else
/*     */           {
/* 867 */             clazz = getSystemClassLoader().loadClass(name);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 872 */       if (resolve)
/*     */       {
/* 874 */         resolveClass(clazz);
/*     */       }
/*     */ 
/* 877 */       return clazz;
/*     */     }
/*     */   }
/*     */ }
