/*     */ package com.ibm.tivoli.maximo.report.birt.admin;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 





































/*     */ public class ReportImportInfo
/*     */   implements Serializable
/*     */ {
/*     */   private String name;
/*     */   private String fileName;
/*     */   private String appName;
/*     */   private byte[] xmlReportData;
/*     */   private byte[] resources;
/*     */   private boolean library;
/*     */   private HashMap<String, String> attributeMap;
/*     */   private boolean importResourcesEnabled;
/*     */   private HashMap<String, ReportImportParamInfo> parameterMap;
/*     */ 
/*     */   public ReportImportInfo()
/*     */   {
/*  60 */     this.library = false;



/*     */ 
/*  65 */     this.attributeMap = new HashMap();



/*     */ 
/*  70 */     this.importResourcesEnabled = true;



/*     */ 
/*  75 */     this.parameterMap = new HashMap();
/*     */   }






/*     */   public String getAppName()
/*     */   {
/*  85 */     return this.appName;
/*     */   }






/*     */   public void setAppName(String appName)
/*     */   {
/*  95 */     this.appName = appName;
/*     */   }






/*     */   public String getFileName()
/*     */   {
/* 105 */     return this.fileName;
/*     */   }






/*     */   public void setFileName(String fileName)
/*     */   {
/* 115 */     this.fileName = fileName;
/*     */   }






/*     */   public String getName()
/*     */   {
/* 125 */     return this.name;
/*     */   }






/*     */   public void setName(String name)
/*     */   {
/* 135 */     this.name = name;
/*     */   }






/*     */   public byte[] getResources()
/*     */   {
/* 145 */     return this.resources;
/*     */   }






/*     */   public void setResources(byte[] resources)
/*     */   {
/* 155 */     this.resources = resources;
/*     */   }






/*     */   public byte[] getXmlReportData()
/*     */   {
/* 165 */     return this.xmlReportData;
/*     */   }






/*     */   public void setXmlReportData(byte[] xmlReportData)
/*     */   {
/* 175 */     this.xmlReportData = xmlReportData;
/*     */   }






/*     */   public boolean isLibrary()
/*     */   {
/* 185 */     return this.library;
/*     */   }






/*     */   public void setLibrary(boolean library)
/*     */   {
/* 195 */     this.library = library;
/*     */   }







/*     */   public void setAttribute(String attributeName, String attributeValue)
/*     */   {
/* 206 */     this.attributeMap.put(attributeName.toLowerCase(), attributeValue);
/*     */   }







/*     */   public String getAttribute(String attributeName)
/*     */   {
/* 217 */     return ((String)this.attributeMap.get(attributeName.toLowerCase()));
/*     */   }






/*     */   public void removeAttribute(String attributeName)
/*     */   {
/* 227 */     this.attributeMap.remove(attributeName.toLowerCase());
/*     */   }






/*     */   public Iterator getAttributes()
/*     */   {
/* 237 */     return this.attributeMap.keySet().iterator();
/*     */   }






/*     */   public boolean isImportResourcesEnabled()
/*     */   {
/* 247 */     return this.importResourcesEnabled;
/*     */   }






/*     */   public void setImportResourcesEnabled(boolean importResourcesEnabled)
/*     */   {
/* 257 */     this.importResourcesEnabled = importResourcesEnabled;
/*     */   }







/*     */   public void setParameter(String parameterName, ReportImportParamInfo paramInfo)
/*     */   {
/* 268 */     this.parameterMap.put(parameterName, paramInfo);
/*     */   }







/*     */   public ReportImportParamInfo getParameter(String parameterName)
/*     */   {
/* 279 */     return ((ReportImportParamInfo)this.parameterMap.get(parameterName));
/*     */   }






/*     */   public void removeParameter(String parameterName)
/*     */   {
/* 289 */     this.parameterMap.remove(parameterName);
/*     */   }






/*     */   public Iterator getParameters()
/*     */   {
/* 299 */     return this.parameterMap.keySet().iterator();
/*     */   }
/*     */ }
