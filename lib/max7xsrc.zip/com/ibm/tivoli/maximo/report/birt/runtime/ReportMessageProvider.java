package com.ibm.tivoli.maximo.report.birt.runtime;

public abstract interface ReportMessageProvider
{
  public abstract String getMessage(String paramString);
}
