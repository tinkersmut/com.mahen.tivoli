/*    */ package com.ibm.tivoli.maximo.report.birt.admin;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import psdi.server.MaximoThread;
/*    */ 

























/*    */ public class ReportTempFolderCleanupManager extends MaximoThread
/*    */ {
/*    */   HashMap<String, String> tobeDeletedFolders;
/*    */   private ReportAdminService reportAdminService;
/*    */ 
/*    */   public ReportTempFolderCleanupManager(ReportAdminService reportAdminServiceParam)
/*    */   {
/* 40 */     super("ReportTempDirCleanupManager");
/* 41 */     this.reportAdminService = reportAdminServiceParam;
/* 42 */     this.tobeDeletedFolders = new HashMap();
/*    */   }





/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/*    */       try
/*    */       {
/* 55 */         Thread.sleep(300000L);

/*    */       }
/*    */       catch (InterruptedException e)
/*    */       {
/* 60 */         if (isMarkedForShutDown())
/*    */         {
/* 62 */           return;
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 67 */       if (isMarkedForShutDown())
/*    */       {
/* 69 */         return;
/*    */       }
/*    */ 
/* 72 */       Iterator iter = this.tobeDeletedFolders.keySet().iterator();
/*    */ 
/* 74 */       while (iter.hasNext())

/*    */       {
/* 77 */         String folderName = (String)iter.next();
/* 78 */         boolean deleted = this.reportAdminService.deleteFolder(folderName);
/* 79 */         if (deleted)
/*    */         {
/* 81 */           this.tobeDeletedFolders.remove(folderName);
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Throwable t)
/*    */     {
/* 87 */       t.printStackTrace();
/*    */     }
/*    */   }
/*    */ }
