/*     */ package com.ibm.tivoli.maximo.report.birt.custom.admin;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminService;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportUsageLogInfo;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetEnumeration;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ 

























/*     */ public class CustomReportAdminService extends ReportAdminService
/*     */   implements CustomReportAdminServiceRemote
/*     */ {
/*     */   private static final String REPORT_MBONAME = "REPORT";
/*     */   private static final String REPORT_REPORTNAME = "REPORTNAME";
/*     */   private static final String REPORT_APPNAME = "APPNAME";
/*     */   private static final String REPORTLOOKUP_RELATIONSHIPNAME = "REPORT_LOOKUP";
/*     */   private static final String REPORTLOOKUP_PARAMETERNAME = "PARAMETERNAME";
/*     */   private static final String REPORTLOOKUP_LOOKUPNAME = "LOOKUPNAME";
/*     */   private static final String DATELOOKUP = "datelookup";
/*     */ 
/*     */   public CustomReportAdminService(MXServer mxServer)
/*     */     throws RemoteException
/*     */   {
/*  53 */     super(mxServer);
/*     */   }











/*     */   public ArrayList<String> getReportDateParams(UserInfo userInfo, String reportName, String appName)
/*     */     throws MXException, RemoteException
/*     */   {
/*  69 */     ArrayList dateParams = new ArrayList();


/*     */ 
/*  73 */     String userLang = userInfo.getLangCode();
/*  74 */     userInfo.setLangCode(MXServer.getMXServer().getBaseLang());
/*     */ 
/*  76 */     MboSetRemote reportMboSet = getMboSet("REPORT", userInfo);
/*  77 */     reportMboSet.setQbeExactMatch(true);
/*  78 */     reportMboSet.setQbe("REPORTNAME", reportName);
/*  79 */     reportMboSet.setQbe("APPNAME", appName);
/*  80 */     reportMboSet.reset();
/*  81 */     MboRemote reportMbo = reportMboSet.getMbo(0);
/*     */ 
/*  83 */     if (reportMbo != null)
/*     */     {
/*  85 */       MboSetRemote reportParamsSetRemote = reportMbo.getMboSet("REPORT_LOOKUP");
/*  86 */       MboSetEnumeration mse = new MboSetEnumeration(reportParamsSetRemote);
/*  87 */       while (mse.hasMoreElements())
/*     */       {
/*  89 */         MboRemote reportLookup = mse.nextMbo();
/*     */ 
/*  91 */         String lookupName = reportLookup.getString("LOOKUPNAME");
/*  92 */         if (lookupName.equalsIgnoreCase("datelookup"))
/*     */         {
/*  94 */           dateParams.add(reportLookup.getString("PARAMETERNAME"));
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 100 */     userInfo.setLangCode(userLang);
/*     */ 
/* 102 */     return dateParams;
/*     */   }
















/*     */   public void createReportUsageLog(UserInfo userInfo, ReportUsageLogInfo usageLogInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 123 */     String userLang = userInfo.getLangCode();
/* 124 */     userInfo.setLangCode(MXServer.getMXServer().getBaseLang());
/*     */ 
/* 126 */     super.createReportUsageLog(userInfo, usageLogInfo);

/*     */ 
/* 129 */     userInfo.setLangCode(userLang);
/*     */   }
/*     */ }
