/*     */ package com.ibm.tivoli.maximo.report.birt.engine;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ActiveReportThreadManager;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportRunInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceProvider;
/*     */ import com.ibm.tivoli.maximo.report.birt.design.ReportParameterInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerProvider;
/*     */ import com.ibm.tivoli.maximo.report.birt.queue.ScheduledActiveReportThreadNotifier;
/*     */ import com.ibm.tivoli.maximo.report.birt.queue.ScheduledReportDataRestrictionProvider;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportExecutionException;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportExecutionInputInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportExecutionParameterData;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportExecutionTask;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportExecutionTaskProvider;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportMessageResources;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportParameterData;
/*     */ import com.ibm.tivoli.maximo.report.birt.util.logging.ReportLoggerProviderImpl;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXFormat;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 





















/*     */ public class MXReportEngine
/*     */ {
/*     */   private static final String REPORT_SCRIPTLOGGER = "com.ibm.tivoli.maximo.report.birt.logger.script";
/*     */   private static final String REPORT_SCRIPTSQLLOGGER = "com.ibm.tivoli.maximo.report.birt.logger.script.sql";
/*     */   private static final String REPORT_DISPLAY_YES = "com.ibm.tivoli.maximo.report.birt.display.yes";
/*     */   private static final String REPORT_DISPLAY_NO = "com.ibm.tivoli.maximo.report.birt.display.no";
/*     */   private static final String REPORT_USER_DATE = "com.ibm.tivoli.maximo.report.birt.userdate";
/*     */   private static final String REPORT_DATASOURCEPROVIDER = "REPORTDATASOURCEPROVIDER";
/*     */   private static final String REPORT_MODE = "com.ibm.tivoli.maximo.report.birt.mode";
/*     */   private static final String REPORT_MODE_SCHEDULE = "SCHEDULE";
/*     */   private static final String REPORT_MODE_IMMEDIATE = "IMMEDIATE";
/*     */   private static final String REPORT_LANGCODE = "com.ibm.tivoli.maximo.report.birt.langcode";
/*     */   private static final String REPORT_LOCALE = "com.ibm.tivoli.maximo.report.birt.locale";
/*     */   private static final String REPORT_TIMEZONE = "com.ibm.tivoli.maximo.report.birt.timezone";
/*     */   private static final String REPORT_ACTIVEREPORTTHREADNOTIFIER = "ACTIVEREPORTTHREADNOTIFIER";
/*     */   public static final String REPORT_USAGELOGNOTIFIER = "USAGELOGNOTIFIER";
/*     */   public static final String REPORT_DATARESTRICTIONPROVIDER = "DATARESTRICTIONPROVIDER";
/*  71 */   private static MXReportEngine reportEngine = new MXReportEngine();
/*     */ 
/*  73 */   private boolean engineInitialized = false;
/*  74 */   private MXSystemOSGiFrameworkLauncher framework = null;
/*     */ 
/*     */   public static MXReportEngine getReportEngine()
/*     */   {
/*  78 */     if (!(reportEngine.isInitialized()))
/*     */     {
/*  80 */       reportEngine.init();
/*     */     }
/*     */ 
/*  83 */     return reportEngine;
/*     */   }





/*     */   private void init()
/*     */   {
/*  92 */     ReportLoggerProvider reportLoggerProvider = new ReportLoggerProviderImpl();
/*  93 */     ReportLoggerFactory.setReportLoggerProvider(reportLoggerProvider);
/*     */ 
/*  95 */     this.framework = new MXSystemOSGiFrameworkLauncher();
/*  96 */     this.framework.init();
/*  97 */     this.framework.deploy();
/*  98 */     this.framework.start();
/*     */ 
/* 100 */     this.engineInitialized = true;
/*     */   }

/*     */   public void stop()
/*     */   {
/* 105 */     if (!(this.engineInitialized))
/*     */       return;
/* 107 */     this.framework.stop();
/* 108 */     this.engineInitialized = false;
/* 109 */     this.framework = null;
/*     */   }


/*     */   public boolean isInitialized()
/*     */   {
/* 115 */     return this.engineInitialized;
/*     */   }





/*     */   public void executeReportInImmediateMode(ReportRunInfo reportRunInfo, ReportParameterData parameterData, String outputFileName, String outputFormat, UserInfo userInfo, Map<String, Object> additionalInfoMap)
/*     */     throws ReportExecutionException
/*     */   {
/* 125 */     executeReport(reportRunInfo, parameterData, outputFileName, outputFormat, userInfo, additionalInfoMap, false);
/*     */   }





/*     */   public void executeReport(ReportRunInfo reportRunInfo, ReportParameterData parameterData, String outputFileName, String outputFormat, UserInfo userInfo, Map<String, Object> additionalInfoMap)
/*     */     throws ReportExecutionException
/*     */   {
/* 135 */     executeReport(reportRunInfo, parameterData, outputFileName, outputFormat, userInfo, additionalInfoMap, true);
/*     */   }






/*     */   public void executeReport(ReportRunInfo reportRunInfo, ReportParameterData parameterData, String outputFileName, String outputFormat, UserInfo userInfo, Map<String, Object> additionalInfoMap, boolean scheduleMode)
/*     */     throws ReportExecutionException
/*     */   {
/* 146 */     if (!(isInitialized()))
/*     */     {
/* 148 */       return;
/*     */     }
/*     */ 
/* 151 */     ClassLoader fwkContextClassLoader = this.framework.getFrameworkContextClassLoader();
/*     */ 
/* 153 */     ClassLoader original = Thread.currentThread().getContextClassLoader();

/*     */     try
/*     */     {
/* 157 */       Thread.currentThread().setContextClassLoader(fwkContextClassLoader);
/* 158 */       ReportExecutionTask task = ReportExecutionTaskProvider.getReportExecutionTask();
/* 159 */       if (task != null)
/*     */       {
/* 161 */         String tempRunFolder = reportRunInfo.getTempRunFolder();
/*     */ 
/* 163 */         String tempFolder = reportRunInfo.getReportFolderName();
/* 164 */         String reportFileName = tempRunFolder + File.separator + tempFolder + File.separator + reportRunInfo.getReportName();

/*     */ 
/* 167 */         ReportExecutionInputInfo reportInputInfo = new ReportExecutionInputInfo();
/* 168 */         reportInputInfo.setOutputFolderName(tempRunFolder + File.separator + reportRunInfo.getReportOutputFolderName());
/*     */ 
/* 170 */         Locale l = new Locale(userInfo.getLangCode(), userInfo.getLocale().getCountry(), userInfo.getLocale().getVariant());
/* 171 */         reportInputInfo.setLocale(l);

/*     */ 
/* 174 */         reportInputInfo.setOutputFileName(outputFileName);
/* 175 */         reportInputInfo.setOutputFormat(outputFormat);
/* 176 */         reportInputInfo.setReportFileName(reportFileName);
/* 177 */         reportInputInfo.setJdbcConnectionProvider(new ReportJdbcConnectionProviderImpl(userInfo, MXServer.getMXServer().getDBManager()));
/*     */ 
/* 179 */         Map mxReportContext = new HashMap();
/* 180 */         mxReportContext.put("com.ibm.tivoli.maximo.report.birt.langcode", userInfo.getLangCode());
/* 181 */         mxReportContext.put("com.ibm.tivoli.maximo.report.birt.locale", userInfo.getLocale());
/* 182 */         mxReportContext.put("com.ibm.tivoli.maximo.report.birt.timezone", userInfo.getTimeZone());
/*     */ 
/* 184 */         MXLogger reportScriptLogger = MXLoggerFactory.getLogger("maximo.report.birt.script");
/* 185 */         MXLogger reportScriptSqlLogger = MXLoggerFactory.getLogger("maximo.report.birt.sql.script");
/*     */ 
/* 187 */         mxReportContext.put("com.ibm.tivoli.maximo.report.birt.logger.script", reportScriptLogger);
/* 188 */         mxReportContext.put("com.ibm.tivoli.maximo.report.birt.logger.script.sql", reportScriptSqlLogger);
/*     */ 
/* 190 */         mxReportContext.put("REPORTDATASOURCEPROVIDER", DataSourceProvider.getDataSourceProvider());
/* 191 */         if (scheduleMode)
/*     */         {
/* 193 */           mxReportContext.put("com.ibm.tivoli.maximo.report.birt.mode", "SCHEDULE");
/*     */         }
/*     */         else
/*     */         {
/* 197 */           mxReportContext.put("com.ibm.tivoli.maximo.report.birt.mode", "IMMEDIATE");
/*     */         }
/* 199 */         mxReportContext.put("com.ibm.tivoli.maximo.report.birt.display.yes", MXFormat.getDisplayYesValue(userInfo.getLocale()));
/* 200 */         mxReportContext.put("com.ibm.tivoli.maximo.report.birt.display.no", MXFormat.getDisplayNoValue(userInfo.getLocale()));
/*     */ 
/* 202 */         String userDate = MXFormat.dateTimeToString(MXServer.getMXServer().getDate(), userInfo.getLocale(), userInfo.getTimeZone());
/*     */ 
/* 204 */         mxReportContext.put("com.ibm.tivoli.maximo.report.birt.userdate", userDate);

/*     */ 
/* 207 */         ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();
/* 208 */         long reportJobId = atmgr.getReportJobId(Thread.currentThread().getName());
/* 209 */         reportInputInfo.setReportJobId(reportJobId);
/*     */ 
/* 211 */         mxReportContext.put("REPORTJOBID", new Long(reportJobId));

/*     */ 
/* 214 */         ScheduledActiveReportThreadNotifier sart = new ScheduledActiveReportThreadNotifier();
/* 215 */         sart.setThreadName(Thread.currentThread().getName());
/* 216 */         sart.setAppName(reportRunInfo.getAppName());
/* 217 */         sart.setReportName(reportRunInfo.getReportName());
/* 218 */         sart.setUserName(userInfo.getUserName());
/* 219 */         mxReportContext.put("ACTIVEREPORTTHREADNOTIFIER", sart);

/*     */ 
/* 222 */         ScheduledReportDataRestrictionProvider dp = new ScheduledReportDataRestrictionProvider();
/* 223 */         dp.setUserInfo(userInfo);
/*     */ 
/* 225 */         MboSetRemote maxAppSet = MXServer.getMXServer().getMboSet("MAXAPPS", userInfo);
/* 226 */         maxAppSet.setQbeExactMatch(true);
/* 227 */         maxAppSet.setQbe("APP", reportRunInfo.getAppName());
/* 228 */         MboRemote maxApp = maxAppSet.getMbo(0);
/* 229 */         if (maxApp != null)
/*     */         {
/* 231 */           dp.setObjectName(maxApp.getString("MAINTBNAME"));
/*     */         }
/*     */ 
/* 234 */         dp.setAppName(reportRunInfo.getAppName());
/* 235 */         mxReportContext.put("DATARESTRICTIONPROVIDER", dp);

/*     */ 
/* 238 */         if (additionalInfoMap != null)

/*     */         {
/* 241 */           Iterator keyIterator = additionalInfoMap.keySet().iterator();
/* 242 */           while (keyIterator.hasNext())
/*     */           {
/* 244 */             String keyName = (String)keyIterator.next();
/* 245 */             mxReportContext.put(keyName, additionalInfoMap.get(keyName));
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 250 */         reportInputInfo.setMxReportContext(mxReportContext);
/*     */ 
/* 252 */         ReportParameterInfo[] paramInfo = reportRunInfo.getReportParameterInfo();
/*     */ 
/* 254 */         HashMap paramInfoMap = new HashMap();
/* 255 */         for (int i = 0; i < paramInfo.length; ++i)
/*     */         {
/* 257 */           paramInfoMap.put(paramInfo[i].getName(), paramInfo[i]);
/*     */         }
/*     */ 
/* 260 */         ReportExecutionParameterData execParamData = new ReportExecutionParameterData();
/* 261 */         Iterator paramsIterator = parameterData.getParameters();
/* 262 */         while (paramsIterator.hasNext())
/*     */         {
/* 264 */           String paramName = (String)paramsIterator.next();
/* 265 */           String parameterValue = parameterData.getParameter(paramName);

/*     */ 
/* 268 */           Object execParamValue = parameterValue;
/*     */ 
/* 270 */           ReportParameterInfo pInfo = (ReportParameterInfo)paramInfoMap.get(paramName);
/* 271 */           if (pInfo == null)
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/* 276 */           if ((parameterValue != null) && (!(parameterValue.trim().equals(""))))
/*     */           {
/* 278 */             String paramDataType = pInfo.getDataType();
/*     */ 
/* 280 */             if (paramDataType.equalsIgnoreCase("date"))
/*     */             {
/* 282 */               java.util.Date dateValue = MXFormat.stringToDate(parameterValue);
/* 283 */               execParamValue = new java.sql.Date(dateValue.getTime());
/*     */             }
/* 285 */             else if (paramDataType.equalsIgnoreCase("dateTime"))
/*     */             {
/* 287 */               execParamValue = MXFormat.stringToDateTime(parameterValue, userInfo.getLocale(), userInfo.getTimeZone());
/*     */             }
/* 289 */             else if (paramDataType.equalsIgnoreCase("integer"))
/*     */             {
/* 291 */               execParamValue = new Integer(MXFormat.stringToInt(parameterValue, userInfo.getLocale()));
/*     */             }
/* 293 */             else if (paramDataType.equalsIgnoreCase("decimal"))
/*     */             {
/* 295 */               execParamValue = new Double(MXFormat.stringToDouble(parameterValue, userInfo.getLocale()));
/*     */             }
/* 297 */             else if (paramDataType.equalsIgnoreCase("float"))
/*     */             {
/* 299 */               execParamValue = new Float(MXFormat.stringToDouble(parameterValue, userInfo.getLocale()));

/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 306 */             String paramDataType = pInfo.getDataType();
/*     */ 
/* 308 */             if (!(paramDataType.equalsIgnoreCase("dateTime")))
/*     */             {
/* 310 */               execParamValue = "";
/*     */             }
/*     */           }
/*     */ 
/* 314 */           execParamData.addParameter(paramName, execParamValue);
/*     */         }
/*     */ 
/* 317 */         if (execParamData.getParameter("appname") == null)
/*     */         {
/* 319 */           execParamData.addParameter("appname", reportRunInfo.getAppName());


/*     */         }
/*     */ 
/* 324 */         reportInputInfo.setReportExecutionParameterData(execParamData);
/*     */ 
/* 326 */         ReportMessageProviderImpl rmp = new ReportMessageProviderImpl(userInfo.getLangCode(), MXServer.getMXServer());
/* 327 */         ReportMessageResources.setMessageProvider(rmp);
/*     */ 
/* 329 */         task.executeReport(reportInputInfo);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 338 */       Thread.currentThread().setContextClassLoader(original);
/*     */     }
/*     */   }
/*     */ }
