/*    */ package com.ibm.tivoli.maximo.report.birt.util.logging;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*    */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerProvider;
/*    */ 















/*    */ public class ReportLoggerProviderImpl
/*    */   implements ReportLoggerProvider
/*    */ {
/*    */   public ReportLogger getLogger(String name)
/*    */   {
/* 26 */     return new ReportLoggerImpl(name);
/*    */   }
/*    */ }
