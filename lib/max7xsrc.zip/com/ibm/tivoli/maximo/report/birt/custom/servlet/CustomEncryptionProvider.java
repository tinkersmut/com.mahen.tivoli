/*    */ package com.ibm.tivoli.maximo.report.birt.custom.servlet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.admin.EncryptionProvider;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.util.CipherPlusBase64;
/*    */ import psdi.util.MXException;
/*    */ 

















/*    */ public class CustomEncryptionProvider
/*    */   implements EncryptionProvider
/*    */ {
/*    */   public String encrypt(String value)
/*    */     throws MXException, RemoteException
/*    */   {
/*    */     try
/*    */     {
/* 33 */       if (!(value.equals("")))
/*    */       {
/* 35 */         value = CipherPlusBase64.encrypt(value, true);
/*    */       }
/*    */     } catch (Throwable t) {
/* 38 */       t.printStackTrace();
/*    */     }
/* 40 */     return value;
/*    */   }
/*    */ }
