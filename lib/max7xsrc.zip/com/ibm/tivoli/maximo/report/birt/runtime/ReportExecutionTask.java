package com.ibm.tivoli.maximo.report.birt.runtime;

public abstract interface ReportExecutionTask
{
  public abstract void executeReport(ReportExecutionInputInfo paramReportExecutionInputInfo)
    throws ReportExecutionException;

  public abstract void cancelReportJob(long paramLong)
    throws ReportExecutionException;

  public abstract void removeReportJob(long paramLong)
    throws ReportExecutionException;
}
