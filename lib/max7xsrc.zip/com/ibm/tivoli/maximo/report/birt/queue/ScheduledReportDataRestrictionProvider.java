/*    */ package com.ibm.tivoli.maximo.report.birt.queue;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.admin.DataRestrictionProvider;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.SqlFormat;
/*    */ import psdi.security.UserInfo;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXException;
/*    */ 












/*    */ public class ScheduledReportDataRestrictionProvider
/*    */   implements DataRestrictionProvider
/*    */ {
/*    */   private UserInfo userInfo;
/*    */   private String objectName;
/*    */   private String appName;
/*    */ 
/*    */   public ScheduledReportDataRestrictionProvider()
/*    */   {
/* 32 */     this.userInfo = null;
/* 33 */     this.objectName = null;
/* 34 */     this.appName = null;
/*    */   }

/*    */   public void setUserInfo(UserInfo userInfo) {
/* 38 */     this.userInfo = userInfo;
/*    */   }

/*    */   public void setObjectName(String objectName)
/*    */   {
/* 43 */     this.objectName = objectName;
/*    */   }

/*    */   public void setAppName(String appName)
/*    */   {
/* 48 */     this.appName = appName;
/*    */   }

/*    */   public String getDataRestrictionWhere()
/*    */     throws MXException, RemoteException
/*    */   {
/* 54 */     MboSetRemote ms = MXServer.getMXServer().getMboSet(this.objectName, this.userInfo);
/* 55 */     ms.setApp(this.appName);
/*    */ 
/* 57 */     String whereClause = ms.getCompleteWhere();
/*    */ 
/* 59 */     whereClause = new SqlFormat(this.userInfo, whereClause).format();
/* 60 */     return whereClause;
/*    */   }
/*    */ }
