package com.ibm.tivoli.maximo.report.birt.admin;

import com.ibm.tivoli.maximo.report.birt.design.CreateReportInputInfo;
import com.ibm.tivoli.maximo.report.birt.runtime.ReportParameterData;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import psdi.security.UserInfo;
import psdi.server.AppServiceRemote;
import psdi.util.MXException;

public abstract interface ReportAdminServiceRemote extends AppServiceRemote
{
  public static final String OUTPUT_FORMAT_PDF = "pdf";
  public static final String OUTPUT_FORMAT_XLS = "xls";
  public static final String OUTPUT_FORMAT_HTML = "html";

  public abstract void importReport(UserInfo paramUserInfo, ReportImportInfo paramReportImportInfo, boolean paramBoolean)
    throws MXException, RemoteException;

  public abstract byte[] exportReport(UserInfo paramUserInfo, String paramString1, String paramString2)
    throws MXException, RemoteException;

  public abstract byte[] exportReportLibrary(UserInfo paramUserInfo, String paramString)
    throws MXException, RemoteException;

  public abstract String getExportReportFolder(UserInfo paramUserInfo, String paramString1, String paramString2)
    throws MXException, RemoteException;

  public abstract String exportReportImportInputInfo(UserInfo paramUserInfo, String paramString1, String paramString2)
    throws MXException, RemoteException;

  public abstract String exportLibraryImportInputInfo(UserInfo paramUserInfo, String paramString)
    throws MXException, RemoteException;

  public abstract void importReportLibrary(UserInfo paramUserInfo, ReportImportInfo paramReportImportInfo)
    throws MXException, RemoteException;

  public abstract ArrayList<String> getReportLibraryNameList(UserInfo paramUserInfo)
    throws MXException, RemoteException;

  public abstract TreeMap<String, List> getReportNameList(UserInfo paramUserInfo)
    throws MXException, RemoteException;

  public abstract TreeMap<String, List> getReportNameList(UserInfo paramUserInfo, int paramInt)
    throws MXException, RemoteException;

  public abstract ReportRunInfo prepareReportForRun(UserInfo paramUserInfo, String paramString1, String paramString2)
    throws MXException, RemoteException;

  public abstract void cleanupReportResources(ReportRunInfo paramReportRunInfo)
    throws MXException, RemoteException;

  public abstract byte[] runReport(UserInfo paramUserInfo, String paramString1, String paramString2, ReportParameterData paramReportParameterData, String paramString3, String paramString4)
    throws MXException, RemoteException;

  public abstract byte[] runReport(UserInfo paramUserInfo, String paramString1, String paramString2, ReportParameterData paramReportParameterData, String paramString3, String paramString4, Map<String, Object> paramMap)
    throws MXException, RemoteException;

  public abstract boolean isOverloaded()
    throws MXException, RemoteException;

  public abstract int getReportEngineState()
    throws MXException, RemoteException;

  public abstract Long addActiveThread(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
    throws MXException, RemoteException;

  public abstract void removeActiveThread(String paramString)
    throws MXException, RemoteException;

  public abstract void renewActiveThread(String paramString)
    throws MXException, RemoteException;

  public abstract void createReportUsageLog(UserInfo paramUserInfo, ReportUsageLogInfo paramReportUsageLogInfo)
    throws MXException, RemoteException;

  public abstract void createReportDesign(UserInfo paramUserInfo, CreateReportInputInfo paramCreateReportInputInfo)
    throws MXException, RemoteException;

  public abstract boolean isAuthorizedToRunReport(UserInfo paramUserInfo, String paramString1, String paramString2)
    throws MXException, RemoteException;

  public abstract String getReportViewerURL()
    throws MXException, RemoteException;

  public abstract void cancelReportJob(long paramLong)
    throws MXException, RemoteException;

  public abstract void cancelReportJobOnThisServer(long paramLong)
    throws MXException, RemoteException;

  public abstract boolean isReportJobCancelled(long paramLong)
    throws MXException, RemoteException;

  public abstract byte[] updateReportDesign(UserInfo paramUserInfo, String paramString1, String paramString2, boolean paramBoolean)
    throws MXException, RemoteException;
}
