package com.ibm.tivoli.maximo.report.birt.custom.admin;

import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminServiceRemote;
import com.ibm.tivoli.maximo.report.birt.admin.ReportUsageLogInfo;
import java.rmi.RemoteException;
import java.util.ArrayList;
import psdi.security.UserInfo;
import psdi.util.MXException;

public abstract interface CustomReportAdminServiceRemote extends ReportAdminServiceRemote
{
  public abstract ArrayList<String> getReportDateParams(UserInfo paramUserInfo, String paramString1, String paramString2)
    throws MXException, RemoteException;

  public abstract void createReportUsageLog(UserInfo paramUserInfo, ReportUsageLogInfo paramReportUsageLogInfo)
    throws MXException, RemoteException;
}
