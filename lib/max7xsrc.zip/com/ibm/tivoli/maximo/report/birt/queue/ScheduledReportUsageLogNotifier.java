/*     */ package com.ibm.tivoli.maximo.report.birt.queue;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminService;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportUsageLogInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportUsageLogNotifier;
/*     */ import java.util.Date;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 

















/*     */ public class ScheduledReportUsageLogNotifier
/*     */   implements ReportUsageLogNotifier
/*     */ {
/*  31 */   private UserInfo userInfo = null;
/*  32 */   private ReportUsageLogInfo usageLogInfo = new ReportUsageLogInfo();
/*  33 */   private MXLogger reportLogger = null;
/*     */ 
/*     */   public ScheduledReportUsageLogNotifier()
/*     */   {
/*  37 */     this.usageLogInfo.setImmediateJob(false);
/*     */   }

/*     */   public void setUserInfo(UserInfo userInfo)
/*     */   {
/*  42 */     this.userInfo = userInfo;
/*     */   }

/*     */   public void setReportLogger(MXLogger reportLogger)
/*     */   {
/*  47 */     this.reportLogger = reportLogger;
/*     */   }

/*     */   public void setAppName(String appName)
/*     */   {
/*  52 */     this.usageLogInfo.setAppName(appName);
/*     */   }

/*     */   public void setReportName(String reportName)
/*     */   {
/*  57 */     this.usageLogInfo.setReportName(reportName);
/*     */   }

/*     */   public void setEnterDate(Date enterDate)
/*     */   {
/*  62 */     this.usageLogInfo.setEnterDate(enterDate);
/*     */   }

/*     */   public void setStartDate(Date startDate)
/*     */   {
/*  67 */     this.usageLogInfo.setStartDate(startDate);
/*     */   }

/*     */   public void setEndDate(Date endDate)
/*     */   {
/*  72 */     this.usageLogInfo.setEndDate(endDate);
/*     */   }

/*     */   public void setRuntime(long runtime)
/*     */   {
/*  77 */     this.usageLogInfo.setRuntime(runtime);
/*     */   }

/*     */   public void setSuccess(boolean success)
/*     */   {
/*  82 */     this.usageLogInfo.setSuccess(success);
/*     */   }

/*     */   public void setReportFailed()
/*     */   {
/*  87 */     this.usageLogInfo.setSuccess(false);
/*     */   }

/*     */   public boolean isSuccess()
/*     */   {
/*  92 */     return this.usageLogInfo.isSuccess();
/*     */   }

/*     */   public void setUserId(String userId)
/*     */   {
/*  97 */     this.usageLogInfo.setUserId(userId);
/*     */   }

/*     */   public void setHostName(String hostName)
/*     */   {
/* 102 */     this.usageLogInfo.setHostName(hostName);
/*     */   }

/*     */   public void setServerName(String serverName)
/*     */   {
/* 107 */     this.usageLogInfo.setServerName(serverName);
/*     */   }

/*     */   public void setReportExecuted()
/*     */   {
/* 112 */     this.usageLogInfo.setReportExecuted(true);
/*     */   }

/*     */   public void setEmailFileType(String emailFileType)
/*     */   {
/* 117 */     this.usageLogInfo.setEmailFileType(emailFileType);
/*     */   }



/*     */   public void createUsageLog()
/*     */   {
/*     */     try
/*     */     {
/* 126 */       ReportAdminService birtAdminService = (ReportAdminService)MXServer.getMXServer().lookup("BIRTREPORT");
/* 127 */       this.usageLogInfo.setEndDate(MXServer.getMXServer().getDate());
/*     */ 
/* 129 */       long startTime = this.usageLogInfo.getStartDate().getTime();
/* 130 */       long endTime = this.usageLogInfo.getEndDate().getTime();
/*     */ 
/* 132 */       long runtime = endTime - startTime;
/* 133 */       this.usageLogInfo.setRuntime(runtime);
/*     */ 
/* 135 */       birtAdminService.createReportUsageLog(this.userInfo, this.usageLogInfo);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 139 */       if ((this.reportLogger == null) || 

/* 141 */         (!(this.reportLogger.isErrorEnabled())))
/*     */         return;
/* 143 */       this.reportLogger.error("Failed to write report usage log", t);
/*     */     }
/*     */   }



/*     */   public void setReportCancelled()
/*     */   {
/* 151 */     this.usageLogInfo.setCancelled(true);
/* 152 */     this.usageLogInfo.setSuccess(false);
/*     */   }
/*     */ }
