/*    */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.admin.DataRestrictionProvider;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.SqlFormat;
/*    */ import psdi.security.UserInfo;
/*    */ import psdi.server.MXServerRemote;
/*    */ import psdi.util.MXException;
/*    */ 











/*    */ public class ImmediateReportDataRestrictionProvider
/*    */   implements DataRestrictionProvider
/*    */ {
/*    */   private UserInfo userInfo;
/*    */   private MXServerRemote mxServerRemote;
/*    */   private String objectName;
/*    */   private String appName;
/*    */ 
/*    */   public ImmediateReportDataRestrictionProvider()
/*    */   {
/* 32 */     this.userInfo = null;
/* 33 */     this.mxServerRemote = null;
/* 34 */     this.objectName = null;
/* 35 */     this.appName = null;
/*    */   }

/*    */   public void setMXServerRemote(MXServerRemote mxServerRemote) {
/* 39 */     this.mxServerRemote = mxServerRemote;
/*    */   }

/*    */   public void setUserInfo(UserInfo userInfo)
/*    */   {
/* 44 */     this.userInfo = userInfo;
/*    */   }

/*    */   public void setObjectName(String objectName)
/*    */   {
/* 49 */     this.objectName = objectName;
/*    */   }

/*    */   public void setAppName(String appName)
/*    */   {
/* 54 */     this.appName = appName;
/*    */   }

/*    */   public String getDataRestrictionWhere()
/*    */     throws MXException, RemoteException
/*    */   {
/* 60 */     MboSetRemote ms = this.mxServerRemote.getMboSet(this.objectName, this.userInfo);
/* 61 */     ms.setApp(this.appName);
/*    */ 
/* 63 */     String whereClause = ms.getCompleteWhere();
/*    */ 
/* 65 */     whereClause = new SqlFormat(this.userInfo, whereClause).format();
/* 66 */     return whereClause;
/*    */   }
/*    */ }
