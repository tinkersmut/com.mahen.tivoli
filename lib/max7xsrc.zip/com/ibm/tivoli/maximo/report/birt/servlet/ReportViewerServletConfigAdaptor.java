/*    */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*    */ 
/*    */ import java.util.Dictionary;
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.Servlet;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ 
















/*    */ public class ReportViewerServletConfigAdaptor
/*    */   implements ServletConfig
/*    */ {
/*    */   private Servlet servlet;
/*    */   private Dictionary initparams;
/*    */   private ServletContext servletContext;
/*    */ 
/*    */   public ReportViewerServletConfigAdaptor(Servlet servlet, Dictionary initparams, ServletContext servletContext)
/*    */   {
/* 34 */     this.servlet = servlet;
/* 35 */     this.initparams = initparams;
/* 36 */     this.servletContext = new ReportViewerServletContextAdaptor(servletContext, initparams);
/*    */   }

/*    */   public String getServletName()
/*    */   {
/* 41 */     return this.servlet.getClass().getName();
/*    */   }

/*    */   public ServletContext getServletContext()
/*    */   {
/* 46 */     return this.servletContext;
/*    */   }

/*    */   public String getInitParameter(String name)
/*    */   {
/* 51 */     return ((String)this.initparams.get(name));
/*    */   }

/*    */   public Enumeration getInitParameterNames()
/*    */   {
/* 56 */     return this.initparams.elements();
/*    */   }
/*    */ }
