/*    */ package com.ibm.tivoli.maximo.report.birt;
/*    */ 
















/*    */ public class ReportException extends Exception
/*    */ {
/*    */   public ReportException(String message)
/*    */   {
/* 23 */     super(message);
/*    */   }

/*    */   public ReportException(String message, Throwable cause)
/*    */   {
/* 28 */     super(message, cause);
/*    */   }
/*    */ }
