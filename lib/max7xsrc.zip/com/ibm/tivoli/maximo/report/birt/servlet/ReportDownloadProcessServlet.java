/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminService;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportRunInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.util.MXSession;
/*     */ 









/*     */ public class ReportDownloadProcessServlet extends HttpServlet
/*     */ {
/*     */   private ServletContext servletContext;
/*     */   private ReportLogger reportLogger;
/*     */   private String bridgeServletMapping;
/*     */   private static final String MXREPORTCONTEXT = "MXREPORTCONTEXT";
/*     */ 
/*     */   public ReportDownloadProcessServlet()
/*     */   {
/*  42 */     this.servletContext = null;
/*  43 */     this.reportLogger = null;
/*     */ 
/*  45 */     this.bridgeServletMapping = null;
/*     */   }

/*     */   public void init(ServletConfig config)
/*     */     throws ServletException
/*     */   {
/*  51 */     this.reportLogger = ReportLoggerFactory.getLogger("maximo.report.birt");
/*     */ 
/*  53 */     ReportViewerServletConfigAdaptor configAdapter = new ReportViewerServletConfigAdaptor(this, null, config.getServletContext());
/*     */ 
/*  55 */     super.init(configAdapter);
/*     */ 
/*  57 */     this.servletContext = configAdapter.getServletContext();
/*     */ 
/*  59 */     this.bridgeServletMapping = config.getInitParameter("bridgeservletmap");
/*  60 */     if (this.bridgeServletMapping == null)
/*     */     {
/*  62 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/*  64 */         this.reportLogger.error("ReportDownloadProcessServlet init-param bridgeservletmap not defined.");
/*     */       }
/*  66 */       throw new ServletException("ReportDownloadProcessServlet init-param bridgeservletmap not defined.");
/*     */     }
/*     */ 
/*  69 */     if (!(this.reportLogger.isDebugEnabled()))
/*     */       return;
/*  71 */     this.reportLogger.debug("ReportDownloadProcessServlet using bridgeservletmap = " + this.bridgeServletMapping);
/*     */   }


/*     */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  78 */     processReportRequest(request, response);
/*     */   }

/*     */   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*     */   {
/*  83 */     processReportRequest(request, response);
/*     */   }


/*     */   protected void processReportRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  90 */     Object objSession = request.getSession().getAttribute("MXSession");
/*  91 */     Object objSessionReport = request.getSession().getAttribute("MXSessionReport");
/*  92 */     if ((((objSessionReport == null) || (!(((MXSession)objSessionReport).isConnected())))) && (((objSession == null) || (!(((MXSession)objSession).isConnected())))))


/*     */     {
/*  96 */       response.getWriter().write("Invalid request. The request must only come from maximo session.");
/*  97 */       response.sendError(401);
/*  98 */       return;
/*     */     }
/*     */ 
/* 101 */     MXSession session = (MXSession)objSession;
/* 102 */     if (session == null)
/*     */     {
/* 104 */       session = (MXSession)objSessionReport;

/*     */     }
/*     */ 
/* 108 */     if (!(session.isConnected()))
/*     */     {
/* 110 */       response.getWriter().write("Invalid request. The request must only come from maximo session.");
/* 111 */       response.sendError(401);
/* 112 */       return;
/*     */     }
/*     */ 
/* 115 */     String reportDesign = request.getParameter("__report");






/*     */ 
/* 123 */     int slashIndex = reportDesign.lastIndexOf("/");
/* 124 */     if (slashIndex >= 0)
/*     */     {
/* 126 */       reportDesign = reportDesign.substring(slashIndex + 1);
/*     */     }
/*     */     else
/*     */     {
/* 130 */       slashIndex = reportDesign.lastIndexOf("\\");
/* 131 */       if (slashIndex >= 0)
/*     */       {
/* 133 */         reportDesign = reportDesign.substring(slashIndex + 1);
/*     */       }
/*     */     }
/*     */ 
/* 137 */     String appName = request.getParameter("appname");
/*     */ 
/* 139 */     String requestId1 = request.getParameter("__requestid");
/* 140 */     String reportRunInfoKey = reportDesign + "_" + appName + "_" + requestId1;

/*     */ 
/* 143 */     if (!(isAuthorizedToRunReport(session, reportDesign, appName)))
/*     */     {
/* 145 */       response.getWriter().write("Unauthorized to run the report.");
/* 146 */       response.getWriter().flush();
/* 147 */       return;
/*     */     }
/* 149 */     Object a = request.getSession().getAttribute(reportRunInfoKey);
/* 150 */     SessionReportRunInfo sessionReportRunInfo = (SessionReportRunInfo)a;
/* 151 */     if (sessionReportRunInfo == null)
/*     */     {
/* 153 */       response.getWriter().write("Invalid request. Report cannot be downloaded, as it is not executed.");
/* 154 */       response.getWriter().flush();
/* 155 */       return;
/*     */     }
/*     */ 
/* 158 */     ReportRunInfo reportRunInfo = sessionReportRunInfo.getReportRunInfo();
/*     */ 
/* 160 */     String reportOutputFolder = reportRunInfo.getReportOutputFolderName();

/*     */ 
/* 163 */     HashMap additionalParams = new HashMap();
/* 164 */     additionalParams.put("__report", new String[] { reportRunInfo.getReportRelativePath() + File.separator + reportDesign });
/*     */ 
/* 166 */     String reportName = reportDesign.substring(0, reportDesign.lastIndexOf("."));
/* 167 */     String reportDocument = reportName + ".rptdocument";
/*     */ 
/* 169 */     String docFileName = reportRunInfo.getTempRunFolder() + File.separator + reportOutputFolder + File.separator + reportDocument;
/* 170 */     additionalParams.put("__document", new String[] { docFileName });
/*     */ 
/* 172 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 174 */       this.reportLogger.debug("ReportDownloadProcessServlet using document: " + docFileName);
/*     */     }
/*     */ 
/* 177 */     String reportContextKey = "context_" + reportDesign + "_" + appName;
/*     */ 
/* 179 */     Object reportContext = request.getSession().getAttribute(reportContextKey);
/* 180 */     if (reportContext != null)
/*     */     {
/* 182 */       request.setAttribute("MXREPORTCONTEXT", reportContext);
/*     */     }
/*     */ 
/* 185 */     StringBuffer buf = new StringBuffer();
/*     */ 
/* 187 */     String requestId = request.getParameter("__requestid");
/* 188 */     buf.append("\n");
/* 189 */     buf.append("\n");
/* 190 */     buf.append("Report parameters in ReportDownloadProcessServlet for RequestID = " + requestId);
/* 191 */     buf.append("\n");
/*     */ 
/* 193 */     String reportRunRequestKey = "reportRequestId" + reportDesign + "_" + appName + "_" + requestId1;
/* 194 */     HashMap reportParams = (HashMap)request.getSession().getAttribute(reportRunRequestKey);
/* 195 */     if (reportParams != null)
/*     */     {
/* 197 */       Iterator repParamIterator = reportParams.keySet().iterator();
/* 198 */       while (repParamIterator.hasNext())
/*     */       {
/* 200 */         String repParamKey = (String)repParamIterator.next();

/*     */ 
/* 203 */         if ((repParamKey.equals("__asattachment")) || (repParamKey.equals("__overwrite")) || (repParamKey.equals("__format"))) continue; if (repParamKey.equals("usepagebreaks"))

/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 209 */         Object repParamValue = reportParams.get(repParamKey);


/*     */ 
/* 213 */         if (repParamValue instanceof String[])
/*     */         {
/* 215 */           additionalParams.put(repParamKey, repParamValue);
/* 216 */           for (int i = 0; i < ((String[])(String[])repParamValue).length; ++i)
/*     */           {
/* 218 */             buf.append(repParamKey + " = " + ((String[])(String[])repParamValue)[i]);
/* 219 */             buf.append("\n");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 224 */           additionalParams.put(repParamKey, new String[] { repParamValue.toString() });
/* 225 */           buf.append(repParamKey + " = " + repParamValue);
/* 226 */           buf.append("\n");

/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 235 */       buf.append("   (NONE)");
/* 236 */       buf.append("\n");
/*     */     }
/* 238 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 240 */       this.reportLogger.debug(buf.toString());
/*     */     }
/*     */ 
/* 243 */     ReportRequestWrapper rw = new ReportRequestWrapper(request, additionalParams);
/* 244 */     this.servletContext.getRequestDispatcher(this.bridgeServletMapping + "output").forward(rw, response);
/*     */   }

/*     */   protected boolean isAuthorizedToRunReport(MXSession session, String reportName, String appName)
/*     */     throws ServletException
/*     */   {
/*     */     try
/*     */     {
/* 252 */       UserInfo userInfo = session.getUserInfo();
/* 253 */       ReportAdminService reportService = (ReportAdminService)session.lookup("BIRTREPORT");
/*     */ 
/* 255 */       boolean authorized = reportService.isAuthorizedToRunReport(userInfo, reportName, appName);
/* 256 */       return authorized;

/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*     */     }
/*     */ 
/* 263 */     return false;
/*     */   }
/*     */ }
