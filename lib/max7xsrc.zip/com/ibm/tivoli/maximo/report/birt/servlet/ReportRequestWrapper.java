/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ 
















/*     */ public class ReportRequestWrapper extends HttpServletRequestWrapper
/*     */ {
/*  30 */   private HashMap additionalParams = null;
/*  31 */   private HashMap additionalAttributes = new HashMap();
/*     */ 
/*     */   public ReportRequestWrapper(HttpServletRequest request, HashMap additionalParams) {
/*  34 */     super(request);
/*     */ 
/*  36 */     this.additionalParams = additionalParams;
/*     */   }

/*     */   public String getParameter(String name)
/*     */   {
/*  41 */     if (this.additionalParams.get(name) == null)
/*     */     {
/*  43 */       return super.getParameter(name);
/*     */     }
/*  45 */     String[] params = (String[])(String[])this.additionalParams.get(name);
/*  46 */     return params[0];
/*     */   }

/*     */   public Map getParameterMap()
/*     */   {
/*  51 */     Map superMap = super.getParameterMap();
/*     */ 
/*  53 */     HashMap myMap = new HashMap();
/*  54 */     Iterator superKeyIterator = superMap.keySet().iterator();
/*  55 */     while (superKeyIterator.hasNext())
/*     */     {
/*  57 */       String superKeyName = (String)superKeyIterator.next();
/*  58 */       myMap.put(superKeyName, superMap.get(superKeyName));
/*     */     }
/*     */ 
/*  61 */     Iterator keyIterator = this.additionalParams.keySet().iterator();
/*  62 */     while (keyIterator.hasNext())
/*     */     {
/*  64 */       String keyName = (String)keyIterator.next();
/*     */ 
/*  66 */       myMap.put(keyName, this.additionalParams.get(keyName));
/*     */     }
/*     */ 
/*  69 */     return myMap;
/*     */   }

/*     */   public String[] getParameterValues(String name)
/*     */   {
/*  74 */     Object obj = this.additionalParams.get(name);
/*  75 */     if (obj == null)
/*     */     {
/*  77 */       return super.getParameterValues(name);

/*     */     }
/*     */ 
/*  81 */     return ((String[])(String[])this.additionalParams.get(name));
/*     */   }

/*     */   public Enumeration getParameterNames()
/*     */   {
/*  86 */     HashMap newMap = new HashMap();

/*     */ 
/*  89 */     Enumeration keyEnum = super.getParameterNames();
/*  90 */     while (keyEnum.hasMoreElements())
/*     */     {
/*  92 */       String keyName = (String)keyEnum.nextElement();
/*  93 */       newMap.put(keyName, keyName);
/*     */     }
/*     */ 
/*  96 */     Iterator keyIterator = this.additionalParams.keySet().iterator();
/*  97 */     while (keyIterator.hasNext())
/*     */     {
/*  99 */       String keyName = (String)keyIterator.next();
/* 100 */       newMap.put(keyName, keyName);
/*     */     }
/*     */ 
/* 103 */     Iterator newMapIterator = newMap.keySet().iterator();
/* 104 */     Vector keyNames = new Vector();
/* 105 */     while (newMapIterator.hasNext())
/*     */     {
/* 107 */       String keyName = (String)newMapIterator.next();
/* 108 */       keyNames.add(keyName);
/*     */     }
/*     */ 
/* 111 */     return keyNames.elements();
/*     */   }


/*     */   public Object getAttribute(String name)
/*     */   {
/* 117 */     if (this.additionalAttributes.get(name) != null)
/*     */     {
/* 119 */       return this.additionalAttributes.get(name);
/*     */     }
/*     */ 
/* 122 */     return super.getAttribute(name);
/*     */   }



/*     */   public void removeAttribute(String name)
/*     */   {
/* 129 */     this.additionalAttributes.remove(name);
/* 130 */     super.removeAttribute(name);
/*     */   }


/*     */   public void setAttribute(String name, Object o)
/*     */   {
/* 136 */     this.additionalAttributes.put(name, o);
/* 137 */     super.setAttribute(name, o);
/*     */   }
/*     */ }
