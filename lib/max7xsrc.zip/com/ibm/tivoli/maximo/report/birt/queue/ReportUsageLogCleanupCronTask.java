/*     */ package com.ibm.tivoli.maximo.report.birt.queue;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import psdi.app.system.CrontaskInstanceRemote;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.SimpleCronTask;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
















/*     */ public class ReportUsageLogCleanupCronTask extends SimpleCronTask
/*     */ {
/*     */   private static final long ONEDAY_IN_MILLS = 86400000L;
/*     */   private MboRemote parameterValidationMbo;
/*     */ 
/*     */   public void cronAction()
/*     */   {
/*  38 */     MXLogger logger = getCronTaskLogger();
/*     */ 
/*  40 */     if (logger.isDebugEnabled())
/*     */     {
/*  42 */       logger.debug("performing cronAction of ReportUsageLogCleanupCronTask");
/*     */     }
/*     */ 
/*  45 */     MboSetRemote msr = null;
/*     */     try
/*     */     {
/*  48 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/*  50 */       int noOfDays = getParamAsInt("NOOFDAYS");
/*     */ 
/*  52 */       Date currentTime = mxServer.getDate();
/*  53 */       long cleaupTime = currentTime.getTime() - (noOfDays * 86400000L);
/*  54 */       String timeFunction = SqlFormat.getTimestampFunction(new Date(cleaupTime));
/*     */ 
/*  56 */       msr = mxServer.getMboSet("REPORTUSAGELOG", getUserInfo());


/*     */       while (true)
/*     */       {
/*  61 */         msr.setWhere("(enterdate is null) or ((enterdate < " + timeFunction + " ))");
/*  62 */         msr.reset();
/*     */ 
/*  64 */         MboRemote mr = msr.getMbo(0);
/*  65 */         if (mr == null)

/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/*  71 */         for (int i = 0; i < 10; ++i)
/*     */         {
/*  73 */           MboRemote mrLog = msr.getMbo(i);
/*  74 */           if (mrLog == null)

/*     */           {
/*     */             break;
/*     */           }
/*     */ 
/*  80 */           mrLog.delete();
/*     */         }
/*     */ 
/*  83 */         msr.save();
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*  88 */       if (logger.isErrorEnabled())
/*     */       {
/*  90 */         logger.error("Failed to cleanup Report Usage Log.", ex);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/*  96 */         if (msr != null)
/*     */         {
/*  98 */           msr.reset();
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {
/*     */       }
/*     */     }
/*     */   }

/*     */   private UserInfo getUserInfo() {
/* 107 */     UserInfo userInfo = null;

/*     */     try
/*     */     {
/* 111 */       userInfo = getRunasUserInfo();
/* 112 */       if (userInfo == null)
/*     */       {
/* 114 */         userInfo = MXServer.getMXServer().getSystemUserInfo();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 119 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 122 */     return userInfo;/*     */   }
/*     */   public ReportUsageLogCleanupCronTask()
/*     */   {
/* 125 */     this.parameterValidationMbo = null;
/*     */   }


/*     */   public MboRemote getParameterValidationMbo(CrontaskInstanceRemote instance)
/*     */     throws MXException, RemoteException
/*     */   {
/* 132 */     if (this.parameterValidationMbo == null)
/*     */     {
/* 134 */       this.parameterValidationMbo = MXServer.getMXServer().getMboSet("REPORTCRONPARAM", instance.getUserInfo()).add();
/*     */     }
/*     */ 
/* 137 */     return this.parameterValidationMbo;
/*     */   }
/*     */ }
