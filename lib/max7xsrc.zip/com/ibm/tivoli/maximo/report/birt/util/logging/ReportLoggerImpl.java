/*     */ package com.ibm.tivoli.maximo.report.birt.util.logging;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 
















/*     */ public class ReportLoggerImpl
/*     */   implements ReportLogger
/*     */ {
/*     */   private MXLogger mxLogger;
/*     */ 
/*     */   public ReportLoggerImpl(String name)
/*     */   {
/*  30 */     this.mxLogger = MXLoggerFactory.getLogger(name);
/*     */   }

/*     */   public void debug(Object message)
/*     */   {
/*  35 */     this.mxLogger.debug(message);
/*     */   }

/*     */   public void debug(Object message, Throwable t)
/*     */   {
/*  40 */     this.mxLogger.debug(message, t);
/*     */   }

/*     */   public void error(Object message)
/*     */   {
/*  45 */     this.mxLogger.error(message);
/*     */   }

/*     */   public void error(Object message, Throwable t)
/*     */   {
/*  50 */     this.mxLogger.error(message, t);
/*     */   }

/*     */   public void fatal(Object message)
/*     */   {
/*  55 */     this.mxLogger.fatal(message);
/*     */   }

/*     */   public void fatal(Object message, Throwable t)
/*     */   {
/*  60 */     this.mxLogger.fatal(message, t);
/*     */   }

/*     */   public void info(Object message)
/*     */   {
/*  65 */     this.mxLogger.info(message);
/*     */   }

/*     */   public void info(Object message, Throwable t)
/*     */   {
/*  70 */     this.mxLogger.info(message, t);
/*     */   }

/*     */   public boolean isDebugEnabled()
/*     */   {
/*  75 */     return this.mxLogger.isDebugEnabled();
/*     */   }

/*     */   public boolean isErrorEnabled()
/*     */   {
/*  80 */     return this.mxLogger.isErrorEnabled();
/*     */   }

/*     */   public boolean isFatalEnabled()
/*     */   {
/*  85 */     return this.mxLogger.isFatalEnabled();
/*     */   }

/*     */   public boolean isInfoEnabled()
/*     */   {
/*  90 */     return this.mxLogger.isInfoEnabled();
/*     */   }

/*     */   public boolean isWarnEnabled()
/*     */   {
/*  95 */     return this.mxLogger.isWarnEnabled();
/*     */   }

/*     */   public void warn(Object message)
/*     */   {
/* 100 */     this.mxLogger.warn(message);
/*     */   }

/*     */   public void warn(Object message, Throwable t)
/*     */   {
/* 105 */     this.mxLogger.warn(message, t);
/*     */   }
/*     */ }
