/*      */ package com.ibm.tivoli.maximo.report.birt.admin;
/*      */ 
/*      */ import com.ibm.tivoli.maximo.report.birt.admin.batch.BatchImport;
/*      */ import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceCache;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.CreateListReportDataColumnInputInfo;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.CreateListReportInputInfo;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.CreateReportInputInfo;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.CreateReportRelationshipInfo;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.ReportDesign;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.ReportDesignTask;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.ReportDesignTaskProvider;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.ReportLabelInfo;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.ReportLibraryInfo;
/*      */ import com.ibm.tivoli.maximo.report.birt.design.ReportParameterInfo;
/*      */ import com.ibm.tivoli.maximo.report.birt.engine.MXReportEngine;
/*      */ import com.ibm.tivoli.maximo.report.birt.queue.ReportQueueManager;
/*      */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportParameterData;
/*      */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportRuntimeTempLocation;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileFilter;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.rmi.RemoteException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Statement;
/*      */ import java.text.DateFormat;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipFile;
/*      */ import java.util.zip.ZipInputStream;
/*      */ import java.util.zip.ZipOutputStream;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerFactory;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import org.w3c.dom.Comment;
/*      */ import org.w3c.dom.DOMImplementation;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import psdi.app.report.ReportServiceRemote;
/*      */ import psdi.app.report.ReportUtil;
/*      */ import psdi.mbo.MaxMessageCache;
/*      */ import psdi.mbo.MaximoDD;
/*      */ import psdi.mbo.MboRemote;
/*      */ import psdi.mbo.MboSetInfo;
/*      */ import psdi.mbo.MboSetRemote;
/*      */ import psdi.mbo.MboValueInfo;
/*      */ import psdi.mbo.RelationInfo;
/*      */ import psdi.mbo.SqlFormat;
/*      */ import psdi.mbo.Translate;
/*      */ import psdi.security.ConnectionKey;
/*      */ import psdi.security.ProfileRemote;
/*      */ import psdi.security.SecurityService;
/*      */ import psdi.security.UserInfo;
/*      */ import psdi.server.AppService;
/*      */ import psdi.server.DBManager;
/*      */ import psdi.server.MXServer;
/*      */ import psdi.server.MXServerInfo;
/*      */ import psdi.server.MaxVarServiceRemote;
/*      */ import psdi.server.MaximoThread;
/*      */ import psdi.util.BidiUtils;
/*      */ import psdi.util.MXAccessException;
/*      */ import psdi.util.MXApplicationException;
/*      */ import psdi.util.MXException;
/*      */ import psdi.util.MXFormat;
/*      */ import psdi.util.Message;
/*      */ import psdi.util.logging.MXLogger;
/*      */ 
















































/*      */ public class ReportAdminService extends AppService
/*      */   implements ReportAdminServiceRemote
/*      */ {
/*      */   private static final String REPORT_MBONAME = "REPORT";
/*      */   private static final String REPORT_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORT_DESCRIPTION = "DESCRIPTION";
/*      */   private static final String REPORT_BASETABLENAME = "BASETABLENAME";
/*      */   private static final String REPORT_REPORTFOLDER = "REPORTFOLDER";
/*      */   private static final String REPORT_APPNAME = "APPNAME";
/*      */   private static final String REPORT_RUNTYPE = "RUNTYPE";
/*      */   private static final String REPORT_EXCLUDEDYNAMICWHERE = "EXCLUDEDYNAMICWHERE";
/*      */   private static final String REPORT_USERID = "USERID";
/*      */   private static final String REPORT_EDITENABLED = "EDITENABLED";
/*      */   private static final String REPORT_FILENAME = "filename";
/*      */   private static final String REPORTDESIGN_MBONAME = "REPORTDESIGN";
/*      */   private static final String REPORTDESIGN_RELATIONSHIPNAME = "REPORT_DESIGN";
/*      */   private static final String REPORTDESIGN_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORTDESIGN_REPORTFILENAME = "REPORTFILENAME";
/*      */   private static final String REPORTDESIGN_REPORTCONTENT = "DESIGN";
/*      */   private static final String REPORTDESIGN_RESOURCES = "RESOURCES";
/*      */   private static final String REPORTDESIGN_ISLIBRARY = "ISLIBRARY";
/*      */   private static final String REPORTDESIGN_DESCRIPTION = "DESCRIPTION";
/*      */   private static final String REPORTDESIGN_IMPORTEDBY = "IMPORTEDBY";
/*      */   private static final String REPORTDESIGN_IMPORTEDDATE = "IMPORTEDDATE";
/*      */   private static final String REPORTLOOKUP_RELATIONSHIPNAME = "REPORT_LOOKUP";
/*      */   private static final String REPORTLOOKUP_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORTLOOKUP_PARAMETERNAME = "PARAMETERNAME";
/*      */   private static final String REPORTLOOKUP_REQUIRED = "REQUIRED";
/*      */   private static final String REPORTLOOKUP_HIDDEN = "HIDDEN";
/*      */   private static final String REPORTLOOKUP_MULTILOOKUP = "MULTILOOKUP";
/*      */   private static final String REPORTLOOKUP_LABELOVERRIDE = "LABELOVERRIDE";
/*      */   private static final String REPORTLOOKUP_ATTRIBUTENAME = "ATTRIBUTENAME";
/*      */   private static final String REPORTDEPEND_MBONAME = "REPORTDEPEND";
/*      */   private static final String REPORTDEPEND_RELATIONSHIPNAME = "REPORTDESIGN_DEPEND";
/*      */   private static final String REPORTDEPEND_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORTDEPEND_LIBRARYNAME = "DEPREPORTNAME";
/*      */   private static final String REPORTPARAM_RELATIONSHIPNAME = "REPORTDESIGN_PARAM";
/*      */   private static final String REPORTPARAM_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORTPARAM_PARAMNAME = "PARAMNAME";
/*      */   private static final String REPORTLABEL_RELATIONSHIPNAME = "REPORT_LABEL";
/*      */   private static final String REPORTLABEL_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORTLABEL_LABELKEY = "LABELKEY";
/*      */   private static final String REPORTLABEL_LABELVALUE = "LABELVALUE";
/*      */   private static final String REPORTLABEL_SIZEDYNAMIC = "SIZEDYNAMIC";
/*      */   private static final String REPORTLABEL_USEATTRIBUTE = "USEATTRIBUTE";
/*      */   private static final String REPORTLABEL_RESOURCENAME = "RESOURCENAME";
/*      */   private static final String REPORTLABEL_LANGCODE = "LANGCODE";
/*      */   private static final String REPORTAUTH_RELATIONSHIPNAME = "REPORTAUTH";
/*      */   private static final String REPORTAUTH_REPORTNAME = "REPORTNAME";
/*      */   private static final String REPORTAUTH_APPNAME = "APPNAME";
/*      */   private static final String REPORTAUTH_GROUPNAME = "GROUPNAME";
/*      */   private static final String REPORTAUTH_REPORTNUM = "REPORTNUM";
/*      */   private static final String REPORTDESIGN_REPORTLABEL_RELATIONSHIPNAME = "REPORTDESIGN_LABEL";
/*      */   private static final String CREATEREPORT_FOLDER = "create";
/*      */   private static final String CREATEREPORT_REPORTFOLDER = "report";
/*      */   private static final String CREATEREPORT_LIBRARIESFOLDER = "libraries";
/*      */   private static final int REPORTTYPE_REPORT = 0;
/*      */   private static final int REPORTTYPE_QBR = 1;
/*      */   private static final int REPORTTYPE_REPORT_AND_QBR = 2;
/*      */   public static final String PROPERTY_VIEWERURL = "mxe.report.birt.viewerurl";
/*  200 */   private ReportQueueManager reportQueueManager = null;
/*      */ 
/*  202 */   private ReportTempFolderCleanupManager reportTempFolderCleanupManager = null;
/*      */ 
/* 2424 */   private static Object tempFolderLockObj = new Object();
/*      */ 
/*      */   public ReportAdminService(MXServer mxServer)
/*      */     throws RemoteException
/*      */   {
/*  213 */     super(mxServer);
/*      */   }




/*      */   public void init()
/*      */   {
/*  221 */     super.init();


/*      */     try
/*      */     {
/*  226 */       DataSourceCache dataSourceCache = DataSourceCache.getDataSourceCache();
/*  227 */       this.mxServer.addToMaximoCache(dataSourceCache.getName(), dataSourceCache);

/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*  232 */       MXLogger reportAdminServiceLogger = getServiceLogger();
/*  233 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/*  235 */         reportAdminServiceLogger.error("Problem with Report Data Source Cache", e);
/*      */       }
/*      */     }
/*      */ 
/*  239 */     this.reportQueueManager = new ReportQueueManager();
/*  240 */     this.reportQueueManager.start();
/*  241 */     this.reportTempFolderCleanupManager = new ReportTempFolderCleanupManager(this);
/*  242 */     this.reportTempFolderCleanupManager.start();

/*      */     try
/*      */     {
/*  246 */       BatchImport batchImport = new BatchImport(this, MXServer.getMXServer().getSystemUserInfo(), getServiceLogger());
/*  247 */       batchImport.start();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  251 */       MXLogger reportAdminServiceLogger = getServiceLogger();
/*  252 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/*  254 */         reportAdminServiceLogger.error("Batch Report import failed. Try to import reports manually using importreports command", ex);
/*      */       }
/*      */     }
/*      */ 
/*  258 */     new ReportJobCleanupTask().start();
/*      */   }


/*      */   class ReportJobCleanupTask extends MaximoThread
/*      */   {
/*  264 */     private Date startDate = null;
/*      */ 
/*      */     public ReportJobCleanupTask()
/*      */     {
/*  268 */       super("ReportJobCleanupTask");
/*      */     }

/*      */     protected boolean isReady()
/*      */     {
/*  273 */       MXServerInfo serverInfo = MXServerInfo.getMXServerInfo();
/*      */ 
/*  275 */       boolean ready = serverInfo.isRunning();
/*      */ 
/*  277 */       return ready;
/*      */     }

/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/*  284 */         this.startDate = MXServer.getMXServer().getDate();
/*      */ 
/*  286 */         while (!(isReady()))

/*      */         {
/*      */           try
/*      */           {
/*  291 */             Thread.sleep(10000L);
/*      */           }
/*      */           catch (InterruptedException e)
/*      */           {
/*  295 */             if (isMarkedForShutDown())
/*      */             {
/*  297 */               break label40:
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*  302 */         if (isMarkedForShutDown())
/*      */         {
/*  304 */           label40: return;


/*      */         }
/*      */ 
/*  309 */         MXServer mxServer = MXServer.getMXServer();
/*  310 */         MboSetRemote reportJobSet = mxServer.getMboSet("REPORTJOB", mxServer.getSystemUserInfo());
/*  311 */         reportJobSet.setQbeExactMatch(true);
/*  312 */         reportJobSet.setQbe("STARTTIME", "<=" + MXFormat.dateTimeToString(this.startDate));
/*  313 */         reportJobSet.setQbe("HOSTNAME", mxServer.getServerHost());
/*  314 */         reportJobSet.setQbe("SERVERNAME", mxServer.getName());
/*      */ 
/*  316 */         SqlFormat sqlFormat = new SqlFormat(reportJobSet.getCompleteWhere());
/*  317 */         String whereClause = sqlFormat.format();


/*      */ 
/*  321 */         Connection con = null;
/*      */ 
/*  323 */         ConnectionKey ck = new ConnectionKey(mxServer.getSystemUserInfo());
/*  324 */         con = mxServer.getDBManager().getConnection(ck);
/*      */ 
/*  326 */         Statement stmt = null;
/*      */         try
/*      */         {
/*  329 */           stmt = con.createStatement();
/*  330 */           int noOfRecsDeleted = stmt.executeUpdate("delete from reportjob where " + whereClause);
/*      */ 
/*  332 */           con.commit();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */           try {
/*  337 */             con.rollback();
/*      */           } catch (Exception ex1) {
/*      */           }
/*  340 */           ex.printStackTrace();
/*      */         }
/*      */         finally
/*      */         {
/*      */           try {
/*  345 */             if (stmt != null)
/*      */             {
/*  347 */               stmt.close(); }
/*      */           } catch (Exception ex) {
/*      */           }
/*  350 */           mxServer.getDBManager().freeConnection(ck);


/*      */         }
/*      */ 
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*  358 */         t.printStackTrace();
/*      */       }
/*      */     }
/*      */   }





/*      */   public void destroy()
/*      */   {
/*  369 */     super.destroy();
/*      */ 
/*  371 */     if (this.reportQueueManager != null)
/*      */     {
/*  373 */       this.reportQueueManager.markShutdown();
/*  374 */       this.reportQueueManager = null;
/*      */     }
/*      */ 
/*  377 */     if (this.reportTempFolderCleanupManager == null)
/*      */       return;
/*  379 */     this.reportTempFolderCleanupManager.markShutdown();
/*  380 */     this.reportTempFolderCleanupManager = null;
/*      */   }









/*      */   protected boolean isAuthorized(UserInfo userInfo, String sigOptionName)
/*      */   {
/*      */     try
/*      */     {
/*  395 */       SecurityService securityService = (SecurityService)MXServer.getMXServer().lookup("SECURITY");
/*  396 */       ProfileRemote profileRemote = securityService.getProfile(userInfo);
/*  397 */       boolean authorized = profileRemote.getAppOptionAuth("REPORT", sigOptionName, null);
/*  398 */       return authorized;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  402 */       MXLogger reportAdminServiceLogger = getServiceLogger();
/*  403 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/*  405 */         reportAdminServiceLogger.error("Failed to determine authorization for option: " + sigOptionName, ex);
/*      */       }
/*      */     }
/*      */ 
/*  409 */     return false;
/*      */   }

















/*      */   public byte[] updateReportDesign(UserInfo userInfo, String reportName, String appName, boolean saveChanges)
/*      */     throws MXException, RemoteException
/*      */   {
/*  431 */     if ((!(isAuthorized(userInfo, "REPEXPREP"))) || (!(isAuthorized(userInfo, "REPIMPREP"))))
/*      */     {
/*  433 */       throw new MXAccessException("access", "notauthorized");
/*      */     }
/*      */ 
/*  436 */     MXLogger reportAdminServiceLogger = getServiceLogger();
/*  437 */     byte[] xmlReportData = null;
/*      */ 
/*  439 */     if (reportAdminServiceLogger.isInfoEnabled())
/*      */     {
/*  441 */       reportAdminServiceLogger.info("Started updating report: " + reportName);
/*      */     }
/*      */ 
/*  444 */     if (reportName == null)
/*      */     {
/*  446 */       throw new IllegalArgumentException("Report name is required to update a report.");
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  451 */       ReportDesignTask designTask = ReportDesignTaskProvider.getReportDesignTask();
/*  452 */       if (designTask == null)
/*      */       {
/*  454 */         throw new IllegalStateException("BIRT Report Engine not initialized properly for this operation to work.");
/*      */       }
/*      */ 
/*  457 */       if (designTask != null)
/*      */       {
/*  459 */         ReportRunInfo reportRunInfo = null;



/*      */         try
/*      */         {
/*  465 */           reportRunInfo = prepareReportForExport(userInfo, reportName, appName);
/*  466 */           String reportPath = reportRunInfo.getTempRunFolder() + File.separator + reportRunInfo.getReportFolderName();

/*      */ 
/*  469 */           if (reportAdminServiceLogger.isDebugEnabled())
/*      */           {
/*  471 */             reportAdminServiceLogger.debug("Extracting report into a temporary folder: " + reportRunInfo.getTempRunFolder());

/*      */           }
/*      */ 
/*  475 */           boolean wasUpdated = designTask.updateReportDesign(reportRunInfo.getReportName(), reportPath, Locale.ENGLISH);
/*      */ 
/*  477 */           if (wasUpdated == true)




/*      */           {
/*  483 */             xmlReportData = getFileContent(reportPath + File.separator + reportName);
/*  484 */             if (saveChanges == true)


/*      */             {
/*  488 */               MboSetRemote reportDesignSetRemote = getMboSet("REPORTDESIGN", userInfo);
/*  489 */               reportDesignSetRemote.setQbeExactMatch(true);
/*  490 */               reportDesignSetRemote.setQbe("REPORTNAME", reportName);
/*  491 */               reportDesignSetRemote.reset();
/*      */ 
/*  493 */               MboRemote reportDesignRemote = reportDesignSetRemote.getMbo(0);
/*  494 */               if (reportDesignRemote == null)
/*      */               {
/*  496 */                 throw new MXApplicationException("reports", "notfound", new Object[] { reportName, appName });
/*      */               }
/*      */ 
/*  499 */               reportDesignRemote.setValue("DESIGN", new String(xmlReportData, "UTF-8"));
/*  500 */               reportDesignSetRemote.save();
/*      */             }
/*      */           }
/*      */         }
/*      */         finally
/*      */         {
/*  506 */           deleteFolder(reportRunInfo.getTempRunFolder());
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  512 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/*  514 */         reportAdminServiceLogger.error(ex.getMessage(), ex);
/*      */       }
/*  516 */       throw new MXApplicationException("reports", "failedtoupdate");
/*      */     }
/*  518 */     return xmlReportData;
/*      */   }











/*      */   public void importReport(UserInfo userInfo, ReportImportInfo reportImportInfo, boolean fromUI)
/*      */     throws MXException, RemoteException
/*      */   {
/*  534 */     importReport(userInfo, reportImportInfo, fromUI, true);
/*      */   }












/*      */   protected void importReport(UserInfo userInfo, ReportImportInfo reportImportInfo, boolean fromUI, boolean checkAuthorization)
/*      */     throws MXException, RemoteException
/*      */   {
/*  551 */     importReport(userInfo, reportImportInfo, fromUI, true, false);
/*      */   }













/*      */   protected void importReport(UserInfo userInfo, ReportImportInfo reportImportInfo, boolean fromUI, boolean checkAuthorization, boolean makePublic)
/*      */     throws MXException, RemoteException
/*      */   {
/*  569 */     MXLogger reportAdminServiceLogger = getServiceLogger();
/*      */ 
/*  571 */     if ((checkAuthorization) && 

/*  573 */       (!(isAuthorized(userInfo, "REPIMPREP"))))
/*      */     {
/*  575 */       throw new MXAccessException("access", "notauthorized");

/*      */     }
/*      */ 
/*  579 */     if (reportImportInfo == null)
/*      */     {
/*  581 */       throw new IllegalArgumentException("ReportImportInfo is required to import a report.");
/*      */     }
/*      */ 
/*  584 */     if (reportAdminServiceLogger.isInfoEnabled())
/*      */     {
/*  586 */       reportAdminServiceLogger.info("Started Importing report for app [" + reportImportInfo.getAppName() + "] : " + reportImportInfo.getName());
/*      */     }
/*      */ 
/*  589 */     String reportName = reportImportInfo.getName();
/*  590 */     String reportDescription = reportImportInfo.getAttribute("DESCRIPTION");
/*  591 */     String reportFileName = reportImportInfo.getFileName();
/*  592 */     byte[] xmlReportData = reportImportInfo.getXmlReportData();
/*  593 */     byte[] resources = reportImportInfo.getResources();


/*      */ 
/*  597 */     if (reportName == null)
/*      */     {
/*  599 */       throw new IllegalArgumentException("ReportName is required to import a report.");
/*      */     }
/*      */ 
/*  602 */     if (xmlReportData == null)
/*      */     {
/*  604 */       throw new IllegalArgumentException("Report does not seem to have anything.");

/*      */     }
/*      */ 
/*  608 */     HashMap reportParametersAllInfo = new HashMap();
/*  609 */     HashSet reportParametersAll = new HashSet();
/*  610 */     ArrayList reportParameters = new ArrayList();
/*  611 */     ArrayList reportLibraries = new ArrayList();

/*      */ 
/*  614 */     ByteArrayInputStream reportInputStream = new ByteArrayInputStream(xmlReportData);
/*  615 */     ByteArrayInputStream resourcesInputStream = null;
/*      */ 
/*  617 */     if ((resources != null) && (reportImportInfo.isImportResourcesEnabled()))
/*      */     {
/*  619 */       resourcesInputStream = new ByteArrayInputStream(resources);
/*      */     }
/*      */ 
/*  622 */     ReportParameterInfo[] reportParams = null;
/*  623 */     ReportLibraryInfo[] libraryInfoArray = null;
/*  624 */     ReportLabelInfo[] labelInfoArray = null;
/*  625 */     String includedResourceFileName = null;

/*      */     try
/*      */     {
/*  629 */       ReportDesignTask designTask = ReportDesignTaskProvider.getReportDesignTask();
/*  630 */       if (designTask == null)
/*      */       {
/*  632 */         throw new IllegalStateException("BIRT Report Engine not initialized properly for this operation to work.");
/*      */       }
/*      */ 
/*  635 */       if (designTask != null)
/*      */       {
/*  637 */         String tempReportFolder = null;
/*  638 */         String tempFolder = AdminServiceTempLocation.getTemporaryImportLocation();
/*  639 */         String tempUniqueFolder = createUniqueTempFolder(tempFolder);
/*  640 */         ReportDesign reportDesign = null;

/*      */         try
/*      */         {
/*  644 */           tempReportFolder = tempFolder + File.separator + tempUniqueFolder;
/*  645 */           copyReportFile(tempReportFolder, reportFileName, new String(xmlReportData, "UTF-8"), resourcesInputStream);
/*      */ 
/*  647 */           Locale l = getLocaleByLangCode(userInfo);
/*  648 */           reportDesign = designTask.openReportDesign(reportFileName, tempReportFolder, l);
/*      */ 
/*  650 */           reportParams = reportDesign.getParameterInfo();
/*  651 */           libraryInfoArray = reportDesign.getLibraryInfo();
/*  652 */           includedResourceFileName = reportDesign.getIncludedResourceFileName();
/*      */ 
/*  654 */           labelInfoArray = getReportLabels(tempReportFolder, includedResourceFileName, userInfo.getLangCode());
/*  655 */           String reportTitle = reportDesign.getTitle();
/*  656 */           if (reportTitle != null)
/*      */           {
/*  658 */             reportDescription = reportTitle;
/*      */           }
/*      */         }
/*      */         finally
/*      */         {
/*  663 */           if (reportDesign != null)
/*      */           {
/*  665 */             reportDesign.close();
/*      */           }
/*      */ 
/*  668 */           deleteFolder(tempReportFolder);
/*      */         }
/*      */ 
/*  671 */         if (reportParams != null)
/*      */         {
/*  673 */           int noOfParams = reportParams.length;
/*  674 */           for (int i = 0; i < noOfParams; ++i)
/*      */           {
/*  676 */             String param = reportParams[i].getName();


/*      */ 
/*  680 */             if (libraryInfoArray.length <= 0)
/*      */             {
/*  682 */               reportParametersAllInfo.put(param, reportParams[i]);
/*      */             }
/*      */ 
/*  685 */             reportParameters.add(param);
/*  686 */             reportParametersAll.add(param);
/*      */ 
/*  688 */             if (!(reportAdminServiceLogger.isDebugEnabled()))
/*      */               continue;
/*  690 */             reportAdminServiceLogger.debug("[" + reportImportInfo.getName() + "] Report parameter[" + i + "] = " + param);


/*      */           }
/*      */ 
/*      */         }
/*  696 */         else if (reportAdminServiceLogger.isDebugEnabled())
/*      */         {
/*  698 */           reportAdminServiceLogger.debug("[" + reportImportInfo.getName() + "] Report has no parameters");

/*      */         }
/*      */ 
/*  702 */         if (libraryInfoArray != null)
/*      */         {
/*  704 */           int noOfLibraries = libraryInfoArray.length;
/*  705 */           for (int i = 0; i < noOfLibraries; ++i)
/*      */           {
/*  707 */             String libraryName = libraryInfoArray[i].getName();
/*  708 */             reportLibraries.add(libraryInfoArray[i]);
/*      */ 
/*  710 */             if (!(reportAdminServiceLogger.isDebugEnabled()))
/*      */               continue;
/*  712 */             reportAdminServiceLogger.debug("[" + reportImportInfo.getName() + "] Report depends on library[" + i + "] = " + libraryName);


/*      */           }
/*      */ 
/*      */         }
/*  718 */         else if (reportAdminServiceLogger.isDebugEnabled())
/*      */         {
/*  720 */           reportAdminServiceLogger.debug("[" + reportImportInfo.getName() + "] Report does not depend on any Libraries");
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  727 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/*  729 */         reportAdminServiceLogger.error(ex.getMessage(), ex);
/*      */       }
/*      */ 
/*  732 */       throw new MXApplicationException("reports", "failedtoimport");


/*      */     }
/*      */ 
/*  737 */     MboSetRemote reportLibrarySetRemote = getMboSet("REPORTDESIGN", userInfo);
/*  738 */     reportLibrarySetRemote.setQbeExactMatch(true);
/*      */ 
/*  740 */     int noOfLibraries = reportLibraries.size();
/*  741 */     for (int i = 0; i < noOfLibraries; ++i)
/*      */     {
/*  743 */       ReportLibraryInfo libraryInfo = (ReportLibraryInfo)reportLibraries.get(i);
/*  744 */       reportLibrarySetRemote.setQbe("REPORTNAME", libraryInfo.getFileName());
/*  745 */       reportLibrarySetRemote.setQbe("ISLIBRARY", "1");
/*  746 */       reportLibrarySetRemote.reset();
/*      */ 
/*  748 */       if (!(reportLibrarySetRemote.isEmpty()))
/*      */         continue;
/*  750 */       throw new MXApplicationException("reports", "librarynotimported");







/*      */     }
/*      */ 
/*  760 */     for (int i = 0; i < noOfLibraries; ++i)
/*      */     {
/*  762 */       ReportLibraryInfo libraryInfo = (ReportLibraryInfo)reportLibraries.get(i);
/*      */ 
/*  764 */       String libraryFileName = libraryInfo.getFileName();
/*  765 */       addDependentLibraryParameters(userInfo, libraryFileName, reportParametersAll);

/*      */     }
/*      */ 
/*  769 */     Iterator paramIterator = reportParametersAll.iterator();
/*  770 */     while (paramIterator.hasNext())
/*      */     {
/*  772 */       String paramName = (String)paramIterator.next();
/*  773 */       if (!(reportParameters.contains(paramName)))




/*      */       {
/*  779 */         throw new MXApplicationException("reports", "allparamsnotinreport", new Object[] { reportName, reportImportInfo.getAppName() });







/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  793 */       if (noOfLibraries > 0)
/*      */       {
/*  795 */         ReportDesignTask designTask = ReportDesignTaskProvider.getReportDesignTask();
/*  796 */         if (designTask == null)
/*      */         {
/*  798 */           throw new IllegalStateException("BIRT Report Engine not initialized properly for this operation to work.");
/*      */         }
/*      */ 
/*  801 */         if (designTask != null)
/*      */         {
/*  803 */           String tempReportFolder = null;
/*  804 */           String tempFolder = AdminServiceTempLocation.getTemporaryImportLocation();
/*  805 */           String tempUniqueFolder = createUniqueTempFolder(tempFolder);
/*  806 */           ReportDesign reportDesign = null;

/*      */           try
/*      */           {
/*  810 */             tempReportFolder = tempFolder + File.separator + tempUniqueFolder;

/*      */ 
/*  813 */             MboSetRemote reportDependSet = getMboSet("REPORTDEPEND", userInfo);
/*  814 */             reportDependSet.setQbeExactMatch(true);
/*  815 */             reportDependSet.setQbe("REPORTNAME", reportName);
/*  816 */             reportDependSet.reset();
/*      */ 
/*  818 */             int i = 0;
/*      */             while (true)
/*      */             {
/*  821 */               MboRemote reportDependMbo = reportDependSet.getMbo(i);
/*  822 */               if (reportDependMbo == null)
/*      */               {
/*      */                 break;
/*      */               }
/*      */ 
/*  827 */               String libraryName = reportDependMbo.getString("DEPREPORTNAME");

/*      */ 
/*  830 */               extractReport(userInfo, libraryName, tempReportFolder, true);
/*      */ 
/*  832 */               ++i;
/*      */             }
/*      */ 
/*  835 */             reportInputStream = new ByteArrayInputStream(xmlReportData);
/*  836 */             if ((resources != null) && (reportImportInfo.isImportResourcesEnabled()))
/*      */             {
/*  838 */               resourcesInputStream = new ByteArrayInputStream(resources);
/*      */             }
/*      */ 
/*  841 */             Locale l = getLocaleByLangCode(userInfo);
/*  842 */             copyReportFile(tempReportFolder, reportFileName, new String(xmlReportData, "UTF-8"), resourcesInputStream);
/*      */ 
/*  844 */             reportDesign = designTask.openReportDesign(reportFileName, tempReportFolder, l);
/*  845 */             reportParams = reportDesign.getParameterInfo();
/*      */ 
/*  847 */             int noOfReportParams = reportParams.length;
/*  848 */             for (int j = 0; j < noOfReportParams; ++j)
/*      */             {
/*  850 */               ReportParameterInfo reportParamInfo = reportParams[j];
/*  851 */               reportParametersAllInfo.put(reportParamInfo.getName(), reportParamInfo);
/*      */             }
/*      */           }
/*      */           finally
/*      */           {
/*  856 */             if (reportDesign != null)
/*      */             {
/*  858 */               reportDesign.close();
/*      */             }
/*      */ 
/*  861 */             deleteFolder(tempReportFolder);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  868 */       throw new MXApplicationException("reports", "failedtoextractparams", new Object[] { reportName, reportImportInfo.getAppName() }, t);






/*      */     }
/*      */ 
/*  877 */     MboSetRemote reportMboSet = getMboSet("REPORT", userInfo);
/*  878 */     reportMboSet.setQbeExactMatch(true);
/*  879 */     reportMboSet.setQbe("REPORTNAME", reportName);
/*  880 */     reportMboSet.setQbe("APPNAME", reportImportInfo.getAppName());
/*  881 */     reportMboSet.reset();
/*  882 */     MboRemote reportMbo = reportMboSet.getMbo(0);
/*  883 */     if (reportMbo == null)

/*      */     {
/*  886 */       reportMbo = reportMboSet.add();
/*  887 */       reportMbo.setValue("REPORTNAME", reportName);
/*  888 */       reportMbo.setValue("APPNAME", reportImportInfo.getAppName());


/*      */     }
/*      */ 
/*  893 */     if (fromUI) {
/*  894 */       reportMbo.setValue("DESCRIPTION", reportImportInfo.getAttribute("DESCRIPTION"), 11L);

/*      */     }
/*  897 */     else if (reportMbo.isNull("DESCRIPTION")) {
/*  898 */       reportMbo.setValue("DESCRIPTION", reportImportInfo.getAttribute("DESCRIPTION"), 11L);


/*      */     }
/*      */ 
/*  903 */     String baseTableName = reportImportInfo.getAttribute("BASETABLENAME");
/*  904 */     if (baseTableName == null)
/*      */     {
/*  906 */       baseTableName = reportMbo.getString("REPORTTOAPP.MAINTBNAME");
/*      */     }
/*      */ 
/*  909 */     reportMbo.setValue("BASETABLENAME", baseTableName);
/*  910 */     String runType = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("REPORTTYPES", "BIRT", reportMbo);
/*  911 */     reportMbo.setValue("RUNTYPE", runType, 11L);
/*      */ 
/*  913 */     Iterator attrIterator = reportImportInfo.getAttributes();
/*  914 */     while (attrIterator.hasNext())
/*      */     {
/*  916 */       String attributeName = (String)attrIterator.next();
/*  917 */       if ((attributeName.equalsIgnoreCase("DESCRIPTION")) || (attributeName.equalsIgnoreCase("BASETABLENAME")) || (attributeName.equalsIgnoreCase("APPNAME")) || (attributeName.equalsIgnoreCase("REPORTNAME")) || (attributeName.equalsIgnoreCase("filename"))) continue; if (attributeName.equalsIgnoreCase("RUNTYPE"))







/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/*  929 */       String attributeValue = reportImportInfo.getAttribute(attributeName);
/*      */ 
/*  931 */       if (attributeName.equalsIgnoreCase("TOOLBARLOCATION"))
/*      */       {
/*  933 */         String toolbarLocation = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("TOOLBARLOCATIONS", attributeValue, reportMbo);
/*  934 */         reportMbo.setValue(attributeName, toolbarLocation, 38L);
/*      */       }
/*  936 */       else if (attributeName.equalsIgnoreCase("TOOLBARICON"))
/*      */       {
/*  938 */         String toolbarIcon = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("TOOLBARICONS", attributeValue, reportMbo);
/*  939 */         reportMbo.setValue(attributeName, toolbarIcon, 38L);
/*      */       }
/*  941 */       else if (attributeName.equalsIgnoreCase("QLLOC"))
/*      */       {
/*  943 */         String qlLoc = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("TOOLBARLOCATIONS", attributeValue, reportMbo);
/*  944 */         reportMbo.setValue(attributeName, qlLoc, 38L);
/*      */       }
/*  946 */       else if (attributeName.equalsIgnoreCase("DPLOC"))
/*      */       {
/*  948 */         String dpLoc = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("TOOLBARLOCATIONS", attributeValue, reportMbo);
/*  949 */         reportMbo.setValue(attributeName, dpLoc, 38L);
/*      */       }
/*  951 */       else if (attributeName.equalsIgnoreCase("PADLOC"))
/*      */       {
/*  953 */         String padLoc = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("TOOLBARLOCATIONS", attributeValue, reportMbo);
/*  954 */         reportMbo.setValue(attributeName, padLoc, 38L);
/*      */       }
/*      */       else
/*      */       {
/*  958 */         reportMbo.setValue(attributeName, attributeValue, 38L);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  963 */     MboSetRemote reportDesignMboSet = reportMbo.getMboSet("REPORT_DESIGN");
/*  964 */     MboRemote reportDesignMbo = reportDesignMboSet.getMbo(0);
/*  965 */     if (reportDesignMbo == null)

/*      */     {
/*  968 */       reportDesignMbo = reportDesignMboSet.add();
/*  969 */       reportDesignMbo.setValue("REPORTNAME", reportName);
/*  970 */       reportDesignMbo.setValue("REPORTFILENAME", reportFileName);

/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  976 */       reportDesignMbo.setValue("ISLIBRARY", false);
/*  977 */       reportDesignMbo.setValue("DESCRIPTION", reportDescription);
/*  978 */       reportDesignMbo.setValue("DESIGN", new String(xmlReportData, "UTF-8"));
/*  979 */       reportDesignMbo.setValue("IMPORTEDBY", userInfo.getUserName());
/*  980 */       reportDesignMbo.setValue("IMPORTEDDATE", MXServer.getMXServer().getDate());
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  984 */       throw new MXApplicationException("reports", "failedtosetvalue", new Object[] { reportName, reportImportInfo.getAppName() }, t);


/*      */     }
/*      */ 
/*  989 */     if (reportImportInfo.isImportResourcesEnabled())
/*      */     {
/*  991 */       reportDesignMbo.setValue("RESOURCES", resources);


/*      */     }
/*      */ 
/*  996 */     MboSetRemote reportLibraryRefSetRemote = reportDesignMbo.getMboSet("REPORTDESIGN_DEPEND");
/*  997 */     reportLibraryRefSetRemote.deleteAll();
/*      */ 
/*  999 */     for (int j = 0; j < noOfLibraries; ++j)
/*      */     {
/* 1001 */       ReportLibraryInfo libraryInfo = (ReportLibraryInfo)reportLibraries.get(j);
/*      */ 
/* 1003 */       String libraryFileName = libraryInfo.getFileName();
/*      */ 
/* 1005 */       MboRemote reportLibraryRefRemote = reportLibraryRefSetRemote.add();
/*      */ 
/* 1007 */       reportLibraryRefRemote.setValue("REPORTNAME", reportName);
/* 1008 */       reportLibraryRefRemote.setValue("DEPREPORTNAME", libraryFileName);


/*      */     }
/*      */ 
/* 1013 */     MboSetRemote reportParamsSetRemote = reportDesignMbo.getMboSet("REPORTDESIGN_PARAM");
/* 1014 */     reportParamsSetRemote.deleteAll();
/* 1015 */     int noOfParams = reportParameters.size();
/*      */ 
/* 1017 */     for (int i = 0; i < noOfParams; ++i)
/*      */     {
/* 1019 */       String paramName = (String)reportParameters.get(i);
/*      */ 
/* 1021 */       MboRemote reportParamRemote = reportParamsSetRemote.add();
/*      */ 
/* 1023 */       reportParamRemote.setValue("REPORTNAME", reportName);
/* 1024 */       reportParamRemote.setValue("PARAMNAME", paramName);


/*      */     }
/*      */ 
/* 1029 */     ArrayList existingParamsList = new ArrayList();
/* 1030 */     MboSetRemote birtReportLookupMboSet = reportMbo.getMboSet("REPORT_LOOKUP");
/* 1031 */     int i = 0;
/*      */     while (true)
/*      */     {
/* 1034 */       MboRemote birtReportLookup = birtReportLookupMboSet.getMbo(i);
/* 1035 */       if (birtReportLookup == null)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 1040 */       String paramName = birtReportLookup.getString("PARAMETERNAME");
/* 1041 */       existingParamsList.add(paramName);
/* 1042 */       ++i;

/*      */     }
/*      */ 
/* 1046 */     int existingParamCount = existingParamsList.size();
/* 1047 */     for (int j = 0; j < existingParamCount; ++j)
/*      */     {
/* 1049 */       String existingParam = (String)existingParamsList.get(j);
/* 1050 */       if (reportParametersAll.contains(existingParam)) {
/*      */         continue;
/*      */       }
/* 1053 */       birtReportLookupMboSet.getMbo(j).delete();


/*      */     }
/*      */ 
/* 1058 */     Iterator reportParamAllIterator = reportParametersAll.iterator();
/* 1059 */     while (reportParamAllIterator.hasNext())
/*      */     {
/* 1061 */       String reportParam = (String)reportParamAllIterator.next();

/*      */ 
/* 1064 */       if ((reportParam.equalsIgnoreCase("appname")) || (reportParam.equalsIgnoreCase("delimitedparams")) || (reportParam.equalsIgnoreCase("paramstring")) || (reportParam.equalsIgnoreCase("paramdelimiter")) || (reportParam.equalsIgnoreCase("where"))) continue; if (reportParam.equalsIgnoreCase("usepagebreaks"))







/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/* 1076 */       if (!(existingParamsList.contains(reportParam)))





/*      */       {
/* 1083 */         MboRemote birtReportLookupMbo = birtReportLookupMboSet.add();
/* 1084 */         birtReportLookupMbo.setValue("REPORTNAME", reportName);
/* 1085 */         birtReportLookupMbo.setValue("PARAMETERNAME", reportParam);
/* 1086 */         birtReportLookupMbo.setValue("MULTILOOKUP", 0);
/*      */ 
/* 1088 */         ReportParameterInfo paramInfo = (ReportParameterInfo)reportParametersAllInfo.get(reportParam);
/* 1089 */         birtReportLookupMbo.setValue("REQUIRED", !(paramInfo.isAllowBlank()));
/* 1090 */         birtReportLookupMbo.setValue("HIDDEN", paramInfo.isConcealValue());
/* 1091 */         birtReportLookupMbo.setValue("LABELOVERRIDE", paramInfo.getPromptText());
/*      */ 
/* 1093 */         ReportImportParamInfo importParamInfo = reportImportInfo.getParameter(reportParam);
/* 1094 */         if (importParamInfo != null)
/*      */         {
/* 1096 */           Iterator paramAttrIterator = importParamInfo.getAttributes();
/* 1097 */           while (paramAttrIterator.hasNext())
/*      */           {
/* 1099 */             String paramAttributeName = (String)paramAttrIterator.next();
/* 1100 */             if (paramAttributeName.equalsIgnoreCase("APPNAME")) continue; if (paramAttributeName.equalsIgnoreCase("REPORTNAME"))



/*      */             {
/*      */               continue;
/*      */             }
/*      */ 
/* 1108 */             String paramAttributeValue = importParamInfo.getAttribute(paramAttributeName);
/* 1109 */             birtReportLookupMbo.setValue(paramAttributeName, paramAttributeValue, 38L);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1117 */     i = 0;
/*      */     while (true)
/*      */     {
/* 1120 */       MboRemote birtReportLookupMbo = birtReportLookupMboSet.getMbo(i);
/* 1121 */       if (birtReportLookupMbo == null)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 1126 */       if ((birtReportLookupMbo.isNew()) || (birtReportLookupMbo.toBeDeleted()))
/*      */       {
/* 1128 */         ++i;

/*      */       }
/*      */ 
/* 1132 */       String reportParam = birtReportLookupMbo.getString("PARAMETERNAME");
/* 1133 */       ReportParameterInfo paramInfo = (ReportParameterInfo)reportParametersAllInfo.get(reportParam);
/* 1134 */       birtReportLookupMbo.setValue("REQUIRED", !(paramInfo.isAllowBlank()));
/* 1135 */       birtReportLookupMbo.setValue("HIDDEN", paramInfo.isConcealValue());


/*      */ 
/* 1139 */       ReportImportParamInfo importParamInfo = reportImportInfo.getParameter(reportParam);
/* 1140 */       if (importParamInfo != null)
/*      */       {
/* 1142 */         Iterator paramAttrIterator = importParamInfo.getAttributes();
/* 1143 */         while (paramAttrIterator.hasNext())
/*      */         {
/* 1145 */           String paramAttributeName = (String)paramAttrIterator.next();
/* 1146 */           if ((paramAttributeName.equalsIgnoreCase("APPNAME")) || (paramAttributeName.equalsIgnoreCase("REPORTNAME"))) continue; if (paramAttributeName.equalsIgnoreCase("LABELOVERRIDE"))




/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 1155 */           String paramAttributeValue = importParamInfo.getAttribute(paramAttributeName);
/* 1156 */           birtReportLookupMbo.setValue(paramAttributeName, paramAttributeValue, 38L);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1161 */       ++i;

/*      */     }
/*      */ 
/* 1165 */     if (makePublic == true)
/*      */     {
/* 1167 */       MboSetRemote birtReportAuthSet = reportMbo.getMboSet("REPORTAUTH");
/* 1168 */       String allUserGroup = getMaxVar().getString("ALLUSERGROUP", null);
/*      */ 
/* 1170 */       birtReportAuthSet.setQbeExactMatch(true);
/* 1171 */       birtReportAuthSet.setQbe("GROUPNAME", allUserGroup);
/* 1172 */       birtReportAuthSet.reset();
/*      */ 
/* 1174 */       if (birtReportAuthSet.isEmpty())
/*      */       {
/* 1176 */         MboRemote birtReportAuth = birtReportAuthSet.add();
/* 1177 */         birtReportAuth.setValue("REPORTNAME", reportName);
/* 1178 */         birtReportAuth.setValue("APPNAME", reportImportInfo.getAppName());
/* 1179 */         birtReportAuth.setValue("GROUPNAME", allUserGroup);
/* 1180 */         birtReportAuth.setValue("REPORTNUM", reportMbo.getString("reportnum"));

/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1186 */     if (reportImportInfo.isImportResourcesEnabled())

/*      */     {
/* 1189 */       String baseLangCode = getMaxVar().getString("BASELANGUAGE", "");
/*      */ 
/* 1191 */       MboSetRemote reportLabelSetRemote = reportMbo.getMboSet("REPORT_LABEL");
/*      */ 
/* 1193 */       if (labelInfoArray != null)


/*      */       {
/* 1197 */         if (labelInfoArray.length == 0)


/*      */         {
/* 1201 */           reportLabelSetRemote.deleteAll();
/*      */         }
/*      */         else
/*      */         {
/* 1205 */           ArrayList currentLabels = new ArrayList();
/* 1206 */           int noOfCurrentLabels = labelInfoArray.length;
/* 1207 */           for (int j = 0; j < noOfCurrentLabels; ++j)
/*      */           {
/* 1209 */             currentLabels.add(labelInfoArray[j].getKey());


/*      */           }
/*      */ 
/* 1214 */           HashMap existingLabelKeys = new HashMap();
/* 1215 */           ArrayList existingLabelKeyIndexes = new ArrayList();
/* 1216 */           i = 0;
/*      */           while (true)
/*      */           {
/* 1219 */             MboRemote reportLabelRemote = reportLabelSetRemote.getMbo(i);
/* 1220 */             if (reportLabelRemote == null)
/*      */             {
/*      */               break;
/*      */             }
/*      */ 
/* 1225 */             String labelKey = reportLabelRemote.getString("LABELKEY");
/* 1226 */             String labelValue = reportLabelRemote.getString("LABELVALUE");
/* 1227 */             existingLabelKeys.put(labelKey, labelValue);
/* 1228 */             existingLabelKeyIndexes.add(labelKey);


/*      */ 
/* 1232 */             if (!(currentLabels.contains(labelKey)))
/*      */             {
/* 1234 */               reportLabelRemote.delete();
/*      */             }
/*      */ 
/* 1237 */             ++i;

/*      */           }
/*      */ 
/* 1241 */           for (int j = 0; j < noOfCurrentLabels; ++j)
/*      */           {
/* 1243 */             String currentLabelKey = labelInfoArray[j].getKey();
/*      */ 
/* 1245 */             Object obj = existingLabelKeys.get(currentLabelKey);
/*      */ 
/* 1247 */             if (obj != null)
/*      */             {
/* 1249 */               String valueInDB = (String)obj;
/* 1250 */               if (!(valueInDB.equals(labelInfoArray[j].getValue())))

/*      */               {
/* 1253 */                 int index = existingLabelKeyIndexes.indexOf(currentLabelKey);
/* 1254 */                 MboRemote reportLabelRemote = reportLabelSetRemote.getMbo(index);
/* 1255 */                 reportLabelRemote.setValue("LABELVALUE", labelInfoArray[j].getValue());
/* 1256 */                 if (includedResourceFileName != null)
/*      */                 {
/* 1258 */                   reportLabelRemote.setValue("RESOURCENAME", includedResourceFileName + ".properties");
/*      */                 }
/*      */                 else
/*      */                 {
/* 1262 */                   reportLabelRemote.setValueNull("RESOURCENAME");
/*      */                 }
/*      */ 
/* 1265 */                 reportLabelRemote.setValue("LANGCODE", baseLangCode);
/*      */               }
/*      */               else
/*      */               {
/* 1269 */                 int index = existingLabelKeyIndexes.indexOf(currentLabelKey);
/* 1270 */                 MboRemote reportLabelRemote = reportLabelSetRemote.getMbo(index);
/* 1271 */                 String resourceNameInDB = reportLabelRemote.getString("RESOURCENAME");
/* 1272 */                 boolean resourceNameInDBNull = reportLabelRemote.isNull("RESOURCENAME");
/*      */ 
/* 1274 */                 if (includedResourceFileName != null)
/*      */                 {
/* 1276 */                   if ((!(resourceNameInDBNull)) && (!(resourceNameInDB.equals(includedResourceFileName + ".properties"))))


/*      */                   {
/* 1280 */                     reportLabelRemote.setValue("LABELVALUE", labelInfoArray[j].getValue());
/* 1281 */                     reportLabelRemote.setValue("RESOURCENAME", includedResourceFileName + ".properties");
/*      */                   }
/* 1283 */                   else if (resourceNameInDBNull)
/*      */                   {
/* 1285 */                     reportLabelRemote.setValue("LABELVALUE", labelInfoArray[j].getValue());
/* 1286 */                     reportLabelRemote.setValue("RESOURCENAME", includedResourceFileName + ".properties");

/*      */                   }
/*      */ 
/*      */                 }
/* 1291 */                 else if (!(resourceNameInDBNull))
/*      */                 {
/* 1293 */                   reportLabelRemote.setValueNull("RESOURCENAME");
/*      */                 }
/*      */ 
/* 1296 */                 reportLabelRemote.setValue("LANGCODE", baseLangCode);
/*      */               }
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1302 */               MboRemote reportLabelRemote = reportLabelSetRemote.add();
/* 1303 */               reportLabelRemote.setValue("REPORTNAME", reportName);
/* 1304 */               reportLabelRemote.setValue("LABELKEY", labelInfoArray[j].getKey());
/* 1305 */               reportLabelRemote.setValue("LABELVALUE", labelInfoArray[j].getValue());
/* 1306 */               reportLabelRemote.setValue("SIZEDYNAMIC", 0);
/* 1307 */               reportLabelRemote.setValue("USEATTRIBUTE", 0);
/* 1308 */               if (includedResourceFileName != null)
/*      */               {
/* 1310 */                 reportLabelRemote.setValue("RESOURCENAME", includedResourceFileName + ".properties");
/*      */               }
/*      */               else
/*      */               {
/* 1314 */                 reportLabelRemote.setValueNull("RESOURCENAME");
/*      */               }
/* 1316 */               reportLabelRemote.setValue("LANGCODE", baseLangCode);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1323 */     reportMboSet.save();
/*      */ 
/* 1325 */     if (!(reportAdminServiceLogger.isInfoEnabled()))
/*      */       return;
/* 1327 */     reportAdminServiceLogger.info("Finished Importing report for app [" + reportImportInfo.getAppName() + "] : " + reportImportInfo.getName());
/*      */   }











/*      */   public void importReportLibrary(UserInfo userInfo, ReportImportInfo reportImportInfo)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1343 */     if (!(isAuthorized(userInfo, "REPIMPLIB")))
/*      */     {
/* 1345 */       throw new MXAccessException("access", "notauthorized");
/*      */     }
/*      */ 
/* 1348 */     MXLogger reportAdminServiceLogger = getServiceLogger();
/*      */ 
/* 1350 */     if (reportImportInfo == null)
/*      */     {
/* 1352 */       throw new IllegalArgumentException("ReportImportInfo is required to import a report.");
/*      */     }
/*      */ 
/* 1355 */     if (reportAdminServiceLogger.isInfoEnabled())
/*      */     {
/* 1357 */       reportAdminServiceLogger.info("Started Importing Report Library: " + reportImportInfo.getName());
/*      */     }
/*      */ 
/* 1360 */     String reportName = reportImportInfo.getName();
/* 1361 */     String reportDescription = reportImportInfo.getAttribute("DESCRIPTION");
/* 1362 */     String reportFileName = reportImportInfo.getFileName();
/* 1363 */     byte[] xmlReportData = reportImportInfo.getXmlReportData();
/* 1364 */     byte[] resources = reportImportInfo.getResources();


/*      */ 
/* 1368 */     if (reportName == null)
/*      */     {
/* 1370 */       throw new IllegalArgumentException("ReportName is required to import a report.");
/*      */     }
/*      */ 
/* 1373 */     if (xmlReportData == null)
/*      */     {
/* 1375 */       throw new IllegalArgumentException("Report does not seem to have anything.");
/*      */     }
/*      */ 
/* 1378 */     ArrayList reportParametersAll = new ArrayList();
/* 1379 */     ArrayList reportParameters = new ArrayList();
/* 1380 */     ArrayList reportLibraries = new ArrayList();

/*      */ 
/* 1383 */     ByteArrayInputStream reportInputStream = new ByteArrayInputStream(xmlReportData);
/* 1384 */     ByteArrayInputStream resourcesInputStream = null;
/*      */ 
/* 1386 */     if ((resources != null) && (reportImportInfo.isImportResourcesEnabled()))
/*      */     {
/* 1388 */       resourcesInputStream = new ByteArrayInputStream(resources);
/*      */     }
/*      */ 
/* 1391 */     ReportParameterInfo[] reportParams = null;
/* 1392 */     ReportLibraryInfo[] libraryInfoArray = null;
/* 1393 */     ReportLabelInfo[] labelInfoArray = null;
/* 1394 */     String includedResourceFileName = null;

/*      */     try
/*      */     {
/* 1398 */       ReportDesignTask designTask = ReportDesignTaskProvider.getReportDesignTask();
/* 1399 */       if (designTask == null)
/*      */       {
/* 1401 */         throw new IllegalStateException("BIRT Report Engine not initialized properly for this operation to work.");
/*      */       }
/*      */ 
/* 1404 */       if (designTask != null)
/*      */       {
/* 1406 */         String tempReportFolder = null;
/* 1407 */         String tempFolder = AdminServiceTempLocation.getTemporaryImportLocation();
/* 1408 */         String tempUniqueFolder = createUniqueTempFolder(tempFolder);
/* 1409 */         ReportDesign reportDesign = null;

/*      */         try
/*      */         {
/* 1413 */           tempReportFolder = tempFolder + File.separator + tempUniqueFolder;
/* 1414 */           copyReportFile(tempReportFolder, reportFileName, new String(xmlReportData, "UTF-8"), resourcesInputStream);
/*      */ 
/* 1416 */           Locale l = getLocaleByLangCode(userInfo);
/* 1417 */           reportDesign = designTask.openReportDesign(reportFileName, tempReportFolder, l);
/*      */ 
/* 1419 */           reportParams = reportDesign.getParameterInfo();
/* 1420 */           libraryInfoArray = reportDesign.getLibraryInfo();
/* 1421 */           includedResourceFileName = reportDesign.getIncludedResourceFileName();
/* 1422 */           labelInfoArray = getReportLabels(tempReportFolder, includedResourceFileName, userInfo.getLangCode());
/* 1423 */           String reportDesc = reportDesign.getDescription();
/* 1424 */           if (reportDesc != null)
/*      */           {
/* 1426 */             reportDescription = reportDesc;
/*      */           }
/*      */         }
/*      */         finally
/*      */         {
/* 1431 */           if (reportDesign != null)
/*      */           {
/* 1433 */             reportDesign.close();
/*      */           }
/*      */ 
/* 1436 */           deleteFolder(tempReportFolder);
/*      */         }
/*      */ 
/* 1439 */         if (reportParams != null)
/*      */         {
/* 1441 */           int noOfParams = reportParams.length;
/* 1442 */           for (int i = 0; i < noOfParams; ++i)
/*      */           {
/* 1444 */             String param = reportParams[i].getName();
/* 1445 */             reportParameters.add(param);
/* 1446 */             reportParametersAll.add(param);
/*      */ 
/* 1448 */             if (!(reportAdminServiceLogger.isDebugEnabled()))
/*      */               continue;
/* 1450 */             reportAdminServiceLogger.debug("[" + reportImportInfo.getName() + "] Report library parameter[" + i + "] = " + param);


/*      */           }
/*      */ 
/*      */         }
/* 1456 */         else if (reportAdminServiceLogger.isDebugEnabled())
/*      */         {
/* 1458 */           reportAdminServiceLogger.debug("[" + reportImportInfo.getName() + "] Report library has no parameters");

/*      */         }
/*      */ 
/* 1462 */         if (libraryInfoArray != null)
/*      */         {
/* 1464 */           int noOfLibraries = libraryInfoArray.length;
/* 1465 */           for (int i = 0; i < noOfLibraries; ++i)
/*      */           {
/* 1467 */             String libraryName = libraryInfoArray[i].getName();
/* 1468 */             reportLibraries.add(libraryInfoArray[i]);
/*      */ 
/* 1470 */             if (!(reportAdminServiceLogger.isDebugEnabled()))
/*      */               continue;
/* 1472 */             reportAdminServiceLogger.debug("[" + reportImportInfo.getName() + "] Report libray depends on library[" + i + "] = " + libraryName);


/*      */           }
/*      */ 
/*      */         }
/* 1478 */         else if (reportAdminServiceLogger.isDebugEnabled())
/*      */         {
/* 1480 */           reportAdminServiceLogger.debug("[" + reportImportInfo.getName() + "] Report library does not depend on any Libraries");
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 1487 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/* 1489 */         reportAdminServiceLogger.error(ex.getMessage(), ex);
/*      */       }
/*      */ 
/* 1492 */       throw new MXApplicationException("reports", "failedtoimport");


/*      */     }
/*      */ 
/* 1497 */     MboSetRemote reportLibrarySetRemote = getMboSet("REPORTDESIGN", userInfo);
/* 1498 */     reportLibrarySetRemote.setQbeExactMatch(true);
/*      */ 
/* 1500 */     int noOfLibraries = reportLibraries.size();
/* 1501 */     for (int i = 0; i < noOfLibraries; ++i)
/*      */     {
/* 1503 */       ReportLibraryInfo libraryInfo = (ReportLibraryInfo)reportLibraries.get(i);
/* 1504 */       reportLibrarySetRemote.setQbe("REPORTNAME", libraryInfo.getFileName());
/* 1505 */       reportLibrarySetRemote.setQbe("ISLIBRARY", "1");
/* 1506 */       reportLibrarySetRemote.reset();
/*      */ 
/* 1508 */       if (!(reportLibrarySetRemote.isEmpty()))
/*      */         continue;
/* 1510 */       throw new MXApplicationException("reports", "librarynotimported");







/*      */     }
/*      */ 
/* 1520 */     for (int i = 0; i < noOfLibraries; ++i)
/*      */     {
/* 1522 */       ReportLibraryInfo libraryInfo = (ReportLibraryInfo)reportLibraries.get(i);
/*      */ 
/* 1524 */       String libraryFileName = libraryInfo.getFileName();
/* 1525 */       addDependentLibraryParameters(userInfo, libraryFileName, reportParametersAll);




/*      */     }
/*      */ 
/* 1532 */     MboSetRemote reportDesignMboSet = getMboSet("REPORTDESIGN", userInfo);
/* 1533 */     reportDesignMboSet.setQbeExactMatch(true);
/* 1534 */     reportDesignMboSet.setQbe("REPORTNAME", reportName);
/*      */ 
/* 1536 */     MboRemote reportDesignMbo = reportDesignMboSet.getMbo(0);
/* 1537 */     if (reportDesignMbo == null)

/*      */     {
/* 1540 */       reportDesignMbo = reportDesignMboSet.add();
/* 1541 */       reportDesignMbo.setValue("REPORTNAME", reportName);
/* 1542 */       reportDesignMbo.setValue("REPORTFILENAME", reportFileName);

/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1548 */       reportDesignMbo.setValue("ISLIBRARY", true);
/* 1549 */       reportDesignMbo.setValue("DESCRIPTION", reportDescription);
/* 1550 */       reportDesignMbo.setValue("DESIGN", new String(xmlReportData, "UTF-8"));
/* 1551 */       reportDesignMbo.setValue("IMPORTEDBY", userInfo.getUserName());
/* 1552 */       reportDesignMbo.setValue("IMPORTEDDATE", MXServer.getMXServer().getDate());
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1556 */       throw new MXApplicationException("reports", "failedtosetvalue", new Object[] { reportName, reportImportInfo.getAppName() }, t);


/*      */     }
/*      */ 
/* 1561 */     if (reportImportInfo.isImportResourcesEnabled())
/*      */     {
/* 1563 */       reportDesignMbo.setValue("RESOURCES", resources);



/*      */     }
/*      */ 
/* 1569 */     MboSetRemote reportLibraryRefSetRemote = reportDesignMbo.getMboSet("REPORTDESIGN_DEPEND");
/* 1570 */     reportLibraryRefSetRemote.deleteAll();
/*      */ 
/* 1572 */     for (int j = 0; j < noOfLibraries; ++j)
/*      */     {
/* 1574 */       ReportLibraryInfo libraryInfo = (ReportLibraryInfo)reportLibraries.get(j);
/*      */ 
/* 1576 */       String libraryFileName = libraryInfo.getName();
/*      */ 
/* 1578 */       MboRemote reportLibraryRefRemote = reportLibraryRefSetRemote.add();
/*      */ 
/* 1580 */       reportLibraryRefRemote.setValue("REPORTNAME", reportName);
/* 1581 */       reportLibraryRefRemote.setValue("DEPREPORTNAME", libraryFileName);


/*      */     }
/*      */ 
/* 1586 */     MboSetRemote reportParamsSetRemote = reportDesignMbo.getMboSet("REPORTDESIGN_PARAM");
/* 1587 */     reportParamsSetRemote.deleteAll();
/* 1588 */     int noOfParams = reportParameters.size();
/*      */     int i;
/* 1590 */     for (int i = 0; i < noOfParams; ++i)
/*      */     {
/* 1592 */       String paramName = (String)reportParameters.get(i);
/*      */ 
/* 1594 */       MboRemote reportParamRemote = reportParamsSetRemote.add();
/*      */ 
/* 1596 */       reportParamRemote.setValue("REPORTNAME", reportName);
/* 1597 */       reportParamRemote.setValue("PARAMNAME", paramName);


/*      */     }
/*      */ 
/* 1602 */     if (reportImportInfo.isImportResourcesEnabled())

/*      */     {
/* 1605 */       String baseLangCode = getMaxVar().getString("BASELANGUAGE", "");
/*      */ 
/* 1607 */       MboSetRemote reportLabelSetRemote = reportDesignMbo.getMboSet("REPORTDESIGN_LABEL");
/*      */ 
/* 1609 */       if (labelInfoArray != null)


/*      */       {
/* 1613 */         if (labelInfoArray.length == 0)


/*      */         {
/* 1617 */           reportLabelSetRemote.deleteAll();
/*      */         }
/*      */         else
/*      */         {
/* 1621 */           ArrayList currentLabels = new ArrayList();
/* 1622 */           int noOfCurrentLabels = labelInfoArray.length;
/* 1623 */           for (int j = 0; j < noOfCurrentLabels; ++j)
/*      */           {
/* 1625 */             currentLabels.add(labelInfoArray[j].getKey());


/*      */           }
/*      */ 
/* 1630 */           HashMap existingLabelKeys = new HashMap();
/* 1631 */           ArrayList existingLabelIndexes = new ArrayList();
/* 1632 */           int i = 0;
/*      */           while (true)
/*      */           {
/* 1635 */             MboRemote reportLabelRemote = reportLabelSetRemote.getMbo(i);
/* 1636 */             if (reportLabelRemote == null)
/*      */             {
/*      */               break;
/*      */             }
/*      */ 
/* 1641 */             String labelKey = reportLabelRemote.getString("LABELKEY");
/* 1642 */             String labelValue = reportLabelRemote.getString("LABELVALUE");
/* 1643 */             existingLabelKeys.put(labelKey, labelValue);
/* 1644 */             existingLabelIndexes.add(labelKey);


/*      */ 
/* 1648 */             if (!(currentLabels.contains(labelKey)))
/*      */             {
/* 1650 */               reportLabelRemote.delete();
/*      */             }
/*      */ 
/* 1653 */             ++i;

/*      */           }
/*      */ 
/* 1657 */           for (int j = 0; j < noOfCurrentLabels; ++j)
/*      */           {
/* 1659 */             String currentLabelKey = labelInfoArray[j].getKey();
/*      */ 
/* 1661 */             Object obj = existingLabelKeys.get(currentLabelKey);
/*      */ 
/* 1663 */             if (obj != null)
/*      */             {
/* 1665 */               String valueInDB = (String)obj;
/* 1666 */               if (!(valueInDB.equals(labelInfoArray[j].getValue())))

/*      */               {
/* 1669 */                 int index = existingLabelIndexes.indexOf(currentLabelKey);
/* 1670 */                 MboRemote reportLabelRemote = reportLabelSetRemote.getMbo(index);
/* 1671 */                 reportLabelRemote.setValue("LABELVALUE", labelInfoArray[j].getValue());
/* 1672 */                 if (includedResourceFileName != null)
/*      */                 {
/* 1674 */                   reportLabelRemote.setValue("RESOURCENAME", includedResourceFileName + ".properties");
/*      */                 }
/*      */                 else
/*      */                 {
/* 1678 */                   reportLabelRemote.setValueNull("RESOURCENAME");
/*      */                 }
/* 1680 */                 reportLabelRemote.setValue("LANGCODE", baseLangCode);
/*      */               }
/*      */               else
/*      */               {
/* 1684 */                 int index = existingLabelIndexes.indexOf(currentLabelKey);
/* 1685 */                 MboRemote reportLabelRemote = reportLabelSetRemote.getMbo(index);
/* 1686 */                 String resourceNameInDB = reportLabelRemote.getString("RESOURCENAME");
/* 1687 */                 boolean resourceNameInDBNull = reportLabelRemote.isNull("RESOURCENAME");
/*      */ 
/* 1689 */                 if (includedResourceFileName != null)
/*      */                 {
/* 1691 */                   if ((!(resourceNameInDBNull)) && (!(resourceNameInDB.equals(includedResourceFileName + ".properties"))))


/*      */                   {
/* 1695 */                     reportLabelRemote.setValue("LABELVALUE", labelInfoArray[j].getValue());
/* 1696 */                     reportLabelRemote.setValue("RESOURCENAME", includedResourceFileName + ".properties");
/*      */                   }
/* 1698 */                   else if (resourceNameInDBNull)
/*      */                   {
/* 1700 */                     reportLabelRemote.setValue("LABELVALUE", labelInfoArray[j].getValue());
/* 1701 */                     reportLabelRemote.setValue("RESOURCENAME", includedResourceFileName + ".properties");

/*      */                   }
/*      */ 
/*      */                 }
/* 1706 */                 else if (!(resourceNameInDBNull))
/*      */                 {
/* 1708 */                   reportLabelRemote.setValueNull("RESOURCENAME");
/*      */                 }
/*      */ 
/* 1711 */                 reportLabelRemote.setValue("LANGCODE", baseLangCode);
/*      */               }
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1717 */               MboRemote reportLabelRemote = reportLabelSetRemote.add();
/* 1718 */               reportLabelRemote.setValue("REPORTNAME", reportName);
/* 1719 */               reportLabelRemote.setValue("LABELKEY", labelInfoArray[j].getKey());
/* 1720 */               reportLabelRemote.setValue("LABELVALUE", labelInfoArray[j].getValue());
/* 1721 */               reportLabelRemote.setValue("SIZEDYNAMIC", 0);
/* 1722 */               reportLabelRemote.setValue("USEATTRIBUTE", 0);
/* 1723 */               if (includedResourceFileName != null)
/*      */               {
/* 1725 */                 reportLabelRemote.setValue("RESOURCENAME", includedResourceFileName + ".properties");
/*      */               }
/*      */               else
/*      */               {
/* 1729 */                 reportLabelRemote.setValueNull("RESOURCENAME");
/*      */               }
/* 1731 */               reportLabelRemote.setValue("LANGCODE", baseLangCode);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1737 */     reportDesignMboSet.save();
/*      */ 
/* 1739 */     if (!(reportAdminServiceLogger.isInfoEnabled()))
/*      */       return;
/* 1741 */     reportAdminServiceLogger.info("Finished Importing Report Library: " + reportImportInfo.getName());
/*      */   }

/*      */   protected ReportLabelInfo[] getReportLabels(String tempFolderName, String resourceName, String langCode)
/*      */     throws Exception
/*      */   {
/* 1747 */     if (resourceName == null)
/*      */     {
/* 1749 */       return new ReportLabelInfo[0];
/*      */     }
/*      */ 
/* 1752 */     langCode = langCode.toLowerCase();
/* 1753 */     String propertiesFileName = resourceName + ".properties";
/* 1754 */     if ((langCode != null) && (!(langCode.equalsIgnoreCase("en"))))
/*      */     {
/* 1756 */       propertiesFileName = resourceName + "_" + langCode + ".properties";

/*      */     }
/*      */ 
/* 1760 */     File f = new File(tempFolderName + File.separator + propertiesFileName);
/* 1761 */     if (!(f.exists()))
/*      */     {
/* 1763 */       MXLogger reportAdminServiceLogger = getServiceLogger();
/*      */ 
/* 1765 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/* 1767 */         reportAdminServiceLogger.error("Failed to find properties file: " + f.getName() + ". Labels are not going to be imported.");
/*      */       }
/*      */ 
/* 1770 */       return null;


/*      */     }
/*      */ 
/* 1775 */     if ((langCode != null) && (langCode.equalsIgnoreCase("en")))
/*      */     {
/* 1777 */       String pf = resourceName + "_" + langCode + ".properties";
/* 1778 */       File f1 = new File(tempFolderName + File.separator + pf);
/* 1779 */       if (f1.exists())
/*      */       {
/* 1781 */         propertiesFileName = pf;
/*      */       }
/*      */     }
/*      */ 
/* 1785 */     Properties p = new Properties();
/*      */ 
/* 1787 */     FileInputStream fis = null;
/*      */     try
/*      */     {
/* 1790 */       fis = new FileInputStream(tempFolderName + File.separator + propertiesFileName);
/*      */ 
/* 1792 */       p.load(fis);
/*      */ 
/* 1794 */       Set keySet = p.keySet();
/* 1795 */       Iterator keyIterator = keySet.iterator();
/*      */ 
/* 1797 */       int noOfKeys = p.keySet().size();
/*      */ 
/* 1799 */       if (noOfKeys == 0)
/*      */       {
/* 1801 */         ReportLabelInfo[] arrayOfReportLabelInfo1 = new ReportLabelInfo[0];
/*      */         return arrayOfReportLabelInfo1;
/*      */       }
/* 1804 */       ReportLabelInfo[] labelInfoArray = new ReportLabelInfo[noOfKeys];
/*      */ 
/* 1806 */       int i = 0;
/* 1807 */       while (keyIterator.hasNext())
/*      */       {
/* 1809 */         keyName = (String)keyIterator.next();
/* 1810 */         ReportLabelInfo info = new ReportLabelInfo();
/* 1811 */         info.setKey(keyName);
/* 1812 */         info.setValue(p.getProperty(keyName));
/*      */ 
/* 1814 */         labelInfoArray[i] = info;
/* 1815 */         ++i;
/*      */       }
/*      */ 
/* 1818 */       String keyName = labelInfoArray;

/*      */     }
/*      */     finally
/*      */     {
/* 1823 */       if (fis != null)
/*      */ 
/*      */       {/* 1825 */       return keyName;/* 1825 */         fis.close();
/*      */       }
/*      */     }
/*      */   }










/*      */   private void addDependentLibraryParameters(UserInfo userInfo, String libraryFileName, Collection<String> reportParametersAll)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1842 */     MboSetRemote reportMboSetRemote = getMboSet("REPORTDESIGN", userInfo);
/* 1843 */     reportMboSetRemote.setQbeExactMatch(true);
/* 1844 */     reportMboSetRemote.setQbe("REPORTNAME", libraryFileName);
/*      */ 
/* 1846 */     MboRemote reportMboRemote = reportMboSetRemote.getMbo(0);
/*      */ 
/* 1848 */     MboSetRemote reportParamsMboSetRemote = reportMboRemote.getMboSet("REPORTDESIGN_PARAM");
/* 1849 */     int j = 0;
/*      */     while (true)
/*      */     {
/* 1852 */       MboRemote reportParamMboRemote = reportParamsMboSetRemote.getMbo(j);
/* 1853 */       if (reportParamMboRemote == null)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 1858 */       ++j;
/* 1859 */       String reportParamName = reportParamMboRemote.getString("PARAMNAME");
/* 1860 */       reportParametersAll.add(reportParamName);

/*      */     }
/*      */ 
/* 1864 */     MboSetRemote reportLibSetRemote = reportMboRemote.getMboSet("REPORTDESIGN_DEPEND");
/* 1865 */     int i = 0;
/*      */     while (true)
/*      */     {
/* 1868 */       MboRemote reportLibRemote = reportLibSetRemote.getMbo(i);
/* 1869 */       if (reportLibRemote == null)
/*      */       {
/*      */         return;
/*      */       }
/*      */ 
/* 1874 */       ++i;
/* 1875 */       String depLibraryName = reportLibRemote.getString("DEPREPORTNAME");
/* 1876 */       addDependentLibraryParameters(userInfo, depLibraryName, reportParametersAll);
/*      */     }
/*      */   }



















/*      */   public ReportRunInfo prepareReportForRun(UserInfo userInfo, String reportName, String appName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 1901 */     return prepareReportForRun(userInfo, reportName, appName, true); } 






























































































































































































































/*      */   private void copyFiles(String sourceFolderName, String destFolderName) throws IOException { File sourceFolder = new File(sourceFolderName);
/*      */ 
/* 2126 */     File[] list = sourceFolder.listFiles();
/* 2127 */     for (int i = 0; i < list.length; ++i)
/*      */     {
/* 2129 */       File f = list[i];
/* 2130 */       if (f.isDirectory())
/*      */       {
/* 2132 */         copyFiles(f.getAbsolutePath(), destFolderName + File.separator + f.getName());
/*      */       }
/*      */       else
/*      */       {
/* 2136 */         FileInputStream fis = new FileInputStream(f);
/*      */         try
/*      */         {
/* 2139 */           createFileFromStream(new File(destFolderName + File.separator + f.getName()), fis);
/*      */         }
/*      */         finally
/*      */         {
/* 2143 */           fis.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }









/*      */   public void cleanupReportResources(ReportRunInfo reportRunInfo)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2160 */     String tempRunFolderName = reportRunInfo.getTempRunFolder();
/*      */ 
/* 2162 */     boolean deleted = deleteFolder(tempRunFolderName);
/* 2163 */     if (deleted)
/*      */       return;
/* 2165 */     this.reportTempFolderCleanupManager.tobeDeletedFolders.put(tempRunFolderName, tempRunFolderName);
/*      */   }
















/*      */   protected ReportRunInfo prepareReportForExport(UserInfo userInfo, String reportName, String appName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2186 */     MboSetRemote reportSetRemote = getMboSet("REPORT", userInfo);
/* 2187 */     reportSetRemote.setQbeExactMatch(true);
/* 2188 */     reportSetRemote.setQbe("REPORTNAME", reportName);
/* 2189 */     reportSetRemote.setQbe("APPNAME", appName);
/*      */ 
/* 2191 */     MboRemote reportRemote = reportSetRemote.getMbo(0);
/* 2192 */     if (reportRemote == null)
/*      */     {
/* 2194 */       throw new MXApplicationException("reports", "notfound", new Object[] { reportName, appName });
/*      */     }
/*      */ 
/* 2197 */     ReportRunInfo reportRunInfo = prepareReportDesignForRun(userInfo, reportName, false);
/* 2198 */     reportRunInfo.setAppName(appName);
/* 2199 */     return reportRunInfo;
/*      */   }













/*      */   public ReportRunInfo prepareReportLibraryForExport(UserInfo userInfo, String reportName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2217 */     ReportRunInfo reportRunInfo = prepareReportDesignForRun(userInfo, reportName, false);
/* 2218 */     return reportRunInfo;
/*      */   }














/*      */   public ReportRunInfo prepareReportDesignForRun(UserInfo userInfo, String reportName, boolean extractAll)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2237 */     MXLogger reportAdminServiceLogger = getServiceLogger();
/*      */ 
/* 2239 */     String tempReportFolderPath = null;
/*      */     try
/*      */     {
/* 2242 */       String tempRunFolder = ReportRuntimeTempLocation.getReportsLocation();
/* 2243 */       String uniqueFolder = createUniqueTempFolder(tempRunFolder);
/*      */ 
/* 2245 */       String tempReportFolder = "birtreport";
/* 2246 */       String tempReportRelativePath = uniqueFolder + File.separator + tempReportFolder;
/*      */ 
/* 2248 */       tempReportFolderPath = tempRunFolder + File.separator + tempReportRelativePath;
/* 2249 */       File fRun = new File(tempReportFolderPath);
/* 2250 */       fRun.mkdirs();
/*      */ 
/* 2252 */       if (reportAdminServiceLogger.isDebugEnabled())
/*      */       {
/* 2254 */         reportAdminServiceLogger.debug("Extracting report into a temporary folder: " + tempReportFolderPath);
/*      */       }
/*      */ 
/* 2257 */       String outputFolderName = "_output";
/* 2258 */       String tempOutRelativePath = uniqueFolder + File.separator + outputFolderName;
/*      */ 
/* 2260 */       String tempOutputFolderPath = tempRunFolder + File.separator + tempOutRelativePath;
/* 2261 */       File fOut = new File(tempOutputFolderPath);
/* 2262 */       fOut.mkdirs();

/*      */ 
/* 2265 */       extractReport(userInfo, reportName, tempReportFolderPath, extractAll);

/*      */ 
/* 2268 */       localizeLabelsForRun(userInfo, reportName, tempReportFolderPath, extractAll);
/*      */ 
/* 2270 */       ReportRunInfo reportRunInfo = new ReportRunInfo();
/* 2271 */       reportRunInfo.setReportName(reportName);
/* 2272 */       reportRunInfo.setReportRelativePath(tempReportRelativePath);
/* 2273 */       reportRunInfo.setReportFolderName(tempReportFolder);
/* 2274 */       reportRunInfo.setReportOutputFolderName(outputFolderName);
/* 2275 */       reportRunInfo.setTempRunFolder(tempRunFolder + File.separator + uniqueFolder);
/*      */ 
/* 2277 */       return reportRunInfo;

/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 2282 */       if (tempReportFolderPath != null)
/*      */       {
/* 2284 */         deleteFolder(tempReportFolderPath);
/*      */       }
/*      */ 
/* 2287 */       throw new MXApplicationException("reports", "failedtopreparereport", new Object[] { reportName }, ex);
/*      */     }
/*      */   }

/*      */   protected void localizeLabelsForRun(UserInfo userInfo, String reportName, String tempReportFolderPath, boolean extractAll) throws Exception {
/* 2292 */     ReportDesignTask designTask = ReportDesignTaskProvider.getReportDesignTask();
/* 2293 */     if (designTask == null)
/*      */     {
/* 2295 */       throw new IllegalStateException("BIRT Report Engine not initialized properly for this operation to work.");
/*      */     }
/*      */ 
/* 2298 */     if (designTask == null)
/*      */       return;
/* 2300 */     ReportDesign reportDesign = null;
/* 2301 */     String resourceFileName = null;

/*      */     try
/*      */     {
/* 2305 */       Locale l = getLocaleByLangCode(userInfo);
/* 2306 */       reportDesign = designTask.openReportDesign(reportName, tempReportFolderPath, l);
/*      */ 
/* 2308 */       resourceFileName = reportDesign.getIncludedResourceFileName();
/*      */     }
/*      */     finally
/*      */     {
/* 2312 */       if (reportDesign != null)
/*      */       {
/* 2314 */         reportDesign.close();
/*      */       }
/*      */     }
/*      */ 
/* 2318 */     if (resourceFileName != null)
/*      */     {
/* 2320 */       FileOutputStream fos = null;

/*      */       try
/*      */       {
/* 2324 */         File fR = new File(tempReportFolderPath);
/* 2325 */         File[] propertiesFiles = fR.listFiles(new PropertiesFileFilter(resourceFileName));
/* 2326 */         for (int i = 0; i < propertiesFiles.length; ++i)
/*      */         {
/* 2328 */           File propertyFile = propertiesFiles[i];
/* 2329 */           propertyFile.delete();
/*      */         }
/*      */ 
/* 2332 */         String langCode = userInfo.getLangCode().toLowerCase();
/* 2333 */         String propertiesFileName = null;

/*      */ 
/* 2336 */         propertiesFileName = tempReportFolderPath + File.separator + resourceFileName + ".properties";





/*      */ 
/* 2343 */         fos = new FileOutputStream(propertiesFileName);



/*      */ 
/* 2348 */         HashMap reportLabelsMap = getReportLabelsFromDB(userInfo, reportName);
/* 2349 */         Properties newP = new Properties();
/* 2350 */         Iterator keyIterator = reportLabelsMap.keySet().iterator();
/* 2351 */         while (keyIterator.hasNext())
/*      */         {
/* 2353 */           String labelKey = (String)keyIterator.next();
/* 2354 */           String labelValue = (String)reportLabelsMap.get(labelKey);
/* 2355 */           newP.put(labelKey, labelValue);
/*      */         }
/* 2357 */         newP.store(fos, null);
/*      */       }
/*      */       finally
/*      */       {
/* 2361 */         if (fos != null)
/*      */         {
/* 2363 */           fos.flush();
/* 2364 */           fos.close();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2371 */     if (!(extractAll))
/*      */       return;
/* 2373 */     MboSetRemote reportRefsSetRemote = getMboSet("REPORTDEPEND", userInfo);
/* 2374 */     reportRefsSetRemote.setQbeExactMatch(true);
/* 2375 */     reportRefsSetRemote.setQbe("REPORTNAME", reportName);
/*      */ 
/* 2377 */     MboRemote reportRefsRemote = null;
/*      */ 
/* 2379 */     int i = 0;
/*      */     while (true)
/*      */     {
/* 2382 */       reportRefsRemote = reportRefsSetRemote.getMbo(i);
/* 2383 */       if (reportRefsRemote == null)
/*      */       {
/*      */         return;
/*      */       }
/*      */ 
/* 2388 */       String refReportName = reportRefsRemote.getString("DEPREPORTNAME");
/* 2389 */       localizeLabelsForRun(userInfo, refReportName, tempReportFolderPath, extractAll);
/* 2390 */       ++i;
/*      */     }
/*      */   }



/*      */   protected HashMap<String, String> getReportLabelsFromDB(UserInfo userInfo, String reportName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2399 */     MboSetRemote reportLabelSetRemote = getMboSet("REPORTLABEL", userInfo);
/* 2400 */     reportLabelSetRemote.setQbeExactMatch(true);
/* 2401 */     reportLabelSetRemote.setQbe("REPORTNAME", reportName);
/*      */ 
/* 2403 */     HashMap reportLabelInfoMap = new HashMap();
/*      */ 
/* 2405 */     int i = 0;
/*      */     while (true)
/*      */     {
/* 2408 */       MboRemote reportLabelRemote = reportLabelSetRemote.getMbo(i);
/* 2409 */       if (reportLabelRemote == null)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 2414 */       String labelKey = reportLabelRemote.getString("LABELKEY");
/* 2415 */       String labelValue = reportLabelRemote.getString("LABELVALUE");
/*      */ 
/* 2417 */       reportLabelInfoMap.put(labelKey, labelValue);
/* 2418 */       ++i;
/*      */     }
/*      */ 
/* 2421 */     return reportLabelInfoMap;
/*      */   }




/*      */   public static String createUniqueTempFolder(String parentFolderName)
/*      */   {
/* 2429 */     String uniqueTempFolder = null;
/*      */ 
/* 2431 */     synchronized (tempFolderLockObj)
/*      */     {
/* 2433 */       long curTime = System.currentTimeMillis();
/*      */ 
/* 2435 */       int noOfAttempts = 0;

/*      */       while (true)
/*      */       {
/* 2439 */         String folderToCheck = parentFolderName + File.separator + curTime;
/* 2440 */         File f = new File(folderToCheck);
/* 2441 */         if (!(f.exists()))
/*      */         {
/* 2443 */           f.mkdirs();
/* 2444 */           uniqueTempFolder = "" + curTime;
/* 2445 */           break;
/*      */         }
/*      */ 
/* 2448 */         curTime += 1L;
/* 2449 */         ++noOfAttempts;
/* 2450 */         if (noOfAttempts > 1000) {
/*      */           break;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2457 */     return uniqueTempFolder;
/*      */   }



/*      */   private void extractReport(UserInfo userInfo, String reportName, String tempReportFolder, boolean extractAll)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2465 */     MboSetRemote reportDesignSetRemote = getMboSet("REPORTDESIGN", userInfo);
/* 2466 */     reportDesignSetRemote.setQbeExactMatch(true);
/* 2467 */     reportDesignSetRemote.setQbe("REPORTNAME", reportName);
/*      */ 
/* 2469 */     MboRemote reportDesignRemote = reportDesignSetRemote.getMbo(0);
/* 2470 */     if (reportDesignRemote == null)
/*      */     {
/* 2472 */       return;
/*      */     }
/*      */ 
/* 2475 */     String reportContent = reportDesignRemote.getString("DESIGN");
/* 2476 */     byte[] resources = reportDesignRemote.getBytes("RESOURCES");


/*      */     try
/*      */     {
/* 2481 */       FileOutputStream fos = new FileOutputStream(tempReportFolder + File.separator + reportName);
/* 2482 */       PrintWriter pw = new PrintWriter(new OutputStreamWriter(fos, "UTF-8"));
/* 2483 */       pw.print(reportContent);
/* 2484 */       pw.close();
/*      */ 
/* 2486 */       if ((resources != null) && (resources.length > 0))

/*      */       {
/* 2489 */         FileOutputStream fos1 = new FileOutputStream(tempReportFolder + File.separator + reportName + ".zip");
/* 2490 */         fos1.write(resources);
/* 2491 */         fos1.close();
/*      */ 
/* 2493 */         File zipFile = new File(tempReportFolder + File.separator + reportName + ".zip");
/* 2494 */         extractResources(zipFile, tempReportFolder);

/*      */ 
/* 2497 */         zipFile.delete();
/*      */       }
/*      */ 
/* 2500 */       if (extractAll)
/*      */       {
/* 2502 */         extractLibrary(userInfo, reportName, tempReportFolder);
/*      */       }
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 2507 */       throw new MXApplicationException("reports", "failedtoextractreport", new Object[] { reportName }, e);
/*      */     }
/*      */   }




/*      */   private void extractLibrary(UserInfo userInfo, String reportName, String tempReportFolder)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2517 */     MboSetRemote reportRefsSetRemote = getMboSet("REPORTDEPEND", userInfo);
/* 2518 */     reportRefsSetRemote.setQbeExactMatch(true);
/* 2519 */     reportRefsSetRemote.setQbe("REPORTNAME", reportName);
/*      */ 
/* 2521 */     MboRemote reportRefsRemote = null;
/*      */ 
/* 2523 */     int i = 0;
/*      */     while (true)
/*      */     {
/* 2526 */       reportRefsRemote = reportRefsSetRemote.getMbo(i);
/* 2527 */       if (reportRefsRemote == null)
/*      */       {
/*      */         return;
/*      */       }
/*      */ 
/* 2532 */       String refReportName = reportRefsRemote.getString("DEPREPORTNAME");
/* 2533 */       extractReport(userInfo, refReportName, tempReportFolder, true);
/* 2534 */       ++i;
/*      */     }
/*      */   }

/*      */   private void extractResources(File resourcesZipFile, String reportFolder)
/*      */     throws IOException
/*      */   {
/* 2541 */     ZipFile zFile = new ZipFile(resourcesZipFile);
/* 2542 */     Enumeration zipEnum = zFile.entries();
/*      */ 
/* 2544 */     String outputFolder = reportFolder;
/* 2545 */     while (zipEnum.hasMoreElements())
/*      */     {
/* 2547 */       ZipEntry zipEntry = (ZipEntry)zipEnum.nextElement();
/* 2548 */       InputStream zipEntryInputStream = zFile.getInputStream(zipEntry);
/*      */ 
/* 2550 */       String zipEntryName = zipEntry.getName();
/* 2551 */       boolean isDir = zipEntry.isDirectory();
/*      */ 
/* 2553 */       if (isDir)
/*      */       {
/* 2555 */         File f = new File(outputFolder + File.separator + zipEntryName);
/* 2556 */         f.mkdirs();
/*      */       }
/*      */       else
/*      */       {
/* 2560 */         File f = new File(outputFolder + File.separator + zipEntryName);
/* 2561 */         f.getParentFile().mkdirs();
/*      */ 
/* 2563 */         createFileFromStream(f, zipEntryInputStream);
/*      */       }
/*      */     }
/*      */ 
/* 2567 */     zFile.close();
/*      */   }

/*      */   private void createFileFromStream(File file, InputStream inputStream)
/*      */     throws IOException
/*      */   {
/* 2573 */     FileOutputStream fos = new FileOutputStream(file);
/*      */ 
/* 2575 */     byte[] buf = new byte[1024];
/*      */     while (true)
/*      */     {
/* 2578 */       int bytesRead = inputStream.read(buf);
/* 2579 */       if (bytesRead <= 0) {
/*      */         break;
/*      */       }
/*      */ 
/* 2583 */       fos.write(buf, 0, bytesRead);
/*      */     }
/*      */ 
/* 2586 */     fos.flush();
/* 2587 */     fos.close(); } 




























































/*      */   public String getExportReportFolder(UserInfo userInfo, String reportName, String appName) throws MXException, RemoteException { MboSetRemote reportSetRemote = getMboSet("REPORT", userInfo);
/* 2649 */     reportSetRemote.setQbeExactMatch(true);
/* 2650 */     reportSetRemote.setQbe("REPORTNAME", reportName);
/* 2651 */     reportSetRemote.setQbe("APPNAME", appName);
/*      */ 
/* 2653 */     MboRemote reportRemote = reportSetRemote.getMbo(0);
/* 2654 */     if (reportRemote == null)
/*      */     {
/* 2656 */       throw new MXApplicationException("reports", "notfound", new Object[] { reportName, appName });
/*      */     }
/*      */ 
/* 2659 */     return reportRemote.getString("REPORTFOLDER"); } 

























































/*      */   public ArrayList<String> getReportLibraryNameList(UserInfo userInfo) throws MXException, RemoteException { MboSetRemote reportDesignMboSet = getMboSet("REPORTDESIGN", userInfo);
/* 2718 */     reportDesignMboSet.setFlag(39L, true);
/* 2719 */     reportDesignMboSet.setQbeExactMatch(true);
/* 2720 */     reportDesignMboSet.setQbe("ISLIBRARY", "true");
/* 2721 */     reportDesignMboSet.reset();
/*      */ 
/* 2723 */     ArrayList libraryNameList = new ArrayList();
/* 2724 */     int i = 0;
/*      */     while (true)
/*      */     {
/* 2727 */       MboRemote reportDesignMbo = reportDesignMboSet.getMbo(i);
/* 2728 */       if (reportDesignMbo == null)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 2733 */       libraryNameList.add(reportDesignMbo.getString("REPORTNAME"));
/* 2734 */       ++i;
/*      */     }
/*      */ 
/* 2737 */     return libraryNameList;
/*      */   }











/*      */   public TreeMap<String, List> getReportNameList(UserInfo userInfo)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2753 */     return getReportNameList(userInfo, 2);
/*      */   }












/*      */   public TreeMap<String, List> getReportNameList(UserInfo userInfo, int reportType)
/*      */     throws MXException, RemoteException
/*      */   {
/* 2770 */     MboSetRemote reportMboSet = getMboSet("REPORT", userInfo);
/* 2771 */     reportMboSet.setFlag(39L, true);
/* 2772 */     reportMboSet.setQbeExactMatch(true);
/* 2773 */     String runType = MXServer.getMXServer().getMaximoDD().getTranslator().toExternalDefaultValue("REPORTTYPES", "BIRT", null);
/* 2774 */     reportMboSet.setQbe("RUNTYPE", runType);
/*      */ 
/* 2776 */     if (reportType == 0)
/*      */     {
/* 2778 */       reportMboSet.setQbe("USERID", "~NULL~");
/*      */     }
/* 2780 */     else if (reportType == 1)
/*      */     {
/* 2782 */       reportMboSet.setQbe("USERID", "!=~NULL~");
/*      */     }
/*      */ 
/* 2785 */     reportMboSet.setOrderBy("APPNAME ASC");
/* 2786 */     reportMboSet.reset();
/*      */ 
/* 2788 */     TreeMap reportsByApp = new TreeMap();
/* 2789 */     int i = 0;
/*      */     while (true)
/*      */     {
/* 2792 */       MboRemote reportMbo = reportMboSet.getMbo(i);
/* 2793 */       if (reportMbo == null)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 2798 */       String appName = reportMbo.getString("APPNAME");
/* 2799 */       String reportName = reportMbo.getString("REPORTNAME");
/*      */ 
/* 2801 */       ArrayList reportNames = null;
/* 2802 */       reportNames = (ArrayList)reportsByApp.get(appName);
/*      */ 
/* 2804 */       if (reportNames == null)
/*      */       {
/* 2806 */         reportNames = new ArrayList();
/* 2807 */         reportsByApp.put(appName, reportNames);
/*      */       }
/* 2809 */       reportNames.add(reportName);
/*      */ 
/* 2811 */       ++i;
/*      */     }
/*      */ 
/* 2814 */     return reportsByApp;
/*      */   }

/*      */   public String getDateFormat(UserInfo userInfo) throws Exception
/*      */   {
/* 2819 */     String langCode = userInfo.getLangCode();
/* 2820 */     Locale locale = userInfo.getLocale();
/*      */ 
/* 2822 */     String dateFormat = getMXServer().getProperty("setting.DISPLAYDATE", langCode);
/* 2823 */     if ((dateFormat == null) || (dateFormat.equals("")))
/*      */     {
/* 2825 */       dateFormat = ((SimpleDateFormat)DateFormat.getDateInstance(3, locale)).toPattern();
/*      */     }
/*      */ 
/* 2828 */     return dateFormat;
/*      */   }

/*      */   public String getTimeFormat(UserInfo userInfo) throws Exception
/*      */   {
/* 2833 */     String langCode = userInfo.getLangCode();
/* 2834 */     Locale locale = userInfo.getLocale();
/*      */ 
/* 2836 */     String timeFormat = getMXServer().getProperty("setting.PARSETIME", langCode);
/*      */ 
/* 2838 */     if ((timeFormat == null) || (timeFormat.equals("")))
/*      */     {
/* 2840 */       timeFormat = ((SimpleDateFormat)DateFormat.getTimeInstance(2, locale)).toPattern();
/*      */     }
/*      */ 
/* 2843 */     return timeFormat;
/*      */   }

/*      */   public String getDateTimeFormat(UserInfo userInfo) throws Exception
/*      */   {
/* 2848 */     String langCode = userInfo.getLangCode();
/* 2849 */     Locale locale = userInfo.getLocale();
/*      */ 
/* 2851 */     String dateFormat = getMXServer().getProperty("setting.DISPLAYDATE", langCode);
/* 2852 */     String timeFormat = getMXServer().getProperty("setting.PARSETIME", langCode);
/*      */ 
/* 2854 */     if ((dateFormat == null) || (dateFormat.equals("")))
/*      */     {
/* 2856 */       dateFormat = ((SimpleDateFormat)DateFormat.getDateInstance(3, locale)).toPattern();
/*      */     }
/*      */ 
/* 2859 */     if ((timeFormat == null) || (timeFormat.equals("")))
/*      */     {
/* 2861 */       timeFormat = ((SimpleDateFormat)DateFormat.getTimeInstance(3, locale)).toPattern();
/*      */     }
/*      */ 
/* 2864 */     String dateTimeFormat = dateFormat + " " + timeFormat;
/*      */ 
/* 2866 */     return dateTimeFormat;
/*      */   }

/*      */   public String getDateTimeFormat(UserInfo userInfo, String objectName, String attributeName) throws Exception
/*      */   {
/* 2871 */     MboSetInfo msInfo = getMXServer().getMaximoDD().getMboSetInfo(objectName);

/*      */ 
/* 2874 */     int index = attributeName.indexOf(46);
/* 2875 */     if (index != -1)
/*      */     {
/* 2877 */       String relationshipName = attributeName.substring(0, index).toUpperCase();
/*      */ 
/* 2879 */       RelationInfo rsInfo = msInfo.getRelationInfo(relationshipName);
/* 2880 */       String childObject = rsInfo.getDest();
/* 2881 */       String childAttribute = attributeName.substring(index + 1);
/*      */ 
/* 2883 */       return getDateTimeFormat(userInfo, childObject, childAttribute);

/*      */     }
/*      */ 
/* 2887 */     MboValueInfo mvInfo = msInfo.getMboValueInfo(attributeName);
/* 2888 */     int dataType = mvInfo.getTypeAsInt();
/*      */ 
/* 2890 */     switch (dataType)
/*      */     {
/*      */     case 3:
/* 2893 */       return getDateFormat(userInfo);
/*      */     case 4:
/* 2895 */       return getDateTimeFormat(userInfo);
/*      */     case 5:
/* 2897 */       return getTimeFormat(userInfo);
/*      */     }
/*      */ 
/* 2900 */     throw new Exception("getDateTimeFormat called for incorrect attribute.");
/*      */   }


/*      */   public String getNumberFormat(UserInfo userInfo)
/*      */     throws Exception
/*      */   {
/* 2907 */     NumberFormat f = NumberFormat.getInstance(userInfo.getLocale());
/*      */ 
/* 2909 */     if (f instanceof DecimalFormat)
/*      */     {
/* 2911 */       DecimalFormat df = (DecimalFormat)f;
/*      */ 
/* 2913 */       String numberFormat = df.toLocalizedPattern();
/*      */ 
/* 2915 */       return numberFormat;

/*      */     }
/*      */ 
/* 2919 */     throw new Exception("getNumberFormat failed to determine the format.");
/*      */   }

/*      */   public String getDecimalFormat(UserInfo userInfo, int fractionDigits) throws Exception
/*      */   {
/* 2924 */     NumberFormat f = NumberFormat.getInstance(userInfo.getLocale());
/*      */ 
/* 2926 */     if (f instanceof DecimalFormat)
/*      */     {
/* 2928 */       DecimalFormat df = (DecimalFormat)f;
/*      */ 
/* 2930 */       df.setMaximumFractionDigits(fractionDigits);
/*      */ 
/* 2932 */       String numberFormat = df.toLocalizedPattern();
/*      */ 
/* 2934 */       return numberFormat;

/*      */     }
/*      */ 
/* 2938 */     throw new Exception("getDecimalFormat failed to determine the format.");
/*      */   }

/*      */   public String getNumberFormat(UserInfo userInfo, String objectName, String attributeName) throws Exception
/*      */   {
/* 2943 */     MboSetInfo msInfo = getMXServer().getMaximoDD().getMboSetInfo(objectName);

/*      */ 
/* 2946 */     int index = attributeName.indexOf(46);
/* 2947 */     if (index != -1)
/*      */     {
/* 2949 */       String relationshipName = attributeName.substring(0, index).toUpperCase();
/*      */ 
/* 2951 */       RelationInfo rsInfo = msInfo.getRelationInfo(relationshipName);
/* 2952 */       String childObject = rsInfo.getDest();
/* 2953 */       String childAttribute = attributeName.substring(index + 1);
/*      */ 
/* 2955 */       return getNumberFormat(userInfo, childObject, childAttribute);

/*      */     }
/*      */ 
/* 2959 */     MboValueInfo mvInfo = msInfo.getMboValueInfo(attributeName);
/* 2960 */     int dataType = mvInfo.getTypeAsInt();
/* 2961 */     switch (dataType)
/*      */     {
/*      */     case 6:
/*      */     case 7:
/* 2965 */       return getNumberFormat(userInfo);
/*      */     case 8:
/*      */     case 9:
/* 2968 */       return getDecimalFormat(userInfo, mvInfo.getScale());
/*      */     case 10:
/*      */     case 11:
/* 2971 */       throw new Exception("getNumberFormat called for incorrect attribute [" + attributeName + "]");
/*      */     }
/*      */ 
/* 2974 */     throw new Exception("getNumberFormat called for incorrect attribute [" + attributeName + "]");
/*      */   }























/*      */   public byte[] runReport(UserInfo userInfo, String reportName, String appName, ReportParameterData parameterData, String outputFileName, String outputFormat)
/*      */     throws MXException, RemoteException
/*      */   {
/* 3002 */     return runReport(userInfo, reportName, appName, parameterData, outputFileName, outputFormat, null); } 



































































































/*      */   protected void checkAuthorizationToRunReport(UserInfo userInfo, String reportName, String appName) throws MXException, RemoteException { if (isAuthorizedToRunReport(userInfo, reportName, appName))
/*      */       return;
/* 3104 */     throw new MXApplicationException("reports", "unauthorized");
/*      */   }











/*      */   public void createReportUsageLog(UserInfo userInfo, ReportUsageLogInfo usageLogInfo)
/*      */     throws MXException, RemoteException
/*      */   {
/* 3120 */     if (!(usageLogInfo.isReportExecuted()))
/*      */     {
/* 3122 */       return;
/*      */     }
/*      */ 
/* 3125 */     MboSetRemote usageLogSet = null;
/*      */     try
/*      */     {
/* 3128 */       usageLogSet = MXServer.getMXServer().getMboSet("REPORTUSAGELOG", userInfo);
/* 3129 */       MboRemote usageLog = usageLogSet.add();
/*      */ 
/* 3131 */       usageLog.setValue("APPNAME", usageLogInfo.getAppName());
/* 3132 */       usageLog.setValue("REPORTNAME", usageLogInfo.getReportName());
/* 3133 */       usageLog.setValue("ENTERDATE", usageLogInfo.getEnterDate());
/* 3134 */       usageLog.setValue("IMMEDIATEJOB", usageLogInfo.isImmediateJob());
/* 3135 */       usageLog.setValue("STARTDATE", usageLogInfo.getStartDate());
/* 3136 */       usageLog.setValue("ENDDATE", usageLogInfo.getEndDate());
/* 3137 */       usageLog.setValue("RUNTIME", usageLogInfo.getRuntime());
/* 3138 */       usageLog.setValue("SUCCESS", usageLogInfo.isSuccess());
/* 3139 */       usageLog.setValue("USERID", usageLogInfo.getUserId());
/* 3140 */       usageLog.setValue("HOSTNAME", usageLogInfo.getHostName());
/* 3141 */       usageLog.setValue("SERVERNAME", usageLogInfo.getServerName());
/* 3142 */       usageLog.setValue("ISTRANSIENT", usageLogInfo.isTransientReport());
/* 3143 */       usageLog.setValue("CANCELJOB", usageLogInfo.isCancelled());
/* 3144 */       usageLog.setValue("EMAILFILETYPE", usageLogInfo.getEmailFileType());
/*      */ 
/* 3146 */       MboSetRemote reportSet = usageLog.getMboSet("REPORT");
/* 3147 */       MboRemote report = reportSet.getMbo(0);
/* 3148 */       if (report != null)
/*      */       {
/* 3150 */         report.setValue("LASTRUNDATE", usageLogInfo.getEnterDate());
/* 3151 */         report.setValue("LASTRUNBY", usageLogInfo.getUserId());
/* 3152 */         report.setValue("LASTRUNDURATION", ReportUtil.toHourMinSecFromMiliSec(usageLogInfo.getRuntime()));
/*      */       }
/*      */ 
/* 3155 */       usageLogSet.save();
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 3159 */       MXLogger reportAdminServiceLogger = getServiceLogger();
/*      */ 
/* 3161 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/* 3163 */         reportAdminServiceLogger.error("Failed to write usage log.", t);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try {
/* 3169 */         if (usageLogSet != null)
/*      */         {
/* 3171 */           usageLogSet.reset();
/*      */         }
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*      */       }
/*      */     }
/*      */   }







/*      */   public boolean isOverloaded()
/*      */     throws MXException, RemoteException
/*      */   {
/* 3189 */     ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();
/*      */ 
/* 3191 */     return atmgr.isOverloaded();
/*      */   }











/*      */   public int getReportEngineState()
/*      */     throws MXException, RemoteException
/*      */   {
/* 3207 */     ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();

/*      */ 
/* 3210 */     if (atmgr.getMaxAllowedActiveReportThreads() < 1)
/*      */     {
/* 3212 */       return 1;
/*      */     }
/*      */ 
/* 3215 */     if (atmgr.isOverloaded())
/*      */     {
/* 3217 */       return 2;
/*      */     }
/*      */ 
/* 3220 */     return 0;
/*      */   }

















/*      */   public Long addActiveThread(String threadName, String reportName, String appName, String userName, boolean scheduledJob)
/*      */     throws MXException, RemoteException
/*      */   {
/* 3242 */     ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();
/*      */ 
/* 3244 */     return atmgr.addActiveThread(threadName, reportName, appName, userName, scheduledJob);
/*      */   }










/*      */   public void removeActiveThread(String threadName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 3259 */     ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();
/*      */ 
/* 3261 */     atmgr.removeActiveThread(threadName);
/*      */   }









/*      */   public void renewActiveThread(String threadName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 3275 */     ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();
/*      */ 
/* 3277 */     atmgr.renewActiveThread(threadName);
/*      */   }

/*      */   private byte[] createReportOutputData(String fileName)
/*      */     throws IOException
/*      */   {
/* 3283 */     int BUFFER_SIZE = 2048;
/* 3284 */     byte[] data = new byte[BUFFER_SIZE];
/*      */ 
/* 3286 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*      */ 
/* 3288 */     FileInputStream fis = new FileInputStream(fileName);
/* 3289 */     BufferedInputStream origin = new BufferedInputStream(fis, BUFFER_SIZE);

/*      */ 
/* 3292 */     while ((count = origin.read(data, 0, BUFFER_SIZE)) != -1)
/*      */     {/*      */       int count;
/* 3294 */       bos.write(data, 0, count);
/*      */     }
/*      */ 
/* 3297 */     origin.close();
/*      */ 
/* 3299 */     bos.flush();
/*      */ 
/* 3301 */     return bos.toByteArray();
/*      */   }

/*      */   private byte[] createZipData(String folderName) throws IOException
/*      */   {
/* 3306 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 3307 */     ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(bos));
/*      */ 
/* 3309 */     createZipEntry(null, folderName, out);
/*      */ 
/* 3311 */     out.flush();
/* 3312 */     out.finish();
/* 3313 */     out.close();
/*      */ 
/* 3315 */     return bos.toByteArray();
/*      */   }

/*      */   private void createZipEntry(String entryName, String folderName, ZipOutputStream out)
/*      */     throws IOException
/*      */   {
/* 3321 */     MXLogger reportAdminServiceLogger = getServiceLogger();
/*      */ 
/* 3323 */     int BUFFER_SIZE = 2048;
/*      */ 
/* 3325 */     byte[] data = new byte[BUFFER_SIZE];
/* 3326 */     File f = new File(folderName);
/* 3327 */     File[] fileNames = f.listFiles();
/*      */ 
/* 3329 */     String zipEntryName = "";
/* 3330 */     if (entryName != null)
/*      */     {
/* 3332 */       zipEntryName = entryName + "/";
/*      */     }
/*      */ 
/* 3335 */     int noOfFiles = fileNames.length;
/*      */ 
/* 3337 */     if (noOfFiles == 0)
/*      */     {
/* 3339 */       if (reportAdminServiceLogger.isDebugEnabled())
/*      */       {
/* 3341 */         reportAdminServiceLogger.debug("*** createZipEntry adding(emptydir) .... " + zipEntryName);
/*      */       }
/*      */ 
/* 3344 */       ZipEntry entry = new ZipEntry(zipEntryName);
/* 3345 */       out.putNextEntry(entry);
/*      */ 
/* 3347 */       return;
/*      */     }
/*      */ 
/* 3350 */     for (int i = 0; i < noOfFiles; ++i)
/*      */     {
/* 3352 */       if (fileNames[i].isDirectory())
/*      */       {
/* 3354 */         if (entryName == null)
/*      */         {
/* 3356 */           createZipEntry(fileNames[i].getName(), fileNames[i].getAbsolutePath(), out);
/*      */         }
/*      */         else
/*      */         {
/* 3360 */           createZipEntry(zipEntryName + fileNames[i].getName(), fileNames[i].getAbsolutePath(), out);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 3365 */         if (reportAdminServiceLogger.isDebugEnabled())
/*      */         {
/* 3367 */           reportAdminServiceLogger.debug("*** createZipEntry adding .... " + zipEntryName + fileNames[i].getName());
/*      */         }
/*      */ 
/* 3370 */         ZipEntry entry = new ZipEntry(zipEntryName + fileNames[i].getName());
/* 3371 */         out.putNextEntry(entry);
/*      */ 
/* 3373 */         FileInputStream fis = new FileInputStream(fileNames[i]);
/* 3374 */         BufferedInputStream origin = new BufferedInputStream(fis, BUFFER_SIZE);

/*      */ 
/* 3377 */         while ((count = origin.read(data, 0, BUFFER_SIZE)) != -1)
/*      */         {/*      */           int count;
/* 3379 */           out.write(data, 0, count);
/*      */         }
/*      */ 
/* 3382 */         origin.close();
/*      */       }
/*      */     }
/*      */   }

/*      */   boolean deleteFolder(String folderName)
/*      */   {
/* 3389 */     if (folderName == null)
/*      */     {
/* 3391 */       return true;
/*      */     }
/*      */ 
/* 3394 */     File folder = new File(folderName);
/* 3395 */     deleteAllFilesFromFolder(folder);
/* 3396 */     boolean deleted = folder.delete();
/* 3397 */     return deleted;
/*      */   }

/*      */   private void deleteAllFilesFromFolder(File folder)
/*      */   {
/* 3402 */     File[] files = folder.listFiles();
/* 3403 */     for (int i = 0; i < files.length; ++i)
/*      */     {
/* 3405 */       File f = files[i];
/* 3406 */       if (f.isDirectory())
/*      */       {
/* 3408 */         deleteAllFilesFromFolder(f);
/* 3409 */         f.delete();
/*      */       }
/*      */       else
/*      */       {
/* 3413 */         f.delete();
/*      */       }
/*      */     }
/*      */   }

/*      */   protected Locale getLocaleByLangCode(UserInfo userInfo)
/*      */   {
/* 3420 */     Locale uL = userInfo.getLocale();
/*      */ 
/* 3422 */     Locale l = new Locale(userInfo.getLangCode(), uL.getCountry(), uL.getVariant());
/*      */ 
/* 3424 */     return l;
/*      */   }



/*      */   protected void copyReportFile(String tempFolder, String reportFileName, String designFileContent, InputStream resourcesStream)
/*      */     throws IOException
/*      */   {
/* 3432 */     if ((reportFileName == null) || (reportFileName.trim().length() == 0))
/*      */     {
/* 3434 */       reportFileName = "birtreport.report";
/*      */     }
/*      */ 
/* 3437 */     String reportName = tempFolder + File.separator + reportFileName;
/*      */ 
/* 3439 */     File reportFolder = new File(tempFolder);
/* 3440 */     if (!(reportFolder.exists()))
/*      */     {
/* 3442 */       reportFolder.mkdirs();
/*      */     }
/*      */ 
/* 3445 */     createFileFromString(reportName, designFileContent);
/*      */ 
/* 3447 */     if (resourcesStream == null)
/*      */       return;
/* 3449 */     File resourcesZipFile = new File(reportFolder.getAbsolutePath() + File.separator + "resources.zip");
/* 3450 */     createFileFromStream(resourcesZipFile, resourcesStream);


/*      */ 
/* 3454 */     extractResources(resourcesZipFile, reportFolder.getAbsolutePath());
/* 3455 */     resourcesZipFile.delete();
/*      */   }


/*      */   protected void createFileFromString(String reportFileName, String designFileContent)
/*      */     throws IOException
/*      */   {
/* 3462 */     FileOutputStream fos = new FileOutputStream(reportFileName);
/* 3463 */     PrintWriter pw = new PrintWriter(new OutputStreamWriter(fos, "UTF-8"));
/* 3464 */     pw.print(designFileContent);
/* 3465 */     pw.close();
/*      */   }

/*      */   class PropertiesFileFilter
/*      */     implements FileFilter
/*      */   {
/* 3471 */     private String propertiesName = null;
/*      */ 
/*      */     public PropertiesFileFilter(String paramString)
/*      */     {
/* 3475 */       this.propertiesName = paramString;
/*      */     }

/*      */     public boolean accept(File pathname)
/*      */     {
/* 3480 */       if (pathname.isDirectory())
/*      */       {
/* 3482 */         return false;
/*      */       }
/*      */ 
/* 3485 */       String fullPath = pathname.getAbsolutePath();
/* 3486 */       if (fullPath.endsWith(".properties"))
/*      */       {
/* 3488 */         String fileName = pathname.getName();
/*      */ 
/* 3490 */         if ((fileName.startsWith(this.propertiesName + "_")) && (fileName.endsWith(".properties")))
/*      */         {
/* 3492 */           return true;


/*      */         }
/*      */ 
/* 3497 */         return (fullPath.endsWith(this.propertiesName + ".properties"));



/*      */       }
/*      */ 
/* 3503 */       return false;
/*      */     }
/*      */   }















/*      */   public String exportReportImportInputInfo(UserInfo userInfo, String reportName, String appName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 3524 */     MboSetRemote reportSetRemote = getMboSet("REPORT", userInfo);
/* 3525 */     reportSetRemote.setQbeExactMatch(true);
/* 3526 */     reportSetRemote.setQbe("REPORTNAME", reportName);
/* 3527 */     reportSetRemote.setQbe("APPNAME", appName);
/*      */ 
/* 3529 */     MboRemote reportRemote = reportSetRemote.getMbo(0);
/*      */ 
/* 3531 */     String lineSeparator = System.getProperty("line.separator");
/* 3532 */     StringBuffer output = new StringBuffer();
/* 3533 */     output.append(" "); output.append(lineSeparator);
/* 3534 */     output.append("This file can be used to define what reports need to be imported"); output.append(lineSeparator);
/* 3535 */     output.append("and the details of the report to be imported."); output.append(lineSeparator);
/* 3536 */     output.append(" "); output.append(lineSeparator);
/* 3537 */     output.append("an example:"); output.append(lineSeparator);
/* 3538 */     output.append("    <report name=\"WorkorderListParam.rptdesign\">"); output.append(lineSeparator);
/* 3539 */     output.append("        <attribute name=\"filename\">WorkorderListParam.rptdesign</attribute>"); output.append(lineSeparator);
/* 3540 */     output.append("        <attribute name=\"description\">Workorder List with Parameters</attribute>"); output.append(lineSeparator);
/* 3541 */     output.append("        <attribute name=\"toolbarlocation\">NONE</attribute>"); output.append(lineSeparator);
/* 3542 */     output.append("        <attribute name=\"toolbaricon\">nav_icon_overview.gif</attribute>"); output.append(lineSeparator);
/* 3543 */     output.append("        <attribute name=\"toolbarsequence\">1</attribute>"); output.append(lineSeparator);
/* 3544 */     output.append("        <attribute name=\"attacheddoc\">0</attribute>"); output.append(lineSeparator);
/* 3545 */     output.append("        <attribute name=\"norequestpage\">0</attribute>"); output.append(lineSeparator);
/* 3546 */     output.append("        <attribute name=\"detail\">0</attribute>"); output.append(lineSeparator);
/* 3547 */     output.append("        <attribute name=\"reportfolder\">WOTRACK</attribute>"); output.append(lineSeparator);
/* 3548 */     output.append(" "); output.append(lineSeparator);
/* 3549 */     output.append("        <parameters>"); output.append(lineSeparator);
/* 3550 */     output.append("            <parameter name=\"siteid\">"); output.append(lineSeparator);
/* 3551 */     output.append("                <attribute name=\"attributename\">SITEID</attribute>"); output.append(lineSeparator);
/* 3552 */     output.append("                <attribute name=\"lookupname\">site</attribute>"); output.append(lineSeparator);
/* 3553 */     output.append("                <attribute name=\"sequence\"></attribute>"); output.append(lineSeparator);
/* 3554 */     output.append("                <attribute name=\"labeloverride\">Site Id</attribute>"); output.append(lineSeparator);
/* 3555 */     output.append("                <attribute name=\"defaultvalue\"></attribute>"); output.append(lineSeparator);
/* 3556 */     output.append("                <attribute name=\"required\">1</attribute>"); output.append(lineSeparator);
/* 3557 */     output.append("                <attribute name=\"hidden\">0</attribute>"); output.append(lineSeparator);
/* 3558 */     output.append("                <attribute name=\"operator\"></attribute>"); output.append(lineSeparator);
/* 3559 */     output.append("                <attribute name=\"multilookup\">0</attribute>"); output.append(lineSeparator);
/* 3560 */     output.append("            </parameter>"); output.append(lineSeparator);
/* 3561 */     output.append("        </parameters>"); output.append(lineSeparator);
/* 3562 */     output.append(" "); output.append(lineSeparator);
/* 3563 */     output.append("        <resources>"); output.append(lineSeparator);
/* 3564 */     output.append("            <resource>"); output.append(lineSeparator);
/* 3565 */     output.append("                <reference>workorderlistparam.properties</reference>"); output.append(lineSeparator);
/* 3566 */     output.append("                <filename>${libraryfolder}/workorderlistparam.properties</filename>"); output.append(lineSeparator);
/* 3567 */     output.append("            </resource>"); output.append(lineSeparator);
/* 3568 */     output.append("        </resources>"); output.append(lineSeparator);
/* 3569 */     output.append("    </report>"); output.append(lineSeparator);
/* 3570 */     output.append(" "); output.append(lineSeparator);
/* 3571 */     output.append(" "); output.append(lineSeparator);
/* 3572 */     output.append(" "); output.append(lineSeparator);

/*      */     try
/*      */     {
/* 3576 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 3577 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 3578 */       DOMImplementation impl = builder.getDOMImplementation();

/*      */ 
/* 3581 */       Document xmldoc = null;
/* 3582 */       xmldoc = impl.createDocument(null, "reports", null);
/* 3583 */       Element root = xmldoc.getDocumentElement();
/*      */ 
/* 3585 */       Comment comment = xmldoc.createComment(output.toString());
/* 3586 */       root.appendChild(comment);

/*      */ 
/* 3589 */       Element reportElement = xmldoc.createElementNS(null, "report");
/* 3590 */       reportElement.setAttributeNS(null, "name", reportName);
/* 3591 */       root.appendChild(reportElement);


/*      */ 
/* 3595 */       Element reportAttrElement = xmldoc.createElementNS(null, "attribute");
/* 3596 */       reportAttrElement.setAttributeNS(null, "name", "filename");
/*      */ 
/* 3598 */       String fileName = reportName;
/* 3599 */       String reportFolder = reportRemote.getString("REPORTFOLDER");
/* 3600 */       if (!(reportFolder.equalsIgnoreCase(appName)))
/*      */       {
/* 3602 */         fileName = ".." + File.separator + reportFolder + File.separator + reportName;
/*      */       }
/*      */ 
/* 3605 */       Node n = xmldoc.createTextNode(fileName);
/* 3606 */       reportAttrElement.appendChild(n);
/* 3607 */       reportElement.appendChild(reportAttrElement);

/*      */ 
/* 3610 */       MaximoDD maximoDD = MXServer.getMXServer().getMaximoDD();
/* 3611 */       Iterator attributeIterator = maximoDD.getMboSetInfo("REPORT").getAttributes();
/* 3612 */       while (attributeIterator.hasNext())
/*      */       {
/* 3614 */         MboValueInfo attrInfo = (MboValueInfo)attributeIterator.next();
/* 3615 */         if (!(attrInfo.isPersistent()))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 3620 */         String attrName = attrInfo.getAttributeName();
/*      */ 
/* 3622 */         if ((attrName.equalsIgnoreCase("REPORTID")) || (attrName.equalsIgnoreCase("REPORTNAME"))) continue; if (attrName.equalsIgnoreCase("REPORTNUM"))


/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 3629 */         String value = reportRemote.getString(attrName);
/*      */ 
/* 3631 */         if (attrName.equalsIgnoreCase("TOOLBARLOCATION"))
/*      */         {
/* 3633 */           String toolbarLocation = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("TOOLBARLOCATIONS", value, reportRemote);
/* 3634 */           value = toolbarLocation;
/*      */         }
/* 3636 */         else if (attrName.equalsIgnoreCase("TOOLBARICON"))
/*      */         {
/* 3638 */           String toolbarIcon = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("TOOLBARICONS", value, reportRemote);
/* 3639 */           value = toolbarIcon;
/*      */         }
/* 3641 */         else if (attrName.equalsIgnoreCase("QLLOC"))
/*      */         {
/* 3643 */           String qlLoc = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("TOOLBARLOCATIONS", value, reportRemote);
/* 3644 */           value = qlLoc;
/*      */         }
/* 3646 */         else if (attrName.equalsIgnoreCase("DPLOC"))
/*      */         {
/* 3648 */           String dpLoc = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("TOOLBARLOCATIONS", value, reportRemote);
/* 3649 */           value = dpLoc;
/*      */         }
/* 3651 */         else if (attrName.equalsIgnoreCase("PADLOC"))
/*      */         {
/* 3653 */           String padLoc = MXServer.getMXServer().getMaximoDD().getTranslator().toInternalString("TOOLBARLOCATIONS", value, reportRemote);
/* 3654 */           value = padLoc;
/*      */         }
/*      */ 
/* 3657 */         Element reportAttrElement = xmldoc.createElementNS(null, "attribute");
/* 3658 */         reportAttrElement.setAttributeNS(null, "name", attrName.toLowerCase());
/* 3659 */         Node n = xmldoc.createTextNode(value);
/* 3660 */         reportAttrElement.appendChild(n);
/*      */ 
/* 3662 */         reportElement.appendChild(reportAttrElement);
/*      */       }
/*      */ 
/* 3665 */       Element reportParamsElement = null;
/* 3666 */       MboSetRemote reportLookupSet = reportRemote.getMboSet("REPORT_LOOKUP");
/* 3667 */       int i = 0;
/*      */       while (true)
/*      */       {
/* 3670 */         MboRemote reportLookup = reportLookupSet.getMbo(i);
/* 3671 */         if (reportLookup == null)
/*      */         {
/*      */           break;
/*      */         }
/*      */ 
/* 3676 */         if (i == 0)
/*      */         {
/* 3678 */           reportParamsElement = xmldoc.createElementNS(null, "parameters");
/* 3679 */           reportElement.appendChild(reportParamsElement);
/*      */         }
/*      */ 
/* 3682 */         ++i;
/* 3683 */         Element reportParamElement = xmldoc.createElementNS(null, "parameter");
/* 3684 */         reportParamElement.setAttributeNS(null, "name", reportLookup.getString("PARAMETERNAME"));
/* 3685 */         reportParamsElement.appendChild(reportParamElement);
/*      */ 
/* 3687 */         attributeIterator = maximoDD.getMboSetInfo("REPORTLOOKUP").getAttributes();
/* 3688 */         while (attributeIterator.hasNext())
/*      */         {
/* 3690 */           MboValueInfo attrInfo = (MboValueInfo)attributeIterator.next();
/* 3691 */           if (!(attrInfo.isPersistent()))
/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 3696 */           String attrName = attrInfo.getAttributeName();
/*      */ 
/* 3698 */           if (attrName.equalsIgnoreCase("REPORTLOOKUPID")) continue; if (attrName.equalsIgnoreCase("REPORTNUM"))

/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 3704 */           String value = reportLookup.getString(attrName);
/*      */ 
/* 3706 */           Element paramAttrElement = xmldoc.createElementNS(null, "attribute");
/* 3707 */           paramAttrElement.setAttributeNS(null, "name", attrName);
/* 3708 */           Node n = xmldoc.createTextNode(value);
/* 3709 */           paramAttrElement.appendChild(n);
/*      */ 
/* 3711 */           reportParamElement.appendChild(paramAttrElement);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3716 */       Element reportResourcesElement = null;
/* 3717 */       MboSetRemote reportDesignSet = reportRemote.getMboSet("REPORT_DESIGN");
/* 3718 */       MboRemote reportDesign = reportDesignSet.getMbo(0);
/* 3719 */       if ((reportDesign != null) && (!(reportDesign.isNull("RESOURCES"))))
/*      */       {
/* 3721 */         reportResourcesElement = xmldoc.createElementNS(null, "resources");
/* 3722 */         reportElement.appendChild(reportResourcesElement);
/*      */ 
/* 3724 */         byte[] resources = reportDesign.getBytes("RESOURCES");
/*      */ 
/* 3726 */         ByteArrayInputStream bis = new ByteArrayInputStream(resources);
/* 3727 */         ZipInputStream zipIs = new ZipInputStream(bis);

/*      */         while (true)
/*      */         {
/* 3731 */           ZipEntry zipEntry = zipIs.getNextEntry();
/* 3732 */           if (zipEntry == null) {
/*      */             break;
/*      */           }
/*      */ 
/* 3736 */           String zipEntryName = zipEntry.getName();
/* 3737 */           boolean isDir = zipEntry.isDirectory();
/*      */ 
/* 3739 */           if (isDir)

/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 3745 */           Element reportResourceElement = xmldoc.createElementNS(null, "resource");
/* 3746 */           reportResourcesElement.appendChild(reportResourceElement);
/*      */ 
/* 3748 */           Element resourceReferenceElement = xmldoc.createElementNS(null, "reference");
/* 3749 */           Node n = xmldoc.createTextNode(zipEntryName);
/* 3750 */           resourceReferenceElement.appendChild(n);
/*      */ 
/* 3752 */           Element resourceFilenameElement = xmldoc.createElementNS(null, "filename");
/* 3753 */           Node n1 = xmldoc.createTextNode("${libraryfolder}/" + zipEntryName);
/* 3754 */           resourceFilenameElement.appendChild(n1);
/*      */ 
/* 3756 */           reportResourceElement.appendChild(resourceReferenceElement);
/* 3757 */           reportResourceElement.appendChild(resourceFilenameElement);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3762 */       StringWriter sw = new StringWriter();
/*      */ 
/* 3764 */       DOMSource domSource = new DOMSource(xmldoc);
/* 3765 */       StreamResult streamResult = new StreamResult(sw);
/* 3766 */       TransformerFactory tf = TransformerFactory.newInstance();
/* 3767 */       Transformer serializer = tf.newTransformer();
/* 3768 */       serializer.setOutputProperty("encoding", "ISO-8859-1");
/* 3769 */       serializer.setOutputProperty("indent", "yes");
/* 3770 */       serializer.transform(domSource, streamResult);
/*      */ 
/* 3772 */       sw.flush();
/*      */ 
/* 3774 */       return sw.getBuffer().toString();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 3778 */       MXLogger reportAdminServiceLogger = getServiceLogger();
/* 3779 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/* 3781 */         reportAdminServiceLogger.error("Failed to export report import input information.", ex);
/*      */       }
/*      */ 
/* 3784 */       throw new MXApplicationException("reports", "failedtoexportlibraryimportinfo");
/*      */     }
/*      */   }













/*      */   public String exportLibraryImportInputInfo(UserInfo userInfo, String reportName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 3803 */     MboSetRemote reportDesignSetRemote = getMboSet("REPORTDESIGN", userInfo);
/* 3804 */     reportDesignSetRemote.setQbeExactMatch(true);
/* 3805 */     reportDesignSetRemote.setQbe("REPORTNAME", reportName);
/* 3806 */     reportDesignSetRemote.setQbe("ISLIBRARY", "true");
/*      */ 
/* 3808 */     MboRemote reportDesignRemote = reportDesignSetRemote.getMbo(0);
/*      */ 
/* 3810 */     String lineSeparator = System.getProperty("line.separator");
/* 3811 */     StringBuffer output = new StringBuffer();
/* 3812 */     output.append(" "); output.append(lineSeparator);
/* 3813 */     output.append("NOTE: The libraries are imported in the exact order mentioned in this file."); output.append(lineSeparator);
/* 3814 */     output.append("If the order of the libraries is not mentioned correctly, then the report import may fail."); output.append(lineSeparator);
/* 3815 */     output.append(" "); output.append(lineSeparator);
/* 3816 */     output.append("For example:"); output.append(lineSeparator);
/* 3817 */     output.append(" "); output.append(lineSeparator);
/* 3818 */     output.append("library1 (does not depended on anything)"); output.append(lineSeparator);
/* 3819 */     output.append("library2 (depends on library1)"); output.append(lineSeparator);
/* 3820 */     output.append("library3 (does not depended on anything)"); output.append(lineSeparator);
/* 3821 */     output.append("library4 (depends on library 2)"); output.append(lineSeparator);
/* 3822 */     output.append(" "); output.append(lineSeparator);
/* 3823 */     output.append(" "); output.append(lineSeparator);
/* 3824 */     output.append("an example:"); output.append(lineSeparator);
/* 3825 */     output.append("    <library name=\"WorkorderListParam.rptlibrary\">"); output.append(lineSeparator);
/* 3826 */     output.append("        <attribute name=\"filename\">WorkorderListParam.rptlibrary</attribute>"); output.append(lineSeparator);
/* 3827 */     output.append("        <attribute name=\"description\">Workorder List with Parameters Library</attribute>"); output.append(lineSeparator);
/* 3828 */     output.append(" "); output.append(lineSeparator);
/* 3829 */     output.append("        <resources>"); output.append(lineSeparator);
/* 3830 */     output.append("            <resource>"); output.append(lineSeparator);
/* 3831 */     output.append("                <reference>workorderlistparam.properties</reference>"); output.append(lineSeparator);
/* 3832 */     output.append("                <filename>workorderlistparam.properties</filename>"); output.append(lineSeparator);
/* 3833 */     output.append("            </resource>"); output.append(lineSeparator);
/* 3834 */     output.append("        </resources>"); output.append(lineSeparator);
/* 3835 */     output.append("    </library>"); output.append(lineSeparator);
/* 3836 */     output.append(" "); output.append(lineSeparator);
/* 3837 */     output.append(" "); output.append(lineSeparator);
/* 3838 */     output.append(" "); output.append(lineSeparator);

/*      */     try
/*      */     {
/* 3842 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 3843 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 3844 */       DOMImplementation impl = builder.getDOMImplementation();
/*      */ 
/* 3846 */       Document xmldoc = null;
/* 3847 */       xmldoc = impl.createDocument(null, "libraries", null);
/* 3848 */       Element root = xmldoc.getDocumentElement();
/*      */ 
/* 3850 */       Comment comment = xmldoc.createComment(output.toString());
/* 3851 */       root.appendChild(comment);
/*      */ 
/* 3853 */       Element reportElement = xmldoc.createElementNS(null, "library");
/* 3854 */       reportElement.setAttributeNS(null, "name", reportName);
/* 3855 */       root.appendChild(reportElement);


/*      */ 
/* 3859 */       Element reportAttrElement = xmldoc.createElementNS(null, "attribute");
/* 3860 */       reportAttrElement.setAttributeNS(null, "name", "filename");
/* 3861 */       Node n = xmldoc.createTextNode(reportName);
/* 3862 */       reportAttrElement.appendChild(n);
/* 3863 */       reportElement.appendChild(reportAttrElement);


/*      */ 
/* 3867 */       MaximoDD maximoDD = MXServer.getMXServer().getMaximoDD();
/* 3868 */       Iterator attributeIterator = maximoDD.getMboSetInfo("REPORTDESIGN").getAttributes();
/* 3869 */       while (attributeIterator.hasNext())
/*      */       {
/* 3871 */         MboValueInfo attrInfo = (MboValueInfo)attributeIterator.next();
/* 3872 */         if (!(attrInfo.isPersistent()))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 3877 */         String attrName = attrInfo.getAttributeName();
/*      */ 
/* 3879 */         if ((attrName.equalsIgnoreCase("REPORTDESIGNID")) || (attrName.equalsIgnoreCase("REPORTNUM")) || (attrName.equalsIgnoreCase("REPORTNAME")) || (attrName.equalsIgnoreCase("REPORTFILENAME")) || (attrName.equalsIgnoreCase("ISLIBRARY")) || (attrName.equalsIgnoreCase("DESIGN"))) continue; if (attrName.equalsIgnoreCase("RESOURCES"))







/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 3891 */         String value = reportDesignRemote.getString(attrName);
/*      */ 
/* 3893 */         Element reportAttrElement = xmldoc.createElementNS(null, "attribute");
/* 3894 */         reportAttrElement.setAttributeNS(null, "name", attrName.toLowerCase());
/* 3895 */         Node n = xmldoc.createTextNode(value);
/* 3896 */         reportAttrElement.appendChild(n);
/*      */ 
/* 3898 */         reportElement.appendChild(reportAttrElement);
/*      */       }
/*      */ 
/* 3901 */       Element reportResourcesElement = null;
/* 3902 */       if ((reportDesignRemote != null) && (!(reportDesignRemote.isNull("RESOURCES"))))
/*      */       {
/* 3904 */         reportResourcesElement = xmldoc.createElementNS(null, "resources");
/* 3905 */         reportElement.appendChild(reportResourcesElement);
/*      */ 
/* 3907 */         byte[] resources = reportDesignRemote.getBytes("RESOURCES");
/*      */ 
/* 3909 */         ByteArrayInputStream bis = new ByteArrayInputStream(resources);
/* 3910 */         ZipInputStream zipIs = new ZipInputStream(bis);

/*      */         while (true)
/*      */         {
/* 3914 */           ZipEntry zipEntry = zipIs.getNextEntry();
/* 3915 */           if (zipEntry == null) {
/*      */             break;
/*      */           }
/*      */ 
/* 3919 */           String zipEntryName = zipEntry.getName();
/* 3920 */           boolean isDir = zipEntry.isDirectory();
/*      */ 
/* 3922 */           if (isDir)

/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/* 3928 */           Element reportResourceElement = xmldoc.createElementNS(null, "resource");
/* 3929 */           reportResourcesElement.appendChild(reportResourceElement);
/*      */ 
/* 3931 */           Element resourceReferenceElement = xmldoc.createElementNS(null, "reference");
/* 3932 */           Node n = xmldoc.createTextNode(zipEntryName);
/* 3933 */           resourceReferenceElement.appendChild(n);
/*      */ 
/* 3935 */           Element resourceFilenameElement = xmldoc.createElementNS(null, "filename");
/* 3936 */           Node n1 = xmldoc.createTextNode(zipEntryName);
/* 3937 */           resourceFilenameElement.appendChild(n1);
/*      */ 
/* 3939 */           reportResourceElement.appendChild(resourceReferenceElement);
/* 3940 */           reportResourceElement.appendChild(resourceFilenameElement);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3945 */       StringWriter sw = new StringWriter();
/*      */ 
/* 3947 */       DOMSource domSource = new DOMSource(xmldoc);
/* 3948 */       StreamResult streamResult = new StreamResult(sw);
/* 3949 */       TransformerFactory tf = TransformerFactory.newInstance();
/* 3950 */       Transformer serializer = tf.newTransformer();
/* 3951 */       serializer.setOutputProperty("indent", "yes");
/* 3952 */       serializer.transform(domSource, streamResult);
/*      */ 
/* 3954 */       sw.flush();
/*      */ 
/* 3956 */       return sw.getBuffer().toString();
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 3960 */       MXLogger reportAdminServiceLogger = getServiceLogger();
/* 3961 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/* 3963 */         reportAdminServiceLogger.error("Failed to export library import input information.", ex);
/*      */       }
/*      */ 
/* 3966 */       throw new MXApplicationException("reports", "failedtoexportlibraryimportinfo");
/*      */     }
/*      */   }














/*      */   public void createReportDesign(UserInfo userInfo, CreateReportInputInfo reportInputInfo)
/*      */     throws MXException, RemoteException
/*      */   {
/* 3986 */     ReportDesignTask designTask = ReportDesignTaskProvider.getReportDesignTask();
/* 3987 */     if (designTask == null)
/*      */     {
/* 3989 */       throw new IllegalStateException("BIRT Report Engine not initialized properly for this operation to work.");

/*      */     }
/*      */ 
/* 3993 */     CreateReportInputInfo copyOfReportInputInfo = (CreateReportInputInfo)reportInputInfo.clone();
/*      */ 
/* 3995 */     String userId = userInfo.getLoginUserName();
/* 3996 */     String reportOwner = copyOfReportInputInfo.getUserName();
/* 3997 */     if (reportOwner == null)
/*      */     {
/* 3999 */       reportOwner = userId;
/* 4000 */       copyOfReportInputInfo.setUserName(reportOwner);


/*      */     }
/*      */ 
/* 4005 */     String userFolderName = ReportUtil.getUserFolderName(userInfo);
/* 4006 */     String tempRunFolder = ReportRuntimeTempLocation.getReportsLocation();
/* 4007 */     String tempFolder = tempRunFolder + File.separator + "create" + File.separator + userFolderName;
/* 4008 */     String tempUniqueFolder = createUniqueTempFolder(tempFolder);
/*      */ 
/* 4010 */     String tempLibraryFolder = tempFolder + File.separator + tempUniqueFolder + File.separator + "libraries";
/* 4011 */     String tempReportFolder = tempFolder + File.separator + tempUniqueFolder + File.separator + "report";

/*      */     try
/*      */     {
/* 4015 */       new File(tempLibraryFolder).mkdirs();
/* 4016 */       new File(tempReportFolder).mkdirs();

/*      */ 
/* 4019 */       extractReport(userInfo, "MaximoSystemLibrary.rptlibrary", tempLibraryFolder, true);


/*      */ 
/* 4023 */       MaximoDD maximoDD = MXServer.getMXServer().getMaximoDD();

/*      */ 
/* 4026 */       String masterMboName = copyOfReportInputInfo.getMboName();
/* 4027 */       MboSetInfo mboSetInfo = maximoDD.getMboSetInfo(masterMboName);
/*      */ 
/* 4029 */       copyOfReportInputInfo.setEntityName(mboSetInfo.getEntityName().toLowerCase());
/*      */ 
/* 4031 */       Iterator reportInfoIterator = copyOfReportInputInfo.getAllListReportInputInfo();
/* 4032 */       while (reportInfoIterator.hasNext())
/*      */       {
/* 4034 */         CreateListReportInputInfo listReportInfo = (CreateListReportInputInfo)reportInfoIterator.next();
/*      */ 
/* 4036 */         String reportMboName = listReportInfo.getMboName();
/*      */ 
/* 4038 */         mboSetInfo = maximoDD.getMboSetInfo(reportMboName);
/*      */ 
/* 4040 */         listReportInfo.setEntityName(mboSetInfo.getEntityName().toLowerCase());
/*      */ 
/* 4042 */         Iterator dcInfoIterator = listReportInfo.getAllDataColumnInputInfo();
/* 4043 */         while (dcInfoIterator.hasNext())
/*      */         {
/* 4045 */           CreateListReportDataColumnInputInfo dcInfo = (CreateListReportDataColumnInputInfo)dcInfoIterator.next();
/* 4046 */           String mboAttributeName = dcInfo.getMboAttributeName();

/*      */ 
/* 4049 */           String columMboName = dcInfo.getMboName();
/* 4050 */           mboSetInfo = maximoDD.getMboSetInfo(columMboName);
/*      */ 
/* 4052 */           MboValueInfo mboValueInfo = mboSetInfo.getMboValueInfo(mboAttributeName);
/* 4053 */           if (mboValueInfo == null)
/*      */           {
/* 4055 */             Object[] params = { mboAttributeName };
/* 4056 */             throw new MXApplicationException("system", "noattribute", params);
/*      */           }
/*      */ 
/* 4059 */           String maxType = mboValueInfo.getMaxType();
/* 4060 */           int length = mboValueInfo.getLength();
/* 4061 */           boolean localized = mboValueInfo.isMLInUse();
/*      */ 
/* 4063 */           dcInfo.setEntityName(mboValueInfo.getEntityName().toLowerCase());
/* 4064 */           String entityUIDColumnName = mboSetInfo.getUniqueIDName();
/* 4065 */           if (entityUIDColumnName != null)
/* 4066 */             dcInfo.setEntityUIDColumnName(entityUIDColumnName.toLowerCase());
/* 4067 */           dcInfo.setColumnName(mboValueInfo.getEntityColumnName().toLowerCase());
/* 4068 */           dcInfo.setMxDataType(maxType);
/* 4069 */           dcInfo.setColumnLength(length);
/* 4070 */           dcInfo.setLocalized(localized);
/* 4071 */           dcInfo.setBirtDataType(getBirtDataType(maxType));
/* 4072 */           if (dcInfo.getWidth() == null)
/*      */           {
/* 4074 */             dcInfo.setWidth(calculateDataColumnWidth(maxType, length));
/*      */           }
/* 4076 */           if (dcInfo.getTitle() == null)
/*      */           {
/* 4078 */             dcInfo.setTitle(mboValueInfo.getTitle());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 4083 */         ArrayList bindParamList = listReportInfo.getBindParamList();
/* 4084 */         int size = bindParamList.size();
/* 4085 */         for (int i = 0; i < size; ++i)
/*      */         {
/* 4087 */           String paramValue = (String)bindParamList.get(i);
/* 4088 */           mboSetInfo = maximoDD.getMboSetInfo(masterMboName);
/* 4089 */           MboValueInfo mboValueInfo = mboSetInfo.getMboValueInfo(paramValue);
/* 4090 */           if (mboValueInfo == null)
/*      */           {
/* 4092 */             Object[] params = { paramValue };
/* 4093 */             throw new MXApplicationException("system", "noattribute", params);
/*      */           }
/* 4095 */           bindParamList.set(i, mboValueInfo.getEntityColumnName().toLowerCase());

/*      */         }
/*      */ 
/* 4099 */         Iterator relationIterator = listReportInfo.getAllRelationshipInfo();
/* 4100 */         while (relationIterator.hasNext())
/*      */         {
/* 4102 */           CreateReportRelationshipInfo relationInfo = (CreateReportRelationshipInfo)relationIterator.next();
/* 4103 */           String mboName = relationInfo.getParentObjectName();
/* 4104 */           mboSetInfo = maximoDD.getMboSetInfo(mboName);
/* 4105 */           relationInfo.setParentEntityName(mboSetInfo.getEntityName().toLowerCase());
/* 4106 */           mboName = relationInfo.getChildObjectName();
/* 4107 */           mboSetInfo = maximoDD.getMboSetInfo(mboName);
/* 4108 */           relationInfo.setChildEntityName(mboSetInfo.getEntityName().toLowerCase());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4113 */       HashMap messages = new HashMap();
/* 4114 */       messages.put("numberOfRecords", getStaticText(userInfo, "numberOfRecords", "Number of Records"));
/* 4115 */       messages.put("savedWhereClause", getStaticText(userInfo, "savedWhereClause", "Saved Where Clause"));
/* 4116 */       messages.put("dynamicWhereClause", getStaticText(userInfo, "dynamicWhereClause", "Dynamic Where Clause"));
/* 4117 */       copyOfReportInputInfo.setMessages(messages);





/*      */ 
/* 4124 */       Locale l = Locale.US;
/* 4125 */       designTask.createReportDesign(copyOfReportInputInfo, tempLibraryFolder, tempReportFolder, l);

/*      */ 
/* 4128 */       if (copyOfReportInputInfo.isToBeSaved())
/*      */       {
/* 4130 */         ReportImportInfo reportImportInfo = new ReportImportInfo();
/* 4131 */         reportImportInfo.setName(copyOfReportInputInfo.getName());
/* 4132 */         reportImportInfo.setAppName(copyOfReportInputInfo.getAppName());
/* 4133 */         reportImportInfo.setFileName(copyOfReportInputInfo.getName());
/* 4134 */         reportImportInfo.setAttribute("DESCRIPTION", copyOfReportInputInfo.getDescription());
/* 4135 */         reportImportInfo.setAttribute("REPORTFOLDER", copyOfReportInputInfo.getAppName());



/*      */ 
/* 4140 */         if (copyOfReportInputInfo.hasFixedQuery() == true)
/*      */         {
/* 4142 */           reportImportInfo.setAttribute("EXCLUDEDYNAMICWHERE", "1");
/*      */         }
/*      */ 
/* 4145 */         reportImportInfo.setAttribute("USERID", reportOwner);
/* 4146 */         reportImportInfo.setAttribute("EDITENABLED", "1");
/* 4147 */         reportImportInfo.setFileName(copyOfReportInputInfo.getName());
/* 4148 */         reportImportInfo.setXmlReportData(getFileContent(tempReportFolder + File.separator + copyOfReportInputInfo.getName()));
/* 4149 */         reportImportInfo.setResources(createResourcesZip(new File(tempReportFolder).listFiles()));

/*      */ 
/* 4152 */         Iterator paramInfoIterator = copyOfReportInputInfo.getAllImportParamInfo();
/* 4153 */         while (paramInfoIterator.hasNext())
/*      */         {
/* 4155 */           ReportImportParamInfo paramInfo = (ReportImportParamInfo)paramInfoIterator.next();
/*      */ 
/* 4157 */           String paramName = paramInfo.getAttribute("attributename").toLowerCase();
/* 4158 */           reportImportInfo.setParameter(paramName, paramInfo);

/*      */         }
/*      */ 
/* 4162 */         boolean isPublic = copyOfReportInputInfo.isPublic();
/* 4163 */         importReport(userInfo, reportImportInfo, false, false, isPublic);
/*      */       }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 4168 */       MXLogger reportAdminServiceLogger = getServiceLogger();




/*      */ 
/* 4174 */       throw new MXApplicationException("reports", "failedtocreatelistreport", ex);

/*      */     }
/*      */     finally
/*      */     {
/* 4179 */       if (copyOfReportInputInfo.isToBeSaved())
/*      */       {
/* 4181 */         deleteFolder(tempFolder + File.separator + tempUniqueFolder);
/*      */       }
/*      */     }
/*      */   }



























































/*      */   private String calculateDataColumnWidth(String maxType, int length)
/*      */   {
/* 4246 */     if ((length > 0) && (length <= 12))
/*      */     {
/* 4248 */       return "0.7in";
/*      */     }
/* 4250 */     if ((length > 12) && (length <= 30))
/*      */     {
/* 4252 */       return "1in";
/*      */     }
/* 4254 */     if (length > 30)
/*      */     {
/* 4256 */       return "1.5in";
/*      */     }
/*      */ 
/* 4259 */     return "0in";
/*      */   }


















/*      */   private String getBirtDataType(String maxType)
/*      */   {
/* 4281 */     if ((maxType.equalsIgnoreCase("ALN")) || (maxType.equalsIgnoreCase("LOWER")) || (maxType.equalsIgnoreCase("UPPER")) || (maxType.equalsIgnoreCase("YORN")) || (maxType.equalsIgnoreCase("CLOB")) || (maxType.equalsIgnoreCase("GL")) || (maxType.equalsIgnoreCase("LONGALN")))







/*      */     {
/* 4290 */       return "string";
/*      */     }
/* 4292 */     if ((maxType.equalsIgnoreCase("DATETIME")) || (maxType.equalsIgnoreCase("TIME")))


/*      */     {
/* 4296 */       return "date-time";
/*      */     }
/* 4298 */     if (maxType.equalsIgnoreCase("DATE"))
/*      */     {
/* 4300 */       return "date";
/*      */     }
/* 4302 */     if ((maxType.equalsIgnoreCase("AMOUNT")) || (maxType.equalsIgnoreCase("DECIMAL")))


/*      */     {
/* 4306 */       return "decimal";
/*      */     }
/* 4308 */     if ((maxType.equalsIgnoreCase("DURATION")) || (maxType.equalsIgnoreCase("FLOAT")))


/*      */     {
/* 4312 */       return "float";
/*      */     }
/* 4314 */     if ((maxType.equalsIgnoreCase("INTEGER")) || (maxType.equalsIgnoreCase("SMALLINT")))


/*      */     {
/* 4318 */       return "integer";
/*      */     }
/*      */ 
/* 4321 */     return "string";
/*      */   }

/*      */   private byte[] getFileContent(String fileName) throws IOException
/*      */   {
/* 4326 */     if (fileName == null)
/*      */     {
/* 4328 */       return null;
/*      */     }
/*      */ 
/* 4331 */     FileInputStream fs = new FileInputStream(fileName);
/* 4332 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 4333 */     byte[] buf = new byte[1024];
/*      */     while (true)
/*      */     {
/* 4336 */       int noOfBytesRead = fs.read(buf);
/* 4337 */       if (noOfBytesRead <= 0)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 4342 */       bos.write(buf, 0, noOfBytesRead);
/*      */     }
/*      */ 
/* 4345 */     bos.flush();
/*      */ 
/* 4347 */     byte[] data = bos.toByteArray();
/*      */ 
/* 4349 */     return data;
/*      */   }

/*      */   private void writeFileContents(String fileName, ZipOutputStream out) throws IOException
/*      */   {
/* 4354 */     byte[] data = new byte[2048];
/* 4355 */     FileInputStream fis = new FileInputStream(fileName);
/* 4356 */     BufferedInputStream origin = null;

/*      */     try
/*      */     {
/* 4360 */       origin = new BufferedInputStream(fis, 2048);

/*      */ 
/* 4363 */       while ((count = origin.read(data, 0, 2048)) != -1)
/*      */       {/*      */         int count;
/* 4365 */         out.write(data, 0, count);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try {
/* 4371 */         if (origin != null)
/* 4372 */           origin.close();
/*      */       } catch (Throwable t) {
/*      */       }
/*      */     }
/*      */   }

/*      */   private byte[] createResourcesZip(File[] files) throws Exception {
/* 4379 */     byte[] data = new byte[2048];
/*      */ 
/* 4381 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 4382 */     ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(bos));
/*      */ 
/* 4384 */     int noOfFiles = files.length;
/* 4385 */     for (int i = 0; i < noOfFiles; ++i)
/*      */     {
/* 4387 */       File f = files[i];
/* 4388 */       String fileName = f.getName();
/* 4389 */       if (fileName.endsWith(".rptdesign"))

/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/* 4395 */       ZipEntry entry = new ZipEntry(fileName);
/* 4396 */       out.putNextEntry(entry);
/*      */ 
/* 4398 */       writeFileContents(f.getAbsolutePath(), out);
/*      */     }
/*      */ 
/* 4401 */     out.flush();
/* 4402 */     out.finish();
/* 4403 */     out.close();
/*      */ 
/* 4405 */     return bos.toByteArray();
/*      */   }














/*      */   public boolean isAuthorizedToRunReport(UserInfo userInfo, String reportName, String appName)
/*      */     throws MXException, RemoteException
/*      */   {
/* 4424 */     ReportServiceRemote reportService = (ReportServiceRemote)MXServer.getMXServer().lookup("REPORT");
/*      */ 
/* 4426 */     boolean authorized = reportService.canRunThisReport(userInfo, reportName, appName);
/*      */ 
/* 4428 */     if (!(authorized))


/*      */     {
/* 4432 */       String userFolderName = ReportUtil.getUserFolderName(userInfo);
/*      */ 
/* 4434 */       String tempRunFolder = ReportRuntimeTempLocation.getReportsLocation();
/* 4435 */       String tempUserFolder = tempRunFolder + File.separator + "create" + File.separator + userFolderName;

/*      */ 
/* 4438 */       File userFolder = new File(tempUserFolder);
/* 4439 */       File[] listOfUniqueFolders = userFolder.listFiles();
/* 4440 */       for (int i = 0; i < listOfUniqueFolders.length; ++i)
/*      */       {
/* 4442 */         String reportFile = listOfUniqueFolders[i].getAbsolutePath() + File.separator + "report" + File.separator + reportName;
/* 4443 */         File f = new File(reportFile);
/* 4444 */         if (f.exists())
/*      */         {
/* 4446 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 4451 */     return authorized;
/*      */   }











/*      */   public String getReportViewerURL()
/*      */     throws MXException, RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 4469 */       MXServer mxServer = MXServer.getMXServer();
/*      */ 
/* 4471 */       String viewerURL = mxServer.getProperty("mxe.report.birt.viewerurl");
/* 4472 */       if (viewerURL == null)
/*      */       {
/* 4474 */         return null;
/*      */       }
/*      */ 
/* 4477 */       return viewerURL;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 4481 */       MXLogger reportAdminServiceLogger = getServiceLogger();
/* 4482 */       if (reportAdminServiceLogger.isErrorEnabled())
/*      */       {
/* 4484 */         reportAdminServiceLogger.error("Failed to obtain [mxe.report.birt.viewerurl] property value. Assuming cluster or dedicated report server setup not present.", ex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4489 */     return null;
/*      */   }







/*      */   public void cancelReportJob(long reportJobId)
/*      */     throws MXException, RemoteException
/*      */   {
/* 4501 */     ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();
/*      */ 
/* 4503 */     atmgr.cancelReportJob(reportJobId);
/*      */   }







/*      */   public void cancelReportJobOnThisServer(long reportJobId)
/*      */     throws MXException, RemoteException
/*      */   {
/* 4515 */     ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();
/*      */ 
/* 4517 */     atmgr.cancelReportJobOnThisServer(reportJobId);
/*      */   }








/*      */   public boolean isReportJobCancelled(long reportJobId)
/*      */     throws MXException, RemoteException
/*      */   {
/* 4530 */     ActiveReportThreadManager atmgr = ActiveReportThreadManager.getActiveReportThreadManager();
/*      */ 
/* 4532 */     return atmgr.isReportJobCancelled(reportJobId);
/*      */   }

/*      */   private String getStaticText(UserInfo userInfo, String key, String defaultValue)
/*      */   {
/*      */     try
/*      */     {
/* 4539 */       Message msg = MXServer.getMXServer().getMaxMessageCache().getMessage("reports", key, userInfo);
/* 4540 */       if (msg != null)
/*      */       {
/* 4542 */         msg.setLocale(userInfo.getLocale());
/* 4543 */         return msg.getMessage();
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/*      */     }
/* 4548 */     return defaultValue;
/*      */   }
/*      */ }
