/*     */ package com.ibm.tivoli.maximo.report.birt.scheduler;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.SimpleCronTask;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 

































/*     */ public class ReportOutputCleanupCronTask extends SimpleCronTask
/*     */ {
/*     */   private static final String CRONTASKNAME = "ReportOutputCleanupCronTask";
/*     */   private MXLogger logger;
/*     */ 
/*     */   public void cronAction()
/*     */   {
/*  55 */     MXLogger logger = getCronTaskLogger();
/*     */ 
/*  57 */     if (logger.isDebugEnabled()) {
/*  58 */       logger.debug("ReportOutputCleanupCronTask cronAction called....");
/*  59 */       logger.debug("ReportOutputCleanupCronTask starting work");
/*     */     }
/*     */ 
/*  62 */     doCleanup();
/*     */ 
/*  64 */     if (logger.isDebugEnabled())
/*  65 */       logger.debug("ReportOutputCleanupCronTask done with work");
/*     */   }








/*     */   private void doCleanup()
/*     */   {
/*     */     try
/*     */     {
/*  79 */       int keepDays = getParamAsInt("NOOFDAYS");
/*     */ 
/*  81 */       Date limitDate = setDateLimit(keepDays);
/*     */ 
/*  83 */       MXServer mxserver = MXServer.getMXServer();
/*     */ 
/*  85 */       MboSetRemote reportOutputSet = mxserver.getMboSet("REPORTOUTPUT", mxserver.getSystemUserInfo());
/*  86 */       String sqlWhere = " createddate < " + SqlFormat.getTimestampFunction(limitDate);
/*  87 */       SqlFormat sqlFormat = new SqlFormat(reportOutputSet.getUserInfo(), sqlWhere);
/*  88 */       reportOutputSet.setWhere(sqlFormat.format());
/*  89 */       reportOutputSet.reset();
/*     */ 
/*  91 */       deleteReportOutputEntries(reportOutputSet);
/*     */ 
/*  93 */       reportOutputSet.save();
/*     */     }
/*     */     catch (RemoteException e) {
/*  96 */       this.logger.debug("ReportOutputCleanupCronTask failed due to exception", e);
/*  97 */       e.printStackTrace();
/*     */     } catch (MXException e) {
/*  99 */       this.logger.debug("ReportOutputCleanupCronTask failed due to exception", e);
/* 100 */       e.printStackTrace();
/*     */     }
/*     */   }







/*     */   private void deleteReportOutputEntries(MboSetRemote reportOutputSet)
/*     */     throws MXException, RemoteException
/*     */   {
/* 113 */     for (int i = 0; i < reportOutputSet.count(); ++i) {
/* 114 */       MboRemote reportOutput = reportOutputSet.getMbo(i);
/* 115 */       MboSetRemote reportOutputAuthSet = reportOutput.getMboSet("REPORTOUTPUTAUTH");
/* 116 */       reportOutputAuthSet.deleteAll(11L);
/*     */ 
/* 118 */       MboSetRemote reportOutputCntSet = reportOutput.getMboSet("REPORTOUTPUTCNT");
/* 119 */       reportOutputCntSet.deleteAll(11L);
/*     */     }
/* 121 */     reportOutputSet.deleteAll(11L);
/*     */   }






/*     */   private Date setDateLimit(int keepDays)
/*     */     throws RemoteException
/*     */   {
/* 132 */     Calendar calendar = GregorianCalendar.getInstance();
/* 133 */     calendar.setTime(MXServer.getMXServer().getDate());
/* 134 */     calendar.add(6, keepDays * -1);
/* 135 */     calendar.set(10, 23);
/* 136 */     calendar.set(12, 59);
/* 137 */     calendar.set(13, 59);
/* 138 */     calendar.set(14, 0);
/* 139 */     return calendar.getTime();
/*     */   }
/*     */ }
