/*    */ package com.ibm.tivoli.maximo.report.birt.session;
/*    */ 
/*    */ import psdi.util.MXSession;
/*    */ import psdi.util.MXSessionImplFactory;
/*    */ 



























/*    */ public class SecuredWebAppSessionFactory
/*    */   implements MXSessionImplFactory
/*    */ {
/*    */   public MXSession getSession()
/*    */   {
/* 38 */     return new SecuredWebAppSession();
/*    */   }






/*    */   public MXSession getNewSession()
/*    */   {
/* 48 */     return new SecuredWebAppSession();
/*    */   }
/*    */ }
