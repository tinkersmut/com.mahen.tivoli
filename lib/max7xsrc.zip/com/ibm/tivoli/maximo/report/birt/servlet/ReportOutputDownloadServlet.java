/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import psdi.app.report.ReportConstants.EmailFileTypes;
/*     */ import psdi.app.report.ReportOutputCntRemote;
/*     */ import psdi.mbo.MaxMessageCache;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.util.Message;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 

































/*     */ public class ReportOutputDownloadServlet extends HttpServlet
/*     */ {
/*     */   private ReportLogger reportLogger;
/*     */ 
/*     */   public void init(ServletConfig config)
/*     */     throws ServletException
/*     */   {
/*  68 */     super.init(config);
/*  69 */     this.reportLogger = ReportLoggerFactory.getLogger("maximo.report.birt");
/*     */   }



/*     */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  77 */     pushReportOutput(request, response);
/*     */   }



/*     */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  85 */     pushReportOutput(request, response);
/*     */   }







/*     */   protected void pushReportOutput(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  97 */     String uisessionid_key = "uisessionid";
/*  98 */     String uisessionid = request.getParameter(uisessionid_key);
/*  99 */     if (uisessionid == null)
/*     */     {
/*     */       try {
/* 102 */         String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "MissingRequiredUrlParameter").getMessage(uisessionid_key);

/*     */ 
/* 105 */         this.reportLogger.error(message);
/*     */       } catch (MXException e) {
/* 107 */         e.printStackTrace();
/*     */       }
/* 109 */       response.setStatus(401);
/* 110 */       return;
/*     */     }
/*     */ 
/* 113 */     String jobnum_key = "jobnum";
/* 114 */     String jobnum = request.getParameter(jobnum_key);
/* 115 */     if (jobnum == null)
/*     */     {
/*     */       try {
/* 118 */         String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "MissingRequiredUrlParameter").getMessage(jobnum_key);

/*     */ 
/* 121 */         this.reportLogger.error(message);
/*     */       } catch (MXException e) {
/* 123 */         e.printStackTrace();
/*     */       }
/* 125 */       response.setStatus(401);
/* 126 */       return;
/*     */     }
/*     */ 
/* 129 */     WebClientRuntime webClientRuntime = WebClientRuntime.getWebClientRuntime();
/* 130 */     WebClientSession webClientSession = webClientRuntime.getWebClientSession(request);
/*     */ 
/* 132 */     UserInfo userInfo = webClientSession.getUserInfo();
/* 133 */     MXSession mxSession = webClientSession.getMXSession();
/*     */ 
/* 135 */     if (!(mxSession.isConnected()))
/*     */     {
/*     */       try {
/* 138 */         String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "MXSessionNotConnected").getMessage();

/*     */ 
/* 141 */         this.reportLogger.error(message);
/*     */       } catch (MXException e) {
/* 143 */         e.printStackTrace();
/*     */       }
/* 145 */       response.setStatus(401);
/* 146 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 150 */       ReportOutputCntRemote reportOutputCnt = getReportOutputCnt(jobnum, userInfo, mxSession);
/* 151 */       ReportConstants.EmailFileTypes emailFileType = reportOutputCnt.getFileType();
/*     */ 
/* 153 */       response.reset();
/*     */ 
/* 155 */       response.setContentType(emailFileType.getContentType());
/* 156 */       response.addHeader("Content-Disposition", reportOutputCnt.getString("filename") + '.' + emailFileType.getExtension());
/*     */ 
/* 158 */       byte[] content = reportOutputCnt.getBytes("CONTENT");
/* 159 */       OutputStream output = response.getOutputStream();
/*     */ 
/* 161 */       response.setContentLength(content.length);
/* 162 */       output.write(content);
/* 163 */       output.flush();
/* 164 */       output.close();

/*     */     }
/*     */     catch (MXException e)
/*     */     {
/*     */       try
/*     */       {
/* 171 */         String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "ReportOutputFileNotCreated").getMessage();

/*     */ 
/* 174 */         this.reportLogger.error(message, e);
/*     */       } catch (MXException e1) {
/* 176 */         e1.printStackTrace();
/*     */       }
/* 178 */       response.setStatus(500);
/*     */     }
/*     */   }










/*     */   private ReportOutputCntRemote getReportOutputCnt(String jobnum, UserInfo userInfo, MXSession mxSession)
/*     */     throws MXException, RemoteException, MXApplicationException
/*     */   {
/* 194 */     MboSetRemote reportOutputSet = mxSession.getMboSet("REPORTOUTPUT");
/* 195 */     String userName = userInfo.getUserName();
/* 196 */     String sqlWhere = " jobnum='" + jobnum + "' and ( userid='" + userName + "' or jobnum in (select jobnum from reportoutputauth where userid='" + userName + "') )";
/* 197 */     SqlFormat sqlFormat = new SqlFormat(userInfo, sqlWhere);
/* 198 */     reportOutputSet.setWhere(sqlFormat.format());
/* 199 */     reportOutputSet.reset();
/*     */ 
/* 201 */     if (reportOutputSet.count() == 0) {
/* 202 */       String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "NoRecordsAfterSecurityApplied").getMessage("REPORTOUTPUT");

/*     */ 
/* 205 */       this.reportLogger.error(message);
/* 206 */       throw new MXApplicationException("reports", "NoReportOutputFound");
/*     */     }
/*     */ 
/* 209 */     if (reportOutputSet.getMbo(0) == null) {
/* 210 */       String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "BadRecord").getMessage("REPORTOUTPUT");

/*     */ 
/* 213 */       this.reportLogger.error(message);
/* 214 */       throw new MXApplicationException("reports", "NoReportOutputFound");
/*     */     }
/*     */ 
/* 217 */     MboRemote reportOutput = reportOutputSet.getMbo(0);
/*     */ 
/* 219 */     MboSetRemote reportOutputCntSet = reportOutput.getMboSet("REPORTOUTPUTCNT");
/*     */ 
/* 221 */     if (reportOutputCntSet.count() == 0) {
/* 222 */       String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "NoRecordsAfterSecurityApplied").getMessage("REPORTOUTPUTCNT");

/*     */ 
/* 225 */       this.reportLogger.error(message);
/* 226 */       throw new MXApplicationException("reports", "NoReportOutputFound");
/*     */     }
/*     */ 
/* 229 */     if (reportOutputCntSet.getMbo(0) == null) {
/* 230 */       String message = MXServer.getMXServer().getMaxMessageCache().getTaggedMessage("reports", "BadRecord").getMessage("REPORTOUTPUTCNT");

/*     */ 
/* 233 */       this.reportLogger.error(message);
/* 234 */       throw new MXApplicationException("reports", "NoReportOutputFound");
/*     */     }
/*     */ 
/* 237 */     ReportOutputCntRemote reportOutputCnt = (ReportOutputCntRemote)reportOutputCntSet.getMbo(0);
/* 238 */     return reportOutputCnt;
/*     */   }
/*     */ }
