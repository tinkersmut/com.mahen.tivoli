/*     */ package com.ibm.tivoli.maximo.report.birt.admin;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.design.ReportParameterInfo;
/*     */ import java.io.Serializable;
/*     */ 




























































/*     */ public class ReportRunInfo
/*     */   implements Serializable
/*     */ {
/*     */   private String reportName;
/*     */   private String appName;
/*     */   private String reportFolderName;
/*     */   private String reportOutputFolderName;
/*     */   private String tempRunFolder;
/*     */   private String reportRelativePath;
/*     */   private ReportParameterInfo[] paramInfo;
/*     */ 
/*     */   public String getReportFolderName()
/*     */   {
/*  79 */     return this.reportFolderName;
/*     */   }









/*     */   public void setReportFolderName(String reportFolderName)
/*     */   {
/*  92 */     this.reportFolderName = reportFolderName;
/*     */   }






/*     */   public String getReportName()
/*     */   {
/* 102 */     return this.reportName;
/*     */   }






/*     */   public void setReportName(String reportName)
/*     */   {
/* 112 */     this.reportName = reportName;
/*     */   }






/*     */   public String getAppName()
/*     */   {
/* 122 */     return this.appName;
/*     */   }






/*     */   public void setAppName(String appName)
/*     */   {
/* 132 */     this.appName = appName;
/*     */   }







/*     */   public String getReportOutputFolderName()
/*     */   {
/* 143 */     return this.reportOutputFolderName;
/*     */   }







/*     */   public void setReportOutputFolderName(String reportOutputFolderName)
/*     */   {
/* 154 */     this.reportOutputFolderName = reportOutputFolderName;
/*     */   }







/*     */   public String getTempRunFolder()
/*     */   {
/* 165 */     return this.tempRunFolder;
/*     */   }







/*     */   public void setTempRunFolder(String tempFolder)
/*     */   {
/* 176 */     this.tempRunFolder = tempFolder;
/*     */   }








/*     */   public String getReportRelativePath()
/*     */   {
/* 188 */     return this.reportRelativePath;
/*     */   }








/*     */   public void setReportRelativePath(String reportRelativePath)
/*     */   {
/* 200 */     this.reportRelativePath = reportRelativePath;
/*     */   }

/*     */   public ReportParameterInfo[] getReportParameterInfo()
/*     */   {
/* 205 */     return this.paramInfo;
/*     */   }

/*     */   public void setReportParameterInfo(ReportParameterInfo[] paramInfo)
/*     */   {
/* 210 */     this.paramInfo = paramInfo;
/*     */   }
/*     */ }
