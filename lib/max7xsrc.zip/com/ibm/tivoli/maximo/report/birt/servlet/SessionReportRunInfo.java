/*    */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminServiceRemote;
/*    */ import com.ibm.tivoli.maximo.report.birt.admin.ReportRunInfo;
/*    */ import javax.servlet.http.HttpSessionBindingEvent;
/*    */ import javax.servlet.http.HttpSessionBindingListener;
/*    */ 
















/*    */ public class SessionReportRunInfo
/*    */   implements HttpSessionBindingListener
/*    */ {
/* 27 */   private ReportRunInfo reportRunInfo = null;
/* 28 */   private ReportAdminServiceRemote birtAdminService = null;
/* 29 */   private boolean cancelled = false;
/*    */ 
/*    */   public SessionReportRunInfo(ReportRunInfo reportRunInfo, ReportAdminServiceRemote birtAdminService)
/*    */   {
/* 33 */     this.reportRunInfo = reportRunInfo;
/* 34 */     this.birtAdminService = birtAdminService;
/*    */   }

/*    */   public ReportRunInfo getReportRunInfo()
/*    */   {
/* 39 */     return this.reportRunInfo;
/*    */   }

/*    */   public void setCancelled()
/*    */   {
/* 44 */     this.cancelled = true;
/*    */   }

/*    */   public Boolean isCancelled()
/*    */   {
/* 49 */     return new Boolean(this.cancelled);
/*    */   }







/*    */   public void valueUnbound(HttpSessionBindingEvent event)
/*    */   {
/*    */     try
/*    */     {
/* 62 */       this.birtAdminService.cleanupReportResources(this.reportRunInfo);
/*    */     }
/*    */     catch (Throwable e)
/*    */     {
/*    */     }
/*    */   }
/*    */ }
