package com.ibm.tivoli.maximo.report.birt.admin;

import java.rmi.RemoteException;
import psdi.util.MXException;

public abstract interface ActiveReportThreadNotifier
{
  public abstract Long addActiveThread()
    throws MXException, RemoteException;

  public abstract void removeActiveThread()
    throws MXException, RemoteException;

  public abstract void renewActiveThread()
    throws MXException, RemoteException;

  public abstract Boolean isReportJobCancelled(Long paramLong)
    throws MXException, RemoteException;
}
