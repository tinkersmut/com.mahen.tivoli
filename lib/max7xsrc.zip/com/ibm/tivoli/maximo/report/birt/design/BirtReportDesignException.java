/*    */ package com.ibm.tivoli.maximo.report.birt.design;
/*    */ 




















/*    */ public class BirtReportDesignException extends Exception
/*    */ {
/*    */   public BirtReportDesignException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BirtReportDesignException(Throwable cause)
/*    */   {
/* 31 */     super(cause);
/*    */   }

/*    */   public BirtReportDesignException(String message)
/*    */   {
/* 36 */     super(message);
/*    */   }

/*    */   public BirtReportDesignException(String message, Throwable cause)
/*    */   {
/* 41 */     super(message, cause);
/*    */   }
/*    */ }
