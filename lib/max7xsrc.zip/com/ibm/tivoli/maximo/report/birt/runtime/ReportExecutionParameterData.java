/*    */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 














/*    */ public class ReportExecutionParameterData
/*    */   implements Serializable
/*    */ {
/*    */   private HashMap reportParameterDetails;
/*    */ 
/*    */   public ReportExecutionParameterData()
/*    */   {
/* 29 */     this.reportParameterDetails = new HashMap();
/*    */   }

/*    */   public void addParameter(String paramName, Object value) {
/* 33 */     this.reportParameterDetails.put(paramName, value);
/*    */   }

/*    */   public Object getParameter(String paramName)
/*    */   {
/* 38 */     return this.reportParameterDetails.get(paramName);
/*    */   }

/*    */   public void clearParameter(String paramName)
/*    */   {
/* 43 */     this.reportParameterDetails.remove(paramName);
/*    */   }

/*    */   public void clearAllParameters()
/*    */   {
/* 48 */     this.reportParameterDetails.clear();
/*    */   }

/*    */   public Iterator getParameters()
/*    */   {
/* 53 */     return this.reportParameterDetails.keySet().iterator();
/*    */   }
/*    */ }
