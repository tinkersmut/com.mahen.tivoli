/*     */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ 










































































































































































































































/*     */ public class ReportMessageResources
/*     */ {
/*  23 */   private static HashMap<String, String> keyMappings = new HashMap();
/*     */   private static ThreadLocal<ReportMessageProvider> threadLocalMessageProvider;
/*     */ 
/*     */   public static String getMessage(String key)
/*     */   {
/* 247 */     if (keyMappings.get(key) != null)


/*     */     {
/* 251 */       if (getMessageProvider() == null)
/*     */       {
/* 253 */         System.out.println("In ReportMessageResources.java getMessageProvider() is null. So could not find message for key:" + key);
/*     */ 
/* 255 */         return null;
/*     */       }
/* 257 */       return getMessageProvider().getMessage((String)keyMappings.get(key));
/*     */     }
/*     */ 
/* 260 */     return null;
/*     */   }







/*     */   public static void setMessageProvider(ReportMessageProvider messageProvider)
/*     */   {
/* 271 */     threadLocalMessageProvider.set(messageProvider);
/*     */   }

/*     */   public static ReportMessageProvider getMessageProvider()
/*     */   {
/* 276 */     ReportMessageProvider rmp = (ReportMessageProvider)threadLocalMessageProvider.get();
/* 277 */     return rmp;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  29 */     keyMappings.put("birt.viewer.title.main", "birtMsgMainTitle");
/*  30 */     keyMappings.put("birt.viewer.title", "birtmsgTitle");
/*  31 */     keyMappings.put("birt.viewer.title.navigation", "birtmsgTitleNavigation");
/*  32 */     keyMappings.put("birt.viewer.title.error", "birtmsgTitleError");
/*  33 */     keyMappings.put("birt.viewer.title.complete", "birtmsgTitleComplete");
/*  34 */     keyMappings.put("bbirt.viewer.title.message", "birtmsgTitleMessage");
/*     */ 
/*  36 */     keyMappings.put("birt.viewer.parameter", "birtmsgParameter");
/*  37 */     keyMappings.put("birt.viewer.runreport", "birtmsgRunreport");
/*  38 */     keyMappings.put("birt.viewer.required", "birtmsgRequired");
/*     */ 
/*  40 */     keyMappings.put("birt.viewer.viewinpdf", "birtmsgViewinpdf");
/*  41 */     keyMappings.put("birt.viewer.maximize", "birtmsgMaximize");
/*  42 */     keyMappings.put("birt.viewer.restore", "birtmsgRestore");
/*     */ 
/*  44 */     keyMappings.put("birt.viewer.error", "birtmsgError");
/*  45 */     keyMappings.put("birt.viewer.error.noparameter", "birtmsgErrorNoParam");
/*  46 */     keyMappings.put("birt.viewer.error.parameter.invalid", "birtmsgErrorInvalidParam");
/*  47 */     keyMappings.put("birt.viewer.error.noprinter", "birtmsgErrorNoPrinter");
/*  48 */     keyMappings.put("birt.viewer.error.unknownerror", "birtmsgErrorunKnownError");
/*  49 */     keyMappings.put("birt.viewer.error.generatereportfirst", "birtmsgErrorGenRepFirst");
/*  50 */     keyMappings.put("birt.viewer.error.parameterrequired", "birtmsgErrorParamRequired");
/*  51 */     keyMappings.put("birt.viewer.error.parameternotallowblank", "birtmsgErrorNoBlankParam");
/*  52 */     keyMappings.put("birt.viewer.error.parameternotselected", "birtmsgErrorParamNotselected");
/*  53 */     keyMappings.put("birt.viewer.error.noviewingsession", "birtmsgErrorNoViewingSess");
/*  54 */     keyMappings.put("birt.viewer.error.viewingsessionexpired", "birtmsgErrorViewingSessExp");
/*  55 */     keyMappings.put("birt.viewer.error.viewingsessionlocked", "birtmsgErrorViewingSessLocked");
/*  56 */     keyMappings.put("birt.viewer.error.viewingsessionmaxreached", "birtmsgErrorViewSessMaxReach");
/*  57 */     keyMappings.put("birt.viewer.message.taskcanceled", "birtmsgErrorTaskCanceled");
/*     */ 
/*  61 */     keyMappings.put("birt.viewer.toolbar.print", "birtmsgToolbarPrint");
/*  62 */     keyMappings.put("birt.viewer.toolbar.printserver", "birtmsgToolbarPrintServer");
/*  63 */     keyMappings.put("birt.viewer.toolbar.toc", "birtmsgToolbarToc");
/*  64 */     keyMappings.put("birt.viewer.toolbar.parameter", "birtmsgToolbarParam");
/*  65 */     keyMappings.put("birt.viewer.toolbar.export", "birtmsgToolbarExport");
/*  66 */     keyMappings.put("birt.viewer.toolbar.font", "birtmsgToolbarFont");
/*  67 */     keyMappings.put("birt.viewer.toolbar.enableiv", "birtmsgToolbarIv");
/*  68 */     keyMappings.put("birt.viewer.toolbar.pdf", "birtmsgToolbarPDF");
/*  69 */     keyMappings.put("birt.viewer.toolbar.exportreport", "birtmsgToolbarExportReport");
/*     */ 
/*  72 */     keyMappings.put("birt.viewer.navbar.first", "birtmsgNavbarFirst");
/*  73 */     keyMappings.put("birt.viewer.navbar.previous", "birtmsgNavbarPrevious");
/*  74 */     keyMappings.put("birt.viewer.navbar.next", "birtmsgNavbarNext");
/*  75 */     keyMappings.put("birt.viewer.navbar.last", "birtmsgNavbarLast");
/*  76 */     keyMappings.put("birt.viewer.navbar.goto", "birtmsgNavbarGoto");
/*  77 */     keyMappings.put("birt.viewer.navbar.lable.goto", "birtmsgNavbarGotoLabel");
/*  78 */     keyMappings.put("birt.viewer.navbar.prompt.one", "birtmsgNavbarPrompt1");
/*  79 */     keyMappings.put("birt.viewer.navbar.prompt.page", "birtmsgNavbarPage");
/*  80 */     keyMappings.put("birt.viewer.navbar.prompt.two", "birtmsgNavbarPrompt2");
/*  81 */     keyMappings.put("birt.viewer.navbar.error.blankpagenum", "birtmsgNavbarBlankNum");
/*     */ 
/*  84 */     keyMappings.put("birt.viewer.progressbar.prompt", "birtmsgProgressPompt");
/*  85 */     keyMappings.put("birt.viewer.progressbar.confirmcanceltask", "birtmsgProgressConfCancel");
/*     */ 
/*  89 */     keyMappings.put("birt.viewer.dialog.ok", "birtmsgDlgOK");
/*  90 */     keyMappings.put("birt.viewer.dialog.cancel", "birtmsgDlgCancel");
/*  91 */     keyMappings.put("birt.viewer.dialog.run", "birtmsgDlgRun");
/*  92 */     keyMappings.put("birt.viewer.dialog.close", "birtmsgDlgClose");
/*     */ 
/*  94 */     keyMappings.put("birt.viewer.dialog.page.all", "birtmsgAllPages");
/*  95 */     keyMappings.put("birt.viewer.dialog.page.current", "birtmsgCurrentPage");
/*  96 */     keyMappings.put("birt.viewer.dialog.page.range", "birtmsgPageRange");
/*  97 */     keyMappings.put("birt.viewer.dialog.page.range.description", "birtmsgPageRangeDesc");
/*  98 */     keyMappings.put("birt.viewer.dialog.page.error.invalidpagerange", "birtmsgInvalidPageRange");
/*     */ 
/* 102 */     keyMappings.put("birt.viewer.dialog.exception.title", "birtmsgDlgExceptionTitle");
/* 103 */     keyMappings.put("birt.viewer.dialog.exportReport.title", "birtmsgDlgExpTitle");
/* 104 */     keyMappings.put("birt.viewer.dialog.parameter.title", "birtmsgDlgParamTitle");
/* 105 */     keyMappings.put("birt.viewer.dialog.simpleExportData.title", "birtmsgDlgExpDataTitle");
/* 106 */     keyMappings.put("birt.viewer.dialog.printReport.title", "birtmsgPrintReportTitle");
/* 107 */     keyMappings.put("birt.viewer.dialog.printReportServer.title", "birtmsgPrintServerTitle");
/*     */ 
/* 110 */     keyMappings.put("birt.viewer.dialog.export.format", "birtmsgDlgExpFormat");
/* 111 */     keyMappings.put("birt.viewer.dialog.export.format.pdf", "birtmsgDlgExpFormatPDF");
/* 112 */     keyMappings.put("birt.viewer.dialog.export.format.excel", "birtmsgDlgFormatExcel");
/* 113 */     keyMappings.put("birt.viewer.dialog.export.all", "birtmsgDlgExpAll");
/* 114 */     keyMappings.put("birt.viewer.dialog.export.all.detail", "birtmsgDlgExpAllDetail");
/* 115 */     keyMappings.put("birt.viewer.dialog.export.modified", "birtmsgDlgExpMod");
/* 116 */     keyMappings.put("birt.viewer.dialog.export.modified.detail", "birtmsgDlgExpModDetail");
/*     */ 
/* 118 */     keyMappings.put("birt.viewer.dialog.export.pdf.fittoauto", "birtmsgDlgPdfAuto");
/* 119 */     keyMappings.put("birt.viewer.dialog.export.pdf.fittoactual", "birtmsgDlgPdfActual");
/* 120 */     keyMappings.put("birt.viewer.dialog.export.pdf.fittowidth", "birtmsgDlgPdfFitWidth");
/* 121 */     keyMappings.put("birt.viewer.dialog.export.pdf.fittowhole", "birtmsgDlgPdfFitWhole");
/*     */ 
/* 124 */     keyMappings.put("birt.viewer.dialog.print.format", "birtmsgDlgPrintFormat");
/* 125 */     keyMappings.put("birt.viewer.dialog.print.format.html", "birtmsgDlgPrintHtml");
/* 126 */     keyMappings.put("birt.viewer.dialog.print.format.pdf", "birtmsgDlgPrintPdf");
/* 127 */     keyMappings.put("birt.viewer.dialog.print.printpreviewalreadyopen", "birtmsgDlgPrintPrevOpen");
/*     */ 
/* 130 */     keyMappings.put("birt.viewer.dialog.printserver.onserver", "birtmsgDlgPSrvOnserver");
/* 131 */     keyMappings.put("birt.viewer.dialog.printserver.printer", "birtmsgDlgPSrvPrinter");
/* 132 */     keyMappings.put("birt.viewer.dialog.printserver.status", "birtmsgDlgPSrvStatus");
/* 133 */     keyMappings.put("birt.viewer.dialog.printserver.model", "birtmsgDlgPSrvModel");
/* 134 */     keyMappings.put("birt.viewer.dialog.printserver.description", "birtmsgDlgPSrvDesc");
/* 135 */     keyMappings.put("birt.viewer.dialog.printserver.status.acceptingjobs", "birtmsgAcceptJobs");
/* 136 */     keyMappings.put("birt.viewer.dialog.printserver.status.notacceptingjobs", "birtmsgNotAcceptJobs");
/*     */ 
/* 138 */     keyMappings.put("birt.viewer.dialog.printserver.settings", "birtmsgDlgPSrvSettings");
/* 139 */     keyMappings.put("birt.viewer.dialog.printserver.settings.copies", "birtmsgDlgPSrvCopies");
/* 140 */     keyMappings.put("birt.viewer.dialog.printserver.settings.collate", "birtmsgDlgPSrvCollate");
/* 141 */     keyMappings.put("birt.viewer.dialog.printserver.settings.mode", "birtmsgDlgPSrvMode");
/* 142 */     keyMappings.put("birt.viewer.dialog.printserver.settings.mode.bw", "birtmsgDlgPSrvBW");
/* 143 */     keyMappings.put("birt.viewer.dialog.printserver.settings.mode.color", "birtmsgDlgPSrvColor");
/* 144 */     keyMappings.put("birt.viewer.dialog.printserver.settings.duplex", "birtmsgDlgPSrvDuplex");
/* 145 */     keyMappings.put("birt.viewer.dialog.printserver.settings.duplex.simplex", "birtmsgDlgPSrvSimplex");
/* 146 */     keyMappings.put("birt.viewer.dialog.printserver.settings.duplex.horizontal", "birtmsgDlgPSrvHoriz");
/* 147 */     keyMappings.put("birt.viewer.dialog.printserver.settings.duplex.vertical", "birtmsgDlgPSrvVertical");
/* 148 */     keyMappings.put("birt.viewer.dialog.printserver.settings.pagesize", "birtmsgDlgPSrvPazeSize");
/* 149 */     keyMappings.put("birt.viewer.dialog.printserver.settings.print", "birtmsgDlgPSrvPrint");
/*     */ 
/* 151 */     keyMappings.put("birt.viewer.dialog.printserver.complete", "birtmsgDlgPSrvComplete");
/* 152 */     keyMappings.put("birt.viewer.dialog.printserver.error.noprinter", "birtmsgDlgPSrvNoPrinter");
/*     */ 
/* 155 */     keyMappings.put("birt.viewer.dialog.confirmation.title", "birtmsgDlgPSrvConfTitle");
/*     */ 
/* 161 */     keyMappings.put("birt.viewer.dialog.exportdata.tab.field", "birtmsgDlgExpDataTabField");
/* 162 */     keyMappings.put("birt.viewer.dialog.exportdata.tab.filter", "birtmsgDlgExpDataTabFilter");
/* 163 */     keyMappings.put("birt.viewer.dialog.exportdata.resultsets", "birtmsgDlgExpDataRes");
/* 164 */     keyMappings.put("birt.viewer.dialog.exportdata.availablecolumn", "birtmsgDlgExpDataAvailCol");
/* 165 */     keyMappings.put("birt.viewer.dialog.exportdata.selectedcolumn", "birtmsgDlgExpDataSelCol");
/*     */ 
/* 167 */     keyMappings.put("birt.viewer.dialog.exportdata.extension", "birtmsgDlgExpDataExt");
/* 168 */     keyMappings.put("birt.viewer.dialog.exportdata.encoding", "birtmsgDlgExpDataEncoding");
/* 169 */     keyMappings.put("birt.viewer.dialog.exportdata.encoding.other", "birtmsgDlgExpDataOther");
/* 170 */     keyMappings.put("birt.viewer.dialog.exportdata.encoding.comment", "birtmsgDlgExpDataComment");
/*     */ 
/* 172 */     keyMappings.put("birt.viewer.dialog.exportdata.format", "birtmsgDlgExpDataFormat");
/* 173 */     keyMappings.put("birt.viewer.dialog.exportdata.addall", "birtmsgDlgExpDataAddAll");
/* 174 */     keyMappings.put("birt.viewer.dialog.exportdata.add", "birtmsgDlgExpDataAdd");
/* 175 */     keyMappings.put("birt.viewer.dialog.exportdata.removeall", "birtmsgDlgExpDataRemoveAll");
/* 176 */     keyMappings.put("birt.viewer.dialog.exportdata.remove", "birtmsgDlgExpDataRemove");
/* 177 */     keyMappings.put("birt.viewer.dialog.exportdata.up", "birtmsgDlgExpDataUp");
/* 178 */     keyMappings.put("birt.viewer.dialog.exportdata.down", "birtmsgDlgExpDataDown");
/* 179 */     keyMappings.put("birt.viewer.dialog.exportdata.separator", "birtmsgDlgExpDataSeparator");
/* 180 */     keyMappings.put("birt.viewer.dialog.exportdata.datatype", "birtmsgDlgExpDataDataType");
/* 181 */     keyMappings.put("birt.viewer.dialog.exportdata.localeneutral", "birtmsgDlgExpDataLocNut");
/*     */ 
/* 184 */     keyMappings.put("birt.viewer.sep.0", "birtmsgSep0");
/* 185 */     keyMappings.put("birt.viewer.sep.1", "birtmsgSep1");
/* 186 */     keyMappings.put("birt.viewer.sep.2", "birtmsgSep2");
/* 187 */     keyMappings.put("birt.viewer.sep.3", "birtmsgSep3");
/* 188 */     keyMappings.put("birt.viewer.sep.4", "birtmsgSep4");
/*     */ 
/* 191 */     keyMappings.put("birt.viewer.generalException.DOCUMENT_FILE_ERROR", "birtmsgExcepDocFileError");
/* 192 */     keyMappings.put("birt.viewer.generalException.DOCUMENT_ACCESS_ERROR", "birtmsgExcepDocAccessError");
/* 193 */     keyMappings.put("birt.viewer.generalException.REPORT_FILE_ERROR", "birtmsgExcepRepFileError");
/* 194 */     keyMappings.put("birt.viewer.generalException.REPORT_ACCESS_ERROR", "birtmsgExcepRepAccessError");
/* 195 */     keyMappings.put("birt.viewer.generalException.DOCUMENT_FILE_PROCESSING", "birtmsgExcepDocFileProcess");
/* 196 */     keyMappings.put("birt.viewer.generalException.NO_REPORT_DESIGN", "birtmsgExcepNoRepDesign");
/* 197 */     keyMappings.put("birt.viewer.generalException.MULTIPLE_EXCEPTIONS", "birtmsgExcepMultExce");
/*     */ 
/* 200 */     keyMappings.put("birt.viewer.reportServiceException.EXTRACT_DATA_NO_DOCUMENT", "birtmsgExcepRSExtractNoDoc");
/* 201 */     keyMappings.put("birt.viewer.reportServiceException.EXTRACT_DATA_NO_RESULT_SET", "birtmsgExcepRSExtractNoRes");
/* 202 */     keyMappings.put("birt.viewer.reportServiceException.INVALID_TOC", "birtmsgExcepRSInvalidToc");
/* 203 */     keyMappings.put("birt.viewer.reportServiceException.INVALID_PARAMETER", "birtmsgExcepRSInvalidParam");
/* 204 */     keyMappings.put("birt.viewer.reportServiceException.STARTUP_REPORTENGINE_ERROR", "birtmsgExcepStartErr");
/*     */ 
/* 206 */     keyMappings.put("birt.viewer.reportServiceException.INVALID_EXTRACTFORMAT", "birtmsgExcepInvalidExtFormat");
/* 207 */     keyMappings.put("birt.viewer.reportServiceException.INVALID_EXTRACTEXTENSION", "birtmsgExcepInvalidExtExtn");
/*     */ 
/* 212 */     keyMappings.put("birt.viewer.actionException.NO_REPORT_DOCUMENT", "birtmsgExcepActNoRepDoc");
/* 213 */     keyMappings.put("birt.viewer.actionException.INVALID_BOOKMARK", "birtmsgExcepActInvalidBookmark");
/* 214 */     keyMappings.put("birt.viewer.actionException.INVALID_PAGE_NUMBER", "birtmsgExcepActInvalidPageNum");
/* 215 */     keyMappings.put("birt.viewer.actionException.INVALID_ID_FORMAT", "birtmsgExcepActInvalidIdFormat");
/* 216 */     keyMappings.put("birt.viewer.actionException.DOCUMENT_FILE_NO_EXIST", "birtmsgExcepActNoDocFile");
/*     */ 
/* 219 */     keyMappings.put("birt.viewer.soapBindingException.NO_HANDLER_FOR_TARGET", "birtmsgExcepSBNoHandler");
/*     */ 
/* 222 */     keyMappings.put("birt.viewer.componentProcessorException.MISSING_OPERATOR", "birtmsgExcepSBNoHandler");
/*     */ 
/* 225 */     keyMappings.put("birt.viewer.exceptionDialog.stackTrace", "birtmsgExcepDlgStacktrace");
/* 226 */     keyMappings.put("birt.viewer.exceptionDialog.showStackTrace", "birtmsgExcepDlgShowStacktrace");
/* 227 */     keyMappings.put("birt.viewer.exceptionDialog.hideStackTrace", "birtmsgExcepDlgHideStacktrace");
/*     */ 
/* 230 */     keyMappings.put("birt.viewer.taglib.NO_ATTR_ID", "birtmsgJspTaglibNoAttr");
/* 231 */     keyMappings.put("birt.viewer.taglib.INVALID_ATTR_ID", "birtmsgJspTaglibInvalidAttr");
/* 232 */     keyMappings.put("birt.viewer.taglib.ATTR_ID_DUPLICATE", "birtmsgJspTaglibDupAttr");
/* 233 */     keyMappings.put("birt.viewer.taglib.PARAM_NAME_DUPLICATE", "birtmsgJspTaglibDupParam");
/* 234 */     keyMappings.put("birt.viewer.taglib.NO_REPORT_SOURCE", "birtmsgJspTaglibNoRptSrc");
/* 235 */     keyMappings.put("birt.viewer.taglib.NO_REPORT_DOCUMENT", "birtmsgJspTaglibNoRptDoc");
/* 236 */     keyMappings.put("birt.viewer.taglib.NO_REQUESTER_NAME", "birtmsgJspTaglibNoReqname");
/*     */ 
/* 239 */     keyMappings.put("birt.viewer.message.document.successful", "birtmsgDocSuccess");
/*     */ 
/* 242 */     keyMappings.put("birt.viewer.exception.maybe_disabled_cookies", "birtmsgExcookiesDis");
/*     */ 
/* 267 */     threadLocalMessageProvider = new ThreadLocal();
/*     */   }
/*     */ }
