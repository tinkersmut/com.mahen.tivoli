/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ActiveReportThreadNotifier;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminServiceRemote;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.util.MXException;
/*     */ 


















/*     */ public class ImmediateActiveReportThreadNotifier
/*     */   implements ActiveReportThreadNotifier
/*     */ {
/*     */   private ReportAdminServiceRemote birtAdminService;
/*     */   private String threadName;
/*     */   private String reportName;
/*     */   private String appName;
/*     */   private String userName;
/*     */ 
/*     */   public ReportAdminServiceRemote getBirtAdminService()
/*     */   {
/*  37 */     return this.birtAdminService;
/*     */   }

/*     */   public void setBirtAdminService(ReportAdminServiceRemote birtAdminService)
/*     */   {
/*  42 */     this.birtAdminService = birtAdminService;
/*     */   }

/*     */   public String getAppName()
/*     */   {
/*  47 */     return this.appName;
/*     */   }

/*     */   public void setAppName(String appName)
/*     */   {
/*  52 */     this.appName = appName;
/*     */   }

/*     */   public String getReportName()
/*     */   {
/*  57 */     return this.reportName;
/*     */   }

/*     */   public void setReportName(String reportName)
/*     */   {
/*  62 */     this.reportName = reportName;
/*     */   }

/*     */   public String getThreadName()
/*     */   {
/*  67 */     return this.threadName;
/*     */   }

/*     */   public void setThreadName(String threadName)
/*     */   {
/*  72 */     this.threadName = threadName;
/*     */   }

/*     */   public String getUserName()
/*     */   {
/*  77 */     return this.userName;
/*     */   }

/*     */   public void setUserName(String userName)
/*     */   {
/*  82 */     this.userName = userName;
/*     */   }

/*     */   public Long addActiveThread()
/*     */     throws MXException, RemoteException
/*     */   {
/*  88 */     this.threadName = Thread.currentThread().getName();
/*     */ 
/*  90 */     return this.birtAdminService.addActiveThread(this.threadName, this.reportName, this.appName, this.userName, false);
/*     */   }

/*     */   public void removeActiveThread()
/*     */     throws MXException, RemoteException
/*     */   {
/*  96 */     this.birtAdminService.removeActiveThread(this.threadName);
/*     */   }

/*     */   public void renewActiveThread()
/*     */     throws MXException, RemoteException
/*     */   {
/* 102 */     this.birtAdminService.renewActiveThread(this.threadName);
/*     */   }

/*     */   public Boolean isReportJobCancelled(Long reportJobId)
/*     */     throws MXException, RemoteException
/*     */   {
/* 108 */     return new Boolean(this.birtAdminService.isReportJobCancelled(reportJobId.longValue()));
/*     */   }
/*     */ }
