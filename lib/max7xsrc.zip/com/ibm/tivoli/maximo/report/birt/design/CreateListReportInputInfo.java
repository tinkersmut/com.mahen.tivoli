/*     */ package com.ibm.tivoli.maximo.report.birt.design;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 












/*     */ public class CreateListReportInputInfo
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private int objectID;
/*     */   private String mboName;
/*     */   private String entityName;
/*     */   private String fixedQueryWhereClause;
/*     */   private List<CreateListReportDataColumnInputInfo> dcInfoList;
/*     */   private List<CreateReportRelationshipInfo> relationList;
/*     */   private String headerText;
/*     */   private String linkRelation;
/*     */   private ArrayList<String> bindParamList;
/*     */   private ArrayList<Integer> includedObjectList;
/*     */ 
/*     */   public CreateListReportInputInfo()
/*     */   {
/*  36 */     this.mboName = null;

/*     */ 
/*  39 */     this.entityName = null;


/*     */ 
/*  43 */     this.fixedQueryWhereClause = null;

/*     */ 
/*  46 */     this.dcInfoList = new ArrayList();

/*     */ 
/*  49 */     this.relationList = new ArrayList();

/*     */ 
/*  52 */     this.headerText = null;


/*     */ 
/*  56 */     this.linkRelation = null;



/*     */ 
/*  61 */     this.bindParamList = new ArrayList();


/*     */ 
/*  65 */     this.includedObjectList = new ArrayList();
/*     */   }





/*     */   public int getObjectID()
/*     */   {
/*  74 */     return this.objectID;
/*     */   }

/*     */   public void setObjectID(int objectID)
/*     */   {
/*  79 */     this.objectID = objectID;
/*     */   }

/*     */   public String getMboName()
/*     */   {
/*  84 */     return this.mboName;
/*     */   }

/*     */   public void setMboName(String mboName)
/*     */   {
/*  89 */     this.mboName = mboName;
/*     */   }

/*     */   public String getEntityName()
/*     */   {
/*  94 */     return this.entityName;
/*     */   }

/*     */   public void setEntityName(String entityName)
/*     */   {
/*  99 */     this.entityName = entityName;
/*     */   }

/*     */   public String getFixedQueryWhereClause()
/*     */   {
/* 104 */     return this.fixedQueryWhereClause;
/*     */   }

/*     */   public void setFixedQueryWhereClause(String fixedQueryWhereClause)
/*     */   {
/* 109 */     this.fixedQueryWhereClause = fixedQueryWhereClause;
/*     */   }

/*     */   public void addDataColumnInputInfo(CreateListReportDataColumnInputInfo info)
/*     */   {
/* 114 */     this.dcInfoList.add(info);
/*     */   }

/*     */   public void removeDataColumnInputInfo(String mboAttributeName, String mboName)
/*     */   {
/* 119 */     int size = this.dcInfoList.size();
/* 120 */     for (int i = 0; i < size; ++i)
/*     */     {
/* 122 */       CreateListReportDataColumnInputInfo info = (CreateListReportDataColumnInputInfo)this.dcInfoList.get(i);
/* 123 */       if ((!(info.getMboAttributeName().equalsIgnoreCase(mboAttributeName))) || (!(info.getMboName().equalsIgnoreCase(mboName)))) {
/*     */         continue;
/*     */       }
/* 126 */       this.dcInfoList.remove(i);
/* 127 */       return;
/*     */     }
/*     */   }


/*     */   public Iterator getAllDataColumnInputInfo()
/*     */   {
/* 134 */     return this.dcInfoList.iterator();
/*     */   }

/*     */   public boolean includesDataColumn(String objectName, String attributeName)
/*     */   {
/* 139 */     int size = this.dcInfoList.size();
/* 140 */     for (int i = 0; i < size; ++i)
/*     */     {
/* 142 */       CreateListReportDataColumnInputInfo info = (CreateListReportDataColumnInputInfo)this.dcInfoList.get(i);
/* 143 */       if ((info.getMboAttributeName().equalsIgnoreCase(attributeName)) && (info.getMboName().equalsIgnoreCase(objectName)))

/*     */       {
/* 146 */         return true;
/*     */       }
/*     */     }
/* 149 */     return false;
/*     */   }

/*     */   public void addRelationshipInfo(CreateReportRelationshipInfo info)
/*     */   {
/* 154 */     this.relationList.add(info);
/*     */   }

/*     */   public Iterator getAllRelationshipInfo()
/*     */   {
/* 159 */     return this.relationList.iterator();
/*     */   }

/*     */   public String getWhereClause(String parent, String child)
/*     */   {
/* 164 */     int size = this.relationList.size();
/* 165 */     for (int i = 0; i < size; ++i)
/*     */     {
/* 167 */       CreateReportRelationshipInfo relation = (CreateReportRelationshipInfo)this.relationList.get(i);
/* 168 */       if ((relation.getParentObjectName().equalsIgnoreCase(parent)) && (relation.getChildObjectName().equalsIgnoreCase(child)))

/*     */       {
/* 171 */         return relation.getWhereClause();
/*     */       }
/*     */     }
/*     */ 
/* 175 */     return "1=1";
/*     */   }

/*     */   public String getLinkRelation()
/*     */   {
/* 180 */     return this.linkRelation;
/*     */   }

/*     */   public void setLinkRelation(String linkRelation)
/*     */   {
/* 185 */     this.linkRelation = linkRelation;
/*     */   }

/*     */   public void addBindParam(String attributeName)
/*     */   {
/* 190 */     this.bindParamList.add(attributeName);
/*     */   }

/*     */   public Iterator getAllBindParams()
/*     */   {
/* 195 */     return this.bindParamList.iterator();
/*     */   }

/*     */   public ArrayList<String> getBindParamList()
/*     */   {
/* 200 */     return this.bindParamList;
/*     */   }

/*     */   public void addIncludedObject(Integer objectID)
/*     */   {
/* 205 */     this.includedObjectList.add(objectID);
/*     */   }

/*     */   public boolean isObjectIncluded(int objectID)
/*     */   {
/* 210 */     return this.includedObjectList.contains(Integer.valueOf(objectID));
/*     */   }

/*     */   public String getHeaderText()
/*     */   {
/* 215 */     return this.headerText;
/*     */   }

/*     */   public void setHeaderText(String headerText)
/*     */   {
/* 220 */     this.headerText = headerText;
/*     */   }

/*     */   public boolean isAttributeIncluded(String attributeName)
/*     */   {
/* 225 */     int size = this.dcInfoList.size();
/* 226 */     int i = 0; if (i < size)
/*     */     {
/* 228 */       CreateListReportDataColumnInputInfo dcInfo = (CreateListReportDataColumnInputInfo)this.dcInfoList.get(i);
/* 229 */       if ((dcInfo.getMboName().equalsIgnoreCase(getMboName())) && (dcInfo.getMboAttributeName().equalsIgnoreCase(attributeName)));


/* 232 */       return true;
/*     */     }
/*     */ 
/* 235 */     return false;
/*     */   }

/*     */   public Object clone()
/*     */   {
/* 240 */     CreateListReportInputInfo clone = new CreateListReportInputInfo();
/*     */ 
/* 242 */     clone.objectID = this.objectID;
/* 243 */     clone.entityName = this.entityName;
/* 244 */     clone.fixedQueryWhereClause = this.fixedQueryWhereClause;
/* 245 */     clone.mboName = this.mboName;
/*     */ 
/* 247 */     clone.linkRelation = this.linkRelation;
/* 248 */     clone.headerText = this.headerText;
/* 249 */     clone.bindParamList = this.bindParamList;

/*     */ 
/* 252 */     int size = this.dcInfoList.size();
/* 253 */     for (int i = 0; i < size; ++i)
/*     */     {
/* 255 */       CreateListReportDataColumnInputInfo dcInfo = (CreateListReportDataColumnInputInfo)this.dcInfoList.get(i);
/* 256 */       CreateListReportDataColumnInputInfo cloneDCInfo = (CreateListReportDataColumnInputInfo)dcInfo.clone();
/*     */ 
/* 258 */       clone.addDataColumnInputInfo(cloneDCInfo);
/*     */     }
/*     */ 
/* 261 */     size = this.relationList.size();
/* 262 */     for (int i = 0; i < size; ++i)
/*     */     {
/* 264 */       CreateReportRelationshipInfo relationInfo = (CreateReportRelationshipInfo)this.relationList.get(i);
/* 265 */       CreateReportRelationshipInfo cloneRelationInfo = (CreateReportRelationshipInfo)relationInfo.clone();
/*     */ 
/* 267 */       clone.addRelationshipInfo(cloneRelationInfo);
/*     */     }
/*     */ 
/* 270 */     return clone;
/*     */   }
/*     */ }
