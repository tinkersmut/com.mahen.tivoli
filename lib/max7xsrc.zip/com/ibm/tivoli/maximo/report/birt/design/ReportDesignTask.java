package com.ibm.tivoli.maximo.report.birt.design;

import java.util.Locale;

public abstract interface ReportDesignTask
{
  public abstract ReportDesign openReportDesign(String paramString1, String paramString2, Locale paramLocale)
    throws BirtReportDesignException;

  public abstract void createReportDesign(CreateReportInputInfo paramCreateReportInputInfo, String paramString1, String paramString2, Locale paramLocale)
    throws BirtReportDesignException;

  public abstract boolean updateReportDesign(String paramString1, String paramString2, Locale paramLocale)
    throws BirtReportDesignException;
}
