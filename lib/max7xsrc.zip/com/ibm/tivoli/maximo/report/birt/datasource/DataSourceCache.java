/*     */ package com.ibm.tivoli.maximo.report.birt.datasource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import psdi.mbo.MaximoCache;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.MXServerInfo;
/*     */ import psdi.server.MaxPropCache;
/*     */ import psdi.server.MaximoThread;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 










/*     */ public class DataSourceCache
/*     */   implements MaximoCache
/*     */ {
/*  35 */   private static DataSourceCache dataSourceCache = new DataSourceCache();
/*     */ 
/*  42 */   private HashMap<String, DataSourceConnectionPool> dsConnectionPoolMap = new HashMap();
/*  43 */   private DataSourceConnectionPool mxDataSourceConnectionPool = null;
/*  44 */   private ConnectionPoolManager connectionPoolMgr = null;
/*  45 */   private boolean initialized = false;
/*     */ 
/*     */   public static DataSourceCache getDataSourceCache()
/*     */   {
/*  39 */     return dataSourceCache;
/*     */   }






/*     */   private DataSourceCache()
/*     */   {
/*  49 */     this.connectionPoolMgr = new ConnectionPoolManager();
/*  50 */     this.connectionPoolMgr.start();
/*     */   }

/*     */   public String getName()
/*     */   {
/*  55 */     return "REPORTDATASOURCE";
/*     */   }

/*     */   public void init() throws MXException
/*     */   {
/*  60 */     MXServerInfo serverInfo = MXServerInfo.getMXServerInfo();
/*     */ 
/*  62 */     boolean ready = serverInfo.isRunning();
/*     */ 
/*  64 */     if (!(ready))
/*     */     {
/*  66 */       return;

/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  72 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/*  74 */       MaxPropCache propCache = (MaxPropCache)MXServer.getMXServer().getFromMaximoCache("MAXPROP");



/*     */ 
/*  79 */       String mxDriver = propCache.getProperty("mxe.db.driver");
/*  80 */       String mxUrl = propCache.getProperty("mxe.db.url");
/*  81 */       String mxUserName = propCache.getProperty("mxe.db.user");
/*  82 */       String mxPassword = propCache.getProperty("mxe.db.password");
/*  83 */       String mxSchemaOwner = propCache.getProperty("mxe.db.schemaowner");
/*     */ 
/*  85 */       DataSourceInfo mxDSInfo = new DataSourceInfo();
/*  86 */       mxDSInfo.setName("MAXIMO");
/*  87 */       mxDSInfo.setDriver(mxDriver);
/*  88 */       mxDSInfo.setUrl(mxUrl);
/*  89 */       mxDSInfo.setUserName(mxUserName);
/*  90 */       mxDSInfo.setPassword(mxPassword);
/*  91 */       mxDSInfo.setSchemaOwner(mxSchemaOwner);

/*     */ 
/*  94 */       String mxSslConnection = propCache.getProperty("mxe.db.DB2sslConnection");
/*  95 */       String mxSslTrustStoreLocation = propCache.getProperty("mxe.db.DB2sslTrustStoreLocation");
/*  96 */       String mxSslTrustStorePassword = propCache.getProperty("mxe.db.DB2sslTrustStorePassword");
/*  97 */       mxDSInfo.setSslConnection(mxSslConnection);
/*  98 */       mxDSInfo.setSslTrustStoreLocation(mxSslTrustStoreLocation);
/*  99 */       mxDSInfo.setSslTrustStorePassword(mxSslTrustStorePassword);

/*     */ 
/* 102 */       this.mxDataSourceConnectionPool = new DataSourceConnectionPool(mxDSInfo);
/*     */ 
/* 104 */       loadAllDataSources();
/*     */ 
/* 106 */       this.initialized = true;
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 110 */       throw new MXApplicationException("reports", "datasourcecachefailed", e);
/*     */     }
/*     */   }

/*     */   public boolean isInitialized()
/*     */   {
/* 116 */     return this.initialized;
/*     */   }

/*     */   public void reload() throws MXException
/*     */   {
/* 121 */     synchronized (this.dsConnectionPoolMap)
/*     */     {
/* 123 */       Iterator dsConPoolIterator = this.dsConnectionPoolMap.values().iterator();
/* 124 */       while (dsConPoolIterator.hasNext())
/*     */       {
/* 126 */         DataSourceConnectionPool pool = (DataSourceConnectionPool)dsConPoolIterator.next();
/* 127 */         pool.destroy();

/*     */       }
/*     */ 
/* 131 */       this.dsConnectionPoolMap.clear();
/*     */     }
/*     */ 
/* 134 */     loadAllDataSources();
/*     */   }






/*     */   private void loadAllDataSources()
/*     */     throws MXException
/*     */   {
/*     */     try
/*     */     {
/* 147 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/* 149 */       MboSetRemote reportDSSet = mxServer.getMboSet("REPORTDS", mxServer.getSystemUserInfo());
/* 150 */       int i = 0;
/*     */       while (true)
/*     */       {
/* 153 */         MboRemote reportDS = reportDSSet.getMbo(i);
/* 154 */         if (reportDS == null)


/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/* 161 */         MboSetRemote reportDSParamSet = reportDS.getMboSet("REPORTDSPARAM");
/*     */ 
/* 163 */         MboRemote reportDSParam = reportDSParamSet.getMbo(0);
/* 164 */         if (reportDSParam != null)

/*     */         {
/* 167 */           DataSourceInfo dsInfo = new DataSourceInfo();
/* 168 */           dsInfo.setName(reportDS.getString("DATASOURCENAME"));
/* 169 */           dsInfo.setDriver(reportDSParam.getString("DRIVER"));
/* 170 */           dsInfo.setUrl(reportDSParam.getString("URL"));
/* 171 */           dsInfo.setUserName(reportDSParam.getString("USERNAME"));
/* 172 */           dsInfo.setPassword(reportDSParam.getString("PASSWORD"));
/* 173 */           dsInfo.setSchemaOwner(reportDSParam.getString("SCHEMAOWNER"));

/*     */ 
/* 176 */           DataSourceConnectionPool dsPool = new DataSourceConnectionPool(dsInfo);
/*     */ 
/* 178 */           synchronized (this.dsConnectionPoolMap)
/*     */           {
/* 180 */             this.dsConnectionPoolMap.put(reportDS.getString("DATASOURCENAME"), dsPool);
/*     */           }
/*     */         }
/*     */ 
/* 184 */         ++i;
/*     */       }
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 189 */       throw new MXApplicationException("reports", "datasourcecachefailed", e);
/*     */     }
/*     */   }

/*     */   public DataSourceConnectionPool getDataSourceConnectionPool(String name)
/*     */   {
/* 195 */     if (!(isInitialized()))
/*     */     {
/*     */       try
/*     */       {
/* 199 */         init();
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 207 */     DataSourceConnectionPool dsPool = null;
/*     */ 
/* 209 */     synchronized (this.dsConnectionPoolMap)
/*     */     {
/* 211 */       dsPool = (DataSourceConnectionPool)this.dsConnectionPoolMap.get(name);
/*     */     }
/*     */ 
/* 214 */     if (dsPool == null)
/*     */     {
/* 216 */       dsPool = this.mxDataSourceConnectionPool;
/*     */     }
/*     */ 
/* 219 */     return dsPool;
/*     */   }

/*     */   class ConnectionPoolManager extends MaximoThread
/*     */   {
/*     */     public ConnectionPoolManager()
/*     */     {
/* 226 */       super("REPORTCONPOOLMGR");
/*     */     }

/*     */     public void run()
/*     */     {
/*     */       label159: 
/*     */       while (true)
/*     */         try
/*     */         {
/* 235 */           Thread.sleep(60000L);
/*     */ 
/* 237 */           if (isReady());




/* 242 */           ArrayList poolList = new ArrayList();
/*     */ 
/* 244 */           synchronized (DataSourceCache.this.dsConnectionPoolMap)
/*     */           {
/* 246 */             Iterator dsConPoolIterator = DataSourceCache.this.dsConnectionPoolMap.values().iterator();
/* 247 */             while (dsConPoolIterator.hasNext())
/*     */             {
/* 249 */               DataSourceConnectionPool pool = (DataSourceConnectionPool)dsConPoolIterator.next();
/* 250 */               poolList.add(pool);
/*     */             }
/*     */           }
/*     */ 
/* 254 */           for (int i = 0; i < poolList.size(); ++i)
/*     */           {
/* 256 */             DataSourceConnectionPool pool = (DataSourceConnectionPool)poolList.get(i);
/* 257 */             pool.adjustPool();
/*     */           }
/*     */ 
/* 260 */           DataSourceCache.this.mxDataSourceConnectionPool.adjustPool();
/*     */         }
/*     */         catch (InterruptedException iex)
/*     */         {
/* 264 */           if (isMarkedForShutDown())
/*     */           {
/* 266 */             return;
/*     */           }
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 271 */           if (!(isMarkedForShutDown()))
/*     */             break label159;
/*     */         }
/*     */     }





/*     */     boolean isReady()
/*     */     {
/* 282 */       MXServerInfo serverInfo = MXServerInfo.getMXServerInfo();
/*     */ 
/* 284 */       boolean ready = serverInfo.isRunning();
/*     */ 
/* 286 */       return ready;
/*     */     }
/*     */   }
/*     */ }
