/*    */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*    */ 





















/*    */ public class ReportExecutionException extends Exception
/*    */ {
/*    */   public ReportExecutionException(String message)
/*    */   {
/* 28 */     super(message);
/*    */   }

/*    */   public ReportExecutionException(String message, Throwable cause)
/*    */   {
/* 33 */     super(message, cause);
/*    */   }
/*    */ }
