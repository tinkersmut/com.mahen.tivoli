/*    */ package com.ibm.tivoli.maximo.report.birt.logging;
/*    */ 

















/*    */ public class ReportLoggerFactory
/*    */ {
/* 22 */   private static ReportLoggerProvider loggerProvider = null;
/*    */ 
/*    */   public static ReportLogger getLogger(String name)
/*    */   {
/* 26 */     return loggerProvider.getLogger(name);
/*    */   }

/*    */   public static void setReportLoggerProvider(ReportLoggerProvider provider)
/*    */   {
/* 31 */     loggerProvider = provider;
/*    */   }
/*    */ }
