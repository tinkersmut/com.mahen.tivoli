/*    */ package com.ibm.tivoli.maximo.report.birt.session;
/*    */ 
/*    */ import psdi.util.MXSession;
/*    */ import psdi.util.MXSessionImplFactory;
/*    */ 

























/*    */ public class SimpleWebAppSessionFactory
/*    */   implements MXSessionImplFactory
/*    */ {
/*    */   public MXSession getSession()
/*    */   {
/* 36 */     return new SimpleWebAppSession();
/*    */   }






/*    */   public MXSession getNewSession()
/*    */   {
/* 46 */     return new SimpleWebAppSession();
/*    */   }
/*    */ }
