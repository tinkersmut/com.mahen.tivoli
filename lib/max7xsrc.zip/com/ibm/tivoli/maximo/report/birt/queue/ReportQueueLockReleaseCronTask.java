/*     */ package com.ibm.tivoli.maximo.report.birt.queue;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import psdi.app.system.CrontaskInstanceRemote;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.SimpleCronTask;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
















/*     */ public class ReportQueueLockReleaseCronTask extends SimpleCronTask
/*     */ {
/*     */   private static final long ONEMINUTE_IN_MILLIS = 60000L;
/*     */   private MboRemote parameterValidationMbo;
/*     */ 
/*     */   public void cronAction()
/*     */   {
/*  38 */     MXLogger logger = getCronTaskLogger();
/*     */ 
/*  40 */     if (logger.isDebugEnabled())
/*     */     {
/*  42 */       logger.debug("performing cronAction of ReportQueueLockReleaseCronTask");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  47 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/*  49 */       int lockInterval = getParamAsInt("LOCKINTERVALINMINUTES");
/*     */ 
/*  51 */       Date currentTime = mxServer.getDate();
/*  52 */       long cleaupTime = currentTime.getTime() - (lockInterval * 60000L);
/*  53 */       String timeFunction = SqlFormat.getTimestampFunction(new Date(cleaupTime));
/*     */ 
/*  55 */       MboSetRemote msr = mxServer.getMboSet("REPORTRUNLOCK", getUserInfo());


/*     */       while (true)
/*     */       {
/*  60 */         msr.setWhere("locktime is not null and (locktime < " + timeFunction + " )");
/*  61 */         msr.reset();
/*     */ 
/*  63 */         MboRemote mr = msr.getMbo(0);
/*  64 */         if (mr == null)

/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/*  70 */         for (int i = 0; i < 10; ++i)
/*     */         {
/*  72 */           MboRemote mrLock = msr.getMbo(i);
/*  73 */           if (mrLock == null)

/*     */           {
/*     */             break;
/*     */           }
/*     */ 
/*  79 */           mrLock.delete();

/*     */ 
/*  82 */           MboSetRemote msrQ = mrLock.getMboSet("REPORTRUNQUEUE");
/*  83 */           MboRemote mrQ = msrQ.getMbo(0);
/*  84 */           if (mrQ == null)
/*     */             continue;
/*  86 */           mrQ.setValue("RUNNING", false);

/*     */         }
/*     */ 
/*  90 */         msr.save();
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  95 */       if (!(logger.isErrorEnabled()))
/*     */         return;
/*  97 */       logger.error("Failed to execute Report Lock Release operation.", ex);
/*     */     }
/*     */   }


/*     */   private UserInfo getUserInfo()
/*     */   {
/* 104 */     UserInfo userInfo = null;

/*     */     try
/*     */     {
/* 108 */       userInfo = getRunasUserInfo();
/* 109 */       if (userInfo == null)
/*     */       {
/* 111 */         userInfo = MXServer.getMXServer().getSystemUserInfo();
/*     */       }
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 116 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 119 */     return userInfo;/*     */   }
/*     */   public ReportQueueLockReleaseCronTask()
/*     */   {
/* 122 */     this.parameterValidationMbo = null;
/*     */   }


/*     */   public MboRemote getParameterValidationMbo(CrontaskInstanceRemote instance)
/*     */     throws MXException, RemoteException
/*     */   {
/* 129 */     if (this.parameterValidationMbo == null)
/*     */     {
/* 131 */       this.parameterValidationMbo = MXServer.getMXServer().getMboSet("REPORTCRONPARAM", instance.getUserInfo()).add();
/*     */     }
/*     */ 
/* 134 */     return this.parameterValidationMbo;
/*     */   }
/*     */ }
