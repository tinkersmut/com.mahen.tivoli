package com.ibm.tivoli.maximo.report.birt.datasource;

public abstract interface DataSource
{
  public abstract DataSourceConnection getNewConnection();

  public abstract void freeConnection(DataSourceConnection paramDataSourceConnection);
}
