/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Set;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ 
















/*     */ public class ReportViewerServletContextAdaptor
/*     */   implements ServletContext
/*     */ {
/*     */   private ServletContext servletContext;
/*  35 */   private Dictionary initparams = null;
/*     */ 
/*     */   public ReportViewerServletContextAdaptor(ServletContext servletContext, Dictionary initparams)
/*     */   {
/*  39 */     if (initparams == null)
/*     */     {
/*  41 */       initparams = new Hashtable();
/*     */     }
/*     */ 
/*  44 */     this.servletContext = servletContext;
/*  45 */     this.initparams = initparams;
/*     */ 
/*  47 */     Enumeration nameEnum = servletContext.getInitParameterNames();
/*  48 */     while (nameEnum.hasMoreElements())
/*     */     {
/*  50 */       String paramName = (String)nameEnum.nextElement();
/*  51 */       if (initparams.get(paramName) != null)
/*     */       {
/*  53 */         initparams.put(paramName, servletContext.getInitParameter(paramName));
/*     */       }
/*     */     }
/*     */   }

/*     */   public Object getAttribute(String attrName)
/*     */   {
/*  60 */     return this.servletContext.getAttribute(attrName);
/*     */   }

/*     */   public Enumeration getAttributeNames()
/*     */   {
/*  65 */     return this.servletContext.getAttributeNames();
/*     */   }

/*     */   public ServletContext getContext(String uriPath)
/*     */   {
/*  70 */     return this.servletContext.getContext(uriPath);
/*     */   }


/*     */   public String getInitParameter(String name)
/*     */   {
/*  76 */     return ((String)this.initparams.get(name));
/*     */   }


/*     */   public Enumeration getInitParameterNames()
/*     */   {
/*  82 */     return this.initparams.keys();
/*     */   }

/*     */   public int getMajorVersion()
/*     */   {
/*  87 */     return this.servletContext.getMajorVersion();
/*     */   }

/*     */   public String getMimeType(String arg0)
/*     */   {
/*  92 */     return this.servletContext.getMimeType(arg0);
/*     */   }

/*     */   public int getMinorVersion()
/*     */   {
/*  97 */     return this.servletContext.getMinorVersion();
/*     */   }

/*     */   public RequestDispatcher getNamedDispatcher(String uriPath)
/*     */   {
/* 102 */     return this.servletContext.getNamedDispatcher(uriPath);
/*     */   }

/*     */   public String getRealPath(String path)
/*     */   {
/* 107 */     return this.servletContext.getRealPath(path);
/*     */   }

/*     */   public RequestDispatcher getRequestDispatcher(String path)
/*     */   {
/* 112 */     return this.servletContext.getRequestDispatcher(path);
/*     */   }

/*     */   public URL getResource(String path) throws MalformedURLException
/*     */   {
/* 117 */     return this.servletContext.getResource(path);
/*     */   }

/*     */   public InputStream getResourceAsStream(String path)
/*     */   {
/* 122 */     return this.servletContext.getResourceAsStream(path);
/*     */   }

/*     */   public Set getResourcePaths(String path)
/*     */   {
/* 127 */     return this.servletContext.getResourcePaths(path);
/*     */   }

/*     */   public String getServerInfo()
/*     */   {
/* 132 */     return this.servletContext.getServerInfo();
/*     */   }

/*     */   public Servlet getServlet(String name) throws ServletException
/*     */   {
/* 137 */     return this.servletContext.getServlet(name);
/*     */   }

/*     */   public String getServletContextName()
/*     */   {
/* 142 */     return this.servletContext.getServletContextName();
/*     */   }

/*     */   public Enumeration getServletNames()
/*     */   {
/* 147 */     return this.servletContext.getServletNames();
/*     */   }

/*     */   public Enumeration getServlets()
/*     */   {
/* 152 */     return this.servletContext.getServlets();
/*     */   }

/*     */   public void log(String msg)
/*     */   {
/* 157 */     this.servletContext.log(msg);
/*     */   }

/*     */   public void log(Exception exception, String msg)
/*     */   {
/* 162 */     this.servletContext.log(exception, msg);
/*     */   }

/*     */   public void log(String msg, Throwable throwable)
/*     */   {
/* 167 */     this.servletContext.log(msg, throwable);
/*     */   }

/*     */   public void removeAttribute(String name)
/*     */   {
/* 172 */     this.servletContext.removeAttribute(name);
/*     */   }

/*     */   public void setAttribute(String name, Object object)
/*     */   {
/* 177 */     this.servletContext.setAttribute(name, object);
/*     */   }

/*     */   public String getContextPath() {
/* 181 */     return null;
/*     */   }
/*     */ }
