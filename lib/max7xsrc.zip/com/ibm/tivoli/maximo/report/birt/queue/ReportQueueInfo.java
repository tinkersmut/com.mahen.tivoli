/*    */ package com.ibm.tivoli.maximo.report.birt.queue;
/*    */ 
















/*    */ public class ReportQueueInfo
/*    */ {
/* 21 */   private int runningReportCount = 0;
/*    */ 
/*    */   ReportQueueInfo(int runningReportCount)
/*    */   {
/* 25 */     this.runningReportCount = runningReportCount;
/*    */   }

/*    */   public int getRunningReportCount()
/*    */   {
/* 30 */     return this.runningReportCount;
/*    */   }
/*    */ }
