/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.AdminServiceTempLocation;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerProvider;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportRuntimeTempLocation;
/*     */ import com.ibm.tivoli.maximo.report.birt.util.logging.ReportLoggerProviderImpl;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ 























/*     */ public class ReportWebAppStartupServlet extends HttpServlet
/*     */ {
/*     */   protected static final String REPORT_SCRIPTCLASSES_BASE = "/WEB-INF/birt/script/classes/";
/*  44 */   private static boolean initialized = false;
/*     */ 
/*  46 */   private ServletContext context = null;
/*  47 */   private ReportLogger reportLogger = null;
/*     */ 
/*     */   public void init(ServletConfig config)
/*     */     throws ServletException
/*     */   {
/*  55 */     super.init(config);
/*     */ 
/*  57 */     ReportLoggerProvider reportLoggerProvider = new ReportLoggerProviderImpl();
/*  58 */     ReportLoggerFactory.setReportLoggerProvider(reportLoggerProvider);
/*     */ 
/*  60 */     this.reportLogger = ReportLoggerFactory.getLogger("maximo.report.birt");
/*  61 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/*  63 */       this.reportLogger.debug("ReportWebAppStartupServlet (initializing)");

/*     */     }
/*     */ 
/*  67 */     this.context = config.getServletContext();
/*     */ 
/*  69 */     File servletTemp = null;
/*     */ 
/*  71 */     if (System.getProperty("mxe.report.birt.tempfolder") != null)
/*     */     {
/*  73 */       servletTemp = new File(System.getProperty("mxe.report.birt.tempfolder"));
/*     */     }
/*     */     else
/*     */     {
/*  77 */       servletTemp = (File)this.context.getAttribute("javax.servlet.context.tempdir");
/*     */ 
/*  79 */       String filePath = servletTemp.getAbsolutePath();
/*  80 */       int index = filePath.indexOf(" ");
/*  81 */       if (index > -1)
/*     */       {
/*  83 */         filePath = filePath.replaceAll(" ", "_");
/*  84 */         servletTemp = new File(filePath);
/*     */       }
/*     */     }
/*     */ 
/*  88 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/*  90 */       this.reportLogger.debug("ReportWebAppStartupServlet temp directory = " + servletTemp.getAbsolutePath());









/*     */     }
/*     */ 
/* 102 */     if (!(initialized))
/*     */     {
/* 104 */       File birtPlatformDir = new File(servletTemp, "birtplatform");
/* 105 */       boolean delPlatformSuccess = deleteFolder(birtPlatformDir.getAbsolutePath());
/*     */ 
/* 107 */       if (!(delPlatformSuccess))
/*     */       {
/* 109 */         File birtPlatformDir1 = new File(servletTemp, "birtplatform");
/* 110 */         deleteFolder(birtPlatformDir1.getAbsolutePath());
/*     */       }
/*     */ 
/* 113 */       File reportAdminDir = new File(servletTemp, "reportadmin");
/* 114 */       boolean delAdminSuccess = deleteFolder(reportAdminDir.getAbsolutePath());
/* 115 */       if (!(delAdminSuccess))
/*     */       {
/* 117 */         File reportAdminDir1 = new File(servletTemp, "reportadmin");
/* 118 */         deleteFolder(reportAdminDir1.getAbsolutePath());
/*     */       }
/*     */ 
/* 121 */       File reportRuntimeDir = new File(servletTemp, "reportruntime");
/* 122 */       boolean delRuntimeSuccess = deleteFolder(reportRuntimeDir.getAbsolutePath());
/* 123 */       if (!(delRuntimeSuccess))
/*     */       {
/* 125 */         File reportRuntimeDir1 = new File(servletTemp, "reportruntime");
/* 126 */         deleteFolder(reportRuntimeDir1.getAbsolutePath());

/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 132 */     File adminDirectory = new File(servletTemp, "reportadmin");
/* 133 */     if (!(adminDirectory.exists()))
/*     */     {
/* 135 */       adminDirectory.mkdirs();
/*     */     }
/*     */ 
/* 138 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 140 */       this.reportLogger.debug("ReportWebAppStartupServlet admin directory = " + adminDirectory.getAbsolutePath());

/*     */     }
/*     */ 
/* 144 */     AdminServiceTempLocation.setAdminServiceTempLocation(adminDirectory.getAbsolutePath());
/*     */ 
/* 146 */     File runtimeDirectory = new File(servletTemp, "reportruntime");
/* 147 */     if (!(runtimeDirectory.exists()))
/*     */     {
/* 149 */       runtimeDirectory.mkdirs();
/*     */     }
/*     */ 
/* 152 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 154 */       this.reportLogger.debug("ReportWebAppStartupServlet runtime directory = " + runtimeDirectory.getAbsolutePath());

/*     */     }
/*     */ 
/* 158 */     ReportRuntimeTempLocation.setReportRuntimeTempLocation(runtimeDirectory.getAbsolutePath());

/*     */ 
/* 161 */     copyResource("/WEB-INF/birt/script/classes/", new File(ReportRuntimeTempLocation.getScriptsLibLocation()));
/*     */ 
/* 163 */     if (this.reportLogger.isDebugEnabled())
/*     */     {
/* 165 */       this.reportLogger.debug("ReportWebAppStartupServlet (initialized)");
/*     */     }
/*     */ 
/* 168 */     initialized = true;
/*     */   }
/*     */   protected void copyResource(String resourcePath, File target)
/*     */     throws ServletException
/*     */   {
/*     */     Iterator it;
/* 174 */     if (resourcePath.endsWith("/"))
/*     */     {
/* 176 */       target.mkdir();
/* 177 */       Set paths = this.context.getResourcePaths(resourcePath);
/* 178 */       if (paths == null)
/*     */       {
/* 180 */         return;
/*     */       }
/*     */ 
/* 183 */       for (it = paths.iterator(); it.hasNext(); )
/*     */       {
/* 185 */         String path = (String)it.next();
/* 186 */         File newFile = new File(target, path.substring(resourcePath.length()));
/* 187 */         copyResource(path, newFile);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 194 */         if (target.createNewFile())
/*     */         {
/* 196 */           InputStream is = null;
/* 197 */           OutputStream os = null;
/*     */           try
/*     */           {
/* 200 */             is = this.context.getResourceAsStream(resourcePath);
/* 201 */             if (is == null)
/*     */             {
/*     */               return;
/*     */             }
/*     */ 
/* 206 */             os = new FileOutputStream(target);
/* 207 */             byte[] buffer = new byte[8192];
/* 208 */             int bytesRead = is.read(buffer);
/* 209 */             while (bytesRead != -1)
/*     */             {
/* 211 */               os.write(buffer, 0, bytesRead);
/* 212 */               bytesRead = is.read(buffer);
/*     */             }
/*     */           }
/*     */           finally
/*     */           {
/* 217 */             if (is != null) {
/* 218 */               is.close();
/*     */             }
/* 220 */             if (os != null)
/* 221 */               os.close();
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 227 */         if (this.reportLogger.isErrorEnabled())
/*     */         {
/* 229 */           this.reportLogger.error("Failed to copy resources from " + resourcePath + " to " + target.getAbsolutePath(), e);
/*     */         }
/*     */ 
/* 232 */         throw new ServletException("Failed to copy resources from " + resourcePath + " to " + target.getAbsolutePath());
/*     */       }
/*     */     }
/*     */   }

/*     */   private boolean deleteFolder(String folderName)
/*     */   {
/* 239 */     if (folderName == null)
/*     */     {
/* 241 */       return true;
/*     */     }
/*     */ 
/* 244 */     File folder = new File(folderName);
/* 245 */     if (!(folder.exists()))
/*     */     {
/* 247 */       return true;
/*     */     }
/*     */ 
/* 250 */     boolean successDeletingAll = deleteAllFilesFromFolder(folder);
/* 251 */     boolean success = folder.delete();


/*     */ 
/* 255 */     return ((successDeletingAll) && (success));
/*     */   }




/*     */   private boolean deleteAllFilesFromFolder(File folder)
/*     */   {
/* 263 */     boolean deleteSuccess = true;
/* 264 */     File[] files = folder.listFiles();
/* 265 */     for (int i = 0; i < files.length; ++i)
/*     */     {
/* 267 */       File f = files[i];
/* 268 */       if (f.isDirectory())
/*     */       {
/* 270 */         boolean successDeletingAll = deleteAllFilesFromFolder(f);
/* 271 */         boolean success = f.delete();
/* 272 */         if ((!(successDeletingAll)) || (!(success)))
/*     */         {
/* 274 */           deleteSuccess = false;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 279 */         boolean success = f.delete();
/* 280 */         if (success)
/*     */           continue;
/* 282 */         deleteSuccess = false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 287 */     return deleteSuccess;
/*     */   }
/*     */ }
