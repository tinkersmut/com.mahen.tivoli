/*     */ package com.ibm.tivoli.maximo.report.birt.queue;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportParameterData;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Iterator;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXException;
/*     */ 






















/*     */ public class ReportQueueService
/*     */ {
/*  36 */   private static ReportQueueService queueManager = new ReportQueueService();
/*     */ 
/*     */   public static ReportQueueService getQueueService()
/*     */   {
/*  40 */     return queueManager;
/*     */   }


























/*     */   @Deprecated
/*     */   public void queueReport(String reportName, String appName, String userId, String emailAddresses, String emailSubject, String emailComments, ReportParameterData parameterData, String country, String language, String variant, String timeZone, String langCode, long reportScheduleId, UserInfo userInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/*  72 */     MboSetRemote runQueueSet = null;

/*     */     try
/*     */     {
/*  76 */       runQueueSet = MXServer.getMXServer().getMboSet("REPORTRUNQUEUE", userInfo);
/*     */ 
/*  78 */       MboRemote runQueue = runQueueSet.add();
/*     */ 
/*  80 */       runQueue.setValue("REPORTNAME", reportName);
/*  81 */       runQueue.setValue("APPNAME", appName);
/*  82 */       runQueue.setValue("USERID", userId);
/*  83 */       runQueue.setValue("EMAILUSERS", emailAddresses);
/*  84 */       runQueue.setValue("EMAILSUBJECT", emailSubject);
/*  85 */       runQueue.setValue("EMAILCOMMENTS", emailComments);
/*  86 */       runQueue.setValue("SUBMITTIME", MXServer.getMXServer().getDate());
/*     */ 
/*  88 */       runQueue.setValue("COUNTRY", country);
/*  89 */       runQueue.setValue("LANGUAGE", language);
/*  90 */       runQueue.setValue("VARIANT", variant);
/*  91 */       runQueue.setValue("TIMEZONE", timeZone);
/*  92 */       runQueue.setValue("LANGCODE", langCode);
/*  93 */       runQueue.setValue("RUNNING", false);
/*  94 */       runQueue.setValue("REPORTSCHEDID", reportScheduleId);
/*     */ 
/*  96 */       MboSetRemote runParamSet = runQueue.getMboSet("REPORTRUNPARAM");
/*     */ 
/*  98 */       Iterator paramIterator = parameterData.getParameters();
/*  99 */       while (paramIterator.hasNext())
/*     */       {
/* 101 */         String paramName = (String)paramIterator.next();
/* 102 */         String paramValue = parameterData.getParameter(paramName);
/*     */ 
/* 104 */         MboRemote runParam = runParamSet.add();
/* 105 */         runParam.setValue("PARAMNAME", paramName);
/* 106 */         runParam.setValue("PARAMVALUE", paramValue);
/* 107 */         runParam.setValue("REPORTRUNQUEUEID", runQueue.getUniqueIDValue());
/*     */       }
/*     */ 
/* 110 */       runQueueSet.save();
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 115 */         if (runQueueSet != null)
/*     */         {
/* 117 */           runQueueSet.reset();
/*     */         }
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */       }
/*     */     }
/*     */   }























/*     */   public void queueReport(String reportName, String appName, String userId, String emailAddresses, String emailSubject, String emailComments, String emailFileType, String emailType, String maximoUrl, ReportParameterData parameterData, String country, String language, String variant, String timeZone, String langCode, long reportScheduleId, UserInfo userInfo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 151 */     MboSetRemote runQueueSet = null;

/*     */     try
/*     */     {
/* 155 */       runQueueSet = MXServer.getMXServer().getMboSet("REPORTRUNQUEUE", userInfo);
/*     */ 
/* 157 */       MboRemote runQueue = runQueueSet.add();
/*     */ 
/* 159 */       runQueue.setValue("REPORTNAME", reportName);
/* 160 */       runQueue.setValue("APPNAME", appName);
/* 161 */       runQueue.setValue("USERID", userId);
/* 162 */       runQueue.setValue("EMAILUSERS", emailAddresses);
/* 163 */       runQueue.setValue("EMAILSUBJECT", emailSubject);
/* 164 */       runQueue.setValue("EMAILCOMMENTS", emailComments);
/* 165 */       runQueue.setValue("EMAILFILETYPE", emailFileType);
/* 166 */       runQueue.setValue("EMAILTYPE", emailType);
/* 167 */       runQueue.setValue("MAXIMOURL", maximoUrl);
/* 168 */       runQueue.setValue("SUBMITTIME", MXServer.getMXServer().getDate());
/*     */ 
/* 170 */       runQueue.setValue("COUNTRY", country);
/* 171 */       runQueue.setValue("LANGUAGE", language);
/* 172 */       runQueue.setValue("VARIANT", variant);
/* 173 */       runQueue.setValue("TIMEZONE", timeZone);
/* 174 */       runQueue.setValue("LANGCODE", langCode);
/* 175 */       runQueue.setValue("RUNNING", false);
/* 176 */       runQueue.setValue("REPORTSCHEDID", reportScheduleId);
/*     */ 
/* 178 */       MboSetRemote runParamSet = runQueue.getMboSet("REPORTRUNPARAM");
/*     */ 
/* 180 */       Iterator paramIterator = parameterData.getParameters();
/* 181 */       while (paramIterator.hasNext())
/*     */       {
/* 183 */         String paramName = (String)paramIterator.next();
/* 184 */         String paramValue = parameterData.getParameter(paramName);
/*     */ 
/* 186 */         MboRemote runParam = runParamSet.add();
/* 187 */         runParam.setValue("PARAMNAME", paramName);
/* 188 */         runParam.setValue("PARAMVALUE", paramValue);
/* 189 */         runParam.setValue("REPORTRUNQUEUEID", runQueue.getUniqueIDValue());
/*     */       }
/*     */ 
/* 192 */       runQueueSet.save();
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 197 */         if (runQueueSet != null)
/*     */         {
/* 199 */           runQueueSet.reset();
/*     */         }
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ }
