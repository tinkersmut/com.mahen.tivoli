package com.ibm.tivoli.maximo.report.birt.logging;

public abstract interface ReportLoggerNames
{
  public static final String REPORT = "maximo.report";
  public static final String REPORT_BIRT = "maximo.report.birt";
  public static final String REPORT_BIRT_ADMIN = "maximo.report.birt.admin";
  public static final String REPORT_BIRT_ADMIN_OSGIBUNDLE = "maximo.report.birt.admin.osgibundle";
  public static final String REPORT_BIRT_ENGINE = "maximo.report.birt.engine";
  public static final String REPORT_BIRT_SCRIPT = "maximo.report.birt.script";
  public static final String REPORT_BIRT_SCRIPT_SQL = "maximo.report.birt.sql.script";
  public static final String REPORT_BIRT_VIEWER = "maximo.report.birt.viewer";
  public static final String REPORT_BIRT_QUEUE = "maximo.report.birt.queue";
  public static final String REPORT_BIRT_DATASOURCE = "maximo.report.birt.datasource";
}
