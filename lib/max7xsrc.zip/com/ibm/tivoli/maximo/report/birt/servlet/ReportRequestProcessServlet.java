/*     */ package com.ibm.tivoli.maximo.report.birt.servlet;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminService;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportAdminServiceRemote;
/*     */ import com.ibm.tivoli.maximo.report.birt.admin.ReportRunInfo;
/*     */ import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceProvider;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLogger;
/*     */ import com.ibm.tivoli.maximo.report.birt.logging.ReportLoggerFactory;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportMessageResources;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServerRemote;
/*     */ import psdi.util.BidiUtils;
/*     */ import psdi.util.MXFormat;
/*     */ import psdi.util.MXSession;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ import psdi.webclient.system.websession.TokenWebAppSession;
/*     */ import psdi.webclient.system.websession.TokenWebAppSessionFactory;
/*     */ 













/*     */ public class ReportRequestProcessServlet extends HttpServlet
/*     */ {
/*     */   private static final String MXREPORTCONTEXT = "MXREPORTCONTEXT";
/*     */   private static final String REPORT_SCRIPTLOGGER = "com.ibm.tivoli.maximo.report.birt.logger.script";
/*     */   private static final String REPORT_SCRIPTSQLLOGGER = "com.ibm.tivoli.maximo.report.birt.logger.script.sql";
/*     */   private static final String REPORT_DISPLAY_YES = "com.ibm.tivoli.maximo.report.birt.display.yes";
/*     */   private static final String REPORT_DISPLAY_NO = "com.ibm.tivoli.maximo.report.birt.display.no";
/*     */   private static final String REPORT_USER_DATE = "com.ibm.tivoli.maximo.report.birt.userdate";
/*     */   private static final String REPORT_DATASOURCEPROVIDER = "REPORTDATASOURCEPROVIDER";
/*     */   private static final String REPORT_MODE = "com.ibm.tivoli.maximo.report.birt.mode";
/*     */   private static final String REPORT_MODE_IMMEDIATE = "IMMEDIATE";
/*     */   private static final String REPORT_LANGCODE = "com.ibm.tivoli.maximo.report.birt.langcode";
/*     */   private static final String REPORT_LOCALE = "com.ibm.tivoli.maximo.report.birt.locale";
/*     */   private static final String REPORT_TIMEZONE = "com.ibm.tivoli.maximo.report.birt.timezone";
/*     */   private static final String REPORT_ACTIVEREPORTTHREADNOTIFIER = "ACTIVEREPORTTHREADNOTIFIER";
/*     */   private static final String REPORT_USAGELOGNOTIFIER = "USAGELOGNOTIFIER";
/*     */   private static final String REPORT_DATARESTRICTIONPROVIDER = "DATARESTRICTIONPROVIDER";
/*     */   private static final String REPORT_REQUESTSERVLETPATH = "com.ibm.tivoli.maximo.report.birt.servlet.ReportRequestProcessServlet.path";
/*     */   private static final String REPORT_REQUESTCONTEXTPATH = "com.ibm.tivoli.maximo.report.birt.servlet.ReportRequestProcessServlet.context";
/*     */   private static final String REPORT_PASSTHROUGH = "com.ibm.tivoli.maximo.report.birt.servlet.ReportRequestProcessServlet.passthrough";
/*     */   private static final String REPORTRUNINFOKEY = "REPORTRUNINFOKEY";
/*     */   private ServletContext servletContext;
/*     */   private ReportLogger reportLogger;
/*     */   private String bridgeServletMapping;
/*     */ 
/*     */   public ReportRequestProcessServlet()
/*     */   {
/*  81 */     this.servletContext = null;
/*     */ 
/*  83 */     this.reportLogger = null;
/*     */ 
/*  85 */     this.bridgeServletMapping = null;
/*     */   }

/*     */   public void init(ServletConfig config) throws ServletException {
/*  89 */     this.reportLogger = ReportLoggerFactory.getLogger("maximo.report.birt");
/*     */ 
/*  91 */     ReportViewerServletConfigAdaptor configAdapter = new ReportViewerServletConfigAdaptor(this, null, config.getServletContext());
/*     */ 
/*  93 */     super.init(configAdapter);
/*     */ 
/*  95 */     this.servletContext = configAdapter.getServletContext();
/*     */ 
/*  97 */     this.bridgeServletMapping = config.getInitParameter("bridgeservletmap");
/*  98 */     if (this.bridgeServletMapping == null)
/*     */     {
/* 100 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 102 */         this.reportLogger.error("ReportRequestProcessServlet init-param bridgeservletmap not defined.");
/*     */       }
/* 104 */       throw new ServletException("ReportRequestProcessServlet init-param bridgeservletmap not defined.");
/*     */     }
/*     */ 
/* 107 */     if (!(this.reportLogger.isDebugEnabled()))
/*     */       return;
/* 109 */     this.reportLogger.debug("ReportRequestProcessServlet using bridgeservletmap = " + this.bridgeServletMapping);
/*     */   }


/*     */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 116 */     processReportRequest(request, response);
/*     */   }

/*     */   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*     */   {
/* 121 */     processReportRequest(request, response);
/*     */   }

/*     */   protected void processReportRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 127 */     request.setCharacterEncoding("UTF-8");
/* 128 */     String encoding = request.getCharacterEncoding();
/* 129 */     boolean tokenBasedSession = false;
/*     */ 
/* 131 */     MXSession session = null;

/*     */ 
/* 134 */     String mxToken = getRequestParameterValue(request, "__mxtoken");
/* 135 */     String userId = getRequestParameterValue(request, "__userid");
/* 136 */     if ((mxToken == null) || (userId == null))

/*     */     {
/* 139 */       Object objSession = request.getSession().getAttribute("MXSession");
/* 140 */       Object objSessionReport = request.getSession().getAttribute("MXSessionReport");
/* 141 */       if ((((objSessionReport == null) || (!(((MXSession)objSessionReport).isConnected())))) && (((objSession == null) || (!(((MXSession)objSession).isConnected())))))


/*     */       {
/* 145 */         response.getWriter().write("Invalid request. The request must only come from maximo session.");
/* 146 */         response.sendError(401);
/* 147 */         return;
/*     */       }
/*     */ 
/* 150 */       session = (MXSession)objSession;
/* 151 */       if (session == null)
/*     */       {
/* 153 */         session = (MXSession)objSessionReport;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 158 */       tokenBasedSession = true;
/*     */     }
/*     */ 
/* 161 */     if (tokenBasedSession)


/*     */     {
/* 165 */       Object objSession = request.getSession().getAttribute("MXSessionReport");
/* 166 */       if (objSession == null)

/*     */       {
/*     */         try
/*     */         {
/* 171 */           TokenWebAppSession tokenWebAppSession = (TokenWebAppSession)(TokenWebAppSession)new TokenWebAppSessionFactory().getNewSession();
/* 172 */           tokenWebAppSession.setUserName(userId);
/* 173 */           tokenWebAppSession.setSessionToken(mxToken);
/* 174 */           tokenWebAppSession.connect();
/* 175 */           request.getSession().setAttribute("MXSessionReport", tokenWebAppSession);
/* 176 */           objSession = tokenWebAppSession;
/* 177 */           session = (MXSession)objSession;
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 181 */           if (this.reportLogger.isErrorEnabled())
/*     */           {
/* 183 */             this.reportLogger.error("ReportRequestProcessServlet Failed to process request.", e);
/*     */           }
/*     */ 
/* 186 */           throw new ServletException("ReportRequestProcessServlet Failed to process request", e);
/*     */         }
/*     */ 
/*     */       }
/*     */       else {
/*     */         try
/*     */         {
/* 193 */           TokenWebAppSession tokenWebAppSession = (TokenWebAppSession)objSession;
/* 194 */           if (!(tokenWebAppSession.getSessionToken().equals(mxToken)))
/*     */           {
/* 196 */             tokenWebAppSession.disconnect();
/* 197 */             tokenWebAppSession.setSessionToken(mxToken);
/* 198 */             tokenWebAppSession.connect();
/*     */           }
/*     */ 
/* 201 */           objSession = tokenWebAppSession;
/* 202 */           session = (MXSession)objSession;
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 206 */           if (this.reportLogger.isErrorEnabled())
/*     */           {
/* 208 */             this.reportLogger.error("ReportRequestProcessServlet Failed to process request.", e);
/*     */           }
/*     */ 
/* 211 */           throw new ServletException("ReportRequestProcessServlet Failed to process request", e);





/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 223 */     String reportRequestServletPath = request.getServletPath();
/* 224 */     String reportRequestContextPath = request.getContextPath();
/* 225 */     request.getSession().setAttribute("com.ibm.tivoli.maximo.report.birt.servlet.ReportRequestProcessServlet.path", reportRequestServletPath);
/* 226 */     request.getSession().setAttribute("com.ibm.tivoli.maximo.report.birt.servlet.ReportRequestProcessServlet.context", reportRequestContextPath);

/*     */ 
/* 229 */     String baseURL = getRequestParameterValue(request, "baseURL");
/* 230 */     if ((baseURL != null) && (!(baseURL.trim().equals("")))) {
/* 231 */       request.getSession().setAttribute("com.ibm.tivoli.maximo.report.birt.baseurl", baseURL);
/*     */     }
/*     */ 
/* 234 */     String reportDesign = getRequestParameterValue(request, "__report");






/*     */ 
/* 242 */     int slashIndex = reportDesign.lastIndexOf("/");
/* 243 */     if (slashIndex >= 0)
/*     */     {
/* 245 */       reportDesign = reportDesign.substring(slashIndex + 1);
/*     */     }
/*     */     else
/*     */     {
/* 249 */       slashIndex = reportDesign.lastIndexOf("\\");
/* 250 */       if (slashIndex >= 0)
/*     */       {
/* 252 */         reportDesign = reportDesign.substring(slashIndex + 1);
/*     */       }
/*     */     }
/*     */ 
/* 256 */     String appName = getRequestParameterValue(request, "appname");
/*     */ 
/* 258 */     String requestId1 = getRequestParameterValue(request, "__requestid");
/* 259 */     if (requestId1 == null)



/*     */     {
/* 264 */       String whereParam = getRequestParameterValue(request, "where");
/* 265 */       if ((whereParam == null) || (whereParam.trim().length() == 0))
/*     */       {
/* 267 */         response.sendError(400);
/* 268 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 272 */     String reportRunInfoKey = reportDesign + "_" + appName + "_" + requestId1;
/*     */ 
/* 274 */     String reportRunRequestKey = "reportRequestId" + reportDesign + "_" + appName + "_" + requestId1;
/*     */ 
/* 276 */     String reportContextKey = "context_" + reportDesign + "_" + appName;
/*     */ 
/* 278 */     String newRun = getRequestParameterValue(request, "__newrun");
/*     */ 
/* 280 */     String trans = getRequestParameterValue(request, "__transient");
/* 281 */     boolean isTransient = (trans != null) && (trans.equalsIgnoreCase("true"));










/*     */ 
/* 293 */     ArrayList attrNameKeys = new ArrayList();

/*     */ 
/* 296 */     Enumeration attrEnum = request.getSession().getAttributeNames();
/* 297 */     String prefix = reportDesign + "_" + appName + "_";
/* 298 */     while (attrEnum.hasMoreElements())
/*     */     {
/* 300 */       String attrName = (String)attrEnum.nextElement();
/*     */ 
/* 302 */       if ((attrName.startsWith(prefix)) && 

/* 304 */         (!(attrName.equals(reportRunInfoKey))))
/*     */       {
/* 306 */         attrNameKeys.add(attrName);

/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 312 */     for (int i = 0; i < attrNameKeys.size(); ++i)
/*     */     {
/* 314 */       SessionReportRunInfo sessionReportRunInfo = (SessionReportRunInfo)request.getSession().getAttribute((String)attrNameKeys.get(i));
/* 315 */       if (sessionReportRunInfo == null)
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 320 */       request.getSession().removeAttribute((String)attrNameKeys.get(i));
/*     */ 
/* 322 */       request.getSession().removeAttribute(reportContextKey);

/*     */     }
/*     */ 
/* 326 */     if (!(isAuthorizedToRunReport(session, reportDesign, appName)))
/*     */     {
/* 328 */       response.getWriter().write("Unauthorized to run the report.");
/* 329 */       response.getWriter().flush();
/* 330 */       return;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 335 */       ReportRunInfo reportRunInfo = null;
/* 336 */       SessionReportRunInfo sessionReportRunInfo = (SessionReportRunInfo)request.getSession().getAttribute(reportRunInfoKey);
/* 337 */       if (sessionReportRunInfo == null)
/*     */       {
/* 339 */         ReportAdminServiceRemote birtAdminService = (ReportAdminServiceRemote)session.lookup("BIRTREPORT");
/* 340 */         reportRunInfo = birtAdminService.prepareReportForRun(session.getUserInfo(), reportDesign, appName);
/*     */ 
/* 342 */         sessionReportRunInfo = new SessionReportRunInfo(reportRunInfo, birtAdminService);
/* 343 */         request.getSession().setAttribute(reportRunInfoKey, sessionReportRunInfo);

/*     */ 
/* 346 */         setMXReportContext(request, session.getUserInfo(), reportDesign, appName, isTransient, reportContextKey, session, reportRunInfoKey);
/*     */       }
/*     */       else
/*     */       {
/* 350 */         reportRunInfo = sessionReportRunInfo.getReportRunInfo();
/*     */       }
/*     */ 
/* 353 */       Object reportContext = request.getSession().getAttribute(reportContextKey);
/* 354 */       if (reportContext != null)
/*     */       {
/* 356 */         request.setAttribute("MXREPORTCONTEXT", reportContext);
/*     */       }
/*     */ 
/* 359 */       String reportOutputFolder = reportRunInfo.getReportOutputFolderName();
/*     */ 
/* 361 */       HashMap additionalParams = new HashMap();
/* 362 */       additionalParams.put("__report", new String[] { reportRunInfo.getReportRelativePath() + File.separator + reportDesign });
/*     */ 
/* 364 */       String reportName = reportDesign.substring(0, reportDesign.lastIndexOf("."));
/* 365 */       String reportDocument = reportName + ".rptdocument";
/*     */ 
/* 367 */       String docFileName = reportRunInfo.getTempRunFolder() + File.separator + reportOutputFolder + File.separator + reportDocument;
/* 368 */       additionalParams.put("__document", new String[] { docFileName });

/*     */ 
/* 371 */       UserInfo userInfo = session.getUserInfo();
/* 372 */       String langCode = userInfo.getLangCode();
/* 373 */       if (userInfo.getLangCode().equalsIgnoreCase("zht"))
/* 374 */         langCode = "zh";
/* 375 */       Locale l = new Locale(langCode, userInfo.getLocale().getCountry(), userInfo.getLocale().getVariant());
/* 376 */       additionalParams.put("__locale", new String[] { l.toString() });
/*     */ 
/* 378 */       if (BidiUtils.getLayoutOrientation(userInfo.getLangCode()).equalsIgnoreCase("RTL")) {
/* 379 */         additionalParams.put("__rtl", new String[] { "true" });
/*     */       }
/* 381 */       ReportMessageProviderImpl rmp = new ReportMessageProviderImpl(userInfo.getLangCode(), session.getMXServerRemote());
/* 382 */       ReportMessageResources.setMessageProvider(rmp);
/*     */ 
/* 384 */       StringBuffer buf = new StringBuffer();
/*     */ 
/* 386 */       String requestId = getRequestParameterValue(request, "__requestid");
/* 387 */       buf.append("\n");
/* 388 */       buf.append("\n");
/* 389 */       buf.append("Report parameters for RequestID = " + requestId);
/* 390 */       buf.append("\n");
/* 391 */       buf.append("encoding=" + encoding);
/* 392 */       buf.append("\n");
/*     */ 
/* 394 */       HashMap reportParams = (HashMap)request.getSession().getAttribute(reportRunRequestKey);
/* 395 */       if (reportParams != null)
/*     */       {
/* 397 */         Iterator repParamIterator = reportParams.keySet().iterator();
/* 398 */         while (repParamIterator.hasNext())
/*     */         {
/* 400 */           String repParamKey = (String)repParamIterator.next();

/*     */ 
/* 403 */           if ((repParamKey.equals("__asattachment")) || (repParamKey.equals("__overwrite"))) continue; if (repParamKey.equals("__format"))

/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/* 409 */           Object repParamValue = reportParams.get(repParamKey);


/*     */ 
/* 413 */           if (repParamValue instanceof String[])
/*     */           {
/* 415 */             additionalParams.put(repParamKey, repParamValue);
/* 416 */             for (int i = 0; i < ((String[])(String[])repParamValue).length; ++i)
/*     */             {
/* 418 */               buf.append(repParamKey + " = " + ((String[])(String[])repParamValue)[i]);
/* 419 */               buf.append("\n");
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 424 */             additionalParams.put(repParamKey, new String[] { repParamValue.toString() });
/* 425 */             buf.append(repParamKey + " = " + repParamValue);
/* 426 */             buf.append("\n");

/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 435 */         buf.append("   (NONE)");
/* 436 */         buf.append("\n");

/*     */       }
/*     */ 
/* 440 */       Map reportParamsMap = request.getParameterMap();
/* 441 */       if (reportParamsMap != null)
/*     */       {
/* 443 */         Iterator repParamIterator = reportParamsMap.keySet().iterator();
/* 444 */         while (repParamIterator.hasNext())
/*     */         {
/* 446 */           String repParamKey = (String)repParamIterator.next();
/* 447 */           String[] repParamValues = null;
/* 448 */           if (repParamKey.equals("__sessionId"))





/*     */           {
/* 455 */             String[] tempSessionId = getRequestParameterValues(request, repParamKey);
/* 456 */             if (tempSessionId[0].startsWith("???"))

/*     */             {
/* 459 */               repParamValues = request.getParameterValues(repParamKey);
/*     */             }
/*     */             else
/*     */             {
/* 463 */               repParamValues = tempSessionId;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 468 */             repParamValues = getRequestParameterValues(request, repParamKey);


/*     */           }
/*     */ 
/* 473 */           additionalParams.put(repParamKey, repParamValues);
/* 474 */           for (int i = 0; i < repParamValues.length; ++i)
/*     */           {
/* 476 */             buf.append(repParamKey + " = " + repParamValues[i]);
/* 477 */             buf.append("\n");
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 484 */         buf.append("   (NONE)");
/* 485 */         buf.append("\n");
/*     */       }
/*     */ 
/* 488 */       additionalParams.put("__report", new String[] { reportRunInfo.getReportRelativePath() + File.separator + reportDesign });
/* 489 */       if (mxToken != null)
/*     */       {
/* 491 */         additionalParams.put("__mxtoken", new String[] { mxToken });
/*     */       }
/*     */ 
/* 494 */       if (userId != null)
/*     */       {
/* 496 */         additionalParams.put("__userid", new String[] { userId });
/*     */       }
/*     */ 
/* 499 */       buf.append("\n");
/* 500 */       buf.append("\n");

/*     */ 
/* 503 */       if (this.reportLogger.isDebugEnabled())
/*     */       {
/* 505 */         this.reportLogger.debug(buf.toString());

/*     */       }
/*     */ 
/* 509 */       request.getSession().setAttribute(reportRunRequestKey, additionalParams);
/*     */ 
/* 511 */       Enumeration paramEnum = request.getParameterNames();
/* 512 */       while (paramEnum.hasMoreElements())
/*     */       {
/* 514 */         String paramName = (String)paramEnum.nextElement();
/* 515 */         if (paramName.startsWith("__")) {
/*     */           continue;
/*     */         }
/*     */ 
/* 519 */         String[] paramValues = getRequestParameterValues(request, paramName);
/* 520 */         additionalParams.put(paramName, paramValues);

/*     */       }
/*     */ 
/* 524 */       if (this.reportLogger.isDebugEnabled())
/*     */       {
/* 526 */         this.reportLogger.debug("Using document = " + docFileName);
/*     */       }
/*     */ 
/* 529 */       ReportRequestWrapper rw = new ReportRequestWrapper(request, additionalParams);



/*     */ 
/* 534 */       rw.setAttribute("com.ibm.tivoli.maximo.report.birt.servlet.ReportRequestProcessServlet.passthrough", "true");
/* 535 */       rw.setAttribute("MXREPORTCONTEXT", reportContext);





/*     */ 
/* 542 */       if ((newRun != null) && (newRun.equalsIgnoreCase("true")))



/*     */       {
/* 547 */         String tempQbr = getRequestParameterValue(request, "__tempQbr");
/* 548 */         if ((tempQbr != null) && (tempQbr.equalsIgnoreCase("true")))
/*     */         {
/*     */           try
/*     */           {
/* 552 */             Thread.sleep(500L);
/*     */           }
/*     */           catch (InterruptedException e) {
/*     */           }
/*     */         }
/* 557 */         response.setContentType("text/html;charset=utf-8");
/* 558 */         PrintWriter pw = response.getWriter();
/*     */ 
/* 560 */         pw.println("<html>");
/* 561 */         pw.println("<body>");
/* 562 */         pw.println("<form name=\"reportForm\" id=\"reportForm\" action=\"testAction\">");
/*     */ 
/* 564 */         Enumeration parameters = request.getParameterNames();
/* 565 */         while (parameters.hasMoreElements())
/*     */         {
/* 567 */           String paramName = (String)parameters.nextElement();
/*     */ 
/* 569 */           if (paramName.equals("__newrun")) continue; if (paramName.equals("__tempQbr"))
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/* 574 */           String[] paramValues = null;
/* 575 */           if (paramName.equals("__sessionId"))

/*     */           {
/* 578 */             String[] tempSessionId = getRequestParameterValues(request, paramName);
/* 579 */             if (tempSessionId[0].startsWith("???"))
/*     */             {
/* 581 */               paramValues = request.getParameterValues(paramName);
/*     */             }
/*     */             else
/*     */             {
/* 585 */               paramValues = tempSessionId;
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 591 */             paramValues = getRequestParameterValues(request, paramName);



/*     */           }
/*     */ 
/* 597 */           for (int i = 0; i < paramValues.length; ++i)
/*     */           {
/* 599 */             String paramValue = paramValues[i];
/* 600 */             if (paramValue.length() <= 0)

/*     */             {
/*     */               continue;
/*     */             }
/*     */ 
/* 606 */             paramValue = paramValue.replaceAll("\"", "&quot;");
/*     */ 
/* 608 */             pw.println("<input type=\"hidden\" ");
/* 609 */             pw.println(" name=\"" + paramName + "\"");
/* 610 */             pw.println(" value = \"" + paramValue + "\"");
/* 611 */             pw.println(">");
/*     */           }
/*     */         }
/*     */ 
/* 615 */         pw.println("</form>");
/* 616 */         pw.println("</body>");
/* 617 */         pw.println("</html>");
/*     */ 
/* 619 */         pw.println("<SCRIPT language=\"JavaScript\">");
/* 620 */         pw.println("window.focus();");
/* 621 */         pw.println("var reportForm = document.reportForm;");
/*     */ 
/* 623 */         String contextPath = request.getContextPath();
/* 624 */         String queryString = request.getQueryString();
/* 625 */         int newRunIndex = queryString.toLowerCase().indexOf("__newrun=true");
/* 626 */         if (newRunIndex >= 0)
/*     */         {
/* 628 */           String before = queryString.substring(0, newRunIndex);
/* 629 */           if (before.endsWith("&"))
/*     */           {
/* 631 */             before = before.substring(0, before.length() - 1);
/*     */           }
/* 633 */           String after = queryString.substring(newRunIndex + "__newrun=true".length());
/* 634 */           queryString = before + after;
/*     */         }
/*     */ 
/* 637 */         String servletPath = request.getServletPath();
/* 638 */         if (servletPath.endsWith("/"))
/*     */         {
/* 640 */           servletPath = servletPath.substring(0, servletPath.length() - 1);
/*     */         }
/* 642 */         String actionStr = contextPath + servletPath + "?" + queryString;
/* 643 */         pw.println("reportForm.action=\"" + actionStr + "\"");
/* 644 */         pw.println("reportForm.method=\"post\"");
/* 645 */         pw.println("reportForm.submit();");
/*     */ 
/* 647 */         pw.println("</SCRIPT>");
/*     */ 
/* 649 */         pw.flush();
/* 650 */         return;
/*     */       }
/*     */ 
/* 653 */       this.servletContext.getRequestDispatcher(this.bridgeServletMapping + "frameset").forward(rw, response);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 657 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 659 */         this.reportLogger.error("ReportRequestProcessServlet Failed to process request.", e);
/*     */       }
/*     */ 
/* 662 */       throw new ServletException("ReportRequestProcessServlet Failed to process request", e);
/*     */     }
/*     */   }






/*     */   protected void setMXReportContext(HttpServletRequest request, UserInfo userInfo, String reportName, String appName, boolean isTransient, String reportContextKey, MXSession session, String reportRunInfoKey)
/*     */     throws Exception
/*     */   {
/* 674 */     HashMap mxReportContext = new HashMap();
/* 675 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.langcode", userInfo.getLangCode());
/* 676 */     Locale l = new Locale(userInfo.getLangCode(), userInfo.getLocale().getCountry(), userInfo.getLocale().getVariant());
/* 677 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.locale", l);
/* 678 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.timezone", userInfo.getTimeZone());
/* 679 */     mxReportContext.put("REPORTRUNINFOKEY", reportRunInfoKey);
/*     */ 
/* 681 */     MXLogger reportScriptLogger = MXLoggerFactory.getLogger("maximo.report.birt.script");
/* 682 */     MXLogger reportScriptSqlLogger = MXLoggerFactory.getLogger("maximo.report.birt.sql.script");
/*     */ 
/* 684 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.logger.script", reportScriptLogger);
/* 685 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.logger.script.sql", reportScriptSqlLogger);
/*     */ 
/* 687 */     mxReportContext.put("REPORTDATASOURCEPROVIDER", DataSourceProvider.getDataSourceProvider());
/* 688 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.mode", "IMMEDIATE");

/*     */ 
/* 691 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.display.yes", MXFormat.getDisplayYesValue(userInfo.getLocale()));
/* 692 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.display.no", MXFormat.getDisplayNoValue(userInfo.getLocale()));
/*     */ 
/* 694 */     String userDate = MXFormat.dateTimeToString(session.getMXServerRemote().getDate(), userInfo.getLocale(), userInfo.getTimeZone());
/*     */ 
/* 696 */     mxReportContext.put("com.ibm.tivoli.maximo.report.birt.userdate", userDate);

/*     */ 
/* 699 */     ReportAdminServiceRemote birtAdminService = (ReportAdminServiceRemote)session.lookup("BIRTREPORT");
/*     */ 
/* 701 */     ImmediateActiveReportThreadNotifier iart = new ImmediateActiveReportThreadNotifier();
/* 702 */     iart.setBirtAdminService(birtAdminService);
/* 703 */     iart.setAppName(appName);
/* 704 */     iart.setReportName(reportName);
/* 705 */     iart.setUserName(userInfo.getUserName());
/* 706 */     iart.setThreadName(Thread.currentThread().getName());
/*     */ 
/* 708 */     mxReportContext.put("ACTIVEREPORTTHREADNOTIFIER", iart);
/*     */ 
/* 710 */     ImmediateReportDataRestrictionProvider dp = new ImmediateReportDataRestrictionProvider();
/* 711 */     dp.setMXServerRemote(session.getMXServerRemote());
/* 712 */     dp.setUserInfo(userInfo);
/*     */ 
/* 714 */     MboSetRemote maxAppSet = session.getMXServerRemote().getMboSet("MAXAPPS", userInfo);
/* 715 */     maxAppSet.setQbeExactMatch(true);
/* 716 */     maxAppSet.setQbe("APP", appName);
/* 717 */     MboRemote maxApp = maxAppSet.getMbo(0);
/* 718 */     if (maxApp != null)
/*     */     {
/* 720 */       dp.setObjectName(maxApp.getString("MAINTBNAME"));
/*     */     }
/* 722 */     dp.setAppName(appName);
/*     */ 
/* 724 */     mxReportContext.put("DATARESTRICTIONPROVIDER", dp);
/*     */ 
/* 726 */     ImmediateReportUsageLogNotifier iruln = new ImmediateReportUsageLogNotifier();
/* 727 */     iruln.setReportLogger(this.reportLogger);
/* 728 */     iruln.setBirtAdminService(birtAdminService);
/* 729 */     iruln.setEnterDate(session.getMXServerRemote().getDate());
/* 730 */     iruln.setStartDate(session.getMXServerRemote().getDate());
/* 731 */     iruln.setHostName(request.getRemoteHost());
/* 732 */     iruln.setServerName(session.getMXServerRemote().getName());
/* 733 */     iruln.setAppName(appName);
/* 734 */     iruln.setReportName(reportName);
/* 735 */     iruln.setUserId(userInfo.getUserName());
/* 736 */     iruln.setMXServerRemote(session.getMXServerRemote());
/* 737 */     iruln.setUserInfo(userInfo);
/* 738 */     iruln.setTransientReport(isTransient);




/*     */ 
/* 744 */     mxReportContext.put("USAGELOGNOTIFIER", iruln);
/*     */ 
/* 746 */     ReportMessageProviderImpl rmp = new ReportMessageProviderImpl(userInfo.getLangCode(), session.getMXServerRemote());
/* 747 */     ReportMessageResources.setMessageProvider(rmp);
/*     */ 
/* 749 */     request.getSession().setAttribute(reportContextKey, mxReportContext);
/*     */   }

/*     */   protected boolean isAuthorizedToRunReport(MXSession session, String reportName, String appName)
/*     */     throws ServletException
/*     */   {
/*     */     try
/*     */     {
/* 757 */       UserInfo userInfo = session.getUserInfo();
/* 758 */       ReportAdminService reportService = (ReportAdminService)session.lookup("BIRTREPORT");
/*     */ 
/* 760 */       boolean authorized = reportService.isAuthorizedToRunReport(userInfo, reportName, appName);
/* 761 */       return authorized;

/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*     */     }
/*     */ 
/* 768 */     return false;
/*     */   }


/*     */   public String getRequestParameterValue(HttpServletRequest request, String paramName)
/*     */   {
/* 774 */     String paramValue = request.getParameter(paramName);
/* 775 */     if (paramValue == null)
/*     */     {
/* 777 */       return null;
/*     */     }
/* 779 */     String encoding = request.getCharacterEncoding();
/* 780 */     if (encoding == null)
/* 781 */       encoding = "8859_1";
/* 782 */     if (encoding.equalsIgnoreCase("UTF-8")) {
/* 783 */       return paramValue;
/*     */     }
/*     */     try
/*     */     {
/* 787 */       return new String(paramValue.getBytes(encoding), "UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 790 */       e.printStackTrace(); }
/* 791 */     return paramValue;
/*     */   }


/*     */   public String[] getRequestParameterValues(HttpServletRequest request, String paramName)
/*     */   {
/* 797 */     String[] paramValues = request.getParameterValues(paramName);
/* 798 */     String encoding = request.getCharacterEncoding();
/* 799 */     if (encoding == null)
/* 800 */       encoding = "8859_1";
/* 801 */     if (encoding.equalsIgnoreCase("UTF-8")) {
/* 802 */       return paramValues;
/*     */     }
/* 804 */     String[] newValues = new String[paramValues.length];
/* 805 */     for (int i = 0; i < paramValues.length; ++i)
/*     */     {
/* 807 */       if (paramValues[i] == null)
/*     */       {
/* 809 */         newValues[i] = paramValues[i];
/*     */       }
/*     */       else {
/*     */         try
/*     */         {
/* 814 */           newValues[i] = new String(paramValues[i].getBytes(encoding), "UTF-8");
/*     */         }
/*     */         catch (UnsupportedEncodingException e)
/*     */         {
/* 818 */           e.printStackTrace();
/* 819 */           newValues[i] = paramValues[i];
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 824 */     return newValues;
/*     */   }
/*     */ }
