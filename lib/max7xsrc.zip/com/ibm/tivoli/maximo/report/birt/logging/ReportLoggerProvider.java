package com.ibm.tivoli.maximo.report.birt.logging;

public abstract interface ReportLoggerProvider
{
  public abstract ReportLogger getLogger(String paramString);
}
