/*    */ package com.ibm.tivoli.maximo.report.birt.admin;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 











/*    */ public class ReportImportParamInfo
/*    */   implements Serializable
/*    */ {
/*    */   private HashMap<String, String> attributeMap;
/*    */ 
/*    */   public ReportImportParamInfo()
/*    */   {
/* 26 */     this.attributeMap = new HashMap();
/*    */   }

/*    */   public void setAttribute(String attributeName, String attributeValue) {
/* 30 */     this.attributeMap.put(attributeName, attributeValue);
/*    */   }

/*    */   public String getAttribute(String attributeName)
/*    */   {
/* 35 */     return ((String)this.attributeMap.get(attributeName));
/*    */   }

/*    */   public void removeAttribute(String attributeName)
/*    */   {
/* 40 */     this.attributeMap.remove(attributeName);
/*    */   }

/*    */   public void reset()
/*    */   {
/* 45 */     this.attributeMap = new HashMap();
/*    */   }

/*    */   public Iterator getAttributes()
/*    */   {
/* 50 */     return this.attributeMap.keySet().iterator();
/*    */   }
/*    */ }
