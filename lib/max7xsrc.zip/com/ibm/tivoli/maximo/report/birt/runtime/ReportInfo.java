/*    */ package com.ibm.tivoli.maximo.report.birt.runtime;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ 







/*    */ public class ReportInfo
/*    */   implements Serializable
/*    */ {
/*    */   private String reportName;
/*    */   private String reportDesign;
/*    */   private byte[] reportResources;
/*    */   private String propertiesFileName;
/*    */   private HashMap properties;
/*    */   private ArrayList libraryReportInfoList;
/*    */ 
/*    */   public ReportInfo()
/*    */   {
/* 27 */     this.reportName = null;
/*    */ 
/* 29 */     this.reportDesign = null;
/*    */ 
/* 31 */     this.reportResources = null;
/*    */ 
/* 33 */     this.propertiesFileName = null;
/*    */ 
/* 35 */     this.properties = null;

/*    */ 
/* 38 */     this.libraryReportInfoList = new ArrayList();
/*    */   }

/*    */   public HashMap getProperties() {
/* 42 */     return this.properties;
/*    */   }

/*    */   public void setProperties(HashMap properties)
/*    */   {
/* 47 */     this.properties = properties;
/*    */   }

/*    */   public String getPropertiesFileName()
/*    */   {
/* 52 */     return this.propertiesFileName;
/*    */   }

/*    */   public void setPropertiesFileName(String propertiesFileName)
/*    */   {
/* 57 */     this.propertiesFileName = propertiesFileName;
/*    */   }

/*    */   public String getReportDesign()
/*    */   {
/* 62 */     return this.reportDesign;
/*    */   }

/*    */   public void setReportDesign(String reportDesign)
/*    */   {
/* 67 */     this.reportDesign = reportDesign;
/*    */   }

/*    */   public String getReportName()
/*    */   {
/* 72 */     return this.reportName;
/*    */   }

/*    */   public void setReportName(String reportName)
/*    */   {
/* 77 */     this.reportName = reportName;
/*    */   }

/*    */   public byte[] getReportResources()
/*    */   {
/* 82 */     return this.reportResources;
/*    */   }

/*    */   public void setReportResources(byte[] reportResources)
/*    */   {
/* 87 */     this.reportResources = reportResources;
/*    */   }

/*    */   public void addLibraryInfo(ReportInfo libraryInfo)
/*    */   {
/* 92 */     this.libraryReportInfoList.add(libraryInfo);
/*    */   }

/*    */   public Iterator getLibraries()
/*    */   {
/* 97 */     return this.libraryReportInfoList.iterator();
/*    */   }
/*    */ }
