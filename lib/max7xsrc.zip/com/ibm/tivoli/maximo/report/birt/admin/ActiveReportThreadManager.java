/*     */ package com.ibm.tivoli.maximo.report.birt.admin;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportExecutionTask;
/*     */ import com.ibm.tivoli.maximo.report.birt.runtime.ReportExecutionTaskProvider;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.MXServerRemote;
/*     */ import psdi.server.MaximoThread;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 





/*     */ public class ActiveReportThreadManager
/*     */ {
/*  42 */   private static ActiveReportThreadManager activeReportThreadManager = new ActiveReportThreadManager();
/*     */   public static final int DEFAULT_MAX_CONCURRENT_THREADCOUNT = 3;
/*     */   public static final String PROPERTY_MAXCONCURRENTRUN = "mxe.report.birt.maxconcurrentrun";
/*  54 */   private static final Integer STATUS_ACTIVE = new Integer(1);
/*  55 */   private static final Integer STATUS_CANCEL = new Integer(2);
/*     */ 
/*  57 */   private static Object lockObject = new Object();
/*     */ 
/*  59 */   private MXLogger reportLogger = null;
/*  60 */   private HashMap<String, ActiveThreadInfo> activeThreads = new HashMap();
/*     */ 
/*  63 */   private HashMap<Long, ActiveThreadInfo> activeJobs = new HashMap();
/*     */ 
/*  75 */   static Object activeReportLock = new Object();
/*     */ 
/*     */   public static ActiveReportThreadManager getActiveReportThreadManager()
/*     */   {
/*  46 */     return activeReportThreadManager;
/*     */   }


















/*     */   private ActiveReportThreadManager()
/*     */   {
/*  68 */     this.reportLogger = MXLoggerFactory.getLogger("maximo.report.birt");

/*     */ 
/*  71 */     ReportStuckThreadLoggerThread t = new ReportStuckThreadLoggerThread();
/*  72 */     t.start();
/*     */   }





/*     */   public synchronized Long addActiveThread(String threadName, String reportName, String appName, String userName, boolean scheduledJob)
/*     */   {
/*  81 */     MXServer mxServer = null;
/*  82 */     long startTime = 0L;
/*     */     try
/*     */     {
/*  85 */       mxServer = MXServer.getMXServer();
/*  86 */       startTime = mxServer.getDate().getTime();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  90 */       ex.printStackTrace();
/*     */     }
/*     */ 
/*  93 */     synchronized (lockObject)
/*     */     {
/*  95 */       ActiveThreadInfo activeThreadInfo = (ActiveThreadInfo)this.activeThreads.get(threadName);
/*     */ 
/*  97 */       if (activeThreadInfo != null)
/*     */       {
/*  99 */         long reportJobId = activeThreadInfo.getReportJobId();
/* 100 */         return new Long(reportJobId);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     while (true) {
/*     */       try
/*     */       {
/* 108 */         synchronized (activeReportLock)
/*     */         {
/* 110 */           if (isOverloaded())
/*     */           {
/* 112 */             activeReportLock.wait();
/*     */           }
/*     */ 
/* 115 */           if (!(isOverloaded()))
/*     */           {
/* 117 */             break label150:
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 123 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/* 127 */     label150: long reportJobId = 0L;

/*     */ 
/* 130 */     if (!(scheduledJob))


/*     */     {
/*     */       try
/*     */       {
/* 136 */         UserInfo systemUserInfo = mxServer.getSystemUserInfo();
/* 137 */         reportJobId = createReportJob(systemUserInfo, reportName, appName, userName, scheduledJob, startTime);

/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 142 */         ex.printStackTrace();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 147 */     ActiveThreadInfo aThreadInfo = new ActiveThreadInfo();
/* 148 */     aThreadInfo.setStartTime(startTime);
/* 149 */     aThreadInfo.setReportName(reportName);
/* 150 */     aThreadInfo.setAppName(appName);
/* 151 */     aThreadInfo.setUserName(userName);
/* 152 */     aThreadInfo.setScheduledJob(scheduledJob);
/* 153 */     aThreadInfo.setReportJobId(reportJobId);
/*     */ 
/* 155 */     boolean addedThread = false;
/* 156 */     synchronized (lockObject)
/*     */     {
/* 158 */       this.activeThreads.put(threadName, aThreadInfo);
/* 159 */       addedThread = true;
/*     */ 
/* 161 */       if (reportJobId != 0L)
/*     */       {
/* 163 */         this.activeJobs.put(new Long(reportJobId), aThreadInfo);
/*     */       }
/*     */     }
/*     */ 
/* 167 */     if ((addedThread) && (this.reportLogger.isDebugEnabled()))
/*     */     {
/* 169 */       this.reportLogger.debug("Added active report thread: [" + threadName + "], Is this a ScheduledJob? = " + scheduledJob + ", reportJobId = " + reportJobId);
/*     */     }
/*     */ 
/* 172 */     return new Long(reportJobId);
/*     */   }




/*     */   public long createReportJob(UserInfo userInfo, String reportName, String appName, String userName, boolean scheduledJob, long startTime)
/*     */     throws MXException, RemoteException
/*     */   {
/* 181 */     MXServer mxServer = MXServer.getMXServer();
/*     */ 
/* 183 */     MboSetRemote reportJobSet = mxServer.getMboSet("REPORTJOB", userInfo);
/*     */ 
/* 185 */     MboRemote reportJob = reportJobSet.add();
/* 186 */     if (reportJob == null)
/*     */     {
/* 188 */       return 0L;
/*     */     }
/*     */ 
/* 191 */     long reportJobId = reportJob.getUniqueIDValue();
/*     */ 
/* 193 */     reportJob.setValue("APPNAME", appName);
/* 194 */     reportJob.setValue("REPORTNAME", reportName);
/* 195 */     reportJob.setValue("ISIMMEDIATE", !(scheduledJob));
/* 196 */     reportJob.setValue("STARTTIME", new Date(startTime));
/* 197 */     reportJob.setValue("USERID", userName);
/* 198 */     reportJob.setValue("HOSTNAME", mxServer.getServerHost());
/* 199 */     reportJob.setValue("SERVERNAME", mxServer.getName());
/* 200 */     reportJob.setValue("STATUS", "ACTIVE");
/*     */ 
/* 202 */     reportJobSet.save();
/* 203 */     reportJobSet.reset();
/*     */ 
/* 205 */     return reportJobId;
/*     */   }


/*     */   public long getReportJobId(String threadName)
/*     */   {
/* 211 */     ActiveThreadInfo aThreadInfo = null;
/* 212 */     long reportJobId = 0L;
/*     */ 
/* 214 */     synchronized (lockObject)
/*     */     {
/* 216 */       aThreadInfo = (ActiveThreadInfo)this.activeThreads.get(threadName);
/* 217 */       if (aThreadInfo != null)
/*     */       {
/* 219 */         reportJobId = aThreadInfo.getReportJobId();
/*     */       }
/*     */     }
/*     */ 
/* 223 */     return reportJobId;
/*     */   }

/*     */   public void removeActiveThread(String threadName)
/*     */   {
/* 228 */     ActiveThreadInfo aThreadInfo = null;
/* 229 */     long reportJobId = 0L;
/* 230 */     boolean scheduledJob = false;
/*     */ 
/* 232 */     boolean removedThread = false;
/* 233 */     synchronized (lockObject)
/*     */     {
/* 235 */       aThreadInfo = (ActiveThreadInfo)this.activeThreads.remove(threadName);
/* 236 */       removedThread = true;
/* 237 */       if (aThreadInfo != null)
/*     */       {
/* 239 */         reportJobId = aThreadInfo.getReportJobId();
/* 240 */         scheduledJob = aThreadInfo.isScheduledJob();
/*     */       }
/*     */     }
/*     */ 
/* 244 */     if ((removedThread) && (this.reportLogger.isDebugEnabled()))
/*     */     {
/* 246 */       this.reportLogger.debug("Removed active report thread: [" + threadName + "]");
/*     */     }
/*     */ 
/* 249 */     if (reportJobId != 0L)
/*     */     {
/*     */       try
/*     */       {
/* 253 */         if (scheduledJob)
/*     */         {
/* 255 */           ReportExecutionTask task = ReportExecutionTaskProvider.getReportExecutionTask();
/* 256 */           if (task != null)
/*     */           {
/* 258 */             task.removeReportJob(reportJobId);
/*     */           }
/*     */         }
/*     */ 
/* 262 */         UserInfo systemUserInfo = MXServer.getMXServer().getSystemUserInfo();
/* 263 */         removeReportJob(systemUserInfo, reportJobId);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 267 */         ex.printStackTrace();
/*     */       }
/*     */ 
/* 270 */       synchronized (lockObject)
/*     */       {
/* 272 */         this.activeJobs.remove(new Long(reportJobId));
/*     */       }
/*     */ 
/* 275 */       if (this.reportLogger.isDebugEnabled())
/*     */       {
/* 277 */         this.reportLogger.debug("Removed ReportJobId: [" + reportJobId + "]");
/*     */       }
/*     */     }
/*     */ 
/* 281 */     synchronized (activeReportLock)
/*     */     {
/* 283 */       activeReportLock.notify();
/*     */     }
/*     */   }




/*     */   public void removeReportJob(UserInfo userInfo, long reportJobId)
/*     */     throws MXException, RemoteException
/*     */   {
/* 293 */     MXServer mxServer = MXServer.getMXServer();
/*     */ 
/* 295 */     MboSetRemote reportJobSet = mxServer.getMboSet("REPORTJOB", userInfo);
/* 296 */     reportJobSet.setQbeExactMatch(true);
/* 297 */     reportJobSet.setQbe("REPORTJOBID", "" + reportJobId);
/* 298 */     reportJobSet.reset();
/*     */ 
/* 300 */     MboRemote reportJob = reportJobSet.getMbo(0);
/* 301 */     if (reportJob == null)
/*     */     {
/* 303 */       return;
/*     */     }
/*     */ 
/* 306 */     reportJob.delete();
/*     */ 
/* 308 */     reportJobSet.save();
/* 309 */     reportJobSet.reset();
/*     */   }

/*     */   public void cancelReportJob(long reportJobId)
/*     */   {
/* 314 */     boolean cancelled = cancelReportJobOnThisServer(reportJobId);
/* 315 */     if (cancelled)
/*     */     {
/* 317 */       return;







/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 329 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/* 331 */       UserInfo userInfo = mxServer.getSystemUserInfo();
/*     */ 
/* 333 */       MboSetRemote reportJobSet = mxServer.getMboSet("REPORTJOB", userInfo);
/* 334 */       reportJobSet.setQbeExactMatch(true);
/* 335 */       reportJobSet.setQbe("REPORTJOBID", "" + reportJobId);
/* 336 */       reportJobSet.reset();
/*     */ 
/* 338 */       MboRemote reportJob = reportJobSet.getMbo(0);
/* 339 */       if (reportJob == null)
/*     */       {
/* 341 */         return;
/*     */       }
/*     */ 
/* 344 */       String hostName = reportJob.getString("HOSTNAME");
/* 345 */       String serverName = reportJob.getString("SERVERNAME");



/*     */ 
/* 350 */       String rmiRegistryPort = mxServer.getProperty("mxe.registry.port");
/*     */ 
/* 352 */       String rmiBinding = "rmi://" + hostName + ":" + rmiRegistryPort + "/" + serverName;
/*     */ 
/* 354 */       MXServerRemote mxServer1 = (MXServerRemote)Naming.lookup(rmiBinding);
/* 355 */       ReportAdminServiceRemote reportAdminService = (ReportAdminServiceRemote)mxServer1.lookup("BIRTREPORT");
/* 356 */       reportAdminService.cancelReportJobOnThisServer(reportJobId);

/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 361 */       ex.printStackTrace();
/*     */     }
/*     */   }


/*     */   public boolean cancelReportJobOnThisServer(long reportJobId)
/*     */   {
/* 368 */     boolean scheduledJob = false;
/*     */ 
/* 370 */     synchronized (lockObject)
/*     */     {
/* 372 */       int jobStatus = 0;
/*     */ 
/* 374 */       ActiveThreadInfo aThreadInfo = (ActiveThreadInfo)this.activeJobs.get(new Long(reportJobId));

/*     */ 
/* 377 */       if (aThreadInfo != null)
/*     */       {
/* 379 */         aThreadInfo.setJobStatus(STATUS_CANCEL.intValue());
/* 380 */         scheduledJob = aThreadInfo.isScheduledJob();
/*     */ 
/* 382 */         if (this.reportLogger.isDebugEnabled())
/*     */         {
/* 384 */           this.reportLogger.debug("Marked the active report thread status to CANCEL for ReportJobId: [" + reportJobId + "]");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 393 */       if (scheduledJob)
/*     */       {
/* 395 */         ReportExecutionTask task = ReportExecutionTaskProvider.getReportExecutionTask();
/* 396 */         if (task != null)
/*     */         {
/* 398 */           if (this.reportLogger.isDebugEnabled())
/*     */           {
/* 400 */             this.reportLogger.debug("Calling BIRT API to CANCEL the report job ReportJobId: [" + reportJobId + "]");
/*     */           }
/*     */ 
/* 403 */           task.cancelReportJob(reportJobId);
/*     */ 
/* 405 */           if (this.reportLogger.isDebugEnabled())
/*     */           {
/* 407 */             this.reportLogger.debug("Finished Calling BIRT API to CANCEL the report job ReportJobId: [" + reportJobId + "]");
/*     */           }
/*     */ 
/* 410 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 416 */       ex.printStackTrace();
/*     */     }
/*     */ 
/* 419 */     return false;
/*     */   }

/*     */   public boolean isReportJobCancelled(long reportJobId)
/*     */   {
/* 424 */     synchronized (lockObject)
/*     */     {
/* 426 */       ActiveThreadInfo aThreadInfo = (ActiveThreadInfo)this.activeJobs.get(new Long(reportJobId));

/*     */ 
/* 429 */       if ((aThreadInfo != null) && 

/* 431 */         (aThreadInfo.getJobStatus() == STATUS_CANCEL.intValue()))
/*     */       {
/* 433 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 438 */     return false;
/*     */   }

/*     */   public void renewActiveThread(String threadName)
/*     */   {
/* 443 */     boolean isScheduledJob = false;
/* 444 */     long scheduledJobId = 0L;
/*     */ 
/* 446 */     synchronized (lockObject)
/*     */     {
/* 448 */       ActiveThreadInfo aThreadInfo = (ActiveThreadInfo)this.activeThreads.get(threadName);
/* 449 */       if (aThreadInfo == null)
/*     */       {
/* 451 */         return;
/*     */       }
/*     */ 
/* 454 */       aThreadInfo.setRenewTime(System.currentTimeMillis());
/*     */ 
/* 456 */       isScheduledJob = aThreadInfo.isScheduledJob();
/* 457 */       scheduledJobId = aThreadInfo.getScheduledJobId();


/*     */     }
/*     */ 
/* 462 */     if (!(isScheduledJob))
/*     */       return;
/* 464 */     renewLock(scheduledJobId);
/*     */   }


/*     */   private void renewLock(long scheduledJobId)
/*     */   {
/* 470 */     MboSetRemote msr = null;

/*     */     try
/*     */     {
/* 474 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/* 476 */       UserInfo sysUserInfo = mxServer.getSystemUserInfo();
/*     */ 
/* 478 */       msr = mxServer.getMboSet("REPORTRUNLOCK", sysUserInfo);
/* 479 */       msr.setQbe("REPORTRUNQUEUEID", "" + scheduledJobId);
/* 480 */       MboRemote mr = msr.getMbo(0);
/* 481 */       if (mr == null)
/*     */       {
/*     */         return;
/*     */       }
/*     */ 
/* 486 */       mr.setValue("LOCKTIME", mxServer.getDate());
/* 487 */       msr.save();
/* 488 */       msr.reset();

/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 493 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 495 */         this.reportLogger.error("Failed to renew report lock on reportrunqueueid: " + scheduledJobId, t);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 501 */         if (msr != null)
/*     */         {
/* 503 */           msr.reset();
/*     */         }
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */       }
/*     */     }
/*     */   }

/*     */   public void updateActiveThread(String threadName, String reportName, String appName, String userName, boolean scheduledJob, long scheduleJobId) {
/* 513 */     long startTime = 0L;
/*     */ 
/* 515 */     synchronized (lockObject)
/*     */     {
/* 517 */       ActiveThreadInfo aThreadInfo = (ActiveThreadInfo)this.activeThreads.get(threadName);
/* 518 */       if (aThreadInfo == null)
/*     */       {
/* 520 */         return;
/*     */       }
/*     */ 
/* 523 */       aThreadInfo.setReportName(reportName);
/* 524 */       aThreadInfo.setAppName(appName);
/* 525 */       aThreadInfo.setUserName(userName);
/* 526 */       aThreadInfo.setScheduledJob(scheduledJob);
/* 527 */       aThreadInfo.setScheduledJobId(scheduleJobId);
/*     */ 
/* 529 */       startTime = aThreadInfo.getStartTime();
/*     */     }
/*     */ 
/* 532 */     long reportJobId = 0L;

/*     */ 
/* 535 */     if (!(scheduledJob)) {
/*     */       return;
/*     */     }
/*     */     try
/*     */     {
/* 540 */       MXServer mxServer = MXServer.getMXServer();
/* 541 */       UserInfo systemUserInfo = mxServer.getSystemUserInfo();
/* 542 */       reportJobId = createReportJob(systemUserInfo, reportName, appName, userName, scheduledJob, startTime);

/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 547 */       ex.printStackTrace();
/*     */     }
/*     */ 
/* 550 */     synchronized (lockObject)
/*     */     {
/* 552 */       ActiveThreadInfo aThreadInfo = (ActiveThreadInfo)this.activeThreads.get(threadName);
/* 553 */       if (aThreadInfo == null)
/*     */       {
/* 555 */         return;
/*     */       }
/*     */ 
/* 558 */       aThreadInfo.setReportJobId(reportJobId);
/* 559 */       if (reportJobId != 0L)
/*     */       {
/* 561 */         this.activeJobs.put(new Long(reportJobId), aThreadInfo);
/*     */       }
/*     */     }
/*     */ 
/* 565 */     if (!(this.reportLogger.isDebugEnabled()))
/*     */       return;
/* 567 */     this.reportLogger.debug("Updated active report thread: [" + threadName + "], Is this a ScheduledJob? = " + scheduledJob + ", reportJobId = " + reportJobId);
/*     */   }




/*     */   public boolean isOverloaded()
/*     */   {
/* 575 */     int noOfActiveReportThreads = 0;
/*     */ 
/* 577 */     synchronized (lockObject)

/*     */     {
/* 580 */       noOfActiveReportThreads = this.activeThreads.size();


/*     */     }
/*     */ 
/* 585 */     int maxAllowed = getMaxAllowedActiveReportThreads();
/* 586 */     if (noOfActiveReportThreads >= maxAllowed)
/*     */     {
/* 588 */       if (this.reportLogger.isDebugEnabled())
/*     */       {
/* 590 */         StringBuffer buf = new StringBuffer();
/* 591 */         buf.append("**** BIRT REPORTS OVERLOADED ****");
/* 592 */         buf.append("\n");
/* 593 */         buf.append("**** current mxe.report.birt.maxconcurrentrun = " + maxAllowed);
/* 594 */         buf.append("\n");
/* 595 */         buf.append("**** No of active report thread known = " + noOfActiveReportThreads);
/* 596 */         buf.append("\n");
/* 597 */         if (this.reportLogger.isDebugEnabled())
/*     */         {
/* 599 */           this.reportLogger.debug(buf.toString());
/*     */         }
/*     */       }
/*     */ 
/* 603 */       return true;
/*     */     }
/*     */ 
/* 606 */     return false;
/*     */   }



/*     */   public int getMaxAllowedActiveReportThreads()
/*     */   {
/*     */     try
/*     */     {
/* 615 */       MXServer mxServer = MXServer.getMXServer();
/*     */ 
/* 617 */       String maxCRunStr = mxServer.getProperty("mxe.report.birt.maxconcurrentrun");
/* 618 */       if (maxCRunStr == null)
/*     */       {
/* 620 */         return 3;
/*     */       }
/*     */ 
/* 623 */       int maxAllowed = Integer.valueOf(maxCRunStr).intValue();
/*     */ 
/* 625 */       return maxAllowed;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 629 */       if (this.reportLogger.isErrorEnabled())
/*     */       {
/* 631 */         this.reportLogger.error("Failed to obtain [mxe.report.birt.maxconcurrentrun] property value. Assuming default [3].", e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 636 */     return 3;
/*     */   }
/*     */   class ActiveThreadInfo/*     */     implements Cloneable/*     */   {/*     */     private long startTime;/*     */     private long renewTime;/*     */     private String reportName;/*     */     private String appName;/*     */     private String userName;/*     */     private boolean scheduledJob;/*     */     private long scheduledJobId;/*     */     private long reportJobId;/*     */     private int jobStatus;/*     */ 
/*     */     ActiveThreadInfo()
/*     */     {
/* 641 */       this.startTime = 0L;
/* 642 */       this.renewTime = 0L;


/*     */ 
/* 646 */       this.scheduledJob = false;
/* 647 */       this.scheduledJobId = 0L;
/* 648 */       this.reportJobId = 0L;
/* 649 */       this.jobStatus = ActiveReportThreadManager.STATUS_ACTIVE.intValue();
/*     */     }

/*     */     public void setStartTime(long sTime) {
/* 653 */       this.startTime = sTime;
/* 654 */       this.renewTime = sTime;
/*     */     }

/*     */     public long getStartTime()
/*     */     {
/* 659 */       return this.startTime;
/*     */     }

/*     */     public void setRenewTime(long rTime)
/*     */     {
/* 664 */       this.renewTime = rTime;
/*     */     }

/*     */     public long getRenewTime()
/*     */     {
/* 669 */       return this.renewTime;
/*     */     }

/*     */     public String getAppName()
/*     */     {
/* 674 */       return this.appName;
/*     */     }

/*     */     public void setAppName(String appName)
/*     */     {
/* 679 */       this.appName = appName;
/*     */     }

/*     */     public String getReportName()
/*     */     {
/* 684 */       return this.reportName;
/*     */     }

/*     */     public void setReportName(String reportName)
/*     */     {
/* 689 */       this.reportName = reportName;
/*     */     }

/*     */     public String getUserName()
/*     */     {
/* 694 */       return this.userName;
/*     */     }

/*     */     public void setUserName(String userName)
/*     */     {
/* 699 */       this.userName = userName;
/*     */     }

/*     */     public boolean isScheduledJob()
/*     */     {
/* 704 */       return this.scheduledJob;
/*     */     }

/*     */     public void setScheduledJob(boolean scheduledJob)
/*     */     {
/* 709 */       this.scheduledJob = scheduledJob;
/*     */     }

/*     */     public long getScheduledJobId()
/*     */     {
/* 714 */       return this.scheduledJobId;
/*     */     }

/*     */     public void setScheduledJobId(long scheduleJobId)
/*     */     {
/* 719 */       this.scheduledJobId = scheduleJobId;
/*     */     }

/*     */     public long getReportJobId()
/*     */     {
/* 724 */       return this.reportJobId;
/*     */     }

/*     */     public void setReportJobId(long reportJobId)
/*     */     {
/* 729 */       this.reportJobId = reportJobId;
/*     */     }

/*     */     public int getJobStatus()
/*     */     {
/* 734 */       return this.jobStatus;
/*     */     }

/*     */     public void setJobStatus(int jobStatus)
/*     */     {
/* 739 */       this.jobStatus = jobStatus;
/*     */     }

/*     */     public Object clone() throws CloneNotSupportedException
/*     */     {
/* 744 */       ActiveThreadInfo copy = (ActiveThreadInfo)super.clone();
/* 745 */       return copy;
/*     */     }
/*     */   }



/*     */   class ReportStuckThreadLoggerThread extends MaximoThread
/*     */   {
/* 752 */     private long sleepTime = 300000L;
/* 753 */     private long stuckTime = 600000L;
/* 754 */     private long maxStuckTime = 3L * this.stuckTime;
/*     */ 
/*     */     public ReportStuckThreadLoggerThread()
/*     */     {
/* 759 */       super("ReportStuckThreadLoggerThread");
/*     */     }

/*     */     public void run()
/*     */     {
/*     */       label697: 
/*     */       while (true)
/*     */         try
/*     */         {
/* 768 */           Thread.sleep(this.sleepTime);
/*     */ 
/* 770 */           if (isMarkedForShutDown())

/*     */           {
/*     */             return;
/*     */           }
/*     */ 
/* 776 */           HashMap stuckThreadList = new HashMap();

/*     */ 
/* 779 */           synchronized (ActiveReportThreadManager.lockObject)
/*     */           {
/* 781 */             Iterator nameIterator = ActiveReportThreadManager.this.activeThreads.keySet().iterator();
/* 782 */             while (nameIterator.hasNext())
/*     */             {
/* 784 */               String threadName = (String)nameIterator.next();
/*     */ 
/* 786 */               ActiveReportThreadManager.ActiveThreadInfo info = (ActiveReportThreadManager.ActiveThreadInfo)ActiveReportThreadManager.this.activeThreads.get(threadName);
/*     */ 
/* 788 */               ActiveReportThreadManager.ActiveThreadInfo clonedInfo = (ActiveReportThreadManager.ActiveThreadInfo)info.clone();
/*     */ 
/* 790 */               long renewTime = clonedInfo.getRenewTime();
/* 791 */               if (System.currentTimeMillis() - renewTime > this.stuckTime)
/*     */               {
/* 793 */                 stuckThreadList.put(threadName, clonedInfo);
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 798 */           if (isMarkedForShutDown())

/*     */           {
/*     */             return;
/*     */           }
/*     */ 
/* 804 */           Iterator stuckThreadNameIterator = stuckThreadList.keySet().iterator();
/* 805 */           while (stuckThreadNameIterator.hasNext())
/*     */           {
/* 807 */             String stuckThreadName = (String)stuckThreadNameIterator.next();
/*     */ 
/* 809 */             ActiveReportThreadManager.ActiveThreadInfo info = (ActiveReportThreadManager.ActiveThreadInfo)stuckThreadList.get(stuckThreadName);
/*     */ 
/* 811 */             long startTime = info.getStartTime();
/* 812 */             long renewTime = info.getRenewTime();
/* 813 */             String appName = info.getAppName();
/* 814 */             String reportName = info.getReportName();
/* 815 */             String userName = info.getUserName();
/* 816 */             boolean scheduledJob = info.isScheduledJob();
/*     */ 
/* 818 */             if (ActiveReportThreadManager.this.reportLogger.isErrorEnabled())
/*     */             {
/* 820 */               StringBuffer buf = new StringBuffer();
/* 821 */               buf.append("A thread running a report seems to be stuck. Details: threadName=[");
/* 822 */               buf.append(stuckThreadName);
/* 823 */               buf.append("], report=[");
/* 824 */               buf.append(reportName);
/* 825 */               buf.append("], app=[");
/* 826 */               buf.append(appName);
/* 827 */               buf.append("], user=[");
/* 828 */               buf.append(userName);
/* 829 */               buf.append("], scheduledJob=[");
/* 830 */               buf.append(scheduledJob);
/* 831 */               buf.append("], startTime[");
/* 832 */               buf.append(new Date(startTime).toString());
/* 833 */               buf.append("], stuck for [");
/* 834 */               buf.append((System.currentTimeMillis() - renewTime) / 1000L);
/* 835 */               buf.append(" seconds ");
/* 836 */               buf.append("] ");
/*     */ 
/* 838 */               ActiveReportThreadManager.this.reportLogger.error(buf.toString());


/*     */               try
/*     */               {
/* 843 */                 StackTraceElement[] stackTrace = (StackTraceElement[])Thread.getAllStackTraces().get(stuckThreadName);
/* 844 */                 if (stackTrace != null)
/*     */                 {
/* 846 */                   String lineSeparator = System.getProperty("line.separator");
/*     */ 
/* 848 */                   buf.append(lineSeparator);
/* 849 */                   buf.append("Current Stack Trace of the thread: " + stuckThreadName);
/* 850 */                   buf.append(stuckThreadName);
/* 851 */                   buf.append(lineSeparator);
/*     */ 
/* 853 */                   for (int i = 0; i < stackTrace.length; ++i)
/*     */                   {
/* 855 */                     StackTraceElement ste = stackTrace[i];
/* 856 */                     buf.append(ste.toString());
/* 857 */                     buf.append(lineSeparator);
/*     */                   }
/*     */                 }
/*     */               }
/*     */               catch (Throwable t)
/*     */               {
/*     */               }
/*     */             }
/* 865 */             if (System.currentTimeMillis() - renewTime > this.maxStuckTime)

/*     */             {
/* 868 */               ActiveReportThreadManager.this.removeActiveThread(stuckThreadName);
/*     */ 
/* 870 */               if (ActiveReportThreadManager.this.reportLogger.isWarnEnabled())
/*     */               {
/* 872 */                 StringBuffer buf = new StringBuffer();
/* 873 */                 buf.append("The stuck report thread [");
/* 874 */                 buf.append(stuckThreadName);
/* 875 */                 buf.append("] is removed from the active report thread list to give a chance to run reports.");
/*     */ 
/* 877 */                 ActiveReportThreadManager.this.reportLogger.warn(buf.toString());
/*     */               }
/*     */             }
/*     */ 
/* 881 */             if (isMarkedForShutDown()) {
/*     */               break;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (InterruptedException ex)
/*     */         {
/* 890 */           if (isMarkedForShutDown())
/*     */           {
/* 892 */             return;
/*     */           }
/*     */         }
/*     */         catch (Throwable t)
/*     */         {
/* 897 */           if (ActiveReportThreadManager.this.reportLogger.isErrorEnabled())
/*     */           {
/* 899 */             ActiveReportThreadManager.this.reportLogger.error(t.getMessage(), t);
/*     */           }
/*     */ 
/* 902 */           if (!(isMarkedForShutDown()))
/*     */             break label697;
/*     */         }
/*     */     }
/*     */   }
/*     */ }
