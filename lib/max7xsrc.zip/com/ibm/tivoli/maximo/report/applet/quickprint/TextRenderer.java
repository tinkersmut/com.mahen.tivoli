/*     */ package com.ibm.tivoli.maximo.report.applet.quickprint;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Pageable;
/*     */ import java.awt.print.Printable;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.net.URL;
/*     */ import java.util.Vector;
/*     */ 



















/*     */ public class TextRenderer
/*     */   implements Pageable, Printable
/*     */ {
/*  44 */   public static String FONTFAMILY = "Monospaced";
/*  45 */   public static int FONTSIZE = 10;
/*  46 */   public static int FONTSTYLE = 0;
/*  47 */   public static float LINESPACEFACTOR = 1.1F;
/*     */   PageFormat format;
/*     */   Vector lines;
/*     */   Font font;
/*     */   int linespacing;
/*     */   int linesPerPage;
/*     */   int numPages;
/*     */   int baseline;
/*     */ 
/*     */   public TextRenderer(Reader stream, PageFormat format)
/*     */     throws IOException
/*     */   {
/*  55 */     this.baseline = -1;
/*     */   public TextRenderer(String text, PageFormat format)
/*     */     throws IOException
/*     */   {
/*  59 */     this(new StringReader(text), format);
/*     */   }

/*     */   public TextRenderer(URL fileURL, PageFormat format) throws IOException
/*     */   {
/*  64 */     this(new InputStreamReader(fileURL.openStream()), format);
/*     */   }


/*     */ 
/*  69 */     this.format = format;


/*     */ 
/*  73 */     BufferedReader in = new BufferedReader(stream);
/*  74 */     this.lines = new Vector();
/*     */ 
/*  76 */     while ((line = in.readLine()) != null)
/*     */     {/*     */       String line;/*  77 */       this.lines.addElement(line);
/*     */     }
/*     */ 
/*  80 */     this.font = new Font(FONTFAMILY, FONTSTYLE, FONTSIZE);
/*  81 */     this.linespacing = (int)(FONTSIZE * LINESPACEFACTOR);

/*     */ 
/*  84 */     this.linesPerPage = (int)Math.floor(format.getImageableHeight() / this.linespacing);
/*  85 */     this.numPages = ((this.lines.size() - 1) / this.linesPerPage + 1);
/*     */   }


/*     */   public int getNumberOfPages()
/*     */   {
/*  91 */     return this.numPages; } 







/*     */   public int print(Graphics g, PageFormat format, int pagenum)
/*     */   {
/* 101 */     if ((((pagenum < 0) ? 1 : 0) | ((pagenum >= this.numPages) ? 1 : 0)) != 0) {
/* 102 */       return 1;

/*     */     }
/*     */ 
/* 106 */     if (this.baseline == -1) {
/* 107 */       FontMetrics fm = g.getFontMetrics(this.font);
/* 108 */       this.baseline = fm.getAscent();


/*     */     }
/*     */ 
/* 113 */     g.setColor(Color.white);
/* 114 */     g.fillRect((int)format.getImageableX(), (int)format.getImageableY(), (int)format.getImageableWidth(), (int)format.getImageableHeight());




/*     */ 
/* 120 */     g.setFont(this.font);
/* 121 */     g.setColor(Color.black);

/*     */ 
/* 124 */     int startLine = pagenum * this.linesPerPage;
/* 125 */     int endLine = startLine + this.linesPerPage - 1;
/* 126 */     if (endLine >= this.lines.size()) {
/* 127 */       endLine = this.lines.size() - 1;
/*     */     }
/*     */ 
/* 130 */     int x0 = (int)format.getImageableX();
/* 131 */     int y0 = (int)format.getImageableY() + this.baseline;

/*     */ 
/* 134 */     for (int i = startLine; i <= endLine; ++i)
/*     */     {
/* 136 */       String line = (String)this.lines.elementAt(i);




/*     */ 
/* 142 */       if (line.length() > 0) {
/* 143 */         g.drawString(line, x0, y0);
/*     */       }
/*     */ 
/* 146 */       y0 += this.linespacing;

/*     */     }
/*     */ 
/* 150 */     return 0;
/*     */   }
/*     */ }
