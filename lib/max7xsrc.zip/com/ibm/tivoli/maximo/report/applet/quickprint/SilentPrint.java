/*     */ package com.ibm.tivoli.maximo.report.applet.quickprint;
/*     */ 
/*     */ import java.applet.Applet;
/*     */ import java.applet.AppletContext;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.PrinterJob;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.AbstractList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import javax.print.Doc;
/*     */ import javax.print.DocFlavor;
/*     */ import javax.print.DocFlavor.INPUT_STREAM;
/*     */ import javax.print.DocPrintJob;
/*     */ import javax.print.PrintService;
/*     */ import javax.print.PrintServiceLookup;
/*     */ import javax.print.SimpleDoc;
/*     */ import javax.print.attribute.HashPrintRequestAttributeSet;
/*     */ import javax.print.attribute.IntegerSyntax;
/*     */ import javax.print.attribute.PrintRequestAttributeSet;
/*     */ import javax.print.attribute.standard.Copies;
/*     */ import javax.print.attribute.standard.QueuedJobCount;
/*     */ 



/*     */ public class SilentPrint extends Applet
/*     */ {
/*     */   private Vector curDoclinks;
/*     */   private boolean debug;
/*     */   private boolean dummyPrint;
/*     */   private boolean twopasspdf;
/*     */   private long printwait;
/*     */   private boolean padRequest;
/*     */   private PrintService defaultPrintService;
/*     */   private boolean continueWait;
/*     */   private HttpURLConnection connection;
/*     */   static Class class$javax$print$attribute$standard$QueuedJobCount;
/*     */ 
/*     */   public SilentPrint()
/*     */   {
/*  52 */     this.curDoclinks = new Vector();
/*  53 */     this.debug = false;
/*  54 */     this.dummyPrint = false;
/*  55 */     this.twopasspdf = false;
/*  56 */     this.printwait = 0L;
/*  57 */     this.padRequest = false;
/*  58 */     this.defaultPrintService = null;
/*  59 */     this.continueWait = false;
/*     */   }

/*     */   public void init()
/*     */   {
/*     */     try {
/*  65 */       this.defaultPrintService = PrintServiceLookup.lookupDefaultPrintService();
/*  66 */       if ((super.getParameter("printdebug") != null) && (super.getParameter("printdebug").equalsIgnoreCase("1")))
/*     */       {
/*  68 */         this.debug = true;
/*     */       }
/*     */ 
/*  71 */       if ((super.getParameter("twopasspdf") != null) && (super.getParameter("twopasspdf").equalsIgnoreCase("1")))
/*     */       {
/*  73 */         this.twopasspdf = true;
/*     */       }
/*     */ 
/*  76 */       if ((super.getParameter("dummyPrint") != null) && (super.getParameter("dummyPrint").equalsIgnoreCase("true")))
/*     */       {
/*  78 */         this.dummyPrint = true;
/*     */       }
/*     */ 
/*  81 */       if ((super.getParameter("reporttype") != null) && (super.getParameter("reporttype").equalsIgnoreCase("PAD")))
/*     */       {
/*  83 */         this.padRequest = true;
/*     */       }
/*     */ 
/*  86 */       if (super.getParameter("printwait") != null)
/*     */       {
/*  88 */         this.printwait = (60000 * Integer.parseInt(super.getParameter("printwait")));
/*     */       }
/*  90 */       int iParmCount = 0;
/*  91 */       String docLinkurl = null;
/*  92 */       while ((docLinkurl = super.getParameter("param_docfile_" + iParmCount)) != null)
/*     */       {
/*  94 */         if (this.debug) System.out.println("DocLinkURL Obtained: " + docLinkurl);
/*  95 */         this.curDoclinks.add(docLinkurl);
/*  96 */         ++iParmCount;
/*     */       }
/*  98 */       submitPrintJob();
/*     */     } catch (Throwable e) {
/* 100 */       e.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 106 */         Thread.sleep(5000L);
/*     */       } catch (InterruptedException e) {
/* 108 */         e.printStackTrace();
/*     */       } finally {
/* 110 */         closeWindow();
/*     */       }
/*     */     }
/*     */   }








/*     */   public boolean submitPrintJob()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 127 */       Iterator docs = this.curDoclinks.iterator();
/* 128 */       String docLinkPath = null;
/* 129 */       String tempPath = null;
/* 130 */       while (docs.hasNext())
/*     */       {
/* 132 */         docLinkPath = (String)docs.next();
/* 133 */         tempPath = docLinkPath.toUpperCase();
/* 134 */         docLinkPath = convertToUtf8(docLinkPath);
/* 135 */         if (this.debug) System.out.println("Print Job for : " + docLinkPath);
/* 136 */         if (!(this.dummyPrint)) {
/*     */           try
/*     */           {
/* 139 */             if ((tempPath.endsWith("PDF")) || (tempPath.indexOf("&RPTTYPE=PDF") > -1))
/*     */             {
/* 141 */               URL docLinkURL = null;
/* 142 */               docLinkPath = replaceString(docLinkPath, "+", "%20");
/* 143 */               docLinkPath = replaceString(docLinkPath, " ", "%20");
/* 144 */               docLinkURL = new URL(super.getCodeBase(), docLinkPath);



/*     */ 
/* 149 */               if ((this.twopasspdf) && (tempPath.indexOf("&RPTTYPE=PDF") < 0))
/*     */               {
/* 151 */                 if (this.debug) System.out.println("Processing 2 Pass PDF document " + tempPath);
/*     */                 try {
/* 153 */                   if (proc2PassPDFStream(docLinkURL))
/*     */                   {
/* 155 */                     docLinkPath = docLinkPath.replaceAll("doaction=3", "doaction=4");
/* 156 */                     docLinkURL = new URL(super.getCodeBase(), docLinkPath);
/* 157 */                     startPDFPrinting(docLinkURL);
/*     */                   }
/*     */                 }
/*     */                 catch (Exception ex)
/*     */                 {
/* 162 */                   tempPath = tempPath.replaceAll("&URL", "==URL");
/* 163 */                   String errString = tempPath + "  " + ex.getMessage();
/* 164 */                   docLinkPath = docLinkPath.replaceAll("doaction=3", "doaction=5");
/* 165 */                   docLinkPath = docLinkPath.replaceAll("doaction=4", "doaction=5");
/* 166 */                   docLinkPath = docLinkPath + "&remoteerrMsg=" + errString;
/* 167 */                   docLinkURL = new URL(super.getCodeBase(), docLinkPath);
/* 168 */                   startPDFPrinting(docLinkURL);
/*     */                 }
/*     */               }
/*     */               else
/*     */               {
/* 173 */                 if (this.debug) System.out.println("Print Job for " + docLinkURL);
/* 174 */                 startPDFPrinting(docLinkURL);
/*     */               }
/* 176 */             } else if (tempPath.endsWith("JPG"))
/*     */             {
/* 178 */               printImage(docLinkPath, "JPG");
/* 179 */             } else if (tempPath.endsWith("GIF"))
/*     */             {
/* 181 */               printImage(docLinkPath, "GIF");
/* 182 */             } else if (tempPath.endsWith("PNG"))
/*     */             {
/* 184 */               printImage(docLinkPath, "PNG");
/* 185 */             } else if (tempPath.endsWith("JPEG"))
/*     */             {
/* 187 */               printImage(docLinkPath, "JPG");
/* 188 */             } else if ((tempPath.endsWith("TXT")) || (tempPath.endsWith("CSV")))
/*     */             {
/* 190 */               printText(docLinkPath);

/*     */             }
/* 193 */             else if ((this.padRequest) && (tempPath.startsWith("PRINTMSOBJECTS")))
/*     */             {
/* 195 */               if (this.debug) System.out.println("Print microsoft document");
/* 196 */               printActiveXDocs(docLinkPath);
/*     */             }
/*     */           }
/*     */           catch (Exception printEx) {
/* 200 */             if (this.debug) System.out.println("Print failed for: \"" + docLinkPath + " @ " + this.defaultPrintService.getName() + "\"");
/* 201 */             printEx.printStackTrace();
/*     */ 
/* 203 */             System.out.println("###PRINT REQUEST TERMINATED DUE TO ERRORS, CHECK SERVER LOGS ALSO###");
/* 204 */             showErrorMessage();
/* 205 */             break label604:
/*     */           }
/*     */         }
/* 208 */         label604: Thread.sleep(3000L);
/*     */       }
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 213 */       throw new Exception(e.getMessage(), e);
/*     */     }
/* 215 */     return true;
/*     */   }





/*     */   public boolean printImage(String inFile, String imageType)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*     */       DocFlavor curDocFlavour;
/*     */       DocFlavor curDocFlavour;
/* 229 */       if (imageType.equals("GIF"))
/*     */       {
/* 231 */         curDocFlavour = DocFlavor.INPUT_STREAM.GIF;
/*     */       }/*     */       else/*     */       {/*     */         DocFlavor curDocFlavour;/* 232 */         if (imageType.equals("JPG"))
/*     */         {
/* 234 */           curDocFlavour = DocFlavor.INPUT_STREAM.JPEG;
/*     */         }/*     */         else/*     */         {/*     */           DocFlavor curDocFlavour;/* 235 */           if (imageType.equals("PNG"))
/*     */           {
/* 237 */             curDocFlavour = DocFlavor.INPUT_STREAM.GIF;
/*     */           }
/*     */           else
/* 240 */             curDocFlavour = DocFlavor.INPUT_STREAM.AUTOSENSE; 
/*     */         }/*     */       }
/* 242 */       URL docLinkImage = new URL(inFile);
/* 243 */       PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
/* 244 */       pras.add(new Copies(1));
/*     */ 
/* 246 */       PrintService pss = PrintServiceLookup.lookupDefaultPrintService();
/*     */ 
/* 248 */       if (pss == null) {
/* 249 */         throw new RuntimeException("No printer services available.");
/*     */       }
/* 251 */       DocPrintJob job = pss.createPrintJob();
/*     */ 
/* 253 */       Doc doc = new SimpleDoc(docLinkImage.openStream(), curDocFlavour, null);
/* 254 */       job.print(doc, pras);
/* 255 */       if (this.debug) System.out.println("Printed " + inFile + " @" + pss.getName() + "\"");
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 259 */       e.printStackTrace();
/*     */     }
/* 261 */     return true;
/*     */   }

/*     */   public void printText(String docLink)
/*     */   {
/*     */     try
/*     */     {
/* 268 */       PrinterJob printJob = PrinterJob.getPrinterJob();

/*     */ 
/* 271 */       PageFormat format = printJob.defaultPage();
/*     */ 
/* 273 */       printJob.setPageable(new TextRenderer(new URL(docLink), format));
/* 274 */       printJob.print();
/*     */     } catch (Throwable ex) {
/* 276 */       ex.printStackTrace();
/*     */     }
/*     */   }




/*     */   public void printActiveXDocs(String funcName)
/*     */   {
/*     */     try
/*     */     {
/* 287 */       super.getAppletContext().showDocument(new URL("javascript:" + funcName));
/*     */     }
/*     */     catch (Throwable ex) {
/* 290 */       ex.printStackTrace();
/*     */     }
/*     */   }

/*     */   public void closeWindow() {
/* 295 */     if (this.debug) System.out.println("Print Finished");
/*     */     try {
/* 297 */       super.getAppletContext().showDocument(new URL("javascript:closeWindow()"));
/*     */     }
/*     */     catch (Throwable ex) {
/* 300 */       ex.printStackTrace();
/*     */     }
/*     */   }

/*     */   public void showErrorMessage() {
/* 305 */     if (this.debug) System.out.println("Print Error");
/*     */     try {
/* 307 */       super.getAppletContext().showDocument(new URL("javascript:showErrorMessage()"));
/*     */     }
/*     */     catch (Throwable ex) {
/* 310 */       ex.printStackTrace();
/*     */     }
/*     */   }






/*     */   public void printPDF(String pdfurl)
/*     */   {
/*     */     try
/*     */     {
/* 323 */       System.out.println("Print PDF document " + pdfurl);
/* 324 */       super.getAppletContext().showDocument(new URL("javascript:printPDF(\"" + pdfurl + "\")"));
/*     */     }
/*     */     catch (Throwable ex) {
/* 327 */       ex.printStackTrace();
/*     */     }
/*     */   }


/*     */   private String convertToUtf8(String docpath)
/*     */   {
/* 334 */     if (docpath.startsWith("http://"))
/*     */     {
/* 336 */       String prefix = "http://";
/* 337 */       String temp = replaceString(docpath, "\\", "/");
/* 338 */       temp = temp.substring(7);
/* 339 */       int slashIndex = temp.indexOf("/");
/*     */ 
/* 341 */       if (slashIndex != -1)
/*     */       {
/* 343 */         prefix = prefix + temp.substring(0, slashIndex + 1);
/* 344 */         temp = temp.substring(slashIndex + 1);
/* 345 */         temp = encodeFilePath(temp);
/* 346 */         docpath = prefix + temp;
/*     */       }
/*     */     }
/* 349 */     else if (docpath.startsWith("https://"))
/*     */     {
/* 351 */       String prefix = "https://";
/* 352 */       String temp = replaceString(docpath, "\\", "/");
/* 353 */       temp = temp.substring(8);
/* 354 */       int slashIndex = temp.indexOf("/");
/*     */ 
/* 356 */       if (slashIndex != -1)
/*     */       {
/* 358 */         prefix = prefix + temp.substring(0, slashIndex + 1);
/* 359 */         temp = temp.substring(slashIndex + 1);
/* 360 */         temp = encodeFilePath(temp);
/* 361 */         docpath = prefix + temp;
/*     */       }
/*     */     }
/* 364 */     return docpath;
/*     */   }

/*     */   private String encodeFilePath(String filepathvalue)
/*     */   {
/* 369 */     String encodedValue = "";
/* 370 */     String[] values = filepathvalue.split("/");
/* 371 */     String processValue = "";
/* 372 */     boolean isSpace = false;
/*     */     try
/*     */     {
/* 375 */       for (int i = 0; i < values.length; ++i)
/*     */       {
/* 377 */         processValue = values[i];
/* 378 */         isSpace = processValue.indexOf(" ") > -1;
/* 379 */         processValue = URLEncoder.encode(processValue, "utf-8") + "/";
/* 380 */         if (isSpace)
/*     */         {
/* 382 */           processValue = replaceString(processValue, "+", "%20");
/* 383 */           processValue = replaceString(processValue, " ", "%20");
/*     */         }
/* 385 */         encodedValue = encodedValue + processValue;
/*     */       }
/* 387 */       encodedValue = encodedValue.substring(0, encodedValue.length() - 1);
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 391 */       e.printStackTrace();
/*     */     }
/* 393 */     filepathvalue = encodedValue;
/*     */ 
/* 395 */     return filepathvalue;
/*     */   }

/*     */   private String replaceString(String str, String pattern, String replacement)
/*     */   {
/* 400 */     int i = -1;
/* 401 */     int j = 0;
/* 402 */     while ((str != null) && (replacement != null) && (pattern != null) && 

/* 404 */       ((i = str.indexOf(pattern, j)) >= 0))
/*     */     {
/* 406 */       String t = str.substring(0, i) + replacement + str.substring(i + pattern.length());
/* 407 */       str = t;
/* 408 */       j = i + replacement.length();
/*     */     }
/*     */ 
/* 411 */     return str;
/*     */   }






/*     */   private boolean proc2PassPDFStream(URL extURL)
/*     */     throws Exception
/*     */   {
/* 422 */     String query = extURL.getQuery();
/* 423 */     query = query.substring(query.lastIndexOf("url=") + 4);
/* 424 */     URL docURL = new URL(query);
/* 425 */     InputStream fis = docURL.openStream();
/* 426 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 427 */     byte[] buf = new byte[1024];
/* 428 */     int bytesRead = 0;
/* 429 */     while ((bytesRead = fis.read(buf)) > 0)
/*     */     {
/* 431 */       bos.write(buf, 0, bytesRead);
/*     */     }
/* 433 */     bos.flush();
/* 434 */     bos.close();
/* 435 */     byte[] metaDataContent = bos.toByteArray();

/*     */ 
/* 438 */     HttpURLConnection uc = (HttpURLConnection)extURL.openConnection();
/*     */ 
/* 440 */     uc.setDoOutput(true);
/* 441 */     uc.setUseCaches(false);
/* 442 */     uc.setRequestMethod("POST");
/* 443 */     uc.setRequestProperty("Content-Type", "application/pdf");
/* 444 */     uc.setRequestProperty("Content-Length", Integer.toString(metaDataContent.length));
/* 445 */     DataOutputStream dos = new DataOutputStream(uc.getOutputStream());
/*     */ 
/* 447 */     dos.write(metaDataContent);
/* 448 */     dos.flush();
/* 449 */     Thread.sleep(500L);
/* 450 */     dos.close();
/* 451 */     if (200 == uc.getResponseCode())
/*     */     {
/* 453 */       return true;
/*     */     }
/* 455 */     System.out.println("Access/Post failure for " + extURL.toExternalForm() + " with " + uc.getResponseCode());
/* 456 */     throw new Exception(uc.getResponseCode() + "" + extURL.toExternalForm());
/*     */   }






/*     */   public void startPDFPrinting(URL inDocLinkURL)
/*     */     throws Exception
/*     */   {
/* 467 */     long stTime = System.currentTimeMillis() + this.printwait;
/* 468 */     this.continueWait = true;
/* 469 */     PrintJobMonitor printMon = new PrintJobMonitor();
/* 470 */     Thread printJobThread = new Thread(printMon);
/* 471 */     printPDF(inDocLinkURL.toString());
/* 472 */     printJobThread.start();
/* 473 */     while (printJobThread.isAlive())
/*     */       try {
/* 475 */         Thread.sleep(500L);
/* 476 */         if (System.currentTimeMillis() > stTime)
/*     */         {
/* 478 */           this.continueWait = false;
/* 479 */           System.out.println("WaitTimeout, bypassing " + inDocLinkURL);
/*     */         }
/*     */       } catch (InterruptedException e) {
/* 482 */         e.printStackTrace();
/*     */       }
/*     */   }








/*     */   static Class class$(String x0)
/*     */   {
/*     */     try
/*     */     {
/* 497 */       return Class.forName(x0); } catch (ClassNotFoundException x1) { throw new NoClassDefFoundError(x1.getMessage());
/*     */     }
/*     */   class PrintJobMonitor/*     */     implements Runnable/*     */   {/* 494 */     QueuedJobCount curJobs = null;/*     */ /*     */     public PrintJobMonitor() {/*     */       try { this.curJobs = ((QueuedJobCount)SilentPrint.this.defaultPrintService.getAttribute((SilentPrint.class$javax$print$attribute$standard$QueuedJobCount == null) ? (SilentPrint.class$javax$print$attribute$standard$QueuedJobCount = SilentPrint.class$("javax.print.attribute.standard.QueuedJobCount")) : SilentPrint.class$javax$print$attribute$standard$QueuedJobCount));/*     */       } catch (Exception ex) {/*     */   }/* 499 */         ex.printStackTrace();
/*     */       }
/*     */     }

/*     */     public void run() {
/* 504 */       QueuedJobCount newJobs = this.curJobs;
/* 505 */       while ((SilentPrint.this.continueWait) && (this.curJobs.getValue() == newJobs.getValue())) {
/* 506 */         newJobs = (QueuedJobCount)SilentPrint.this.defaultPrintService.getAttribute((SilentPrint.class$javax$print$attribute$standard$QueuedJobCount == null) ? (SilentPrint.class$javax$print$attribute$standard$QueuedJobCount = SilentPrint.class$("javax.print.attribute.standard.QueuedJobCount")) : SilentPrint.class$javax$print$attribute$standard$QueuedJobCount);
/*     */       }
/* 508 */       if ((SilentPrint.this.debug & this.curJobs.getValue() != newJobs.getValue()))
/* 509 */         System.out.println("Print Job Submitted");
/*     */     }
/*     */   }
/*     */ }
