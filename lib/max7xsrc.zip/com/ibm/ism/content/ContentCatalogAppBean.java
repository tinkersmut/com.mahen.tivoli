/*     */ package com.ibm.ism.content;
/*     */ 
/*     */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ import psdi.webclient.controls.Dialog;
/*     */ import psdi.webclient.system.beans.AppBean;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 

















/*     */ public class ContentCatalogAppBean extends AppBean
/*     */ {
/*     */   private static final String CLASSNAME = "ContentCatalogAppBean";
/*     */   private final ContentCatalogLogger log;
/*     */ 
/*     */   public ContentCatalogAppBean()
/*     */   {
/*  39 */     this.log = new ContentCatalogLogger(MXLoggerFactory.getLogger("maximo.service.SYSTEM.IBMCONTENTCATALOG"));
/*     */   }

/*     */   public synchronized void delete() throws MXException, RemoteException
/*     */   {
/*  44 */     String METHOD = "delete";
/*  45 */     this.log.debugEntry("ContentCatalogAppBean", "delete");

/*     */     try
/*     */     {
/*  49 */       this.log.info("ContentCatalogAppBean", "delete", "ISM Content Installer - Delete Content Source: " + this.parent.getMbo().getString("description"));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  53 */       this.log.info("ContentCatalogAppBean", "delete", "ISM Content Installer - Delete Content Source.");
/*     */     }
/*     */ 
/*  56 */     super.delete();
/*  57 */     this.log.debugExit("ContentCatalogAppBean", "delete");
/*     */   }

/*     */   public void SAVECATALOG()
/*     */     throws MXException, RemoteException
/*     */   {
/*  63 */     String METHOD = "SAVECATALOG";
/*  64 */     this.log.debugEntry("ContentCatalogAppBean", "SAVECATALOG");
/*  65 */     CatalogRemote catalog = (CatalogRemote)getMbo();
/*     */ 
/*  67 */     if ((catalog.isNull("URL_NPF")) || (catalog.getString("URL_NPF").equals(""))) {
/*  68 */       throw new MXApplicationException("system", "null", new Object[] { "URL" });
/*     */     }
/*  70 */     if ((catalog.isNull("DESC_NPF")) || (catalog.getString("DESC_NPF").equals(""))) {
/*  71 */       throw new MXApplicationException("system", "null", new Object[] { "Description" });
/*     */     }
/*     */ 
/*  74 */     catalog.setValue("URL", catalog.getString("URL_NPF"));
/*  75 */     catalog.setValue("DESCRIPTION", catalog.getString("DESC_NPF"));
/*     */ 
/*  77 */     save(catalog);
/*  78 */     ((Dialog)this.clientSession.findDialog("EDIT")).dialogok();
/*     */ 
/*  80 */     gotoTab(this.clientSession, "list");
/*  81 */     initializeApp();
/*  82 */     this.log.debugExit("ContentCatalogAppBean", "SAVECATALOG");
/*     */   }

/*     */   public void CANCEL() throws MXException, RemoteException
/*     */   {
/*  87 */     String METHOD = "CANCEL";
/*  88 */     this.log.debugEntry("ContentCatalogAppBean", "CANCEL");
/*  89 */     CatalogRemote catalog = (CatalogRemote)getMbo();

/*     */ 
/*  92 */     if ((catalog.isNull("URL")) || (catalog.getString("URL").equals("")) || (catalog.isNull("DESCRIPTION")) || (catalog.getString("DESCRIPTION").equals("")))

/*     */     {
/*  95 */       catalog.delete();
/*  96 */       reset();
/*     */ 
/*  98 */       ((Dialog)this.clientSession.findDialog("EDIT")).dialogcancel();


/*     */ 
/* 102 */       gotoTab(this.clientSession, "list");
/* 103 */       initializeApp();
/*     */     }
/*     */     else
/*     */     {
/* 107 */       ((Dialog)this.clientSession.findDialog("EDIT")).dialogcancel();
/*     */     }
/*     */ 
/* 110 */     this.log.debugExit("ContentCatalogAppBean", "CANCEL");
/*     */   }

/*     */   public void EDIT() throws MXException, RemoteException
/*     */   {
/* 115 */     String METHOD = "EDIT";
/* 116 */     this.log.debugEntry("ContentCatalogAppBean", "EDIT");
/* 117 */     CatalogRemote catalog = (CatalogRemote)getMbo();
/* 118 */     String url = catalog.getString("URL");
/* 119 */     String desc = catalog.getString("DESCRIPTION");
/* 120 */     catalog.setValue("URL_NPF", url);
/* 121 */     catalog.setValue("DESC_NPF", desc);
/* 122 */     fireDataChangedEvent();
/*     */ 
/* 124 */     this.log.debugExit("ContentCatalogAppBean", "EDIT");
/*     */   }
























/*     */   public void NEW()
/*     */     throws MXException, RemoteException
/*     */   {
/* 153 */     String METHOD = "NEW";
/* 154 */     this.log.debugEntry("ContentCatalogAppBean", "NEW");
/*     */ 
/* 156 */     this.clientSession.loadDialog("EDIT");
/* 157 */     this.log.debugExit("ContentCatalogAppBean", "NEW");
/*     */   }

/*     */   public void initializeApp()
/*     */     throws MXException, RemoteException
/*     */   {
/* 163 */     String METHOD = "initializeApp";
/* 164 */     this.log.debugEntry("ContentCatalogAppBean", "initializeApp");
/*     */ 
/* 166 */     this.app.setAppStartupQueryName("All Records");
/* 167 */     super.initializeApp();
/*     */ 
/* 169 */     this.log.debugExit("ContentCatalogAppBean", "initializeApp");
/*     */   }

/*     */   public int selectrecord()
/*     */     throws MXException, RemoteException
/*     */   {
/* 175 */     return super.selectrecord();
/*     */   }




/*     */   protected void gotoTab(WebClientSession wcs, String tab)
/*     */   {
/* 183 */     String METHOD = "gotoTab";
/* 184 */     this.log.debugEntry("ContentCatalogAppBean", "gotoTab");
/*     */ 
/* 186 */     super.gotoTab(wcs, tab);
/*     */ 
/* 188 */     if (tab.equalsIgnoreCase("insert")) {
/* 189 */       this.clientSession.loadDialog("EDIT");
/*     */     }
/* 191 */     this.log.debugExit("ContentCatalogAppBean", "gotoTab");
/*     */   }
/*     */ }
