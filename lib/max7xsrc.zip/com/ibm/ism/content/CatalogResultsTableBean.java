/*    */ package com.ibm.ism.content;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.net.URL;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.ResultsBean;
/*    */ import psdi.webclient.system.controller.AppInstance;
/*    */ import psdi.webclient.system.controller.ControlInstance;
/*    */ import psdi.webclient.system.controller.PageInstance;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 












/*    */ public class CatalogResultsTableBean extends ResultsBean
/*    */ {
/*    */   private void updateCatalogInfo(MboRemote mbo)
/*    */     throws MXException, RemoteException
/*    */   {
/* 33 */     if (this.app.getCurrentPage().getControlInstance("cataloginfo") == null) {
/* 34 */       return;
/*    */     }
/* 36 */     mbo.getMboSet("CATALOGITEMS");
/* 37 */     String infoUrl = mbo.getString("infourl");
/* 38 */     if ((infoUrl != null) && (!(infoUrl.equals("")))) {
/*    */       try {
/* 40 */         URL url = new URL(infoUrl);
/* 41 */         Object content = CatalogItemsBean.getUrlContent(url);
/* 42 */         this.app.getCurrentPage().getControlInstance("cataloginfo").setProperty("innerhtml", content.toString());

/*    */       }
/*    */       catch (IOException e)
/*    */       {
/* 47 */         this.app.getCurrentPage().getControlInstance("cataloginfo").setProperty("innerhtml", mbo.getString("description"));
/*    */       }
/*    */ 
/*    */     }
/*    */     else {
/* 52 */       this.app.getCurrentPage().getControlInstance("cataloginfo").setProperty("innerhtml", mbo.getString("description"));
/*    */     }
/*    */ 
/* 55 */     this.app.getCurrentPage().getControlInstance("cataloginfo").setChangedFlag(true);
/* 56 */     fireDataChangedEvent();
/*    */   }


/*    */   public int selectrecord()
/*    */     throws MXException, RemoteException
/*    */   {
/* 63 */     System.out.println("Select Record");
/* 64 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/* 65 */     int row = getRowIndexFromEvent(event);
/* 66 */     int rc = super.selectrecord();
/*    */ 
/* 68 */     MboRemote mbo = getMbo(row);
/* 69 */     updateCatalogInfo(mbo);
/* 70 */     return rc;
/*    */   }
/*    */ }
