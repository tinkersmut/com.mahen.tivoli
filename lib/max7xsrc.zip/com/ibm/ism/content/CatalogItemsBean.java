/*     */ package com.ibm.ism.content;
/*     */ 
/*     */ import com.ibm.ism.content.virtual.CatalogItemRemote;
/*     */ import com.ibm.ism.content.virtual.CatalogItemSetRemote;
/*     */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.List;
/*     */ import javax.naming.AuthenticationException;
/*     */ import org.python.util.PythonInterpreter;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.BitFlag;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ import psdi.webclient.controls.Dialog;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.ControlInstance;
/*     */ import psdi.webclient.system.controller.PageInstance;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 










/*     */ public class CatalogItemsBean extends DataBean
/*     */ {
/*     */   private static final String CLASSNAME = "CatalogItemsBean";
/*  47 */   private static final ContentCatalogLogger log = new ContentCatalogLogger(MXLoggerFactory.getLogger("maximo.service.SYSTEM.IBMCONTENTCATALOG"));
/*     */   boolean validationError;
/*     */   String errorMessage;
/*     */   boolean authenticationRequested;
/*     */ 
/*     */   public CatalogItemsBean()
/*     */   {
/*  49 */     this.validationError = false;
/*  50 */     this.errorMessage = "";
/*  51 */     this.authenticationRequested = false;
/*     */   }

/*     */   static String getUrlContent(URL url) throws IOException {
/*  55 */     String METHOD = "getUrlContent";
/*  56 */     log.debugEntry("CatalogItemsBean", "getUrlContent");
/*     */ 
/*  58 */     StringBuffer buffer = new StringBuffer();
/*  59 */     BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
/*     */ 
/*  61 */     while ((oneline = reader.readLine()) != null)
/*     */     {/*     */       String oneline;/*  62 */       buffer.append(oneline);
/*     */     }
/*  64 */     reader.close();
/*  65 */     log.debugExit("CatalogItemsBean", "getUrlContent");
/*  66 */     return buffer.toString();
/*     */   }

/*     */   protected void initialize()
/*     */     throws MXException, RemoteException
/*     */   {
/*  72 */     String METHOD = "initialize";
/*  73 */     log.debugEntry("CatalogItemsBean", "initialize");
/*  74 */     System.out.println("initialize");

/*     */ 
/*  77 */     updateCatalogInfo();

/*     */ 
/*  80 */     displayContentItemTable();
/*     */ 
/*  82 */     super.initialize();
/*  83 */     log.debugExit("CatalogItemsBean", "initialize");
/*     */   }









/*     */   private void displayContentItemTable()
/*     */   {
/*  96 */     String METHOD = "displayContentItemTable";
/*  97 */     log.debugEntry("CatalogItemsBean", "displayContentItemTable");

/*     */     try
/*     */     {
/* 101 */       CatalogItemSetRemote catalogSet = (CatalogItemSetRemote)getMboSet();
/*     */ 
/* 103 */       if (catalogSet.isEmpty())
/* 104 */         this.tableStateFlags.setFlag(1L, false);
/*     */       else {
/* 106 */         this.tableStateFlags.setFlag(1L, true);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/* 112 */     log.debugExit("CatalogItemsBean", "displayContentItemTable");
/*     */   }

/*     */   public synchronized void save()
/*     */     throws MXException
/*     */   {
/* 118 */     String METHOD = "save";
/* 119 */     log.debugEntry("CatalogItemsBean", "save");
/*     */     try
/*     */     {
/* 122 */       updateCatalogInfo();
/*     */     }
/*     */     catch (RemoteException e) {
/* 125 */       log.error("CatalogItemsBean", "save", "error", e);
/* 126 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 129 */     super.save();
/*     */ 
/* 131 */     log.debugExit("CatalogItemsBean", "save");
/*     */   }

/*     */   private void updateCatalogInfo() throws MXException, RemoteException {
/* 135 */     String METHOD = "updateCatalogInfo";
/* 136 */     log.debugEntry("CatalogItemsBean", "updateCatalogInfo");
/*     */ 
/* 138 */     String infoUrl = this.parent.getMbo().getString("infourl");
/* 139 */     String description = this.parent.getMbo().getString("description");
/* 140 */     PageInstance page = this.app.getCurrentPage();
/* 141 */     if (page.getId().equals("EDIT"))


/*     */     {
/* 145 */       description = "";
/* 146 */       page = this.app.getApplicationPage();
/*     */     }
/* 148 */     ControlInstance catalogInfoInstance = page.getControlInstance("cataloginfo");
/*     */ 
/* 150 */     if (catalogInfoInstance != null)
/*     */     {
/* 152 */       if ((infoUrl != null) && (!(infoUrl.equals(""))))

/*     */       {
/*     */         try
/*     */         {
/* 157 */           if (infoUrl.contains("<html>"))
/*     */           {
/* 159 */             catalogInfoInstance.setProperty("innerhtml", infoUrl.toString());
/*     */           }
/*     */           else
/*     */           {
/* 163 */             URL url = new URL(infoUrl);
/* 164 */             Object content = getUrlContent(url);
/* 165 */             catalogInfoInstance.setProperty("innerhtml", content.toString());
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 171 */           log.error("CatalogItemsBean", "updateCatalogInfo", "error", e);
/* 172 */           catalogInfoInstance.setProperty("innerhtml", description);
/*     */         }
/*     */       }
/* 175 */       else if (description != null)
/*     */       {
/* 177 */         catalogInfoInstance.setProperty("innerhtml", description);
/*     */       }
/*     */ 
/* 180 */       catalogInfoInstance.setChangedFlag(true);
/* 181 */       fireDataChangedEvent();

/*     */     }
/*     */ 
/* 185 */     log.debugExit("CatalogItemsBean", "updateCatalogInfo");
/*     */   }

/*     */   public void INSTALL()
/*     */     throws RemoteException, MXException
/*     */   {
/* 191 */     String METHOD = "INSTALL";
/* 192 */     log.debugEntry("CatalogItemsBean", "INSTALL");
/*     */ 
/* 194 */     ((Dialog)this.clientSession.findDialog("SHOWINSTALLWARNING")).dialogclose();
/*     */ 
/* 196 */     if (!(getMbo().getBoolean("INSTALLABLE"))) {
/* 197 */       this.clientSession.loadDialog("installstepMissingPreReq");
/*     */     }
/* 199 */     else if ((getMbo().getBoolean("INSTALLED")) && (this.clientSession.findDialog("installstepAlreadyInstalled").needsRender())) {
/* 200 */       this.clientSession.loadDialog("installstepAlreadyInstalled");
/*     */     }
/*     */     else {
/* 203 */       if (this.clientSession.findDialog("installstepAlreadyInstalled") != null) {
/* 204 */         ((Dialog)this.clientSession.findDialog("installstepAlreadyInstalled")).dialogclose();
/*     */       }
/*     */ 
/* 207 */       CatalogItemRemote catalogItem = (CatalogItemRemote)getMbo();
/*     */ 
/* 209 */       String licenseURL = catalogItem.loadLicense();
/* 210 */       this.clientSession.loadDialog("installstepShowDetails");
/*     */ 
/* 212 */       if ((licenseURL == null) || (licenseURL.equals(""))) {
/* 213 */         this.app.getCurrentPage().getControlInstance("license_section").setProperty("display", "false");
/*     */       }
/*     */       else {
/* 216 */         String licenseText = this.app.getCurrentPage().getControlInstance("licenseTextBox").getProperty("innerhtml");
/* 217 */         licenseText = "<a target='_blank' href='" + licenseURL + "'>" + licenseText + "</a>";
/* 218 */         this.app.getCurrentPage().getControlInstance("licenseTextBox").setProperty("innerhtml", licenseText);
/*     */       }
/*     */ 
/* 221 */       fireDataChangedEvent();
/*     */     }
/* 223 */     log.debugExit("CatalogItemsBean", "INSTALL");
/*     */   }

/*     */   public void INSTALLPKG() throws RemoteException, MXException
/*     */   {
/* 228 */     String METHOD = "INSTALLPKG";
/* 229 */     log.debugEntry("CatalogItemsBean", "INSTALLPKG");
/*     */ 
/* 231 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/*     */     try
/*     */     {
/* 234 */       CatalogItemRemote catalogItem = (CatalogItemRemote)getMbo();

/*     */ 
/* 237 */       if ((!(this.clientSession.hasLongOpStarted())) && (!(this.clientSession.hasLongOpCompleted())))
/*     */       {
/* 239 */         this.validationError = false;
/* 240 */         this.clientSession.runLongOp(this, "INSTALLPKG");

/*     */       }
/* 243 */       else if ((this.clientSession.hasLongOpStarted()) && (!(this.clientSession.hasLongOpCompleted())))
/*     */       {
/* 245 */         this.errorMessage = "";
/* 246 */         MboSetRemote ms = getMbo().getMboSet("MRIUREPLACEMENTS");
/* 247 */         if ((ms.count() != 1) || (!(ms.isNull("ATTRIBUTENAME"))))
/*     */         {
/* 249 */           int lcv = 0; for (int size = ms.getSize(); lcv < size; ++lcv) {
/* 250 */             MboRemote m = ms.getMbo(lcv);
/* 251 */             String id = m.getString("ID");
/* 252 */             String name = m.getString("ATTRIBUTENAME");
/* 253 */             String repValue = m.getString("VALUE");
/* 254 */             if ((repValue != null) && (!(repValue.equals(""))))
/*     */               continue;
/* 256 */             this.validationError = true;
/*     */             CatalogItemsBean tmp221_220 = this; tmp221_220.errorMessage = tmp221_220.errorMessage + name + ", ";
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 262 */         if (this.validationError)
/*     */         {
/* 264 */           this.errorMessage = this.errorMessage.trim().substring(0, this.errorMessage.length() - 2);
/*     */         }
/*     */         else
/*     */         {
/* 268 */           catalogItem.installContent();

/*     */         }
/*     */ 
/*     */       }
/* 273 */       else if (!(this.validationError))
/*     */       {
/* 275 */         ((Dialog)this.clientSession.findDialog("installstepInstall")).dialogclose();
/* 276 */         ((Dialog)this.clientSession.findDialog("mriuinstallstepInstall")).dialogclose();
/* 277 */         if (catalogItem.isInstallFailed())

/*     */         {
/* 280 */           this.clientSession.loadDialog("installstepFail");



/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/* 289 */             List jythonScripts = catalogItem.getJythonScripts();
/* 290 */             if (jythonScripts != null)
/*     */             {
/* 292 */               for (int i = 0; i < jythonScripts.size(); ++i)
/*     */               {
/* 294 */                 String script = (String)jythonScripts.get(i);

/*     */ 
/* 297 */                 PythonInterpreter jython = new PythonInterpreter();

/*     */                 try
/*     */                 {
/* 301 */                   jython.set("webclient", this.clientSession);
/* 302 */                   jython.set("appbean", this.app);

/*     */ 
/* 305 */                   jython.exec(script);
/*     */ 
/* 307 */                   catalogItem.setValue("installmessages", catalogItem.getString("installmessages") + "\n\nJython Script has Completed.");
/* 308 */                   log.info("CatalogItemsBean", "INSTALLPKG", "Jython Script has Completed");
/*     */                 }
/*     */                 catch (Exception e)
/*     */                 {
/* 312 */                   catalogItem.setValue("installmessages", catalogItem.getString("installmessages") + "\n\nProblem executing the Jython Script: \n" + e.getMessage());
/*     */ 
/* 314 */                   log.error("CatalogItemsBean", "INSTALLPKG", e.toString());
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 321 */             log.error("CatalogItemsBean", "INSTALLPKG", e.toString());

/*     */           }
/*     */ 
/* 325 */           this.clientSession.loadDialog("installstepComplete");
/*     */ 
/* 327 */           catalogItem.setValue("INSTALLED", true);
/*     */         }
/* 329 */         fireDataChangedEvent();
/*     */       }
/*     */       else
/*     */       {
/* 333 */         MXApplicationException e = new MXApplicationException("contentcat", "ReplacementValueMandatory", new Object[] { this.errorMessage });
/* 334 */         throw e;
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 340 */       log.error("CatalogItemsBean", "INSTALLPKG", "error", e);
/* 341 */       this.clientSession.showMessageBox(event, e);
/*     */     }
/* 343 */     log.debugExit("CatalogItemsBean", "INSTALLPKG");
/*     */   }

/*     */   public void DOWNLOADPKG() throws RemoteException, MXException
/*     */   {
/* 348 */     String METHOD = "DOWNLOADPKG";
/* 349 */     log.debugEntry("CatalogItemsBean", "DOWNLOADPKG");
/*     */ 
/* 351 */     WebClientEvent event = this.clientSession.getCurrentEvent();

/*     */     try
/*     */     {
/* 355 */       CatalogItemRemote catalogItem = (CatalogItemRemote)getMbo();
/*     */ 
/* 357 */       if ((!(catalogItem.isNull("LICENSEURL"))) && (!(catalogItem.getString("LICENSEURL").equals(""))) && 
/* 358 */         (!(catalogItem.getBoolean("acceptedlicense")))) {
/* 359 */         throw new MXApplicationException("contentcat", "MustAccLicense");


/*     */       }
/*     */ 
/* 364 */       if ((!(this.clientSession.hasLongOpStarted())) && (!(this.clientSession.hasLongOpCompleted()))) {
/* 365 */         this.clientSession.runLongOp(this, "DOWNLOADPKG");

/*     */       }
/* 368 */       else if ((this.clientSession.hasLongOpStarted()) && (!(this.clientSession.hasLongOpCompleted()))) {
/*     */         try {
/* 370 */           this.authenticationRequested = false;
/* 371 */           catalogItem.downloadContent();
/*     */         }
/*     */         catch (AuthenticationException e) {
/* 374 */           this.authenticationRequested = true;
/*     */         }
/*     */         catch (MXException e)
/*     */         {
/* 378 */           log.debug("CatalogItemsBean", "DOWNLOADPKG", "error", e);
/*     */ 
/* 380 */           throw e;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 385 */         ((Dialog)this.clientSession.findDialog("installstepShowDetails")).dialogclose();
/* 386 */         ((Dialog)this.clientSession.findDialog("installAuthentication")).dialogclose();

/*     */ 
/* 389 */         if (!(catalogItem.isDownloadFailed()))
/*     */         {
/* 391 */           if (this.authenticationRequested) {
/* 392 */             this.clientSession.loadDialog("installAuthentication");
/*     */           }
/* 394 */           else if (getMbo().getString("type").equalsIgnoreCase("mriu")) {
/* 395 */             this.clientSession.loadDialog("mriuinstallstepInstall");

/*     */ 
/* 398 */             MboSetRemote ms = getMbo().getMboSet("MRIUREPLACEMENTS");
/* 399 */             if ((ms.count() == 1) && (ms.isNull("ATTRIBUTENAME"))) {
/* 400 */               this.app.getCurrentPage().getControlInstance("mriu_replacements_tab").setProperty("display", "false");
/*     */             }
/*     */             else {
/* 403 */               this.app.getCurrentPage().getControlInstance("mriu_replacements_tab").setProperty("display", "true");

/*     */             }
/*     */ 
/* 407 */             ms = getMbo().getMboSet("DOCUMENTS");
/* 408 */             if ((ms.count() == 1) && (ms.isNull("FILE"))) {
/* 409 */               this.app.getCurrentPage().getControlInstance("mriu_docs_tab").setProperty("display", "false");
/*     */             }
/*     */             else
/* 412 */               this.app.getCurrentPage().getControlInstance("mriu_docs_tab").setProperty("display", "true");
/*     */           }
/*     */           else
/*     */           {
/* 416 */             this.clientSession.loadDialog("installstepInstall");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 423 */       log.error("CatalogItemsBean", "DOWNLOADPKG", "error", e);
/* 424 */       this.clientSession.showMessageBox(event, e);
/*     */     }
/* 426 */     log.debugExit("CatalogItemsBean", "DOWNLOADPKG");
/*     */   }

/*     */   public void INSTALLCOMPLETE() throws RemoteException, MXException
/*     */   {
/* 431 */     String METHOD = "INSTALLCOMPLETE";
/* 432 */     log.debugEntry("CatalogItemsBean", "INSTALLCOMPLETE");
/*     */ 
/* 434 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/*     */     try
/*     */     {
/* 437 */       CatalogItemRemote catalogItem = (CatalogItemRemote)getMbo();
/* 438 */       catalogItem.installContent();
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 442 */       log.error("CatalogItemsBean", "INSTALLCOMPLETE", "error", e);
/* 443 */       this.clientSession.showMessageBox(event, e);
/*     */     }
/* 445 */     log.debugExit("CatalogItemsBean", "INSTALLCOMPLETE");
/*     */   }
/*     */ }
