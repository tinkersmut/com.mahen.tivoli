package com.ibm.ism.content;

import psdi.mbo.MboRemote;

public abstract interface CatalogRemote extends MboRemote
{
}
