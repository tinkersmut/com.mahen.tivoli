package com.ibm.ism.content;

import psdi.mbo.MboSetRemote;

public abstract interface CatalogSetRemote extends MboSetRemote
{
}
