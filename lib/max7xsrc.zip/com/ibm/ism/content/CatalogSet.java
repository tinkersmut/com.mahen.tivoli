/*    */ package com.ibm.ism.content;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.util.MXException;
/*    */ 



























/*    */ public class CatalogSet extends MboSet
/*    */   implements CatalogSetRemote
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public CatalogSet(MboServerInterface ms)
/*    */     throws RemoteException
/*    */   {
/* 44 */     super(ms);
/*    */   }





/*    */   protected Mbo getMboInstance(MboSet arg0)
/*    */     throws MXException, RemoteException
/*    */   {
/* 54 */     return new Catalog(arg0);
/*    */   }
/*    */ }
