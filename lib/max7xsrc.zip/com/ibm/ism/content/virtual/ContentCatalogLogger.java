/*     */ package com.ibm.ism.content.virtual;
/*     */ 
/*     */ import psdi.util.logging.MXLogger;
/*     */ 


















































/*     */ public class ContentCatalogLogger
/*     */ {
/*     */   private static final String SEP = ".";
/*     */   private final MXLogger logger;
/*     */ 
/*     */   public ContentCatalogLogger(MXLogger logger)
/*     */   {
/*  62 */     this.logger = logger;
/*     */   }







/*     */   public boolean isDebug()
/*     */   {
/*  73 */     return this.logger.isDebugEnabled();
/*     */   }





/*     */   public boolean isInfo()
/*     */   {
/*  82 */     return this.logger.isInfoEnabled();
/*     */   }





/*     */   public boolean isWarn()
/*     */   {
/*  91 */     return this.logger.isWarnEnabled();
/*     */   }





/*     */   public boolean isError()
/*     */   {
/* 100 */     return this.logger.isErrorEnabled();
/*     */   }














/*     */   public void debug(String className, String method, String msg)
/*     */   {
/* 118 */     if (this.logger.isDebugEnabled())
/* 119 */       this.logger.debug(className + "." + method + " " + msg);
/*     */   }









/*     */   public void debug(String className, String method, String msg, Throwable t)
/*     */   {
/* 132 */     if (this.logger.isDebugEnabled())
/* 133 */       this.logger.debug(className + "." + method + " " + msg, t);
/*     */   }









/*     */   public void info(String className, String method, String msg)
/*     */   {
/* 146 */     if (this.logger.isInfoEnabled())
/* 147 */       this.logger.info(className + "." + method + " " + msg);
/*     */   }









/*     */   public void info(String className, String method, String msg, Throwable t)
/*     */   {
/* 160 */     if (this.logger.isInfoEnabled())
/* 161 */       this.logger.info(className + "." + method + " " + msg, t);
/*     */   }









/*     */   public void warn(String className, String method, String msg)
/*     */   {
/* 174 */     if (this.logger.isWarnEnabled())
/* 175 */       this.logger.warn(className + "." + method + " " + msg);
/*     */   }









/*     */   public void warn(String className, String method, String msg, Throwable t)
/*     */   {
/* 188 */     if (this.logger.isWarnEnabled())
/* 189 */       this.logger.warn(className + "." + method + " " + msg, t);
/*     */   }










/*     */   public void error(String className, String method, String msg)
/*     */   {
/* 203 */     if (this.logger.isErrorEnabled())
/* 204 */       this.logger.error(className + "." + method + " " + msg);
/*     */   }









/*     */   public void error(String className, String method, String msg, Throwable t)
/*     */   {
/* 217 */     if (this.logger.isErrorEnabled())
/* 218 */       this.logger.error(className + "." + method + " " + msg, t);
/*     */   }









/*     */   public void fatal(String className, String method, String msg)
/*     */   {
/* 231 */     if (this.logger.isFatalEnabled())
/* 232 */       this.logger.fatal(className + "." + method + " " + msg);
/*     */   }









/*     */   public void fatal(String className, String method, String msg, Throwable t)
/*     */   {
/* 245 */     if (this.logger.isFatalEnabled())
/* 246 */       this.logger.fatal(className + "." + method + " " + msg, t);
/*     */   }



















/*     */   public void debugEntry(String className, String method, Object[] params)
/*     */   {
/* 269 */     if (this.logger.isDebugEnabled())
/* 270 */       if ((params != null) && (params.length > 0)) {
/* 271 */         StringBuffer paramString = new StringBuffer(params[0].toString());
/*     */ 
/* 273 */         for (int i = 1; i < params.length; ++i) {
/* 274 */           paramString.append(", " + params[i]);
/*     */         }
/* 276 */         this.logger.debug(className + "." + method + " ENTRY : " + paramString);
/*     */       } else {
/* 278 */         this.logger.debug(className + "." + method + " ENTRY");
/*     */       }
/*     */   }








/*     */   public void debugEntry(String className, String method)
/*     */   {
/* 291 */     if (this.logger.isDebugEnabled())
/* 292 */       this.logger.debug(className + "." + method + " ENTRY");
/*     */   }









/*     */   public void debugEntry(String className, String method, Object param1)
/*     */   {
/* 305 */     if (this.logger.isDebugEnabled())
/* 306 */       this.logger.debug(className + "." + method + " ENTRY : " + param1);
/*     */   }










/*     */   public void debugEntry(String className, String method, Object param1, Object param2)
/*     */   {
/* 320 */     if (this.logger.isDebugEnabled())
/* 321 */       this.logger.debug(className + "." + method + " ENTRY : " + param1 + ", " + param2);
/*     */   }











/*     */   public void debugEntry(String className, String method, Object param1, Object param2, Object param3)
/*     */   {
/* 336 */     if (this.logger.isDebugEnabled())
/* 337 */       this.logger.debug(className + "." + method + " ENTRY : " + param1 + ", " + param2 + ", " + param3);
/*     */   }












/*     */   public void debugEntry(String className, String method, Object param1, Object param2, Object param3, Object param4)
/*     */   {
/* 353 */     if (this.logger.isDebugEnabled())
/* 354 */       this.logger.debug(className + "." + method + " ENTRY : " + param1 + ", " + param2 + ", " + param3 + ", " + param4);
/*     */   }





















/*     */   public void debugExit(String className, String method, Object returnValue)
/*     */   {
/* 379 */     if (this.logger.isDebugEnabled())
/* 380 */       this.logger.debug(className + "." + method + " EXIT : " + returnValue);
/*     */   }




















/*     */   public void debugExit(String className, String method)
/*     */   {
/* 404 */     if (this.logger.isDebugEnabled())
/* 405 */       this.logger.debug(className + "." + method + " EXIT");
/*     */   }
/*     */ }
