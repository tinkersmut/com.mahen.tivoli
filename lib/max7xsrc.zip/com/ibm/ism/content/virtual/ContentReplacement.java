/*    */ package com.ibm.ism.content.virtual;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.NonPersistentMbo;
/*    */ import psdi.util.MXException;
/*    */ 



















/*    */ public class ContentReplacement extends NonPersistentMbo
/*    */   implements ContentReplacementRemote
/*    */ {
/*    */   private static final String CLASSNAME = "ContentReplacement";
/* 35 */   private final ContentCatalogLogger log = new ContentCatalogLogger(getMboLogger());
/*    */   private static final long serialVersionUID = 8946336307819900977L;
/*    */ 
/*    */   public ContentReplacement(MboSet ms)
/*    */     throws RemoteException
/*    */   {
/* 38 */     super(ms);
/*    */   }






/*    */   public MboSetRemote getList(String attribute)
/*    */     throws MXException, RemoteException
/*    */   {
/* 49 */     return getMboSet("POSSIBLEVALUES");
/*    */   }
/*    */ }
