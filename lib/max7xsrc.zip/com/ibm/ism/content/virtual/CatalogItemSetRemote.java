package com.ibm.ism.content.virtual;

import psdi.mbo.NonPersistentMboSetRemote;

public abstract interface CatalogItemSetRemote extends NonPersistentMboSetRemote
{
}
