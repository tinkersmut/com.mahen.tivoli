/*     */ package com.ibm.ism.content.virtual;
/*     */ 
/*     */ import com.ibm.ism.content.mriu.AbstractReplacementValue;
/*     */ import com.ibm.ism.content.mriu.DefaultPackageResolver;
/*     */ import com.ibm.ism.content.mriu.PackageManager;
/*     */ import com.ibm.ism.content.mriu.SelectionReplacementValue;
/*     */ import com.ibm.ism.content.mriu.model.FilePath;
/*     */ import com.ibm.ism.content.mriu.model.MRIUPackage;
/*     */ import com.ibm.ism.content.psdi.webclient.upgrade.MXApplyTransactions;
/*     */ import com.ibm.ism.contentinstaller.tools.ImportSAXObject;
/*     */ import com.ibm.ism.contentinstaller.tools.monitors.IProgressMonitor;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.Authenticator;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipException;
/*     */ import java.util.zip.ZipFile;
/*     */ import javax.naming.AuthenticationException;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.xml.sax.SAXException;
/*     */ import psdi.dm.pkg.DMPackageRemote;
/*     */ import psdi.dm.util.DMDirStructure;
/*     */ import psdi.dm.virtual.DMDeployablePkgRemote;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.NonPersistentMbo;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.DBManager;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 

































/*     */ public class CatalogItem extends NonPersistentMbo
/*     */   implements CatalogItemRemote
/*     */ {
/*     */   private static final String CLASSNAME = "CatalogItem";
/*  84 */   public static final ContentCatalogLogger log = new ContentCatalogLogger(MXLoggerFactory.getLogger("maximo.service.SYSTEM.IBMCONTENTCATALOG"));
/*     */ 
/*  86 */   static HTTPAuthenticator authenticator = new HTTPAuthenticator();
/*     */   private static final long serialVersionUID = 8946336307819900977L;
/*     */   private static final String NO_FILES_SELECTED = "NO_FILES_SELECTED";
/*     */   File contentFile;
/*  94 */   boolean downloadComplete = false;
/*  95 */   boolean downloadFailed = false;
/*  96 */   boolean installComplete = false;
/*  97 */   boolean installFailed = false;
/*  98 */   boolean displayReplacementsDropDown = false;
/*  99 */   List<String> jythonScripts = null;
/* 100 */   StringBuffer downloadMessages = new StringBuffer();
/* 101 */   StringBuffer installMessages = new StringBuffer();
/*     */   private MRIUPackage mriuPackage;
/* 103 */   private Vector<Object[]> mriuItemToMboMap = new Vector();
/*     */ 
/*     */   public CatalogItem(MboSet ms)
/*     */     throws RemoteException
/*     */   {
/* 110 */     super(ms);
/*     */     try {
/* 112 */       setValue("URLTYPE", "URL");
/*     */     }
/*     */     catch (MXException e) {
/* 115 */       e.printStackTrace(); }  } 
























































































/*     */   private File doFileDownload(URL url) throws IOException, MXException, FileNotFoundException, AuthenticationException { String METHOD = "doFileDownload";
/* 205 */     log.debugEntry("CatalogItem", "doFileDownload");
/*     */ 
/* 207 */     URLConnection connection = url.openConnection();
/* 208 */     connection.setDefaultUseCaches(false);
/* 209 */     connection.setUseCaches(false);
/* 210 */     connection.setRequestProperty("Cache-Control", "no-cache");
/* 211 */     connection.setRequestProperty("Pragma", "no-cache");
/* 212 */     connection.connect();



/*     */ 
/* 217 */     String fileName = url.getFile();
/* 218 */     fileName = fileName.substring(fileName.lastIndexOf(47) + 1);
/* 219 */     String dmpath = DMDirStructure.getDirPath("inbound") + File.separator + fileName;

/*     */     try
/*     */     {
/* 223 */       InputStream instream = connection.getInputStream();
/* 224 */       FileOutputStream out = new FileOutputStream(dmpath);
/* 225 */       byte[] buffer = new byte[1024];
/* 226 */       int bytes = 0;
/* 227 */       while ((bytes = instream.read(buffer)) > 0) {
/* 228 */         out.write(buffer, 0, bytes);
/*     */       }
/* 230 */       out.flush();
/* 231 */       out.close();
/* 232 */       instream.close();
/*     */     }
/*     */     catch (IOException e) {
/* 235 */       log.error("CatalogItem", "doFileDownload", "Encountered a problem downloading the file:");
/* 236 */       log.error("CatalogItem", "doFileDownload", "error", e);
/*     */ 
/* 238 */       if (getBoolean("NEEDSAUTHENTICATION")) {
/* 239 */         log.error("CatalogItem", "doFileDownload", "Authentication is required.");
/* 240 */         throw new AuthenticationException();
/*     */       }
/* 242 */       throw e;
/*     */     }
/* 244 */     log.debugExit("CatalogItem", "doFileDownload");
/* 245 */     return new File(dmpath);
/*     */   }

/*     */   private void doContentLoaderDownload(URL url)
/*     */     throws IOException, MXException, FileNotFoundException, AuthenticationException
/*     */   {
/* 251 */     String METHOD = "doContentLoaderDownload";
/* 252 */     log.debugEntry("CatalogItem", "doContentLoaderDownload");
/*     */ 
/* 254 */     this.contentFile = doFileDownload(url);
/* 255 */     log.debugExit("CatalogItem", "doContentLoaderDownload");
/*     */   }


/*     */   private void doMriuDownload(URL url)
/*     */     throws IOException, MXException, FileNotFoundException, AuthenticationException
/*     */   {
/* 262 */     String METHOD = "doMriuDownload";
/* 263 */     log.debugEntry("CatalogItem", "doMriuDownload");
/*     */ 
/* 265 */     doContentLoaderDownload(url);
/* 266 */     IProgressMonitor monitor = new StringBufferMonitor();
/* 267 */     PackageManager mgr = new PackageManager();
/* 268 */     DefaultPackageResolver resolver = new DefaultPackageResolver(monitor);
/*     */     try
/*     */     {
/* 271 */       log.debug("CatalogItem", "doMriuDownload", "Starting the mriuPackage parser");
/* 272 */       this.mriuPackage = new MRIUPackage("");
/* 273 */       mgr.parsePackageImport(this.mriuPackage, this.contentFile.toURI(), resolver);

/*     */ 
/* 276 */       List files = this.mriuPackage.getFiles();
/* 277 */       displayFilesTab("doMriuDownload", files);



/*     */ 
/* 282 */       Map replacements = this.mriuPackage.getReplacements();
/* 283 */       displayReplacementsTab("doMriuDownload", replacements);

/*     */ 
/* 286 */       MboSetRemote docs = getMboSet("documents");
/* 287 */       displayDocumentsTab("doMriuDownload", docs);
/*     */     }
/*     */     catch (Exception e) {
/* 290 */       log.error("CatalogItem", "doMriuDownload", "Encountered a problem parsing the MRIU package content:");
/* 291 */       log.error("CatalogItem", "doMriuDownload", "error", e);
/* 292 */       throw new IOException(e.toString());
/*     */     }
/* 294 */     log.debugExit("CatalogItem", "doMriuDownload");
/*     */   }

/*     */   private void displayDocumentsTab(String METHOD, MboSetRemote docs)
/*     */     throws ZipException, IOException, MXException, RemoteException
/*     */   {
/* 300 */     log.debug("CatalogItem", METHOD, "Displaying the documents.");
/*     */ 
/* 302 */     ZipFile zip = new ZipFile(this.contentFile);
/* 303 */     Enumeration entires = zip.entries();
/* 304 */     while (entires.hasMoreElements()) {
/* 305 */       ZipEntry entry = (ZipEntry)entires.nextElement();
/* 306 */       if ((entry.getName().toLowerCase().startsWith("docs/")) && (entry.getName().toLowerCase().endsWith(".pdf"))) {
/* 307 */         String docUrl = writeDocFile(zip, entry);
/* 308 */         MboRemote docMbo = docs.addAtEnd();
/* 309 */         docMbo.setValue("FILE", entry.getName().substring(entry.getName().lastIndexOf(47) + 1));
/* 310 */         docMbo.setValue("SIZE", entry.getSize());
/* 311 */         docMbo.setValue("URL", docUrl);
/*     */       }
/*     */     }
/*     */   }







/*     */   private void displayReplacementsTab(String METHOD, Map<String, SelectionReplacementValue> replacements)
/*     */     throws MXException, RemoteException
/*     */   {
/* 325 */     log.debug("CatalogItem", METHOD, "Setting the replacement values.");
/*     */ 
/* 327 */     MboSetRemote ms = getMboSet("MRIUREPLACEMENTS");
/* 328 */     Set ids = replacements.keySet();
/*     */ 
/* 330 */     for (String id : ids)
/*     */     {
/* 332 */       AbstractReplacementValue rValue = (AbstractReplacementValue)replacements.get(id);
/* 333 */       MboRemote m = ms.addAtEnd();

/*     */ 
/* 336 */       m.setValue("ID", rValue.getId());

/*     */ 
/* 339 */       if (rValue.getColumnName().contains(","))
/* 340 */         m.setValue("ATTRIBUTENAME", "Multiple Replacements");
/*     */       else {
/* 342 */         m.setValue("ATTRIBUTENAME", rValue.getColumnName());
/*     */       }
/*     */ 
/* 345 */       if ((rValue.getDescription() != null) && (!(rValue.getDescription().equalsIgnoreCase(""))))
/* 346 */         m.setValue("DESCRIPTION", rValue.getDescription());
/*     */       else {
/* 348 */         m.setValue("DESCRIPTION", "Column(s): " + rValue.getColumnName());
/*     */       }
/*     */ 
/* 351 */       MboSetRemote replacementValues = m.getMboSet("POSSIBLEVALUES");
/* 352 */       List possibleValues = rValue.getValues();
/*     */ 
/* 354 */       if (possibleValues != null)
/*     */       {
/* 356 */         int lcv = 0; for (int size = possibleValues.size(); lcv < size; ++lcv)
/*     */         {
/* 358 */           String sqlValue = (String)possibleValues.get(lcv);
/*     */           try
/*     */           {
/* 361 */             replacementValues.addAtEnd().setValue("VALUE", sqlValue);
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 369 */         if (possibleValues.size() > 1)
/*     */         {
/*     */           try
/*     */           {
/* 373 */             m.setValue("VALUE", "");

/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*     */           }
/*     */ 
/*     */         }
/* 381 */         else if (possibleValues.size() == 1)
/*     */         {
/*     */           try
/*     */           {
/* 385 */             m.setValue("VALUE", (String)possibleValues.get(0));
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 394 */       if ((rValue.getDefaultValue() != null) && (!(rValue.getDefaultValue().trim().equals(""))))
/*     */       {
/* 396 */         m.setValue("VALUE", rValue.getDefaultValue());
/*     */       }
/*     */ 
/* 399 */       m.setFieldFlag("VALUE", 1L, true);
/* 400 */       m.setFieldFlag("VALUE", 128L, true);
/*     */     }
/*     */   }










/*     */   private void displayFilesTab(String METHOD, List<FilePath> files)
/*     */     throws MXException, RemoteException
/*     */   {
/* 416 */     MboSetRemote ms = getMboSet("MRIUCOMPONENTS");
/* 417 */     this.mriuItemToMboMap.clear();
/*     */ 
/* 419 */     log.debug("CatalogItem", METHOD, "Got " + files.size() + " files.");
/* 420 */     for (int i = 0; i < files.size(); ++i)
/*     */     {
/* 422 */       FilePath file = (FilePath)files.get(i);
/* 423 */       String description = file.getName();
/* 424 */       String id = file.getName();
/* 425 */       MboRemote m = ms.addAtEnd();
/* 426 */       m.setValue("ID", id);
/* 427 */       m.setValue("DESCRIPTION", description);
/* 428 */       m.setValue("SELECTED", true);
/* 429 */       if (!(file.isRequired()))
/*     */       {
/* 431 */         m.setFieldFlag("SELECTED", 7L, false);
/*     */       }
/*     */       else
/*     */       {
/* 435 */         m.setFieldFlag("SELECTED", 7L, true);
/*     */       }
/* 437 */       this.mriuItemToMboMap.add(new Object[] { file, m });
/*     */ 
/* 439 */       log.debug("CatalogItem", METHOD, "File " + i + ":" + file.getName());
/*     */     }
/*     */   }





/*     */   String writeDocFile(ZipFile zip, ZipEntry entry)
/*     */     throws IOException
/*     */   {
/* 450 */     String METHOD = "writeDocFile";
/* 451 */     log.debugEntry("CatalogItem", "writeDocFile");

/*     */ 
/* 454 */     String directoryName = this.contentFile.getName() + ".docs";
/* 455 */     File dirFile = new File(this.contentFile.getAbsolutePath() + ".docs");
/* 456 */     if (dirFile.exists()) {
/* 457 */       if (!(dirFile.isDirectory())) {
/* 458 */         dirFile.delete();
/* 459 */         if (dirFile.mkdir()) {
/* 460 */           throw new IOException("Cannot create directory " + dirFile);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/* 465 */     else if (!(dirFile.mkdir())) {
/* 466 */       throw new IOException("Cannot create directory " + dirFile);


/*     */     }
/*     */ 
/* 471 */     InputStream in = zip.getInputStream(entry);
/* 472 */     String fileName = entry.getName().substring(entry.getName().lastIndexOf(47) + 1);
/* 473 */     FileOutputStream out = new FileOutputStream(new File(dirFile, fileName));
/* 474 */     byte[] buffer = new byte[4096];
/* 475 */     int rc = in.read(buffer);
/* 476 */     while (rc >= 0) {
/* 477 */       out.write(buffer, 0, rc);
/* 478 */       rc = in.read(buffer);
/*     */     }
/* 480 */     out.flush();
/* 481 */     out.close();
/*     */ 
/* 483 */     log.debugExit("CatalogItem", "writeDocFile");
/*     */ 
/* 485 */     return "../migration/inbound/" + directoryName + "/" + fileName;
/*     */   }









/*     */   private void doMigrationManagerDownload(URL url)
/*     */     throws IOException, MXException, FileNotFoundException, AuthenticationException
/*     */   {
/* 499 */     String METHOD = "doMigrationManagerDownload";
/* 500 */     log.debugEntry("CatalogItem", "doMigrationManagerDownload");
/*     */ 
/* 502 */     this.contentFile = doFileDownload(url);
/*     */ 
/* 504 */     log.debugExit("CatalogItem", "doMigrationManagerDownload");
/*     */   }





/*     */   void cutReceipt(String installLog)
/*     */     throws RemoteException, MXException
/*     */   {
/* 514 */     String METHOD = "cutReceipt";
/* 515 */     log.debugEntry("CatalogItem", "cutReceipt");
/*     */ 
/* 517 */     MboSetRemote ms = getMboSet("receipts");
/* 518 */     MboRemote m = ms.addAtEnd();

/*     */ 
/* 521 */     if (isNull("NAVCODE"))
/*     */     {
/* 523 */       m.setValue("CATALOGITEMURL", getString("URL"));
/*     */     }
/*     */     else
/*     */     {
/* 527 */       m.setValue("NAVCODE", getString("NAVCODE"));
/*     */     }
/*     */ 
/* 530 */     m.setValue("ACCEPTEDLICENSE", getBoolean("ACCEPTEDLICENSE"));
/* 531 */     m.setValue("CATALOGURL", getOwner().getString("URL"));
/* 532 */     m.setValue("INSTALLDATE", new Date());
/* 533 */     m.setValue("INSTALLMESSAGES", installLog);
/* 534 */     ms.save();
/*     */ 
/* 536 */     log.info("CatalogItem", "cutReceipt", "Save Receipt:");
/* 537 */     log.info("CatalogItem", "cutReceipt", "CATALOGITEMURL: " + getString("URL"));
/* 538 */     log.info("CatalogItem", "cutReceipt", "CATALOGURL: " + getOwner().getString("URL"));
/* 539 */     log.info("CatalogItem", "cutReceipt", "INSTALLDATE: " + new Date());
/* 540 */     log.info("CatalogItem", "cutReceipt", "INSTALLMESSAGES: " + installLog);
/*     */ 
/* 542 */     log.debugExit("CatalogItem", "cutReceipt");
/*     */   }



/*     */   public void installContent()
/*     */     throws RemoteException, MXException
/*     */   {
/* 550 */     String METHOD = "installContent";
/* 551 */     log.debugEntry("CatalogItem", "installContent");
/*     */ 
/* 553 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 554 */     PrintStream installLog = new PrintStream(out);
/*     */     try
/*     */     {
/* 557 */       installLog.println("Install begins - " + new Date() + "\n");
/* 558 */       installLog.println("Install user: " + getUserName() + "\n");
/*     */ 
/* 560 */       String category = getString("CATEGORY");
/* 561 */       String name = getString("name");
/* 562 */       installLog.println("Installing: " + category + " / " + name + " (" + this.contentFile.getName() + ")");
/*     */ 
/* 564 */       log.info("CatalogItem", "installContent", "Install begins - " + new Date() + "\n");
/* 565 */       log.info("CatalogItem", "installContent", "Install user: " + getUserName() + "\n");
/* 566 */       log.info("CatalogItem", "installContent", "Installing: " + category + " / " + name + " (" + this.contentFile + ")");

/*     */ 
/* 569 */       URL url = this.contentFile.toURL();
/*     */ 
/* 571 */       String catalogItemType = getString("type");
/* 572 */       if (catalogItemType.equalsIgnoreCase("cl"))
/*     */       {
/* 574 */         doContentLoaderInstall(url, installLog);
/*     */       }
/* 576 */       else if (catalogItemType.equalsIgnoreCase("mm"))
/*     */       {
/* 578 */         doMigrationManagerInstall(url);
/*     */       }
/* 580 */       else if (catalogItemType.equalsIgnoreCase("mriu"))
/*     */       {
/* 582 */         doMriuInstall(url, installLog);
/*     */       }
/* 584 */       else if (catalogItemType.equalsIgnoreCase("mxs"))
/*     */       {
/* 586 */         doMxsInstall(url, installLog);
/*     */       }
/*     */ 
/* 589 */       this.installComplete = true;
/* 590 */       this.installFailed = false;
/*     */ 
/* 592 */       installLog.println("\nInstall completed sucessfully");
/* 593 */       installLog.println("\nInstall ends - " + new Date());
/* 594 */       log.info("CatalogItem", "installContent", "Install ends - " + new Date());
/* 595 */       log.info("CatalogItem", "installContent", "installComplete " + this.installComplete);
/* 596 */       log.info("CatalogItem", "installContent", "installFailed " + this.installFailed);


/*     */ 
/* 600 */       cutReceipt(out.toString());
/*     */     }
/*     */     catch (SAXException e) {
/* 603 */       Date SAXDate = new Date();
/* 604 */       log.error("CatalogItem", "installContent", "Encountered a problem parsing the XML:");
/* 605 */       log.error("CatalogItem", "installContent", "error", e);
/* 606 */       this.installFailed = true;
/* 607 */       this.installComplete = true;
/* 608 */       installLog.println("Install failed - " + SAXDate);
/* 609 */       installLog.println("\nThe install encountered a problem parsing the XML:");
/* 610 */       installLog.println("SAXParseException: " + e.getMessage());
/* 611 */       installLog.println("\nFor further details, review the maximo log files (e.g. maximo.log).");
/*     */ 
/* 613 */       log.error("CatalogItem", "installContent", "Install failed - " + SAXDate);
/* 614 */       log.error("CatalogItem", "installContent", "installComplete " + this.installComplete);
/* 615 */       log.error("CatalogItem", "installContent", "installFailed " + this.installFailed);
/*     */     }
/*     */     catch (Exception e) {
/* 618 */       log.error("CatalogItem", "installContent", "Encountered a problem installing content:");
/* 619 */       log.error("CatalogItem", "installContent", "error", e);
/* 620 */       this.installFailed = true;
/* 621 */       this.installComplete = true;
/* 622 */       installLog.println("Install failed - " + new Date());
/* 623 */       if (!(e.getMessage().equalsIgnoreCase("NO_FILES_SELECTED")))
/* 624 */         e.printStackTrace(installLog);
/*     */       else {
/* 626 */         installLog.println("\nNo files selected for import.\n");
/*     */       }
/* 628 */       installLog.println("\nFor further details, review the maximo log files (e.g. maximo.log).");
/* 629 */       log.error("CatalogItem", "installContent", "Install failed - " + new Date());
/* 630 */       log.error("CatalogItem", "installContent", "installComplete " + this.installComplete);
/* 631 */       log.error("CatalogItem", "installContent", "installFailed " + this.installFailed);
/*     */     } finally {
/* 633 */       installLog.flush();
/* 634 */       System.out.println(out.toString());
/* 635 */       setValue("installmessages", out.toString());
/*     */     }
/*     */ 
/* 638 */     log.debugExit("CatalogItem", "installContent");
/*     */   }







/*     */   private void doMigrationManagerInstall(URL url)
/*     */     throws IOException, MXException, FileNotFoundException, RemoteException
/*     */   {
/* 650 */     String METHOD = "doMigrationManagerInstall";
/* 651 */     log.debugEntry("CatalogItem", "doMigrationManagerInstall");


/*     */ 
/* 655 */     String fileName = this.contentFile.getName();
/* 656 */     String pkgName = fileName.substring(0, fileName.lastIndexOf("."));
/* 657 */     MboSetRemote ms = MXServer.getMXServer().getMboSet("DMDEPLOYABLEPKG", getUserInfo());
/*     */ 
/* 659 */     DMDeployablePkgRemote deployablePkg = (DMDeployablePkgRemote)ms.add();
/* 660 */     deployablePkg.setValue("package", pkgName, 11L);
/*     */ 
/* 662 */     deployablePkg.setValue("type", "FILE", 11L);
/*     */ 
/* 664 */     deployablePkg.loadStagingRecords();
/* 665 */     DMPackageRemote pkgMbo = (DMPackageRemote)deployablePkg.deployPkgMetaData();
/*     */ 
/* 667 */     pkgMbo.deployPackage(null);
/*     */ 
/* 669 */     log.debugExit("CatalogItem", "doMigrationManagerInstall");
/*     */   }










/*     */   private void doMxsInstall(URL url, PrintStream installLog)
/*     */     throws IOException, ParserConfigurationException, SAXException, RemoteException, Exception, SQLException
/*     */   {
/* 684 */     String METHOD = "doMxsInstall";
/* 685 */     log.debugEntry("CatalogItem", "doMxsInstall");
/*     */ 
/* 687 */     InputStream instream = url.openStream();

/*     */ 
/* 690 */     Connection con = MXServer.getMXServer().getDBManager().getConnection(getUserInfo().getConnectionKey());


/*     */     try
/*     */     {
/* 695 */       MXApplyTransactions.applyScreenUpdates(con, instream, installLog);
/* 696 */       con.commit();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 700 */       con.rollback();
/*     */ 
/* 702 */       throw e;
/*     */     }
/*     */     finally
/*     */     {
/* 706 */       MXServer.getMXServer().getDBManager().freeConnection(getUserInfo().getConnectionKey());
/*     */     }
/* 708 */     log.debugExit("CatalogItem", "doMxsInstall");
/*     */   }










/*     */   private void doContentLoaderInstall(URL url, PrintStream installLog)
/*     */     throws IOException, ParserConfigurationException, SAXException, RemoteException, Exception, SQLException
/*     */   {
/* 723 */     String METHOD = "doContentLoaderInstall";
/* 724 */     log.debugEntry("CatalogItem", "doContentLoaderInstall");
/*     */ 
/* 726 */     InputStream instream = url.openStream();

/*     */ 
/* 729 */     Connection con = MXServer.getMXServer().getDBManager().getConnection(getUserInfo().getConnectionKey());



/*     */     try
/*     */     {
/* 735 */       ImportSAXObject importer = new ImportSAXObject();
/* 736 */       importer.setOutput(installLog);
/* 737 */       importer.importFile(con, instream);
/* 738 */       con.commit();
/*     */     }
/*     */     finally
/*     */     {
/* 742 */       MXServer.getMXServer().getDBManager().freeConnection(getUserInfo().getConnectionKey());
/*     */     }
/* 744 */     log.debugExit("CatalogItem", "doContentLoaderInstall");
/*     */   }











/*     */   private void doMriuInstall(URL url, PrintStream installLog)
/*     */     throws IOException, ParserConfigurationException, SAXException, RemoteException, Exception, SQLException
/*     */   {
/* 760 */     String METHOD = "doMriuInstall";
/* 761 */     log.debugEntry("CatalogItem", "doMriuInstall");



/*     */     try
/*     */     {
/* 767 */       int lcv = 0; for (int size = this.mriuItemToMboMap.size(); lcv < size; ++lcv)
/*     */       {
/* 769 */         Object[] o = (Object[])this.mriuItemToMboMap.get(lcv);
/* 770 */         FilePath filePath = (FilePath)o[0];
/* 771 */         MboRemote m = (MboRemote)o[1];
/*     */ 
/* 773 */         filePath.setSelected(m.getBoolean("SELECTED"));
/*     */ 
/* 775 */         if (m.getBoolean("SELECTED"))
/* 776 */           log.debug("CatalogItem", "doMriuInstall", "Selected File: " + filePath.getName() + " (" + filePath.getPath() + ")");
/*     */         else {
/* 778 */           log.debug("CatalogItem", "doMriuInstall", "NOT Selected: " + filePath.getName() + " (" + filePath.getPath() + ")");
/*     */         }
/*     */       }
/*     */ 
/* 782 */       String replacementMessage = "";
/* 783 */       if (this.mriuPackage.getReplacements().size() > 0)
/*     */       {
/* 785 */         installLog.println("\nReplacements:");
/* 786 */         MboSetRemote ms = getMboSet("MRIUREPLACEMENTS");
/* 787 */         int lcv = 0; for (int size = ms.getSize(); lcv < size; ++lcv)
/*     */         {
/* 789 */           MboRemote m = ms.getMbo(lcv);
/* 790 */           String id = m.getString("ID");
/* 791 */           String repValue = m.getString("VALUE");

/*     */ 
/* 794 */           this.mriuPackage.getValuesIdMapReplacements().put(id, repValue);
/*     */ 
/* 796 */           replacementMessage = "Substituting value '" + repValue + "' for attribute " + ((SelectionReplacementValue)this.mriuPackage.getReplacements().get(id)).getColumnName();



/*     */ 
/* 801 */           String patternRep = ((SelectionReplacementValue)this.mriuPackage.getReplacements().get(id)).getPattern();
/* 802 */           if ((patternRep != null) && (!(patternRep.equals("")))) {
/* 803 */             replacementMessage = replacementMessage + " using the pattern: " + patternRep;
/*     */           }
/* 805 */           log.debug("CatalogItem", "doMriuInstall", replacementMessage);
/* 806 */           installLog.println(replacementMessage);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 811 */       Connection con = MXServer.getMXServer().getDBManager().getConnection(getUserInfo().getConnectionKey());
/*     */ 
/* 813 */       boolean somethingInstalled = false;
/* 814 */       boolean somethingSelected = false;
/* 815 */       List files = this.mriuPackage.getFiles();
/*     */ 
/* 817 */       Map replacementsForImport = this.mriuPackage.getCalculatedReplacementsForImport();
/*     */ 
/* 819 */       installLog.println("\nImporting: ");
/* 820 */       for (int i = 0; i < files.size(); ++i)
/*     */       {
/* 822 */         FilePath filePath = (FilePath)files.get(i);
/* 823 */         boolean isSelected = filePath.isSelected();
/*     */ 
/* 825 */         String fileNameAndPath = filePath.getName() + " (" + filePath.getPath() + ")";

/*     */ 
/* 828 */         if (!(isSelected))
/*     */         {
/* 830 */           installLog.println(fileNameAndPath + "\t[Installed:N];\t [Not Selected For Import.]");
/*     */         }
/*     */         else
/*     */         {
/* 834 */           somethingSelected = true;

/*     */           try
/*     */           {
/* 838 */             log.debug("CatalogItem", "doMriuInstall", "Importing file: " + filePath.getName() + " (" + filePath.getPath() + ")");

/*     */ 
/* 841 */             if (filePath.getType().equalsIgnoreCase("mxs"))
/*     */             {
/* 843 */               MXApplyTransactions.applyScreenUpdates(con, filePath.getInputStream(), installLog);

/*     */             }
/*     */             else
/*     */             {
/* 848 */               ImportSAXObject importer = new ImportSAXObject();
/*     */ 
/* 850 */               importer.setOutput(installLog);
/* 851 */               importer.importFile(con, filePath.getInputStream(), replacementsForImport);
/*     */             }
/*     */ 
/* 854 */             somethingInstalled = true;
/*     */ 
/* 856 */             log.debug("CatalogItem", "doMriuInstall", "Import complete.");
/* 857 */             installLog.println(fileNameAndPath + "\t[Installed:Y];\t [Import Complete.]");
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 861 */             con.rollback();
/*     */ 
/* 863 */             installLog.println("\n" + fileNameAndPath + "\t[Installed:N];\t [Import Failed.]");
/* 864 */             installLog.println(e.getMessage());
/* 865 */             installLog.println("\nNOTE: Rolling back all previous imports.");
/* 866 */             log.error("CatalogItem", "doMriuInstall", "Import failed: " + e.getMessage());
/* 867 */             log.error("CatalogItem", "doMriuInstall", "Import failed [FULL TRACE]: " + e);
/* 868 */             throw e;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 873 */       if (somethingInstalled)

/*     */       {
/* 876 */         con.commit();

/*     */ 
/* 879 */         List jythonFiles = this.mriuPackage.getJythonScripts();
/* 880 */         populateJythonScriptsArray(installLog, "doMriuInstall", jythonFiles);
/*     */       }
/*     */ 
/* 883 */       if (!(somethingSelected))
/*     */       {
/* 885 */         log.error("CatalogItem", "doMriuInstall", "Nothing imported! No files selected!");
/* 886 */         throw new Exception("NO_FILES_SELECTED");






/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 898 */       throw e;
/*     */     }
/*     */     finally {
/* 901 */       MXServer.getMXServer().getDBManager().freeConnection(getUserInfo().getConnectionKey());
/*     */     }
/*     */ 
/* 904 */     log.debugExit("CatalogItem", "doMriuInstall");
/*     */   }










/*     */   private void populateJythonScriptsArray(PrintStream installLog, String METHOD, List<FilePath> jythonFiles)
/*     */     throws Exception
/*     */   {
/* 919 */     this.jythonScripts = new ArrayList();
/* 920 */     if (jythonFiles == null)
/*     */       return;
/* 922 */     installLog.println();
/* 923 */     installLog.println("Jython Scripts:");
/* 924 */     for (int i = 0; i < jythonFiles.size(); ++i)
/*     */     {
/* 926 */       FilePath script = (FilePath)jythonFiles.get(i);
/* 927 */       String name = script.getName();
/* 928 */       String path = script.getPath();
/*     */ 
/* 930 */       log.info("CatalogItem", METHOD, "RUN THE JYTHON SCRIPT: " + name);
/* 931 */       log.debug("CatalogItem", METHOD, "                 path: " + path);
/* 932 */       installLog.println(name + " (" + path + ")");
/*     */ 
/* 934 */       this.jythonScripts.add(script.getFileContents());
/*     */     }
/*     */   }




/*     */   public String loadLicense()
/*     */     throws RemoteException, MXException
/*     */   {
/* 944 */     String METHOD = "loadLicense";
/* 945 */     log.debugEntry("CatalogItem", "loadLicense");
/*     */ 
/* 947 */     String licenseUrl = getString("LICENSEURL");
/* 948 */     if ((licenseUrl != null) && (licenseUrl.trim().length() > 0))
/*     */     {
/* 950 */       setValue("acceptedlicense", false);
/* 951 */       setFieldFlag("acceptedlicense", 7L, false);
/*     */ 
/* 953 */       return licenseUrl;


/*     */     }
/*     */ 
/* 958 */     setFieldFlag("acceptedlicense", 263L, true);
/* 959 */     setFieldFlag("acceptedlicense", 7L, true);
/* 960 */     return "";
/*     */   }

/*     */   public List<String> getJythonScripts()
/*     */     throws RemoteException, MXException
/*     */   {
/* 966 */     return this.jythonScripts;
/*     */   }

/*     */   public boolean isDownloadComplete() throws RemoteException, MXException {
/* 970 */     return this.downloadComplete;
/*     */   }

/*     */   public boolean isInstallComplete() throws RemoteException, MXException {
/* 974 */     return this.installComplete;
/*     */   }

/*     */   public String getDownloadMessages() throws RemoteException, MXException {
/* 978 */     return this.downloadMessages.toString();
/*     */   }

/*     */   public String getInstallMessages() throws RemoteException, MXException {
/* 982 */     return this.installMessages.toString();
/*     */   }

/*     */   public boolean isDownloadFailed() throws RemoteException, MXException {
/* 986 */     return this.downloadFailed;
/*     */   }

/*     */   public boolean isInstallFailed() throws RemoteException, MXException {
/* 990 */     return this.installFailed;
/*     */   }
/*     */ }
