package com.ibm.ism.content.virtual;

import psdi.mbo.NonPersistentMboRemote;

public abstract interface ContentReplacementRemote extends NonPersistentMboRemote
{
}
