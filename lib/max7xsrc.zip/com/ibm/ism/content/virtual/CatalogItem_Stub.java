/*      */ package com.ibm.ism.content.virtual;/*      */ /*      */ import java.lang.reflect.Method;/*      */ import java.rmi.RemoteException;/*      */ import java.rmi.UnexpectedException;/*      */ import java.rmi.server.RemoteObject;/*      */ import java.rmi.server.RemoteRef;/*      */ import java.rmi.server.RemoteStub;/*      */ import java.util.Date;/*      */ import java.util.HashMap;/*      */ import java.util.HashSet;/*      */ import java.util.Hashtable;/*      */ import java.util.List;/*      */ import java.util.Locale;/*      */ import java.util.Set;/*      */ import java.util.TimeZone;/*      */ import java.util.Vector;/*      */ import javax.naming.AuthenticationException;/*      */ import psdi.mbo.KeyValue;/*      */ import psdi.mbo.MaxMessage;/*      */ import psdi.mbo.Mbo;/*      */ import psdi.mbo.MboData;/*      */ import psdi.mbo.MboRemote;/*      */ import psdi.mbo.MboSetRemote;/*      */ import psdi.mbo.MboValueData;/*      */ import psdi.mbo.MboValueInfoStatic;/*      */ import psdi.mbo.NonPersistentMboRemote;/*      */ import psdi.security.UserInfo;/*      */ import psdi.txn.MXTransaction;/*      */ import psdi.util.ApplicationError;/*      */ import psdi.util.MXException;/*      */ import psdi.util.MaxType;/*      */ 
/*      */ public final class CatalogItem_Stub extends RemoteStub/*      */   implements CatalogItemRemote, NonPersistentMboRemote, MboRemote/*      */ {/*      */   private static final long serialVersionUID = 2L;/*      */   private static Method $method_add_0;/*      */   private static Method $method_addMboSetForRequiredCheck_1;/*      */   private static Method $method_addToDeleteForInsertList_2;/*      */   private static Method $method_blindCopy_3;/*      */   private static Method $method_checkMethodAccess_4;/*      */   private static Method $method_clear_5;/*      */   private static Method $method_copy_6;/*      */   private static Method $method_copy_7;/*      */   private static Method $method_copy_8;/*      */   private static Method $method_copyFake_9;/*      */   private static Method $method_copyValue_10;/*      */   private static Method $method_copyValue_11;/*      */   private static Method $method_createComm_12;/*      */   private static Method $method_delete_13;/*      */   private static Method $method_delete_14;/*      */   private static Method $method_downloadContent_15;/*      */   private static Method $method_duplicate_16;/*      */   private static Method $method_evaluateCondition_17;/*      */   private static Method $method_evaluateCtrlConditions_18;/*      */   private static Method $method_evaluateCtrlConditions_19;/*      */   private static Method $method_excludeObjectForPropagate_20;/*      */   private static Method $method_generateAutoKey_21;/*      */   private static Method $method_getBoolean_22;/*      */   private static Method $method_getByte_23;/*      */   private static Method $method_getBytes_24;/*      */   private static Method $method_getCommLogOwnerNameAndUniqueId_25;/*      */   private static Method $method_getDatabaseValue_26;/*      */   private static Method $method_getDate_27;/*      */   private static Method $method_getDeleteForInsertList_28;/*      */   private static Method $method_getDocLinksCount_29;/*      */   private static Method $method_getDomainIDs_30;/*      */   private static Method $method_getDouble_31;/*      */   private static Method $method_getDownloadMessages_32;/*      */   private static Method $method_getExistingMboSet_33;/*      */   private static Method $method_getFlags_34;/*      */   private static Method $method_getFloat_35;/*      */   private static Method $method_getInitialValue_36;/*      */   private static Method $method_getInsertCompanySetId_37;/*      */   private static Method $method_getInsertItemSetId_38;/*      */   private static Method $method_getInsertOrganization_39;/*      */   private static Method $method_getInsertSite_40;/*      */   private static Method $method_getInstallMessages_41;/*      */   private static Method $method_getInt_42;/*      */   private static Method $method_getJythonScripts_43;/*      */   private static Method $method_getKeyValue_44;/*      */   private static Method $method_getLinesRelationship_45;/*      */   private static Method $method_getList_46;/*      */   private static Method $method_getLong_47;/*      */   private static Method $method_getMXTransaction_48;/*      */   private static Method $method_getMatchingAttr_49;/*      */   private static Method $method_getMatchingAttr_50;/*      */   private static Method $method_getMatchingAttrs_51;/*      */   private static Method $method_getMaxMessage_52;/*      */   private static Method $method_getMboData_53;/*      */   private static Method $method_getMboDataSet_54;/*      */   private static Method $method_getMboInitialValue_55;/*      */   private static Method $method_getMboList_56;/*      */   private static Method $method_getMboSet_57;/*      */   private static Method $method_getMboSet_58;/*      */   private static Method $method_getMboSet_59;/*      */   private static Method $method_getMboValueData_60;/*      */   private static Method $method_getMboValueData_61;/*      */   private static Method $method_getMboValueData_62;/*      */   private static Method $method_getMboValueInfoStatic_63;/*      */   private static Method $method_getMboValueInfoStatic_64;/*      */   private static Method $method_getMessage_65;/*      */   private static Method $method_getMessage_66;/*      */   private static Method $method_getMessage_67;/*      */   private static Method $method_getMessage_68;/*      */   private static Method $method_getName_69;/*      */   private static Method $method_getOrgForGL_70;/*      */   private static Method $method_getOrgSiteForMaxvar_71;/*      */   private static Method $method_getOwner_72;/*      */   private static Method $method_getPropagateKeyFlag_73;/*      */   private static Method $method_getRecordIdentifer_74;/*      */   private static Method $method_getSiteOrg_75;/*      */   private static Method $method_getString_76;/*      */   private static Method $method_getString_77;/*      */   private static Method $method_getStringInBaseLanguage_78;/*      */   private static Method $method_getStringInSpecificLocale_79;/*      */   private static Method $method_getStringTransparent_80;/*      */   private static Method $method_getThisMboSet_81;/*      */   private static Method $method_getUniqueIDName_82;/*      */   private static Method $method_getUniqueIDValue_83;/*      */   private static Method $method_getUserInfo_84;/*      */   private static Method $method_getUserName_85;/*      */   private static Method $method_hasHierarchyLink_86;/*      */   private static Method $method_installContent_87;/*      */   private static Method $method_isAutoKeyed_88;/*      */   private static Method $method_isBasedOn_89;/*      */   private static Method $method_isDownloadComplete_90;/*      */   private static Method $method_isDownloadFailed_91;/*      */   private static Method $method_isFlagSet_92;/*      */   private static Method $method_isForDM_93;/*      */   private static Method $method_isInstallComplete_94;/*      */   private static Method $method_isInstallFailed_95;/*      */   private static Method $method_isModified_96;/*      */   private static Method $method_isModified_97;/*      */   private static Method $method_isNew_98;/*      */   private static Method $method_isNull_99;/*      */   private static Method $method_isSelected_100;/*      */   private static Method $method_isZombie_101;/*      */   private static Method $method_loadLicense_102;/*      */   private static Method $method_propagateKeyValue_103;/*      */   private static Method $method_rollbackToCheckpoint_104;/*      */   private static Method $method_select_105;/*      */   private static Method $method_setApplicationError_106;/*      */   private static Method $method_setApplicationRequired_107;/*      */   private static Method $method_setCopyDefaults_108;/*      */   private static Method $method_setDeleted_109;/*      */   private static Method $method_setESigFieldModified_110;/*      */   private static Method $method_setFieldFlag_111;/*      */   private static Method $method_setFieldFlag_112;/*      */   private static Method $method_setFieldFlag_113;/*      */   private static Method $method_setFieldFlag_114;/*      */   private static Method $method_setFieldFlag_115;/*      */   private static Method $method_setFieldFlag_116;/*      */   private static Method $method_setFieldFlags_117;/*      */   private static Method $method_setFlag_118;/*      */   private static Method $method_setFlag_119;/*      */   private static Method $method_setFlags_120;/*      */   private static Method $method_setForDM_121;/*      */   private static Method $method_setMLValue_122;/*      */   private static Method $method_setModified_123;/*      */   private static Method $method_setNewMbo_124;/*      */   private static Method $method_setPropagateKeyFlag_125;/*      */   private static Method $method_setPropagateKeyFlag_126;/*      */   private static Method $method_setReferencedMbo_127;/*      */   private static Method $method_setValue_128;/*      */   private static Method $method_setValue_129;/*      */   private static Method $method_setValue_130;/*      */   private static Method $method_setValue_131;/*      */   private static Method $method_setValue_132;/*      */   private static Method $method_setValue_133;/*      */   private static Method $method_setValue_134;/*      */   private static Method $method_setValue_135;/*      */   private static Method $method_setValue_136;/*      */   private static Method $method_setValue_137;/*      */   private static Method $method_setValue_138;/*      */   private static Method $method_setValue_139;/*      */   private static Method $method_setValue_140;/*      */   private static Method $method_setValue_141;/*      */   private static Method $method_setValue_142;/*      */   private static Method $method_setValue_143;/*      */   private static Method $method_setValue_144;/*      */   private static Method $method_setValue_145;/*      */   private static Method $method_setValue_146;/*      */   private static Method $method_setValue_147;/*      */   private static Method $method_setValue_148;/*      */   private static Method $method_setValue_149;/*      */   private static Method $method_setValue_150;/*      */   private static Method $method_setValueNull_151;/*      */   private static Method $method_setValueNull_152;/*      */   private static Method $method_sigOptionAccessAuthorized_153;/*      */   private static Method $method_sigopGranted_154;/*      */   private static Method $method_sigopGranted_155;/*      */   private static Method $method_sigopGranted_156;/*      */   private static Method $method_smartFill_157;/*      */   private static Method $method_smartFind_158;/*      */   private static Method $method_smartFind_159;/*      */   private static Method $method_smartFindByObjectName_160;/*      */   private static Method $method_smartFindByObjectName_161;/*      */   private static Method $method_smartFindByObjectNameDirect_162;/*      */   private static Method $method_startCheckpoint_163;/*      */   private static Method $method_thisToBeUpdated_164;/*      */   private static Method $method_toBeAdded_165;/*      */   private static Method $method_toBeDeleted_166;/*      */   private static Method $method_toBeSaved_167;/*      */   private static Method $method_toBeUpdated_168;/*      */   private static Method $method_toBeValidated_169;/*      */   private static Method $method_undelete_170;/*      */   private static Method $method_unselect_171;/*      */   private static Method $method_validate_172;/*      */   private static Method $method_validateAttributes_173;/*      */   static Class array$Ljava$lang$String;/*      */   static Class array$Ljava$lang$Object;/*      */   static Class array$B;/*      */   static Class array$$Ljava$lang$String;/*      */ /*      */   static/*      */   {/*      */     // Byte code:/*      */     //   0: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3: ifnull +9 -> 12/*      */     //   6: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   9: goto +12 -> 21/*      */     //   12: ldc 102/*      */     //   14: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   17: dup/*      */     //   18: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   21: ldc 5/*      */     //   23: iconst_0/*      */     //   24: anewarray 154	java/lang/Class/*      */     //   27: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   30: putstatic 194	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_add_0	Ljava/lang/reflect/Method;/*      */     //   33: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   36: ifnull +9 -> 45/*      */     //   39: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   42: goto +12 -> 54/*      */     //   45: ldc 102/*      */     //   47: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   50: dup/*      */     //   51: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   54: ldc 6/*      */     //   56: iconst_1/*      */     //   57: anewarray 154	java/lang/Class/*      */     //   60: dup/*      */     //   61: iconst_0/*      */     //   62: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   65: ifnull +9 -> 74/*      */     //   68: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   71: goto +12 -> 83/*      */     //   74: ldc 103/*      */     //   76: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   79: dup/*      */     //   80: putstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   83: aastore/*      */     //   84: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   87: putstatic 192	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_addMboSetForRequiredCheck_1	Ljava/lang/reflect/Method;/*      */     //   90: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   93: ifnull +9 -> 102/*      */     //   96: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   99: goto +12 -> 111/*      */     //   102: ldc 102/*      */     //   104: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   107: dup/*      */     //   108: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   111: ldc 7/*      */     //   113: iconst_1/*      */     //   114: anewarray 154	java/lang/Class/*      */     //   117: dup/*      */     //   118: iconst_0/*      */     //   119: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   122: ifnull +9 -> 131/*      */     //   125: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   128: goto +12 -> 140/*      */     //   131: ldc 93/*      */     //   133: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   136: dup/*      */     //   137: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   140: aastore/*      */     //   141: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   144: putstatic 193	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_addToDeleteForInsertList_2	Ljava/lang/reflect/Method;/*      */     //   147: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   150: ifnull +9 -> 159/*      */     //   153: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   156: goto +12 -> 168/*      */     //   159: ldc 102/*      */     //   161: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   164: dup/*      */     //   165: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   168: ldc 8/*      */     //   170: iconst_1/*      */     //   171: anewarray 154	java/lang/Class/*      */     //   174: dup/*      */     //   175: iconst_0/*      */     //   176: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   179: ifnull +9 -> 188/*      */     //   182: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   185: goto +12 -> 197/*      */     //   188: ldc 103/*      */     //   190: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   193: dup/*      */     //   194: putstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   197: aastore/*      */     //   198: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   201: putstatic 195	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_blindCopy_3	Ljava/lang/reflect/Method;/*      */     //   204: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   207: ifnull +9 -> 216/*      */     //   210: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   213: goto +12 -> 225/*      */     //   216: ldc 102/*      */     //   218: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   221: dup/*      */     //   222: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   225: ldc 9/*      */     //   227: iconst_1/*      */     //   228: anewarray 154	java/lang/Class/*      */     //   231: dup/*      */     //   232: iconst_0/*      */     //   233: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   236: ifnull +9 -> 245/*      */     //   239: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   242: goto +12 -> 254/*      */     //   245: ldc 93/*      */     //   247: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   250: dup/*      */     //   251: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   254: aastore/*      */     //   255: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   258: putstatic 196	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_checkMethodAccess_4	Ljava/lang/reflect/Method;/*      */     //   261: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   264: ifnull +9 -> 273/*      */     //   267: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   270: goto +12 -> 282/*      */     //   273: ldc 102/*      */     //   275: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   278: dup/*      */     //   279: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   282: ldc 10/*      */     //   284: iconst_0/*      */     //   285: anewarray 154	java/lang/Class/*      */     //   288: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   291: putstatic 197	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_clear_5	Ljava/lang/reflect/Method;/*      */     //   294: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   297: ifnull +9 -> 306/*      */     //   300: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   303: goto +12 -> 315/*      */     //   306: ldc 102/*      */     //   308: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   311: dup/*      */     //   312: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   315: ldc 12/*      */     //   317: iconst_0/*      */     //   318: anewarray 154	java/lang/Class/*      */     //   321: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   324: putstatic 201	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_copy_6	Ljava/lang/reflect/Method;/*      */     //   327: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   330: ifnull +9 -> 339/*      */     //   333: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   336: goto +12 -> 348/*      */     //   339: ldc 102/*      */     //   341: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   344: dup/*      */     //   345: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   348: ldc 12/*      */     //   350: iconst_1/*      */     //   351: anewarray 154	java/lang/Class/*      */     //   354: dup/*      */     //   355: iconst_0/*      */     //   356: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   359: ifnull +9 -> 368/*      */     //   362: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   365: goto +12 -> 377/*      */     //   368: ldc 103/*      */     //   370: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   373: dup/*      */     //   374: putstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   377: aastore/*      */     //   378: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   381: putstatic 202	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_copy_7	Ljava/lang/reflect/Method;/*      */     //   384: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   387: ifnull +9 -> 396/*      */     //   390: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   393: goto +12 -> 405/*      */     //   396: ldc 102/*      */     //   398: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   401: dup/*      */     //   402: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   405: ldc 12/*      */     //   407: iconst_2/*      */     //   408: anewarray 154	java/lang/Class/*      */     //   411: dup/*      */     //   412: iconst_0/*      */     //   413: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   416: ifnull +9 -> 425/*      */     //   419: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   422: goto +12 -> 434/*      */     //   425: ldc 103/*      */     //   427: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   430: dup/*      */     //   431: putstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   434: aastore/*      */     //   435: dup/*      */     //   436: iconst_1/*      */     //   437: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   440: aastore/*      */     //   441: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   444: putstatic 203	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_copy_8	Ljava/lang/reflect/Method;/*      */     //   447: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   450: ifnull +9 -> 459/*      */     //   453: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   456: goto +12 -> 468/*      */     //   459: ldc 102/*      */     //   461: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   464: dup/*      */     //   465: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   468: ldc 13/*      */     //   470: iconst_1/*      */     //   471: anewarray 154	java/lang/Class/*      */     //   474: dup/*      */     //   475: iconst_0/*      */     //   476: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   479: ifnull +9 -> 488/*      */     //   482: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   485: goto +12 -> 497/*      */     //   488: ldc 103/*      */     //   490: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   493: dup/*      */     //   494: putstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   497: aastore/*      */     //   498: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   501: putstatic 198	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_copyFake_9	Ljava/lang/reflect/Method;/*      */     //   504: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   507: ifnull +9 -> 516/*      */     //   510: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   513: goto +12 -> 525/*      */     //   516: ldc 102/*      */     //   518: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   521: dup/*      */     //   522: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   525: ldc 14/*      */     //   527: iconst_4/*      */     //   528: anewarray 154	java/lang/Class/*      */     //   531: dup/*      */     //   532: iconst_0/*      */     //   533: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   536: ifnull +9 -> 545/*      */     //   539: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   542: goto +12 -> 554/*      */     //   545: ldc 102/*      */     //   547: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   550: dup/*      */     //   551: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   554: aastore/*      */     //   555: dup/*      */     //   556: iconst_1/*      */     //   557: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   560: ifnull +9 -> 569/*      */     //   563: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   566: goto +12 -> 578/*      */     //   569: ldc 93/*      */     //   571: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   574: dup/*      */     //   575: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   578: aastore/*      */     //   579: dup/*      */     //   580: iconst_2/*      */     //   581: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   584: ifnull +9 -> 593/*      */     //   587: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   590: goto +12 -> 602/*      */     //   593: ldc 93/*      */     //   595: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   598: dup/*      */     //   599: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   602: aastore/*      */     //   603: dup/*      */     //   604: iconst_3/*      */     //   605: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   608: aastore/*      */     //   609: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   612: putstatic 199	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_copyValue_10	Ljava/lang/reflect/Method;/*      */     //   615: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   618: ifnull +9 -> 627/*      */     //   621: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   624: goto +12 -> 636/*      */     //   627: ldc 102/*      */     //   629: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   632: dup/*      */     //   633: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   636: ldc 14/*      */     //   638: iconst_4/*      */     //   639: anewarray 154	java/lang/Class/*      */     //   642: dup/*      */     //   643: iconst_0/*      */     //   644: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   647: ifnull +9 -> 656/*      */     //   650: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   653: goto +12 -> 665/*      */     //   656: ldc 102/*      */     //   658: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   661: dup/*      */     //   662: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   665: aastore/*      */     //   666: dup/*      */     //   667: iconst_1/*      */     //   668: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   671: ifnull +9 -> 680/*      */     //   674: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   677: goto +12 -> 689/*      */     //   680: ldc 3/*      */     //   682: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   685: dup/*      */     //   686: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   689: aastore/*      */     //   690: dup/*      */     //   691: iconst_2/*      */     //   692: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   695: ifnull +9 -> 704/*      */     //   698: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   701: goto +12 -> 713/*      */     //   704: ldc 3/*      */     //   706: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   709: dup/*      */     //   710: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   713: aastore/*      */     //   714: dup/*      */     //   715: iconst_3/*      */     //   716: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   719: aastore/*      */     //   720: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   723: putstatic 200	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_copyValue_11	Ljava/lang/reflect/Method;/*      */     //   726: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   729: ifnull +9 -> 738/*      */     //   732: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   735: goto +12 -> 747/*      */     //   738: ldc 102/*      */     //   740: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   743: dup/*      */     //   744: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   747: ldc 15/*      */     //   749: iconst_0/*      */     //   750: anewarray 154	java/lang/Class/*      */     //   753: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   756: putstatic 204	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_createComm_12	Ljava/lang/reflect/Method;/*      */     //   759: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   762: ifnull +9 -> 771/*      */     //   765: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   768: goto +12 -> 780/*      */     //   771: ldc 102/*      */     //   773: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   776: dup/*      */     //   777: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   780: ldc 16/*      */     //   782: iconst_0/*      */     //   783: anewarray 154	java/lang/Class/*      */     //   786: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   789: putstatic 205	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_delete_13	Ljava/lang/reflect/Method;/*      */     //   792: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   795: ifnull +9 -> 804/*      */     //   798: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   801: goto +12 -> 813/*      */     //   804: ldc 102/*      */     //   806: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   809: dup/*      */     //   810: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   813: ldc 16/*      */     //   815: iconst_1/*      */     //   816: anewarray 154	java/lang/Class/*      */     //   819: dup/*      */     //   820: iconst_0/*      */     //   821: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   824: aastore/*      */     //   825: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   828: putstatic 206	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_delete_14	Ljava/lang/reflect/Method;/*      */     //   831: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   834: ifnull +9 -> 843/*      */     //   837: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   840: goto +12 -> 852/*      */     //   843: ldc 11/*      */     //   845: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   848: dup/*      */     //   849: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   852: ldc 17/*      */     //   854: iconst_0/*      */     //   855: anewarray 154	java/lang/Class/*      */     //   858: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   861: putstatic 207	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_downloadContent_15	Ljava/lang/reflect/Method;/*      */     //   864: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   867: ifnull +9 -> 876/*      */     //   870: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   873: goto +12 -> 885/*      */     //   876: ldc 102/*      */     //   878: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   881: dup/*      */     //   882: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   885: ldc 18/*      */     //   887: iconst_0/*      */     //   888: anewarray 154	java/lang/Class/*      */     //   891: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   894: putstatic 208	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_duplicate_16	Ljava/lang/reflect/Method;/*      */     //   897: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   900: ifnull +9 -> 909/*      */     //   903: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   906: goto +12 -> 918/*      */     //   909: ldc 102/*      */     //   911: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   914: dup/*      */     //   915: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   918: ldc 19/*      */     //   920: iconst_1/*      */     //   921: anewarray 154	java/lang/Class/*      */     //   924: dup/*      */     //   925: iconst_0/*      */     //   926: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   929: ifnull +9 -> 938/*      */     //   932: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   935: goto +12 -> 947/*      */     //   938: ldc 93/*      */     //   940: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   943: dup/*      */     //   944: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   947: aastore/*      */     //   948: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   951: putstatic 209	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_evaluateCondition_17	Ljava/lang/reflect/Method;/*      */     //   954: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   957: ifnull +9 -> 966/*      */     //   960: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   963: goto +12 -> 975/*      */     //   966: ldc 102/*      */     //   968: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   971: dup/*      */     //   972: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   975: ldc 20/*      */     //   977: iconst_1/*      */     //   978: anewarray 154	java/lang/Class/*      */     //   981: dup/*      */     //   982: iconst_0/*      */     //   983: getstatic 396	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$HashSet	Ljava/lang/Class;/*      */     //   986: ifnull +9 -> 995/*      */     //   989: getstatic 396	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$HashSet	Ljava/lang/Class;/*      */     //   992: goto +12 -> 1004/*      */     //   995: ldc 95/*      */     //   997: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1000: dup/*      */     //   1001: putstatic 396	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$HashSet	Ljava/lang/Class;/*      */     //   1004: aastore/*      */     //   1005: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1008: putstatic 210	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_evaluateCtrlConditions_18	Ljava/lang/reflect/Method;/*      */     //   1011: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1014: ifnull +9 -> 1023/*      */     //   1017: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1020: goto +12 -> 1032/*      */     //   1023: ldc 102/*      */     //   1025: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1028: dup/*      */     //   1029: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1032: ldc 20/*      */     //   1034: iconst_2/*      */     //   1035: anewarray 154	java/lang/Class/*      */     //   1038: dup/*      */     //   1039: iconst_0/*      */     //   1040: getstatic 396	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$HashSet	Ljava/lang/Class;/*      */     //   1043: ifnull +9 -> 1052/*      */     //   1046: getstatic 396	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$HashSet	Ljava/lang/Class;/*      */     //   1049: goto +12 -> 1061/*      */     //   1052: ldc 95/*      */     //   1054: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1057: dup/*      */     //   1058: putstatic 396	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$HashSet	Ljava/lang/Class;/*      */     //   1061: aastore/*      */     //   1062: dup/*      */     //   1063: iconst_1/*      */     //   1064: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1067: ifnull +9 -> 1076/*      */     //   1070: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1073: goto +12 -> 1085/*      */     //   1076: ldc 93/*      */     //   1078: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1081: dup/*      */     //   1082: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1085: aastore/*      */     //   1086: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1089: putstatic 211	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_evaluateCtrlConditions_19	Ljava/lang/reflect/Method;/*      */     //   1092: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1095: ifnull +9 -> 1104/*      */     //   1098: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1101: goto +12 -> 1113/*      */     //   1104: ldc 102/*      */     //   1106: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1109: dup/*      */     //   1110: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1113: ldc 21/*      */     //   1115: iconst_1/*      */     //   1116: anewarray 154	java/lang/Class/*      */     //   1119: dup/*      */     //   1120: iconst_0/*      */     //   1121: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1124: ifnull +9 -> 1133/*      */     //   1127: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1130: goto +12 -> 1142/*      */     //   1133: ldc 93/*      */     //   1135: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1138: dup/*      */     //   1139: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1142: aastore/*      */     //   1143: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1146: putstatic 212	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_excludeObjectForPropagate_20	Ljava/lang/reflect/Method;/*      */     //   1149: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1152: ifnull +9 -> 1161/*      */     //   1155: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1158: goto +12 -> 1170/*      */     //   1161: ldc 102/*      */     //   1163: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1166: dup/*      */     //   1167: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1170: ldc 22/*      */     //   1172: iconst_0/*      */     //   1173: anewarray 154	java/lang/Class/*      */     //   1176: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1179: putstatic 213	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_generateAutoKey_21	Ljava/lang/reflect/Method;/*      */     //   1182: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1185: ifnull +9 -> 1194/*      */     //   1188: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1191: goto +12 -> 1203/*      */     //   1194: ldc 102/*      */     //   1196: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1199: dup/*      */     //   1200: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1203: ldc 23/*      */     //   1205: iconst_1/*      */     //   1206: anewarray 154	java/lang/Class/*      */     //   1209: dup/*      */     //   1210: iconst_0/*      */     //   1211: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1214: ifnull +9 -> 1223/*      */     //   1217: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1220: goto +12 -> 1232/*      */     //   1223: ldc 93/*      */     //   1225: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1228: dup/*      */     //   1229: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1232: aastore/*      */     //   1233: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1236: putstatic 214	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getBoolean_22	Ljava/lang/reflect/Method;/*      */     //   1239: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1242: ifnull +9 -> 1251/*      */     //   1245: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1248: goto +12 -> 1260/*      */     //   1251: ldc 102/*      */     //   1253: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1256: dup/*      */     //   1257: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1260: ldc 24/*      */     //   1262: iconst_1/*      */     //   1263: anewarray 154	java/lang/Class/*      */     //   1266: dup/*      */     //   1267: iconst_0/*      */     //   1268: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1271: ifnull +9 -> 1280/*      */     //   1274: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1277: goto +12 -> 1289/*      */     //   1280: ldc 93/*      */     //   1282: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1285: dup/*      */     //   1286: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1289: aastore/*      */     //   1290: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1293: putstatic 215	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getByte_23	Ljava/lang/reflect/Method;/*      */     //   1296: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1299: ifnull +9 -> 1308/*      */     //   1302: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1305: goto +12 -> 1317/*      */     //   1308: ldc 102/*      */     //   1310: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1313: dup/*      */     //   1314: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1317: ldc 25/*      */     //   1319: iconst_1/*      */     //   1320: anewarray 154	java/lang/Class/*      */     //   1323: dup/*      */     //   1324: iconst_0/*      */     //   1325: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1328: ifnull +9 -> 1337/*      */     //   1331: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1334: goto +12 -> 1346/*      */     //   1337: ldc 93/*      */     //   1339: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1342: dup/*      */     //   1343: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1346: aastore/*      */     //   1347: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1350: putstatic 216	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getBytes_24	Ljava/lang/reflect/Method;/*      */     //   1353: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1356: ifnull +9 -> 1365/*      */     //   1359: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1362: goto +12 -> 1374/*      */     //   1365: ldc 102/*      */     //   1367: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1370: dup/*      */     //   1371: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1374: ldc 26/*      */     //   1376: iconst_0/*      */     //   1377: anewarray 154	java/lang/Class/*      */     //   1380: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1383: putstatic 217	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getCommLogOwnerNameAndUniqueId_25	Ljava/lang/reflect/Method;/*      */     //   1386: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1389: ifnull +9 -> 1398/*      */     //   1392: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1395: goto +12 -> 1407/*      */     //   1398: ldc 102/*      */     //   1400: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1403: dup/*      */     //   1404: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1407: ldc 27/*      */     //   1409: iconst_1/*      */     //   1410: anewarray 154	java/lang/Class/*      */     //   1413: dup/*      */     //   1414: iconst_0/*      */     //   1415: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1418: ifnull +9 -> 1427/*      */     //   1421: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1424: goto +12 -> 1436/*      */     //   1427: ldc 93/*      */     //   1429: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1432: dup/*      */     //   1433: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1436: aastore/*      */     //   1437: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1440: putstatic 218	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getDatabaseValue_26	Ljava/lang/reflect/Method;/*      */     //   1443: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1446: ifnull +9 -> 1455/*      */     //   1449: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1452: goto +12 -> 1464/*      */     //   1455: ldc 102/*      */     //   1457: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1460: dup/*      */     //   1461: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1464: ldc 28/*      */     //   1466: iconst_1/*      */     //   1467: anewarray 154	java/lang/Class/*      */     //   1470: dup/*      */     //   1471: iconst_0/*      */     //   1472: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1475: ifnull +9 -> 1484/*      */     //   1478: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1481: goto +12 -> 1493/*      */     //   1484: ldc 93/*      */     //   1486: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1489: dup/*      */     //   1490: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1493: aastore/*      */     //   1494: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1497: putstatic 219	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getDate_27	Ljava/lang/reflect/Method;/*      */     //   1500: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1503: ifnull +9 -> 1512/*      */     //   1506: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1509: goto +12 -> 1521/*      */     //   1512: ldc 102/*      */     //   1514: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1517: dup/*      */     //   1518: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1521: ldc 29/*      */     //   1523: iconst_0/*      */     //   1524: anewarray 154	java/lang/Class/*      */     //   1527: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1530: putstatic 220	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getDeleteForInsertList_28	Ljava/lang/reflect/Method;/*      */     //   1533: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1536: ifnull +9 -> 1545/*      */     //   1539: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1542: goto +12 -> 1554/*      */     //   1545: ldc 102/*      */     //   1547: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1550: dup/*      */     //   1551: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1554: ldc 30/*      */     //   1556: iconst_0/*      */     //   1557: anewarray 154	java/lang/Class/*      */     //   1560: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1563: putstatic 221	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getDocLinksCount_29	Ljava/lang/reflect/Method;/*      */     //   1566: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1569: ifnull +9 -> 1578/*      */     //   1572: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1575: goto +12 -> 1587/*      */     //   1578: ldc 102/*      */     //   1580: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1583: dup/*      */     //   1584: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1587: ldc 31/*      */     //   1589: iconst_1/*      */     //   1590: anewarray 154	java/lang/Class/*      */     //   1593: dup/*      */     //   1594: iconst_0/*      */     //   1595: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1598: ifnull +9 -> 1607/*      */     //   1601: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1604: goto +12 -> 1616/*      */     //   1607: ldc 93/*      */     //   1609: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1612: dup/*      */     //   1613: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1616: aastore/*      */     //   1617: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1620: putstatic 222	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getDomainIDs_30	Ljava/lang/reflect/Method;/*      */     //   1623: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1626: ifnull +9 -> 1635/*      */     //   1629: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1632: goto +12 -> 1644/*      */     //   1635: ldc 102/*      */     //   1637: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1640: dup/*      */     //   1641: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1644: ldc 32/*      */     //   1646: iconst_1/*      */     //   1647: anewarray 154	java/lang/Class/*      */     //   1650: dup/*      */     //   1651: iconst_0/*      */     //   1652: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1655: ifnull +9 -> 1664/*      */     //   1658: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1661: goto +12 -> 1673/*      */     //   1664: ldc 93/*      */     //   1666: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1669: dup/*      */     //   1670: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1673: aastore/*      */     //   1674: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1677: putstatic 223	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getDouble_31	Ljava/lang/reflect/Method;/*      */     //   1680: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   1683: ifnull +9 -> 1692/*      */     //   1686: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   1689: goto +12 -> 1701/*      */     //   1692: ldc 11/*      */     //   1694: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1697: dup/*      */     //   1698: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   1701: ldc 33/*      */     //   1703: iconst_0/*      */     //   1704: anewarray 154	java/lang/Class/*      */     //   1707: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1710: putstatic 224	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getDownloadMessages_32	Ljava/lang/reflect/Method;/*      */     //   1713: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1716: ifnull +9 -> 1725/*      */     //   1719: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1722: goto +12 -> 1734/*      */     //   1725: ldc 102/*      */     //   1727: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1730: dup/*      */     //   1731: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1734: ldc 34/*      */     //   1736: iconst_1/*      */     //   1737: anewarray 154	java/lang/Class/*      */     //   1740: dup/*      */     //   1741: iconst_0/*      */     //   1742: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1745: ifnull +9 -> 1754/*      */     //   1748: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1751: goto +12 -> 1763/*      */     //   1754: ldc 93/*      */     //   1756: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1759: dup/*      */     //   1760: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1763: aastore/*      */     //   1764: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1767: putstatic 225	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getExistingMboSet_33	Ljava/lang/reflect/Method;/*      */     //   1770: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1773: ifnull +9 -> 1782/*      */     //   1776: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1779: goto +12 -> 1791/*      */     //   1782: ldc 102/*      */     //   1784: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1787: dup/*      */     //   1788: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1791: ldc 35/*      */     //   1793: iconst_0/*      */     //   1794: anewarray 154	java/lang/Class/*      */     //   1797: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1800: putstatic 226	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getFlags_34	Ljava/lang/reflect/Method;/*      */     //   1803: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1806: ifnull +9 -> 1815/*      */     //   1809: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1812: goto +12 -> 1824/*      */     //   1815: ldc 102/*      */     //   1817: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1820: dup/*      */     //   1821: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1824: ldc 36/*      */     //   1826: iconst_1/*      */     //   1827: anewarray 154	java/lang/Class/*      */     //   1830: dup/*      */     //   1831: iconst_0/*      */     //   1832: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1835: ifnull +9 -> 1844/*      */     //   1838: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1841: goto +12 -> 1853/*      */     //   1844: ldc 93/*      */     //   1846: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1849: dup/*      */     //   1850: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1853: aastore/*      */     //   1854: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1857: putstatic 227	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getFloat_35	Ljava/lang/reflect/Method;/*      */     //   1860: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1863: ifnull +9 -> 1872/*      */     //   1866: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1869: goto +12 -> 1881/*      */     //   1872: ldc 102/*      */     //   1874: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1877: dup/*      */     //   1878: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1881: ldc 37/*      */     //   1883: iconst_1/*      */     //   1884: anewarray 154	java/lang/Class/*      */     //   1887: dup/*      */     //   1888: iconst_0/*      */     //   1889: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1892: ifnull +9 -> 1901/*      */     //   1895: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1898: goto +12 -> 1910/*      */     //   1901: ldc 93/*      */     //   1903: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1906: dup/*      */     //   1907: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   1910: aastore/*      */     //   1911: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1914: putstatic 228	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getInitialValue_36	Ljava/lang/reflect/Method;/*      */     //   1917: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1920: ifnull +9 -> 1929/*      */     //   1923: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1926: goto +12 -> 1938/*      */     //   1929: ldc 102/*      */     //   1931: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1934: dup/*      */     //   1935: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1938: ldc 38/*      */     //   1940: iconst_0/*      */     //   1941: anewarray 154	java/lang/Class/*      */     //   1944: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1947: putstatic 229	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getInsertCompanySetId_37	Ljava/lang/reflect/Method;/*      */     //   1950: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1953: ifnull +9 -> 1962/*      */     //   1956: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1959: goto +12 -> 1971/*      */     //   1962: ldc 102/*      */     //   1964: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   1967: dup/*      */     //   1968: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1971: ldc 39/*      */     //   1973: iconst_0/*      */     //   1974: anewarray 154	java/lang/Class/*      */     //   1977: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   1980: putstatic 230	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getInsertItemSetId_38	Ljava/lang/reflect/Method;/*      */     //   1983: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1986: ifnull +9 -> 1995/*      */     //   1989: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   1992: goto +12 -> 2004/*      */     //   1995: ldc 102/*      */     //   1997: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2000: dup/*      */     //   2001: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2004: ldc 40/*      */     //   2006: iconst_0/*      */     //   2007: anewarray 154	java/lang/Class/*      */     //   2010: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2013: putstatic 231	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getInsertOrganization_39	Ljava/lang/reflect/Method;/*      */     //   2016: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2019: ifnull +9 -> 2028/*      */     //   2022: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2025: goto +12 -> 2037/*      */     //   2028: ldc 102/*      */     //   2030: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2033: dup/*      */     //   2034: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2037: ldc 41/*      */     //   2039: iconst_0/*      */     //   2040: anewarray 154	java/lang/Class/*      */     //   2043: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2046: putstatic 232	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getInsertSite_40	Ljava/lang/reflect/Method;/*      */     //   2049: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   2052: ifnull +9 -> 2061/*      */     //   2055: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   2058: goto +12 -> 2070/*      */     //   2061: ldc 11/*      */     //   2063: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2066: dup/*      */     //   2067: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   2070: ldc 42/*      */     //   2072: iconst_0/*      */     //   2073: anewarray 154	java/lang/Class/*      */     //   2076: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2079: putstatic 233	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getInstallMessages_41	Ljava/lang/reflect/Method;/*      */     //   2082: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2085: ifnull +9 -> 2094/*      */     //   2088: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2091: goto +12 -> 2103/*      */     //   2094: ldc 102/*      */     //   2096: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2099: dup/*      */     //   2100: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2103: ldc 43/*      */     //   2105: iconst_1/*      */     //   2106: anewarray 154	java/lang/Class/*      */     //   2109: dup/*      */     //   2110: iconst_0/*      */     //   2111: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2114: ifnull +9 -> 2123/*      */     //   2117: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2120: goto +12 -> 2132/*      */     //   2123: ldc 93/*      */     //   2125: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2128: dup/*      */     //   2129: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2132: aastore/*      */     //   2133: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2136: putstatic 234	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getInt_42	Ljava/lang/reflect/Method;/*      */     //   2139: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   2142: ifnull +9 -> 2151/*      */     //   2145: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   2148: goto +12 -> 2160/*      */     //   2151: ldc 11/*      */     //   2153: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2156: dup/*      */     //   2157: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   2160: ldc 44/*      */     //   2162: iconst_0/*      */     //   2163: anewarray 154	java/lang/Class/*      */     //   2166: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2169: putstatic 235	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getJythonScripts_43	Ljava/lang/reflect/Method;/*      */     //   2172: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2175: ifnull +9 -> 2184/*      */     //   2178: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2181: goto +12 -> 2193/*      */     //   2184: ldc 102/*      */     //   2186: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2189: dup/*      */     //   2190: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2193: ldc 45/*      */     //   2195: iconst_0/*      */     //   2196: anewarray 154	java/lang/Class/*      */     //   2199: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2202: putstatic 236	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getKeyValue_44	Ljava/lang/reflect/Method;/*      */     //   2205: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2208: ifnull +9 -> 2217/*      */     //   2211: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2214: goto +12 -> 2226/*      */     //   2217: ldc 102/*      */     //   2219: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2222: dup/*      */     //   2223: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2226: ldc 46/*      */     //   2228: iconst_0/*      */     //   2229: anewarray 154	java/lang/Class/*      */     //   2232: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2235: putstatic 237	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getLinesRelationship_45	Ljava/lang/reflect/Method;/*      */     //   2238: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2241: ifnull +9 -> 2250/*      */     //   2244: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2247: goto +12 -> 2259/*      */     //   2250: ldc 102/*      */     //   2252: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2255: dup/*      */     //   2256: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2259: ldc 47/*      */     //   2261: iconst_1/*      */     //   2262: anewarray 154	java/lang/Class/*      */     //   2265: dup/*      */     //   2266: iconst_0/*      */     //   2267: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2270: ifnull +9 -> 2279/*      */     //   2273: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2276: goto +12 -> 2288/*      */     //   2279: ldc 93/*      */     //   2281: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2284: dup/*      */     //   2285: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2288: aastore/*      */     //   2289: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2292: putstatic 238	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getList_46	Ljava/lang/reflect/Method;/*      */     //   2295: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2298: ifnull +9 -> 2307/*      */     //   2301: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2304: goto +12 -> 2316/*      */     //   2307: ldc 102/*      */     //   2309: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2312: dup/*      */     //   2313: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2316: ldc 48/*      */     //   2318: iconst_1/*      */     //   2319: anewarray 154	java/lang/Class/*      */     //   2322: dup/*      */     //   2323: iconst_0/*      */     //   2324: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2327: ifnull +9 -> 2336/*      */     //   2330: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2333: goto +12 -> 2345/*      */     //   2336: ldc 93/*      */     //   2338: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2341: dup/*      */     //   2342: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2345: aastore/*      */     //   2346: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2349: putstatic 239	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getLong_47	Ljava/lang/reflect/Method;/*      */     //   2352: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2355: ifnull +9 -> 2364/*      */     //   2358: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2361: goto +12 -> 2373/*      */     //   2364: ldc 102/*      */     //   2366: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2369: dup/*      */     //   2370: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2373: ldc 49/*      */     //   2375: iconst_0/*      */     //   2376: anewarray 154	java/lang/Class/*      */     //   2379: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2382: putstatic 240	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMXTransaction_48	Ljava/lang/reflect/Method;/*      */     //   2385: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2388: ifnull +9 -> 2397/*      */     //   2391: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2394: goto +12 -> 2406/*      */     //   2397: ldc 102/*      */     //   2399: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2402: dup/*      */     //   2403: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2406: ldc 50/*      */     //   2408: iconst_1/*      */     //   2409: anewarray 154	java/lang/Class/*      */     //   2412: dup/*      */     //   2413: iconst_0/*      */     //   2414: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2417: ifnull +9 -> 2426/*      */     //   2420: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2423: goto +12 -> 2435/*      */     //   2426: ldc 93/*      */     //   2428: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2431: dup/*      */     //   2432: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2435: aastore/*      */     //   2436: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2439: putstatic 241	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMatchingAttr_49	Ljava/lang/reflect/Method;/*      */     //   2442: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2445: ifnull +9 -> 2454/*      */     //   2448: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2451: goto +12 -> 2463/*      */     //   2454: ldc 102/*      */     //   2456: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2459: dup/*      */     //   2460: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2463: ldc 50/*      */     //   2465: iconst_2/*      */     //   2466: anewarray 154	java/lang/Class/*      */     //   2469: dup/*      */     //   2470: iconst_0/*      */     //   2471: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2474: ifnull +9 -> 2483/*      */     //   2477: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2480: goto +12 -> 2492/*      */     //   2483: ldc 93/*      */     //   2485: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2488: dup/*      */     //   2489: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2492: aastore/*      */     //   2493: dup/*      */     //   2494: iconst_1/*      */     //   2495: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2498: ifnull +9 -> 2507/*      */     //   2501: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2504: goto +12 -> 2516/*      */     //   2507: ldc 93/*      */     //   2509: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2512: dup/*      */     //   2513: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2516: aastore/*      */     //   2517: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2520: putstatic 242	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMatchingAttr_50	Ljava/lang/reflect/Method;/*      */     //   2523: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2526: ifnull +9 -> 2535/*      */     //   2529: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2532: goto +12 -> 2544/*      */     //   2535: ldc 102/*      */     //   2537: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2540: dup/*      */     //   2541: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2544: ldc 51/*      */     //   2546: iconst_2/*      */     //   2547: anewarray 154	java/lang/Class/*      */     //   2550: dup/*      */     //   2551: iconst_0/*      */     //   2552: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2555: ifnull +9 -> 2564/*      */     //   2558: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2561: goto +12 -> 2573/*      */     //   2564: ldc 93/*      */     //   2566: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2569: dup/*      */     //   2570: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2573: aastore/*      */     //   2574: dup/*      */     //   2575: iconst_1/*      */     //   2576: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2579: ifnull +9 -> 2588/*      */     //   2582: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2585: goto +12 -> 2597/*      */     //   2588: ldc 93/*      */     //   2590: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2593: dup/*      */     //   2594: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2597: aastore/*      */     //   2598: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2601: putstatic 243	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMatchingAttrs_51	Ljava/lang/reflect/Method;/*      */     //   2604: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2607: ifnull +9 -> 2616/*      */     //   2610: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2613: goto +12 -> 2625/*      */     //   2616: ldc 102/*      */     //   2618: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2621: dup/*      */     //   2622: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2625: ldc 52/*      */     //   2627: iconst_2/*      */     //   2628: anewarray 154	java/lang/Class/*      */     //   2631: dup/*      */     //   2632: iconst_0/*      */     //   2633: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2636: ifnull +9 -> 2645/*      */     //   2639: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2642: goto +12 -> 2654/*      */     //   2645: ldc 93/*      */     //   2647: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2650: dup/*      */     //   2651: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2654: aastore/*      */     //   2655: dup/*      */     //   2656: iconst_1/*      */     //   2657: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2660: ifnull +9 -> 2669/*      */     //   2663: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2666: goto +12 -> 2678/*      */     //   2669: ldc 93/*      */     //   2671: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2674: dup/*      */     //   2675: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2678: aastore/*      */     //   2679: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2682: putstatic 244	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMaxMessage_52	Ljava/lang/reflect/Method;/*      */     //   2685: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2688: ifnull +9 -> 2697/*      */     //   2691: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2694: goto +12 -> 2706/*      */     //   2697: ldc 102/*      */     //   2699: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2702: dup/*      */     //   2703: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2706: ldc 53/*      */     //   2708: iconst_1/*      */     //   2709: anewarray 154	java/lang/Class/*      */     //   2712: dup/*      */     //   2713: iconst_0/*      */     //   2714: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   2717: ifnull +9 -> 2726/*      */     //   2720: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   2723: goto +12 -> 2735/*      */     //   2726: ldc 3/*      */     //   2728: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2731: dup/*      */     //   2732: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   2735: aastore/*      */     //   2736: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2739: putstatic 246	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboData_53	Ljava/lang/reflect/Method;/*      */     //   2742: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2745: ifnull +9 -> 2754/*      */     //   2748: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2751: goto +12 -> 2763/*      */     //   2754: ldc 102/*      */     //   2756: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2759: dup/*      */     //   2760: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2763: ldc 54/*      */     //   2765: iconst_1/*      */     //   2766: anewarray 154	java/lang/Class/*      */     //   2769: dup/*      */     //   2770: iconst_0/*      */     //   2771: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2774: ifnull +9 -> 2783/*      */     //   2777: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2780: goto +12 -> 2792/*      */     //   2783: ldc 93/*      */     //   2785: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2788: dup/*      */     //   2789: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2792: aastore/*      */     //   2793: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2796: putstatic 245	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboDataSet_54	Ljava/lang/reflect/Method;/*      */     //   2799: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2802: ifnull +9 -> 2811/*      */     //   2805: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2808: goto +12 -> 2820/*      */     //   2811: ldc 102/*      */     //   2813: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2816: dup/*      */     //   2817: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2820: ldc 55/*      */     //   2822: iconst_1/*      */     //   2823: anewarray 154	java/lang/Class/*      */     //   2826: dup/*      */     //   2827: iconst_0/*      */     //   2828: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2831: ifnull +9 -> 2840/*      */     //   2834: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2837: goto +12 -> 2849/*      */     //   2840: ldc 93/*      */     //   2842: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2845: dup/*      */     //   2846: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2849: aastore/*      */     //   2850: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2853: putstatic 247	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboInitialValue_55	Ljava/lang/reflect/Method;/*      */     //   2856: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2859: ifnull +9 -> 2868/*      */     //   2862: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2865: goto +12 -> 2877/*      */     //   2868: ldc 102/*      */     //   2870: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2873: dup/*      */     //   2874: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2877: ldc 56/*      */     //   2879: iconst_1/*      */     //   2880: anewarray 154	java/lang/Class/*      */     //   2883: dup/*      */     //   2884: iconst_0/*      */     //   2885: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2888: ifnull +9 -> 2897/*      */     //   2891: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2894: goto +12 -> 2906/*      */     //   2897: ldc 93/*      */     //   2899: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2902: dup/*      */     //   2903: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2906: aastore/*      */     //   2907: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2910: putstatic 248	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboList_56	Ljava/lang/reflect/Method;/*      */     //   2913: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2916: ifnull +9 -> 2925/*      */     //   2919: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2922: goto +12 -> 2934/*      */     //   2925: ldc 102/*      */     //   2927: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2930: dup/*      */     //   2931: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2934: ldc 57/*      */     //   2936: iconst_1/*      */     //   2937: anewarray 154	java/lang/Class/*      */     //   2940: dup/*      */     //   2941: iconst_0/*      */     //   2942: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2945: ifnull +9 -> 2954/*      */     //   2948: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2951: goto +12 -> 2963/*      */     //   2954: ldc 93/*      */     //   2956: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2959: dup/*      */     //   2960: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   2963: aastore/*      */     //   2964: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   2967: putstatic 249	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboSet_57	Ljava/lang/reflect/Method;/*      */     //   2970: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2973: ifnull +9 -> 2982/*      */     //   2976: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2979: goto +12 -> 2991/*      */     //   2982: ldc 102/*      */     //   2984: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   2987: dup/*      */     //   2988: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   2991: ldc 57/*      */     //   2993: iconst_2/*      */     //   2994: anewarray 154	java/lang/Class/*      */     //   2997: dup/*      */     //   2998: iconst_0/*      */     //   2999: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3002: ifnull +9 -> 3011/*      */     //   3005: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3008: goto +12 -> 3020/*      */     //   3011: ldc 93/*      */     //   3013: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3016: dup/*      */     //   3017: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3020: aastore/*      */     //   3021: dup/*      */     //   3022: iconst_1/*      */     //   3023: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3026: ifnull +9 -> 3035/*      */     //   3029: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3032: goto +12 -> 3044/*      */     //   3035: ldc 93/*      */     //   3037: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3040: dup/*      */     //   3041: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3044: aastore/*      */     //   3045: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3048: putstatic 250	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboSet_58	Ljava/lang/reflect/Method;/*      */     //   3051: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3054: ifnull +9 -> 3063/*      */     //   3057: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3060: goto +12 -> 3072/*      */     //   3063: ldc 102/*      */     //   3065: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3068: dup/*      */     //   3069: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3072: ldc 57/*      */     //   3074: iconst_3/*      */     //   3075: anewarray 154	java/lang/Class/*      */     //   3078: dup/*      */     //   3079: iconst_0/*      */     //   3080: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3083: ifnull +9 -> 3092/*      */     //   3086: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3089: goto +12 -> 3101/*      */     //   3092: ldc 93/*      */     //   3094: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3097: dup/*      */     //   3098: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3101: aastore/*      */     //   3102: dup/*      */     //   3103: iconst_1/*      */     //   3104: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3107: ifnull +9 -> 3116/*      */     //   3110: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3113: goto +12 -> 3125/*      */     //   3116: ldc 93/*      */     //   3118: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3121: dup/*      */     //   3122: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3125: aastore/*      */     //   3126: dup/*      */     //   3127: iconst_2/*      */     //   3128: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3131: ifnull +9 -> 3140/*      */     //   3134: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3137: goto +12 -> 3149/*      */     //   3140: ldc 93/*      */     //   3142: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3145: dup/*      */     //   3146: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3149: aastore/*      */     //   3150: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3153: putstatic 251	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboSet_59	Ljava/lang/reflect/Method;/*      */     //   3156: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3159: ifnull +9 -> 3168/*      */     //   3162: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3165: goto +12 -> 3177/*      */     //   3168: ldc 102/*      */     //   3170: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3173: dup/*      */     //   3174: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3177: ldc 58/*      */     //   3179: iconst_1/*      */     //   3180: anewarray 154	java/lang/Class/*      */     //   3183: dup/*      */     //   3184: iconst_0/*      */     //   3185: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3188: ifnull +9 -> 3197/*      */     //   3191: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3194: goto +12 -> 3206/*      */     //   3197: ldc 93/*      */     //   3199: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3202: dup/*      */     //   3203: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3206: aastore/*      */     //   3207: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3210: putstatic 252	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboValueData_60	Ljava/lang/reflect/Method;/*      */     //   3213: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3216: ifnull +9 -> 3225/*      */     //   3219: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3222: goto +12 -> 3234/*      */     //   3225: ldc 102/*      */     //   3227: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3230: dup/*      */     //   3231: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3234: ldc 58/*      */     //   3236: iconst_2/*      */     //   3237: anewarray 154	java/lang/Class/*      */     //   3240: dup/*      */     //   3241: iconst_0/*      */     //   3242: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3245: ifnull +9 -> 3254/*      */     //   3248: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3251: goto +12 -> 3263/*      */     //   3254: ldc 93/*      */     //   3256: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3259: dup/*      */     //   3260: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3263: aastore/*      */     //   3264: dup/*      */     //   3265: iconst_1/*      */     //   3266: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   3269: aastore/*      */     //   3270: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3273: putstatic 253	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboValueData_61	Ljava/lang/reflect/Method;/*      */     //   3276: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3279: ifnull +9 -> 3288/*      */     //   3282: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3285: goto +12 -> 3297/*      */     //   3288: ldc 102/*      */     //   3290: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3293: dup/*      */     //   3294: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3297: ldc 58/*      */     //   3299: iconst_1/*      */     //   3300: anewarray 154	java/lang/Class/*      */     //   3303: dup/*      */     //   3304: iconst_0/*      */     //   3305: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   3308: ifnull +9 -> 3317/*      */     //   3311: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   3314: goto +12 -> 3326/*      */     //   3317: ldc 3/*      */     //   3319: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3322: dup/*      */     //   3323: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   3326: aastore/*      */     //   3327: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3330: putstatic 254	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboValueData_62	Ljava/lang/reflect/Method;/*      */     //   3333: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3336: ifnull +9 -> 3345/*      */     //   3339: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3342: goto +12 -> 3354/*      */     //   3345: ldc 102/*      */     //   3347: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3350: dup/*      */     //   3351: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3354: ldc 59/*      */     //   3356: iconst_1/*      */     //   3357: anewarray 154	java/lang/Class/*      */     //   3360: dup/*      */     //   3361: iconst_0/*      */     //   3362: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3365: ifnull +9 -> 3374/*      */     //   3368: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3371: goto +12 -> 3383/*      */     //   3374: ldc 93/*      */     //   3376: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3379: dup/*      */     //   3380: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3383: aastore/*      */     //   3384: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3387: putstatic 255	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboValueInfoStatic_63	Ljava/lang/reflect/Method;/*      */     //   3390: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3393: ifnull +9 -> 3402/*      */     //   3396: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3399: goto +12 -> 3411/*      */     //   3402: ldc 102/*      */     //   3404: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3407: dup/*      */     //   3408: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3411: ldc 59/*      */     //   3413: iconst_1/*      */     //   3414: anewarray 154	java/lang/Class/*      */     //   3417: dup/*      */     //   3418: iconst_0/*      */     //   3419: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   3422: ifnull +9 -> 3431/*      */     //   3425: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   3428: goto +12 -> 3440/*      */     //   3431: ldc 3/*      */     //   3433: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3436: dup/*      */     //   3437: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   3440: aastore/*      */     //   3441: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3444: putstatic 256	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMboValueInfoStatic_64	Ljava/lang/reflect/Method;/*      */     //   3447: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3450: ifnull +9 -> 3459/*      */     //   3453: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3456: goto +12 -> 3468/*      */     //   3459: ldc 102/*      */     //   3461: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3464: dup/*      */     //   3465: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3468: ldc 60/*      */     //   3470: iconst_2/*      */     //   3471: anewarray 154	java/lang/Class/*      */     //   3474: dup/*      */     //   3475: iconst_0/*      */     //   3476: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3479: ifnull +9 -> 3488/*      */     //   3482: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3485: goto +12 -> 3497/*      */     //   3488: ldc 93/*      */     //   3490: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3493: dup/*      */     //   3494: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3497: aastore/*      */     //   3498: dup/*      */     //   3499: iconst_1/*      */     //   3500: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3503: ifnull +9 -> 3512/*      */     //   3506: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3509: goto +12 -> 3521/*      */     //   3512: ldc 93/*      */     //   3514: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3517: dup/*      */     //   3518: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3521: aastore/*      */     //   3522: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3525: putstatic 257	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMessage_65	Ljava/lang/reflect/Method;/*      */     //   3528: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3531: ifnull +9 -> 3540/*      */     //   3534: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3537: goto +12 -> 3549/*      */     //   3540: ldc 102/*      */     //   3542: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3545: dup/*      */     //   3546: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3549: ldc 60/*      */     //   3551: iconst_3/*      */     //   3552: anewarray 154	java/lang/Class/*      */     //   3555: dup/*      */     //   3556: iconst_0/*      */     //   3557: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3560: ifnull +9 -> 3569/*      */     //   3563: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3566: goto +12 -> 3578/*      */     //   3569: ldc 93/*      */     //   3571: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3574: dup/*      */     //   3575: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3578: aastore/*      */     //   3579: dup/*      */     //   3580: iconst_1/*      */     //   3581: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3584: ifnull +9 -> 3593/*      */     //   3587: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3590: goto +12 -> 3602/*      */     //   3593: ldc 93/*      */     //   3595: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3598: dup/*      */     //   3599: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3602: aastore/*      */     //   3603: dup/*      */     //   3604: iconst_2/*      */     //   3605: getstatic 393	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$Object	Ljava/lang/Class;/*      */     //   3608: ifnull +9 -> 3617/*      */     //   3611: getstatic 393	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$Object	Ljava/lang/Class;/*      */     //   3614: goto +12 -> 3626/*      */     //   3617: ldc 92/*      */     //   3619: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3622: dup/*      */     //   3623: putstatic 393	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$Object	Ljava/lang/Class;/*      */     //   3626: aastore/*      */     //   3627: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3630: putstatic 258	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMessage_66	Ljava/lang/reflect/Method;/*      */     //   3633: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3636: ifnull +9 -> 3645/*      */     //   3639: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3642: goto +12 -> 3654/*      */     //   3645: ldc 102/*      */     //   3647: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3650: dup/*      */     //   3651: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3654: ldc 60/*      */     //   3656: iconst_3/*      */     //   3657: anewarray 154	java/lang/Class/*      */     //   3660: dup/*      */     //   3661: iconst_0/*      */     //   3662: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3665: ifnull +9 -> 3674/*      */     //   3668: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3671: goto +12 -> 3683/*      */     //   3674: ldc 93/*      */     //   3676: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3679: dup/*      */     //   3680: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3683: aastore/*      */     //   3684: dup/*      */     //   3685: iconst_1/*      */     //   3686: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3689: ifnull +9 -> 3698/*      */     //   3692: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3695: goto +12 -> 3707/*      */     //   3698: ldc 93/*      */     //   3700: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3703: dup/*      */     //   3704: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3707: aastore/*      */     //   3708: dup/*      */     //   3709: iconst_2/*      */     //   3710: getstatic 387	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$Object	Ljava/lang/Class;/*      */     //   3713: ifnull +9 -> 3722/*      */     //   3716: getstatic 387	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$Object	Ljava/lang/Class;/*      */     //   3719: goto +12 -> 3731/*      */     //   3722: ldc 2/*      */     //   3724: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3727: dup/*      */     //   3728: putstatic 387	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$Object	Ljava/lang/Class;/*      */     //   3731: aastore/*      */     //   3732: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3735: putstatic 259	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMessage_67	Ljava/lang/reflect/Method;/*      */     //   3738: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3741: ifnull +9 -> 3750/*      */     //   3744: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3747: goto +12 -> 3759/*      */     //   3750: ldc 102/*      */     //   3752: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3755: dup/*      */     //   3756: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3759: ldc 60/*      */     //   3761: iconst_1/*      */     //   3762: anewarray 154	java/lang/Class/*      */     //   3765: dup/*      */     //   3766: iconst_0/*      */     //   3767: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   3770: ifnull +9 -> 3779/*      */     //   3773: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   3776: goto +12 -> 3788/*      */     //   3779: ldc 105/*      */     //   3781: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3784: dup/*      */     //   3785: putstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   3788: aastore/*      */     //   3789: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3792: putstatic 260	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getMessage_68	Ljava/lang/reflect/Method;/*      */     //   3795: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3798: ifnull +9 -> 3807/*      */     //   3801: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3804: goto +12 -> 3816/*      */     //   3807: ldc 102/*      */     //   3809: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3812: dup/*      */     //   3813: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3816: ldc 61/*      */     //   3818: iconst_0/*      */     //   3819: anewarray 154	java/lang/Class/*      */     //   3822: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3825: putstatic 261	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getName_69	Ljava/lang/reflect/Method;/*      */     //   3828: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3831: ifnull +9 -> 3840/*      */     //   3834: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3837: goto +12 -> 3849/*      */     //   3840: ldc 102/*      */     //   3842: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3845: dup/*      */     //   3846: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3849: ldc 62/*      */     //   3851: iconst_1/*      */     //   3852: anewarray 154	java/lang/Class/*      */     //   3855: dup/*      */     //   3856: iconst_0/*      */     //   3857: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3860: ifnull +9 -> 3869/*      */     //   3863: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3866: goto +12 -> 3878/*      */     //   3869: ldc 93/*      */     //   3871: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3874: dup/*      */     //   3875: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3878: aastore/*      */     //   3879: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3882: putstatic 262	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getOrgForGL_70	Ljava/lang/reflect/Method;/*      */     //   3885: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3888: ifnull +9 -> 3897/*      */     //   3891: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3894: goto +12 -> 3906/*      */     //   3897: ldc 102/*      */     //   3899: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3902: dup/*      */     //   3903: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3906: ldc 63/*      */     //   3908: iconst_1/*      */     //   3909: anewarray 154	java/lang/Class/*      */     //   3912: dup/*      */     //   3913: iconst_0/*      */     //   3914: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3917: ifnull +9 -> 3926/*      */     //   3920: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3923: goto +12 -> 3935/*      */     //   3926: ldc 93/*      */     //   3928: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3931: dup/*      */     //   3932: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   3935: aastore/*      */     //   3936: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3939: putstatic 263	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getOrgSiteForMaxvar_71	Ljava/lang/reflect/Method;/*      */     //   3942: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3945: ifnull +9 -> 3954/*      */     //   3948: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3951: goto +12 -> 3963/*      */     //   3954: ldc 102/*      */     //   3956: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3959: dup/*      */     //   3960: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3963: ldc 64/*      */     //   3965: iconst_0/*      */     //   3966: anewarray 154	java/lang/Class/*      */     //   3969: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   3972: putstatic 264	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getOwner_72	Ljava/lang/reflect/Method;/*      */     //   3975: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3978: ifnull +9 -> 3987/*      */     //   3981: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3984: goto +12 -> 3996/*      */     //   3987: ldc 102/*      */     //   3989: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   3992: dup/*      */     //   3993: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   3996: ldc 65/*      */     //   3998: iconst_0/*      */     //   3999: anewarray 154	java/lang/Class/*      */     //   4002: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4005: putstatic 265	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getPropagateKeyFlag_73	Ljava/lang/reflect/Method;/*      */     //   4008: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4011: ifnull +9 -> 4020/*      */     //   4014: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4017: goto +12 -> 4029/*      */     //   4020: ldc 102/*      */     //   4022: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4025: dup/*      */     //   4026: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4029: ldc 66/*      */     //   4031: iconst_0/*      */     //   4032: anewarray 154	java/lang/Class/*      */     //   4035: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4038: putstatic 266	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getRecordIdentifer_74	Ljava/lang/reflect/Method;/*      */     //   4041: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4044: ifnull +9 -> 4053/*      */     //   4047: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4050: goto +12 -> 4062/*      */     //   4053: ldc 102/*      */     //   4055: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4058: dup/*      */     //   4059: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4062: ldc 67/*      */     //   4064: iconst_0/*      */     //   4065: anewarray 154	java/lang/Class/*      */     //   4068: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4071: putstatic 267	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getSiteOrg_75	Ljava/lang/reflect/Method;/*      */     //   4074: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4077: ifnull +9 -> 4086/*      */     //   4080: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4083: goto +12 -> 4095/*      */     //   4086: ldc 102/*      */     //   4088: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4091: dup/*      */     //   4092: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4095: ldc 68/*      */     //   4097: iconst_1/*      */     //   4098: anewarray 154	java/lang/Class/*      */     //   4101: dup/*      */     //   4102: iconst_0/*      */     //   4103: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4106: ifnull +9 -> 4115/*      */     //   4109: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4112: goto +12 -> 4124/*      */     //   4115: ldc 93/*      */     //   4117: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4120: dup/*      */     //   4121: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4124: aastore/*      */     //   4125: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4128: putstatic 271	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getString_76	Ljava/lang/reflect/Method;/*      */     //   4131: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4134: ifnull +9 -> 4143/*      */     //   4137: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4140: goto +12 -> 4152/*      */     //   4143: ldc 102/*      */     //   4145: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4148: dup/*      */     //   4149: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4152: ldc 68/*      */     //   4154: iconst_2/*      */     //   4155: anewarray 154	java/lang/Class/*      */     //   4158: dup/*      */     //   4159: iconst_0/*      */     //   4160: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4163: ifnull +9 -> 4172/*      */     //   4166: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4169: goto +12 -> 4181/*      */     //   4172: ldc 93/*      */     //   4174: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4177: dup/*      */     //   4178: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4181: aastore/*      */     //   4182: dup/*      */     //   4183: iconst_1/*      */     //   4184: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4187: ifnull +9 -> 4196/*      */     //   4190: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4193: goto +12 -> 4205/*      */     //   4196: ldc 93/*      */     //   4198: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4201: dup/*      */     //   4202: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4205: aastore/*      */     //   4206: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4209: putstatic 272	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getString_77	Ljava/lang/reflect/Method;/*      */     //   4212: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4215: ifnull +9 -> 4224/*      */     //   4218: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4221: goto +12 -> 4233/*      */     //   4224: ldc 102/*      */     //   4226: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4229: dup/*      */     //   4230: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4233: ldc 69/*      */     //   4235: iconst_1/*      */     //   4236: anewarray 154	java/lang/Class/*      */     //   4239: dup/*      */     //   4240: iconst_0/*      */     //   4241: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4244: ifnull +9 -> 4253/*      */     //   4247: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4250: goto +12 -> 4262/*      */     //   4253: ldc 93/*      */     //   4255: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4258: dup/*      */     //   4259: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4262: aastore/*      */     //   4263: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4266: putstatic 268	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getStringInBaseLanguage_78	Ljava/lang/reflect/Method;/*      */     //   4269: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4272: ifnull +9 -> 4281/*      */     //   4275: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4278: goto +12 -> 4290/*      */     //   4281: ldc 102/*      */     //   4283: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4286: dup/*      */     //   4287: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4290: ldc 70/*      */     //   4292: iconst_3/*      */     //   4293: anewarray 154	java/lang/Class/*      */     //   4296: dup/*      */     //   4297: iconst_0/*      */     //   4298: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4301: ifnull +9 -> 4310/*      */     //   4304: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4307: goto +12 -> 4319/*      */     //   4310: ldc 93/*      */     //   4312: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4315: dup/*      */     //   4316: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4319: aastore/*      */     //   4320: dup/*      */     //   4321: iconst_1/*      */     //   4322: getstatic 397	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Locale	Ljava/lang/Class;/*      */     //   4325: ifnull +9 -> 4334/*      */     //   4328: getstatic 397	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Locale	Ljava/lang/Class;/*      */     //   4331: goto +12 -> 4343/*      */     //   4334: ldc 96/*      */     //   4336: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4339: dup/*      */     //   4340: putstatic 397	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Locale	Ljava/lang/Class;/*      */     //   4343: aastore/*      */     //   4344: dup/*      */     //   4345: iconst_2/*      */     //   4346: getstatic 399	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$TimeZone	Ljava/lang/Class;/*      */     //   4349: ifnull +9 -> 4358/*      */     //   4352: getstatic 399	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$TimeZone	Ljava/lang/Class;/*      */     //   4355: goto +12 -> 4367/*      */     //   4358: ldc 98/*      */     //   4360: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4363: dup/*      */     //   4364: putstatic 399	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$TimeZone	Ljava/lang/Class;/*      */     //   4367: aastore/*      */     //   4368: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4371: putstatic 269	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getStringInSpecificLocale_79	Ljava/lang/reflect/Method;/*      */     //   4374: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4377: ifnull +9 -> 4386/*      */     //   4380: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4383: goto +12 -> 4395/*      */     //   4386: ldc 102/*      */     //   4388: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4391: dup/*      */     //   4392: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4395: ldc 71/*      */     //   4397: iconst_2/*      */     //   4398: anewarray 154	java/lang/Class/*      */     //   4401: dup/*      */     //   4402: iconst_0/*      */     //   4403: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4406: ifnull +9 -> 4415/*      */     //   4409: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4412: goto +12 -> 4424/*      */     //   4415: ldc 93/*      */     //   4417: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4420: dup/*      */     //   4421: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4424: aastore/*      */     //   4425: dup/*      */     //   4426: iconst_1/*      */     //   4427: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4430: ifnull +9 -> 4439/*      */     //   4433: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4436: goto +12 -> 4448/*      */     //   4439: ldc 93/*      */     //   4441: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4444: dup/*      */     //   4445: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4448: aastore/*      */     //   4449: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4452: putstatic 270	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getStringTransparent_80	Ljava/lang/reflect/Method;/*      */     //   4455: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4458: ifnull +9 -> 4467/*      */     //   4461: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4464: goto +12 -> 4476/*      */     //   4467: ldc 102/*      */     //   4469: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4472: dup/*      */     //   4473: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4476: ldc 72/*      */     //   4478: iconst_0/*      */     //   4479: anewarray 154	java/lang/Class/*      */     //   4482: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4485: putstatic 273	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getThisMboSet_81	Ljava/lang/reflect/Method;/*      */     //   4488: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4491: ifnull +9 -> 4500/*      */     //   4494: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4497: goto +12 -> 4509/*      */     //   4500: ldc 102/*      */     //   4502: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4505: dup/*      */     //   4506: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4509: ldc 73/*      */     //   4511: iconst_0/*      */     //   4512: anewarray 154	java/lang/Class/*      */     //   4515: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4518: putstatic 274	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getUniqueIDName_82	Ljava/lang/reflect/Method;/*      */     //   4521: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4524: ifnull +9 -> 4533/*      */     //   4527: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4530: goto +12 -> 4542/*      */     //   4533: ldc 102/*      */     //   4535: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4538: dup/*      */     //   4539: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4542: ldc 74/*      */     //   4544: iconst_0/*      */     //   4545: anewarray 154	java/lang/Class/*      */     //   4548: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4551: putstatic 275	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getUniqueIDValue_83	Ljava/lang/reflect/Method;/*      */     //   4554: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4557: ifnull +9 -> 4566/*      */     //   4560: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4563: goto +12 -> 4575/*      */     //   4566: ldc 102/*      */     //   4568: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4571: dup/*      */     //   4572: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4575: ldc 75/*      */     //   4577: iconst_0/*      */     //   4578: anewarray 154	java/lang/Class/*      */     //   4581: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4584: putstatic 276	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getUserInfo_84	Ljava/lang/reflect/Method;/*      */     //   4587: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4590: ifnull +9 -> 4599/*      */     //   4593: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4596: goto +12 -> 4608/*      */     //   4599: ldc 102/*      */     //   4601: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4604: dup/*      */     //   4605: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4608: ldc 76/*      */     //   4610: iconst_0/*      */     //   4611: anewarray 154	java/lang/Class/*      */     //   4614: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4617: putstatic 277	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_getUserName_85	Ljava/lang/reflect/Method;/*      */     //   4620: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4623: ifnull +9 -> 4632/*      */     //   4626: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4629: goto +12 -> 4641/*      */     //   4632: ldc 102/*      */     //   4634: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4637: dup/*      */     //   4638: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4641: ldc 77/*      */     //   4643: iconst_0/*      */     //   4644: anewarray 154	java/lang/Class/*      */     //   4647: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4650: putstatic 278	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_hasHierarchyLink_86	Ljava/lang/reflect/Method;/*      */     //   4653: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4656: ifnull +9 -> 4665/*      */     //   4659: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4662: goto +12 -> 4674/*      */     //   4665: ldc 11/*      */     //   4667: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4670: dup/*      */     //   4671: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4674: ldc 78/*      */     //   4676: iconst_0/*      */     //   4677: anewarray 154	java/lang/Class/*      */     //   4680: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4683: putstatic 279	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_installContent_87	Ljava/lang/reflect/Method;/*      */     //   4686: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4689: ifnull +9 -> 4698/*      */     //   4692: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4695: goto +12 -> 4707/*      */     //   4698: ldc 102/*      */     //   4700: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4703: dup/*      */     //   4704: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4707: ldc 79/*      */     //   4709: iconst_1/*      */     //   4710: anewarray 154	java/lang/Class/*      */     //   4713: dup/*      */     //   4714: iconst_0/*      */     //   4715: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4718: ifnull +9 -> 4727/*      */     //   4721: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4724: goto +12 -> 4736/*      */     //   4727: ldc 93/*      */     //   4729: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4732: dup/*      */     //   4733: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4736: aastore/*      */     //   4737: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4740: putstatic 280	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isAutoKeyed_88	Ljava/lang/reflect/Method;/*      */     //   4743: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4746: ifnull +9 -> 4755/*      */     //   4749: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4752: goto +12 -> 4764/*      */     //   4755: ldc 102/*      */     //   4757: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4760: dup/*      */     //   4761: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4764: ldc 80/*      */     //   4766: iconst_1/*      */     //   4767: anewarray 154	java/lang/Class/*      */     //   4770: dup/*      */     //   4771: iconst_0/*      */     //   4772: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4775: ifnull +9 -> 4784/*      */     //   4778: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4781: goto +12 -> 4793/*      */     //   4784: ldc 93/*      */     //   4786: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4789: dup/*      */     //   4790: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   4793: aastore/*      */     //   4794: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4797: putstatic 281	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isBasedOn_89	Ljava/lang/reflect/Method;/*      */     //   4800: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4803: ifnull +9 -> 4812/*      */     //   4806: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4809: goto +12 -> 4821/*      */     //   4812: ldc 11/*      */     //   4814: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4817: dup/*      */     //   4818: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4821: ldc 81/*      */     //   4823: iconst_0/*      */     //   4824: anewarray 154	java/lang/Class/*      */     //   4827: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4830: putstatic 282	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isDownloadComplete_90	Ljava/lang/reflect/Method;/*      */     //   4833: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4836: ifnull +9 -> 4845/*      */     //   4839: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4842: goto +12 -> 4854/*      */     //   4845: ldc 11/*      */     //   4847: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4850: dup/*      */     //   4851: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4854: ldc 82/*      */     //   4856: iconst_0/*      */     //   4857: anewarray 154	java/lang/Class/*      */     //   4860: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4863: putstatic 283	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isDownloadFailed_91	Ljava/lang/reflect/Method;/*      */     //   4866: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4869: ifnull +9 -> 4878/*      */     //   4872: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4875: goto +12 -> 4887/*      */     //   4878: ldc 102/*      */     //   4880: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4883: dup/*      */     //   4884: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4887: ldc 83/*      */     //   4889: iconst_1/*      */     //   4890: anewarray 154	java/lang/Class/*      */     //   4893: dup/*      */     //   4894: iconst_0/*      */     //   4895: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   4898: aastore/*      */     //   4899: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4902: putstatic 284	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isFlagSet_92	Ljava/lang/reflect/Method;/*      */     //   4905: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4908: ifnull +9 -> 4917/*      */     //   4911: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4914: goto +12 -> 4926/*      */     //   4917: ldc 102/*      */     //   4919: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4922: dup/*      */     //   4923: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   4926: ldc 84/*      */     //   4928: iconst_0/*      */     //   4929: anewarray 154	java/lang/Class/*      */     //   4932: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4935: putstatic 285	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isForDM_93	Ljava/lang/reflect/Method;/*      */     //   4938: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4941: ifnull +9 -> 4950/*      */     //   4944: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4947: goto +12 -> 4959/*      */     //   4950: ldc 11/*      */     //   4952: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4955: dup/*      */     //   4956: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4959: ldc 85/*      */     //   4961: iconst_0/*      */     //   4962: anewarray 154	java/lang/Class/*      */     //   4965: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   4968: putstatic 286	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isInstallComplete_94	Ljava/lang/reflect/Method;/*      */     //   4971: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4974: ifnull +9 -> 4983/*      */     //   4977: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4980: goto +12 -> 4992/*      */     //   4983: ldc 11/*      */     //   4985: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   4988: dup/*      */     //   4989: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   4992: ldc 86/*      */     //   4994: iconst_0/*      */     //   4995: anewarray 154	java/lang/Class/*      */     //   4998: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5001: putstatic 287	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isInstallFailed_95	Ljava/lang/reflect/Method;/*      */     //   5004: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5007: ifnull +9 -> 5016/*      */     //   5010: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5013: goto +12 -> 5025/*      */     //   5016: ldc 102/*      */     //   5018: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5021: dup/*      */     //   5022: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5025: ldc 87/*      */     //   5027: iconst_0/*      */     //   5028: anewarray 154	java/lang/Class/*      */     //   5031: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5034: putstatic 288	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isModified_96	Ljava/lang/reflect/Method;/*      */     //   5037: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5040: ifnull +9 -> 5049/*      */     //   5043: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5046: goto +12 -> 5058/*      */     //   5049: ldc 102/*      */     //   5051: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5054: dup/*      */     //   5055: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5058: ldc 87/*      */     //   5060: iconst_1/*      */     //   5061: anewarray 154	java/lang/Class/*      */     //   5064: dup/*      */     //   5065: iconst_0/*      */     //   5066: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5069: ifnull +9 -> 5078/*      */     //   5072: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5075: goto +12 -> 5087/*      */     //   5078: ldc 93/*      */     //   5080: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5083: dup/*      */     //   5084: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5087: aastore/*      */     //   5088: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5091: putstatic 289	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isModified_97	Ljava/lang/reflect/Method;/*      */     //   5094: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5097: ifnull +9 -> 5106/*      */     //   5100: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5103: goto +12 -> 5115/*      */     //   5106: ldc 102/*      */     //   5108: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5111: dup/*      */     //   5112: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5115: ldc 88/*      */     //   5117: iconst_0/*      */     //   5118: anewarray 154	java/lang/Class/*      */     //   5121: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5124: putstatic 290	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isNew_98	Ljava/lang/reflect/Method;/*      */     //   5127: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5130: ifnull +9 -> 5139/*      */     //   5133: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5136: goto +12 -> 5148/*      */     //   5139: ldc 102/*      */     //   5141: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5144: dup/*      */     //   5145: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5148: ldc 89/*      */     //   5150: iconst_1/*      */     //   5151: anewarray 154	java/lang/Class/*      */     //   5154: dup/*      */     //   5155: iconst_0/*      */     //   5156: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5159: ifnull +9 -> 5168/*      */     //   5162: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5165: goto +12 -> 5177/*      */     //   5168: ldc 93/*      */     //   5170: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5173: dup/*      */     //   5174: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5177: aastore/*      */     //   5178: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5181: putstatic 291	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isNull_99	Ljava/lang/reflect/Method;/*      */     //   5184: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5187: ifnull +9 -> 5196/*      */     //   5190: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5193: goto +12 -> 5205/*      */     //   5196: ldc 102/*      */     //   5198: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5201: dup/*      */     //   5202: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5205: ldc 90/*      */     //   5207: iconst_0/*      */     //   5208: anewarray 154	java/lang/Class/*      */     //   5211: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5214: putstatic 292	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isSelected_100	Ljava/lang/reflect/Method;/*      */     //   5217: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5220: ifnull +9 -> 5229/*      */     //   5223: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5226: goto +12 -> 5238/*      */     //   5229: ldc 102/*      */     //   5231: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5234: dup/*      */     //   5235: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5238: ldc 91/*      */     //   5240: iconst_0/*      */     //   5241: anewarray 154	java/lang/Class/*      */     //   5244: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5247: putstatic 293	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_isZombie_101	Ljava/lang/reflect/Method;/*      */     //   5250: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   5253: ifnull +9 -> 5262/*      */     //   5256: getstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   5259: goto +12 -> 5271/*      */     //   5262: ldc 11/*      */     //   5264: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5267: dup/*      */     //   5268: putstatic 392	com/ibm/ism/content/virtual/CatalogItem_Stub:class$com$ibm$ism$content$virtual$CatalogItemRemote	Ljava/lang/Class;/*      */     //   5271: ldc 99/*      */     //   5273: iconst_0/*      */     //   5274: anewarray 154	java/lang/Class/*      */     //   5277: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5280: putstatic 294	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_loadLicense_102	Ljava/lang/reflect/Method;/*      */     //   5283: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5286: ifnull +9 -> 5295/*      */     //   5289: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5292: goto +12 -> 5304/*      */     //   5295: ldc 102/*      */     //   5297: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5300: dup/*      */     //   5301: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5304: ldc 100/*      */     //   5306: iconst_2/*      */     //   5307: anewarray 154	java/lang/Class/*      */     //   5310: dup/*      */     //   5311: iconst_0/*      */     //   5312: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5315: ifnull +9 -> 5324/*      */     //   5318: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5321: goto +12 -> 5333/*      */     //   5324: ldc 93/*      */     //   5326: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5329: dup/*      */     //   5330: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5333: aastore/*      */     //   5334: dup/*      */     //   5335: iconst_1/*      */     //   5336: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5339: ifnull +9 -> 5348/*      */     //   5342: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5345: goto +12 -> 5357/*      */     //   5348: ldc 93/*      */     //   5350: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5353: dup/*      */     //   5354: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5357: aastore/*      */     //   5358: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5361: putstatic 295	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_propagateKeyValue_103	Ljava/lang/reflect/Method;/*      */     //   5364: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5367: ifnull +9 -> 5376/*      */     //   5370: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5373: goto +12 -> 5385/*      */     //   5376: ldc 102/*      */     //   5378: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5381: dup/*      */     //   5382: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5385: ldc 107/*      */     //   5387: iconst_0/*      */     //   5388: anewarray 154	java/lang/Class/*      */     //   5391: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5394: putstatic 296	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_rollbackToCheckpoint_104	Ljava/lang/reflect/Method;/*      */     //   5397: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5400: ifnull +9 -> 5409/*      */     //   5403: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5406: goto +12 -> 5418/*      */     //   5409: ldc 102/*      */     //   5411: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5414: dup/*      */     //   5415: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5418: ldc 108/*      */     //   5420: iconst_0/*      */     //   5421: anewarray 154	java/lang/Class/*      */     //   5424: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5427: putstatic 297	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_select_105	Ljava/lang/reflect/Method;/*      */     //   5430: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5433: ifnull +9 -> 5442/*      */     //   5436: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5439: goto +12 -> 5451/*      */     //   5442: ldc 102/*      */     //   5444: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5447: dup/*      */     //   5448: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5451: ldc 109/*      */     //   5453: iconst_2/*      */     //   5454: anewarray 154	java/lang/Class/*      */     //   5457: dup/*      */     //   5458: iconst_0/*      */     //   5459: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5462: ifnull +9 -> 5471/*      */     //   5465: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5468: goto +12 -> 5480/*      */     //   5471: ldc 93/*      */     //   5473: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5476: dup/*      */     //   5477: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5480: aastore/*      */     //   5481: dup/*      */     //   5482: iconst_1/*      */     //   5483: getstatic 403	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$ApplicationError	Ljava/lang/Class;/*      */     //   5486: ifnull +9 -> 5495/*      */     //   5489: getstatic 403	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$ApplicationError	Ljava/lang/Class;/*      */     //   5492: goto +12 -> 5504/*      */     //   5495: ldc 104/*      */     //   5497: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5500: dup/*      */     //   5501: putstatic 403	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$ApplicationError	Ljava/lang/Class;/*      */     //   5504: aastore/*      */     //   5505: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5508: putstatic 298	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setApplicationError_106	Ljava/lang/reflect/Method;/*      */     //   5511: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5514: ifnull +9 -> 5523/*      */     //   5517: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5520: goto +12 -> 5532/*      */     //   5523: ldc 102/*      */     //   5525: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5528: dup/*      */     //   5529: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5532: ldc 110/*      */     //   5534: iconst_2/*      */     //   5535: anewarray 154	java/lang/Class/*      */     //   5538: dup/*      */     //   5539: iconst_0/*      */     //   5540: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5543: ifnull +9 -> 5552/*      */     //   5546: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5549: goto +12 -> 5561/*      */     //   5552: ldc 93/*      */     //   5554: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5557: dup/*      */     //   5558: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5561: aastore/*      */     //   5562: dup/*      */     //   5563: iconst_1/*      */     //   5564: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   5567: aastore/*      */     //   5568: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5571: putstatic 299	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setApplicationRequired_107	Ljava/lang/reflect/Method;/*      */     //   5574: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5577: ifnull +9 -> 5586/*      */     //   5580: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5583: goto +12 -> 5595/*      */     //   5586: ldc 102/*      */     //   5588: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5591: dup/*      */     //   5592: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5595: ldc 111/*      */     //   5597: iconst_0/*      */     //   5598: anewarray 154	java/lang/Class/*      */     //   5601: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5604: putstatic 300	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setCopyDefaults_108	Ljava/lang/reflect/Method;/*      */     //   5607: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5610: ifnull +9 -> 5619/*      */     //   5613: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5616: goto +12 -> 5628/*      */     //   5619: ldc 102/*      */     //   5621: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5624: dup/*      */     //   5625: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5628: ldc 112/*      */     //   5630: iconst_1/*      */     //   5631: anewarray 154	java/lang/Class/*      */     //   5634: dup/*      */     //   5635: iconst_0/*      */     //   5636: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   5639: aastore/*      */     //   5640: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5643: putstatic 301	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setDeleted_109	Ljava/lang/reflect/Method;/*      */     //   5646: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5649: ifnull +9 -> 5658/*      */     //   5652: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5655: goto +12 -> 5667/*      */     //   5658: ldc 102/*      */     //   5660: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5663: dup/*      */     //   5664: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5667: ldc 113/*      */     //   5669: iconst_1/*      */     //   5670: anewarray 154	java/lang/Class/*      */     //   5673: dup/*      */     //   5674: iconst_0/*      */     //   5675: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   5678: aastore/*      */     //   5679: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5682: putstatic 302	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setESigFieldModified_110	Ljava/lang/reflect/Method;/*      */     //   5685: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5688: ifnull +9 -> 5697/*      */     //   5691: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5694: goto +12 -> 5706/*      */     //   5697: ldc 102/*      */     //   5699: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5702: dup/*      */     //   5703: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5706: ldc 114/*      */     //   5708: iconst_3/*      */     //   5709: anewarray 154	java/lang/Class/*      */     //   5712: dup/*      */     //   5713: iconst_0/*      */     //   5714: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5717: ifnull +9 -> 5726/*      */     //   5720: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5723: goto +12 -> 5735/*      */     //   5726: ldc 93/*      */     //   5728: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5731: dup/*      */     //   5732: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5735: aastore/*      */     //   5736: dup/*      */     //   5737: iconst_1/*      */     //   5738: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   5741: aastore/*      */     //   5742: dup/*      */     //   5743: iconst_2/*      */     //   5744: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   5747: aastore/*      */     //   5748: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5751: putstatic 303	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFieldFlag_111	Ljava/lang/reflect/Method;/*      */     //   5754: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5757: ifnull +9 -> 5766/*      */     //   5760: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5763: goto +12 -> 5775/*      */     //   5766: ldc 102/*      */     //   5768: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5771: dup/*      */     //   5772: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5775: ldc 114/*      */     //   5777: iconst_4/*      */     //   5778: anewarray 154	java/lang/Class/*      */     //   5781: dup/*      */     //   5782: iconst_0/*      */     //   5783: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5786: ifnull +9 -> 5795/*      */     //   5789: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5792: goto +12 -> 5804/*      */     //   5795: ldc 93/*      */     //   5797: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5800: dup/*      */     //   5801: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   5804: aastore/*      */     //   5805: dup/*      */     //   5806: iconst_1/*      */     //   5807: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   5810: aastore/*      */     //   5811: dup/*      */     //   5812: iconst_2/*      */     //   5813: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   5816: aastore/*      */     //   5817: dup/*      */     //   5818: iconst_3/*      */     //   5819: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   5822: ifnull +9 -> 5831/*      */     //   5825: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   5828: goto +12 -> 5840/*      */     //   5831: ldc 105/*      */     //   5833: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5836: dup/*      */     //   5837: putstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   5840: aastore/*      */     //   5841: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5844: putstatic 304	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFieldFlag_112	Ljava/lang/reflect/Method;/*      */     //   5847: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5850: ifnull +9 -> 5859/*      */     //   5853: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5856: goto +12 -> 5868/*      */     //   5859: ldc 102/*      */     //   5861: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5864: dup/*      */     //   5865: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5868: ldc 114/*      */     //   5870: iconst_3/*      */     //   5871: anewarray 154	java/lang/Class/*      */     //   5874: dup/*      */     //   5875: iconst_0/*      */     //   5876: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   5879: ifnull +9 -> 5888/*      */     //   5882: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   5885: goto +12 -> 5897/*      */     //   5888: ldc 3/*      */     //   5890: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5893: dup/*      */     //   5894: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   5897: aastore/*      */     //   5898: dup/*      */     //   5899: iconst_1/*      */     //   5900: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   5903: aastore/*      */     //   5904: dup/*      */     //   5905: iconst_2/*      */     //   5906: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   5909: aastore/*      */     //   5910: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   5913: putstatic 305	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFieldFlag_113	Ljava/lang/reflect/Method;/*      */     //   5916: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5919: ifnull +9 -> 5928/*      */     //   5922: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5925: goto +12 -> 5937/*      */     //   5928: ldc 102/*      */     //   5930: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5933: dup/*      */     //   5934: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   5937: ldc 114/*      */     //   5939: iconst_4/*      */     //   5940: anewarray 154	java/lang/Class/*      */     //   5943: dup/*      */     //   5944: iconst_0/*      */     //   5945: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   5948: ifnull +9 -> 5957/*      */     //   5951: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   5954: goto +12 -> 5966/*      */     //   5957: ldc 3/*      */     //   5959: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5962: dup/*      */     //   5963: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   5966: aastore/*      */     //   5967: dup/*      */     //   5968: iconst_1/*      */     //   5969: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   5972: aastore/*      */     //   5973: dup/*      */     //   5974: iconst_2/*      */     //   5975: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   5978: aastore/*      */     //   5979: dup/*      */     //   5980: iconst_3/*      */     //   5981: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   5984: ifnull +9 -> 5993/*      */     //   5987: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   5990: goto +12 -> 6002/*      */     //   5993: ldc 105/*      */     //   5995: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   5998: dup/*      */     //   5999: putstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   6002: aastore/*      */     //   6003: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6006: putstatic 306	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFieldFlag_114	Ljava/lang/reflect/Method;/*      */     //   6009: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6012: ifnull +9 -> 6021/*      */     //   6015: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6018: goto +12 -> 6030/*      */     //   6021: ldc 102/*      */     //   6023: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6026: dup/*      */     //   6027: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6030: ldc 114/*      */     //   6032: iconst_4/*      */     //   6033: anewarray 154	java/lang/Class/*      */     //   6036: dup/*      */     //   6037: iconst_0/*      */     //   6038: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6041: ifnull +9 -> 6050/*      */     //   6044: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6047: goto +12 -> 6059/*      */     //   6050: ldc 3/*      */     //   6052: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6055: dup/*      */     //   6056: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6059: aastore/*      */     //   6060: dup/*      */     //   6061: iconst_1/*      */     //   6062: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6065: aastore/*      */     //   6066: dup/*      */     //   6067: iconst_2/*      */     //   6068: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   6071: aastore/*      */     //   6072: dup/*      */     //   6073: iconst_3/*      */     //   6074: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6077: aastore/*      */     //   6078: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6081: putstatic 307	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFieldFlag_115	Ljava/lang/reflect/Method;/*      */     //   6084: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6087: ifnull +9 -> 6096/*      */     //   6090: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6093: goto +12 -> 6105/*      */     //   6096: ldc 102/*      */     //   6098: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6101: dup/*      */     //   6102: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6105: ldc 114/*      */     //   6107: iconst_5/*      */     //   6108: anewarray 154	java/lang/Class/*      */     //   6111: dup/*      */     //   6112: iconst_0/*      */     //   6113: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6116: ifnull +9 -> 6125/*      */     //   6119: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6122: goto +12 -> 6134/*      */     //   6125: ldc 3/*      */     //   6127: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6130: dup/*      */     //   6131: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6134: aastore/*      */     //   6135: dup/*      */     //   6136: iconst_1/*      */     //   6137: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6140: aastore/*      */     //   6141: dup/*      */     //   6142: iconst_2/*      */     //   6143: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   6146: aastore/*      */     //   6147: dup/*      */     //   6148: iconst_3/*      */     //   6149: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6152: aastore/*      */     //   6153: dup/*      */     //   6154: iconst_4/*      */     //   6155: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   6158: ifnull +9 -> 6167/*      */     //   6161: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   6164: goto +12 -> 6176/*      */     //   6167: ldc 105/*      */     //   6169: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6172: dup/*      */     //   6173: putstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   6176: aastore/*      */     //   6177: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6180: putstatic 308	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFieldFlag_116	Ljava/lang/reflect/Method;/*      */     //   6183: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6186: ifnull +9 -> 6195/*      */     //   6189: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6192: goto +12 -> 6204/*      */     //   6195: ldc 102/*      */     //   6197: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6200: dup/*      */     //   6201: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6204: ldc 115/*      */     //   6206: iconst_2/*      */     //   6207: anewarray 154	java/lang/Class/*      */     //   6210: dup/*      */     //   6211: iconst_0/*      */     //   6212: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6215: ifnull +9 -> 6224/*      */     //   6218: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6221: goto +12 -> 6233/*      */     //   6224: ldc 93/*      */     //   6226: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6229: dup/*      */     //   6230: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6233: aastore/*      */     //   6234: dup/*      */     //   6235: iconst_1/*      */     //   6236: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   6239: aastore/*      */     //   6240: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6243: putstatic 309	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFieldFlags_117	Ljava/lang/reflect/Method;/*      */     //   6246: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6249: ifnull +9 -> 6258/*      */     //   6252: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6255: goto +12 -> 6267/*      */     //   6258: ldc 102/*      */     //   6260: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6263: dup/*      */     //   6264: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6267: ldc 116/*      */     //   6269: iconst_2/*      */     //   6270: anewarray 154	java/lang/Class/*      */     //   6273: dup/*      */     //   6274: iconst_0/*      */     //   6275: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   6278: aastore/*      */     //   6279: dup/*      */     //   6280: iconst_1/*      */     //   6281: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6284: aastore/*      */     //   6285: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6288: putstatic 310	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFlag_118	Ljava/lang/reflect/Method;/*      */     //   6291: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6294: ifnull +9 -> 6303/*      */     //   6297: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6300: goto +12 -> 6312/*      */     //   6303: ldc 102/*      */     //   6305: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6308: dup/*      */     //   6309: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6312: ldc 116/*      */     //   6314: iconst_3/*      */     //   6315: anewarray 154	java/lang/Class/*      */     //   6318: dup/*      */     //   6319: iconst_0/*      */     //   6320: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   6323: aastore/*      */     //   6324: dup/*      */     //   6325: iconst_1/*      */     //   6326: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6329: aastore/*      */     //   6330: dup/*      */     //   6331: iconst_2/*      */     //   6332: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   6335: ifnull +9 -> 6344/*      */     //   6338: getstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   6341: goto +12 -> 6353/*      */     //   6344: ldc 105/*      */     //   6346: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6349: dup/*      */     //   6350: putstatic 404	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MXException	Ljava/lang/Class;/*      */     //   6353: aastore/*      */     //   6354: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6357: putstatic 311	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFlag_119	Ljava/lang/reflect/Method;/*      */     //   6360: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6363: ifnull +9 -> 6372/*      */     //   6366: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6369: goto +12 -> 6381/*      */     //   6372: ldc 102/*      */     //   6374: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6377: dup/*      */     //   6378: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6381: ldc 117/*      */     //   6383: iconst_1/*      */     //   6384: anewarray 154	java/lang/Class/*      */     //   6387: dup/*      */     //   6388: iconst_0/*      */     //   6389: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   6392: aastore/*      */     //   6393: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6396: putstatic 312	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setFlags_120	Ljava/lang/reflect/Method;/*      */     //   6399: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6402: ifnull +9 -> 6411/*      */     //   6405: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6408: goto +12 -> 6420/*      */     //   6411: ldc 102/*      */     //   6413: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6416: dup/*      */     //   6417: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6420: ldc 118/*      */     //   6422: iconst_1/*      */     //   6423: anewarray 154	java/lang/Class/*      */     //   6426: dup/*      */     //   6427: iconst_0/*      */     //   6428: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6431: aastore/*      */     //   6432: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6435: putstatic 313	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setForDM_121	Ljava/lang/reflect/Method;/*      */     //   6438: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6441: ifnull +9 -> 6450/*      */     //   6444: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6447: goto +12 -> 6459/*      */     //   6450: ldc 102/*      */     //   6452: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6455: dup/*      */     //   6456: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6459: ldc 119/*      */     //   6461: iconst_4/*      */     //   6462: anewarray 154	java/lang/Class/*      */     //   6465: dup/*      */     //   6466: iconst_0/*      */     //   6467: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6470: ifnull +9 -> 6479/*      */     //   6473: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6476: goto +12 -> 6488/*      */     //   6479: ldc 93/*      */     //   6481: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6484: dup/*      */     //   6485: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6488: aastore/*      */     //   6489: dup/*      */     //   6490: iconst_1/*      */     //   6491: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6494: ifnull +9 -> 6503/*      */     //   6497: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6500: goto +12 -> 6512/*      */     //   6503: ldc 93/*      */     //   6505: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6508: dup/*      */     //   6509: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6512: aastore/*      */     //   6513: dup/*      */     //   6514: iconst_2/*      */     //   6515: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6518: ifnull +9 -> 6527/*      */     //   6521: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6524: goto +12 -> 6536/*      */     //   6527: ldc 93/*      */     //   6529: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6532: dup/*      */     //   6533: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6536: aastore/*      */     //   6537: dup/*      */     //   6538: iconst_3/*      */     //   6539: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   6542: aastore/*      */     //   6543: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6546: putstatic 314	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setMLValue_122	Ljava/lang/reflect/Method;/*      */     //   6549: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6552: ifnull +9 -> 6561/*      */     //   6555: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6558: goto +12 -> 6570/*      */     //   6561: ldc 102/*      */     //   6563: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6566: dup/*      */     //   6567: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6570: ldc 120/*      */     //   6572: iconst_1/*      */     //   6573: anewarray 154	java/lang/Class/*      */     //   6576: dup/*      */     //   6577: iconst_0/*      */     //   6578: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6581: aastore/*      */     //   6582: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6585: putstatic 315	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setModified_123	Ljava/lang/reflect/Method;/*      */     //   6588: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6591: ifnull +9 -> 6600/*      */     //   6594: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6597: goto +12 -> 6609/*      */     //   6600: ldc 102/*      */     //   6602: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6605: dup/*      */     //   6606: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6609: ldc 121/*      */     //   6611: iconst_1/*      */     //   6612: anewarray 154	java/lang/Class/*      */     //   6615: dup/*      */     //   6616: iconst_0/*      */     //   6617: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6620: aastore/*      */     //   6621: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6624: putstatic 316	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setNewMbo_124	Ljava/lang/reflect/Method;/*      */     //   6627: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6630: ifnull +9 -> 6639/*      */     //   6633: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6636: goto +12 -> 6648/*      */     //   6639: ldc 102/*      */     //   6641: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6644: dup/*      */     //   6645: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6648: ldc 122/*      */     //   6650: iconst_1/*      */     //   6651: anewarray 154	java/lang/Class/*      */     //   6654: dup/*      */     //   6655: iconst_0/*      */     //   6656: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6659: aastore/*      */     //   6660: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6663: putstatic 317	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setPropagateKeyFlag_125	Ljava/lang/reflect/Method;/*      */     //   6666: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6669: ifnull +9 -> 6678/*      */     //   6672: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6675: goto +12 -> 6687/*      */     //   6678: ldc 102/*      */     //   6680: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6683: dup/*      */     //   6684: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6687: ldc 122/*      */     //   6689: iconst_2/*      */     //   6690: anewarray 154	java/lang/Class/*      */     //   6693: dup/*      */     //   6694: iconst_0/*      */     //   6695: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6698: ifnull +9 -> 6707/*      */     //   6701: getstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6704: goto +12 -> 6716/*      */     //   6707: ldc 3/*      */     //   6709: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6712: dup/*      */     //   6713: putstatic 388	com/ibm/ism/content/virtual/CatalogItem_Stub:array$Ljava$lang$String	Ljava/lang/Class;/*      */     //   6716: aastore/*      */     //   6717: dup/*      */     //   6718: iconst_1/*      */     //   6719: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   6722: aastore/*      */     //   6723: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6726: putstatic 318	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setPropagateKeyFlag_126	Ljava/lang/reflect/Method;/*      */     //   6729: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6732: ifnull +9 -> 6741/*      */     //   6735: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6738: goto +12 -> 6750/*      */     //   6741: ldc 102/*      */     //   6743: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6746: dup/*      */     //   6747: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6750: ldc 123/*      */     //   6752: iconst_2/*      */     //   6753: anewarray 154	java/lang/Class/*      */     //   6756: dup/*      */     //   6757: iconst_0/*      */     //   6758: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6761: ifnull +9 -> 6770/*      */     //   6764: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6767: goto +12 -> 6779/*      */     //   6770: ldc 93/*      */     //   6772: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6775: dup/*      */     //   6776: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6779: aastore/*      */     //   6780: dup/*      */     //   6781: iconst_1/*      */     //   6782: getstatic 400	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$Mbo	Ljava/lang/Class;/*      */     //   6785: ifnull +9 -> 6794/*      */     //   6788: getstatic 400	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$Mbo	Ljava/lang/Class;/*      */     //   6791: goto +12 -> 6803/*      */     //   6794: ldc 101/*      */     //   6796: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6799: dup/*      */     //   6800: putstatic 400	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$Mbo	Ljava/lang/Class;/*      */     //   6803: aastore/*      */     //   6804: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6807: putstatic 319	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setReferencedMbo_127	Ljava/lang/reflect/Method;/*      */     //   6810: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6813: ifnull +9 -> 6822/*      */     //   6816: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6819: goto +12 -> 6831/*      */     //   6822: ldc 102/*      */     //   6824: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6827: dup/*      */     //   6828: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6831: ldc 124/*      */     //   6833: iconst_2/*      */     //   6834: anewarray 154	java/lang/Class/*      */     //   6837: dup/*      */     //   6838: iconst_0/*      */     //   6839: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6842: ifnull +9 -> 6851/*      */     //   6845: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6848: goto +12 -> 6860/*      */     //   6851: ldc 93/*      */     //   6853: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6856: dup/*      */     //   6857: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6860: aastore/*      */     //   6861: dup/*      */     //   6862: iconst_1/*      */     //   6863: getstatic 379	java/lang/Byte:TYPE	Ljava/lang/Class;/*      */     //   6866: aastore/*      */     //   6867: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6870: putstatic 322	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_128	Ljava/lang/reflect/Method;/*      */     //   6873: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6876: ifnull +9 -> 6885/*      */     //   6879: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6882: goto +12 -> 6894/*      */     //   6885: ldc 102/*      */     //   6887: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6890: dup/*      */     //   6891: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6894: ldc 124/*      */     //   6896: iconst_3/*      */     //   6897: anewarray 154	java/lang/Class/*      */     //   6900: dup/*      */     //   6901: iconst_0/*      */     //   6902: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6905: ifnull +9 -> 6914/*      */     //   6908: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6911: goto +12 -> 6923/*      */     //   6914: ldc 93/*      */     //   6916: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6919: dup/*      */     //   6920: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6923: aastore/*      */     //   6924: dup/*      */     //   6925: iconst_1/*      */     //   6926: getstatic 379	java/lang/Byte:TYPE	Ljava/lang/Class;/*      */     //   6929: aastore/*      */     //   6930: dup/*      */     //   6931: iconst_2/*      */     //   6932: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   6935: aastore/*      */     //   6936: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   6939: putstatic 323	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_129	Ljava/lang/reflect/Method;/*      */     //   6942: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6945: ifnull +9 -> 6954/*      */     //   6948: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6951: goto +12 -> 6963/*      */     //   6954: ldc 102/*      */     //   6956: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6959: dup/*      */     //   6960: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   6963: ldc 124/*      */     //   6965: iconst_2/*      */     //   6966: anewarray 154	java/lang/Class/*      */     //   6969: dup/*      */     //   6970: iconst_0/*      */     //   6971: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6974: ifnull +9 -> 6983/*      */     //   6977: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6980: goto +12 -> 6992/*      */     //   6983: ldc 93/*      */     //   6985: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   6988: dup/*      */     //   6989: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   6992: aastore/*      */     //   6993: dup/*      */     //   6994: iconst_1/*      */     //   6995: getstatic 380	java/lang/Double:TYPE	Ljava/lang/Class;/*      */     //   6998: aastore/*      */     //   6999: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7002: putstatic 324	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_130	Ljava/lang/reflect/Method;/*      */     //   7005: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7008: ifnull +9 -> 7017/*      */     //   7011: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7014: goto +12 -> 7026/*      */     //   7017: ldc 102/*      */     //   7019: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7022: dup/*      */     //   7023: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7026: ldc 124/*      */     //   7028: iconst_3/*      */     //   7029: anewarray 154	java/lang/Class/*      */     //   7032: dup/*      */     //   7033: iconst_0/*      */     //   7034: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7037: ifnull +9 -> 7046/*      */     //   7040: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7043: goto +12 -> 7055/*      */     //   7046: ldc 93/*      */     //   7048: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7051: dup/*      */     //   7052: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7055: aastore/*      */     //   7056: dup/*      */     //   7057: iconst_1/*      */     //   7058: getstatic 380	java/lang/Double:TYPE	Ljava/lang/Class;/*      */     //   7061: aastore/*      */     //   7062: dup/*      */     //   7063: iconst_2/*      */     //   7064: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   7067: aastore/*      */     //   7068: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7071: putstatic 325	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_131	Ljava/lang/reflect/Method;/*      */     //   7074: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7077: ifnull +9 -> 7086/*      */     //   7080: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7083: goto +12 -> 7095/*      */     //   7086: ldc 102/*      */     //   7088: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7091: dup/*      */     //   7092: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7095: ldc 124/*      */     //   7097: iconst_2/*      */     //   7098: anewarray 154	java/lang/Class/*      */     //   7101: dup/*      */     //   7102: iconst_0/*      */     //   7103: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7106: ifnull +9 -> 7115/*      */     //   7109: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7112: goto +12 -> 7124/*      */     //   7115: ldc 93/*      */     //   7117: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7120: dup/*      */     //   7121: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7124: aastore/*      */     //   7125: dup/*      */     //   7126: iconst_1/*      */     //   7127: getstatic 381	java/lang/Float:TYPE	Ljava/lang/Class;/*      */     //   7130: aastore/*      */     //   7131: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7134: putstatic 326	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_132	Ljava/lang/reflect/Method;/*      */     //   7137: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7140: ifnull +9 -> 7149/*      */     //   7143: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7146: goto +12 -> 7158/*      */     //   7149: ldc 102/*      */     //   7151: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7154: dup/*      */     //   7155: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7158: ldc 124/*      */     //   7160: iconst_3/*      */     //   7161: anewarray 154	java/lang/Class/*      */     //   7164: dup/*      */     //   7165: iconst_0/*      */     //   7166: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7169: ifnull +9 -> 7178/*      */     //   7172: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7175: goto +12 -> 7187/*      */     //   7178: ldc 93/*      */     //   7180: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7183: dup/*      */     //   7184: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7187: aastore/*      */     //   7188: dup/*      */     //   7189: iconst_1/*      */     //   7190: getstatic 381	java/lang/Float:TYPE	Ljava/lang/Class;/*      */     //   7193: aastore/*      */     //   7194: dup/*      */     //   7195: iconst_2/*      */     //   7196: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   7199: aastore/*      */     //   7200: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7203: putstatic 327	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_133	Ljava/lang/reflect/Method;/*      */     //   7206: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7209: ifnull +9 -> 7218/*      */     //   7212: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7215: goto +12 -> 7227/*      */     //   7218: ldc 102/*      */     //   7220: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7223: dup/*      */     //   7224: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7227: ldc 124/*      */     //   7229: iconst_2/*      */     //   7230: anewarray 154	java/lang/Class/*      */     //   7233: dup/*      */     //   7234: iconst_0/*      */     //   7235: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7238: ifnull +9 -> 7247/*      */     //   7241: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7244: goto +12 -> 7256/*      */     //   7247: ldc 93/*      */     //   7249: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7252: dup/*      */     //   7253: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7256: aastore/*      */     //   7257: dup/*      */     //   7258: iconst_1/*      */     //   7259: getstatic 382	java/lang/Integer:TYPE	Ljava/lang/Class;/*      */     //   7262: aastore/*      */     //   7263: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7266: putstatic 328	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_134	Ljava/lang/reflect/Method;/*      */     //   7269: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7272: ifnull +9 -> 7281/*      */     //   7275: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7278: goto +12 -> 7290/*      */     //   7281: ldc 102/*      */     //   7283: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7286: dup/*      */     //   7287: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7290: ldc 124/*      */     //   7292: iconst_3/*      */     //   7293: anewarray 154	java/lang/Class/*      */     //   7296: dup/*      */     //   7297: iconst_0/*      */     //   7298: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7301: ifnull +9 -> 7310/*      */     //   7304: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7307: goto +12 -> 7319/*      */     //   7310: ldc 93/*      */     //   7312: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7315: dup/*      */     //   7316: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7319: aastore/*      */     //   7320: dup/*      */     //   7321: iconst_1/*      */     //   7322: getstatic 382	java/lang/Integer:TYPE	Ljava/lang/Class;/*      */     //   7325: aastore/*      */     //   7326: dup/*      */     //   7327: iconst_2/*      */     //   7328: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   7331: aastore/*      */     //   7332: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7335: putstatic 329	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_135	Ljava/lang/reflect/Method;/*      */     //   7338: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7341: ifnull +9 -> 7350/*      */     //   7344: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7347: goto +12 -> 7359/*      */     //   7350: ldc 102/*      */     //   7352: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7355: dup/*      */     //   7356: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7359: ldc 124/*      */     //   7361: iconst_2/*      */     //   7362: anewarray 154	java/lang/Class/*      */     //   7365: dup/*      */     //   7366: iconst_0/*      */     //   7367: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7370: ifnull +9 -> 7379/*      */     //   7373: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7376: goto +12 -> 7388/*      */     //   7379: ldc 93/*      */     //   7381: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7384: dup/*      */     //   7385: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7388: aastore/*      */     //   7389: dup/*      */     //   7390: iconst_1/*      */     //   7391: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   7394: aastore/*      */     //   7395: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7398: putstatic 330	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_136	Ljava/lang/reflect/Method;/*      */     //   7401: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7404: ifnull +9 -> 7413/*      */     //   7407: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7410: goto +12 -> 7422/*      */     //   7413: ldc 102/*      */     //   7415: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7418: dup/*      */     //   7419: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7422: ldc 124/*      */     //   7424: iconst_3/*      */     //   7425: anewarray 154	java/lang/Class/*      */     //   7428: dup/*      */     //   7429: iconst_0/*      */     //   7430: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7433: ifnull +9 -> 7442/*      */     //   7436: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7439: goto +12 -> 7451/*      */     //   7442: ldc 93/*      */     //   7444: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7447: dup/*      */     //   7448: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7451: aastore/*      */     //   7452: dup/*      */     //   7453: iconst_1/*      */     //   7454: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   7457: aastore/*      */     //   7458: dup/*      */     //   7459: iconst_2/*      */     //   7460: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   7463: aastore/*      */     //   7464: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7467: putstatic 331	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_137	Ljava/lang/reflect/Method;/*      */     //   7470: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7473: ifnull +9 -> 7482/*      */     //   7476: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7479: goto +12 -> 7491/*      */     //   7482: ldc 102/*      */     //   7484: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7487: dup/*      */     //   7488: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7491: ldc 124/*      */     //   7493: iconst_2/*      */     //   7494: anewarray 154	java/lang/Class/*      */     //   7497: dup/*      */     //   7498: iconst_0/*      */     //   7499: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7502: ifnull +9 -> 7511/*      */     //   7505: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7508: goto +12 -> 7520/*      */     //   7511: ldc 93/*      */     //   7513: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7516: dup/*      */     //   7517: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7520: aastore/*      */     //   7521: dup/*      */     //   7522: iconst_1/*      */     //   7523: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7526: ifnull +9 -> 7535/*      */     //   7529: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7532: goto +12 -> 7544/*      */     //   7535: ldc 93/*      */     //   7537: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7540: dup/*      */     //   7541: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7544: aastore/*      */     //   7545: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7548: putstatic 332	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_138	Ljava/lang/reflect/Method;/*      */     //   7551: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7554: ifnull +9 -> 7563/*      */     //   7557: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7560: goto +12 -> 7572/*      */     //   7563: ldc 102/*      */     //   7565: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7568: dup/*      */     //   7569: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7572: ldc 124/*      */     //   7574: iconst_3/*      */     //   7575: anewarray 154	java/lang/Class/*      */     //   7578: dup/*      */     //   7579: iconst_0/*      */     //   7580: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7583: ifnull +9 -> 7592/*      */     //   7586: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7589: goto +12 -> 7601/*      */     //   7592: ldc 93/*      */     //   7594: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7597: dup/*      */     //   7598: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7601: aastore/*      */     //   7602: dup/*      */     //   7603: iconst_1/*      */     //   7604: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7607: ifnull +9 -> 7616/*      */     //   7610: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7613: goto +12 -> 7625/*      */     //   7616: ldc 93/*      */     //   7618: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7621: dup/*      */     //   7622: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7625: aastore/*      */     //   7626: dup/*      */     //   7627: iconst_2/*      */     //   7628: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   7631: aastore/*      */     //   7632: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7635: putstatic 333	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_139	Ljava/lang/reflect/Method;/*      */     //   7638: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7641: ifnull +9 -> 7650/*      */     //   7644: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7647: goto +12 -> 7659/*      */     //   7650: ldc 102/*      */     //   7652: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7655: dup/*      */     //   7656: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7659: ldc 124/*      */     //   7661: iconst_2/*      */     //   7662: anewarray 154	java/lang/Class/*      */     //   7665: dup/*      */     //   7666: iconst_0/*      */     //   7667: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7670: ifnull +9 -> 7679/*      */     //   7673: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7676: goto +12 -> 7688/*      */     //   7679: ldc 93/*      */     //   7681: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7684: dup/*      */     //   7685: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7688: aastore/*      */     //   7689: dup/*      */     //   7690: iconst_1/*      */     //   7691: getstatic 395	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Date	Ljava/lang/Class;/*      */     //   7694: ifnull +9 -> 7703/*      */     //   7697: getstatic 395	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Date	Ljava/lang/Class;/*      */     //   7700: goto +12 -> 7712/*      */     //   7703: ldc 94/*      */     //   7705: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7708: dup/*      */     //   7709: putstatic 395	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Date	Ljava/lang/Class;/*      */     //   7712: aastore/*      */     //   7713: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7716: putstatic 334	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_140	Ljava/lang/reflect/Method;/*      */     //   7719: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7722: ifnull +9 -> 7731/*      */     //   7725: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7728: goto +12 -> 7740/*      */     //   7731: ldc 102/*      */     //   7733: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7736: dup/*      */     //   7737: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7740: ldc 124/*      */     //   7742: iconst_3/*      */     //   7743: anewarray 154	java/lang/Class/*      */     //   7746: dup/*      */     //   7747: iconst_0/*      */     //   7748: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7751: ifnull +9 -> 7760/*      */     //   7754: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7757: goto +12 -> 7769/*      */     //   7760: ldc 93/*      */     //   7762: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7765: dup/*      */     //   7766: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7769: aastore/*      */     //   7770: dup/*      */     //   7771: iconst_1/*      */     //   7772: getstatic 395	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Date	Ljava/lang/Class;/*      */     //   7775: ifnull +9 -> 7784/*      */     //   7778: getstatic 395	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Date	Ljava/lang/Class;/*      */     //   7781: goto +12 -> 7793/*      */     //   7784: ldc 94/*      */     //   7786: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7789: dup/*      */     //   7790: putstatic 395	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Date	Ljava/lang/Class;/*      */     //   7793: aastore/*      */     //   7794: dup/*      */     //   7795: iconst_2/*      */     //   7796: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   7799: aastore/*      */     //   7800: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7803: putstatic 335	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_141	Ljava/lang/reflect/Method;/*      */     //   7806: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7809: ifnull +9 -> 7818/*      */     //   7812: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7815: goto +12 -> 7827/*      */     //   7818: ldc 102/*      */     //   7820: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7823: dup/*      */     //   7824: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7827: ldc 124/*      */     //   7829: iconst_2/*      */     //   7830: anewarray 154	java/lang/Class/*      */     //   7833: dup/*      */     //   7834: iconst_0/*      */     //   7835: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7838: ifnull +9 -> 7847/*      */     //   7841: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7844: goto +12 -> 7856/*      */     //   7847: ldc 93/*      */     //   7849: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7852: dup/*      */     //   7853: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7856: aastore/*      */     //   7857: dup/*      */     //   7858: iconst_1/*      */     //   7859: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7862: ifnull +9 -> 7871/*      */     //   7865: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7868: goto +12 -> 7880/*      */     //   7871: ldc 102/*      */     //   7873: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7876: dup/*      */     //   7877: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7880: aastore/*      */     //   7881: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7884: putstatic 336	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_142	Ljava/lang/reflect/Method;/*      */     //   7887: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7890: ifnull +9 -> 7899/*      */     //   7893: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7896: goto +12 -> 7908/*      */     //   7899: ldc 102/*      */     //   7901: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7904: dup/*      */     //   7905: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7908: ldc 124/*      */     //   7910: iconst_2/*      */     //   7911: anewarray 154	java/lang/Class/*      */     //   7914: dup/*      */     //   7915: iconst_0/*      */     //   7916: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7919: ifnull +9 -> 7928/*      */     //   7922: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7925: goto +12 -> 7937/*      */     //   7928: ldc 93/*      */     //   7930: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7933: dup/*      */     //   7934: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   7937: aastore/*      */     //   7938: dup/*      */     //   7939: iconst_1/*      */     //   7940: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   7943: ifnull +9 -> 7952/*      */     //   7946: getstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   7949: goto +12 -> 7961/*      */     //   7952: ldc 103/*      */     //   7954: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7957: dup/*      */     //   7958: putstatic 402	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboSetRemote	Ljava/lang/Class;/*      */     //   7961: aastore/*      */     //   7962: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   7965: putstatic 337	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_143	Ljava/lang/reflect/Method;/*      */     //   7968: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7971: ifnull +9 -> 7980/*      */     //   7974: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7977: goto +12 -> 7989/*      */     //   7980: ldc 102/*      */     //   7982: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   7985: dup/*      */     //   7986: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   7989: ldc 124/*      */     //   7991: iconst_3/*      */     //   7992: anewarray 154	java/lang/Class/*      */     //   7995: dup/*      */     //   7996: iconst_0/*      */     //   7997: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8000: ifnull +9 -> 8009/*      */     //   8003: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8006: goto +12 -> 8018/*      */     //   8009: ldc 93/*      */     //   8011: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8014: dup/*      */     //   8015: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8018: aastore/*      */     //   8019: dup/*      */     //   8020: iconst_1/*      */     //   8021: getstatic 405	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MaxType	Ljava/lang/Class;/*      */     //   8024: ifnull +9 -> 8033/*      */     //   8027: getstatic 405	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MaxType	Ljava/lang/Class;/*      */     //   8030: goto +12 -> 8042/*      */     //   8033: ldc 106/*      */     //   8035: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8038: dup/*      */     //   8039: putstatic 405	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$util$MaxType	Ljava/lang/Class;/*      */     //   8042: aastore/*      */     //   8043: dup/*      */     //   8044: iconst_2/*      */     //   8045: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   8048: aastore/*      */     //   8049: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8052: putstatic 338	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_144	Ljava/lang/reflect/Method;/*      */     //   8055: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8058: ifnull +9 -> 8067/*      */     //   8061: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8064: goto +12 -> 8076/*      */     //   8067: ldc 102/*      */     //   8069: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8072: dup/*      */     //   8073: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8076: ldc 124/*      */     //   8078: iconst_2/*      */     //   8079: anewarray 154	java/lang/Class/*      */     //   8082: dup/*      */     //   8083: iconst_0/*      */     //   8084: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8087: ifnull +9 -> 8096/*      */     //   8090: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8093: goto +12 -> 8105/*      */     //   8096: ldc 93/*      */     //   8098: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8101: dup/*      */     //   8102: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8105: aastore/*      */     //   8106: dup/*      */     //   8107: iconst_1/*      */     //   8108: getstatic 384	java/lang/Short:TYPE	Ljava/lang/Class;/*      */     //   8111: aastore/*      */     //   8112: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8115: putstatic 339	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_145	Ljava/lang/reflect/Method;/*      */     //   8118: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8121: ifnull +9 -> 8130/*      */     //   8124: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8127: goto +12 -> 8139/*      */     //   8130: ldc 102/*      */     //   8132: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8135: dup/*      */     //   8136: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8139: ldc 124/*      */     //   8141: iconst_3/*      */     //   8142: anewarray 154	java/lang/Class/*      */     //   8145: dup/*      */     //   8146: iconst_0/*      */     //   8147: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8150: ifnull +9 -> 8159/*      */     //   8153: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8156: goto +12 -> 8168/*      */     //   8159: ldc 93/*      */     //   8161: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8164: dup/*      */     //   8165: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8168: aastore/*      */     //   8169: dup/*      */     //   8170: iconst_1/*      */     //   8171: getstatic 384	java/lang/Short:TYPE	Ljava/lang/Class;/*      */     //   8174: aastore/*      */     //   8175: dup/*      */     //   8176: iconst_2/*      */     //   8177: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   8180: aastore/*      */     //   8181: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8184: putstatic 340	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_146	Ljava/lang/reflect/Method;/*      */     //   8187: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8190: ifnull +9 -> 8199/*      */     //   8193: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8196: goto +12 -> 8208/*      */     //   8199: ldc 102/*      */     //   8201: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8204: dup/*      */     //   8205: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8208: ldc 124/*      */     //   8210: iconst_2/*      */     //   8211: anewarray 154	java/lang/Class/*      */     //   8214: dup/*      */     //   8215: iconst_0/*      */     //   8216: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8219: ifnull +9 -> 8228/*      */     //   8222: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8225: goto +12 -> 8237/*      */     //   8228: ldc 93/*      */     //   8230: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8233: dup/*      */     //   8234: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8237: aastore/*      */     //   8238: dup/*      */     //   8239: iconst_1/*      */     //   8240: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   8243: aastore/*      */     //   8244: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8247: putstatic 341	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_147	Ljava/lang/reflect/Method;/*      */     //   8250: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8253: ifnull +9 -> 8262/*      */     //   8256: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8259: goto +12 -> 8271/*      */     //   8262: ldc 102/*      */     //   8264: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8267: dup/*      */     //   8268: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8271: ldc 124/*      */     //   8273: iconst_3/*      */     //   8274: anewarray 154	java/lang/Class/*      */     //   8277: dup/*      */     //   8278: iconst_0/*      */     //   8279: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8282: ifnull +9 -> 8291/*      */     //   8285: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8288: goto +12 -> 8300/*      */     //   8291: ldc 93/*      */     //   8293: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8296: dup/*      */     //   8297: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8300: aastore/*      */     //   8301: dup/*      */     //   8302: iconst_1/*      */     //   8303: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   8306: aastore/*      */     //   8307: dup/*      */     //   8308: iconst_2/*      */     //   8309: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   8312: aastore/*      */     //   8313: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8316: putstatic 342	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_148	Ljava/lang/reflect/Method;/*      */     //   8319: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8322: ifnull +9 -> 8331/*      */     //   8325: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8328: goto +12 -> 8340/*      */     //   8331: ldc 102/*      */     //   8333: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8336: dup/*      */     //   8337: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8340: ldc 124/*      */     //   8342: iconst_2/*      */     //   8343: anewarray 154	java/lang/Class/*      */     //   8346: dup/*      */     //   8347: iconst_0/*      */     //   8348: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8351: ifnull +9 -> 8360/*      */     //   8354: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8357: goto +12 -> 8369/*      */     //   8360: ldc 93/*      */     //   8362: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8365: dup/*      */     //   8366: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8369: aastore/*      */     //   8370: dup/*      */     //   8371: iconst_1/*      */     //   8372: getstatic 386	com/ibm/ism/content/virtual/CatalogItem_Stub:array$B	Ljava/lang/Class;/*      */     //   8375: ifnull +9 -> 8384/*      */     //   8378: getstatic 386	com/ibm/ism/content/virtual/CatalogItem_Stub:array$B	Ljava/lang/Class;/*      */     //   8381: goto +12 -> 8393/*      */     //   8384: ldc 1/*      */     //   8386: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8389: dup/*      */     //   8390: putstatic 386	com/ibm/ism/content/virtual/CatalogItem_Stub:array$B	Ljava/lang/Class;/*      */     //   8393: aastore/*      */     //   8394: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8397: putstatic 343	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_149	Ljava/lang/reflect/Method;/*      */     //   8400: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8403: ifnull +9 -> 8412/*      */     //   8406: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8409: goto +12 -> 8421/*      */     //   8412: ldc 102/*      */     //   8414: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8417: dup/*      */     //   8418: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8421: ldc 124/*      */     //   8423: iconst_3/*      */     //   8424: anewarray 154	java/lang/Class/*      */     //   8427: dup/*      */     //   8428: iconst_0/*      */     //   8429: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8432: ifnull +9 -> 8441/*      */     //   8435: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8438: goto +12 -> 8450/*      */     //   8441: ldc 93/*      */     //   8443: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8446: dup/*      */     //   8447: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8450: aastore/*      */     //   8451: dup/*      */     //   8452: iconst_1/*      */     //   8453: getstatic 386	com/ibm/ism/content/virtual/CatalogItem_Stub:array$B	Ljava/lang/Class;/*      */     //   8456: ifnull +9 -> 8465/*      */     //   8459: getstatic 386	com/ibm/ism/content/virtual/CatalogItem_Stub:array$B	Ljava/lang/Class;/*      */     //   8462: goto +12 -> 8474/*      */     //   8465: ldc 1/*      */     //   8467: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8470: dup/*      */     //   8471: putstatic 386	com/ibm/ism/content/virtual/CatalogItem_Stub:array$B	Ljava/lang/Class;/*      */     //   8474: aastore/*      */     //   8475: dup/*      */     //   8476: iconst_2/*      */     //   8477: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   8480: aastore/*      */     //   8481: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8484: putstatic 344	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValue_150	Ljava/lang/reflect/Method;/*      */     //   8487: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8490: ifnull +9 -> 8499/*      */     //   8493: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8496: goto +12 -> 8508/*      */     //   8499: ldc 102/*      */     //   8501: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8504: dup/*      */     //   8505: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8508: ldc 125/*      */     //   8510: iconst_1/*      */     //   8511: anewarray 154	java/lang/Class/*      */     //   8514: dup/*      */     //   8515: iconst_0/*      */     //   8516: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8519: ifnull +9 -> 8528/*      */     //   8522: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8525: goto +12 -> 8537/*      */     //   8528: ldc 93/*      */     //   8530: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8533: dup/*      */     //   8534: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8537: aastore/*      */     //   8538: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8541: putstatic 320	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValueNull_151	Ljava/lang/reflect/Method;/*      */     //   8544: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8547: ifnull +9 -> 8556/*      */     //   8550: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8553: goto +12 -> 8565/*      */     //   8556: ldc 102/*      */     //   8558: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8561: dup/*      */     //   8562: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8565: ldc 125/*      */     //   8567: iconst_2/*      */     //   8568: anewarray 154	java/lang/Class/*      */     //   8571: dup/*      */     //   8572: iconst_0/*      */     //   8573: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8576: ifnull +9 -> 8585/*      */     //   8579: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8582: goto +12 -> 8594/*      */     //   8585: ldc 93/*      */     //   8587: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8590: dup/*      */     //   8591: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8594: aastore/*      */     //   8595: dup/*      */     //   8596: iconst_1/*      */     //   8597: getstatic 383	java/lang/Long:TYPE	Ljava/lang/Class;/*      */     //   8600: aastore/*      */     //   8601: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8604: putstatic 321	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_setValueNull_152	Ljava/lang/reflect/Method;/*      */     //   8607: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8610: ifnull +9 -> 8619/*      */     //   8613: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8616: goto +12 -> 8628/*      */     //   8619: ldc 102/*      */     //   8621: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8624: dup/*      */     //   8625: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8628: ldc 126/*      */     //   8630: iconst_1/*      */     //   8631: anewarray 154	java/lang/Class/*      */     //   8634: dup/*      */     //   8635: iconst_0/*      */     //   8636: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8639: ifnull +9 -> 8648/*      */     //   8642: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8645: goto +12 -> 8657/*      */     //   8648: ldc 93/*      */     //   8650: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8653: dup/*      */     //   8654: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8657: aastore/*      */     //   8658: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8661: putstatic 345	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_sigOptionAccessAuthorized_153	Ljava/lang/reflect/Method;/*      */     //   8664: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8667: ifnull +9 -> 8676/*      */     //   8670: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8673: goto +12 -> 8685/*      */     //   8676: ldc 102/*      */     //   8678: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8681: dup/*      */     //   8682: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8685: ldc 127/*      */     //   8687: iconst_1/*      */     //   8688: anewarray 154	java/lang/Class/*      */     //   8691: dup/*      */     //   8692: iconst_0/*      */     //   8693: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8696: ifnull +9 -> 8705/*      */     //   8699: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8702: goto +12 -> 8714/*      */     //   8705: ldc 93/*      */     //   8707: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8710: dup/*      */     //   8711: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8714: aastore/*      */     //   8715: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8718: putstatic 346	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_sigopGranted_154	Ljava/lang/reflect/Method;/*      */     //   8721: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8724: ifnull +9 -> 8733/*      */     //   8727: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8730: goto +12 -> 8742/*      */     //   8733: ldc 102/*      */     //   8735: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8738: dup/*      */     //   8739: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8742: ldc 127/*      */     //   8744: iconst_2/*      */     //   8745: anewarray 154	java/lang/Class/*      */     //   8748: dup/*      */     //   8749: iconst_0/*      */     //   8750: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8753: ifnull +9 -> 8762/*      */     //   8756: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8759: goto +12 -> 8771/*      */     //   8762: ldc 93/*      */     //   8764: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8767: dup/*      */     //   8768: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8771: aastore/*      */     //   8772: dup/*      */     //   8773: iconst_1/*      */     //   8774: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8777: ifnull +9 -> 8786/*      */     //   8780: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8783: goto +12 -> 8795/*      */     //   8786: ldc 93/*      */     //   8788: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8791: dup/*      */     //   8792: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8795: aastore/*      */     //   8796: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8799: putstatic 347	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_sigopGranted_155	Ljava/lang/reflect/Method;/*      */     //   8802: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8805: ifnull +9 -> 8814/*      */     //   8808: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8811: goto +12 -> 8823/*      */     //   8814: ldc 102/*      */     //   8816: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8819: dup/*      */     //   8820: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8823: ldc 127/*      */     //   8825: iconst_1/*      */     //   8826: anewarray 154	java/lang/Class/*      */     //   8829: dup/*      */     //   8830: iconst_0/*      */     //   8831: getstatic 398	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Set	Ljava/lang/Class;/*      */     //   8834: ifnull +9 -> 8843/*      */     //   8837: getstatic 398	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Set	Ljava/lang/Class;/*      */     //   8840: goto +12 -> 8852/*      */     //   8843: ldc 97/*      */     //   8845: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8848: dup/*      */     //   8849: putstatic 398	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$util$Set	Ljava/lang/Class;/*      */     //   8852: aastore/*      */     //   8853: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8856: putstatic 348	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_sigopGranted_156	Ljava/lang/reflect/Method;/*      */     //   8859: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8862: ifnull +9 -> 8871/*      */     //   8865: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8868: goto +12 -> 8880/*      */     //   8871: ldc 102/*      */     //   8873: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8876: dup/*      */     //   8877: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8880: ldc 128/*      */     //   8882: iconst_3/*      */     //   8883: anewarray 154	java/lang/Class/*      */     //   8886: dup/*      */     //   8887: iconst_0/*      */     //   8888: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8891: ifnull +9 -> 8900/*      */     //   8894: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8897: goto +12 -> 8909/*      */     //   8900: ldc 93/*      */     //   8902: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8905: dup/*      */     //   8906: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8909: aastore/*      */     //   8910: dup/*      */     //   8911: iconst_1/*      */     //   8912: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8915: ifnull +9 -> 8924/*      */     //   8918: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8921: goto +12 -> 8933/*      */     //   8924: ldc 93/*      */     //   8926: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8929: dup/*      */     //   8930: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8933: aastore/*      */     //   8934: dup/*      */     //   8935: iconst_2/*      */     //   8936: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;/*      */     //   8939: aastore/*      */     //   8940: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;/*      */     //   8943: putstatic 349	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_smartFill_157	Ljava/lang/reflect/Method;/*      */     //   8946: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8949: ifnull +9 -> 8958/*      */     //   8952: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8955: goto +12 -> 8967/*      */     //   8958: ldc 102/*      */     //   8960: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8963: dup/*      */     //   8964: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;/*      */     //   8967: ldc 129/*      */     //   8969: iconst_4/*      */     //   8970: anewarray 154	java/lang/Class/*      */     //   8973: dup/*      */     //   8974: iconst_0/*      */     //   8975: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8978: ifnull +9 -> 8987/*      */     //   8981: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8984: goto +12 -> 8996/*      */     //   8987: ldc 93/*      */     //   8989: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   8992: dup/*      */     //   8993: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   8996: aastore/*      */     //   8997: dup/*      */     //   8998: iconst_1/*      */     //   8999: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   9002: ifnull +9 -> 9011/*      */     //   9005: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   9008: goto +12 -> 9020/*      */     //   9011: ldc 93/*      */     //   9013: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;/*      */     //   9016: dup/*      */     //   9017: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   9020: aastore/*      */     //   9021: dup/*      */     //   9022: iconst_2/*      */     //   9023: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   9026: ifnull +9 -> 9035/*      */     //   9029: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;/*      */     //   9032: goto +12 -> 9044/*      */     //   9035: ldc 93/*      */     //   9037: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9040: dup
/*      */     //   9041: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9044: aastore
/*      */     //   9045: dup
/*      */     //   9046: iconst_3
/*      */     //   9047: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;
/*      */     //   9050: aastore
/*      */     //   9051: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9054: putstatic 353	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_smartFind_158	Ljava/lang/reflect/Method;
/*      */     //   9057: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9060: ifnull +9 -> 9069
/*      */     //   9063: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9066: goto +12 -> 9078
/*      */     //   9069: ldc 102
/*      */     //   9071: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9074: dup
/*      */     //   9075: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9078: ldc 129
/*      */     //   9080: iconst_3
/*      */     //   9081: anewarray 154	java/lang/Class
/*      */     //   9084: dup
/*      */     //   9085: iconst_0
/*      */     //   9086: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9089: ifnull +9 -> 9098
/*      */     //   9092: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9095: goto +12 -> 9107
/*      */     //   9098: ldc 93
/*      */     //   9100: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9103: dup
/*      */     //   9104: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9107: aastore
/*      */     //   9108: dup
/*      */     //   9109: iconst_1
/*      */     //   9110: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9113: ifnull +9 -> 9122
/*      */     //   9116: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9119: goto +12 -> 9131
/*      */     //   9122: ldc 93
/*      */     //   9124: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9127: dup
/*      */     //   9128: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9131: aastore
/*      */     //   9132: dup
/*      */     //   9133: iconst_2
/*      */     //   9134: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;
/*      */     //   9137: aastore
/*      */     //   9138: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9141: putstatic 354	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_smartFind_159	Ljava/lang/reflect/Method;
/*      */     //   9144: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9147: ifnull +9 -> 9156
/*      */     //   9150: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9153: goto +12 -> 9165
/*      */     //   9156: ldc 102
/*      */     //   9158: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9161: dup
/*      */     //   9162: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9165: ldc 130
/*      */     //   9167: iconst_4
/*      */     //   9168: anewarray 154	java/lang/Class
/*      */     //   9171: dup
/*      */     //   9172: iconst_0
/*      */     //   9173: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9176: ifnull +9 -> 9185
/*      */     //   9179: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9182: goto +12 -> 9194
/*      */     //   9185: ldc 93
/*      */     //   9187: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9190: dup
/*      */     //   9191: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9194: aastore
/*      */     //   9195: dup
/*      */     //   9196: iconst_1
/*      */     //   9197: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9200: ifnull +9 -> 9209
/*      */     //   9203: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9206: goto +12 -> 9218
/*      */     //   9209: ldc 93
/*      */     //   9211: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9214: dup
/*      */     //   9215: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9218: aastore
/*      */     //   9219: dup
/*      */     //   9220: iconst_2
/*      */     //   9221: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9224: ifnull +9 -> 9233
/*      */     //   9227: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9230: goto +12 -> 9242
/*      */     //   9233: ldc 93
/*      */     //   9235: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9238: dup
/*      */     //   9239: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9242: aastore
/*      */     //   9243: dup
/*      */     //   9244: iconst_3
/*      */     //   9245: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;
/*      */     //   9248: aastore
/*      */     //   9249: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9252: putstatic 351	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_smartFindByObjectName_160	Ljava/lang/reflect/Method;
/*      */     //   9255: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9258: ifnull +9 -> 9267
/*      */     //   9261: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9264: goto +12 -> 9276
/*      */     //   9267: ldc 102
/*      */     //   9269: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9272: dup
/*      */     //   9273: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9276: ldc 130
/*      */     //   9278: iconst_5
/*      */     //   9279: anewarray 154	java/lang/Class
/*      */     //   9282: dup
/*      */     //   9283: iconst_0
/*      */     //   9284: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9287: ifnull +9 -> 9296
/*      */     //   9290: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9293: goto +12 -> 9305
/*      */     //   9296: ldc 93
/*      */     //   9298: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9301: dup
/*      */     //   9302: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9305: aastore
/*      */     //   9306: dup
/*      */     //   9307: iconst_1
/*      */     //   9308: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9311: ifnull +9 -> 9320
/*      */     //   9314: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9317: goto +12 -> 9329
/*      */     //   9320: ldc 93
/*      */     //   9322: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9325: dup
/*      */     //   9326: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9329: aastore
/*      */     //   9330: dup
/*      */     //   9331: iconst_2
/*      */     //   9332: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9335: ifnull +9 -> 9344
/*      */     //   9338: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9341: goto +12 -> 9353
/*      */     //   9344: ldc 93
/*      */     //   9346: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9349: dup
/*      */     //   9350: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9353: aastore
/*      */     //   9354: dup
/*      */     //   9355: iconst_3
/*      */     //   9356: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;
/*      */     //   9359: aastore
/*      */     //   9360: dup
/*      */     //   9361: iconst_4
/*      */     //   9362: getstatic 385	com/ibm/ism/content/virtual/CatalogItem_Stub:array$$Ljava$lang$String	Ljava/lang/Class;
/*      */     //   9365: ifnull +9 -> 9374
/*      */     //   9368: getstatic 385	com/ibm/ism/content/virtual/CatalogItem_Stub:array$$Ljava$lang$String	Ljava/lang/Class;
/*      */     //   9371: goto +12 -> 9383
/*      */     //   9374: ldc 4
/*      */     //   9376: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9379: dup
/*      */     //   9380: putstatic 385	com/ibm/ism/content/virtual/CatalogItem_Stub:array$$Ljava$lang$String	Ljava/lang/Class;
/*      */     //   9383: aastore
/*      */     //   9384: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9387: putstatic 352	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_smartFindByObjectName_161	Ljava/lang/reflect/Method;
/*      */     //   9390: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9393: ifnull +9 -> 9402
/*      */     //   9396: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9399: goto +12 -> 9411
/*      */     //   9402: ldc 102
/*      */     //   9404: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9407: dup
/*      */     //   9408: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9411: ldc 131
/*      */     //   9413: iconst_4
/*      */     //   9414: anewarray 154	java/lang/Class
/*      */     //   9417: dup
/*      */     //   9418: iconst_0
/*      */     //   9419: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9422: ifnull +9 -> 9431
/*      */     //   9425: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9428: goto +12 -> 9440
/*      */     //   9431: ldc 93
/*      */     //   9433: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9436: dup
/*      */     //   9437: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9440: aastore
/*      */     //   9441: dup
/*      */     //   9442: iconst_1
/*      */     //   9443: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9446: ifnull +9 -> 9455
/*      */     //   9449: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9452: goto +12 -> 9464
/*      */     //   9455: ldc 93
/*      */     //   9457: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9460: dup
/*      */     //   9461: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9464: aastore
/*      */     //   9465: dup
/*      */     //   9466: iconst_2
/*      */     //   9467: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9470: ifnull +9 -> 9479
/*      */     //   9473: getstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9476: goto +12 -> 9488
/*      */     //   9479: ldc 93
/*      */     //   9481: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9484: dup
/*      */     //   9485: putstatic 394	com/ibm/ism/content/virtual/CatalogItem_Stub:class$java$lang$String	Ljava/lang/Class;
/*      */     //   9488: aastore
/*      */     //   9489: dup
/*      */     //   9490: iconst_3
/*      */     //   9491: getstatic 378	java/lang/Boolean:TYPE	Ljava/lang/Class;
/*      */     //   9494: aastore
/*      */     //   9495: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9498: putstatic 350	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_smartFindByObjectNameDirect_162	Ljava/lang/reflect/Method;
/*      */     //   9501: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9504: ifnull +9 -> 9513
/*      */     //   9507: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9510: goto +12 -> 9522
/*      */     //   9513: ldc 102
/*      */     //   9515: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9518: dup
/*      */     //   9519: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9522: ldc 132
/*      */     //   9524: iconst_0
/*      */     //   9525: anewarray 154	java/lang/Class
/*      */     //   9528: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9531: putstatic 355	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_startCheckpoint_163	Ljava/lang/reflect/Method;
/*      */     //   9534: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9537: ifnull +9 -> 9546
/*      */     //   9540: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9543: goto +12 -> 9555
/*      */     //   9546: ldc 102
/*      */     //   9548: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9551: dup
/*      */     //   9552: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9555: ldc 134
/*      */     //   9557: iconst_0
/*      */     //   9558: anewarray 154	java/lang/Class
/*      */     //   9561: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9564: putstatic 356	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_thisToBeUpdated_164	Ljava/lang/reflect/Method;
/*      */     //   9567: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9570: ifnull +9 -> 9579
/*      */     //   9573: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9576: goto +12 -> 9588
/*      */     //   9579: ldc 102
/*      */     //   9581: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9584: dup
/*      */     //   9585: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9588: ldc 135
/*      */     //   9590: iconst_0
/*      */     //   9591: anewarray 154	java/lang/Class
/*      */     //   9594: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9597: putstatic 357	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_toBeAdded_165	Ljava/lang/reflect/Method;
/*      */     //   9600: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9603: ifnull +9 -> 9612
/*      */     //   9606: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9609: goto +12 -> 9621
/*      */     //   9612: ldc 102
/*      */     //   9614: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9617: dup
/*      */     //   9618: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9621: ldc 136
/*      */     //   9623: iconst_0
/*      */     //   9624: anewarray 154	java/lang/Class
/*      */     //   9627: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9630: putstatic 358	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_toBeDeleted_166	Ljava/lang/reflect/Method;
/*      */     //   9633: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9636: ifnull +9 -> 9645
/*      */     //   9639: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9642: goto +12 -> 9654
/*      */     //   9645: ldc 102
/*      */     //   9647: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9650: dup
/*      */     //   9651: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9654: ldc 137
/*      */     //   9656: iconst_0
/*      */     //   9657: anewarray 154	java/lang/Class
/*      */     //   9660: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9663: putstatic 359	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_toBeSaved_167	Ljava/lang/reflect/Method;
/*      */     //   9666: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9669: ifnull +9 -> 9678
/*      */     //   9672: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9675: goto +12 -> 9687
/*      */     //   9678: ldc 102
/*      */     //   9680: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9683: dup
/*      */     //   9684: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9687: ldc 138
/*      */     //   9689: iconst_0
/*      */     //   9690: anewarray 154	java/lang/Class
/*      */     //   9693: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9696: putstatic 360	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_toBeUpdated_168	Ljava/lang/reflect/Method;
/*      */     //   9699: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9702: ifnull +9 -> 9711
/*      */     //   9705: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9708: goto +12 -> 9720
/*      */     //   9711: ldc 102
/*      */     //   9713: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9716: dup
/*      */     //   9717: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9720: ldc 139
/*      */     //   9722: iconst_0
/*      */     //   9723: anewarray 154	java/lang/Class
/*      */     //   9726: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9729: putstatic 361	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_toBeValidated_169	Ljava/lang/reflect/Method;
/*      */     //   9732: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9735: ifnull +9 -> 9744
/*      */     //   9738: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9741: goto +12 -> 9753
/*      */     //   9744: ldc 102
/*      */     //   9746: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9749: dup
/*      */     //   9750: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9753: ldc 141
/*      */     //   9755: iconst_0
/*      */     //   9756: anewarray 154	java/lang/Class
/*      */     //   9759: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9762: putstatic 362	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_undelete_170	Ljava/lang/reflect/Method;
/*      */     //   9765: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9768: ifnull +9 -> 9777
/*      */     //   9771: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9774: goto +12 -> 9786
/*      */     //   9777: ldc 102
/*      */     //   9779: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9782: dup
/*      */     //   9783: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9786: ldc 142
/*      */     //   9788: iconst_0
/*      */     //   9789: anewarray 154	java/lang/Class
/*      */     //   9792: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9795: putstatic 363	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_unselect_171	Ljava/lang/reflect/Method;
/*      */     //   9798: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9801: ifnull +9 -> 9810
/*      */     //   9804: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9807: goto +12 -> 9819
/*      */     //   9810: ldc 102
/*      */     //   9812: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9815: dup
/*      */     //   9816: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9819: ldc 143
/*      */     //   9821: iconst_0
/*      */     //   9822: anewarray 154	java/lang/Class
/*      */     //   9825: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9828: putstatic 365	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_validate_172	Ljava/lang/reflect/Method;
/*      */     //   9831: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9834: ifnull +9 -> 9843
/*      */     //   9837: getstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9840: goto +12 -> 9852
/*      */     //   9843: ldc 102
/*      */     //   9845: invokestatic 391	com/ibm/ism/content/virtual/CatalogItem_Stub:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   9848: dup
/*      */     //   9849: putstatic 401	com/ibm/ism/content/virtual/CatalogItem_Stub:class$psdi$mbo$MboRemote	Ljava/lang/Class;
/*      */     //   9852: ldc 144
/*      */     //   9854: iconst_0
/*      */     //   9855: anewarray 154	java/lang/Class
/*      */     //   9858: invokevirtual 410	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   9861: putstatic 364	com/ibm/ism/content/virtual/CatalogItem_Stub:$method_validateAttributes_173	Ljava/lang/reflect/Method;
/*      */     //   9864: goto +14 -> 9878
/*      */     //   9867: pop
/*      */     //   9868: new 162	java/lang/NoSuchMethodError
/*      */     //   9871: dup
/*      */     //   9872: ldc 133
/*      */     //   9874: invokespecial 372	java/lang/NoSuchMethodError:<init>	(Ljava/lang/String;)V
/*      */     //   9877: athrow
/*      */     //   9878: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	9864	9867	java/lang/NoSuchMethodException
/*      */   }
/*      */ 
/*      */   public CatalogItem_Stub(RemoteRef paramRemoteRef)
/*      */   {
/*  371 */     super(paramRemoteRef);
/*      */   }



/*      */   public void add()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  381 */       this.ref.invoke(this, $method_add_0, null, 7442693827464960371L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  383 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  385 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  387 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  389 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void addMboSetForRequiredCheck(MboSetRemote paramMboSetRemote)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/*  398 */       this.ref.invoke(this, $method_addMboSetForRequiredCheck_1, new Object[] { paramMboSetRemote }, -5338562565545028087L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  400 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  402 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/*  404 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void addToDeleteForInsertList(String paramString)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/*  413 */       this.ref.invoke(this, $method_addToDeleteForInsertList_2, new Object[] { paramString }, -6655771782122869349L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  415 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  417 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/*  419 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboRemote blindCopy(MboSetRemote paramMboSetRemote)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  428 */       Object localObject = this.ref.invoke(this, $method_blindCopy_3, new Object[] { paramMboSetRemote }, -4018632747186293956L);
/*  429 */       return ((MboRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  431 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  433 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  435 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  437 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void checkMethodAccess(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  446 */       this.ref.invoke(this, $method_checkMethodAccess_4, new Object[] { paramString }, 8770342446443124381L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  448 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  450 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  452 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  454 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void clear()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  463 */       this.ref.invoke(this, $method_clear_5, null, -7475254351993695499L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  465 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  467 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  469 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  471 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboRemote copy()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  480 */       Object localObject = this.ref.invoke(this, $method_copy_6, null, 7357015738026087482L);
/*  481 */       return ((MboRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  483 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  485 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  487 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  489 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboRemote copy(MboSetRemote paramMboSetRemote)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  498 */       Object localObject = this.ref.invoke(this, $method_copy_7, new Object[] { paramMboSetRemote }, -4117456723192037795L);
/*  499 */       return ((MboRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  501 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  503 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  505 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  507 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboRemote copy(MboSetRemote paramMboSetRemote, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  516 */       Object localObject = this.ref.invoke(this, $method_copy_8, new Object[] { paramMboSetRemote, new Long(paramLong) }, 6140987686178264144L);
/*  517 */       return ((MboRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  519 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  521 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  523 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  525 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboRemote copyFake(MboSetRemote paramMboSetRemote)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  534 */       Object localObject = this.ref.invoke(this, $method_copyFake_9, new Object[] { paramMboSetRemote }, 1036720388622533370L);
/*  535 */       return ((MboRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  537 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  539 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  541 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  543 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void copyValue(MboRemote paramMboRemote, String paramString1, String paramString2, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  552 */       this.ref.invoke(this, $method_copyValue_10, new Object[] { paramMboRemote, paramString1, paramString2, new Long(paramLong) }, 2058941549748026920L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  554 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  556 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  558 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  560 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void copyValue(MboRemote paramMboRemote, String[] paramArrayOfString1, String[] paramArrayOfString2, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  569 */       this.ref.invoke(this, $method_copyValue_11, new Object[] { paramMboRemote, paramArrayOfString1, paramArrayOfString2, new Long(paramLong) }, 799583690265436859L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  571 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  573 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  575 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  577 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboRemote createComm()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  586 */       Object localObject = this.ref.invoke(this, $method_createComm_12, null, 6383061083541968967L);
/*  587 */       return ((MboRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  589 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  591 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  593 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  595 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void delete()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  604 */       this.ref.invoke(this, $method_delete_13, null, 5524676105212060426L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  606 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  608 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  610 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  612 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void delete(long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  621 */       this.ref.invoke(this, $method_delete_14, new Object[] { new Long(paramLong) }, -4309379989353443610L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  623 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  625 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  627 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  629 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void downloadContent()
/*      */     throws RemoteException, AuthenticationException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  638 */       this.ref.invoke(this, $method_downloadContent_15, null, -8732883174236020380L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  640 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  642 */       throw localRemoteException;
/*      */     } catch (AuthenticationException localAuthenticationException) {
/*  644 */       throw localAuthenticationException;
/*      */     } catch (MXException localMXException) {
/*  646 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  648 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboRemote duplicate()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  657 */       Object localObject = this.ref.invoke(this, $method_duplicate_16, null, 1223086467188012123L);
/*  658 */       return ((MboRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  660 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  662 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  664 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  666 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean evaluateCondition(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  675 */       Object localObject = this.ref.invoke(this, $method_evaluateCondition_17, new Object[] { paramString }, 8089789934617172671L);
/*  676 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/*  678 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  680 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  682 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  684 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public HashMap evaluateCtrlConditions(HashSet paramHashSet)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  693 */       Object localObject = this.ref.invoke(this, $method_evaluateCtrlConditions_18, new Object[] { paramHashSet }, -1109759550070022850L);
/*  694 */       return ((HashMap)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  696 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  698 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  700 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  702 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public HashMap evaluateCtrlConditions(HashSet paramHashSet, String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  711 */       Object localObject = this.ref.invoke(this, $method_evaluateCtrlConditions_19, new Object[] { paramHashSet, paramString }, -6655192765964905902L);
/*  712 */       return ((HashMap)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  714 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  716 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  718 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  720 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean excludeObjectForPropagate(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  729 */       Object localObject = this.ref.invoke(this, $method_excludeObjectForPropagate_20, new Object[] { paramString }, 2917212447191974118L);
/*  730 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/*  732 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  734 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  736 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  738 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void generateAutoKey()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  747 */       this.ref.invoke(this, $method_generateAutoKey_21, null, 2070061064054472488L);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  749 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  751 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  753 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  755 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean getBoolean(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  764 */       Object localObject = this.ref.invoke(this, $method_getBoolean_22, new Object[] { paramString }, -1640992992330807345L);
/*  765 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/*  767 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  769 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  771 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  773 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public byte getByte(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  782 */       Object localObject = this.ref.invoke(this, $method_getByte_23, new Object[] { paramString }, 3166015741238752943L);
/*  783 */       return ((Byte)localObject).byteValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/*  785 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  787 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  789 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  791 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public byte[] getBytes(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  800 */       Object localObject = this.ref.invoke(this, $method_getBytes_24, new Object[] { paramString }, -3054736941581443291L);
/*  801 */       return ((byte[])localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  803 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  805 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  807 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  809 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public Object[] getCommLogOwnerNameAndUniqueId()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  818 */       Object localObject = this.ref.invoke(this, $method_getCommLogOwnerNameAndUniqueId_25, null, 1610923751341104359L);
/*  819 */       return ((Object[])localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  821 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  823 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  825 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  827 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public Object getDatabaseValue(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  836 */       Object localObject = this.ref.invoke(this, $method_getDatabaseValue_26, new Object[] { paramString }, -2505053288975065790L);
/*  837 */       return localObject;
/*      */     } catch (RuntimeException localRuntimeException) {
/*  839 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  841 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  843 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  845 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public Date getDate(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  854 */       Object localObject = this.ref.invoke(this, $method_getDate_27, new Object[] { paramString }, 25358525752956448L);
/*  855 */       return ((Date)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  857 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  859 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  861 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  863 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public Vector getDeleteForInsertList()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/*  872 */       Object localObject = this.ref.invoke(this, $method_getDeleteForInsertList_28, null, -6605650050775173454L);
/*  873 */       return ((Vector)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  875 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  877 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/*  879 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public int getDocLinksCount()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  888 */       Object localObject = this.ref.invoke(this, $method_getDocLinksCount_29, null, 2377991189333645900L);
/*  889 */       return ((Integer)localObject).intValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/*  891 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  893 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  895 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  897 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String[] getDomainIDs(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  906 */       Object localObject = this.ref.invoke(this, $method_getDomainIDs_30, new Object[] { paramString }, -5383783585694635747L);
/*  907 */       return ((String[])localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  909 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  911 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  913 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  915 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public double getDouble(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  924 */       Object localObject = this.ref.invoke(this, $method_getDouble_31, new Object[] { paramString }, -7136627451769557504L);
/*  925 */       return ((Double)localObject).doubleValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/*  927 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  929 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  931 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  933 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getDownloadMessages()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  942 */       Object localObject = this.ref.invoke(this, $method_getDownloadMessages_32, null, 2077499183979584138L);
/*  943 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  945 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  947 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  949 */       throw localMXException;
/*      */     } catch (Exception localException) {
/*  951 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote getExistingMboSet(String paramString)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/*  960 */       Object localObject = this.ref.invoke(this, $method_getExistingMboSet_33, new Object[] { paramString }, -2344305783824064482L);
/*  961 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/*  963 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  965 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/*  967 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public long getFlags()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/*  976 */       Object localObject = this.ref.invoke(this, $method_getFlags_34, null, 8881435422980061864L);
/*  977 */       return ((Long)localObject).longValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/*  979 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  981 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/*  983 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public float getFloat(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/*  992 */       Object localObject = this.ref.invoke(this, $method_getFloat_35, new Object[] { paramString }, -4592236820643884030L);
/*  993 */       return ((Float)localObject).floatValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/*  995 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/*  997 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/*  999 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1001 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MaxType getInitialValue(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1010 */       Object localObject = this.ref.invoke(this, $method_getInitialValue_36, new Object[] { paramString }, -4159234615084602283L);
/* 1011 */       return ((MaxType)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1013 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1015 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1017 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1019 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getInsertCompanySetId()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1028 */       Object localObject = this.ref.invoke(this, $method_getInsertCompanySetId_37, null, 5765642510693535051L);
/* 1029 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1031 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1033 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1035 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1037 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getInsertItemSetId()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1046 */       Object localObject = this.ref.invoke(this, $method_getInsertItemSetId_38, null, 402668792455980798L);
/* 1047 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1049 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1051 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1053 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1055 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getInsertOrganization()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1064 */       Object localObject = this.ref.invoke(this, $method_getInsertOrganization_39, null, 1777454063904355147L);
/* 1065 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1067 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1069 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1071 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1073 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getInsertSite()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1082 */       Object localObject = this.ref.invoke(this, $method_getInsertSite_40, null, 1869000665442854119L);
/* 1083 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1085 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1087 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1089 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1091 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getInstallMessages()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1100 */       Object localObject = this.ref.invoke(this, $method_getInstallMessages_41, null, -1133790630928607177L);
/* 1101 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1103 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1105 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1107 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1109 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public int getInt(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1118 */       Object localObject = this.ref.invoke(this, $method_getInt_42, new Object[] { paramString }, 6551869032578983177L);
/* 1119 */       return ((Integer)localObject).intValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1121 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1123 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1125 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1127 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public List getJythonScripts()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1136 */       Object localObject = this.ref.invoke(this, $method_getJythonScripts_43, null, -2751587408144336092L);
/* 1137 */       return ((List)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1139 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1141 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1143 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1145 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public KeyValue getKeyValue()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1154 */       Object localObject = this.ref.invoke(this, $method_getKeyValue_44, null, 1865032822986385588L);
/* 1155 */       return ((KeyValue)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1157 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1159 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1161 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1163 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getLinesRelationship()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1172 */       Object localObject = this.ref.invoke(this, $method_getLinesRelationship_45, null, 7593554042000654750L);
/* 1173 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1175 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1177 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1179 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1181 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote getList(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1190 */       Object localObject = this.ref.invoke(this, $method_getList_46, new Object[] { paramString }, -1226607622080901807L);
/* 1191 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1193 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1195 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1197 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1199 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public long getLong(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1208 */       Object localObject = this.ref.invoke(this, $method_getLong_47, new Object[] { paramString }, 1123300209586097136L);
/* 1209 */       return ((Long)localObject).longValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1211 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1213 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1215 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1217 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MXTransaction getMXTransaction()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1226 */       Object localObject = this.ref.invoke(this, $method_getMXTransaction_48, null, 5626709230336731958L);
/* 1227 */       return ((MXTransaction)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1229 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1231 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1233 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getMatchingAttr(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1242 */       Object localObject = this.ref.invoke(this, $method_getMatchingAttr_49, new Object[] { paramString }, -372807487548582674L);
/* 1243 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1245 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1247 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1249 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1251 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getMatchingAttr(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1260 */       Object localObject = this.ref.invoke(this, $method_getMatchingAttr_50, new Object[] { paramString1, paramString2 }, 8865467643363211950L);
/* 1261 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1263 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1265 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1267 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1269 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public Object[] getMatchingAttrs(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1278 */       Object localObject = this.ref.invoke(this, $method_getMatchingAttrs_51, new Object[] { paramString1, paramString2 }, -7209878759219369905L);
/* 1279 */       return ((Object[])localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1281 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1283 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1285 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1287 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MaxMessage getMaxMessage(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1296 */       Object localObject = this.ref.invoke(this, $method_getMaxMessage_52, new Object[] { paramString1, paramString2 }, -1770727576702508461L);
/* 1297 */       return ((MaxMessage)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1299 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1301 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1303 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1305 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboData getMboData(String[] paramArrayOfString)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1314 */       Object localObject = this.ref.invoke(this, $method_getMboData_53, new Object[] { paramArrayOfString }, -5046015836519728268L);
/* 1315 */       return ((MboData)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1317 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1319 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1321 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public Vector getMboDataSet(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1330 */       Object localObject = this.ref.invoke(this, $method_getMboDataSet_54, new Object[] { paramString }, -7416455740491744025L);
/* 1331 */       return ((Vector)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1333 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1335 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1337 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1339 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MaxType getMboInitialValue(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1348 */       Object localObject = this.ref.invoke(this, $method_getMboInitialValue_55, new Object[] { paramString }, 4229764382934053882L);
/* 1349 */       return ((MaxType)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1351 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1353 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1355 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1357 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public List getMboList(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1366 */       Object localObject = this.ref.invoke(this, $method_getMboList_56, new Object[] { paramString }, 1631666615088706231L);
/* 1367 */       return ((List)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1369 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1371 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1373 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1375 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote getMboSet(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1384 */       Object localObject = this.ref.invoke(this, $method_getMboSet_57, new Object[] { paramString }, 4352936676464469835L);
/* 1385 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1387 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1389 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1391 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1393 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote getMboSet(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1402 */       Object localObject = this.ref.invoke(this, $method_getMboSet_58, new Object[] { paramString1, paramString2 }, -1016661797923200850L);
/* 1403 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1405 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1407 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1409 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1411 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote getMboSet(String paramString1, String paramString2, String paramString3)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1420 */       Object localObject = this.ref.invoke(this, $method_getMboSet_59, new Object[] { paramString1, paramString2, paramString3 }, -2754101075503716989L);
/* 1421 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1423 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1425 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1427 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1429 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboValueData getMboValueData(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1438 */       Object localObject = this.ref.invoke(this, $method_getMboValueData_60, new Object[] { paramString }, -2193850169204155020L);
/* 1439 */       return ((MboValueData)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1441 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1443 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1445 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1447 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboValueData getMboValueData(String paramString, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1456 */       Object localObject = this.ref.invoke(this, $method_getMboValueData_61, new Object[] { paramString, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -3257167741483570332L);
/* 1457 */       return ((MboValueData)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1459 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1461 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1463 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1465 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboValueData[] getMboValueData(String[] paramArrayOfString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1474 */       Object localObject = this.ref.invoke(this, $method_getMboValueData_62, new Object[] { paramArrayOfString }, -3046682349766384472L);
/* 1475 */       return ((MboValueData[])localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1477 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1479 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1481 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1483 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboValueInfoStatic getMboValueInfoStatic(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1492 */       Object localObject = this.ref.invoke(this, $method_getMboValueInfoStatic_63, new Object[] { paramString }, -4328088463610638087L);
/* 1493 */       return ((MboValueInfoStatic)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1495 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1497 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1499 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1501 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboValueInfoStatic[] getMboValueInfoStatic(String[] paramArrayOfString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1510 */       Object localObject = this.ref.invoke(this, $method_getMboValueInfoStatic_64, new Object[] { paramArrayOfString }, -169869964566830779L);
/* 1511 */       return ((MboValueInfoStatic[])localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1513 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1515 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1517 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1519 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getMessage(String paramString1, String paramString2)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1528 */       Object localObject = this.ref.invoke(this, $method_getMessage_65, new Object[] { paramString1, paramString2 }, -5117172076054138989L);
/* 1529 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1531 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1533 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1535 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getMessage(String paramString1, String paramString2, Object paramObject)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1544 */       Object localObject = this.ref.invoke(this, $method_getMessage_66, new Object[] { paramString1, paramString2, paramObject }, 5002469433788530020L);
/* 1545 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1547 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1549 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1551 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getMessage(String paramString1, String paramString2, Object[] paramArrayOfObject)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1560 */       Object localObject = this.ref.invoke(this, $method_getMessage_67, new Object[] { paramString1, paramString2, paramArrayOfObject }, -5220667813980826248L);
/* 1561 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1563 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1565 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1567 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getMessage(MXException paramMXException)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1576 */       Object localObject = this.ref.invoke(this, $method_getMessage_68, new Object[] { paramMXException }, -4392176690452392965L);
/* 1577 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1579 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1581 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1583 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getName()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1592 */       Object localObject = this.ref.invoke(this, $method_getName_69, null, 6317137956467216454L);
/* 1593 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1595 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1597 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1599 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getOrgForGL(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1608 */       Object localObject = this.ref.invoke(this, $method_getOrgForGL_70, new Object[] { paramString }, -297533474176735503L);
/* 1609 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1611 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1613 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1615 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1617 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getOrgSiteForMaxvar(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1626 */       Object localObject = this.ref.invoke(this, $method_getOrgSiteForMaxvar_71, new Object[] { paramString }, 6081533744683337893L);
/* 1627 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1629 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1631 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1633 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1635 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboRemote getOwner()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1644 */       Object localObject = this.ref.invoke(this, $method_getOwner_72, null, 2290236231147060375L);
/* 1645 */       return ((MboRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1647 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1649 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1651 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean getPropagateKeyFlag()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1660 */       Object localObject = this.ref.invoke(this, $method_getPropagateKeyFlag_73, null, -5538177702501041821L);
/* 1661 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1663 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1665 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1667 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1669 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getRecordIdentifer()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1678 */       Object localObject = this.ref.invoke(this, $method_getRecordIdentifer_74, null, -7011768566766147390L);
/* 1679 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1681 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1683 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1685 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1687 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String[] getSiteOrg()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1696 */       Object localObject = this.ref.invoke(this, $method_getSiteOrg_75, null, 5727159326898518166L);
/* 1697 */       return ((String[])localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1699 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1701 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1703 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1705 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getString(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1714 */       Object localObject = this.ref.invoke(this, $method_getString_76, new Object[] { paramString }, 5066930371966209369L);
/* 1715 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1717 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1719 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1721 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1723 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getString(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1732 */       Object localObject = this.ref.invoke(this, $method_getString_77, new Object[] { paramString1, paramString2 }, 4681388861163595976L);
/* 1733 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1735 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1737 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1739 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1741 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getStringInBaseLanguage(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1750 */       Object localObject = this.ref.invoke(this, $method_getStringInBaseLanguage_78, new Object[] { paramString }, -1632931176936624329L);
/* 1751 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1753 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1755 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1757 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1759 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getStringInSpecificLocale(String paramString, Locale paramLocale, TimeZone paramTimeZone)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1768 */       Object localObject = this.ref.invoke(this, $method_getStringInSpecificLocale_79, new Object[] { paramString, paramLocale, paramTimeZone }, 8365760013188051278L);
/* 1769 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1771 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1773 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1775 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1777 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getStringTransparent(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1786 */       Object localObject = this.ref.invoke(this, $method_getStringTransparent_80, new Object[] { paramString1, paramString2 }, -3695525249492534072L);
/* 1787 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1789 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1791 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1793 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1795 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote getThisMboSet()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1804 */       Object localObject = this.ref.invoke(this, $method_getThisMboSet_81, null, -8653256074306703933L);
/* 1805 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1807 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1809 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1811 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getUniqueIDName()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1820 */       Object localObject = this.ref.invoke(this, $method_getUniqueIDName_82, null, -4382675799323972988L);
/* 1821 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1823 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1825 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1827 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1829 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public long getUniqueIDValue()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1838 */       Object localObject = this.ref.invoke(this, $method_getUniqueIDValue_83, null, 2423491830152826501L);
/* 1839 */       return ((Long)localObject).longValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1841 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1843 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1845 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1847 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public UserInfo getUserInfo()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1856 */       Object localObject = this.ref.invoke(this, $method_getUserInfo_84, null, -6594617694786131693L);
/* 1857 */       return ((UserInfo)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1859 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1861 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1863 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String getUserName()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1872 */       Object localObject = this.ref.invoke(this, $method_getUserName_85, null, 483502017080265922L);
/* 1873 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1875 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1877 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1879 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1881 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean hasHierarchyLink()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1890 */       Object localObject = this.ref.invoke(this, $method_hasHierarchyLink_86, null, -5328975296699729730L);
/* 1891 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1893 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1895 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1897 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1899 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void installContent()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1908 */       this.ref.invoke(this, $method_installContent_87, null, -7907890921226173755L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1910 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1912 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1914 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1916 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isAutoKeyed(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1925 */       Object localObject = this.ref.invoke(this, $method_isAutoKeyed_88, new Object[] { paramString }, -879194310374197922L);
/* 1926 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1928 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1930 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1932 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1934 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isBasedOn(String paramString)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1943 */       Object localObject = this.ref.invoke(this, $method_isBasedOn_89, new Object[] { paramString }, 6201297079127551930L);
/* 1944 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1946 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1948 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 1950 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isDownloadComplete()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1959 */       Object localObject = this.ref.invoke(this, $method_isDownloadComplete_90, null, -7991455459014935474L);
/* 1960 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1962 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1964 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1966 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1968 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isDownloadFailed()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 1977 */       Object localObject = this.ref.invoke(this, $method_isDownloadFailed_91, null, 7656482610197461092L);
/* 1978 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1980 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 1982 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 1984 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 1986 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isFlagSet(long paramLong)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 1995 */       Object localObject = this.ref.invoke(this, $method_isFlagSet_92, new Object[] { new Long(paramLong) }, -7088243327149326417L);
/* 1996 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 1998 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2000 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2002 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isForDM()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2011 */       Object localObject = this.ref.invoke(this, $method_isForDM_93, null, 2873211367698253517L);
/* 2012 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2014 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2016 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2018 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isInstallComplete()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2027 */       Object localObject = this.ref.invoke(this, $method_isInstallComplete_94, null, 7313837372218028286L);
/* 2028 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2030 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2032 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2034 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2036 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isInstallFailed()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2045 */       Object localObject = this.ref.invoke(this, $method_isInstallFailed_95, null, -496541786949269402L);
/* 2046 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2048 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2050 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2052 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2054 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isModified()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2063 */       Object localObject = this.ref.invoke(this, $method_isModified_96, null, 5708482053152154285L);
/* 2064 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2066 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2068 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2070 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isModified(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2079 */       Object localObject = this.ref.invoke(this, $method_isModified_97, new Object[] { paramString }, 4585372949070100938L);
/* 2080 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2082 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2084 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2086 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2088 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isNew()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2097 */       Object localObject = this.ref.invoke(this, $method_isNew_98, null, 6442781755907520873L);
/* 2098 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2100 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2102 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2104 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isNull(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2113 */       Object localObject = this.ref.invoke(this, $method_isNull_99, new Object[] { paramString }, -4712365544638525211L);
/* 2114 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2116 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2118 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2120 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2122 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isSelected()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2131 */       Object localObject = this.ref.invoke(this, $method_isSelected_100, null, 4258462717937186951L);
/* 2132 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2134 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2136 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2138 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2140 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean isZombie()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2149 */       Object localObject = this.ref.invoke(this, $method_isZombie_101, null, 3924586547093250132L);
/* 2150 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2152 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2154 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2156 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public String loadLicense()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2165 */       Object localObject = this.ref.invoke(this, $method_loadLicense_102, null, -7803354810363389847L);
/* 2166 */       return ((String)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2168 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2170 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2172 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2174 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void propagateKeyValue(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2183 */       this.ref.invoke(this, $method_propagateKeyValue_103, new Object[] { paramString1, paramString2 }, 5838101552568681721L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2185 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2187 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2189 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2191 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void rollbackToCheckpoint()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2200 */       this.ref.invoke(this, $method_rollbackToCheckpoint_104, null, 4883480516303419745L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2202 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2204 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2206 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2208 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void select()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2217 */       this.ref.invoke(this, $method_select_105, null, -1495729093048004794L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2219 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2221 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2223 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2225 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setApplicationError(String paramString, ApplicationError paramApplicationError)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2234 */       this.ref.invoke(this, $method_setApplicationError_106, new Object[] { paramString, paramApplicationError }, 6332578525541894392L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2236 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2238 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2240 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2242 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setApplicationRequired(String paramString, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2251 */       this.ref.invoke(this, $method_setApplicationRequired_107, new Object[] { paramString, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, 9097600827641925507L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2253 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2255 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2257 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2259 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setCopyDefaults()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2268 */       this.ref.invoke(this, $method_setCopyDefaults_108, null, -8845229049221431625L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2270 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2272 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2274 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2276 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setDeleted(boolean paramBoolean)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2285 */       this.ref.invoke(this, $method_setDeleted_109, new Object[] { (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -1638088789301976208L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2287 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2289 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2291 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setESigFieldModified(boolean paramBoolean)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2300 */       this.ref.invoke(this, $method_setESigFieldModified_110, new Object[] { (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -4983321710710401682L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2302 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2304 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2306 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFieldFlag(String paramString, long paramLong, boolean paramBoolean)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2315 */       this.ref.invoke(this, $method_setFieldFlag_111, new Object[] { paramString, new Long(paramLong), (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -5529491389076586840L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2317 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2319 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2321 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFieldFlag(String paramString, long paramLong, boolean paramBoolean, MXException paramMXException)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2330 */       this.ref.invoke(this, $method_setFieldFlag_112, new Object[] { paramString, new Long(paramLong), (paramBoolean) ? Boolean.TRUE : Boolean.FALSE, paramMXException }, 5770702900775330002L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2332 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2334 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2336 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFieldFlag(String[] paramArrayOfString, long paramLong, boolean paramBoolean)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2345 */       this.ref.invoke(this, $method_setFieldFlag_113, new Object[] { paramArrayOfString, new Long(paramLong), (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -5393903062192518457L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2347 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2349 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2351 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFieldFlag(String[] paramArrayOfString, long paramLong, boolean paramBoolean, MXException paramMXException)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2360 */       this.ref.invoke(this, $method_setFieldFlag_114, new Object[] { paramArrayOfString, new Long(paramLong), (paramBoolean) ? Boolean.TRUE : Boolean.FALSE, paramMXException }, -1245260593337479812L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2362 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2364 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2366 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFieldFlag(String[] paramArrayOfString, boolean paramBoolean1, long paramLong, boolean paramBoolean2)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2375 */       this.ref.invoke(this, $method_setFieldFlag_115, new Object[] { paramArrayOfString, (paramBoolean1) ? Boolean.TRUE : Boolean.FALSE, new Long(paramLong), (paramBoolean2) ? Boolean.TRUE : Boolean.FALSE }, 1472859374333820580L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2377 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2379 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2381 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFieldFlag(String[] paramArrayOfString, boolean paramBoolean1, long paramLong, boolean paramBoolean2, MXException paramMXException)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2390 */       this.ref.invoke(this, $method_setFieldFlag_116, new Object[] { paramArrayOfString, (paramBoolean1) ? Boolean.TRUE : Boolean.FALSE, new Long(paramLong), (paramBoolean2) ? Boolean.TRUE : Boolean.FALSE, paramMXException }, -1209563117899662500L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2392 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2394 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2396 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFieldFlags(String paramString, long paramLong)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2405 */       this.ref.invoke(this, $method_setFieldFlags_117, new Object[] { paramString, new Long(paramLong) }, 1591237052410980710L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2407 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2409 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2411 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFlag(long paramLong, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2420 */       this.ref.invoke(this, $method_setFlag_118, new Object[] { new Long(paramLong), (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, 8152726795599941974L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2422 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2424 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2426 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2428 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFlag(long paramLong, boolean paramBoolean, MXException paramMXException)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2437 */       this.ref.invoke(this, $method_setFlag_119, new Object[] { new Long(paramLong), (paramBoolean) ? Boolean.TRUE : Boolean.FALSE, paramMXException }, -568127893371775973L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2439 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2441 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2443 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2445 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setFlags(long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2454 */       this.ref.invoke(this, $method_setFlags_120, new Object[] { new Long(paramLong) }, 8574959450838984319L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2456 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2458 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2460 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2462 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setForDM(boolean paramBoolean)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2471 */       this.ref.invoke(this, $method_setForDM_121, new Object[] { (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -37119969352629619L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2473 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2475 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2477 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setMLValue(String paramString1, String paramString2, String paramString3, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2486 */       this.ref.invoke(this, $method_setMLValue_122, new Object[] { paramString1, paramString2, paramString3, new Long(paramLong) }, 6487062711357833068L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2488 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2490 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2492 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2494 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setModified(boolean paramBoolean)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2503 */       this.ref.invoke(this, $method_setModified_123, new Object[] { (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -2178246973424322698L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2505 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2507 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2509 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setNewMbo(boolean paramBoolean)
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 2518 */       this.ref.invoke(this, $method_setNewMbo_124, new Object[] { (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -8330971555555310601L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2520 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2522 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 2524 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setPropagateKeyFlag(boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2533 */       this.ref.invoke(this, $method_setPropagateKeyFlag_125, new Object[] { (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -8309901174032264787L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2535 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2537 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2539 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2541 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setPropagateKeyFlag(String[] paramArrayOfString, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2550 */       this.ref.invoke(this, $method_setPropagateKeyFlag_126, new Object[] { paramArrayOfString, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -2999468859019732148L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2552 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2554 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2556 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2558 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setReferencedMbo(String paramString, Mbo paramMbo)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2567 */       this.ref.invoke(this, $method_setReferencedMbo_127, new Object[] { paramString, paramMbo }, -7091839046965254272L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2569 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2571 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2573 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2575 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, byte paramByte)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2584 */       this.ref.invoke(this, $method_setValue_128, new Object[] { paramString, new Byte(paramByte) }, 3270551574198177870L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2586 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2588 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2590 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2592 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, byte paramByte, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2601 */       this.ref.invoke(this, $method_setValue_129, new Object[] { paramString, new Byte(paramByte), new Long(paramLong) }, -243985487831981328L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2603 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2605 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2607 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2609 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, double paramDouble)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2618 */       this.ref.invoke(this, $method_setValue_130, new Object[] { paramString, new Double(paramDouble) }, -7524981934498388763L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2620 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2622 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2624 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2626 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, double paramDouble, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2635 */       this.ref.invoke(this, $method_setValue_131, new Object[] { paramString, new Double(paramDouble), new Long(paramLong) }, -168439541455018744L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2637 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2639 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2641 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2643 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, float paramFloat)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2652 */       this.ref.invoke(this, $method_setValue_132, new Object[] { paramString, new Float(paramFloat) }, -2815589486362369060L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2654 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2656 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2658 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2660 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, float paramFloat, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2669 */       this.ref.invoke(this, $method_setValue_133, new Object[] { paramString, new Float(paramFloat), new Long(paramLong) }, 7169252791071186101L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2671 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2673 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2675 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2677 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, int paramInt)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2686 */       this.ref.invoke(this, $method_setValue_134, new Object[] { paramString, new Integer(paramInt) }, 8850354658795100389L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2688 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2690 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2692 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2694 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, int paramInt, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2703 */       this.ref.invoke(this, $method_setValue_135, new Object[] { paramString, new Integer(paramInt), new Long(paramLong) }, 3993773668554685290L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2705 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2707 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2709 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2711 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2720 */       this.ref.invoke(this, $method_setValue_136, new Object[] { paramString, new Long(paramLong) }, 9210802592731375364L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2722 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2724 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2726 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2728 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, long paramLong1, long paramLong2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2737 */       this.ref.invoke(this, $method_setValue_137, new Object[] { paramString, new Long(paramLong1), new Long(paramLong2) }, 6848715728568018278L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2739 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2741 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2743 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2745 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2754 */       this.ref.invoke(this, $method_setValue_138, new Object[] { paramString1, paramString2 }, -2811644617196606099L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2756 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2758 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2760 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2762 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString1, String paramString2, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2771 */       this.ref.invoke(this, $method_setValue_139, new Object[] { paramString1, paramString2, new Long(paramLong) }, -4261472768839578905L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2773 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2775 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2777 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2779 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, Date paramDate)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2788 */       this.ref.invoke(this, $method_setValue_140, new Object[] { paramString, paramDate }, -2630749704591450137L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2790 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2792 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2794 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2796 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, Date paramDate, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2805 */       this.ref.invoke(this, $method_setValue_141, new Object[] { paramString, paramDate, new Long(paramLong) }, 7971076697990243292L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2807 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2809 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2811 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2813 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, MboRemote paramMboRemote)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2822 */       this.ref.invoke(this, $method_setValue_142, new Object[] { paramString, paramMboRemote }, -3620476831865796680L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2824 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2826 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2828 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2830 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, MboSetRemote paramMboSetRemote)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2839 */       this.ref.invoke(this, $method_setValue_143, new Object[] { paramString, paramMboSetRemote }, -3537182409801315763L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2841 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2843 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2845 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2847 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, MaxType paramMaxType, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2856 */       this.ref.invoke(this, $method_setValue_144, new Object[] { paramString, paramMaxType, new Long(paramLong) }, -572289542766185319L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2858 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2860 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2862 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2864 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, short paramShort)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2873 */       this.ref.invoke(this, $method_setValue_145, new Object[] { paramString, new Short(paramShort) }, -592203831455696145L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2875 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2877 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2879 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2881 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, short paramShort, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2890 */       this.ref.invoke(this, $method_setValue_146, new Object[] { paramString, new Short(paramShort), new Long(paramLong) }, -6261639766806276381L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2892 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2894 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2896 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2898 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2907 */       this.ref.invoke(this, $method_setValue_147, new Object[] { paramString, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, 4990140584423208903L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2909 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2911 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2913 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2915 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, boolean paramBoolean, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2924 */       this.ref.invoke(this, $method_setValue_148, new Object[] { paramString, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE, new Long(paramLong) }, 8236575036597348343L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2926 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2928 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2930 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2932 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, byte[] paramArrayOfByte)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2941 */       this.ref.invoke(this, $method_setValue_149, new Object[] { paramString, paramArrayOfByte }, -5271144966979799580L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2943 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2945 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2947 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2949 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValue(String paramString, byte[] paramArrayOfByte, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2958 */       this.ref.invoke(this, $method_setValue_150, new Object[] { paramString, paramArrayOfByte, new Long(paramLong) }, 1093725565992944082L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2960 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2962 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2964 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2966 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValueNull(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2975 */       this.ref.invoke(this, $method_setValueNull_151, new Object[] { paramString }, -362562597341262986L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2977 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2979 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2981 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 2983 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void setValueNull(String paramString, long paramLong)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 2992 */       this.ref.invoke(this, $method_setValueNull_152, new Object[] { paramString, new Long(paramLong) }, 5998575739150575662L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 2994 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 2996 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 2998 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3000 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void sigOptionAccessAuthorized(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3009 */       this.ref.invoke(this, $method_sigOptionAccessAuthorized_153, new Object[] { paramString }, 4364214440166883643L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3011 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3013 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3015 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3017 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean sigopGranted(String paramString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3026 */       Object localObject = this.ref.invoke(this, $method_sigopGranted_154, new Object[] { paramString }, 2700460581989440209L);
/* 3027 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3029 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3031 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3033 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3035 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean sigopGranted(String paramString1, String paramString2)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3044 */       Object localObject = this.ref.invoke(this, $method_sigopGranted_155, new Object[] { paramString1, paramString2 }, 334852619251685037L);
/* 3045 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3047 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3049 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3051 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3053 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public HashMap sigopGranted(Set paramSet)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3062 */       Object localObject = this.ref.invoke(this, $method_sigopGranted_156, new Object[] { paramSet }, 5831994481824058998L);
/* 3063 */       return ((HashMap)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3065 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3067 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3069 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3071 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote smartFill(String paramString1, String paramString2, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3080 */       Object localObject = this.ref.invoke(this, $method_smartFill_157, new Object[] { paramString1, paramString2, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -935282078909453374L);
/* 3081 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3083 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3085 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3087 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3089 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote smartFind(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3098 */       Object localObject = this.ref.invoke(this, $method_smartFind_158, new Object[] { paramString1, paramString2, paramString3, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -1456117861212734379L);
/* 3099 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3101 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3103 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3105 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3107 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote smartFind(String paramString1, String paramString2, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3116 */       Object localObject = this.ref.invoke(this, $method_smartFind_159, new Object[] { paramString1, paramString2, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, 615902001724753702L);
/* 3117 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3119 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3121 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3123 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3125 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote smartFindByObjectName(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3134 */       Object localObject = this.ref.invoke(this, $method_smartFindByObjectName_160, new Object[] { paramString1, paramString2, paramString3, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, 9174066938115694658L);
/* 3135 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3137 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3139 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3141 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3143 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote smartFindByObjectName(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String[][] paramArrayOfString)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3152 */       Object localObject = this.ref.invoke(this, $method_smartFindByObjectName_161, new Object[] { paramString1, paramString2, paramString3, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE, paramArrayOfString }, -4824432416975490754L);
/* 3153 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3155 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3157 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3159 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3161 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public MboSetRemote smartFindByObjectNameDirect(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3170 */       Object localObject = this.ref.invoke(this, $method_smartFindByObjectNameDirect_162, new Object[] { paramString1, paramString2, paramString3, (paramBoolean) ? Boolean.TRUE : Boolean.FALSE }, -6639922775789924002L);
/* 3171 */       return ((MboSetRemote)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3173 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3175 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3177 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3179 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void startCheckpoint()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3188 */       this.ref.invoke(this, $method_startCheckpoint_163, null, 8105257734697951775L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3190 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3192 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3194 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3196 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean thisToBeUpdated()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 3205 */       Object localObject = this.ref.invoke(this, $method_thisToBeUpdated_164, null, 7976169955117495941L);
/* 3206 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3208 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3210 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 3212 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean toBeAdded()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 3221 */       Object localObject = this.ref.invoke(this, $method_toBeAdded_165, null, -8509333918488694701L);
/* 3222 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3224 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3226 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 3228 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean toBeDeleted()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 3237 */       Object localObject = this.ref.invoke(this, $method_toBeDeleted_166, null, 6603782709086639129L);
/* 3238 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3240 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3242 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 3244 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean toBeSaved()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 3253 */       Object localObject = this.ref.invoke(this, $method_toBeSaved_167, null, -4334682600408332364L);
/* 3254 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3256 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3258 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 3260 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean toBeUpdated()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 3269 */       Object localObject = this.ref.invoke(this, $method_toBeUpdated_168, null, 7772394697164632407L);
/* 3270 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3272 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3274 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 3276 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public boolean toBeValidated()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 3285 */       Object localObject = this.ref.invoke(this, $method_toBeValidated_169, null, -6229722679165061322L);
/* 3286 */       return ((Boolean)localObject).booleanValue();
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3288 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3290 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 3292 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void undelete()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3301 */       this.ref.invoke(this, $method_undelete_170, null, -3450598412706392512L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3303 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3305 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3307 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3309 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void unselect()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3318 */       this.ref.invoke(this, $method_unselect_171, null, -4036016416924417120L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3320 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3322 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3324 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3326 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public void validate()
/*      */     throws RemoteException, MXException
/*      */   {
/*      */     try
/*      */     {
/* 3335 */       this.ref.invoke(this, $method_validate_172, null, -8368415688081130249L);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3337 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3339 */       throw localRemoteException;
/*      */     } catch (MXException localMXException) {
/* 3341 */       throw localMXException;
/*      */     } catch (Exception localException) {
/* 3343 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }

/*      */   public Hashtable validateAttributes()
/*      */     throws RemoteException
/*      */   {
/*      */     try
/*      */     {
/* 3352 */       Object localObject = this.ref.invoke(this, $method_validateAttributes_173, null, 6372158466213621440L);
/* 3353 */       return ((Hashtable)localObject);
/*      */     } catch (RuntimeException localRuntimeException) {
/* 3355 */       throw localRuntimeException;
/*      */     } catch (RemoteException localRemoteException) {
/* 3357 */       throw localRemoteException;
/*      */     } catch (Exception localException) {
/* 3359 */       throw new UnexpectedException("undeclared checked exception", localException);
/*      */     }
/*      */   }
/*      */ }
