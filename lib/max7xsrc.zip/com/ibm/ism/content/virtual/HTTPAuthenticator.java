/*    */ package com.ibm.ism.content.virtual;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.net.Authenticator;
/*    */ import java.net.PasswordAuthentication;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXException;
/*    */ 














/*    */ public class HTTPAuthenticator extends Authenticator
/*    */ {
/* 26 */   static ThreadLocal<MboRemote> currentMbo = new ThreadLocal();
/*    */ 
/*    */   protected PasswordAuthentication getPasswordAuthentication()
/*    */   {
/*    */     try {
/* 31 */       System.out.println("Authentication requested");
/* 32 */       if (currentMbo.get() != null) {
/* 33 */         MboRemote mbo = (MboRemote)currentMbo.get();
/* 34 */         String userid = mbo.getString("HTTPUSER");
/* 35 */         String password = mbo.getString("HTTPPASSWORD");
/* 36 */         if ((userid.equals("")) || (password.equals(""))) {
/* 37 */           mbo.setValue("NEEDSAUTHENTICATION", true);
/* 38 */           return null;
/*    */         }
/*    */ 
/* 41 */         mbo.setValue("HTTPPASSWORD", "");
/* 42 */         return new PasswordAuthentication(userid, password.toCharArray());
/*    */       }
/*    */     }
/*    */     catch (MXException e)
/*    */     {
/* 47 */       e.printStackTrace();
/*    */     } catch (RemoteException e) {
/* 49 */       e.printStackTrace();
/*    */     }
/* 51 */     return super.getPasswordAuthentication();
/*    */   }
/*    */ }
