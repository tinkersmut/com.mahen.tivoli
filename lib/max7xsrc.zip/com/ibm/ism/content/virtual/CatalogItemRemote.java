package com.ibm.ism.content.virtual;

import java.rmi.RemoteException;
import java.util.List;
import javax.naming.AuthenticationException;
import psdi.mbo.NonPersistentMboRemote;
import psdi.util.MXException;

public abstract interface CatalogItemRemote extends NonPersistentMboRemote
{
  public abstract void installContent()
    throws RemoteException, MXException;

  public abstract void downloadContent()
    throws RemoteException, MXException, AuthenticationException;

  public abstract String loadLicense()
    throws RemoteException, MXException;

  public abstract boolean isDownloadComplete()
    throws RemoteException, MXException;

  public abstract boolean isInstallComplete()
    throws RemoteException, MXException;

  public abstract boolean isDownloadFailed()
    throws RemoteException, MXException;

  public abstract boolean isInstallFailed()
    throws RemoteException, MXException;

  public abstract String getDownloadMessages()
    throws RemoteException, MXException;

  public abstract String getInstallMessages()
    throws RemoteException, MXException;

  public abstract List<String> getJythonScripts()
    throws RemoteException, MXException;
}
