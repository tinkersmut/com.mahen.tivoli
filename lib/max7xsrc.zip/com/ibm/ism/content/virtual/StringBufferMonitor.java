/*    */ package com.ibm.ism.content.virtual;
/*    */ 
/*    */ import com.ibm.ism.contentinstaller.tools.monitors.IProgressMonitor;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.PrintStream;
/*    */ 













/*    */ public class StringBufferMonitor
/*    */   implements IProgressMonitor
/*    */ {
/*    */   ByteArrayOutputStream buffer;
/*    */   PrintStream out;
/*    */ 
/*    */   public StringBufferMonitor()
/*    */   {
/* 28 */     this.buffer = new ByteArrayOutputStream();
/* 29 */     this.out = new PrintStream(this.buffer);
/*    */   }

/*    */   public String getOutput() {
/* 33 */     return this.buffer.toString();
/*    */   }

/*    */   public void setError(String arg0) {
/* 37 */     this.out.println("ERROR: " + arg0 + "\n");
/*    */   }

/*    */   public void setError(String arg0, Throwable arg1) {
/* 41 */     this.out.println("ERROR: " + arg0 + "\n **********");
/* 42 */     arg1.printStackTrace(this.out);
/* 43 */     this.out.println(" **********");
/*    */   }

/*    */   public void setTask(String arg0) {
/* 47 */     this.out.println(arg0 + "\n");
/*    */   }
/*    */ }
