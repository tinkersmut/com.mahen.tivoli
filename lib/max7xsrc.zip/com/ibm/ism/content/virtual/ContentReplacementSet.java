/*    */ package com.ibm.ism.content.virtual;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.NonPersistentMboSet;
/*    */ import psdi.util.MXException;
/*    */ 




























/*    */ public class ContentReplacementSet extends NonPersistentMboSet
/*    */   implements ContentReplacementSetRemote
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ContentReplacementSet(MboServerInterface ms)
/*    */     throws RemoteException
/*    */   {
/* 46 */     super(ms);
/*    */   }







/*    */   protected Mbo getMboInstance(MboSet arg0)
/*    */     throws MXException, RemoteException
/*    */   {
/* 58 */     return new ContentReplacement(arg0);
/*    */   }
/*    */ }
