/*    */ package com.ibm.ism.content;
/*    */ 
/*    */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.logging.MXLoggerFactory;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 



















/*    */ public class ReplacementsTableBean extends DataBean
/*    */ {
/*    */   private static final String CLASSNAME = "ReplacementsTableBean";
/* 30 */   private final ContentCatalogLogger log = new ContentCatalogLogger(MXLoggerFactory.getLogger("maximo.service.SYSTEM.IBMCONTENTCATALOG"));
/*    */ 
/*    */   public int setvalue()
/*    */     throws MXException, RemoteException
/*    */   {
/* 39 */     String METHOD = "setvalue";
/* 40 */     this.log.debugEntry("ReplacementsTableBean", "setvalue");
/*    */ 
/* 42 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/* 43 */     String newValue = event.getValueString();
/* 44 */     int row = event.getRow();
/* 45 */     if (row >= 0) {
/* 46 */       getMbo(row).setValue("VALUE", newValue);
/*    */     }
/*    */     else {
/* 49 */       getMbo().setValue("VALUE", newValue);
/*    */     }
/* 51 */     refreshTable();
/* 52 */     this.log.debugExit("ReplacementsTableBean", "setvalue");
/* 53 */     return 1;
/*    */   }
/*    */ }
