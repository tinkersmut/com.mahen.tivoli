/*    */ package com.ibm.ism.content;
/*    */ 
/*    */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.logging.MXLoggerFactory;
/*    */ import psdi.webclient.system.beans.ResultsBean;
/*    */ 













/*    */ public class CatalogTableBean extends ResultsBean
/*    */ {
/*    */   private static final String CLASSNAME = "CatalogTableBean";
/*    */   private final ContentCatalogLogger log;
/*    */ 
/*    */   public CatalogTableBean()
/*    */   {
/* 29 */     this.log = new ContentCatalogLogger(MXLoggerFactory.getLogger("maximo.service.SYSTEM.IBMCONTENTCATALOG"));
/*    */   }

/*    */   protected void initialize() throws MXException, RemoteException
/*    */   {
/* 34 */     super.initialize();
/*    */   }

/*    */   public int selectrecord() throws MXException, RemoteException {
/* 38 */     int rc = super.selectrecord();
/* 39 */     return rc;
/*    */   }
/*    */ }
