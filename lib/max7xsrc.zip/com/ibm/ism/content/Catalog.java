/*     */ package com.ibm.ism.content;
/*     */ 
/*     */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*     */ import com.ibm.ism.contentinstaller.tools.SaxErrorHandler;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.Version;
/*     */ 



































/*     */ public class Catalog extends Mbo
/*     */   implements CatalogRemote
/*     */ {
/*     */   private static final String CLASSNAME = "Catalog";
/*  61 */   private final ContentCatalogLogger log = new ContentCatalogLogger(getMboLogger());
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String DESCRIPTION_ATTIBUTE = "DESCRIPTION";
/*     */   private static final String IBMCONTENTCATALOGID_ATTIBUTE = "IBMCONTENTCATALOGID";
/*     */   private static final String URL_ATTIBUTE = "URL";
/*     */ 
/*     */   public Catalog(MboSet ms)
/*     */     throws RemoteException
/*     */   {
/*  77 */     super(ms);
/*     */   }




/*     */   private String getUrlAttribute()
/*     */   {
/*  85 */     return getAttribute("URL");
/*     */   }




/*     */   private String getDescriptionAttribute()
/*     */   {
/*  93 */     return getAttribute("DESCRIPTION");
/*     */   }

/*     */   private String getAttribute(String attribute)
/*     */   {
/*  98 */     String METHOD = "getAttribute";
/*  99 */     this.log.debugEntry("Catalog", "getAttribute");
/*     */     try
/*     */     {
/* 102 */       return getString(attribute);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 106 */       this.log.debug("Catalog", "getAttribute", "Problem retriving attribute from MBO: " + attribute);
/*     */ 
/* 108 */       this.log.debugExit("Catalog", "getAttribute"); }
/* 109 */     return "";
/*     */   }

/*     */   public void parseCatalog(MboSetRemote ms, String urlString, String descString)
/*     */     throws IOException, SAXException, MXException
/*     */   {
/* 115 */     String METHOD = "parseCatalog";
/* 116 */     this.log.debugEntry("Catalog", "parseCatalog");
/*     */ 
/* 118 */     if ((urlString == null) || (urlString.trim().length() == 0)) {
/* 119 */       return;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 124 */       this.log.debug("Catalog", "parseCatalog", " >> Parse the content source and create the items.");
/* 125 */       this.log.debug("Catalog", "parseCatalog", " >> descString: " + descString);
/* 126 */       this.log.debug("Catalog", "parseCatalog", " >> urlString: " + urlString);
/*     */ 
/* 128 */       URL url = new URL(urlString);
/*     */ 
/* 130 */       InputStream in = url.openStream();
/* 131 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 132 */       dbf.setIgnoringComments(true);
/* 133 */       dbf.setIgnoringElementContentWhitespace(true);
/* 134 */       DocumentBuilder db = dbf.newDocumentBuilder();
/* 135 */       db.setErrorHandler(new SaxErrorHandler());
/* 136 */       Document doc = db.parse(new InputSource(in));
/* 137 */       this.log.debug("Catalog", "parseCatalog", " >> Parsed document: ");

/*     */ 
/* 140 */       Element rootElement = doc.getDocumentElement();
/*     */ 
/* 142 */       this.log.debug("Catalog", "parseCatalog", " >> GOT rootElement: ");
/*     */ 
/* 144 */       int itemSource = 2;
/* 145 */       if (rootElement.getNodeName().equalsIgnoreCase("response")) {
/* 146 */         itemSource = 1;
/*     */       }
/* 148 */       if (itemSource == 2)
/* 149 */         this.log.debug("Catalog", "parseCatalog", " >> Catalog Source: LOCAL");
/*     */       else {
/* 151 */         this.log.debug("Catalog", "parseCatalog", " >> Catalog Source: ISM");
/*     */       }
/*     */ 
/* 154 */       String informationurl = "";
/* 155 */       switch (itemSource)
/*     */       {
/*     */       case 1:
/* 158 */         informationurl = "<html><div><h3>Integrated Service Management Library</h3><a title='Tivoli software - Intelligent management' href='//www.ibm.com/software/tivoli'><img border='0' alt='Tivoli software - Intelligent management' src='../webclient/images/ISM_Library_Header.jpg'/></a><p><em>Integrated service management accelerators for a smarter infrastructure</em></p></div><div><h3>Content Source: " + descString + "</h3></div>" + "</html>";





/*     */ 
/* 165 */         break;

/*     */       default:
/* 168 */         informationurl = doc.getDocumentElement().getAttribute(ParseHelper.getCatalogInfoURLAttribute());
/* 169 */         if ((informationurl != null) && (!(informationurl.equals("")))) {
/* 170 */           informationurl = new URL(url, informationurl).toString();
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 175 */       setValue("infourl", informationurl, 2L);
/*     */ 
/* 177 */       String[] installedProducts = Version.getStringForHelpAboutDialog();
/*     */ 
/* 179 */       NodeList nodes = doc.getElementsByTagName(ParseHelper.getContentItemTag(itemSource));
/* 180 */       for (int lcv = 0; lcv < nodes.getLength(); ++lcv)
/*     */       {
/* 182 */         this.log.debug("Catalog", "parseCatalog", " >> Catalog items: " + nodes.getLength());
/*     */ 
/* 184 */         MboRemote item = ms.addAtEnd();
/* 185 */         item.setFlag(7L, true);
/* 186 */         Element element = (Element)nodes.item(lcv);

/*     */ 
/* 189 */         String name = element.getElementsByTagName(ParseHelper.getContentNameTag(itemSource)).item(0).getTextContent();
/* 190 */         String description = element.getElementsByTagName(ParseHelper.getContentDescriptionTag(itemSource)).item(0).getTextContent();
/* 191 */         String contentUrl = element.getElementsByTagName(ParseHelper.getContentURLTag(itemSource)).item(0).getTextContent();
/* 192 */         contentUrl = new URL(url, contentUrl).toString();
/*     */ 
/* 194 */         String homepage = element.getElementsByTagName(ParseHelper.getContentHomepageTag(itemSource)).item(0).getTextContent();
/* 195 */         homepage = new URL(url, homepage).toString();
/*     */ 
/* 197 */         String licenseUrl = element.getElementsByTagName(ParseHelper.getContentLicenseURLTag(itemSource)).item(0).getTextContent();
/* 198 */         if (!(licenseUrl.equals(""))) {
/* 199 */           licenseUrl = new URL(url, licenseUrl).toString();
/*     */         }
/* 201 */         StringBuffer installMessages = new StringBuffer();


/*     */ 
/* 205 */         NodeList prereqRules = null;
/*     */         String navcode;/*     */         String category;/*     */         String version;/*     */         String type;/* 206 */         switch (itemSource)

/*     */         {
/*     */         case 1:
/* 210 */           this.log.debug("Catalog", "parseCatalog", " >> Parse ISM Catalog");
/*     */ 
/* 212 */           navcode = element.getElementsByTagName(ParseHelper.getISMNavCodeTag()).item(0).getTextContent();
/* 213 */           navcode = navcode.trim();
/* 214 */           category = navcode;
/*     */ 
/* 216 */           Element versionElem = (Element)element.getElementsByTagName(ParseHelper.getISMVersionTag()).item(0);

/*     */ 
/* 219 */           version = versionElem.getElementsByTagName(ParseHelper.getISMVersionNameTag()).item(0).getTextContent();




/*     */           try
/*     */           {
/* 226 */             Element metaElement = (Element)element.getElementsByTagName(ParseHelper.getISMMetaTag()).item(0);
/* 227 */             String cdataContent = metaElement.getTextContent();
/* 228 */             String internalXML = cdataContent.replace("<![CDATA[", "");
/* 229 */             internalXML = internalXML.substring(0, internalXML.lastIndexOf("]]"));

/*     */ 
/* 232 */             InputStream metaStream = new ByteArrayInputStream(internalXML.trim().getBytes());
/* 233 */             DocumentBuilderFactory dbf2 = DocumentBuilderFactory.newInstance();
/* 234 */             dbf2.setIgnoringComments(true);
/* 235 */             dbf2.setIgnoringElementContentWhitespace(true);
/* 236 */             DocumentBuilder db2 = dbf.newDocumentBuilder();
/* 237 */             db2.setErrorHandler(new SaxErrorHandler());
/* 238 */             Document metaParser = db2.parse(metaStream);
/*     */ 
/* 240 */             Element contentInstallerChild = (Element)metaParser.getElementsByTagName(ParseHelper.getISMContentInstallerTag()).item(0);
/* 241 */             type = contentInstallerChild.getElementsByTagName(ParseHelper.getISMTypeTag()).item(0).getTextContent();
/* 242 */             prereqRules = contentInstallerChild.getElementsByTagName(ParseHelper.getISMProductPrereqTag());

/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 247 */             type = "mriu";
/* 248 */             prereqRules = null;
/*     */           }
/* 250 */           break;

/*     */         default:
/* 253 */           this.log.debug("Catalog", "parseCatalog", " >> Parse Local Catalog");
/* 254 */           navcode = null;
/* 255 */           category = element.getElementsByTagName(ParseHelper.getCatalogCategoryTag()).item(0).getTextContent();
/* 256 */           version = element.getElementsByTagName(ParseHelper.getCatalogVersionTag()).item(0).getTextContent();
/* 257 */           type = element.getElementsByTagName(ParseHelper.getCatalogTypeTag()).item(0).getTextContent();
/* 258 */           prereqRules = element.getElementsByTagName(ParseHelper.getCatalogPreReqTag());

/*     */         }
/*     */ 
/* 262 */         if ((prereqRules != null) && (prereqRules.getLength() > 0)) {
/* 263 */           this.log.debug("Catalog", "parseCatalog", " >> Catalog Rules: Checking");
/* 264 */           boolean installable = true;
/* 265 */           for (int ruleNum = 0; ruleNum < prereqRules.getLength(); ++ruleNum) {
/* 266 */             String rule = prereqRules.item(ruleNum).getTextContent();
/* 267 */             if ((!(rule.trim().equals(""))) && 

/* 269 */               (!(validateProductPrereq(installedProducts, rule)))) {
/* 270 */               installMessages.append("Failed prerequisite rule: [" + rule + "]\n");
/* 271 */               installable = false;
/*     */             }
/*     */ 
/* 274 */             item.setValue("INSTALLMESSAGES", installMessages.toString());
/*     */           }
/* 276 */           item.setValue("INSTALLABLE", installable);
/*     */         }
/*     */         else {
/* 279 */           this.log.debug("Catalog", "parseCatalog", " >> Catalog Rules: None");
/* 280 */           item.setValue("INSTALLABLE", true);
/*     */         }
/*     */ 
/* 283 */         item.setValue("NAME", name, 2L);
/* 284 */         item.setValue("DESCRIPTION", description, 2L);
/* 285 */         item.setValue("URL", contentUrl, 2L);
/* 286 */         item.setValue("VERSION", version, 2L);
/* 287 */         item.setValue("TYPE", type, 2L);
/* 288 */         item.setValue("NAVCODE", navcode, 2L);
/* 289 */         item.setValue("LICENSEURL", licenseUrl, 2L);
/* 290 */         item.setValue("INSTALLED", !(item.getMboSet("receipts").isEmpty()));
/* 291 */         item.setValue("URLTYPE", "URL");
/* 292 */         item.setValue("HOMEPAGE", homepage, 2L);
/* 293 */         item.setValue("CATEGORY", category, 2L);
/*     */ 
/* 295 */         this.log.info("Catalog", "parseCatalog", "Item created: ");
/* 296 */         this.log.info("Catalog", "parseCatalog", "NAME: " + name);
/* 297 */         this.log.info("Catalog", "parseCatalog", "DESCRIPTION: " + description);
/* 298 */         this.log.info("Catalog", "parseCatalog", "HOMEPAGE: " + homepage);
/* 299 */         this.log.info("Catalog", "parseCatalog", "URL: " + contentUrl);
/*     */       }
/*     */     }
/*     */     catch (MalformedURLException e) {
/* 303 */       this.log.debug("Catalog", "parseCatalog", "error", e);
/* 304 */       this.log.info("Catalog", "parseCatalog", "The url provided by the user: " + urlString + " is malformed. Continue anyway.");
/*     */     }
/*     */     catch (ParserConfigurationException e)
/*     */     {
/* 308 */       this.log.debug("Catalog", "parseCatalog", "error", e);
/* 309 */       this.log.info("Catalog", "parseCatalog", "The url content returned from: " + urlString + " is malformed. Continue anyway.");
/*     */     }
/* 311 */     this.log.debugExit("Catalog", "parseCatalog");
/*     */   }

/*     */   private boolean validateProductPrereq(String[] installedProducts, String rule)
/*     */   {
/* 316 */     String METHOD = "validateProductPrereq";
/* 317 */     this.log.debugEntry("Catalog", "validateProductPrereq");
/*     */ 
/* 319 */     Pattern pattern = Pattern.compile(rule);
/* 320 */     boolean matchFound = false;
/* 321 */     for (String product : installedProducts) {
/* 322 */       if (pattern.matcher(product).matches()) {
/* 323 */         matchFound = true;
/* 324 */         break;
/*     */       }
/*     */     }
/* 327 */     this.log.debugExit("Catalog", "validateProductPrereq");
/* 328 */     return matchFound;
/*     */   }


/*     */   public MboSetRemote getMboSet(String arg0)
/*     */     throws MXException, RemoteException
/*     */   {
/* 335 */     String METHOD = "getMboSet";
/* 336 */     this.log.debugEntry("Catalog", "getMboSet");
/*     */ 
/* 338 */     MboSetRemote ms = super.getMboSet(arg0);
/* 339 */     ms.clear();
/*     */ 
/* 341 */     if (arg0.equalsIgnoreCase("CATALOGITEMS")) {
/* 342 */       String urlString = getUrlAttribute();
/* 343 */       String descString = getDescriptionAttribute();
/*     */       try {
/* 345 */         parseCatalog(ms, urlString, descString);
/*     */       }
/*     */       catch (SAXException e) {
/* 348 */         this.log.error("Catalog", "getMboSet", "Encountered a problem parsing the catalog:");
/* 349 */         this.log.error("Catalog", "getMboSet", "error", e);
/* 350 */         e.printStackTrace();
/*     */       }
/*     */       catch (IOException e) {
/* 353 */         this.log.error("Catalog", "getMboSet", "Encountered a problem parsing the catalog:");
/* 354 */         this.log.error("Catalog", "getMboSet", "error", e);
/* 355 */         e.printStackTrace();
/*     */       }
/* 357 */       this.log.debugExit("Catalog", "getMboSet");
/* 358 */       return ms;
/*     */     }
/* 360 */     this.log.debugExit("Catalog", "getMboSet");
/* 361 */     return ms;
/*     */   }
/*     */ }
