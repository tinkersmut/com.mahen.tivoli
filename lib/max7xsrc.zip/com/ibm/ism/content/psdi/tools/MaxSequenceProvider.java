/*     */ package com.ibm.ism.content.psdi.tools;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ 





















































/*     */ public class MaxSequenceProvider
/*     */ {
/*     */   private static final int BUFFERSIZE = 100;
/*     */   private static final int SEARCHSIZE = 100000;
/*  49 */   private static long searchPoint = 100000L;
/*     */ 
/*  54 */   protected static HashMap<Object, MaxSeq> hm = new HashMap();
/*     */ 
/*  58 */   protected static HashMap<String, HashSet<String>> hmMain = new HashMap();
/*     */ 
/*  62 */   protected static HashMap<String, String> tableOrNot = new HashMap();
/*     */ 
/*     */   public void init(Connection con)
/*     */     throws Exception
/*     */   {
/*  80 */     init(con, true);
/*     */   }









/*     */   public void init(Connection conn, boolean loadAll)
/*     */     throws Exception
/*     */   {
/*  94 */     if (conn == null)
/*     */     {
/*  96 */       throw new Exception("Failed to initialize MaxSequenceProvider.  Connection is null.");
/*     */     }
/*     */ 
/*  99 */     String selStmt = "select tbname, name, maxreserved, maxvalue, range, sequencename from maxsequence";
/*     */ 
/* 101 */     if (!(loadAll))
/*     */     {
/* 103 */       selStmt = selStmt + " where tbname in ('MAXOBJECT','MAXOBJECTCFG','MAXTABLE','MAXTABLECFG'," + "'MAXVIEW','MAXVIEWCFG','MAXVIEWCOLUMN','MAXVIEWCOLUMNCFG','MAXATTRIBUTE','MAXATTRIBUTECFG')";





/*     */     }
/*     */ 
/* 111 */     Statement stmt = null;

/*     */     try
/*     */     {
/* 115 */       stmt = conn.createStatement();
/*     */ 
/* 117 */       ResultSet rs = stmt.executeQuery(selStmt);
/* 118 */       while (rs.next() == true)
/*     */       {
/* 120 */         MaxSeq mseq = new MaxSeq();
/*     */ 
/* 122 */         mseq.tbname = rs.getString("tbname");
/* 123 */         mseq.name = rs.getString("name");
/* 124 */         mseq.seqName = rs.getString("sequencename");
/*     */ 
/* 126 */         getNextMaxSequence(conn, mseq.tbname, mseq.name, mseq);

/*     */ 
/* 129 */         String key = mseq.tbname + "_" + mseq.name.toUpperCase();
/* 130 */         hm.put(key, mseq);

/*     */ 
/* 133 */         HashSet xref = null;
/* 134 */         if (hmMain.containsKey(mseq.seqName))
/* 135 */           xref = (HashSet)hmMain.get(mseq.seqName);
/*     */         else
/* 137 */           xref = new HashSet();
/* 138 */         xref.add(key);
/* 139 */         hmMain.put(mseq.seqName, xref);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 148 */       if (stmt != null)
/* 149 */         stmt.close();
/*     */     }
/*     */   }









/*     */   public synchronized long getUniqueID(Connection con, String tbname, String name)
/*     */     throws Exception
/*     */   {
/* 164 */     if (con == null)
/*     */     {
/* 166 */       throw new Exception("Failed to get unique id.  Connection is null.");
/*     */     }
/*     */ 
/* 169 */     String key = tbname + "_" + name.toUpperCase();
/*     */ 
/* 171 */     populateTableOrNot(con, tbname);

/*     */ 
/* 174 */     MaxSeq mseq = (MaxSeq)hm.get(key);
/*     */ 
/* 176 */     if (mseq == null)
/*     */     {
/* 178 */       mseq = new MaxSeq();
/* 179 */       mseq.tbname = tbname.toLowerCase();
/* 180 */       mseq.name = name.toLowerCase();
/*     */ 
/* 182 */       getNextMaxSequence(con, mseq.tbname, mseq.name, mseq);

/*     */ 
/* 185 */       String lkey = mseq.tbname + "_" + mseq.name.toUpperCase();
/* 186 */       hm.put(lkey, mseq);

/*     */ 
/* 189 */       HashSet xref = null;
/* 190 */       if (hmMain.containsKey(mseq.seqName))
/* 191 */         xref = (HashSet)hmMain.get(mseq.seqName);
/*     */       else
/* 193 */         xref = new HashSet();
/* 194 */       xref.add(lkey);

/*     */ 
/* 197 */       String selStmt = "select tbname, name, maxreserved, maxvalue, range, sequencename, rowstamp from maxsequence  where sequencename = '" + mseq.seqName + "' and (tbname != '" + tbname.toUpperCase() + "' or name != '" + name.toUpperCase() + "')";

/*     */ 
/* 200 */       Statement stmt = null;

/*     */       try
/*     */       {
/* 204 */         stmt = con.createStatement();
/*     */ 
/* 206 */         ResultSet rs = stmt.executeQuery(selStmt);
/* 207 */         while (rs.next())
/*     */         {
/* 209 */           String testTbname = rs.getString("tbname");
/* 210 */           String testColname = rs.getString("name");
/* 211 */           String testKey = testTbname + "_" + testColname.toUpperCase();
/*     */ 
/* 213 */           if (!(hm.containsKey(testKey)))
/*     */           {
/* 215 */             MaxSeq mseq2 = new MaxSeq();
/*     */ 
/* 217 */             mseq2.tbname = testTbname;
/* 218 */             mseq2.name = testColname;
/* 219 */             mseq2.seqName = rs.getString("sequencename");
/* 220 */             mseq2.rowstamp = rs.getString("rowstamp");
/*     */ 
/* 222 */             getNextMaxSequence(con, mseq2.tbname, mseq2.name, mseq2);

/*     */ 
/* 225 */             hm.put(testKey, mseq2);

/*     */ 
/* 228 */             xref.add(testKey);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */       finally
/*     */       {
/* 239 */         if (stmt != null) {
/* 240 */           stmt.close();
/*     */         }
/*     */       }
/*     */ 
/* 244 */       hmMain.put(mseq.seqName, xref);



/*     */     }
/*     */     else
/*     */     {
/* 251 */       refreshMaxSequence(con, mseq.tbname, mseq.name, mseq);


/*     */     }
/*     */ 
/* 256 */     if ((mseq.curValue >= 2147483647L) || (mseq.maxReserved >= 2147483647L) || (mseq.maxValue > 0L))

/*     */     {
/* 259 */       if ((mseq.maxValue > 0L) && (mseq.curValue >= mseq.startValue + 100L))

/*     */       {
/* 262 */         getNextMaxSequenceFromBufferedRange(con, tbname, name, mseq);

/*     */       }
/* 265 */       else if ((mseq.curValue >= mseq.range) || (mseq.maxValue >= mseq.range))
/*     */       {
/* 267 */         getUnusedMaxSequence(con, tbname, name, mseq);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 273 */       if (mseq.curValue >= mseq.startValue + 100L)

/*     */       {
/* 276 */         getNextMaxSequence(con, tbname, name, mseq);
/*     */       }
/*     */ 
/* 279 */       if (mseq.curValue >= 2147483647L)
/*     */       {
/* 281 */         getUnusedMaxSequence(con, tbname, name, mseq);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 286 */     mseq.curValue += 1L;
/* 287 */     if (mseq.curValue >= 2147483647L)
/*     */     {
/* 289 */       mseq.curValue = 2147483647L;
/*     */     }
/*     */ 
/* 292 */     return mseq.curValue;
/*     */   }








/*     */   private void populateTableOrNot(Connection con, String tbname)
/*     */     throws Exception
/*     */   {
/* 305 */     Statement stmt = null;

/*     */     try
/*     */     {
/* 309 */       if (tableOrNot.containsKey(tbname.toLowerCase())) {
/*     */         return;
/*     */       }
/* 312 */       String tableStr = "select name from dbo.sysobjects where xtype = 'U' and name = '" + tbname.toLowerCase() + "' and user_name(uid) = 'dbo'";
/* 313 */       stmt = con.createStatement();
/* 314 */       ResultSet rs = stmt.executeQuery(tableStr);
/* 315 */       if (rs.next())
/* 316 */         tableOrNot.put(tbname.toLowerCase(), "Y");
/*     */       else {
/* 318 */         tableOrNot.put(tbname.toLowerCase(), "N");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 324 */       throw new Exception("Exception during tablecheck -- table (" + tbname + ")");
/*     */     }
/*     */     finally
/*     */     {
/* 328 */       if (stmt != null)
/* 329 */         stmt.close();
/*     */     }
/*     */   }









/*     */   private boolean isCurrentValueUnique(Connection con, long curVal, String tbname, String name, String seqName)
/*     */     throws Exception
/*     */   {
/* 344 */     boolean isUnique = true;
/* 345 */     Statement stmt = null;
/* 346 */     Statement stmt2 = null;
/*     */     try
/*     */     {
/* 349 */       String isTable = (String)tableOrNot.get(tbname.toLowerCase());
/* 350 */       if ((isTable != null) && (isTable.equalsIgnoreCase("N"))) {
/* 351 */         int i = 1;
/*     */         return i;/*     */       }
/* 353 */       String selStmt = "select  " + name.toLowerCase() + " from " + tbname.toLowerCase() + " where " + name.toLowerCase() + "=" + curVal;
/*     */ 
/* 355 */       stmt = con.createStatement();
/* 356 */       ResultSet rs = stmt.executeQuery(selStmt);
/* 357 */       if (rs.next())
/*     */       {
/* 359 */         isUnique = false;
/*     */       }
/* 361 */       else if (seqName != null)

/*     */       {
/* 364 */         HashSet xref = (HashSet)hmMain.get(seqName);
/* 365 */         if ((xref != null) && (xref.size() > 1))
/*     */         {
/* 367 */           Iterator i = xref.iterator();
/* 368 */           while (i.hasNext())
/*     */           {
/* 370 */             String key = (String)i.next();
/* 371 */             int idx = key.indexOf("_");
/* 372 */             String tempTbname = key.substring(0, idx);
/* 373 */             String tempColname = key.substring(idx + 1);
/* 374 */             if ((!(tbname.equalsIgnoreCase(tempTbname))) || (!(name.equalsIgnoreCase(tempColname))))
/*     */             {
/* 376 */               selStmt = "select  " + tempColname.toLowerCase() + " from " + tempTbname.toLowerCase() + " where " + tempColname.toLowerCase() + "=" + curVal;
/* 377 */               stmt2 = con.createStatement();
/* 378 */               rs = stmt2.executeQuery(selStmt);
/* 379 */               if (rs.next())
/* 380 */                 isUnique = false;
/* 381 */               stmt2.close();
/*     */             }
/* 383 */             if (!(isUnique)) {
/*     */               break;
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 398 */       if (stmt != null)
/* 399 */         stmt.close();
/* 400 */       if (stmt2 != null)
/* 401 */         stmt2.close();
/*     */     }
/* 403 */     return isUnique;
/*     */   }

/*     */   private void refreshMaxSequence(Connection con, String tbname, String name, MaxSeq mseq)
/*     */     throws Exception
/*     */   {
/* 409 */     Statement stmt = null;
/* 410 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 413 */       stmt = con.createStatement();
/* 414 */       String selStmt = "select maxreserved, maxvalue, range, rowstamp from maxsequence where tbname = '" + tbname.toUpperCase() + "' and name = '" + name.toUpperCase() + "'";

/*     */ 
/* 417 */       rs = stmt.executeQuery(selStmt);
/* 418 */       if (rs.next() == true)

/*     */       {
/* 421 */         String rowstamp = rs.getString("rowstamp");
/*     */ 
/* 423 */         if (rowstamp.equals(mseq.rowstamp)) {
/*     */           return;
/*     */         }
/*     */ 
/* 427 */         getNextMaxSequence(con, tbname, name, mseq);


/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 438 */       if (rs != null)
/* 439 */         rs.close();
/* 440 */       if (stmt != null)
/* 441 */         stmt.close();
/*     */     }
/*     */   }








/*     */   private void getNextMaxSequence(Connection con, String tbname, String name, MaxSeq mseq)
/*     */     throws Exception
/*     */   {
/* 455 */     Statement stmt = null;


/*     */     try
/*     */     {
/* 460 */       String updStmt = "update maxsequence set maxreserved = maxreserved +100 where tbname = '" + tbname.toUpperCase() + "' and name = '" + name.toUpperCase() + "'";

/*     */ 
/* 463 */       stmt = con.createStatement();
/* 464 */       int row = stmt.executeUpdate(updStmt);
/*     */ 
/* 466 */       if (row > 0)
/*     */       {
/* 468 */         String selStmt = "select maxreserved, maxvalue, range, sequencename, rowstamp from maxsequence where tbname = '" + tbname.toUpperCase() + "' and name = '" + name.toUpperCase() + "'";

/*     */ 
/* 471 */         ResultSet rs = stmt.executeQuery(selStmt);
/* 472 */         if (rs.next() == true)
/*     */         {
/* 474 */           mseq.maxReserved = rs.getLong("maxreserved");
/* 475 */           mseq.maxValue = rs.getLong("maxvalue");
/* 476 */           mseq.range = rs.getLong("range");
/* 477 */           mseq.seqName = rs.getString("sequencename");
/* 478 */           mseq.rowstamp = rs.getString("rowstamp");

/*     */ 
/* 481 */           if (mseq.maxReserved >= 2147483647L)
/* 482 */             mseq.curValue = 2147483647L;
/*     */           else
/* 484 */             mseq.curValue = (mseq.maxReserved - 100L);
/* 485 */           mseq.startValue = mseq.curValue;
/*     */         }
/* 487 */         con.commit();



/*     */       }
/*     */       else
/*     */       {
/* 494 */         String selStmt = "select max(" + name.toLowerCase() + ") from " + tbname.toLowerCase();
/*     */ 
/* 496 */         ResultSet rs = stmt.executeQuery(selStmt);
/* 497 */         int maxVal = 0;
/*     */ 
/* 499 */         if (rs.next())
/*     */         {
/* 501 */           maxVal = rs.getInt(1);
/*     */         }
/* 503 */         mseq.curValue = maxVal;
/* 504 */         mseq.startValue = mseq.curValue;

/*     */ 
/* 507 */         if (2147483647 - maxVal <= 100)
/* 508 */           mseq.maxReserved = 2147483647L;
/*     */         else {
/* 510 */           mseq.maxReserved = (maxVal + 100);

/*     */         }
/*     */ 
/* 514 */         String sequenceName = tbname + name + "seq";
/*     */ 
/* 516 */         if (sequenceName.length() > 21)
/*     */         {
/* 518 */           sequenceName = null;
/* 519 */           if (tbname.length() > 10)
/* 520 */             sequenceName = tbname.substring(0, 10);
/*     */           else
/* 522 */             sequenceName = tbname;
/* 523 */           if (name.length() > 7)
/* 524 */             sequenceName = sequenceName + name.substring(0, 7);
/*     */           else {
/* 526 */             sequenceName = sequenceName + name;
/*     */           }
/* 528 */           sequenceName = sequenceName + "seq";


/*     */         }
/*     */ 
/* 533 */         mseq.seqName = sequenceName;
/*     */ 
/* 535 */         String insStmt = "insert into maxsequence (tbname, name, sequencename,maxreserved) values ('" + tbname.toUpperCase() + "','" + name.toUpperCase() + "'," + sequenceName.toUpperCase() + "," + mseq.maxReserved + ")";


/*     */ 
/* 539 */         stmt.execute(insStmt);
/*     */ 
/* 541 */         con.commit();


/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 552 */       if (stmt != null)
/* 553 */         stmt.close();
/*     */     }
/*     */   }













/*     */   private void getUnusedMaxSequence(Connection con, String tbname, String name, MaxSeq mseq)
/*     */     throws Exception
/*     */   {
/* 572 */     Statement stmt = null;

/*     */     try
/*     */     {
/* 576 */       String isTable = (String)tableOrNot.get(tbname.toLowerCase());
/*     */ 
/* 578 */       if ((isTable != null) && (isTable.equalsIgnoreCase("N")))
/*     */       {
/* 580 */         System.out.println("Table name " + tbname + " is not a table. Adjust maxsequence entry manually");
/*     */       }
/*     */ 
/* 583 */       stmt = con.createStatement();
/*     */ 
/* 585 */       String selStmt = "select max(" + name.toLowerCase() + ") from " + tbname.toLowerCase() + " where " + name.toLowerCase() + " < " + searchPoint;

/*     */ 
/* 588 */       ResultSet rs = stmt.executeQuery(selStmt);
/* 589 */       if (rs.next() == true)
/*     */       {
/* 591 */         long id = rs.getLong(1);



/*     */ 
/* 596 */         if ((id == searchPoint) || (searchPoint - id < 100L))
/*     */         {
/* 598 */           searchPoint += 100000L;
/* 599 */           if (searchPoint >= 2147483647L)
/*     */           {
/* 601 */             stmt.close();
/* 602 */             searchPoint = 2147483647L;
/* 603 */             if (id == searchPoint)

/*     */             {
/* 606 */               mseq.curValue = 2147483647L;
/* 607 */               mseq.startValue = mseq.curValue;
/*     */               return;/*     */             }
/*     */           }
/*     */ 
/* 611 */           stmt.close();
/*     */ 
/* 613 */           getUnusedMaxSequence(con, tbname, name, mseq);
/*     */           return;
/*     */         }
/* 616 */         mseq.curValue = id;
/* 617 */         mseq.startValue = id;
/*     */ 
/* 619 */         mseq.maxValue = (mseq.curValue + 100L);
/* 620 */         mseq.range = searchPoint;
/*     */ 
/* 622 */         String updStmt = "update maxsequence set maxvalue =" + mseq.maxValue + ", range =" + mseq.range + " where sequencename in (select sequencename from maxsequence " + " where tbname ='" + tbname.toUpperCase() + "' and name ='" + name.toUpperCase() + "')";


/*     */ 
/* 626 */         stmt.executeUpdate(updStmt);
/*     */ 
/* 628 */         con.commit();

/*     */       }
/*     */       else
/*     */       {
/* 633 */         mseq.curValue = 0L;
/* 634 */         mseq.startValue = 0L;
/* 635 */         throw new Exception("Unable to find maxid for table :" + tbname + ", column :" + name);





/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 649 */       if (stmt != null)
/* 650 */         stmt.close();
/*     */     }
/*     */   }

/*     */   private void getNextMaxSequenceFromBufferedRange(Connection con, String tbname, String name, MaxSeq mseq) throws Exception
/*     */   {
/* 656 */     Statement stmt = null;


/*     */     try
/*     */     {
/* 661 */       String updStmt = "update maxsequence set maxvalue = maxvalue +100 where sequencename in (select sequencename from maxsequence  where tbname = '" + tbname.toUpperCase() + "' and name = '" + name.toUpperCase() + "')";


/*     */ 
/* 665 */       stmt = con.createStatement();
/* 666 */       int row = stmt.executeUpdate(updStmt);
/*     */ 
/* 668 */       if (row > 0)
/*     */       {
/* 670 */         String selStmt = "select maxreserved, maxvalue, range, sequencename, rowstamp from maxsequence where tbname = '" + tbname.toUpperCase() + "' and name = '" + name.toUpperCase() + "'";

/*     */ 
/* 673 */         ResultSet rs = stmt.executeQuery(selStmt);
/* 674 */         if (rs.next() == true)
/*     */         {
/* 676 */           mseq.maxReserved = rs.getLong("maxreserved");
/* 677 */           mseq.maxValue = rs.getLong("maxvalue");
/* 678 */           mseq.range = rs.getLong("range");
/* 679 */           mseq.seqName = rs.getString("sequencename");

/*     */ 
/* 682 */           if (mseq.maxValue >= 2147483647L)
/* 683 */             mseq.curValue = 2147483647L;
/*     */           else
/* 685 */             mseq.curValue = (mseq.maxValue - 100L);
/* 686 */           mseq.startValue = mseq.curValue;
/* 687 */           mseq.rowstamp = rs.getString("rowstamp");
/*     */         }
/*     */ 
/* 690 */         con.commit();
/*     */       }
/*     */       else
/*     */       {
/* 694 */         mseq.curValue = 0L;
/* 695 */         mseq.startValue = 0L;
/* 696 */         con.rollback();
/* 697 */         throw new Exception("Unable to find sequence entry for table (" + tbname + ") and column (" + name + ")");

/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 707 */       if (stmt != null)
/* 708 */         stmt.close();  }  } 
/*     */   class MaxSeq { public String tbname;/*     */     public String name;/*     */     public String seqName;/*     */     public long maxReserved;/*     */     public long maxValue;/*     */     public long range;
/*     */     public long curValue;
/*     */     public long startValue;
/*     */     public String rowstamp;
/*     */ 
/*     */     MaxSeq() { this.tbname = "";
/* 715 */       this.name = "";
/* 716 */       this.seqName = "";
/*     */     }
/*     */   }
/*     */ }
