/*     */ package com.ibm.ism.content.psdi.tools;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ 













































/*     */ public class MaxSequence
/*     */ {
/*  51 */   private static MaxSequenceProvider msp = null;
/*     */ 
/*     */   public static synchronized long generateKey(Connection con, String tbName, String name)
/*     */     throws MXException
/*     */   {
/*  63 */     long oracleSeq = 0L;

/*     */     try
/*     */     {
/*  67 */       String dbName = con.getMetaData().getDatabaseProductName();
/*     */ 
/*  69 */       if (dbName.equalsIgnoreCase("Oracle"))
/*     */       {
/*  71 */         oracleSeq = getOracleSequence(con, tbName, name);
/*     */       }
/*  73 */       else if (dbName.equalsIgnoreCase("Microsoft SQL Server"))
/*     */       {
/*  75 */         oracleSeq = getSqlServerSequence(con, tbName, name);
/*     */       }
/*  77 */       else if (dbName.startsWith("DB2"))
/*     */       {
/*  79 */         oracleSeq = getDb2Sequence(con, tbName, name);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*  85 */       Object[] params = { new Integer(e.getErrorCode()).toString() };
/*  86 */       throw new MXSystemException("system", "sql", params, e);
/*     */     }
/*     */ 
/*  89 */     return oracleSeq;
/*     */   }

/*     */   private static long getOracleSequence(Connection con, String tbName, String name)
/*     */     throws MXException
/*     */   {
/*  95 */     String seqName = null;

/*     */ 
/*  98 */     long oracleSeq = 0L;
/*  99 */     Statement stmt = null;
/*     */     try
/*     */     {
/* 102 */       String sql = "select sequencename from maxsequence where tbname='" + tbName.toUpperCase() + "' and name='" + name.toUpperCase() + "'";
/* 103 */       stmt = con.createStatement();
/* 104 */       ResultSet rs = stmt.executeQuery(sql);
/* 105 */       if ((rs != null) && (rs.next()))
/*     */       {
/* 107 */         seqName = rs.getString(1);
/*     */       }
/* 109 */       oracleSeq = getNextOracleSequence(con, seqName);
/* 110 */       stmt.close();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */       try
/*     */       {
/* 116 */         if (stmt != null)
/* 117 */           stmt.close();
/*     */       }
/*     */       catch (Exception ex1)
/*     */       {
/*     */       }
/* 122 */       Object[] params = { seqName };
/* 123 */       throw new MXSystemException("system", "seqnotexist", params);
/*     */     }
/* 125 */     return oracleSeq;
/*     */   }

/*     */   private static long getNextOracleSequence(Connection con, String seqName)
/*     */     throws MXException
/*     */   {
/* 131 */     long oracleSeq = 0L;
/* 132 */     Statement s = null;
/* 133 */     ResultSet rs = null;

/*     */     try
/*     */     {
/* 137 */       String query = "select " + seqName + ".NEXTVAL from DUMMY_TABLE";
/* 138 */       s = con.createStatement();


/*     */ 
/* 142 */       s.execute(query);
/*     */ 
/* 144 */       rs = s.getResultSet();
/*     */ 
/* 146 */       if (rs.next())
/*     */       {
/* 148 */         oracleSeq = rs.getLong(1);
/*     */       }
/*     */ 
/* 151 */       s.close();
/* 152 */       rs.close();
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */       try {
/* 157 */         if (rs != null) {
/* 158 */           rs.close();
/*     */         }
/* 160 */         if (s != null)
/* 161 */           s.close();
/*     */       } catch (Exception ex) {
/*     */       }
/* 164 */       Object[] params = { seqName };
/* 165 */       throw new MXSystemException("system", "seqnotexist", params);
/*     */     }
/*     */ 
/* 168 */     return oracleSeq;
/*     */   }

/*     */   private static long getSqlServerSequence(Connection con, String tbname, String name) throws MXException
/*     */   {
/*     */     try
/*     */     {
/* 175 */       if (msp == null)
/*     */       {
/* 177 */         msp = new MaxSequenceProvider();
/* 178 */         msp.init(con);
/*     */       }
/*     */ 
/* 181 */       return msp.getUniqueID(con, tbname, name);

/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 186 */       Object[] params = { new Integer(0).toString() };
/* 187 */       throw new MXSystemException("system", "sql", params, e);
/*     */     }
/*     */   }


/*     */   private static long getDb2Sequence(Connection con, String tbName, String name)
/*     */     throws MXException
/*     */   {
/* 195 */     String seqName = null;
/*     */ 
/* 197 */     long seq = 0L;
/* 198 */     Statement stmt = null;

/*     */     try
/*     */     {
/* 202 */       String sql = "select sequencename from maxsequence where tbname='" + tbName + "' and name='" + name + "'";
/* 203 */       stmt = con.createStatement();
/* 204 */       ResultSet rs = stmt.executeQuery(sql);
/* 205 */       if ((rs != null) && (rs.next()))
/*     */       {
/* 207 */         seqName = rs.getString(1);
/*     */       }
/* 209 */       seq = getNextDb2Sequence(con, seqName);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */       Object[] params;
/* 214 */       throw new MXSystemException("system", "seqnotexist", params);

/*     */     }
/*     */     finally
/*     */     {
/* 219 */       if (stmt != null)
/*     */       {
/*     */         try
/*     */         {
/* 223 */           stmt.close();
/*     */         }
/*     */         catch (Exception e) {
/*     */         }
/*     */       }
/*     */     }
/* 229 */     return seq;
/*     */   }

/*     */   private static long getNextDb2Sequence(Connection con, String seqName)
/*     */     throws MXException
/*     */   {
/* 235 */     long seq = 0L;
/* 236 */     Statement s = null;
/* 237 */     ResultSet rs = null;

/*     */     try
/*     */     {
/* 241 */       String query = "select NEXTVAL for " + seqName + " from DUMMY_TABLE";
/* 242 */       s = con.createStatement();


/*     */ 
/* 246 */       s.execute(query);
/*     */ 
/* 248 */       rs = s.getResultSet();
/*     */ 
/* 250 */       if (rs.next())
/*     */       {
/* 252 */         seq = rs.getLong(1);
/*     */       }
/*     */ 
/* 255 */       s.close();
/* 256 */       rs.close();
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */       try {
/* 261 */         if (rs != null) {
/* 262 */           rs.close();
/*     */         }
/* 264 */         if (s != null)
/* 265 */           s.close();
/*     */       } catch (Exception ex) {
/*     */       }
/* 268 */       Object[] params = { seqName };
/* 269 */       throw new MXSystemException("system", "seqnotexist", params);
/*     */     }
/*     */ 
/* 272 */     return seq;
/*     */   }







/*     */   static MaxSequenceProvider getMaxSequenceProvider()
/*     */   {
/* 283 */     return msp;
/*     */   }
/*     */ }
