/*      */ package com.ibm.ism.content.psdi.webclient.upgrade;
/*      */ 
/*      */ import com.ibm.ism.content.psdi.tools.MaxSequence;
/*      */ import com.ibm.ism.content.virtual.CatalogItem;
/*      */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringReader;
/*      */ import java.lang.reflect.Method;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;/*      */ import java.sql.DatabaseMetaData;/*      */ import java.sql.Driver;/*      */ import java.sql.DriverManager;/*      */ import java.sql.PreparedStatement;/*      */ import java.sql.ResultSet;/*      */ import java.sql.SQLException;/*      */ import java.sql.Statement;/*      */ import java.util.Collection;/*      */ import java.util.Hashtable;/*      */ import java.util.Iterator;/*      */ import java.util.LinkedList;/*      */ import java.util.List;/*      */ import java.util.Properties;/*      */ import javax.xml.parsers.DocumentBuilder;/*      */ import javax.xml.parsers.DocumentBuilderFactory;/*      */ import oracle.sql.CLOB;/*      */ import org.w3c.dom.Document;/*      */ import org.w3c.dom.Element;/*      */ import org.w3c.dom.NamedNodeMap;/*      */ import org.w3c.dom.Node;/*      */ import org.w3c.dom.NodeList;/*      */ import org.xml.sax.InputSource;/*      */ import psdi.util.DBConnect;/*      */ import psdi.util.MXFormat;/*      */ import psdi.util.MXProperties;/*      */ 
/*      */ public class MXApplyTransactions extends MXUpgradeUtility
/*      */ {
/*      */   private static final String CLASSNAME = "MXApplyTransactions";
/*   49 */   private static String mxsFileName = null;
/*      */   private boolean updateMAXLabels;
/*      */   private String appType;
/*      */   private String originalApp;
/*      */   private boolean overWrite;
/*      */   private String appName;
/*      */   private Element appDocument;
/*   67 */   private static final Class[] actionMethodParamTypes = { Element.class, Element.class };
/*      */   private static final String UPDATE_MAXLABELS = "update maxlabels set value=? where app=? and id=? and LOWER(property)=?";
/*      */   private static final String DELETE_MAXLABELS = "delete from maxlabels where app=? and id=? and LOWER(property)=?";
/*      */   private static final String INSERT_MAXLABELS = "insert into maxlabels (value,app,id,property,maxlabelsid) values (?,?,?,?,?)";
/*      */   private static final String UPDATE_MAXPRESENTATION = "update maxpresentation set presentation = ? where app = ?";
/*      */   private static final String INSERT_MAXPRESENTATION = "insert into maxpresentation (presentation,app,maxpresentationid) values (?,?,?)";
/*      */   private static final String DEFAULT_PROPERTIES_FILENAME = "maximo.properties";
/*      */   private static final String DEFAULT_TRANSACTION_FILENAME = "transactions.xml";
/*   77 */   private static String DEFAULT_TOOLKIT_FILENAME = "/resources/presentations/system/toolbox.xml";
/*      */   private String sourceApp;
/*      */   public String sqlTerm;
/*      */   public String commentFlag;
/*      */   private String targetApp;
/*      */   private Connection con;
/*      */   private Document transactionDocument;
/*      */   private boolean updateLabels;
/*      */   Collection<PropertyChange> maxLabelChanges;
/*  141 */   private static boolean DEBUG = false;
/*      */   private Hashtable<String, Element> appIndex;
/*      */   private Element templateNewAppDoc;
/*      */   private boolean propsLoaded;
/*      */ 
/*      */   public MXApplyTransactions()
/*      */   {
/*   50 */     this.updateMAXLabels = true;
/*      */ 
/*   52 */     this.appType = null;
/*   53 */     this.originalApp = null;
/*      */ 
/*   55 */     this.overWrite = true;

/*      */   public void setOverWrite(boolean b)
/*      */   {
/*   59 */     this.overWrite = b;
/*      */   }
/*      */ 
/*   62 */     this.appName = null;
/*      */ 
/*   64 */     this.appDocument = null;













/*      */ 
/*   79 */     this.sourceApp = null;
/*      */ 
/*   81 */     this.sqlTerm = ";";
/*   82 */     this.commentFlag = "-- ";

/*      */   public void setSourceApp(String s)
/*      */   {
/*   86 */     this.sourceApp = s;
/*      */   }
/*      */ 
/*   89 */     this.targetApp = null;

/*      */   public void setTargetApp(String s)
/*      */   {
/*   93 */     this.targetApp = s;
/*      */   }
/*      */ 
/*   96 */     this.con = null;

/*      */   public void setConnection(Connection c)
/*      */   {
/*  100 */     this.con = c;

/*      */     try
/*      */     {
/*  104 */       String dbVendor = this.con.getMetaData().getDatabaseProductName().toUpperCase();
/*  105 */       if (dbVendor.indexOf("MICROSOFT") >= 0)
/*  106 */         this.sqlTerm = "go";
/*      */     }
/*      */     catch (SQLException e)
/*      */     {
/*      */     }/*      */   }
/*      */ 
/*  112 */     this.transactionDocument = null;
/*      */   public void openTransactionDocument(String filename)
/*      */     throws Exception
/*      */   {
/*  116 */     this.transactionDocument = parse(filename);
/*      */   }

/*      */   public void setTransactionStream(String filename) throws Exception
/*      */   {
/*  121 */     openTransactionDocument(filename);
/*      */   }

/*      */   public void setTransactionStream(InputStream is) throws Exception
/*      */   {
/*  126 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*  127 */     dbf.setValidating(false);
/*  128 */     this.transactionDocument = dbf.newDocumentBuilder().parse(is);
/*      */   }
/*      */ 
/*  131 */     this.updateLabels = true;

/*      */   public void setUpdateLabels(boolean b)
/*      */   {
/*  135 */     this.updateLabels = b;
/*      */   }

/*      */ 
/*  139 */     this.maxLabelChanges = null;



/*      */   public void setDebug(boolean b)
/*      */   {
/*  145 */     DEBUG = b;
/*      */   }

/*      */ 
/*  149 */     this.appIndex = null;





/*      */ 
/*  156 */     this.templateNewAppDoc = null;
/*      */   private void updateToolboxTemplate()
/*      */     throws Exception
/*      */   {
/*  160 */     String METHOD = "updateToolboxTemplate";
/*  161 */     CatalogItem.log.debugEntry("MXApplyTransactions", "updateToolboxTemplate");
/*      */ 
/*  163 */     Document originalDocument = null;
/*      */ 
/*  165 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*  166 */     dbf.setValidating(false);

/*      */ 
/*  169 */     InputStream in = super.getClass().getResourceAsStream(DEFAULT_TOOLKIT_FILENAME);
/*  170 */     InputSource source = new InputSource(in);
/*      */ 
/*  172 */     originalDocument = dbf.newDocumentBuilder().parse(source);
/*  173 */     this.appName = "TOOLBOX";
/*  174 */     saveApplicationDocument(originalDocument.getDocumentElement());

/*      */ 
/*  177 */     CatalogItem.log.debug("MXApplyTransactions", "updateToolboxTemplate", "delete from maxlabels where app= 'TOOLBOX';");
/*  178 */     PreparedStatement ps = this.con.prepareStatement("delete from maxlabels where app= 'TOOLBOX'");
/*  179 */     ps.executeUpdate();
/*      */ 
/*  181 */     CatalogItem.log.debugExit("MXApplyTransactions", "updateToolboxTemplate");
/*      */   }

/*      */   private String productExtentionPatchID(String s)
/*      */   {
/*  186 */     return (((this.sourceApp != null) && (s.equalsIgnoreCase(this.sourceApp))) ? this.targetApp : s);
/*      */   }






/*      */   private Element loadApplicationDocument(String app)
/*      */     throws Exception
/*      */   {
/*  197 */     String METHOD = "loadApplicationDocument";
/*  198 */     CatalogItem.log.debugEntry("MXApplyTransactions", "loadApplicationDocument");
/*      */ 
/*  200 */     String sqlStatement = new StringBuilder().append("select presentation from maxpresentation where app = '").append(app.toUpperCase()).append("'").toString();
/*      */ 
/*  202 */     Element ret = null;
/*  203 */     Statement st = null;

/*      */     try
/*      */     {
/*  207 */       st = this.con.createStatement();
/*  208 */       ResultSet rs = st.executeQuery(sqlStatement);
/*      */ 
/*  210 */       if (rs.next())
/*      */       {
/*  212 */         Clob mxPresentation = rs.getClob("PRESENTATION");
/*      */ 
/*  214 */         String clobString = MXFormat.clobToString(mxPresentation);
/*  215 */         InputSource source = new InputSource(new StringReader(clobString));
/*      */ 
/*  217 */         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*  218 */         dbf.setValidating(false);
/*  219 */         Document d = dbf.newDocumentBuilder().parse(source);
/*  220 */         ret = d.getDocumentElement();
/*      */       }
/*  222 */       else if (DEBUG)
/*      */       {
/*  224 */         File f = new File(new StringBuilder().append("defaults").append(File.separator).append(app).append(".xml").toString());
/*  225 */         if (f.isFile()) {
/*  226 */           ret = parse(f.getAbsolutePath()).getDocumentElement();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  237 */         if (st != null)
/*  238 */           st.close();
/*      */       }
/*      */       catch (Exception e) {
/*      */       }
/*      */     }
/*  243 */     CatalogItem.log.debugExit("MXApplyTransactions", "loadApplicationDocument");
/*  244 */     return ret;
/*      */   }

/*      */   private StringBuffer stripWhiteSpace(StringBuffer inBuffer)
/*      */   {
/*  249 */     StringBuffer retBuffer = new StringBuffer();
/*      */ 
/*  251 */     for (int i = 0; i < inBuffer.length(); ++i)
/*      */     {
/*  253 */       if ((inBuffer.charAt(i) != ' ') && (inBuffer.charAt(i) != '\t') && (inBuffer.charAt(i) != '\n')) {
/*  254 */         retBuffer.append(inBuffer.charAt(i));
/*      */       }
/*      */     }
/*  257 */     return retBuffer;
/*      */   }

/*      */   private String getTransactionIndex(Element transaction, String property, String tag)
/*      */   {
/*  262 */     String METHOD = "getTransactionIndex";
/*      */ 
/*  264 */     String key = transaction.getAttribute(property);
/*      */ 
/*  266 */     key = productExtentionPatchID(key);
/*      */ 
/*  268 */     if (!(key.equals(""))) {
/*  269 */       return key.toLowerCase();
/*      */     }
/*  271 */     key = transaction.getAttribute("message");
/*      */ 
/*  273 */     if (!(key.equals(""))) {
/*  274 */       return new StringBuilder().append("mobilemessage:::").append(key.toLowerCase()).toString();
/*      */     }
/*  276 */     key = "";
/*  277 */     NodeList list = transaction.getElementsByTagName(tag);
/*      */ 
/*  279 */     if (list.getLength() > 0)
/*      */     {
/*  281 */       StringBuffer sb = new StringBuffer();
/*      */ 
/*  283 */       NodeList children = list.item(0).getChildNodes();
/*      */ 
/*  285 */       for (int x = 0; x < children.getLength(); ++x)
/*      */       {
/*  287 */         if (children.item(x) instanceof Element) {
/*  288 */           getFormattedElement(sb, 0, (Element)children.item(x));
/*      */         }
/*      */       }
/*  291 */       key = stripWhiteSpace(sb).toString();
/*      */     }
/*      */ 
/*  294 */     return key.toLowerCase();
/*      */   }

/*      */   private String getElementID(Element e)
/*      */   {
/*  299 */     String id = e.getAttribute("id");
/*      */ 
/*  301 */     id = productExtentionPatchID(id);
/*      */ 
/*  303 */     if ((id.equals("")) && 

/*  305 */       (this.appType.equalsIgnoreCase("mobileapp-cdc")))
/*      */     {
/*  307 */       if (e.getNodeName().equalsIgnoreCase("mobilembos")) {
/*  308 */         id = "mobilembos";
/*  309 */       } else if (e.getNodeName().equalsIgnoreCase("mobilescreens")) {
/*  310 */         id = "mobilescreens";
/*  311 */       } else if (e.getNodeName().equalsIgnoreCase("mobilemessages")) {
/*  312 */         id = "mobilemessages";
/*  313 */       } else if (e.getNodeName().equalsIgnoreCase("mobilemessage")) {
/*  314 */         id = new StringBuilder().append(e.getNodeName()).append(":::").append(e.getAttribute("key")).toString();
/*  315 */       } else if (e.getNodeName().equalsIgnoreCase("mobileapp-cdc")) {
/*  316 */         id = new StringBuilder().append(e.getNodeName()).append(":::").append(e.getAttribute("name")).toString();
/*      */       }
/*      */       else {
/*  319 */         Element location = createLocationTag(e, "name", "tag-location", true);
/*      */ 
/*  321 */         StringBuffer sb = new StringBuffer();
/*      */ 
/*  323 */         NodeList children = location.getChildNodes();
/*      */ 
/*  325 */         for (int x = 0; x < children.getLength(); ++x)
/*      */         {
/*  327 */           if (children.item(x) instanceof Element) {
/*  328 */             getFormattedElement(sb, 0, (Element)children.item(x));
/*      */           }
/*      */         }
/*  331 */         id = stripWhiteSpace(sb).toString();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  336 */     return id;
/*      */   }

/*      */   private String getElementIndex(Element e)
/*      */   {
/*  341 */     return getElementID(e).toLowerCase();
/*      */   }







/*      */   private void buildAppIndex(Element e)
/*      */     throws Exception
/*      */   {
/*  353 */     String METHOD = "buildAppIndex";
/*      */ 
/*  355 */     if (e == null) {
/*  356 */       return;
/*      */     }
/*  358 */     String id = getElementIndex(e);
/*      */ 
/*  360 */     if (id.equals(""))

/*      */     {
/*  363 */       e.getParentNode().removeChild(e);
/*  364 */       return;
/*      */     }
/*      */ 
/*  367 */     if (this.appIndex.containsKey(id))

/*      */     {
/*  370 */       e.getParentNode().removeChild(e);
/*  371 */       CatalogItem.log.debug("MXApplyTransactions", "buildAppIndex", new StringBuilder().append(this.commentFlag).append("Warning: (").append(this.appName).append(") Application contains controls with duplicate id's (").append(id).append(")").toString());

/*      */     }
/*      */ 
/*  375 */     this.appIndex.put(id, e);
/*      */ 
/*  377 */     NodeList list = e.getChildNodes();
/*  378 */     for (int x = 0; x < list.getLength(); ++x)
/*      */     {
/*  380 */       if (list.item(x) instanceof Element)
/*  381 */         buildAppIndex((Element)list.item(x));
/*      */     }
/*      */   }






/*      */   private void updateMaxLabels()
/*      */     throws Exception
/*      */   {
/*  393 */     String METHOD = "updateMaxLabels";
/*  394 */     CatalogItem.log.debugEntry("MXApplyTransactions", "updateMaxLabels");
/*      */ 
/*  396 */     Iterator i = this.maxLabelChanges.iterator();
/*      */ 
/*  398 */     if (i.hasNext()) {
/*  399 */       CatalogItem.log.debug("MXApplyTransactions", "updateMaxLabels", new StringBuilder().append("\n").append(this.commentFlag).append("\tMAXLABEL Database Statements:\n").toString());
/*      */     }
/*  401 */     String process = "";
/*  402 */     while (i.hasNext())
/*      */     {
/*  404 */       PropertyChange labelChange = (PropertyChange)i.next();
/*  405 */       Statement s = null;
/*  406 */       PreparedStatement ps = null;
/*      */ 
/*  408 */       if ((mxsFileName != null) && (mxsFileName.equalsIgnoreCase("v7115_11")) && (labelChange.id.toLowerCase().contains("gotolink")) && (labelChange.property.equalsIgnoreCase("label")) && (this.appName.equalsIgnoreCase("LIBRARY")))



/*      */       {
/*  413 */         CatalogItem.log.debug("MXApplyTransactions", "updateMaxLabels", new StringBuilder().append("\t\tIgnore label transaction for ").append(labelChange.id).append(" in file ").append(mxsFileName).toString());


/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  420 */         s = this.con.createStatement();
/*  421 */         String sqlQuery = new StringBuilder().append("select value from maxlabels where app= '").append(this.appName).append("' and id='").append(labelChange.id).append("' and LOWER(property) ='").append(labelChange.property.toLowerCase()).append("'").toString();
/*  422 */         ResultSet rs = s.executeQuery(sqlQuery);
/*      */ 
/*  424 */         String labelValue = "";
/*  425 */         if (labelChange.value != null) {
/*  426 */           labelValue = labelChange.value.trim();

/*      */         }
/*      */ 
/*  430 */         if (rs.next())

/*      */         {
/*  433 */           if ((labelChange.removeProperty) || (labelValue.length() == 0) || (labelValue.equals("")))
/*      */           {
/*  435 */             CatalogItem.log.debug("MXApplyTransactions", "updateMaxLabels", new StringBuilder().append("\t\tdelete from maxlabels where app='").append(this.appName).append("' and id='").append(labelChange.id).append("' and LOWER(property)='").append(labelChange.property.toLowerCase()).append("';").toString());
/*      */ 
/*  437 */             if (!(DEBUG))

/*      */             {
/*  440 */               process = "delete from maxlabels where app=? and id=? and LOWER(property)=? initial";
/*  441 */               ps = this.con.prepareStatement("delete from maxlabels where app=? and id=? and LOWER(property)=?");
/*  442 */               ps.setString(1, this.appName);
/*  443 */               ps.setString(2, labelChange.id);
/*  444 */               ps.setString(3, labelChange.property.toLowerCase());
/*  445 */               ps.executeUpdate();
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/*  450 */             CatalogItem.log.debug("MXApplyTransactions", "updateMaxLabels", new StringBuilder().append("\t\tupdate maxlabels set value='").append(labelChange.value).append("' where app='").append(this.appName).append("' and id='").append(labelChange.id).append("' and LOWER(property)='").append(labelChange.property.toLowerCase()).append("';").toString());
/*      */ 
/*  452 */             if ((!(DEBUG)) && (this.updateMAXLabels))

/*      */             {
/*  455 */               process = "update maxlabels set value=? where app=? and id=? and LOWER(property)=?";
/*  456 */               ps = this.con.prepareStatement("update maxlabels set value=? where app=? and id=? and LOWER(property)=?");
/*  457 */               ps.setString(1, labelChange.value);
/*  458 */               ps.setString(2, this.appName);
/*  459 */               ps.setString(3, labelChange.id);
/*  460 */               ps.setString(4, labelChange.property.toLowerCase());
/*  461 */               ps.executeUpdate();
/*      */             }
/*      */           }
/*      */         }
/*  465 */         else if (!(labelChange.removeProperty))
/*      */         {
/*  467 */           CatalogItem.log.debug("MXApplyTransactions", "updateMaxLabels", new StringBuilder().append("\t\tinsert into maxlabels (value,app,id,property,maxlabelsid) values ('").append(labelChange.value).append("','").append(this.appName).append("','").append(labelChange.id).append("','").append(labelChange.property).append("', ").append(generateMaxSequenceKey(this.con, "MAXLABELS", "MAXLABELSID")).append(");").toString());
/*      */ 
/*  469 */           if (!(DEBUG))
/*      */           {
/*  471 */             process = "insert into maxlabels (value,app,id,property,maxlabelsid) values (?,?,?,?,?)";

/*      */ 
/*  474 */             if ((labelValue.length() == 0) || (labelValue.equals("")))
/*      */             {
/*  476 */               CatalogItem.log.debug("MXApplyTransactions", "updateMaxLabels", new StringBuilder().append(this.commentFlag).append("WARNING:  Attempting to add a new label(").append(labelChange.id).append(") for App ").append(this.appName).append(" when the label value specified is blank.  Skipping.").toString());




/*      */             }
/*      */             else
/*      */             {
/*  484 */               ps = this.con.prepareStatement("insert into maxlabels (value,app,id,property,maxlabelsid) values (?,?,?,?,?)");
/*  485 */               ps.setString(1, labelChange.value);
/*  486 */               ps.setString(2, this.appName);
/*  487 */               ps.setString(3, labelChange.id);
/*  488 */               ps.setString(4, labelChange.property);
/*  489 */               ps.setLong(5, generateMaxSequenceKey(this.con, "MAXLABELS", "MAXLABELSID"));
/*  490 */               ps.executeUpdate();
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*  499 */         throw new Exception(new StringBuilder().append("Error:   (").append(this.appName).append(") Unable to update MAXLABELS (").append(labelChange.toString()).append(") - ").append(t.getMessage()).toString());
/*      */       }
/*      */       finally
/*      */       {
/*      */         try
/*      */         {
/*  505 */           if (s != null)
/*  506 */             s.close();
/*      */         }
/*      */         catch (Exception e) {
/*      */         }
/*      */         try {
/*  511 */           if (ps != null)
/*  512 */             ps.close();
/*      */         } catch (Exception e) {
/*      */         }
/*      */       }
/*      */     }
/*  517 */     CatalogItem.log.debugExit("MXApplyTransactions", "updateMaxLabels");
/*      */   }

/*      */   long generateMaxSequenceKey(Connection connection, String table, String column) throws Exception
/*      */   {
/*      */     try
/*      */     {
/*  524 */       return MaxSequence.generateKey(connection, table, column);
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*  528 */       throw new Exception(new StringBuilder().append("MaxSequence Error - ").append(t.getMessage()).toString());
/*      */     }
/*      */   }








/*      */   private void saveApplicationDocument(Element doc)
/*      */     throws Exception
/*      */   {
/*  542 */     String METHOD = "saveApplicationDocument";
/*  543 */     CatalogItem.log.debugEntry("MXApplyTransactions", "saveApplicationDocument");
/*      */ 
/*  545 */     StringBuffer stringBuffer = new StringBuffer();


/*      */ 
/*  549 */     getFormattedElement(stringBuffer, 0, doc);
/*      */ 
/*  551 */     String presentationString = new StringBuilder().append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n").append(stringBuffer).toString();
/*      */ 
/*  553 */     if (DEBUG)
/*      */     {
/*  555 */       String backupFolderName = "presentations";
/*  556 */       File folder = new File(backupFolderName);
/*  557 */       folder.mkdir();
/*      */ 
/*  559 */       PrintStream f = new PrintStream(new FileOutputStream(new StringBuilder().append(backupFolderName).append(File.separator).append(this.appName.toLowerCase()).append(".xml").toString()));
/*  560 */       f.print(presentationString);
/*  561 */       f.close();
/*  562 */       return;
/*      */     }
/*      */ 
/*  565 */     Statement st = null;
/*  566 */     PreparedStatement ps = null;
/*  567 */     Statement st2 = null;

/*      */     try
/*      */     {
/*  571 */       st = this.con.createStatement();

/*      */ 
/*  574 */       String version = "7.5.0";
/*  575 */       doc.setAttribute("version", version);

/*      */ 
/*  578 */       ResultSet rs = st.executeQuery(new StringBuilder().append("select app from maxpresentation where app= '").append(this.appName).append("'").toString());
/*      */ 
/*  580 */       boolean newApp = !(rs.next());
/*      */ 
/*  582 */       ps = this.con.prepareStatement((newApp) ? "insert into maxpresentation (presentation,app,maxpresentationid) values (?,?,?)" : "update maxpresentation set presentation = ? where app = ?");
/*      */ 
/*  584 */       String dbName = this.con.getMetaData().getDatabaseProductName();
/*      */ 
/*  586 */       if ((dbName.equalsIgnoreCase("Microsoft SQL Server")) || (dbName.startsWith("DB2")))
/*      */       {
/*  588 */         ps.setString(1, presentationString);
/*      */       }
/*      */       else
/*      */       {
/*  592 */         st2 = this.con.createStatement();
/*  593 */         st2.execute("select dummy_clob from dummy_table for update");
/*  594 */         ResultSet rs2 = st2.getResultSet();
/*      */ 
/*  596 */         rs2.next();
/*  597 */         Clob nrsClob = rs2.getClob(1);
/*  598 */         ((CLOB)nrsClob).trim(0L);
/*  599 */         ((CLOB)nrsClob).putString(1L, presentationString);
/*      */ 
/*  601 */         ps.setClob(1, nrsClob);
/*      */       }
/*      */ 
/*  604 */       ps.setString(2, this.appName);
/*      */ 
/*  606 */       if (newApp) {
/*  607 */         ps.setLong(3, generateMaxSequenceKey(this.con, "MAXPRESENTATION", "MAXPRESENTATIONID"));
/*      */       }
/*  609 */       ps.executeUpdate();


/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  620 */         if (st != null)
/*  621 */           st.close();
/*      */       }
/*      */       catch (Exception e) {
/*      */       }
/*      */       try {
/*  626 */         if (st2 != null)
/*  627 */           st2.close();
/*      */       }
/*      */       catch (Exception e) {
/*      */       }
/*      */       try {
/*  632 */         if (ps != null)
/*  633 */           ps.close();
/*      */       }
/*      */       catch (Exception e) {
/*      */       }
/*      */     }
/*  638 */     CatalogItem.log.debugExit("MXApplyTransactions", "saveApplicationDocument");
/*      */   }
/*      */ 
/*  641 */     this.propsLoaded = false;
/*      */   }






/*      */   private boolean isTranslatableProperty(String control, String attribute)
/*      */   {
/*  651 */     if (!(this.propsLoaded))
/*      */     {
/*      */       try
/*      */       {
/*  655 */         loadTranslatableProperties();
/*  656 */         this.propsLoaded = true;
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*  660 */         System.out.println("UNABLE TO LOAD TRANSLATABLE PROPS !!!! ");
/*  661 */         t.printStackTrace();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  666 */     return isAttrTranslatable(control, attribute);
/*      */   }









/*      */   private void updateProperties(Element control, List<PropertyChange> changes)
/*      */   {
/*  679 */     String METHOD = "updateProperties";
/*      */ 
/*  681 */     Iterator i = changes.iterator();
/*  682 */     while (i.hasNext())
/*      */     {
/*  684 */       PropertyChange pc = (PropertyChange)i.next();

/*      */ 
/*  687 */       if (pc.removeProperty)
/*      */       {
/*  689 */         if (DEBUG) {
/*  690 */           CatalogItem.log.debug("MXApplyTransactions", "updateProperties", new StringBuilder().append(this.commentFlag).append("\t\t").append((isTranslatableProperty(control.getNodeName(), pc.property)) ? "*" : " ").append(" clear ").append(pc.property).toString());
/*      */         }
/*  692 */         control.removeAttribute(pc.property);
/*      */       }
/*      */       else
/*      */       {
/*  696 */         if (pc.property.equalsIgnoreCase("id")) {
/*  697 */           pc.value = productExtentionPatchID(pc.value);
/*      */         }
/*  699 */         if (pc.property.equalsIgnoreCase("set-tag-value"))
/*      */         {
/*  701 */           if (DEBUG) {
/*  702 */             CatalogItem.log.debug("MXApplyTransactions", "updateProperties", new StringBuilder().append(this.commentFlag).append("\t\t").append(" set tag value to ").append(pc.value).append(" nodeType = ").append(control.getNodeName()).toString());
/*      */           }
/*  704 */           if (control.getParentNode() != null)
/*      */           {
/*  706 */             Node owner = control.getParentNode();
/*  707 */             String nodeType = control.getNodeName();
/*      */ 
/*  709 */             Element updateTag = owner.getOwnerDocument().createElement(nodeType);
/*  710 */             updateTag.setTextContent(pc.value);
/*  711 */             owner.appendChild(updateTag);
/*  712 */             owner.removeChild(control);
/*      */           }
/*      */           else
/*      */           {
/*  716 */             control.setTextContent(pc.value);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  721 */           if (DEBUG)
/*  722 */             CatalogItem.log.debug("MXApplyTransactions", "updateProperties", new StringBuilder().append(this.commentFlag).append("\t\t").append((isTranslatableProperty(control.getNodeName(), pc.property)) ? "*" : " ").append("   set ").append(pc.property).append(" to ").append(pc.value).toString());
/*  723 */           control.setAttribute(pc.property, pc.value);




/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  734 */     Iterator j = changes.iterator();
/*  735 */     while (j.hasNext())
/*      */     {
/*  737 */       PropertyChange pc = (PropertyChange)j.next();
/*  738 */       recordMaxLabelChange(control.getNodeName(), pc);
/*      */     }
/*      */   }







/*      */   private void recordMaxLabelChange(String controlType, PropertyChange pc)
/*      */   {
/*  750 */     if (!(isTranslatableProperty(controlType, pc.property)))
/*      */       return;
/*  752 */     this.maxLabelChanges.add(pc);
/*      */   }









/*      */   public void ADD(Element app, Element xact)
/*      */     throws Exception
/*      */   {
/*  766 */     String METHOD = "ADD";

/*      */ 
/*  769 */     String containerID = getTransactionIndex(xact, "container", "container-tag-location");
/*  770 */     String controlType = xact.getAttribute("control");
/*  771 */     String controlID = null;
/*  772 */     String beforeID = getTransactionIndex(xact, "before", "add-before-tag");
/*      */ 
/*  774 */     if (DEBUG)
/*      */     {
/*  776 */       CatalogItem.log.debug("MXApplyTransactions", "ADD", new StringBuilder().append("\n").append(this.commentFlag).append("\t   ADD: ").append(controlType).append(" to ").append(containerID).append((beforeID.equals("")) ? "" : new StringBuilder().append(" before ").append(beforeID).toString()).append("\n").toString());


/*      */     }
/*      */ 
/*  781 */     if ((controlType.equalsIgnoreCase("resultscolumns")) || (controlType.equalsIgnoreCase("attributelist")))
/*      */     {
/*  783 */       if (DEBUG)
/*      */       {
/*  785 */         CatalogItem.log.debug("MXApplyTransactions", "ADD", new StringBuilder().append("\n").append(this.commentFlag).append("\t\t   Do not add controls from Application Designer Replacement Template.\n").toString());
/*      */       }
/*  787 */       return;
/*      */     }
/*      */ 
/*  790 */     LinkedList properties = loadPropertyChanges(xact.getChildNodes());

/*      */ 
/*  793 */     controlID = getIdProperty(properties);
/*      */ 
/*  795 */     if (controlID == null)
/*      */     {
/*  797 */       controlID = getTransactionIndex(xact, "id", "tag-location");

/*      */     }
/*      */ 
/*  801 */     if (controlID == null)
/*      */     {
/*  803 */       CatalogItem.log.debug("MXApplyTransactions", "ADD", new StringBuilder().append(this.commentFlag).append("ERROR: control added without an id.").append("\n").append(xact).toString());


/*      */     }
/*      */ 
/*  808 */     for (Iterator i = properties.iterator(); i.hasNext(); )
/*      */     {
/*  810 */       PropertyChange c = (PropertyChange)i.next();
/*      */ 
/*  812 */       if ((c.property.equalsIgnoreCase("dataattribute")) && (c.value.equalsIgnoreCase("#{keyattribute}"))) {
/*  813 */         return;
/*      */       }
/*  815 */       c.id = controlID;

/*      */     }
/*      */ 
/*  819 */     Element container = (Element)this.appIndex.get(containerID);
/*  820 */     if (container == null)
/*      */     {
/*  822 */       if (DEBUG)
/*  823 */         CatalogItem.log.debug("MXApplyTransactions", "ADD", new StringBuilder().append("\n").append(this.commentFlag).append("\t\t   Unable to add control, did not find container (").append(containerID).append(").\n").toString());
/*  824 */       return;
/*      */     }
/*      */ 
/*  827 */     if ((!(this.appName.equalsIgnoreCase("TOOLBOX"))) && 



/*  831 */       (controlID != null) && (this.appIndex.containsKey(controlID.toLowerCase())))
/*      */     {
/*  833 */       Element indexedControl = (Element)this.appIndex.get(controlID.toLowerCase());
/*  834 */       Element removeXact = generateRemoveTransaction(app, indexedControl);
/*  835 */       if (this.overWrite)
/*  836 */         REMOVE(app, removeXact);
/*  837 */       if (DEBUG) {
/*  838 */         CatalogItem.log.debug("MXApplyTransactions", "ADD", new StringBuilder().append(this.commentFlag).append("\t\t\t(Info)\t   (").append(this.appName).append(") (").append(controlID).append(") has been replaced.").toString());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  843 */     Element control = app.getOwnerDocument().createElement(controlType);

/*      */ 
/*  846 */     updateProperties(control, properties);

/*      */ 
/*  849 */     control.setAttribute("ADDED-BY-PRODUCT-UPDATE", "TRUE");

/*      */ 
/*  852 */     Element before = null;


/*      */ 
/*  856 */     if (beforeID != null)
/*      */     {
/*  858 */       NodeList nodeList = container.getChildNodes();
/*      */ 
/*  860 */       for (int x = 0; x < nodeList.getLength(); ++x)
/*      */       {
/*  862 */         Node node = nodeList.item(x);
/*  863 */         if ((!(node instanceof Element)) || 

/*  865 */           (!(getElementIndex((Element)node).equalsIgnoreCase(beforeID))))
/*      */           continue;
/*  867 */         before = (Element)node;
/*  868 */         break;

/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  874 */     if (before != null)
/*  875 */       container.insertBefore(control, before);
/*      */     else {
/*  877 */       container.appendChild(control);
/*      */     }
/*      */ 
/*  880 */     this.appIndex.put(getElementIndex(control), control);
/*      */   }

/*      */   private Element generateRemoveTransaction(Element app, Element control)
/*      */   {
/*  885 */     String controlID = getElementIndex(control);
/*  886 */     String container = getControlParentId(control);
/*  887 */     Element removeTag = null;

/*      */ 
/*  890 */     if (!(controlID.equals("")))
/*      */     {
/*  892 */       removeTag = app.getOwnerDocument().createElement("remove");
/*  893 */       removeTag.setAttribute("control", controlID);
/*  894 */       removeTag.setAttribute("container", container);
/*      */     }
/*  896 */     return removeTag;
/*      */   }






/*      */   private String getIdProperty(LinkedList<PropertyChange> properties)
/*      */   {
/*  906 */     Iterator i = properties.iterator();
/*  907 */     while (i.hasNext())
/*      */     {
/*  909 */       PropertyChange pc = (PropertyChange)i.next();
/*  910 */       if (pc.property.equals("id"))
/*      */       {
/*  912 */         return pc.value;
/*      */       }
/*      */     }
/*  915 */     return null;
/*      */   }






/*      */   private LinkedList<PropertyChange> loadPropertyChanges(NodeList changes)
/*      */     throws Exception
/*      */   {
/*  926 */     LinkedList ret = new LinkedList();

/*      */ 
/*  929 */     for (int i = 0; i < changes.getLength(); ++i)
/*      */     {
/*  931 */       if ((changes.item(i).getNodeName().equalsIgnoreCase("tag-type")) || (changes.item(i).getNodeName().equalsIgnoreCase("container-tag-location")) || (changes.item(i).getNodeName().equalsIgnoreCase("tag-location"))) continue; if (changes.item(i).getNodeName().equalsIgnoreCase("add-before-tag"))

/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/*  937 */       if (!(changes.item(i) instanceof Element))
/*      */         continue;
/*  939 */       Element change = (Element)changes.item(i);
/*  940 */       PropertyChange pc = new PropertyChange(change);
/*  941 */       ret.add(pc);

/*      */     }
/*      */ 
/*  945 */     return ret;
/*      */   }


/*      */   private String getControlParentId(Element control)
/*      */   {
/*  951 */     Node parent = control.getParentNode();
/*  952 */     if (parent == null) {
/*  953 */       return null;
/*      */     }
/*  955 */     if ((parent.getNodeName().equalsIgnoreCase("mobilembos")) || (parent.getNodeName().equalsIgnoreCase("mobilescreens")) || (parent.getNodeName().equalsIgnoreCase("mobilemessages")))

/*      */     {
/*  958 */       return parent.getNodeName();
/*      */     }
/*  960 */     String id = null;
/*      */     try
/*      */     {
/*  963 */       id = parent.getAttributes().getNamedItem("id").getNodeValue().toLowerCase();
/*      */     }
/*      */     catch (NullPointerException npe)
/*      */     {
/*  967 */       System.out.println(new StringBuilder().append("NPE ~ ").append(control.getNodeName()).append("/").append(control.getAttribute("mboattribute")).append("/").append(control.getAttribute("name")).append("/").toString());
/*  968 */       return "";
/*      */     }
/*      */ 
/*  971 */     return productExtentionPatchID(id);
/*      */   }









/*      */   public void MODIFY(Element app, Element xact)
/*      */     throws Exception
/*      */   {
/*  985 */     String METHOD = "MODIFY";
/*      */ 
/*  987 */     String controlID = getTransactionIndex(xact, "control", "tag-location");
/*      */ 
/*  989 */     Element control = (Element)this.appIndex.get(controlID);
/*      */ 
/*  991 */     if (DEBUG)
/*      */     {
/*  993 */       CatalogItem.log.debug("MXApplyTransactions", "MODIFY", new StringBuilder().append("\n").append(this.commentFlag).append("\tMODIFY: ").append(controlID).append("\n").toString());
/*      */     }
/*      */ 
/*  996 */     if (control == null)
/*      */     {
/*  998 */       CatalogItem.log.debug("MXApplyTransactions", "MODIFY", new StringBuilder().append(this.commentFlag).append("Warning: (").append(this.appName).append(") Cannot MODIFY control (").append(controlID).append("). ID does not exist").toString());
/*  999 */       return;
/*      */     }
/*      */ 
/* 1002 */     this.appIndex.remove(controlID);

/*      */ 
/* 1005 */     LinkedList propChanges = new LinkedList();
/* 1006 */     NodeList changes = xact.getChildNodes();
/*      */ 
/* 1008 */     for (int x = 0; x < changes.getLength(); ++x)
/*      */     {
/* 1010 */       if (changes.item(x).getNodeName().equalsIgnoreCase("tag-location")) {
/*      */         continue;
/*      */       }
/* 1013 */       if (!(changes.item(x) instanceof Element)) {
/*      */         continue;
/*      */       }
/* 1016 */       Element change = (Element)changes.item(x);
/*      */ 
/* 1018 */       PropertyChange pc = new PropertyChange(change);
/* 1019 */       pc.id = getElementID(control);
/*      */ 
/* 1021 */       propChanges.add(pc);


/*      */     }
/*      */ 
/* 1026 */     updateProperties(control, propChanges);
/*      */ 
/* 1028 */     this.appIndex.put(getElementIndex(control), control);
/*      */   }









/*      */   public void MOVE(Element app, Element xact)
/*      */   {
/* 1041 */     String METHOD = "MOVE";
/*      */ 
/* 1043 */     String controlID = getTransactionIndex(xact, "child", "tag-to-be-moved");
/* 1044 */     Element child = (Element)this.appIndex.get(controlID);
/*      */ 
/* 1046 */     if (child == null)
/*      */     {
/* 1048 */       CatalogItem.log.debug("MXApplyTransactions", "MOVE", new StringBuilder().append(this.commentFlag).append("Warning: (").append(this.appName).append(") Cannot MOVE control (").append(controlID).append("). ID does not exist.").toString());
/* 1049 */       return;
/*      */     }
/*      */ 
/* 1052 */     String containerID = getTransactionIndex(xact, "container", "container-tag-location");
/* 1053 */     Element container = (Element)this.appIndex.get(containerID);
/*      */ 
/* 1055 */     if (container == null)
/*      */     {
/* 1057 */       CatalogItem.log.debug("MXApplyTransactions", "MOVE", new StringBuilder().append(this.commentFlag).append("Warning: (").append(this.appName).append(") Cannot MOVE control (").append(controlID).append("), CONTAINER does not exist (").append(containerID).append(")").toString());
/* 1058 */       return;
/*      */     }
/*      */ 
/* 1061 */     String beforeID = getTransactionIndex(xact, "before", "move-before-tag-location");
/* 1062 */     Element before = (Element)this.appIndex.get(beforeID);
/*      */ 
/* 1064 */     if ((!(xact.getAttribute("before").equals(""))) && (before == null))
/*      */     {
/* 1066 */       CatalogItem.log.debug("MXApplyTransactions", "MOVE", new StringBuilder().append(this.commentFlag).append("Warning: (").append(this.appName).append(") Cannot MOVE control (").append(controlID).append("), BEFORE does not exist (").append(beforeID).append(")").toString());
/* 1067 */       return;
/*      */     }
/*      */ 
/* 1070 */     if (DEBUG)
/*      */     {
/* 1072 */       CatalogItem.log.debug("MXApplyTransactions", "MOVE", new StringBuilder().append("\n").append(this.commentFlag).append("\t  MOVE: ").append(controlID).append("\n").toString());

/*      */     }
/*      */ 
/* 1076 */     child.getParentNode().removeChild(child);

/*      */ 
/* 1079 */     if (before != null)
/*      */     {
/* 1081 */       container.insertBefore(child, before);
/*      */     }
/*      */     else container.appendChild(child);
/*      */   }








/*      */   private void removeNode(Element control)
/*      */   {
/* 1095 */     String METHOD = "removeNode";

/*      */ 
/* 1098 */     NodeList children = control.getChildNodes();
/*      */ 
/* 1100 */     for (int x = 0; x < children.getLength(); ++x)
/*      */     {
/* 1102 */       if ((!(children.item(x) instanceof Element)) || (children.item(x).getNodeName().equalsIgnoreCase("attributelist")))
/*      */         continue;
/* 1104 */       Element child = (Element)children.item(x);
/*      */ 
/* 1106 */       removeNode(child);


/*      */     }
/*      */ 
/* 1111 */     String controlID = getElementIndex(control);
/* 1112 */     this.appIndex.remove(controlID);
/*      */ 
/* 1114 */     if (DEBUG)
/*      */     {
/* 1116 */       CatalogItem.log.debug("MXApplyTransactions", "removeNode", new StringBuilder().append(this.commentFlag).append("\t\t\tRemoving: ").append(controlID).toString());

/*      */     }
/*      */ 
/* 1120 */     NamedNodeMap attributes = control.getAttributes();
/*      */ 
/* 1122 */     for (int x = 0; x < attributes.getLength(); ++x)
/*      */     {
/* 1124 */       String property = attributes.item(x).getNodeName();
/* 1125 */       if (!(isTranslatableProperty(control.getNodeName(), property)))
/*      */         continue;
/* 1127 */       if (DEBUG) {
/* 1128 */         CatalogItem.log.debug("MXApplyTransactions", "removeNode", new StringBuilder().append(this.commentFlag).append("\t\t\t\tclear ").append(property).toString());

/*      */       }
/*      */ 
/* 1132 */       boolean removedExisting = false;
/*      */ 
/* 1134 */       Iterator iterator = this.maxLabelChanges.iterator();
/*      */ 
/* 1136 */       while (iterator.hasNext())
/*      */       {
/* 1138 */         PropertyChange change = (PropertyChange)iterator.next();
/*      */ 
/* 1140 */         if ((change != null) && (change.property.equalsIgnoreCase(property)) && (change.id.equalsIgnoreCase(controlID)))
/*      */         {
/* 1142 */           removedExisting = true;
/* 1143 */           change.removeProperty = true;
/*      */         }
/*      */       }
/*      */ 
/* 1147 */       if (DEBUG) {
/* 1148 */         CatalogItem.log.debug("MXApplyTransactions", "removeNode", (removedExisting) ? new StringBuilder().append(this.commentFlag).append("  (Cleared Prior Transaction)").toString() : "");
/*      */       }
/* 1150 */       this.maxLabelChanges.add(new PropertyChange(true, property, getElementID(control), null));
/*      */     }
/*      */   }










/*      */   public void REMOVE(Element app, Element xact)
/*      */     throws Exception
/*      */   {
/* 1166 */     String METHOD = "REMOVE";
/*      */ 
/* 1168 */     String controlID = getTransactionIndex(xact, "control", "tag-location");
/*      */ 
/* 1170 */     String containerID = xact.getAttribute("container");
/*      */ 
/* 1172 */     containerID = productExtentionPatchID(containerID);
/*      */ 
/* 1174 */     if (DEBUG)
/*      */     {
/* 1176 */       CatalogItem.log.debug("MXApplyTransactions", "REMOVE", new StringBuilder().append("\n").append(this.commentFlag).append("\tREMOVE: ").append(controlID).append(" from ").append(containerID).append("\n").toString());


/*      */     }
/*      */ 
/* 1181 */     Element control = (Element)this.appIndex.get(controlID);
/* 1182 */     if (control == null)
/*      */     {
/* 1184 */       CatalogItem.log.debug("MXApplyTransactions", "REMOVE", new StringBuilder().append(this.commentFlag).append("Warning: (").append(this.appName).append(") Cannot DELETE control (").append(controlID).append("). ID does not exist").toString());
/* 1185 */       return;
/*      */     }
/*      */ 
/* 1188 */     if (control.hasAttribute("ADDED-BY-PRODUCT-UPDATE"))
/*      */     {
/* 1190 */       return;
/*      */     }
/*      */ 
/* 1193 */     removeNode(control);
/*      */ 
/* 1195 */     Element parent = (Element)control.getParentNode();

/*      */ 
/* 1198 */     if (parent != null)
/* 1199 */       parent.removeChild(control);
/*      */   }





/*      */   private void loadExistingLabels(String app)
/*      */     throws Exception
/*      */   {
/* 1209 */     String METHOD = "loadExistingLabels";
/* 1210 */     CatalogItem.log.debugEntry("MXApplyTransactions", "loadExistingLabels");
/*      */ 
/* 1212 */     Statement s = null;

/*      */     try
/*      */     {
/* 1216 */       s = this.con.createStatement();
/* 1217 */       String sqlQuery = new StringBuilder().append("select id, property, value from maxlabels where app= '").append(app).append("'").toString();
/*      */ 
/* 1219 */       ResultSet rs = s.executeQuery(sqlQuery);
/*      */ 
/* 1221 */       while (rs.next())
/*      */       {
/* 1223 */         String id = rs.getString(1);
/* 1224 */         String property = rs.getString(2);
/* 1225 */         String value = rs.getString(3);
/* 1226 */         this.maxLabelChanges.add(new PropertyChange(false, property, id, value));
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1233 */         if (s != null)
/* 1234 */           s.close();
/*      */       } catch (Exception e) {
/*      */       }
/*      */     }
/* 1238 */     CatalogItem.log.debugExit("MXApplyTransactions", "loadExistingLabels");
/*      */   }


/*      */   private void fixTemplate(Element parent)
/*      */   {
/* 1244 */     String METHOD = "fixTemplate";
/*      */ 
/* 1246 */     NodeList nodes = parent.getChildNodes();
/*      */ 
/* 1248 */     for (int x = 0; x < nodes.getLength(); ++x)
/*      */     {
/* 1250 */       if (!(nodes.item(x) instanceof Element))
/*      */         continue;
/* 1252 */       Element child = (Element)nodes.item(x);
/*      */ 
/* 1254 */       if ((child.getAttribute("dataattribute").equalsIgnoreCase("#{keyattribute}")) || (child.getNodeName().equalsIgnoreCase("resultscolumns")) || (child.getNodeName().equalsIgnoreCase("attributelist")))

/*      */       {
/* 1257 */         parent.removeChild(child);
/*      */       }
/*      */       else fixTemplate(child);
/*      */     }
/*      */   }







/*      */   private Element loadNewAppDocument()
/*      */     throws Exception
/*      */   {
/* 1272 */     String METHOD = "loadNewAppDocument";
/* 1273 */     CatalogItem.log.debugEntry("MXApplyTransactions", "loadNewAppDocument");
/*      */ 
/* 1275 */     if (this.templateNewAppDoc == null)
/*      */     {
/* 1277 */       Statement st = null;

/*      */       try
/*      */       {
/* 1281 */         st = this.con.createStatement();
/* 1282 */         ResultSet rs = st.executeQuery("select presentation from maxpresentation where app = 'TOOLBOX' ");
/*      */ 
/* 1284 */         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 1285 */         dbf.setValidating(false);
/*      */ 
/* 1287 */         if (!(rs.next()))
/*      */         {
/* 1289 */           throw new Exception("TOOLBOX systemlib not found.");
/*      */         }
/*      */ 
/* 1292 */         Clob mxPresentation = rs.getClob("PRESENTATION");
/* 1293 */         Document d = dbf.newDocumentBuilder().parse(mxPresentation.getAsciiStream());
/* 1294 */         Element toolbox = d.getDocumentElement();

/*      */ 
/* 1297 */         NodeList list = toolbox.getChildNodes();
/* 1298 */         for (int x = 0; x < list.getLength(); ++x)
/*      */         {
/* 1300 */           if (!(list.item(x) instanceof Element))
/*      */             continue;
/* 1302 */           Element node = (Element)list.item(x);
/* 1303 */           if ((!(node.getNodeName().equalsIgnoreCase("presentation"))) || (!(node.getAttribute("id").equalsIgnoreCase("ctrl_powerapp")))) {
/*      */             continue;
/*      */           }
/* 1306 */           this.templateNewAppDoc = node;
/* 1307 */           break;


/*      */         }
/*      */ 
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*      */       }
/*      */       finally
/*      */       {
/*      */         try
/*      */         {
/* 1320 */           if (st != null) {
/* 1321 */             st.close();
/*      */           }
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/* 1329 */     CatalogItem.log.debugExit("MXApplyTransactions", "loadNewAppDocument");
/* 1330 */     return ((Element)this.templateNewAppDoc.cloneNode(true));
/*      */   }











/*      */   private void applyTransactions(Element transaction)
/*      */     throws Exception
/*      */   {
/* 1346 */     String METHOD = "applyTransactions";
/* 1347 */     CatalogItem.log.debugEntry("MXApplyTransactions", "applyTransactions");


/*      */ 
/* 1351 */     if (transaction.getAttribute("id").equalsIgnoreCase("toolbox")) {
/* 1352 */       return;

/*      */     }
/*      */ 
/* 1356 */     this.appName = transaction.getAttribute("id").toUpperCase();


/*      */ 
/* 1360 */     if (this.sourceApp != null)
/*      */     {
/* 1362 */       if (!(this.sourceApp.equalsIgnoreCase(this.appName))) {
/* 1363 */         return;
/*      */       }
/* 1365 */       this.appName = this.targetApp;
/*      */     }
/*      */ 
/* 1368 */     this.originalApp = transaction.getAttribute("originalapp").toUpperCase();
/* 1369 */     this.appType = transaction.getAttribute("apptype").toUpperCase();
/*      */ 
/* 1371 */     CatalogItem.log.debug("MXApplyTransactions", "applyTransactions", new StringBuilder().append("\n").append(this.commentFlag).append(this.appName).append(" ").append(this.originalApp).append(" ").append(this.appType).append(" ").append((this.sourceApp != null) ? this.sourceApp : "").toString());


/*      */ 
/* 1375 */     boolean isClone = (!(this.originalApp.equals(""))) && (!(this.originalApp.equalsIgnoreCase("CUSTAPP")));
/*      */ 
/* 1377 */     this.appDocument = loadApplicationDocument((isClone) ? this.originalApp : this.appName);
/*      */ 
/* 1379 */     if ((this.appDocument == null) && (!(isClone)) && (!(this.appType.equalsIgnoreCase("mobileapp-cdc")))) {
/* 1380 */       this.appDocument = loadNewAppDocument();
/*      */     }
/* 1382 */     if (this.appDocument == null)
/*      */     {
/* 1384 */       CatalogItem.log.debug("MXApplyTransactions", "applyTransactions", new StringBuilder().append(this.commentFlag).append("Application document did not load.").toString());
/* 1385 */       return;


/*      */     }
/*      */ 
/* 1390 */     this.appIndex = new Hashtable();
/* 1391 */     buildAppIndex(this.appDocument);


/*      */ 
/* 1395 */     this.maxLabelChanges = new MaxLabelChanges();
/*      */ 
/* 1397 */     if (!(this.originalApp.equals(this.appName))) {
/* 1398 */       loadExistingLabels(this.originalApp);

/*      */     }
/*      */ 
/* 1402 */     NodeList xactList = transaction.getChildNodes();
/*      */ 
/* 1404 */     for (int y = 0; y < xactList.getLength(); ++y)
/*      */     {
/* 1406 */       if (!(xactList.item(y) instanceof Element)) {
/*      */         continue;
/*      */       }
/* 1409 */       Element xact = (Element)xactList.item(y);
/*      */ 
/* 1411 */       Object[] params = { this.appDocument, xact };
/* 1412 */       Method m = super.getClass().getMethod(xact.getNodeName().toUpperCase(), actionMethodParamTypes);
/*      */ 
/* 1414 */       m.invoke(this, params);
/*      */     }
/*      */ 
/* 1417 */     fixTemplate(this.appDocument);
/*      */ 
/* 1419 */     saveApplicationDocument(this.appDocument);
/*      */ 
/* 1421 */     if (this.updateLabels) {
/* 1422 */       updateMaxLabels();
/*      */     }
/* 1424 */     CatalogItem.log.debugExit("MXApplyTransactions", "applyTransactions");
/*      */   }






/*      */   public void applyTransactions()
/*      */     throws Exception
/*      */   {
/* 1435 */     String METHOD = "applyTransactions";
/* 1436 */     CatalogItem.log.debugEntry("MXApplyTransactions", "applyTransactions");
/* 1437 */     CatalogItem.log.debug("MXApplyTransactions", "applyTransactions", new StringBuilder().append(this.commentFlag).append("Processing Screen Update Transactions").toString());



/*      */     try
/*      */     {
/* 1443 */       updateToolboxTemplate();
/*      */ 
/* 1445 */       NodeList appList = this.transactionDocument.getDocumentElement().getChildNodes();
/*      */ 
/* 1447 */       for (int x = 0; x < appList.getLength(); ++x)
/*      */       {
/* 1449 */         if (appList.item(x) instanceof Element) {
/* 1450 */           applyTransactions((Element)appList.item(x));
/*      */         }
/*      */       }
/*      */ 
/* 1454 */       CatalogItem.log.debug("MXApplyTransactions", "applyTransactions", "update maxlabels set property=lower(property) where property != lower(property);");
/* 1455 */       PreparedStatement ps = this.con.prepareStatement("update maxlabels set property=lower(property) where property != lower(property)");
/* 1456 */       ps.executeUpdate();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1460 */       this.logStream.println(e.getMessage());
/* 1461 */       throw e;
/*      */     }
/*      */ 
/* 1464 */     CatalogItem.log.debug("MXApplyTransactions", "applyTransactions", new StringBuilder().append(this.commentFlag).append("Processing Complete.").toString());
/* 1465 */     CatalogItem.log.debugExit("MXApplyTransactions", "applyTransactions");
/*      */   }








/*      */   public static void applyScreenUpdates(Connection con2, InputStream fileStrm, PrintStream tmpOut, String filename)
/*      */     throws Exception
/*      */   {
/* 1478 */     mxsFileName = filename;
/* 1479 */     applyScreenUpdates(con2, fileStrm, tmpOut);
/*      */   }







/*      */   public static void applyScreenUpdates(Connection con2, InputStream fileStrm, PrintStream tmpOut)
/*      */     throws Exception
/*      */   {
/* 1491 */     String METHOD = "applyScreenUpdates";
/* 1492 */     CatalogItem.log.debugEntry("MXApplyTransactions", "applyScreenUpdates");

/*      */     try
/*      */     {
/* 1496 */       MXApplyTransactions apply = new MXApplyTransactions();
/*      */ 
/* 1498 */       apply.setConnection(con2);
/* 1499 */       apply.setTransactionStream(fileStrm);
/* 1500 */       apply.setLogStream(tmpOut);
/* 1501 */       apply.setUpdateLabels(true);

/*      */ 
/* 1504 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 1505 */       dbf.setValidating(false);
/* 1506 */       Document updateScriptDocument = dbf.newDocumentBuilder().newDocument();
/*      */ 
/* 1508 */       apply.setUpdateScriptDocument(updateScriptDocument);

/*      */ 
/* 1511 */       Element updateScript = updateScriptDocument.createElement("updatescript");
/*      */ 
/* 1513 */       apply.setUpdateScriptElement(updateScript);
/*      */ 
/* 1515 */       apply.applyTransactions();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1519 */       ByteArrayOutputStream stackOut = new ByteArrayOutputStream();
/* 1520 */       e.printStackTrace(new PrintWriter(stackOut, true));
/* 1521 */       tmpOut.println(stackOut.toString());
/* 1522 */       throw e;
/*      */     }
/*      */ 
/* 1525 */     CatalogItem.log.debugExit("MXApplyTransactions", "applyScreenUpdates");
/*      */   }








/*      */   public static void applyScreenUpdates(Connection con2, String targetApp, String sourceApp, InputStream fileStrm, PrintStream tmpOut, String filename)
/*      */     throws Exception
/*      */   {
/* 1538 */     mxsFileName = filename;
/* 1539 */     applyScreenUpdates(con2, targetApp, sourceApp, fileStrm, tmpOut);
/*      */   }







/*      */   public static void applyScreenUpdates(Connection con2, String targetApp, String sourceApp, InputStream fileStrm, PrintStream tmpOut)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1553 */       MXApplyTransactions apply = new MXApplyTransactions();
/* 1554 */       apply.setConnection(con2);
/* 1555 */       apply.setTransactionStream(fileStrm);
/* 1556 */       apply.setLogStream(tmpOut);
/* 1557 */       apply.setUpdateLabels(true);
/* 1558 */       apply.setSourceApp(sourceApp);
/* 1559 */       apply.setTargetApp(targetApp);
/* 1560 */       apply.setOverWrite(false);

/*      */ 
/* 1563 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 1564 */       dbf.setValidating(false);
/* 1565 */       Document updateScriptDocument = dbf.newDocumentBuilder().newDocument();
/*      */ 
/* 1567 */       apply.setUpdateScriptDocument(updateScriptDocument);

/*      */ 
/* 1570 */       Element updateScript = updateScriptDocument.createElement("updatescript");
/*      */ 
/* 1572 */       apply.setUpdateScriptElement(updateScript);
/*      */ 
/* 1574 */       apply.applyTransactions();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1578 */       ByteArrayOutputStream stackOut = new ByteArrayOutputStream();
/* 1579 */       e.printStackTrace(new PrintWriter(stackOut, true));
/* 1580 */       tmpOut.println(stackOut.toString());
/* 1581 */       throw e;
/*      */     }
/*      */   }





/*      */   public static void main(String[] argv)
/*      */   {
/* 1591 */     System.out.println("\nMAXIMO (MXES)Screen Upgrade - Update Utility - v1.0");
/* 1592 */     System.out.println("For use with Java JDK 1.3 or higher.\n");
/*      */ 
/* 1594 */     String propertiesFilename = "maximo.properties";
/* 1595 */     String transactionFilename = "transactions.xml";
/*      */ 
/* 1597 */     String sourceApp = null;
/* 1598 */     String targetApp = null;


/*      */ 
/* 1602 */     boolean updateMAXLabels = true;
/*      */ 
/* 1604 */     for (int i = 0; i < argv.length; ++i)
/*      */     {
/* 1606 */       if (argv[i].equalsIgnoreCase("-debug"))
/*      */       {
/* 1608 */         DEBUG = true;
/*      */       }
/*      */       else
/*      */       {
/* 1612 */         char cmd = argv[i].substring(0, 2).toLowerCase().charAt(1);
/*      */ 
/* 1614 */         String param = argv[i].substring(2);
/*      */ 
/* 1616 */         switch (cmd)
/*      */         {
/*      */         case 'p':
/* 1619 */           propertiesFilename = param;
/* 1620 */           break;
/*      */         case 't':
/* 1622 */           transactionFilename = param;
/* 1623 */           break;
/*      */         case 'l':
/* 1625 */           updateMAXLabels = false;
/* 1626 */           break;
/*      */         case 'a':
/* 1628 */           targetApp = param;
/* 1629 */           break;
/*      */         case 's':
/* 1631 */           sourceApp = param;
/* 1632 */           break;
/*      */         default:
/* 1634 */           System.out.println("Usage : -t Transaction File (transactions.xml)");
/* 1635 */           System.out.println("        -p Property File (applications\\maximo\\properties\\maximo.properties) and it will look in the properties directory for the file you specify");
/* 1636 */           System.out.println("        -l Update MAXLABELS in DB. (true if not specified)");
/* 1637 */           System.out.println("        -s Specify source application's name for product extentions");
/* 1638 */           System.out.println("        -a Specify target application's name for product extentions");
/* 1639 */           System.out.println();
/* 1640 */           System.exit(1);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1648 */       MXApplyTransactions apply = new MXApplyTransactions();
/*      */ 
/* 1650 */       if (sourceApp != null)
/*      */       {
/* 1652 */         if (targetApp == null)
/*      */         {
/* 1654 */           System.out.println("The (-a) Target Application's name parameter must be specified when the (-s) source application name is property is specified.");
/* 1655 */           System.exit(0);
/*      */         }
/*      */ 
/* 1658 */         apply.setSourceApp(sourceApp);
/* 1659 */         apply.setTargetApp(targetApp);
/*      */       }
/*      */ 
/* 1662 */       InputStream in = new Object().getClass().getResourceAsStream(new StringBuilder().append("/").append(propertiesFilename).toString());
/* 1663 */       Properties properties = MXProperties.loadProperties(in, true);
/*      */ 
/* 1665 */       String url = properties.getProperty("mxe.db.url", "");
/* 1666 */       String user = properties.getProperty("mxe.db.user", "maximo");
/* 1667 */       String password = properties.getProperty("mxe.db.password", "maximo");
/* 1668 */       String schemaowner = properties.getProperty("mxe.db.schemaowner", "MAXIMO");
/*      */ 
/* 1670 */       Driver driver = (Driver)Class.forName(properties.getProperty("mxe.db.driver", "sun.jdbc.odbc.JdbcOdbcDriver")).newInstance();
/* 1671 */       DriverManager.registerDriver(driver);
/*      */ 
/* 1673 */       Connection con = DBConnect.getConnection(url, user, password, schemaowner);
/*      */ 
/* 1675 */       apply.setConnection(con);
/* 1676 */       apply.setTransactionStream(transactionFilename);
/* 1677 */       apply.setLogStream(System.out);
/* 1678 */       apply.setUpdateLabels(updateMAXLabels);

/*      */ 
/* 1681 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 1682 */       dbf.setValidating(false);
/* 1683 */       Document updateScriptDocument = dbf.newDocumentBuilder().newDocument();
/*      */ 
/* 1685 */       apply.setUpdateScriptDocument(updateScriptDocument);

/*      */ 
/* 1688 */       Element updateScript = updateScriptDocument.createElement("updatescript");
/*      */ 
/* 1690 */       apply.setUpdateScriptElement(updateScript);
/*      */ 
/* 1692 */       apply.applyTransactions();

/*      */ 
/* 1695 */       con.commit();
/* 1696 */       con.close();
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1700 */       t.printStackTrace();
/* 1701 */       System.exit(1);
/*      */     }
/*      */ 
/* 1704 */     System.exit(0);
/*      */   }
/*      */ }
