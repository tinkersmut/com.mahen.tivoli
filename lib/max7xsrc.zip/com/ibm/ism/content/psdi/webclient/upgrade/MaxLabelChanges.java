/*     */ package com.ibm.ism.content.psdi.webclient.upgrade;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 




































/*     */ public class MaxLabelChanges
/*     */   implements Collection<PropertyChange>
/*     */ {
/*     */   Map<String, PropertyChange> map;
/*     */ 
/*     */   public MaxLabelChanges()
/*     */   {
/*  51 */     clear();
/*     */   }




/*     */   public int size()
/*     */   {
/*  59 */     return this.map.size();
/*     */   }




/*     */   public boolean isEmpty()
/*     */   {
/*  67 */     return this.map.isEmpty();
/*     */   }




/*     */   public boolean contains(Object o)
/*     */   {
/*  75 */     if (o instanceof PropertyChange) {
/*  76 */       return this.map.containsKey(((PropertyChange)o).id + "." + ((PropertyChange)o).property);
/*     */     }
/*  78 */     return this.map.containsKey(o);
/*     */   }




/*     */   public Iterator<PropertyChange> iterator()
/*     */   {
/*  86 */     return this.map.values().iterator();
/*     */   }




/*     */   public Object[] toArray()
/*     */   {
/*  94 */     return this.map.values().toArray();
/*     */   }





/*     */   public Object[] toArray(Object[] a)
/*     */   {
/* 103 */     return this.map.values().toArray(a);
/*     */   }






/*     */   public boolean add(PropertyChange pc)
/*     */   {
/* 113 */     PropertyChange existing = (PropertyChange)this.map.get(pc.id + "." + pc.property);
/* 114 */     if (existing != null)

/*     */     {
/* 117 */       this.map.remove(existing);
/*     */ 
/* 119 */       if (pc.removeProperty)

/*     */       {
/* 122 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 127 */     this.map.put(pc.id + "." + pc.property, pc);
/*     */ 
/* 129 */     return true;
/*     */   }




/*     */   public boolean remove(Object o)
/*     */   {
/* 137 */     PropertyChange pc = (PropertyChange)o;
/* 138 */     return (this.map.remove(pc.id + "." + pc.property) != null);
/*     */   }




/*     */   public boolean containsAll(Collection c)
/*     */   {
/* 146 */     return this.map.values().containsAll(c);
/*     */   }




/*     */   public boolean addAll(Collection c)
/*     */   {
/* 154 */     if (c.isEmpty())
/*     */     {
/* 156 */       return false;
/*     */     }
/*     */ 
/* 159 */     for (Iterator i = c.iterator(); i.hasNext(); )
/*     */     {
/* 161 */       PropertyChange pc = (PropertyChange)i.next();
/* 162 */       add(pc);
/*     */     }
/*     */ 
/* 165 */     return true;
/*     */   }




/*     */   public boolean removeAll(Collection c)
/*     */   {
/* 173 */     boolean removedAny = false;
/* 174 */     for (Iterator i = c.iterator(); i.hasNext(); )
/*     */     {
/* 176 */       PropertyChange pc = (PropertyChange)i.next();
/* 177 */       removedAny = (removedAny) || (remove(pc));
/*     */     }
/*     */ 
/* 180 */     return removedAny;
/*     */   }




/*     */   public boolean retainAll(Collection c)
/*     */   {
/* 188 */     return false;
/*     */   }




/*     */   public void clear()
/*     */   {
/* 196 */     this.map = new HashMap();
/*     */   }
/*     */ }
