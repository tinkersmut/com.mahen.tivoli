/*    */ package com.ibm.ism.content.psdi.webclient.upgrade;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class PresentationLoader
/*    */ {
/* 28 */   public static final HashMap<String, String> MAXLABELS_PROPERTIES = new HashMap();
/*    */ 
/*    */   static {
/* 31 */     MAXLABELS_PROPERTIES.put("boundlabel", "boundlabel");
/* 32 */     MAXLABELS_PROPERTIES.put("collapsedemptylabel", "collapsedemptylabel");
/* 33 */     MAXLABELS_PROPERTIES.put("collapsedlabel", "collapsedlabel");
/* 34 */     MAXLABELS_PROPERTIES.put("description", "description");
/* 35 */     MAXLABELS_PROPERTIES.put("fieldlabel", "fieldlabel");
/* 36 */     MAXLABELS_PROPERTIES.put("innerhtml", "innerhtml");
/* 37 */     MAXLABELS_PROPERTIES.put("label", "label");
/* 38 */     MAXLABELS_PROPERTIES.put("mxevent_desc", "mxevent_desc");
/* 39 */     MAXLABELS_PROPERTIES.put("norowmsg", "norowmsg");
/* 40 */     MAXLABELS_PROPERTIES.put("parentemptylabel", "parentemptylabel");
/* 41 */     MAXLABELS_PROPERTIES.put("title", "title");
/* 42 */     MAXLABELS_PROPERTIES.put("oklabel", "oklabel");
/* 43 */     MAXLABELS_PROPERTIES.put("cancellabel", "cancellabel");
/*    */   }
/*    */ }
