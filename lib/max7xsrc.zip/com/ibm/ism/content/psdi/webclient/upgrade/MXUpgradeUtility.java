/*     */ package com.ibm.ism.content.psdi.webclient.upgrade;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Vector;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 


/*     */ public abstract class MXUpgradeUtility
/*     */ {
/*  44 */   protected static String DEFAULT_CONTROL_REGISTRY_FILENAME = "/control-registry.xml";
/*     */   protected HashMap<String, ArrayList<String>> translatableProperties;
/*     */   protected FileOutputStream outputStream;
/*     */   public String currentApp;
/*     */   PrintStream logStream;
/*     */   protected Document updateScriptDocument;
/*     */   protected Element updateScript;
/*     */   protected Element applicationTag;
/*     */ 
/*     */   public static String getMaximoRoot()
/*     */   {
/*  39 */     return "";
/*     */   }



/*     */   public MXUpgradeUtility()
/*     */   {
/*  46 */     this.translatableProperties = new HashMap();


/*     */ 
/*  50 */     this.outputStream = null;
/*     */ 
/*  52 */     this.currentApp = "";
/*     */ 
/*  54 */     this.logStream = System.out;

/*     */   public void setLogStream(PrintStream ps)
/*     */   {
/*  58 */     this.logStream = ps;
/*     */   }
/*     */ 
/*  61 */     this.updateScriptDocument = null;

/*     */   public void setUpdateScriptDocument(Document d)
/*     */   {
/*  65 */     this.updateScriptDocument = d;
/*     */   }
/*     */ 
/*  68 */     this.updateScript = null;

/*     */   public void setUpdateScriptElement(Element e)
/*     */   {
/*  72 */     this.updateScript = e;
/*     */   }
/*     */ 
/*  75 */     this.applicationTag = null;
/*     */   }
/*     */   public void setApplicationTagElement(Element e)
/*     */   {
/*  79 */     this.applicationTag = e;
/*     */   }

/*     */   protected void setValue(Element modifyTag, Node node)
/*     */   {
/*  84 */     Element updateTag = this.updateScriptDocument.createElement("set-tag-value");
/*  85 */     updateTag.setTextContent(node.getNodeValue());
/*  86 */     modifyTag.appendChild(updateTag);
/*     */   }









/*     */   protected void setAttribute(Node modifyTag, Attr attribute)
/*     */   {
/*  99 */     String value = handleSpecialChars(attribute.getNodeValue());
/*     */ 
/* 101 */     if (value.equals("")) {
/* 102 */       return;
/*     */     }
/* 104 */     Element transactionTag = this.updateScriptDocument.createElement("set");
/* 105 */     transactionTag.setAttribute("property", attribute.getNodeName());
/* 106 */     transactionTag.setAttribute("value", value);
/* 107 */     modifyTag.appendChild(transactionTag);
/*     */   }









/*     */   protected void clearAttribute(Node modifyTag, Attr attribute)
/*     */   {
/* 120 */     Element transactionTag = this.updateScriptDocument.createElement("clear");
/* 121 */     transactionTag.setAttribute("property", attribute.getNodeName());
/* 122 */     modifyTag.appendChild(transactionTag);
/*     */   }

/*     */   protected boolean isTranslatable(Node propNode)
/*     */   {
/* 127 */     boolean isTranslatable = false;
/* 128 */     NodeList children = propNode.getChildNodes();
/* 129 */     for (int i = 0; i < children.getLength(); ++i)
/*     */     {
/* 131 */       Node child = children.item(i);
/* 132 */       if ((!(child.getNodeName().equalsIgnoreCase("flag"))) || (!(child.getAttributes().getNamedItem("name").getNodeValue().equalsIgnoreCase("translatable")))) {
/*     */         continue;
/*     */       }
/* 135 */       isTranslatable = true;
/*     */     }
/*     */ 
/* 138 */     return isTranslatable;
/*     */   }

/*     */   protected boolean isAttrTranslatable(String control, String attribute)
/*     */   {
/* 143 */     ArrayList translatableAttrs = (ArrayList)this.translatableProperties.get(control);



/*     */ 
/* 148 */     return (((translatableAttrs != null) && (translatableAttrs.contains(attribute.toLowerCase()))) || (PresentationLoader.MAXLABELS_PROPERTIES.containsValue(attribute.toLowerCase())));
/*     */   }


/*     */   protected boolean isAttrTranslatable(Attr attribute)
/*     */   {
/* 154 */     return isAttrTranslatable(attribute.getOwnerElement().getNodeName(), attribute.getNodeName());
/*     */   }


/*     */   private Enumeration<String> getControlRegistryFileList()
/*     */   {
/* 160 */     Vector v = new Vector();


/*     */ 
/* 164 */     v.add(DEFAULT_CONTROL_REGISTRY_FILENAME);













/*     */ 
/* 179 */     return v.elements();
/*     */   }

/*     */   protected void loadTranslatableProperties()
/*     */     throws SAXException, IOException, ParserConfigurationException
/*     */   {
/* 185 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 186 */     dbf.setValidating(false);
/*     */ 
/* 188 */     Enumeration e = getControlRegistryFileList();
/*     */ 
/* 190 */     while (e.hasMoreElements())
/*     */     {
/* 192 */       String file = (String)e.nextElement();

/*     */ 
/* 195 */       InputStream in = super.getClass().getResourceAsStream(file);
/* 196 */       InputSource source = new InputSource(in);
/*     */ 
/* 198 */       Document propertiesDocument = dbf.newDocumentBuilder().parse(source);
/*     */ 
/* 200 */       Element docElement = propertiesDocument.getDocumentElement();
/*     */ 
/* 202 */       if (!(docElement.getNodeName().equalsIgnoreCase("control-registry"))) {
/*     */         continue;
/*     */       }
/* 205 */       NodeList list = docElement.getElementsByTagName("flag");
/*     */ 
/* 207 */       for (int x = 0; x < list.getLength(); ++x)
/*     */       {
/* 209 */         Node trans = list.item(x);
/*     */ 
/* 211 */         if (!(((Element)trans).getAttribute("name").equalsIgnoreCase("translatable")))
/*     */           continue;
/* 213 */         Node prop = trans.getParentNode();
/* 214 */         String propName = ((Element)prop).getAttribute("name").toLowerCase();
/*     */ 
/* 216 */         Node descriptor = prop.getParentNode().getParentNode();
/* 217 */         String descriptorName = ((Element)descriptor).getAttribute("name").toLowerCase();
/*     */ 
/* 219 */         ArrayList transProps = (ArrayList)this.translatableProperties.get(descriptorName);
/*     */ 
/* 221 */         if (transProps == null)
/*     */         {
/* 223 */           transProps = new ArrayList();
/* 224 */           this.translatableProperties.put(descriptorName, transProps);
/*     */         }
/*     */ 
/* 227 */         transProps.add(propName.toLowerCase());
/*     */       }
/*     */     }
/*     */   }












/*     */   private static String replaceSpecialCharsForXML(String str, String pattern, String replacement)
/*     */   {
/* 245 */     int i = -1;
/* 246 */     int j = 0;
/*     */ 
/* 248 */     while ((str != null) && (replacement != null) && (pattern != null) && 

/* 250 */       ((i = str.indexOf(pattern, j)) >= 0))
/*     */     {
/* 252 */       String temp = "";
/* 253 */       if (i + replacement.length() > str.length()) temp = str.substring(0);
/*     */       else temp = str.substring(0, i + replacement.length());
/* 255 */       if (!(temp.endsWith(replacement))) {
/* 256 */         String t = new StringBuilder().append(str.substring(0, i)).append(replacement).append(str.substring(i + pattern.length())).toString();
/* 257 */         str = t;
/*     */       }
/* 259 */       j = i + replacement.length();
/*     */     }
/*     */ 
/* 262 */     return str;
/*     */   }








/*     */   protected static String handleSpecialChars(String str)
/*     */   {
/* 274 */     String strUpdated = str;
/*     */ 
/* 276 */     strUpdated = replaceSpecialCharsForXML(strUpdated, "&", "&amp;");
/* 277 */     strUpdated = replaceSpecialCharsForXML(strUpdated, "<", "&lt;");
/* 278 */     strUpdated = replaceSpecialCharsForXML(strUpdated, ">", "&gt;");
/* 279 */     strUpdated = replaceSpecialCharsForXML(strUpdated, "\"", "&quot;");


/*     */ 
/* 283 */     strUpdated = replaceSpecialCharsForXML(strUpdated, "&amp;lt;", "&lt;");
/* 284 */     strUpdated = replaceSpecialCharsForXML(strUpdated, "&amp;gt;", "&gt;");
/* 285 */     strUpdated = replaceSpecialCharsForXML(strUpdated, "&amp;quot;", "&quot;");
/*     */ 
/* 287 */     return strUpdated;
/*     */   }








/*     */   protected String getTabString(int level)
/*     */   {
/* 299 */     String s = "";
/*     */ 
/* 301 */     for (int x = 0; x < level; ++x) {
/* 302 */       s = new StringBuilder().append(s).append("\t").toString();
/*     */     }
/* 304 */     return s;
/*     */   }

/*     */   protected void getFormattedElement(StringBuffer sb, int level, Element e)
/*     */   {
/* 309 */     String nodeName = e.getNodeName();
/* 310 */     NodeList nodeList = e.getChildNodes();
/* 311 */     boolean isRepLib = (e.getNodeName().equalsIgnoreCase("systemlib")) && (e.getAttribute("id").toUpperCase().startsWith("REPLIB"));
/* 312 */     boolean hasChildren = (e.hasChildNodes()) || (isRepLib);
/* 313 */     NamedNodeMap attrList = e.getAttributes();
/*     */ 
/* 315 */     if ((nodeName.equalsIgnoreCase("dialog")) || (nodeName.equalsIgnoreCase("presentation")))
/*     */     {
/* 317 */       sb.append("\n");
/*     */     }
/* 319 */     if (nodeName.equalsIgnoreCase("presentationset")) {
/* 320 */       sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
/*     */     }
/* 322 */     sb.append(new StringBuilder().append(getTabString(level)).append("<").append(nodeName).toString());


/*     */ 
/* 326 */     for (int x = 0; x < attrList.getLength(); ++x)
/*     */     {
/* 328 */       Node n = attrList.item(x);
/* 329 */       if (!(n.getNodeName().equalsIgnoreCase("ADDED-BY-PRODUCT-UPDATE"))) {
/* 330 */         sb.append(new StringBuilder().append(" ").append(n.getNodeName()).append("=\"").append(handleSpecialChars(n.getNodeValue())).append("\"").toString());
/*     */       }
/*     */     }
/* 333 */     boolean isTextNode = (isRepLib) || ((hasChildren) && (nodeList.item(0).getNodeType() == 3) && (!(nodeList.item(0).getNodeValue().trim().equals(""))));
/*     */ 
/* 335 */     boolean hasElements = false;
/*     */ 
/* 337 */     for (int x = 0; x < nodeList.getLength(); ++x)
/*     */     {
/* 339 */       if (!(nodeList.item(x) instanceof Element))
/*     */         continue;
/* 341 */       hasElements = true;
/* 342 */       break;

/*     */     }
/*     */ 
/* 346 */     sb.append(((hasElements) || (isTextNode)) ? ">" : "/>");
/*     */ 
/* 348 */     if (!(isTextNode)) {
/* 349 */       sb.append("\n");

/*     */     }
/*     */ 
/* 353 */     for (int x = 0; x < nodeList.getLength(); ++x)
/*     */     {
/* 355 */       if (nodeList.item(x) instanceof Element)
/* 356 */         getFormattedElement(sb, level + 1, (Element)nodeList.item(x));
/* 357 */       else if (isTextNode) {
/* 358 */         sb.append(handleSpecialChars(nodeList.item(x).getNodeValue()));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 363 */     if ((hasElements) || (isTextNode))
/* 364 */       sb.append(new StringBuilder().append((isTextNode) ? "" : getTabString(level)).append("</").append(nodeName).append(">\n").toString());
/*     */   }








































































/*     */   protected void writeFormatedDocument(PrintStream outStream, int level, Element e)
/*     */   {
/* 440 */     StringBuffer stringBuffer = new StringBuffer();
/* 441 */     getFormattedElement(stringBuffer, 0, e);
/* 442 */     outStream.print(stringBuffer);
/*     */   }

/*     */   public void writeFormatedDocument(String filename, Element e) throws Exception
/*     */   {
/* 447 */     PrintStream out = new PrintStream(filename);
/* 448 */     out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/* 449 */     writeFormatedDocument(out, 0, e);
/* 450 */     out.close();
/*     */   }

/*     */   public Document parse(String filename)
/*     */   {
/* 455 */     Document document = null;
/*     */ 
/* 457 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 458 */     dbf.setValidating(false);

/*     */     try
/*     */     {
/* 462 */       FileReader f = new FileReader(filename);
/* 463 */       InputSource source = new InputSource(f);
/* 464 */       source.setEncoding(f.getEncoding());
/* 465 */       document = dbf.newDocumentBuilder().parse(source);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 469 */       System.out.println();
/* 470 */       System.out.println(new StringBuilder().append("ERROR: Unable to open ").append(filename).append(" document ").append(t.getMessage()).toString());
/* 471 */       System.out.println();
/*     */     }
/*     */ 
/* 474 */     return document;
/*     */   }

/*     */   protected String fixupKeyName(Element element, String keyName)
/*     */   {
/* 479 */     String nodeName = element.getNodeName();
/* 480 */     String tmpKey = keyName;
/*     */ 
/* 482 */     if ((nodeName.equalsIgnoreCase("ascending")) || (nodeName.equalsIgnoreCase("descending"))) {
/* 483 */       tmpKey = "mobilemboattribute";
/* 484 */     } else if (nodeName.equalsIgnoreCase("mbodependentfilter")) {
/* 485 */       tmpKey = "dependson";
/* 486 */     } else if (nodeName.equalsIgnoreCase("filtercondition"))
/*     */     {
/* 488 */       tmpKey = (element.hasAttribute("dbtype")) ? "dbtype" : "";
/*     */     }
/* 490 */     else if (nodeName.equalsIgnoreCase("match"))
/*     */     {
/* 492 */       if (element.hasAttribute("dependsonmobilemboattribute"))
/* 493 */         tmpKey = "dependsonmobilemboattribute";
/* 494 */       if (element.hasAttribute("parentmobilemboattribute"))
/* 495 */         tmpKey = "parentmobilemboattribute";
/* 496 */       if (element.hasAttribute("mobilemboattribute"))
/* 497 */         tmpKey = "mobilemboattribute";
/*     */     }
/* 499 */     else if ((nodeName.equalsIgnoreCase("mobileapp-cdc")) || (nodeName.equalsIgnoreCase("mobilembo")) || (nodeName.equalsIgnoreCase("mobilemboattribute")))

/*     */     {
/* 502 */       tmpKey = "name";
/* 503 */     } else if ((nodeName.equalsIgnoreCase("mobilembos")) || (nodeName.equalsIgnoreCase("mobilescreens")) || (nodeName.equalsIgnoreCase("mobilemessages")) || (nodeName.equalsIgnoreCase("mboorderby")) || (nodeName.equalsIgnoreCase("mbofilter")))



/*     */     {
/* 508 */       tmpKey = "";
/* 509 */     } else if (element.hasAttribute("id")) {
/* 510 */       tmpKey = "id";
/* 511 */     } else if (element.getNodeName().equalsIgnoreCase("mobilemessage")) {
/* 512 */       tmpKey = "key";
/*     */     }
/* 514 */     return tmpKey;
/*     */   }

/*     */   protected Element createTagID(String tagName, String tagType, String keyName, String keyValue)
/*     */   {
/* 519 */     Element pathTag = this.updateScriptDocument.createElement(tagName);
/*     */ 
/* 521 */     Element element = this.updateScriptDocument.createElement("tag-type");
/* 522 */     element.setTextContent(tagType);
/*     */ 
/* 524 */     pathTag.appendChild(element);
/*     */ 
/* 526 */     if (!(keyName.equals("")))
/*     */     {
/* 528 */       element = this.updateScriptDocument.createElement("key-name");
/* 529 */       element.setTextContent(keyName);
/* 530 */       pathTag.appendChild(element);
/*     */ 
/* 532 */       element = this.updateScriptDocument.createElement("key-value");
/* 533 */       element.setTextContent(keyValue);
/* 534 */       pathTag.appendChild(element);
/*     */     }
/*     */ 
/* 537 */     return pathTag;
/*     */   }

/*     */   protected Element createLocationTag(Node node, String keyName, String tagName, boolean includeNode)
/*     */   {
/* 542 */     Element tagLocation = this.updateScriptDocument.createElement(tagName);
/*     */ 
/* 544 */     Element refNode = null;
/*     */ 
/* 546 */     for (Node n = (includeNode) ? node : node.getParentNode(); (n != null) && (n instanceof Element); n = n.getParentNode())
/*     */     {
/* 548 */       if (n.getNodeName().equalsIgnoreCase("mobileapp-cdc")) {
/*     */         break;
/*     */       }
/* 551 */       keyName = fixupKeyName((Element)n, keyName);
/*     */ 
/* 553 */       Element keyTag = createTagID("tag-key", n.getNodeName(), keyName, ((Element)n).getAttribute(keyName));
/*     */ 
/* 555 */       if (refNode == null)
/* 556 */         tagLocation.appendChild(keyTag);
/*     */       else {
/* 558 */         tagLocation.insertBefore(keyTag, refNode);
/*     */       }
/* 560 */       refNode = keyTag;
/*     */     }
/*     */ 
/* 563 */     return tagLocation;
/*     */   }
/*     */ }
