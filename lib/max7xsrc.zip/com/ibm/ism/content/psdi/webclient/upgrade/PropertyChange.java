/*    */ package com.ibm.ism.content.psdi.webclient.upgrade;
/*    */ 
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 




























/*    */ class PropertyChange
/*    */ {
/*    */   boolean removeProperty;
/*    */   String property;
/*    */   String id;
/*    */   String value;
/*    */ 
/*    */   PropertyChange(boolean clearLabel, String property, String id, String newValue)
/*    */   {
/* 44 */     this.removeProperty = clearLabel;
/* 45 */     this.property = property;
/* 46 */     this.id = id;
/* 47 */     this.value = newValue;
/*    */   }



/*    */   PropertyChange(Element change)
/*    */     throws Exception
/*    */   {
/* 55 */     String updateCommand = change.getNodeName().toLowerCase();
/* 56 */     if (updateCommand.equals("set"))
/*    */     {
/* 58 */       this.removeProperty = false;
/* 59 */       this.property = change.getAttribute("property");
/* 60 */       this.value = change.getAttribute("value");
/* 61 */       this.id = null;
/*    */     }
/* 63 */     else if (updateCommand.equals("clear"))
/*    */     {
/* 65 */       this.removeProperty = true;
/* 66 */       this.property = change.getAttribute("property");
/* 67 */       this.value = null;
/* 68 */       this.id = null;
/*    */     }
/* 70 */     else if (updateCommand.equals("set-tag-value"))
/*    */     {
/* 72 */       this.removeProperty = false;
/* 73 */       this.property = "set-tag-value";
/*    */ 
/* 75 */       NodeList list = change.getChildNodes();
/*    */ 
/* 77 */       for (int x = 0; x < list.getLength(); ++x)
/*    */       {
/* 79 */         this.value = list.item(x).getNodeValue().trim();
/*    */       }
/*    */ 
/* 82 */       this.id = null;
/*    */     }
/*    */     else
/*    */     {
/* 86 */       throw new Exception("Unknown update property command of '" + updateCommand + "'.");
/*    */     }
/*    */   }

/*    */   public String toString()
/*    */   {
/* 92 */     return this.property + "." + this.id;
/*    */   }
/*    */ }
