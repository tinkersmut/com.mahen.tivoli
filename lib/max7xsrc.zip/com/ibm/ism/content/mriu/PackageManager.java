/*     */ package com.ibm.ism.content.mriu;
/*     */ 
/*     */ import com.ibm.ism.content.mriu.model.MRIUPackage;
/*     */ import com.ibm.ism.content.mriu.model.Message;
/*     */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*     */ import com.ibm.ism.contentinstaller.tools.SaxErrorHandler;
/*     */ import com.ibm.ism.contentinstaller.tools.monitors.IProgressMonitor;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 





























/*     */ public class PackageManager
/*     */ {
/*     */   private static final String CLASSNAME = "PackageManager";
/*  43 */   private final ContentCatalogLogger log = new ContentCatalogLogger(MXLoggerFactory.getLogger("maximo.service.SYSTEM.IBMCONTENTCATALOG"));
/*     */ 
/*     */   public void parsePackageImport(MRIUPackage mriuPackage, URI pkgUri, DefaultPackageResolver resolver)
/*     */     throws Exception
/*     */   {
/*  60 */     String METHOD = "parsePackageImport";
/*  61 */     this.log.debugEntry("PackageManager", "parsePackageImport");
/*     */ 
/*  63 */     InputStream is = null;
/*  64 */     if (pkgUri.getPath().endsWith(".zip"))
/*  65 */       is = getInputStreamFromZip(pkgUri, "Package/ImportPackage.xml");
/*  66 */     else if (pkgUri.getPath().endsWith(".jar"))
/*  67 */       is = getInputStreamFromJar(pkgUri, "Package/ImportPackage.xml");
/*     */     else {
/*  69 */       is = new FileInputStream(new File(pkgUri));
/*     */     }
/*     */ 
/*  72 */     this.log.debug("PackageManager", "parsePackageImport", "Got the inputstream");
/*  73 */     parsePackage(mriuPackage, is, new PackageImportParser(resolver, pkgUri), resolver);


/*     */ 
/*  77 */     if (!(mriuPackage.getFiles().isEmpty()))
/*     */       return;
/*  79 */     mriuPackage.setHasError(true);
/*  80 */     mriuPackage.addMessage(Message.newError("Message.No_Package_To_Import", null));
/*     */   }








/*     */   private void parsePackage(MRIUPackage mriuPackage, InputStream is, PackageImportParser parser, DefaultPackageResolver packageResolver)
/*     */   {
/*  92 */     String METHOD = "parsePackage";
/*  93 */     this.log.debugEntry("PackageManager", "parsePackage");
/*  94 */     Document dom = parseXmlFile(is, parser, packageResolver, false);
/*  95 */     parser.parse(mriuPackage, dom);
/*     */   }

/*     */   private InputStream getInputStreamFromZip(URI pkgUri, String fileToFind) throws Exception {
/*  99 */     InputStream is = null;
/* 100 */     ZipFile zf = new ZipFile(new File(pkgUri));
/* 101 */     Enumeration entries = zf.entries();
/* 102 */     while (entries.hasMoreElements()) {
/* 103 */       ZipEntry ze = (ZipEntry)entries.nextElement();
/* 104 */       if (ze.getName().equalsIgnoreCase(fileToFind)) {
/* 105 */         is = zf.getInputStream(ze);
/* 106 */         break;
/*     */       }
/*     */     }
/* 109 */     return is;
/*     */   }

/*     */   private InputStream getInputStreamFromJar(URI pkgUri, String fileToFind) throws Exception {
/* 113 */     InputStream is = null;
/* 114 */     JarFile jf = new JarFile(new File(pkgUri));
/* 115 */     Enumeration entries = jf.entries();
/* 116 */     while (entries.hasMoreElements()) {
/* 117 */       JarEntry je = (JarEntry)entries.nextElement();
/* 118 */       if (je.getName().equalsIgnoreCase(fileToFind)) {
/* 119 */         is = jf.getInputStream(je);
/* 120 */         break;
/*     */       }
/*     */     }
/* 123 */     return is;
/*     */   }

/*     */   private Document parseXmlFile(InputStream inputStream, PackageImportParser parser, DefaultPackageResolver packageResolver, boolean validating) {
/* 127 */     Document dom = null;
/*     */     try {
/* 129 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 130 */       factory.setValidating(validating);
/* 131 */       factory.setIgnoringComments(true);
/* 132 */       factory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");

/*     */ 
/* 135 */       factory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaSource", packageResolver.resolveSchemaPath(parser.getSchemaSource()));



/*     */ 
/* 140 */       DocumentBuilder db = factory.newDocumentBuilder();
/* 141 */       db.setErrorHandler(new SaxErrorHandler());
/* 142 */       dom = db.parse(inputStream);
/*     */     }
/*     */     catch (Exception e) {
/* 145 */       packageResolver.getProgressMonitor().setError("Failed to parse XML file.", e);
/*     */     }
/* 147 */     return dom;
/*     */   }
/*     */ }
