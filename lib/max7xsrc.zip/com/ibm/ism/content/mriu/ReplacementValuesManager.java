/*     */ package com.ibm.ism.content.mriu;
/*     */ 
/*     */ import com.ibm.ism.contentinstaller.service.MaximoResolver;
/*     */ import com.ibm.ism.contentinstaller.tools.DBUtils;
/*     */ import com.ibm.ism.contentinstaller.tools.monitors.IProgressMonitor;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Element;
/*     */ 





















/*     */ public class ReplacementValuesManager
/*     */ {
/*  41 */   private Map<String, Query> replacementQueries = null;
/*  42 */   private Map<String, AbstractReplacementValue> replacements = null;
/*     */ 
/*     */   public class Query
/*     */   {
/*  45 */     public String id = null;
/*  46 */     public String name = null;
/*  47 */     public String description = null;
/*  48 */     public String query = null;
/*  49 */     public String value = null;
/*  50 */     public boolean pkgDefault = false;
/*  51 */     public String pattern = null;
/*  52 */     public String defaultValue = null;
/*     */ 
/*     */     public Query(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean, String paramString6, String paramString7) {
/*  55 */       this.id = paramString1;
/*  56 */       this.name = paramString2;
/*  57 */       this.description = paramString3;
/*  58 */       this.query = paramString4;
/*  59 */       this.value = value;
/*  60 */       this.pkgDefault = paramBoolean;
/*  61 */       this.pattern = paramString6;
/*  62 */       this.defaultValue = paramString7;
/*     */     }
/*     */   }
/*     */   public ReplacementValuesManager()
/*     */   {
/*  67 */     this.replacementQueries = new HashMap();
/*  68 */     this.replacements = new HashMap();
/*     */   }

/*     */   public void addReplacementQueryTag(Element element) {
/*  72 */     String id = element.getAttribute("id");
/*  73 */     String column = element.getAttribute("column");
/*  74 */     String description = element.getAttribute("description");
/*  75 */     String query = element.getAttribute("query");
/*  76 */     String value = element.getAttribute("value");
/*  77 */     boolean enforce = Boolean.parseBoolean(element.getAttribute("enforce"));
/*  78 */     String pattern = element.getAttribute("pattern");
/*  79 */     String defaultvalue = element.getAttribute("defaultValue");
/*     */ 
/*  81 */     this.replacementQueries.put(id, new Query(id, column, description, query, value, enforce, pattern, defaultvalue));
/*     */   }



/*     */   public boolean preloadReplacementQueries(MaximoResolver maximoResolver, IProgressMonitor monitor)
/*     */   {
/*  88 */     boolean hasError = false;
/*     */ 
/*  90 */     monitor.setTask("Determining replacement query values:");
/*     */ 
/*  92 */     for (String key : this.replacementQueries.keySet()) {
/*  93 */       Query query = (Query)this.replacementQueries.get(key);
/*     */       try
/*     */       {
/*  96 */         AbstractReplacementValue newReplacement = null;

/*     */ 
/*  99 */         monitor.setTask("Running query: " + query.query);
/* 100 */         List results = executeQuery(query, maximoResolver);
/* 101 */         monitor.setTask("  Results found: " + results.size());
/*     */ 
/* 103 */         newReplacement = new SelectionReplacementValue(query.id, query.name, query.description, query.pkgDefault, query.pattern, query.defaultValue);
/* 104 */         newReplacement.addValues(results);

/*     */ 
/* 107 */         if (newReplacement != null)
/* 108 */           this.replacements.put(newReplacement.getId(), newReplacement);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 112 */         hasError = true;
/* 113 */         monitor.setError("Failed to load query: " + query, e);
/*     */       }
/*     */     }
/*     */ 
/* 117 */     if (hasError) {
/* 118 */       monitor.setError("Errors were reported during the preloading of the replacement queries");
/*     */     }
/*     */ 
/* 121 */     return hasError;
/*     */   }

/*     */   private List<String> executeQuery(Query query, MaximoResolver maximoResolver) throws Exception {
/* 125 */     List results = new ArrayList();
/*     */ 
/* 127 */     Connection conn = null;
/* 128 */     PreparedStatement statement = null;
/* 129 */     ResultSet result = null;
/*     */     try {
/* 131 */       conn = DBUtils.getConnection(maximoResolver);
/* 132 */       conn.setAutoCommit(true);
/* 133 */       statement = conn.prepareStatement(query.query);
/* 134 */       result = statement.executeQuery();
/* 135 */       while (result.next())
/* 136 */         results.add(result.getString(1));
/*     */     }
/*     */     finally {
/* 139 */       release(conn, statement, result);
/*     */     }
/*     */ 
/* 142 */     return results;
/*     */   }



/*     */   private void release(Connection conn, PreparedStatement statement, ResultSet result)
/*     */   {
/*     */     try
/*     */     {
/* 151 */       if (result != null)
/* 152 */         result.close();
/*     */     }
/*     */     catch (SQLException e) {
/* 155 */       System.err.println("Failed to close ResultSet");
/*     */     }
/*     */     try
/*     */     {
/* 159 */       if (statement != null)
/* 160 */         statement.close();
/*     */     }
/*     */     catch (SQLException e) {
/* 163 */       System.err.println("Failed to close PreparedStatement");
/*     */     }
/*     */ 
/* 166 */     DBUtils.releaseDatabaseConnection(conn);
/*     */   }
/*     */ }
