/*    */ package com.ibm.ism.content.mriu;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 


















/*    */ public abstract class AbstractReplacementValue
/*    */   implements Cloneable
/*    */ {
/*    */   public static final int TYPE_SELECTION = 1;
/* 29 */   private String id = null;
/* 30 */   private String columnName = null;
/* 31 */   private String description = null;
/* 32 */   private boolean shouldEnforce = false;
/* 33 */   private String pattern = null;
/* 34 */   private String defaultValue = null;
/* 35 */   private List<String> values = null;
/*    */ 
/*    */   public AbstractReplacementValue(String id, String columnName, String description, boolean shouldEnforce, String pattern, String defaultValue) {
/* 38 */     this.id = id;
/* 39 */     this.columnName = columnName;
/* 40 */     this.description = description;
/* 41 */     this.shouldEnforce = shouldEnforce;
/* 42 */     this.pattern = pattern;
/* 43 */     this.defaultValue = defaultValue;
/* 44 */     this.values = new ArrayList();
/*    */   }

/*    */   public Object clone()
/*    */     throws CloneNotSupportedException
/*    */   {
/* 50 */     return super.clone();
/*    */   }

/*    */   public String getId() {
/* 54 */     return this.id;
/*    */   }

/*    */   public String getColumnName() {
/* 58 */     return this.columnName;
/*    */   }

/*    */   public boolean shouldEnforce() {
/* 62 */     return this.shouldEnforce;
/*    */   }

/*    */   public void setShouldEnforce(boolean shouldEnforce) {
/* 66 */     this.shouldEnforce = shouldEnforce;
/*    */   }

/*    */   public List<String> getValues() {
/* 70 */     return this.values;
/*    */   }

/*    */   public void addValue(String value) {
/* 74 */     this.values.add(value);
/*    */   }

/*    */   public void addValues(Collection<String> newValues) {
/* 78 */     this.values.addAll(newValues);
/*    */   }

/*    */   public String getDescription() {
/* 82 */     return this.description;
/*    */   }

/*    */   public String getPattern() {
/* 86 */     return this.pattern;
/*    */   }

/*    */   public String getDefaultValue() {
/* 90 */     return this.defaultValue;
/*    */   }
/*    */ }
