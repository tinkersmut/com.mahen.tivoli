package com.ibm.ism.content.mriu;

public abstract interface PackageConstants
{
  public static final String PACKAGE_TAGE = "package";
  public static final String REPLACEMENT_QUERY_TAG = "replacementquery";
  public static final String REPLACEMENTS_TAG = "replacements";
  public static final String REPLACEMENT_TAG = "replacement";
  public static final String GROUP_TAG = "group";
  public static final String SUMMARY_TAG = "summary";
  public static final String FILE_TAG = "file";
  public static final String SCRIPT_TAG = "script";
  public static final String OPTION_TAG = "option";
  public static final String OBJECT_STRUCTURE_TAG = "objectstructure";
  public static final String WHERE_CLAUSE_TAG = "whereclause";
  public static final String OUTPUT_TAG = "output";
  public static final String ID_ATTRIBUTE = "id";
  public static final String COLUMN_ATTRIBUTE = "column";
  public static final String DESCRIPTION_ATTRIBUTE = "description";
  public static final String NAME_ATTRIBUTE = "name";
  public static final String QUERY_LIMIT_ATTRIBUTE = "queryLimit";
  public static final String PATH_ATTRIBUTE = "path";
  public static final String REQUIRED_ATTRIBUTE = "required";
  public static final String ENFORCE_ATTRIBUTE = "enforce";
  public static final String PATTERN_ATTRIBUTE = "pattern";
  public static final String QUERY_ATTRIBUTE = "query";
  public static final String REF_ATTRIBUTE = "ref";
  public static final String VALUE_ATTRIBUTE = "value";
  public static final String DATA_DIR_ATTRIBUTE = "data-dir";
  public static final String TYPE_ATTRIBUTE = "type";
  public static final String DEFAULT_VALUE_ATTRIBUTE = "defaultValue";
  public static final String TYPE_OPTION_MRIU = "mriu";
  public static final String TYPE_OPTION_MXS = "mxs";
}
