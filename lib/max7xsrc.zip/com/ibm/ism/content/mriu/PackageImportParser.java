/*     */ package com.ibm.ism.content.mriu;
/*     */ 
/*     */ import com.ibm.ism.content.mriu.model.FilePath;
/*     */ import com.ibm.ism.content.mriu.model.MRIUPackage;
/*     */ import com.ibm.ism.content.mriu.model.ReplacementQuery;
/*     */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*     */ import com.ibm.ism.contentinstaller.service.MaximoResolver;
/*     */ import com.ibm.ism.contentinstaller.tools.DBUtils;
/*     */ import com.ibm.ism.contentinstaller.tools.monitors.IProgressMonitor;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 





















/*     */ public class PackageImportParser extends AbstractPackageParser
/*     */ {
/*     */   private static final String CLASSNAME = "PackageImportParser";
/*  51 */   private final ContentCatalogLogger log = new ContentCatalogLogger(MXLoggerFactory.getLogger("maximo.service.SYSTEM.IBMCONTENTCATALOG"));
/*     */ 
/*  53 */   private DefaultPackageResolver resolver = null;
/*     */ 
/*  55 */   private URI pkgUri = null;
/*  56 */   private String dataDir = null;
/*     */ 
/*     */   public PackageImportParser(DefaultPackageResolver resolver, URI pkgUri) {
/*  59 */     this.resolver = resolver;
/*  60 */     this.pkgUri = pkgUri;
/*     */   }

/*     */   public String getSchemaSource() {
/*  64 */     return "schema/packageimport.xsd";
/*     */   }

/*     */   public void parse(MRIUPackage mriuPackage, Document document)
/*     */   {
/*  69 */     String METHOD = "parse";
/*  70 */     this.log.debugEntry("PackageImportParser", "parse");
/*  71 */     Element rootElement = document.getDocumentElement();

/*     */ 
/*  74 */     String name = rootElement.getAttribute("name");
/*  75 */     String queryLimit = rootElement.getAttribute("queryLimit");
/*  76 */     if (!(StringUtil.isEmpty(name))) {
/*  77 */       mriuPackage.setName(name);
/*     */     }
/*  79 */     if (!(StringUtil.isEmpty(queryLimit))) {
/*  80 */       mriuPackage.setQueryLimit(queryLimit);

/*     */     }
/*     */ 
/*  84 */     processReplacementQueryTags(rootElement, mriuPackage);

/*     */ 
/*  87 */     preloadReplacementQueries(mriuPackage, this.resolver.getMaximoResolver(), this.resolver.getProgressMonitor());

/*     */ 
/*  90 */     processFiles(rootElement, mriuPackage);

/*     */ 
/*  93 */     processScriptTags(rootElement, mriuPackage);
/*     */ 
/*  95 */     this.log.debugExit("PackageImportParser", "parse");
/*     */   }







/*     */   private void processFiles(Node parentElement, MRIUPackage mriuPackage)
/*     */   {
/* 106 */     NodeList children = parentElement.getChildNodes();

/*     */ 
/* 109 */     if (isEmpty(children)) {
/* 110 */       return;
/*     */     }
/*     */ 
/* 113 */     for (int i = 0; i < children.getLength(); ++i) {
/* 114 */       Node currentNode = children.item(i);
/*     */ 
/* 116 */       if (!(currentNode.getNodeName().equals("file")))
/*     */         continue;
/* 118 */       Element element = (Element)currentNode;
/*     */ 
/* 120 */       String path = element.getAttribute("path");
/* 121 */       String name = element.getAttribute("name");
/* 122 */       String type = element.getAttribute("type");
/* 123 */       boolean required = Boolean.parseBoolean(element.getAttribute("required"));
/*     */ 
/* 125 */       FilePath file = new FilePath();
/* 126 */       file.setPath(path);
/* 127 */       file.setName(name);
/* 128 */       file.setType(type);
/* 129 */       file.setRequired(required);
/*     */ 
/* 131 */       if ((this.pkgUri.getPath().endsWith("zip")) || (this.pkgUri.getPath().endsWith("jar")))
/*     */       {
/*     */         try {
/* 134 */           URI uri = new URI(this.pkgUri.getScheme(), null, this.pkgUri.getPath(), path);
/* 135 */           path = uri.toString();
/*     */         } catch (URISyntaxException e) {
/* 137 */           e.printStackTrace();
/*     */         }
/*     */       } else {
/* 140 */         File absolutePath = this.resolver.resolveObjectStructureDir(path);
/* 141 */         path = absolutePath.getAbsolutePath();
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 146 */         file.setPathURI(new URI(path));
/*     */       }
/*     */       catch (URISyntaxException e)
/*     */       {
/*     */       }
/*     */ 
/* 152 */       mriuPackage.addFile(file);
/*     */     }
/*     */   }








/*     */   private void processScriptTags(Node parentElement, MRIUPackage mriuPackage)
/*     */   {
/* 165 */     NodeList children = parentElement.getChildNodes();

/*     */ 
/* 168 */     if (isEmpty(children)) {
/* 169 */       return;
/*     */     }
/*     */ 
/* 172 */     for (int i = 0; i < children.getLength(); ++i) {
/* 173 */       Node currentNode = children.item(i);
/*     */ 
/* 175 */       if (!(currentNode.getNodeName().equals("script")))
/*     */         continue;
/* 177 */       Element element = (Element)currentNode;
/*     */ 
/* 179 */       String path = element.getAttribute("path");
/* 180 */       String name = element.getAttribute("name");
/*     */ 
/* 182 */       FilePath file = new FilePath();
/* 183 */       file.setPath(path);
/* 184 */       file.setName(name);
/*     */ 
/* 186 */       if ((this.pkgUri.getPath().endsWith("zip")) || (this.pkgUri.getPath().endsWith("jar")))
/*     */       {
/*     */         try {
/* 189 */           URI uri = new URI(this.pkgUri.getScheme(), null, this.pkgUri.getPath(), path);
/* 190 */           path = uri.toString();
/*     */         } catch (URISyntaxException e) {
/* 192 */           e.printStackTrace();
/*     */         }
/*     */       } else {
/* 195 */         File absolutePath = this.resolver.resolveObjectStructureDir(path);
/* 196 */         path = absolutePath.getAbsolutePath();
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 201 */         file.setPathURI(new URI(path));
/*     */       }
/*     */       catch (URISyntaxException e)
/*     */       {
/*     */       }
/*     */ 
/* 207 */       mriuPackage.addJythonScript(file);
/* 208 */       return;
/*     */     }
/*     */   }






/*     */   private void processReplacementQueryTags(Element rootElement, MRIUPackage packageTag)
/*     */   {
/* 219 */     NodeList nodeList = rootElement.getChildNodes();
/* 220 */     if (isEmpty(nodeList)) {
/* 221 */       return;
/*     */     }
/*     */ 
/* 224 */     for (int i = 0; i < nodeList.getLength(); ++i) {
/* 225 */       Node currentNode = nodeList.item(i);
/*     */ 
/* 227 */       if (!(currentNode.getNodeName().equals("replacementquery")))
/*     */         continue;
/* 229 */       Element rqElement = (Element)nodeList.item(i);
/* 230 */       String id = rqElement.getAttribute("id");
/* 231 */       String column = rqElement.getAttribute("column");
/* 232 */       String description = rqElement.getAttribute("description");
/* 233 */       String query = rqElement.getAttribute("query");
/* 234 */       String value = rqElement.getAttribute("value");
/* 235 */       boolean enforce = Boolean.parseBoolean(rqElement.getAttribute("enforce"));
/* 236 */       String pattern = rqElement.getAttribute("pattern");
/* 237 */       String defaultValue = rqElement.getAttribute("defaultValue");
/*     */ 
/* 239 */       ReplacementQuery replacementQuery = new ReplacementQuery();
/* 240 */       replacementQuery.setId(id);
/* 241 */       replacementQuery.setColumn(column);
/* 242 */       replacementQuery.setDescription(description);
/* 243 */       replacementQuery.setQuery(query);
/* 244 */       replacementQuery.setValue(value);
/* 245 */       replacementQuery.setEnforce(enforce);
/* 246 */       replacementQuery.setPattern(pattern);
/* 247 */       replacementQuery.setDefaultValue(defaultValue);
/*     */ 
/* 249 */       packageTag.addReplacementQuery(replacementQuery);
/*     */     }
/*     */   }


/*     */   public void preloadReplacementQueries(MRIUPackage mriuPackage, MaximoResolver maximoResolver, IProgressMonitor monitor)
/*     */   {
/* 256 */     String METHOD = "preloadReplacementQueries";
/* 257 */     this.log.debugEntry("PackageImportParser", "preloadReplacementQueries");
/*     */ 
/* 259 */     monitor.setTask("Determining replacement query values:");
/*     */ 
/* 261 */     for (int i = 0; i < mriuPackage.getReplacementQueries().size(); ++i)
/*     */     {
/* 263 */       ReplacementQuery query = (ReplacementQuery)mriuPackage.getReplacementQueries().get(i);

/*     */       try
/*     */       {
/* 267 */         SelectionReplacementValue newReplacement = new SelectionReplacementValue(query.getId(), query.getColumn(), query.getDescription(), query.isEnforce(), query.getPattern(), query.getDefaultValue());
/*     */ 
/* 269 */         if (!(StringUtil.isEmpty(query.getQuery())))
/*     */         {
/* 271 */           this.log.debug("PackageImportParser", "preloadReplacementQueries", "Running query: " + query.getQuery());

/*     */           try
/*     */           {
/* 275 */             List results = executeQuery(query, maximoResolver);

/*     */ 
/* 278 */             int resultsLimit = mriuPackage.getQueryLimit();
/* 279 */             int resultsSize = results.size();
/* 280 */             if ((resultsLimit > -1) && (resultsSize > resultsLimit))

/*     */             {
/* 283 */               newReplacement.addValues(results.subList(0, mriuPackage.getQueryLimit()));
/*     */             }
/*     */             else {
/* 286 */               newReplacement.addValues(results);
/*     */             }
/* 288 */             int repsize = newReplacement.getValues().size();
/* 289 */             this.log.debug("PackageImportParser", "preloadReplacementQueries", "Results found: " + results.size());
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 293 */             this.log.error("PackageImportParser", "preloadReplacementQueries", "Failed to load possible values from database: " + query, e);
/*     */           }
/*     */         }
/*     */ 
/* 297 */         if (newReplacement != null)
/*     */         {
/* 299 */           mriuPackage.getReplacements().put(newReplacement.getId(), newReplacement);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 303 */         this.log.error("PackageImportParser", "preloadReplacementQueries", "Failed to add query: " + query, e);
/*     */       }
/*     */     }
/*     */ 
/* 307 */     this.log.debugExit("PackageImportParser", "preloadReplacementQueries");
/*     */   }

/*     */   private List<String> executeQuery(ReplacementQuery query, MaximoResolver maximoResolver) throws Exception {
/* 311 */     List results = new ArrayList();
/*     */ 
/* 313 */     Connection conn = null;
/* 314 */     PreparedStatement statement = null;
/* 315 */     ResultSet result = null;
/*     */     try {
/* 317 */       conn = DBUtils.getConnection(maximoResolver);
/* 318 */       conn.setAutoCommit(true);
/* 319 */       statement = conn.prepareStatement(query.getQuery());
/* 320 */       result = statement.executeQuery();
/* 321 */       while (result.next())
/* 322 */         results.add(result.getString(1));
/*     */     }
/*     */     finally {
/* 325 */       release(conn, statement, result);
/*     */     }
/*     */ 
/* 328 */     return results;
/*     */   }



/*     */   private void release(Connection conn, PreparedStatement statement, ResultSet result)
/*     */   {
/*     */     try
/*     */     {
/* 337 */       if (result != null)
/* 338 */         result.close();
/*     */     }
/*     */     catch (SQLException e) {
/* 341 */       System.err.println("Failed to close ResultSet");
/*     */     }
/*     */     try
/*     */     {
/* 345 */       if (statement != null)
/* 346 */         statement.close();
/*     */     }
/*     */     catch (SQLException e) {
/* 349 */       System.err.println("Failed to close PreparedStatement");
/*     */     }
/*     */ 
/* 352 */     DBUtils.releaseDatabaseConnection(conn);
/*     */   }
/*     */ }
