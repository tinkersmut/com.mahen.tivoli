/*    */ package com.ibm.ism.content.mriu;
/*    */ 
/*    */ import com.ibm.ism.contentinstaller.packages.IPackageResolver;
/*    */ import com.ibm.ism.contentinstaller.service.MaximoResolver;
/*    */ import com.ibm.ism.contentinstaller.tools.monitors.IProgressMonitor;
/*    */ import java.io.File;
/*    */ import java.io.InputStream;
/*    */ 















/*    */ public class DefaultPackageResolver
/*    */   implements IPackageResolver
/*    */ {
/* 27 */   private IProgressMonitor monitor = null;
/*    */ 
/*    */   public DefaultPackageResolver(IProgressMonitor monitor) {
/* 30 */     this.monitor = monitor;
/*    */   }

/*    */   public MaximoResolver getMaximoResolver() {
/* 34 */     return null;
/*    */   }

/*    */   public IProgressMonitor getProgressMonitor() {
/* 38 */     return this.monitor;
/*    */   }

/*    */   public File resolveObjectStructureDir(String objStructPath) {
/* 42 */     return null;
/*    */   }

/*    */   public File resolveOutputDir(String outputPath) {
/* 46 */     return null;
/*    */   }

/*    */   public InputStream resolveSchemaPath(String schemaPath) throws Exception {
/* 50 */     return super.getClass().getClassLoader().getResourceAsStream(schemaPath);
/*    */   }
/*    */ }
