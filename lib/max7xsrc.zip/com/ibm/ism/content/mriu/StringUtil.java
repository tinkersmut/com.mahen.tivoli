/*    */ package com.ibm.ism.content.mriu;
/*    */ 














/*    */ public class StringUtil
/*    */ {
/*    */   public static boolean isEmpty(String str)
/*    */   {
/* 21 */     if (str == null) return true;
/* 22 */     if (str.equals("")) return true;
/* 23 */     return (str.equals(" "));
/*    */   }




/*    */   public static String ltrim(String source)
/*    */   {
/* 31 */     return source.replaceAll("^\\s+", "");
/*    */   }



/*    */   public static String rtrim(String source)
/*    */   {
/* 38 */     return source.replaceAll("\\s+$", "");
/*    */   }



/*    */   public static String lrtrim(String source)
/*    */   {
/* 45 */     return ltrim(rtrim(source));
/*    */   }
/*    */ }
