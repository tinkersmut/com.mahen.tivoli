/*    */ package com.ibm.ism.content.mriu.model;
/*    */ 
















/*    */ public class ReplacementQuery
/*    */ {
/*    */   private String id;
/*    */   private String column;
/*    */   private String description;
/*    */   private boolean enforce;
/*    */   private String query;
/*    */   private String value;
/*    */   private String pattern;
/*    */   private String defaultValue;
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 32 */     return this.value; }

/*    */   public void setValue(String value) {
/* 35 */     this.value = value; }

/*    */   public String getId() {
/* 38 */     return this.id; }

/*    */   public void setId(String id) {
/* 41 */     this.id = id; }

/*    */   public String getColumn() {
/* 44 */     return this.column; }

/*    */   public void setColumn(String column) {
/* 47 */     this.column = column; }

/*    */   public boolean isEnforce() {
/* 50 */     return this.enforce; }

/*    */   public void setEnforce(boolean enforce) {
/* 53 */     this.enforce = enforce; }

/*    */   public String getQuery() {
/* 56 */     return this.query; }

/*    */   public void setQuery(String query) {
/* 59 */     this.query = query; }

/*    */   public String getDescription() {
/* 62 */     return this.description; }

/*    */   public void setDescription(String description) {
/* 65 */     this.description = description; }

/*    */   public String getPattern() {
/* 68 */     return this.pattern; }

/*    */   public void setPattern(String pattern) {
/* 71 */     this.pattern = pattern; }

/*    */   public String getDefaultValue() {
/* 74 */     return this.defaultValue; }

/*    */   public void setDefaultValue(String defaultValue) {
/* 77 */     this.defaultValue = defaultValue;
/*    */   }
/*    */ }
