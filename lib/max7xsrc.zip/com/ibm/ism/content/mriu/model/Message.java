/*    */ package com.ibm.ism.content.mriu.model;
/*    */ 
















/*    */ public class Message
/*    */ {
/*    */   public static final int TYPE_ERROR = 0;
/*    */   public static final int TYPE_WARNING = 1;
/*    */   public static final int TYPE_ALERT = 2;
/*    */   public static final int TYPE_REPLACEMENT_REQUIRED = 3;
/* 25 */   private int type = -1;
/* 26 */   private String msgId = null;
/* 27 */   private Object[] msgArgs = null;
/*    */ 
/*    */   public Message(int type, String msgId, Object[] msgArgs) {
/* 30 */     this.type = type;
/* 31 */     this.msgId = msgId;
/* 32 */     this.msgArgs = msgArgs;
/*    */   }

/*    */   public int getType() {
/* 36 */     return this.type;
/*    */   }

/*    */   public String getMsgId() {
/* 40 */     return this.msgId;
/*    */   }

/*    */   public Object[] getMsgArgs() {
/* 44 */     return this.msgArgs;
/*    */   }

/*    */   public static Message newError(String msgId, Object[] msgArgs) {
/* 48 */     return new Message(0, msgId, msgArgs);
/*    */   }

/*    */   public static Message newWarning(String msgId, Object[] msgArgs) {
/* 52 */     return new Message(1, msgId, msgArgs);
/*    */   }

/*    */   public static Message newAlert(String msgId, Object[] msgArgs) {
/* 56 */     return new Message(2, msgId, msgArgs);
/*    */   }

/*    */   public static Message newReplacementRequired(String msgId, Object[] msgArgs) {
/* 60 */     return new Message(3, msgId, msgArgs);
/*    */   }

/*    */   public boolean isError() {
/* 64 */     return (this.type == 0);
/*    */   }

/*    */   public boolean isWarning() {
/* 68 */     return (this.type == 1);
/*    */   }

/*    */   public boolean isAlert() {
/* 72 */     return (this.type == 2);
/*    */   }

/*    */   public boolean isReplacementRequired() {
/* 76 */     return (this.type == 3);
/*    */   }
/*    */ }
