/*     */ package com.ibm.ism.content.mriu.model;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URI;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ 









/*     */ public class FilePath
/*     */ {
/*     */   private String path;
/*     */   private URI pathURI;
/*     */   private String name;
/*     */   private boolean required;
/*     */   private String type;
/*     */   private boolean isZip;
/*     */   private boolean isJar;
/*     */   private boolean isSelected;
/*     */ 
/*     */   public FilePath()
/*     */   {
/*  38 */     this.isZip = false;
/*  39 */     this.isJar = false;
/*     */ 
/*  41 */     this.isSelected = false; }

/*     */   public URI getPathURI() {
/*  44 */     return this.pathURI; }

/*     */   public String getPath() {
/*  47 */     return this.path; }

/*     */   public void setPath(String path) {
/*  50 */     this.path = path; }

/*     */   public String getName() {
/*  53 */     return this.name; }

/*     */   public void setName(String name) {
/*  56 */     this.name = name;
/*     */   }

/*     */   public boolean isSelected() {
/*  60 */     return this.isSelected; }

/*     */   public void setSelected(boolean isSelected) {
/*  63 */     this.isSelected = isSelected;
/*     */   }

/*     */   public void setPathURI(URI uri)
/*     */   {
/*  68 */     System.out.println(uri.getPath());
/*  69 */     if (uri.getPath().endsWith(".zip"))
/*  70 */       this.isZip = true;
/*  71 */     else if (uri.getPath().endsWith(".jar")) {
/*  72 */       this.isJar = true;
/*     */     }
/*  74 */     this.pathURI = uri;
/*     */   }

/*     */   public String getFileContents()
/*     */     throws Exception
/*     */   {
/*  80 */     InputStream fileStream = getInputStream();
/*  81 */     return convertStreamToString(fileStream);
/*     */   }

/*     */   public InputStream getInputStream() throws Exception
/*     */   {
/*  86 */     InputStream is = null;
/*  87 */     if (this.isZip) {
/*  88 */       ZipFile zf = new ZipFile(new File(this.pathURI.getPath()));
/*  89 */       ZipEntry ze = zf.getEntry(this.pathURI.getFragment());
/*  90 */       is = zf.getInputStream(ze);
/*  91 */     } else if (this.isJar) {
/*  92 */       JarFile jf = new JarFile(new File(this.pathURI.getPath()));
/*  93 */       JarEntry je = jf.getJarEntry(this.pathURI.getFragment());
/*  94 */       is = jf.getInputStream(je);
/*     */     } else {
/*  96 */       is = new FileInputStream(new File(this.pathURI.getPath()));
/*     */     }
/*  98 */     return new BufferedInputStream(is);
/*     */   }

/*     */   public String convertStreamToString(InputStream is) throws Exception
/*     */   {
/* 103 */     if (is != null) {
/* 104 */       StringBuilder sb = new StringBuilder();

/*     */       try
/*     */       {
/* 108 */         BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/* 109 */         while ((line = reader.readLine()) != null)
/*     */         {/*     */           String line;/* 110 */           sb.append(line).append("\n");
/*     */         }
/*     */       } finally {
/* 113 */         is.close();
/*     */       }
/* 115 */       return sb.toString();
/*     */     }
/* 117 */     return "";
/*     */   }


/*     */   public boolean isRequired()
/*     */   {
/* 123 */     return this.required; }

/*     */   public void setRequired(boolean required) {
/* 126 */     this.required = required; }

/*     */   public String getType() {
/* 129 */     return this.type; }

/*     */   public void setType(String type) {
/* 132 */     this.type = type;
/*     */   }
/*     */ }
