/*     */ package com.ibm.ism.content.mriu.model;
/*     */ 
/*     */ import com.ibm.ism.content.mriu.SelectionReplacementValue;
/*     */ import com.ibm.ism.content.virtual.ContentCatalogLogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 






















/*     */ public class MRIUPackage
/*     */ {
/*     */   private static final String CLASSNAME = "MRIUPackage";
/*  31 */   private final ContentCatalogLogger log = new ContentCatalogLogger(MXLoggerFactory.getLogger("maximo.service.SYSTEM.IBMCONTENTCATALOG"));
/*     */   private boolean hasError;
/*  36 */   private List<Message> messages = null;
/*     */   private String name;
/*  39 */   private int queryLimit = -1;
/*     */   private List<FilePath> files;
/*     */   private List<ReplacementQuery> replacementQueries;
/*  42 */   private Map<String, SelectionReplacementValue> replacements = null;
/*  43 */   private Map<String, String> valuesIdMapReplacements = null;
/*     */   private List<FilePath> jythonScripts;
/*     */ 
/*     */   public MRIUPackage(String name)
/*     */   {
/*  50 */     this.name = name;
/*  51 */     this.files = new ArrayList();
/*  52 */     this.replacementQueries = new ArrayList();
/*  53 */     this.replacements = new TreeMap();
/*  54 */     this.valuesIdMapReplacements = new TreeMap();
/*  55 */     this.messages = new ArrayList();
/*     */   }

/*     */   public boolean getHasError() {
/*  59 */     return this.hasError;
/*     */   }

/*     */   public void setHasError(boolean hasError) {
/*  63 */     this.hasError = hasError;
/*     */   }

/*     */   public List<Message> getMessages() {
/*  67 */     return this.messages;
/*     */   }

/*     */   public void addMessage(Message mesg) {
/*  71 */     if (this.messages == null) {
/*  72 */       this.messages = new ArrayList();
/*     */     }
/*  74 */     this.messages.add(mesg);
/*     */   }

/*     */   public String getName() {
/*  78 */     return this.name;
/*     */   }

/*     */   public void setName(String name) {
/*  82 */     this.name = name;
/*     */   }

/*     */   public List<FilePath> getFiles() {
/*  86 */     return this.files;
/*     */   }

/*     */   public void addFile(FilePath file) {
/*  90 */     if (this.files == null) {
/*  91 */       this.files = new ArrayList();
/*     */     }
/*  93 */     this.files.add(file);
/*     */   }

/*     */   public List<FilePath> getJythonScripts()
/*     */   {
/*  98 */     return this.jythonScripts;
/*     */   }

/*     */   public void addJythonScript(FilePath jythonScript) {
/* 102 */     if (this.jythonScripts == null) {
/* 103 */       this.jythonScripts = new ArrayList();
/*     */     }
/* 105 */     this.jythonScripts.add(jythonScript);
/*     */   }

/*     */   public List<ReplacementQuery> getReplacementQueries()
/*     */   {
/* 110 */     return this.replacementQueries;
/*     */   }

/*     */   public void addReplacementQuery(ReplacementQuery replacementQuery) {
/* 114 */     if (this.replacementQueries == null) {
/* 115 */       this.replacementQueries = new ArrayList();
/*     */     }
/* 117 */     this.replacementQueries.add(replacementQuery);
/*     */   }

/*     */   public Map<String, SelectionReplacementValue> getReplacements() {
/* 121 */     return this.replacements;
/*     */   }

/*     */   public SelectionReplacementValue getReplacementValueById(String id) {
/* 125 */     return ((SelectionReplacementValue)getReplacements().get(id));
/*     */   }








/*     */   public Map<String, String> getValuesIdMapReplacements()
/*     */   {
/* 137 */     if (this.valuesIdMapReplacements == null) {
/* 138 */       this.valuesIdMapReplacements = new TreeMap();
/*     */     }
/* 140 */     return this.valuesIdMapReplacements;
/*     */   }







/*     */   public Map<String, String[]> getCalculatedReplacementsForImport()
/*     */   {
/* 151 */     Map map = new HashMap();
/*     */ 
/* 153 */     for (String key : getValuesIdMapReplacements().keySet())
/*     */     {
/* 155 */       String columnName = getReplacementValueById(key).getColumnName();
/* 156 */       String[] multipleNames = columnName.split(",");
/* 157 */       for (int i = 0; i < multipleNames.length; ++i)
/*     */       {
/* 159 */         columnName = multipleNames[i].trim();
/* 160 */         String repValue = (String)getValuesIdMapReplacements().get(key);
/* 161 */         String pattern = getReplacementValueById(key).getPattern();
/*     */ 
/* 163 */         map.put(columnName, new String[] { repValue, pattern });
/*     */       }
/*     */     }
/* 166 */     return map;
/*     */   }

/*     */   public int getQueryLimit() {
/* 170 */     return this.queryLimit;
/*     */   }

/*     */   public void setQueryLimit(String queryLimit)
/*     */   {
/*     */     try {
/* 176 */       this.queryLimit = Integer.parseInt(queryLimit);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 180 */       this.queryLimit = -1;
/*     */     }
/*     */   }
/*     */ }
