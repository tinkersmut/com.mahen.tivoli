/*    */ package com.ibm.ism.content.mriu;
/*    */ 
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 


















/*    */ public abstract class AbstractPackageParser
/*    */   implements PackageConstants
/*    */ {
/*    */   protected boolean isEmpty(NodeList list)
/*    */   {
/* 30 */     return ((list == null) || (list.getLength() == 0));
/*    */   }

/*    */   protected String getTextValue(Element ele, String tagName) {
/* 34 */     String textValue = null;
/* 35 */     NodeList nl = ele.getElementsByTagName(tagName);
/* 36 */     if ((nl != null) && (nl.getLength() > 0)) {
/* 37 */       Element el = (Element)nl.item(0);
/* 38 */       textValue = el.getFirstChild().getNodeValue();
/*    */     }
/* 40 */     return textValue;
/*    */   }
/*    */ }
