/*    */ package com.ibm.ism.content.mriu;
/*    */ 


















/*    */ public class SelectionReplacementValue extends AbstractReplacementValue
/*    */ {
/*    */   public SelectionReplacementValue(String id, String columnName, String description, boolean pkgDefault, String pattern, String defaultvalue)
/*    */   {
/* 25 */     super(id, columnName, description, pkgDefault, pattern, defaultvalue);
/*    */   }

/*    */   public int getType() {
/* 29 */     return 1;
/*    */   }
/*    */ }
