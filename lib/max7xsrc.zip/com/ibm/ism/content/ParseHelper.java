/*     */ package com.ibm.ism.content;
/*     */ 
























/*     */ public class ParseHelper
/*     */ {
/*     */   public static final int ISM_LIB = 1;
/*     */   public static final int CC = 2;
/*     */   public static final String ISM_RESPONSE_TAG = "response";
/*     */   public static final String CC_CATALOG_TAG = "catalog";
/*     */   private static final String CC_CATALOG_ITEM_TAG = "catalogItem";
/*     */   private static final String CC_NAME_TAG = "name";
/*     */   private static final String CC_VERSION_TAG = "version";
/*     */   private static final String CC_DESCRIPTION_TAG = "description";
/*     */   private static final String CC_TYPE_TAG = "type";
/*     */   private static final String CC_CATEGORY_TAG = "category";
/*     */   private static final String CC_PRODUCT_PREREQ_TAG = "productprereq";
/*     */   private static final String CC_URL_TAG = "url";
/*     */   private static final String CC_LICENSE_URL_TAG = "licenseurl";
/*     */   private static final String CC_HOMEPAGE_TAG = "homepage";
/*     */   private static final String CC_INFOURL_ATTIBUTE = "infourl";
/*     */   private static final String ISM_CONTENT_TAG = "content";
/*     */   private static final String ISM_NAME_TAG = "name";
/*     */   private static final String ISM_VERSION_TAG = "version";
/*     */   private static final String ISM_VERSION_NAME_TAG = "name";
/*     */   private static final String ISM_SHORT_DESC_TAG = "shortDesc";
/*     */   private static final String ISM_DOWNLOAD_URL_TAG = "ftpUrl";
/*     */   private static final String ISM_LICENSE_URL_TAG = "licenseurl";
/*     */   private static final String ISM_HOMEPAGE_URL_TAG = "homepage";
/*     */   private static final String ISM_META_TAG = "metaData";
/*     */   private static final String ISM_CONTENT_INSTALLER_TAG = "contentInstaller";
/*     */   private static final String ISM_TYPE_TAG = "type";
/*     */   private static final String ISM_NAVCODE_TAG = "navCode";
/*     */   private static final String ISM_PRODUCT_PREREQ_TAG = "productprereq";
/*     */ 
/*     */   public static String getContentItemTag(int itemSource)
/*     */   {
/*  60 */     switch (itemSource)
/*     */     {/*     */     case 1:
/*  62 */       return "content";
/*     */     }
/*     */ 
/*  65 */     return "catalogItem";
/*     */   }


/*     */   public static String getContentNameTag(int itemSource)
/*     */   {
/*  71 */     switch (itemSource)
/*     */     {/*     */     case 1:
/*  73 */       return "name";
/*     */     }
/*     */ 
/*  76 */     return "name";
/*     */   }


/*     */   public static String getContentDescriptionTag(int itemSource)
/*     */   {
/*  82 */     switch (itemSource)
/*     */     {/*     */     case 1:
/*  84 */       return "shortDesc";
/*     */     }
/*     */ 
/*  87 */     return "description";
/*     */   }


/*     */   public static String getContentURLTag(int itemSource)
/*     */   {
/*  93 */     switch (itemSource)
/*     */     {/*     */     case 1:
/*  95 */       return "ftpUrl";
/*     */     }
/*     */ 
/*  98 */     return "url";
/*     */   }


/*     */   public static String getContentLicenseURLTag(int itemSource)
/*     */   {
/* 104 */     switch (itemSource)
/*     */     {/*     */     case 1:
/* 106 */       return "licenseurl";
/*     */     }
/*     */ 
/* 109 */     return "licenseurl";
/*     */   }


/*     */   public static String getContentHomepageTag(int itemSource)
/*     */   {
/* 115 */     switch (itemSource)
/*     */     {/*     */     case 1:
/* 117 */       return "homepage";
/*     */     }
/*     */ 
/* 120 */     return "homepage";
/*     */   }



/*     */   public static String getCatalogVersionTag()
/*     */   {
/* 127 */     return "version";
/*     */   }

/*     */   public static String getCatalogTypeTag()
/*     */   {
/* 132 */     return "type";
/*     */   }

/*     */   public static String getCatalogCategoryTag()
/*     */   {
/* 137 */     return "category";
/*     */   }

/*     */   public static String getCatalogPreReqTag()
/*     */   {
/* 142 */     return "productprereq";
/*     */   }

/*     */   public static String getCatalogInfoURLAttribute()
/*     */   {
/* 147 */     return "infourl";
/*     */   }


/*     */   public static String getISMVersionTag()
/*     */   {
/* 153 */     return "version";
/*     */   }

/*     */   public static String getISMVersionNameTag() {
/* 157 */     return "name";
/*     */   }

/*     */   public static String getISMMetaTag()
/*     */   {
/* 162 */     return "metaData";
/*     */   }

/*     */   public static String getISMTypeTag() {
/* 166 */     return "type";
/*     */   }

/*     */   public static String getISMProductPrereqTag() {
/* 170 */     return "productprereq";
/*     */   }

/*     */   public static String getISMContentInstallerTag() {
/* 174 */     return "contentInstaller";
/*     */   }

/*     */   public static String getISMNavCodeTag() {
/* 178 */     return "navCode";
/*     */   }
/*     */ }
