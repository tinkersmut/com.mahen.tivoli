/*    */ package com.ibm.ism.script.action;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.StringWriter;
/*    */ import java.rmi.RemoteException;
/*    */ import org.python.util.PythonInterpreter;
/*    */ import psdi.common.action.ActionCustomClass;
/*    */ import psdi.common.action.ActionRemote;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.logging.MXLogger;
/*    */ import psdi.util.logging.MXLoggerFactory;
/*    */ import psdi.workflow.WFActionRemote;
/*    */ import psdi.workflow.WFInstance;
/*    */ 












/*    */ public class AutoScriptDelegateAction
/*    */   implements ActionCustomClass
/*    */ {
/*    */   public final String SCRIPTPREFIX = "AUTOSCRIPT_";
/*    */ 
/*    */   public AutoScriptDelegateAction()
/*    */   {
/* 37 */     this.SCRIPTPREFIX = "AUTOSCRIPT_";
/*    */   }

/*    */   public void applyCustomAction(MboRemote arg0, Object[] arg1) throws MXException, RemoteException
/*    */   {
/* 42 */     String scriptName = null;
/* 43 */     MboSetRemote scriptSet = null;
/* 44 */     WFInstance wf = null;

/*    */ 
/* 47 */     MXLogger myLogger = MXLoggerFactory.getLogger("maximo.application.AUTOSCRIPT");
/*    */ 
/* 49 */     String param = (String)arg1[0];


/*    */ 
/* 53 */     if (arg1.length > 2) {
/* 54 */       wf = (WFInstance)arg1[1];
/* 55 */       WFActionRemote wfAction = (WFActionRemote)arg1[2];
/*    */ 
/* 57 */       MboSetRemote actionSet = wfAction.getMboSet("ACTION");
/* 58 */       ActionRemote actionRemote = (ActionRemote)actionSet.getMbo(0);
/* 59 */       String type = actionRemote.getString("type");
/* 60 */       if (type.equalsIgnoreCase("CUSTOMSCRIPT")) {
/* 61 */         scriptName = actionRemote.getString("dispvalue");
/*    */       }
/*    */       else {
/* 64 */         scriptName = actionRemote.getString("ACTION").substring("AUTOSCRIPT_".length());
/*    */       }
/*    */ 
/* 67 */       scriptSet = wf.getControlledMbo().getMboSet("$WFAUTOSCRIPT", "AUTOSCRIPT", "AUTOSCRIPT='" + scriptName + "'");
/*    */ 
/* 69 */       if (scriptSet.isEmpty()) {
/* 70 */         myLogger.error("Script " + scriptName + " doesn't exist");
/* 71 */         return;
/*    */       }
/*    */     }
/* 74 */     else if ((((arg0.isBasedOn("WORKORDER")) || (arg0.isBasedOn("JOBPLAN")))) && (arg0.getString("flowaction").length() > "AUTOSCRIPT_".length()) && (param.length() == 0))
/*    */     {
/* 76 */       if (arg0.getString("flowaction").substring(0, "AUTOSCRIPT_".length()).equals("AUTOSCRIPT_")) {
/* 77 */         String actionName = arg0.getString("FLOWACTION");
/* 78 */         scriptName = actionName.substring("AUTOSCRIPT_".length());
/* 79 */         scriptSet = arg0.getMboSet("$AUTOSCRIPT", "AUTOSCRIPT", "AUTOSCRIPT='" + scriptName + "'");
/*    */ 
/* 81 */         if (scriptSet.isEmpty()) {
/* 82 */           myLogger.error("Script " + scriptName + " doesn't exist");
/* 83 */           return;
/*    */         }
/*    */       }
/*    */     }
/* 87 */     else if (arg1.length == 1) {
/* 88 */       scriptName = param;
/* 89 */       scriptSet = arg0.getMboSet("$AUTOSCRIPT", "AUTOSCRIPT", "AUTOSCRIPT='" + scriptName + "'");
/*    */ 
/* 91 */       if (scriptSet.isEmpty()) {
/* 92 */         myLogger.error("Script " + scriptName + " doesn't exist");
/* 93 */         return;
/*    */       }
/*    */     }
/* 96 */     if (scriptSet != null) {
/* 97 */       MboRemote scriptMbo = scriptSet.getMbo(0);
/* 98 */       String script = scriptMbo.getString("SOURCE");

/*    */ 
/* 101 */       PythonInterpreter jython = new PythonInterpreter();
/* 102 */       StringWriter stdout = new StringWriter();
/* 103 */       StringWriter stderr = new StringWriter();
/*    */ 
/* 105 */       jython.set("scriptHome", arg0);
/* 106 */       if (wf != null) {
/* 107 */         jython.set("wfinstance", wf);
/*    */       }
/* 109 */       jython.setOut(stdout);
/* 110 */       jython.setErr(stderr);
/* 111 */       InputStream scriptStream = new ByteArrayInputStream(script.getBytes());
/*    */       try
/*    */       {
/* 114 */         jython.execfile(scriptStream);
/* 115 */         myLogger.info("Script " + scriptName + " has Completed");
/*    */       }
/*    */       catch (Exception e) {
/* 118 */         stderr.write(e.toString());
/* 119 */         myLogger.error(e.toString());
/*    */       }
/* 121 */       myLogger.info(stdout.toString());
/* 122 */       if ((stderr.toString() != null) && (stderr.toString().length() > 0))
/* 123 */         myLogger.error(stderr.toString());
/*    */     }
/*    */   }
/*    */ }
