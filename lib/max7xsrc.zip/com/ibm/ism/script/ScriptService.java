/*    */ package com.ibm.ism.script;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.server.AppService;
/*    */ import psdi.server.MXServer;
/*    */ 



























/*    */ public class ScriptService extends AppService
/*    */   implements ScriptServiceRemote
/*    */ {
/*    */   public ScriptService()
/*    */     throws RemoteException
/*    */   {
/*    */   }
/*    */ 
/*    */   public ScriptService(MXServer mxServer)
/*    */     throws RemoteException
/*    */   {
/* 45 */     super(mxServer);
/*    */   }
/*    */ }
