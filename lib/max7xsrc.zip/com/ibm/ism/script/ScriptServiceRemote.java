package com.ibm.ism.script;

import psdi.server.AppServiceRemote;

public abstract interface ScriptServiceRemote extends AppServiceRemote
{
}
