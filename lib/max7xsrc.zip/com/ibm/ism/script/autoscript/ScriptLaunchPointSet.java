/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.script.ScriptCache;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXException;
/*    */ 


























/*    */ public class ScriptLaunchPointSet extends MboSet
/*    */   implements MboSetRemote
/*    */ {
/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 44 */     return new ScriptLaunchPoint(ms);
/*    */   }




/*    */   public ScriptLaunchPointSet(MboServerInterface ms)
/*    */     throws RemoteException
/*    */   {
/* 53 */     super(ms);
/*    */   }

/*    */   public void commit() throws MXException, RemoteException
/*    */   {
/* 58 */     super.commit();
/* 59 */     MXServer.getMXServer().reloadMaximoCache(ScriptCache.getInstance().getName(), true);
/*    */   }
/*    */ }
