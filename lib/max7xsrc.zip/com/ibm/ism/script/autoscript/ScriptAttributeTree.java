/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import psdi.mbo.HierarchicalMboRemote;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.NonPersistentMbo;
/*    */ import psdi.mbo.NonPersistentMboRemote;
/*    */ import psdi.util.MXException;
/*    */ 



















/*    */ public class ScriptAttributeTree extends NonPersistentMbo
/*    */   implements NonPersistentMboRemote, HierarchicalMboRemote
/*    */ {
/* 32 */   List<String> alnValue = new ArrayList();
/*    */ 
/*    */   public ScriptAttributeTree(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 39 */     super(ms);
/*    */   }


/*    */   public boolean hasChildren()
/*    */     throws MXException, RemoteException
/*    */   {
/* 46 */     return getBoolean("haschildren");
/*    */   }



/*    */   public boolean hasParents()
/*    */     throws MXException, RemoteException
/*    */   {
/* 54 */     return getBoolean("hasparent");
/*    */   }



/*    */   public boolean isTop()
/*    */     throws MXException, RemoteException
/*    */   {
/* 62 */     return (!(getBoolean("hasparent")));
/*    */   }

/*    */   public void setAlnList(List<String> in) throws MXException, RemoteException {
/* 66 */     this.alnValue = in;
/*    */   }

/*    */   public List<String> getAlnList() throws MXException, RemoteException {
/* 70 */     return this.alnValue;
/*    */   }
/*    */ }
