/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MAXTableDomain;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 































/*    */ public class FldObjectName extends MAXTableDomain
/*    */ {
/*    */   public FldObjectName(MboValue mbv)
/*    */   {
/* 44 */     super(mbv);
/* 45 */     setRelationship("MAXOBJECT", "objectname=:objectname and internal=0");
/* 46 */     setErrorMessage("common", "InvalidObjectName");
/*    */   }

/*    */   public MboSetRemote getList()
/*    */     throws MXException, RemoteException
/*    */   {
/* 52 */     MboSetRemote msr = super.getList();
/* 53 */     msr.setOrderBy("objectname asc");
/* 54 */     return msr;
/*    */   }
/*    */ }
