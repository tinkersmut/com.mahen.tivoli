/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.ALNDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 






































/*    */ public class FldVarBindingType extends ALNDomain
/*    */ {
/*    */   public FldVarBindingType(MboValue mbv)
/*    */   {
/* 51 */     super(mbv);
/*    */   }







/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 63 */     Mbo thisMbo = getMboValue().getMbo();
/* 64 */     thisMbo.setValueNull("literaldatatype", 11L);
/*    */ 
/* 66 */     thisMbo.setValueNull("varbindingvalue", 11L);
/*    */ 
/* 68 */     thisMbo.setValueNull("lpvarbindval", 11L);
/*    */ 
/* 70 */     thisMbo.setValueNull("attributevaluenp", 11L);
/*    */ 
/* 72 */     String maxvalue = getMboValue().getString();
/* 73 */     boolean isLiteral = maxvalue.equalsIgnoreCase("LITERAL");
/* 74 */     if (isLiteral)
/*    */     {
/* 76 */       thisMbo.setFieldFlag("literaldatatype", 7L, false);
/* 77 */       thisMbo.setValue("literaldatatype", "ALN", 11L);
/*    */ 
/* 79 */       thisMbo.setFieldFlag("literaldatatype", 128L, true);
/*    */     }
/*    */     else
/*    */     {
/* 83 */       thisMbo.setFieldFlag("literaldatatype", 7L, true);
/* 84 */       thisMbo.setFieldFlag("literaldatatype", 128L, false);
/* 85 */       thisMbo.setValueNull("literaldatatype", 11L);

/*    */     }
/*    */ 
/* 89 */     boolean isAttr = maxvalue.equalsIgnoreCase("ATTRIBUTE");
/* 90 */     if (isAttr)
/*    */     {
/* 92 */       thisMbo.setFieldFlag("varbindingvalue", 7L, true);
/* 93 */       thisMbo.setFieldFlag("varbindingvalue", 128L, false);

/*    */     }
/*    */     else
/*    */     {
/* 98 */       thisMbo.setFieldFlag("varbindingvalue", 7L, false);
/* 99 */       thisMbo.setFieldFlag("varbindingvalue", 128L, true);
/*    */     }
/*    */   }
/*    */ }
