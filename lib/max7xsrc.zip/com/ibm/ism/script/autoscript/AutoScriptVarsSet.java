/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ 




















/*    */ public class AutoScriptVarsSet extends MboSet
/*    */   implements MboSetRemote
/*    */ {
/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 36 */     return new AutoScriptVars(ms);
/*    */   }

/*    */   public AutoScriptVarsSet(MboServerInterface ms) throws RemoteException
/*    */   {
/* 41 */     super(ms);
/*    */   }
/*    */ }
