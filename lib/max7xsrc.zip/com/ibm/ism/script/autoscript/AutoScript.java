/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.script.JSR223ScriptDriver;
/*     */ import java.io.StringReader;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.script.Compilable;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.ScriptException;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.mbo.StatefulMbo;
/*     */ import psdi.mbo.StatusHandler;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.AppService;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 



































/*     */ public class AutoScript extends StatefulMbo
/*     */   implements AutoScriptRemote
/*     */ {
/*  58 */   private static final Class CLASS = AutoScript.class;
/*     */ 
/*  66 */   protected static Set<String> skipFieldCopy = new HashSet();
/*     */ 
/*  73 */   protected static boolean isHashSetLoaded = false;
/*     */ 
/*     */   public AutoScript(MboSet ms) throws RemoteException
/*     */   {
/*  77 */     super(ms);
/*     */   }



/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  85 */     super.init();

/*     */     try
/*     */     {
/*  89 */       String[] alwaysReadOnly = { "changedate", "changeby", "statusdate", "status", "createddate", "userdefined", "createdby", "createdbyemail", "createdbyid", "createdbyname", "createdbyphone", "orgid", "owner", "owneremail", "ownerid", "ownername", "ownerphone" };

/*     */ 
/*  92 */       setFieldFlag(alwaysReadOnly, 7L, true);
/*  93 */       if (!(toBeAdded()))
/*     */       {
/*  95 */         String[] readOnlyAfterSave = { "autoscript" };
/*  96 */         setFieldFlag(readOnlyAfterSave, 7L, true);
/*  97 */         if (!(getBoolean("userdefined")))
/*     */         {
/*  99 */           String[] allReadOnlyExceptXmlData = { "action", "autoscript", "binaryscriptsource", "category", "createdby", "createdbyemail", "createdbyid", "createdbyname", "createdbyphone", "createddate", "orgid", "owner", "owneremail", "ownerid", "ownername", "ownerphone", "scheduledstatus", "scriptlanguage", "siteid", "source", "stderr", "stdout", "userdefined", "version" };


/*     */ 
/* 103 */           setFieldFlag(allReadOnlyExceptXmlData, 7L, true);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 109 */       getMboLogger().error(e.getMessage(), e);
/* 110 */       throw new MXApplicationException("script", "cannot_initialise");
/*     */     }
/* 112 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 114 */     getMboLogger().debug("Leaving AutoScript init");
/*     */   }

















/*     */   public void add()
/*     */     throws MXException, RemoteException
/*     */   {
/* 136 */     MXLogger myLogger = MXLoggerFactory.getLogger("maximo.application.AUTOSCRIPT");
/* 137 */     myLogger.debug("Entered AutoScript.add()");
/*     */ 
/* 139 */     setFieldFlag("status", 7L, false);
/* 140 */     Date currentDT = MXServer.getMXServer().getDate();
/* 141 */     setValue("statusdate", currentDT, 11L);
/*     */ 
/* 143 */     setValue("changeby", getUserInfo().getUserName(), 11L);
/*     */ 
/* 145 */     setValue("changedate", ((AppService)getMboServer()).getMXServer().getDate(), 11L);
/*     */ 
/* 147 */     setValue("createdby", getUserInfo().getPersonId(), 2L);
/*     */ 
/* 149 */     setValue("status", getTranslator().toExternalDefaultValue("AUTOSCRPHASE", "Draft", this), 11L);


/*     */ 
/* 153 */     setValue("statusdate", currentDT, 11L);

/*     */ 
/* 156 */     setValue("createddate", currentDT, 11L);

/*     */ 
/* 159 */     Set supportedEngines = JSR223ScriptDriver.getSupportedScriptEngineNames();
/* 160 */     String scrLang = "";
/* 161 */     if (!(supportedEngines.isEmpty()))
/*     */     {
/* 163 */       scrLang = (String)supportedEngines.iterator().next();
/*     */     }
/* 165 */     setValue("scriptlanguage", scrLang, 11L);
/* 166 */     setValue("userdefined", true, 11L);
/*     */   }

/*     */   public void componentAdded() throws MXException, RemoteException
/*     */   {
/* 171 */     if (!(toBeAdded()))
/* 172 */       return;
/*     */   }

/*     */   protected StatusHandler getStatusHandler()
/*     */   {
/* 177 */     return new AutoScriptStateHandler(this);
/*     */   }

/*     */   protected MboSetRemote getStatusHistory() throws MXException, RemoteException
/*     */   {
/* 182 */     return getMboSet("AUTOSCRIPTSTATE");
/*     */   }

/*     */   public String getStatusListName() {
/* 186 */     return "AUTOSCRPHASE";
/*     */   }

/*     */   protected void save() throws MXException, RemoteException
/*     */   {
/* 191 */     super.save();
/*     */   }

/*     */   public boolean preCompileScript() throws RemoteException, MXException
/*     */   {
/* 196 */     String scriptLanguage = getString("scriptlanguage");
/* 197 */     ScriptEngineManager mgr = new ScriptEngineManager();
/* 198 */     ScriptEngine scriptEngine = mgr.getEngineByName(scriptLanguage);
/* 199 */     if ((scriptEngine instanceof Compilable) && (!(isNull("source"))))
/*     */     {
/* 201 */       String scriptSource = getString("source");
/*     */ 
/* 203 */       StringReader sr = new StringReader(scriptSource);
/*     */       try
/*     */       {
/* 206 */         ((Compilable)scriptEngine).compile(sr);
/* 207 */         return true;

/*     */       }
/*     */       catch (ScriptException se)
/*     */       {
/* 212 */         String[] params = { getString("autoscript") };
/* 213 */         throw new MXApplicationException("script", "compileerr", params, se);
/*     */       }
/*     */     }
/*     */ 
/* 217 */     return false;
/*     */   }

/*     */   public void appValidate() throws MXException, RemoteException
/*     */   {
/* 222 */     preCompileScript();
/*     */   }











/*     */   public void canDelete()
/*     */     throws MXException, RemoteException
/*     */   {
/* 238 */     if (toBeAdded()) {
/* 239 */       return;


/*     */     }
/*     */ 
/* 244 */     if (!(getTranslator().toInternalString("AUTOSCRPHASE", getString("STATUS")).equals("Archive"))) {
/*     */       return;
/*     */     }
/* 247 */     throw new MXApplicationException("autoscr", "inArchiveState");
/*     */   }





/*     */   public void delete(long accessModifier)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 259 */       super.delete(accessModifier);
/*     */ 
/* 261 */       deleteAssociatedRecords();
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 265 */       MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
/* 266 */       super.undelete();
/* 267 */       throw e;
/*     */     }
/*     */   }



/*     */   private void deleteAssociatedRecords()
/*     */     throws MXException, RemoteException
/*     */   {
/* 276 */     MXLogger myLogger = MXLoggerFactory.getLogger("maximo.application.AUTOSCRIPT");
/* 277 */     myLogger.debug("Entered deleteAssociatedRecords()");

/*     */ 
/* 280 */     getMboSet("AUTOSCRIPTSTATE").deleteAll(2L);

/*     */ 
/* 283 */     getMboSet("AUTOSCRIPTVARS").deleteAll(2L);
/*     */ 
/* 285 */     getMboSet("SCRIPTLAUNCHPOINT").deleteAll(2L);

/*     */ 
/* 288 */     getMboSet("BOOKMARK").deleteAll(2L);

/*     */ 
/* 291 */     getMboSet("ACTION").deleteAll(2L);
/*     */   }







/*     */   public void modify()
/*     */     throws MXException, RemoteException
/*     */   {
/* 303 */     if (!(getMboValue("changedate").isModified())) {
/* 304 */       setValue("changedate", ((AppService)getMboServer()).getMXServer().getDate(), 2L);

/*     */     }
/*     */ 
/* 308 */     if (!(getMboValue("changeby").isModified()))
/* 309 */       setValue("changeby", getUserInfo().getUserName(), 2L);
/*     */   }



/*     */   public MboRemote duplicate()
/*     */     throws MXException, RemoteException
/*     */   {
/* 317 */     if (!(isHashSetLoaded)) {
/* 318 */       loadSkipFieldCopyHashSet();
/*     */     }
/*     */ 
/* 321 */     MboRemote duplicateScript = copy();
/* 322 */     return duplicateScript;
/*     */   }






























/*     */   protected void loadSkipFieldCopyHashSet()
/*     */     throws MXException, RemoteException
/*     */   {
/* 357 */     isHashSetLoaded = true;
/* 358 */     skipFieldCopy.add("AUTOSCRIPT");
/* 359 */     skipFieldCopy.add("STATUS");
/* 360 */     skipFieldCopy.add("STATUSDATE");
/* 361 */     skipFieldCopy.add("SCHEDULEDSTATUS");
/* 362 */     skipFieldCopy.add("CHANGEDATE");
/* 363 */     skipFieldCopy.add("CHANGEBY");
/* 364 */     skipFieldCopy.add("CREATEDBYID");
/* 365 */     skipFieldCopy.add("CREATEDBYNAME");
/* 366 */     skipFieldCopy.add("CREATEDBYPHONE");
/* 367 */     skipFieldCopy.add("CREATEDBYEMAIL");
/* 368 */     skipFieldCopy.add("CREATEDBY");
/* 369 */     skipFieldCopy.add("CREATEDDATE");
/* 370 */     skipFieldCopy.add("ACTION");
/* 371 */     skipFieldCopy.add("USERDEFINED");
/*     */   }









/*     */   protected boolean skipCopyField(MboValueInfo mvi)
/*     */     throws RemoteException, MXException
/*     */   {
/* 385 */     return (skipFieldCopy.contains(mvi.getName()));
/*     */   }
/*     */ }
