/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.util.MXException;
/*     */ 























/*     */ public class FldScriptOwnerName extends MAXTableDomain
/*     */ {
/*     */   public FldScriptOwnerName(MboValue mbv)
/*     */     throws MXException, RemoteException
/*     */   {
/*  39 */     super(mbv);
/*  40 */     String thisAttr = getMboValue().getAttributeName();
/*  41 */     setRelationship("PERSON", "displayname=:" + thisAttr + " and status in (select value from synonymdomain where maxvalue='ACTIVE' and domainid='PERSONSTATUS')");



/*     */ 
/*  46 */     setErrorMessage("person", "InvalidPerson");
/*  47 */     String[] target = { "ownername", "ownerid" };
/*  48 */     String[] source = { "displayname", "personid" };
/*  49 */     setLookupKeyMapInOrder(target, source);
/*     */   }

/*     */   public void initValue() throws MXException, RemoteException {
/*  53 */     MboValue name = getMboValue();
/*     */ 
/*  55 */     if ((!(name.getMbo().toBeAdded())) || 

/*  57 */       (!(name.isNull()))) return;
/*  58 */     name.setValue(name.getMbo().getString("owner.displayname"), 11L);
/*     */ 
/*  60 */     if (name.isNull())
/*  61 */       name.setValue(name.getMbo().getString("owner"), 11L);
/*     */   }














/*     */   public void action()
/*     */     throws MXException, RemoteException
/*     */   {
/*  80 */     MboRemote scriptMbo = getMboValue().getMbo();
/*  81 */     MboSetRemote personSet = getMboSet();
/*  82 */     MboRemote personMbo = null;

/*     */ 
/*  85 */     if ((getMboValue().isNull()) || (personSet.isEmpty())) {
/*  86 */       scriptMbo.setValueNull("OwnerId", 11L);
/*     */ 
/*  88 */       scriptMbo.setValue("Owner", scriptMbo.getString("OwnerName"), 11L);

/*     */ 
/*  91 */       scriptMbo.setValueNull("ownerPhone", 11L);
/*     */ 
/*  93 */       scriptMbo.setValueNull("ownerEmail", 11L);

/*     */ 
/*  96 */       return;
/*     */     }
/*     */ 
/*  99 */     personMbo = personSet.getMbo(0);
/* 100 */     scriptMbo.setValue("ownerId", personMbo.getString("personid"), 11L);
/*     */ 
/* 102 */     scriptMbo.setValue("Owner", personMbo.getString("personid"), 2L);
/*     */   }
/*     */ }
