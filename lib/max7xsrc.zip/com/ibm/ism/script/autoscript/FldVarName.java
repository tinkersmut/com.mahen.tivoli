/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.script.ScriptDriver;
/*    */ import com.ibm.tivoli.maximo.script.ScriptDriverFactory;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 















































/*    */ public class FldVarName extends MboValueAdapter
/*    */ {
/*    */   public FldVarName(MboValue mbv)
/*    */   {
/* 63 */     super(mbv);
/*    */   }

/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 69 */     MboRemote thisMbo = getMboValue().getMbo();
/* 70 */     MboRemote autoScriptMbo = thisMbo.getOwner();
/* 71 */     if ((autoScriptMbo == null) || (!(autoScriptMbo.getName().equalsIgnoreCase("AUTOSCRIPT"))))
/*    */       return;
/* 73 */     String scriptLang = autoScriptMbo.getString("scriptlanguage");
/* 74 */     ScriptDriver scriptDriver = ScriptDriverFactory.getInstance().getScriptDriverForLanguage(scriptLang);
/* 75 */     if (!(scriptDriver.isVarNameMatchesKeyWord(getMboValue().getString())))
/*    */       return;
/* 77 */     String[] params = { getMboValue().getString() };
/* 78 */     throw new MXApplicationException("script", "implicitvarname", params);
/*    */   }
/*    */ }
