package com.ibm.ism.script.autoscript;

import psdi.mbo.MboSetRemote;

public abstract interface AutoScriptStateSetRemote extends MboSetRemote
{
}
