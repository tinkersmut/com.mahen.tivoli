/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MAXTableDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 





















/*    */ public class FldAutoScript extends MAXTableDomain
/*    */ {
/*    */   public FldAutoScript(MboValue mbv)
/*    */     throws MXException
/*    */   {
/* 39 */     super(mbv);
/* 40 */     setRelationship("AUTOSCRIPT", "autoscript=:autoscriptnp");
/* 41 */     setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "autoscript" });
/*    */   }







/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 53 */     if (getMboValue().isNull())
/*    */     {
/* 55 */       super.validate();
/* 56 */       return;
/*    */     }
/* 58 */     MboRemote mbo = getMboValue().getMbo();
/* 59 */     MboSetRemote scriptSet = mbo.getMboSet("AUTOSCRIPTNP");
/* 60 */     scriptSet.setQbeExactMatch(true);
/* 61 */     scriptSet.setQbe("autoscript", getMboValue().getString());
/* 62 */     scriptSet.reset();
/* 63 */     if (scriptSet.isEmpty())
/*    */     {
/* 65 */       String[] params = { getMboValue().getString() };
/* 66 */       throw new MXApplicationException("script", "invalidscript", params);
/*    */     }
/* 68 */     super.validate();
/* 69 */     mbo.setValue("autoscript", getMboValue().getString(), 11L);
/*    */   }







/*    */   public MboSetRemote getList()
/*    */     throws MXException, RemoteException
/*    */   {
/* 81 */     MboServerInterface service = getMboValue().getMbo().getMboServer();
/* 82 */     MboSetRemote relationSet = service.getMboSet("AUTOSCRIPT", getMboValue().getMbo().getUserInfo());
/* 83 */     return relationSet;
/*    */   }
/*    */ }
