/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.iface.mos.ConversionUtil;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 
























/*     */ public class FldLaunchPntVarBindValue extends MAXTableDomain
/*     */ {
/*     */   public FldLaunchPntVarBindValue(MboValue mbv)
/*     */     throws MXException
/*     */   {
/*  42 */     super(mbv);
/*     */   }








/*     */   public MboSetRemote getList()
/*     */     throws MXException, RemoteException
/*     */   {
/*  55 */     setBindRelationship();
/*  56 */     return super.getList();
/*     */   }











/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  72 */     if ((getMboValue().isNull()) || (getMboValue().getMbo().isNull("varbindingtype")))
/*     */       return;
/*  74 */     String data = getMboValue().getString();
/*  75 */     String bindType = getMboValue().getMbo().getString("varbindingtype");
/*  76 */     if (!(bindType.equalsIgnoreCase("LITERAL")))
/*     */       return;
/*  78 */     if (!(getMboValue().getMbo().isNull("literaldatatype")))
/*     */     {
/*  80 */       String ltrlDtType = getMboValue().getMbo().getString("literaldatatype");
/*  81 */       if (ltrlDtType.equalsIgnoreCase("DATETIME"))
/*     */       {
/*  83 */         ConversionUtil.stringToDate(data);
/*     */       }
/*  85 */       else if ((ltrlDtType.equalsIgnoreCase("DECIMAL")) || (ltrlDtType.equalsIgnoreCase("FLOAT")))

/*     */       {
/*  88 */         ConversionUtil.stringToDouble(data);
/*     */       }
/*  90 */       else if (ltrlDtType.equalsIgnoreCase("INTEGER"))
/*     */       {
/*  92 */         ConversionUtil.stringToLong(data);
/*     */       }
/*  94 */       else if (ltrlDtType.equalsIgnoreCase("SMALLINT"))
/*     */       {
/*  96 */         ConversionUtil.stringToInt(data);
/*     */       }
/*  98 */       else if (ltrlDtType.equalsIgnoreCase("YORN"))
/*     */       {
/* 100 */         ConversionUtil.stringToBoolean(data);
/*     */       }
/*     */     }
/* 103 */     return;
/*     */   }



/*     */   private void setBindRelationship()
/*     */     throws MXException, RemoteException
/*     */   {
/* 111 */     String bindType = getVarBindType();
/* 112 */     if ((bindType == null) || (bindType.equals("")))
/*     */       return;
/* 114 */     if (bindType.equalsIgnoreCase("SYSPROP"))
/*     */     {
/* 116 */       setRelationship("MAXPROP", "propname=:" + getMboValue().getName());
/* 117 */       setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "propname" });
/*     */ 
/* 119 */       setErrorMessage("propmaint", "invalidpropname");
/*     */     }
/* 121 */     if (bindType.equalsIgnoreCase("MAXVAR"))
/*     */     {
/* 123 */       setRelationship("MAXVARTYPE", "varname=:" + getMboValue().getName());
/* 124 */       setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "varname" });
/*     */ 
/* 126 */       setErrorMessage("propmaint", "invalidpropname");
/*     */     }
/* 128 */     if (!(bindType.equalsIgnoreCase("ATTRIBUTE")))
/*     */       return;
/* 130 */     setRelationship("MAXATTRIBUTE", "attributename=:" + getMboValue().getName());
/* 131 */     setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "attributename" });
/*     */ 
/* 133 */     setErrorMessage("propmaint", "invalidpropname");
/*     */   }








/*     */   private String getVarBindType()
/*     */     throws MXException, RemoteException
/*     */   {
/* 146 */     MboSetRemote autoVarSet = getMboValue().getMbo().getMboSet("AUTOSCRIPTVARS");
/* 147 */     if (autoVarSet.isEmpty()) {
/* 148 */       throw new MXApplicationException("script", "not_a_valid_variable");
/*     */     }
/* 150 */     MboRemote autoVar = autoVarSet.getMbo(0);
/* 151 */     return autoVar.getString("varbindingtype");
/*     */   }





/*     */   public MboSetRemote smartFill(String value, boolean exact)
/*     */     throws MXException, RemoteException
/*     */   {
/* 161 */     setBindRelationship();
/* 162 */     return super.smartFill(value, exact);
/*     */   }






/*     */   public String getLookupName()
/*     */     throws MXException, RemoteException
/*     */   {
/* 173 */     String bindType = getVarBindType();
/* 174 */     if ((bindType != null) && (!(bindType.equals(""))))
/*     */     {
/* 176 */       if (bindType.equalsIgnoreCase("SYSPROP"))
/*     */       {
/* 178 */         return "maxprop";
/*     */       }
/* 180 */       if (bindType.equalsIgnoreCase("MAXVAR"))
/*     */       {
/* 182 */         return "maxvartype";
/*     */       }
/*     */     }
/* 185 */     return "";
/*     */   }
/*     */ }
