/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.ALNDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 






































/*    */ public class FldScrLaunchPointType extends ALNDomain
/*    */ {
/*    */   public FldScrLaunchPointType(MboValue mbv)
/*    */   {
/* 51 */     super(mbv);
/*    */   }







/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 63 */     Mbo thisMbo = getMboValue().getMbo();
/* 64 */     String maxvalue = getMboValue().getString();
/* 65 */     if (maxvalue.equalsIgnoreCase("ATTRIBUTE"))
/*    */     {
/* 67 */       thisMbo.setFieldFlag("attributename", 7L, false);
/* 68 */       thisMbo.setFieldFlag("attributename", 128L, true);
/* 69 */       thisMbo.setFieldFlag("objectname", 128L, true);
/*    */     }
/* 71 */     if (maxvalue.equalsIgnoreCase("OBJECT"))
/*    */     {
/* 73 */       thisMbo.setFieldFlag("attributename", 7L, true);
/* 74 */       thisMbo.setFieldFlag("attributename", 128L, false);
/* 75 */       thisMbo.setFieldFlag("objectname", 128L, true);
/*    */     }
/* 77 */     if (!(maxvalue.equalsIgnoreCase("ACTION")))
/*    */       return;
/* 79 */     thisMbo.setFieldFlag("attributename", 7L, true);
/* 80 */     thisMbo.setFieldFlag("attributename", 128L, false);
/* 81 */     thisMbo.setFieldFlag("objectname", 128L, false);
/*    */   }
/*    */ }
