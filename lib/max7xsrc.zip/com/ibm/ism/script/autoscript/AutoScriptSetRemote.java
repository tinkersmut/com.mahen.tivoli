package com.ibm.ism.script.autoscript;

import psdi.mbo.MboSetRemote;

public abstract interface AutoScriptSetRemote extends MboSetRemote
{
  public static final String BOOKMARK = "BOOKMARK";
  public static final String DOCLINKS = "DOCLINKS";
  public static final String AUTOSCRIPTSTATE = "AUTOSCRIPTSTATE";
  public static final String ACTION = "ACTION";
  public static final String AUTOSCRIPTVARS = "AUTOSCRIPTVARS";
  public static final String SCRIPTLAUNCHPOINT = "SCRIPTLAUNCHPOINT";
}
