/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import psdi.mbo.MAXTableDomain;
/*    */ import psdi.mbo.MboValue;
/*    */ 




















/*    */ public class FldLaunchPointAttrName extends MAXTableDomain
/*    */ {
/*    */   public FldLaunchPointAttrName(MboValue mbv)
/*    */   {
/* 30 */     super(mbv);
/* 31 */     setRelationship("MAXATTRIBUTE", "objectname = :objectname and attributename = :attributename");
/* 32 */     setListCriteria("objectname = :objectname");
/*    */   }
/*    */ }
