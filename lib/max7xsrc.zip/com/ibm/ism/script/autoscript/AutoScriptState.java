/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 























/*    */ public class AutoScriptState extends Mbo
/*    */   implements AutoScriptStateRemote
/*    */ {
/*    */   public AutoScriptState(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 39 */     super(ms);
/*    */   }


/*    */   public void init()
/*    */     throws MXException
/*    */   {
/* 46 */     setFlag(7L, true);
/* 47 */     super.init();
/*    */   }








/*    */   public void add()
/*    */     throws MXException, RemoteException
/*    */   {
/* 60 */     MboRemote owner = getOwner();
/*    */ 
/* 62 */     if ((owner == null) || (!(owner instanceof AutoScriptRemote))) {
/* 63 */       throw new MXApplicationException("autoscr", "AutoScriptStateNoAdd");

/*    */     }
/*    */ 
/* 67 */     setValue("autoscript", owner.getString("autoscript"), 9L);
/*    */ 
/* 69 */     setValue("status", owner.getString("status"), 9L);
/* 70 */     setValue("changedate", owner.getDate("statusdate"), 9L);
/*    */ 
/* 72 */     setValue("changeby", owner.getString("changeby"), 9L);
/*    */ 
/* 74 */     setValue("siteid", owner.getString("siteid"), 11L);
/*    */ 
/* 76 */     setValue("orgid", owner.getString("orgid"), 11L);
/*    */   }









/*    */   public void canDelete()
/*    */     throws MXException, RemoteException
/*    */   {
/* 90 */     MboRemote owner = getOwner();
/*    */ 
/* 92 */     if ((owner == null) || (!(owner instanceof AutoScriptRemote)))
/* 93 */       throw new MXApplicationException("autoscr", "AutoScriptStateNoDelete");
/*    */   }
/*    */ }
