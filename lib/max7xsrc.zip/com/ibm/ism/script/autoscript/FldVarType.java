/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.ALNDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 






































/*    */ public class FldVarType extends ALNDomain
/*    */ {
/*    */   public FldVarType(MboValue mbv)
/*    */   {
/* 51 */     super(mbv);
/*    */   }








/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 64 */     Mbo thisMbo = getMboValue().getMbo();
/*    */ 
/* 66 */     String maxvalue = getMboValue().getString();
/* 67 */     boolean isInVariable = maxvalue.equalsIgnoreCase("IN");
/* 68 */     if (isInVariable)
/*    */     {
/* 70 */       thisMbo.setFieldFlag("noaccesscheck", 7L, true);
/* 71 */       thisMbo.setFieldFlag("noaction", 7L, true);
/* 72 */       thisMbo.setFieldFlag("novalidation", 7L, true);
/*    */     }
/*    */     else
/*    */     {
/* 76 */       thisMbo.setFieldFlag("noaccesscheck", 7L, false);
/* 77 */       thisMbo.setFieldFlag("noaction", 7L, false);
/* 78 */       thisMbo.setFieldFlag("novalidation", 7L, false);
/*    */     }
/*    */   }
/*    */ }
