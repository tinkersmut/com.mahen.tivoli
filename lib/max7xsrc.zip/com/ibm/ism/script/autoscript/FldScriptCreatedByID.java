/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.app.person.FldPersonID;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 






















/*    */ public class FldScriptCreatedByID extends FldPersonID
/*    */ {
/*    */   public FldScriptCreatedByID(MboValue mbv)
/*    */     throws RemoteException, MXException
/*    */   {
/* 38 */     super(mbv);
/*    */   }

/*    */   public void initValue() throws MXException, RemoteException
/*    */   {
/* 43 */     MboValue name = getMboValue();
/* 44 */     if ((!(name.getMbo().toBeAdded())) || 

/* 46 */       (!(name.isNull())))
/*    */       return;
/* 48 */     name.setValue(name.getMbo().getString("person.personid"), 11L);
/*    */   }


/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 55 */     MboRemote scriptMbo = getMboValue().getMbo();
/* 56 */     MboSetRemote personSet = getMboSet();
/* 57 */     MboRemote personMbo = null;

/*    */ 
/* 60 */     if ((getMboValue().isNull()) || (personSet.isEmpty())) {
/* 61 */       scriptMbo.setValueNull("createdby", 11L);
/*    */ 
/* 63 */       scriptMbo.setValueNull("createdbyName", 11L);
/*    */ 
/* 65 */       scriptMbo.setValueNull("createdbyPhone", 11L);
/*    */ 
/* 67 */       scriptMbo.setValueNull("createdbyEmail", 11L);
/*    */ 
/* 69 */       return;
/*    */     }
/*    */ 
/* 72 */     personMbo = personSet.getMbo(0);
/* 73 */     scriptMbo.setValue("createdby", personMbo.getString("personid"), 2L);
/*    */ 
/* 75 */     scriptMbo.setValue("createdbyName", personMbo.getString("displayname"), 11L);


/*    */ 
/* 79 */     if (scriptMbo.isNull("ownerID")) {
/* 80 */       scriptMbo.setValue("ownerID", scriptMbo.getString("createdbyID"), 11L);
/*    */ 
/* 82 */       scriptMbo.setValue("ownerName", scriptMbo.getString("createdbyName"), 11L);
/*    */     }
/*    */   }
/*    */ }
