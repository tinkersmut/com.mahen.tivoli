/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MAXTableDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 






















/*    */ public class FldScriptCreatedByName extends MAXTableDomain
/*    */ {
/*    */   public FldScriptCreatedByName(MboValue mbv)
/*    */     throws RemoteException, MXException
/*    */   {
/* 38 */     super(mbv);
/* 39 */     String thisAttr = getMboValue().getAttributeName();
/* 40 */     setRelationship("PERSON", "displayname=:" + thisAttr + " and status in (select value from synonymdomain where maxvalue='ACTIVE' and domainid='PERSONSTATUS')");



/*    */ 
/* 45 */     setErrorMessage("person", "InvalidPerson");
/* 46 */     String[] target = { "createdbyname", "createdbyid" };
/* 47 */     String[] source = { "displayname", "personid" };
/* 48 */     setLookupKeyMapInOrder(target, source);
/*    */   }

/*    */   public void initValue() throws MXException, RemoteException
/*    */   {
/* 53 */     MboValue name = getMboValue();
/* 54 */     if ((!(name.getMbo().toBeAdded())) || 

/* 56 */       (!(name.isNull()))) return;
/* 57 */     name.setValue(name.getMbo().getString("person.displayname"), 11L);
/*    */ 
/* 59 */     if (name.isNull())
/* 60 */       name.setValue(name.getMbo().getString("createdbyid"), 11L);
/*    */   }













/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 78 */     MboRemote scriptMbo = getMboValue().getMbo();
/* 79 */     MboSetRemote personSet = getMboSet();
/* 80 */     MboRemote personMbo = null;

/*    */ 
/* 83 */     if ((getMboValue().isNull()) || (personSet.isEmpty())) {
/* 84 */       scriptMbo.setValueNull("createdById", 11L);
/*    */ 
/* 86 */       scriptMbo.setValueNull("createdByPhone", 11L);
/*    */ 
/* 88 */       scriptMbo.setValueNull("createdByEmail", 11L);
/*    */ 
/* 90 */       return;
/*    */     }
/*    */ 
/* 93 */     personMbo = personSet.getMbo(0);
/* 94 */     scriptMbo.setValue("CreatedById", personMbo.getString("personid"), 11L);
/*    */ 
/* 96 */     if (scriptMbo.isNull("OwnerName")) {
/* 97 */       scriptMbo.setValue("OwnerID", scriptMbo.getString("createdById"), 11L);
/*    */ 
/* 99 */       scriptMbo.setValue("ownerName", scriptMbo.getString("createdByName"), 11L);
/*    */     }
/*    */   }
/*    */ }
