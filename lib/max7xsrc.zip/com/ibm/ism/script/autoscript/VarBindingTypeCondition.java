/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.common.condition.CustomCondition;
/*    */ import psdi.iface.mic.MicUtil;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.MXSystemException;
/*    */ import psdi.util.logging.MXLogger;
/*    */ 























/*    */ public class VarBindingTypeCondition
/*    */   implements CustomCondition
/*    */ {
/* 31 */   public static final MXLogger INTEGRATIONLOGGER = MicUtil.INTEGRATIONLOGGER;
/*    */ 
/*    */   public boolean evaluateCondition(MboRemote mbo, Object param)
/*    */     throws MXException, RemoteException
/*    */   {
/* 43 */     if (INTEGRATIONLOGGER.isDebugEnabled())
/*    */     {
/* 45 */       INTEGRATIONLOGGER.debug("PublishCognosCondition evaluateCondition(MboRemote mbo, Object param) entry with mbo = " + mbo + ", param = " + param);

/*    */     }
/*    */ 
/* 49 */     String type = mbo.getString("varbindingtype");
/* 50 */     if (!(type.equalsIgnoreCase("ATTRIBUTE")))
/*    */     {
/* 52 */       if (INTEGRATIONLOGGER.isDebugEnabled())
/*    */       {
/* 54 */         INTEGRATIONLOGGER.debug("evaluateCondition(MboRemote mbo, Object param) exit, returning false because the Use With is not REPORTING.");
/*    */       }
/* 56 */       return false;
/*    */     }
/* 58 */     return true;
/*    */   }











/*    */   public String toWhereClause(Object param, MboSetRemote msr)
/*    */     throws MXException, RemoteException
/*    */   {
/* 74 */     if (INTEGRATIONLOGGER.isErrorEnabled())
/*    */     {
/* 76 */       INTEGRATIONLOGGER.error("This condition class does not support the toWhereClause operation.");
/*    */     }
/* 78 */     throw new MXSystemException("iface", "cannot_use_condition");
/*    */   }
/*    */ }
