/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.app.person.FldPersonID;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 





















/*    */ public class FldScriptOwnerID extends FldPersonID
/*    */ {
/*    */   public FldScriptOwnerID(MboValue mbv)
/*    */     throws MXException, RemoteException
/*    */   {
/* 37 */     super(mbv);
/*    */   }

/*    */   public void initValue() throws MXException, RemoteException {
/* 41 */     MboValue name = getMboValue();
/* 42 */     if ((!(name.getMbo().toBeAdded())) || 

/* 44 */       (!(name.isNull()))) return;
/* 45 */     name.setValue(name.getMbo().getString("owner.personid"), 11L);
/*    */   }






/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 56 */     MboRemote scriptMbo = getMboValue().getMbo();
/* 57 */     MboSetRemote personSet = getMboSet();
/* 58 */     MboRemote personMbo = null;

/*    */ 
/* 61 */     if ((getMboValue().isNull()) || (personSet.isEmpty())) {
/* 62 */       scriptMbo.setValueNull("owner", 11L);
/*    */ 
/* 64 */       scriptMbo.setValueNull("ownerName", 11L);
/*    */ 
/* 66 */       scriptMbo.setValueNull("ownerPhone", 11L);
/*    */ 
/* 68 */       scriptMbo.setValueNull("ownerEmail", 11L);
/*    */ 
/* 70 */       return;
/*    */     }
/*    */ 
/* 73 */     personMbo = personSet.getMbo(0);
/* 74 */     scriptMbo.setValue("Owner", personMbo.getString("personid"), 2L);
/*    */ 
/* 76 */     scriptMbo.setValue("ownerName", personMbo.getString("displayname"), 11L);
/*    */   }
/*    */ }
