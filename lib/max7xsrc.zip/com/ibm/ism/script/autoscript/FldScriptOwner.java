/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.app.person.FldPersonID;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 






















/*    */ public class FldScriptOwner extends FldPersonID
/*    */ {
/*    */   public FldScriptOwner(MboValue mbv)
/*    */     throws MXException, RemoteException
/*    */   {
/* 37 */     super(mbv);
/*    */   }











/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 53 */     MboRemote scriptMbo = getMboValue().getMbo();
/* 54 */     MboSetRemote personSet = getMboSet();

/*    */ 
/* 57 */     if ((getMboValue().isNull()) || (personSet.isEmpty())) {
/* 58 */       scriptMbo.setValueNull("OwnerPhone", 11L);
/*    */ 
/* 60 */       scriptMbo.setValueNull("OwnerEmail", 11L);


/*    */ 
/* 64 */       return;

/*    */     }
/*    */ 
/* 68 */     MboSetRemote phones = personSet.getMbo(0).getMboSet("PHONE");
/* 69 */     phones.setWhere("ISPRIMARY=:yes");
/*    */ 
/* 71 */     String phonenum = null;
/*    */ 
/* 73 */     if (phones.isEmpty()) {
/* 74 */       phonenum = "";
/*    */     }
/*    */     else {
/* 77 */       phonenum = phones.getMbo(0).getString("phonenum");

/*    */     }
/*    */ 
/* 81 */     MboSetRemote email = personSet.getMbo(0).getMboSet("EMAIL");
/* 82 */     email.setWhere("ISPRIMARY=:yes");
/*    */ 
/* 84 */     String emailaddress = null;
/*    */ 
/* 86 */     if (email.isEmpty()) {
/* 87 */       emailaddress = "";
/*    */     }
/*    */     else {
/* 90 */       emailaddress = email.getMbo(0).getString("emailaddress");
/*    */     }
/*    */ 
/* 93 */     if (scriptMbo.getString("Owner").equals(scriptMbo.getString("Createdby")))
/*    */     {
/* 95 */       scriptMbo.setValue("OwnerPhone", scriptMbo.getString("CreatedbyPhone"), 11L);

/*    */ 
/* 98 */       scriptMbo.setValue("OwnerEmail", scriptMbo.getString("CreatedbyEmail"), 11L);



/*    */     }
/*    */     else
/*    */     {
/* 105 */       scriptMbo.setValue("OwnerPhone", phonenum, 11L);
/*    */ 
/* 107 */       scriptMbo.setValue("OwnerEmail", emailaddress, 11L);
/*    */     }
/*    */   }
/*    */ }
