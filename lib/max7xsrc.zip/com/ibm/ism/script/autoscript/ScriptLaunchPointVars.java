/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
























































/*     */ public class ScriptLaunchPointVars extends Mbo
/*     */   implements MboRemote
/*     */ {
/*  65 */   protected static Set<String> skipFieldCopy = new HashSet();
/*     */ 
/*  72 */   protected static boolean isHashSetLoaded = false;
/*     */ 
/*     */   public ScriptLaunchPointVars(MboSet ms)
/*     */     throws RemoteException
/*     */   {
/*  81 */     super(ms);
/*     */   }






/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  92 */     super.init();
/*     */     try
/*     */     {
/*  95 */       String[] readOnlyAfterSave = { "autoscript", "launchpointname", "varname" };
/*  96 */       setFieldFlag(readOnlyAfterSave, 7L, true);
/*     */ 
/*  98 */       if (!(toBeAdded()))
/*     */       {
/* 100 */         setValue("overridden", true, 2L);
/* 101 */         setFieldFlag("varbindingvalue", 7L, false);
/*     */ 
/* 103 */         MboRemote autoVar = getMboSet("AUTOSCRIPTVARS").getMbo(0);
/* 104 */         setValue("varbindingtype", autoVar.getString("varbindingtype"), 2L);
/* 105 */         setValue("literaldatatype", autoVar.getString("literaldatatype"), 2L);
/*     */       }
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/* 110 */       getMboLogger().error(e.getMessage(), e);
/* 111 */       throw new MXApplicationException("script", "cannot_initialize_vars");
/*     */     }
/* 113 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 115 */     getMboLogger().debug("Leaving ScriptLaunchPointVars init");
/*     */   }












/*     */   public void add()
/*     */     throws MXException, RemoteException
/*     */   {
/* 132 */     getMboLogger().debug("Entered Launch Point Vars.add()");
/* 133 */     MboRemote owner = getOwner();
/* 134 */     if ((owner == null) || (!(owner.isBasedOn("SCRIPTLAUNCHPOINT"))))
/*     */       return;
/* 136 */     setValue("autoscript", owner.getString("autoscript"), 11L);
/*     */ 
/* 138 */     setValue("launchpointname", owner.getString("launchpointname"), 11L);
/*     */   }










/*     */   public void modify()
/*     */     throws MXException, RemoteException
/*     */   {
/* 153 */     if (getMboLogger().isDebugEnabled())
/*     */     {
/* 155 */       getMboLogger().debug("Entering ScriptLaunchPointVars modify");
/*     */     }
/* 157 */     if ((getOwner() != null) && (getOwner().getOwner() != null))
/*     */     {
/* 159 */       ((Mbo)getOwner().getOwner()).modify();
/*     */     }
/* 161 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 163 */     getMboLogger().debug("Leaving ScriptLaunchPointVars modify");
/*     */   }








/*     */   public void save()
/*     */     throws MXException, RemoteException
/*     */   {
/* 176 */     if (!(getBoolean("overridden")))
/*     */     {
/* 178 */       delete();
/*     */     }
/* 180 */     super.save();
/*     */   }






















/*     */   protected void loadSkipFieldCopyHashSet()
/*     */     throws MXException, RemoteException
/*     */   {
/* 207 */     isHashSetLoaded = true;
/* 208 */     skipFieldCopy.add("AUTOSCRIPT");
/* 209 */     skipFieldCopy.add("LAUNCHPOINTNAME");
/* 210 */     skipFieldCopy.add("VARNAME");
/*     */   }










/*     */   protected boolean skipCopyField(MboValueInfo mvi)
/*     */     throws RemoteException, MXException
/*     */   {
/* 225 */     return (skipFieldCopy.contains(mvi.getName()));
/*     */   }
/*     */ }
