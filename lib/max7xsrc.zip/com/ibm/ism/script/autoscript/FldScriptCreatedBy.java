/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.app.person.FldPersonID;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.util.MXException;
/*     */ 






















/*     */ public class FldScriptCreatedBy extends FldPersonID
/*     */ {
/*     */   public FldScriptCreatedBy(MboValue mbv)
/*     */     throws RemoteException, MXException
/*     */   {
/*  37 */     super(mbv);
/*     */   }









/*     */   public void action()
/*     */     throws MXException, RemoteException
/*     */   {
/*  51 */     MboRemote scriptMbo = getMboValue().getMbo();
/*  52 */     MboSetRemote personSet = getMboSet();

/*     */ 
/*  55 */     if ((getMboValue().isNull()) || (personSet.isEmpty())) {
/*  56 */       scriptMbo.setValueNull("CreatedByPhone", 11L);
/*     */ 
/*  58 */       scriptMbo.setValueNull("CreatedByEmail", 11L);
/*     */ 
/*  60 */       return;

/*     */     }
/*     */ 
/*  64 */     MboSetRemote phones = personSet.getMbo(0).getMboSet("PHONE");
/*  65 */     phones.setWhere("ISPRIMARY=:yes");
/*     */ 
/*  67 */     String phonenum = null;
/*     */ 
/*  69 */     if (phones.isEmpty()) {
/*  70 */       phonenum = "";
/*     */     }
/*     */     else {
/*  73 */       phonenum = phones.getMbo(0).getString("phonenum");

/*     */     }
/*     */ 
/*  77 */     MboSetRemote email = personSet.getMbo(0).getMboSet("EMAIL");
/*  78 */     email.setWhere("ISPRIMARY=:yes");
/*     */ 
/*  80 */     String emailaddress = null;
/*     */ 
/*  82 */     if (email.isEmpty()) {
/*  83 */       emailaddress = "";
/*     */     }
/*     */     else {
/*  86 */       emailaddress = email.getMbo(0).getString("emailaddress");
/*     */     }
/*     */ 
/*  89 */     if (scriptMbo.isNull("owner")) {
/*  90 */       scriptMbo.setValue("owner", scriptMbo.getString("createdby"), 2L);


/*     */     }
/*     */ 
/*  95 */     scriptMbo.setValue("createdbyPhone", phonenum, 11L);
/*     */ 
/*  97 */     scriptMbo.setValue("createdbyEmail", emailaddress, 11L);

/*     */ 
/* 100 */     if (!(scriptMbo.getString("owner").equals(scriptMbo.getString("createdby"))))
/*     */       return;
/* 102 */     scriptMbo.setValue("ownerPhone", scriptMbo.getString("createdbyPhone"), 11L);

/*     */ 
/* 105 */     scriptMbo.setValue("ownerEmail", scriptMbo.getString("createdbyEmail"), 11L);
/*     */   }
/*     */ }
