/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import psdi.iface.app.intobject.RelationNameComparator;
/*     */ import psdi.iface.jms.MessageUtil;
/*     */ import psdi.mbo.HierarchicalMboSetRemote;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetInfo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueData;
/*     */ import psdi.mbo.NonPersistentMboSet;
/*     */ import psdi.mbo.RelationInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 







/*     */ public class ScriptAttributeTreeSet extends NonPersistentMboSet
/*     */   implements ScriptAttributeTreeSetRemote, HierarchicalMboSetRemote
/*     */ {
/*  34 */   private int attrId = 0;
/*  35 */   private int relationdepth = new Integer(MXServer.getMXServer().getProperty("mxe.script.attributelevel")).intValue();
/*     */ 
/*     */   public ScriptAttributeTreeSet(MboServerInterface ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  43 */     super(ms);
/*     */   }





/*     */   protected Mbo getMboInstance(MboSet ms)
/*     */     throws MXException, RemoteException
/*     */   {
/*  53 */     return new ScriptAttributeTree(ms);
/*     */   }















/*     */   public MboValueData[][] getChildren(String object, String key, String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/*  73 */     List lst = new ArrayList();
/*     */ 
/*  75 */     MboRemote thisMbo = findMbo(getMbo(0), key);
/*  76 */     MboSetRemote child = thisMbo.getMboSet("TREENODE");
/*  77 */     for (int j = 0; j < child.getSize(); ++j)
/*     */     {
/*  79 */       MboRemote childMbo = child.getMbo(j);
/*     */ 
/*  81 */       if (childMbo == null)
/*     */         continue;
/*  83 */       lst.add(childMbo.getMboValueData(attrs));
/*     */     }
/*     */ 
/*  86 */     MboValueData[][] aaa = new MboValueData[lst.size()][];
/*  87 */     int j = 0;
/*  88 */     for (MboValueData[] zzz : lst)
/*  89 */       aaa[(j++)] = zzz;
/*  90 */     return aaa;
/*     */   }













/*     */   public MboValueData[] getParent(String object, String key, String[] attrs)
/*     */     throws MXException, RemoteException
/*     */   {
/* 108 */     if (!(getMbo(0).getBoolean("hasparent")))
/*     */     {
/* 110 */       return null;
/*     */     }
/* 112 */     MboRemote mbo = getOwner();
/* 113 */     return mbo.getMboValueData(attrs);
/*     */   }













/*     */   public MboValueData[][] getSiblings(String object, String key, String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/* 131 */     return ((MboValueData[][])null);
/*     */   }













/*     */   public MboValueData[][] getTop(String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/* 149 */     MboRemote thisMbo = getMbo();
/*     */ 
/* 151 */     if (getSize() == 0)
/*     */     {
/* 153 */       return ((MboValueData[][])null);
/*     */     }
/* 155 */     if (!(getBoolean("hasparent")))
/*     */     {
/* 157 */       return getMboValueData(0, count(), attrs);
/*     */     }
/*     */ 
/*     */     while (true)
/*     */     {
/* 162 */       MboRemote owner = thisMbo.getOwner();
/* 163 */       if (owner == null)
/*     */       {
/* 165 */         return ((MboValueData[][])null);
/*     */       }
/* 167 */       if (!(owner.getBoolean("hasparent")))
/*     */       {
/* 169 */         return getMboValueData(0, count(), attrs);
/*     */       }
/* 171 */       thisMbo = owner;
/*     */     }
/*     */   }















/*     */   public MboValueData[][] getPathToTop(String object, String key, String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/* 192 */     return ((MboValueData[][])null);
/*     */   }






/*     */   public void fill(String objectName, String parentObjName, String relationName, boolean top, int leafLevel)
/*     */     throws MXException, RemoteException
/*     */   {
/* 203 */     MboRemote mbo = addAtEnd();
/* 204 */     MaximoDD maxDD = MXServer.getMXServer().getMaximoDD();
/* 205 */     MboSetInfo mboSetInfo = maxDD.getMboSetInfo(objectName);
/* 206 */     String objName = objectName;
/* 207 */     long uid = Long.parseLong(MessageUtil.generateUniqueID());
/* 208 */     mbo.setValue("scrattrtreeid", uid);
/* 209 */     mbo.setValue("objectname", objName, 2L);
/* 210 */     String elementpath = "";
/*     */ 
/* 212 */     if (top)
/*     */     {
/* 214 */       elementpath = objName;
/* 215 */       mbo.setValue("elementpath", elementpath, 2L);
/* 216 */       mbo.setValue("hasparent", false);
/* 217 */       mbo.setValue("title", objName, 2L);
/*     */     }
/*     */     else
/*     */     {
/* 221 */       elementpath = parentObjName + "." + objName;
/* 222 */       mbo.setValue("elementpath", elementpath, 2L);
/* 223 */       mbo.setValue("hasparent", true);
/* 224 */       mbo.setValue("title", objName + "-" + relationName, 2L);
/*     */     }
/* 226 */     mbo.setValue("haschildren", true, 2L);
/*     */ 
/* 228 */     Map fullAttrMap = mboSetInfo.getAttributeDetails();
/* 229 */     ScriptAttributeTreeSet requestAttrSet = (ScriptAttributeTreeSet)mbo.getMboSet("TREENODE");
/* 230 */     Iterator attrItr = fullAttrMap.keySet().iterator();
/* 231 */     List lstAttr = new ArrayList();
/* 232 */     while (attrItr.hasNext())
/*     */     {
/* 234 */       lstAttr.add((String)attrItr.next());
/*     */     }
/* 236 */     Collections.sort(lstAttr);
/* 237 */     for (String strAttr : lstAttr)
/*     */     {
/* 239 */       uid = Long.parseLong(MessageUtil.generateUniqueID());
/* 240 */       MboRemote attrMbo = requestAttrSet.addAtEnd();
/* 241 */       attrMbo.setValue("scrattrtreeid", uid, 2L);
/* 242 */       attrMbo.setValue("objectname", strAttr, 2L);
/* 243 */       attrMbo.setValue("title", strAttr, 2L);
/* 244 */       attrMbo.setValue("elementpath", elementpath + "." + strAttr, 2L);
/* 245 */       attrMbo.setValue("hasparent", true, 2L);
/* 246 */       attrMbo.setValue("haschildren", false, 2L);
/* 247 */       if (top);




/*     */     }
/*     */ 
/* 254 */     if (leafLevel > this.relationdepth) {
/* 255 */       return;
/*     */     }
/* 257 */     Iterator itr = mboSetInfo.getRelationsInfo();
/* 258 */     List relList = new ArrayList();
/* 259 */     while (itr.hasNext())
/*     */     {
/* 261 */       relList.add((RelationInfo)itr.next());
/*     */     }
/* 263 */     Collections.sort(relList, new RelationNameComparator());
/* 264 */     for (RelationInfo relInfo : relList)
/*     */     {
/* 266 */       requestAttrSet.fill(relInfo.getDest(), elementpath, relInfo.getName(), false, ++leafLevel);
/*     */     }
/*     */   }


/*     */   public MboRemote setup()
/*     */     throws MXException, RemoteException
/*     */   {
/* 274 */     return super.setup();
/*     */   }




/*     */   public MboValueData getUniqueIDValue(String object, String[] attributes, String[] values)
/*     */     throws MXException, RemoteException
/*     */   {
/* 283 */     return null;
/*     */   }














/*     */   public MboValueData[][] getAllHierarchies(String object, String key, String[] attrs, int maxRows)
/*     */     throws MXException, RemoteException
/*     */   {
/* 302 */     return ((MboValueData[][])null);
/*     */   }




/*     */   public MboValueData[] getHierarchy(String object, String key)
/*     */     throws MXException, RemoteException
/*     */   {
/* 311 */     return null;
/*     */   }





/*     */   public MboRemote findMbo(MboRemote mbo, String key)
/*     */     throws MXException, RemoteException
/*     */   {
/* 321 */     MboRemote returnMbo = null;
/* 322 */     if (key == null)
/*     */     {
/* 324 */       throw new MXApplicationException("jspmessages", "table_noselectedrows");
/*     */     }
/* 326 */     if (key.equals(mbo.getString("scrattrtreeid")))
/*     */     {
/* 328 */       return mbo;
/*     */     }
/* 330 */     MboSetRemote child = mbo.getMboSet("TREENODE");
/* 331 */     for (int j = 0; j < child.getSize(); ++j)
/*     */     {
/* 333 */       MboRemote childMbo = child.getMbo(j);
/*     */ 
/* 335 */       if (key.equals(childMbo.getString("scrattrtreeid")))
/*     */       {
/* 337 */         return childMbo;

/*     */       }
/*     */ 
/* 341 */       returnMbo = findMbo(childMbo, key);
/* 342 */       if (returnMbo != null)
/*     */       {
/* 344 */         return returnMbo;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 349 */     return null;
/*     */   }

/*     */   private int getNextId()
/*     */   {
/* 354 */     return (this.attrId++);
/*     */   }
/*     */ }
