/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ 



























/*    */ public class ScriptLaunchPointVarsSet extends MboSet
/*    */   implements ScriptLaunchPointVarsSetRemote
/*    */ {
/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 44 */     return new ScriptLaunchPointVars(ms);
/*    */   }





/*    */   public ScriptLaunchPointVarsSet(MboServerInterface ms)
/*    */     throws RemoteException
/*    */   {
/* 54 */     super(ms);
/*    */   }








/*    */   public void fillLaunchPointVars(MboRemote autovar)
/*    */     throws MXException, RemoteException
/*    */   {
/* 67 */     MboSetRemote varsSet = autovar.getMboSet("AUTOSCRIPTVARS");
/* 68 */     MboRemote var = null;
/* 69 */     for (int i = 0; ; ++i)
/*    */     {
/* 71 */       var = varsSet.getMbo(i);
/* 72 */       if (var == null) {
/*    */         return;
/*    */       }
/*    */ 
/* 76 */       boolean exist = false;
/* 77 */       String bindType = var.getString("varbindingtype");
/* 78 */       for (int j = 0; j < count(); ++j)
/*    */       {
/* 80 */         MboRemote structMbo = getMbo(j);
/* 81 */         if (!(structMbo.getString("varname").equals(var.getString("varname"))))
/*    */           continue;
/* 83 */         structMbo.setValue("overridden", true, 11L);
/* 84 */         structMbo.setFieldFlag("varbindingvalue", 7L, false);
/* 85 */         if (bindType.equalsIgnoreCase("ATTRIBUTE"))
/*    */         {
/* 87 */           structMbo.setFieldFlag("overridden", 7L, true);
/*    */         }
/* 89 */         exist = true;
/* 90 */         break;
/*    */       }
/*    */ 
/* 93 */       if (exist) {
/*    */         continue;
/*    */       }
/* 96 */       MboRemote launchVarMbo = addAtEnd();
/* 97 */       launchVarMbo.setValue("varname", var.getString("varname"), 11L);
/* 98 */       launchVarMbo.setValue("varbindingvalue", var.getString("varbindingvalue"), 2L);
/* 99 */       String maxvalue = var.getString("varbindingtype");
/* 100 */       launchVarMbo.setValue("varbindingtype", maxvalue, 2L);
/* 101 */       boolean isAttr = maxvalue.equalsIgnoreCase("ATTRIBUTE");
/* 102 */       if (isAttr)
/*    */       {
/* 104 */         launchVarMbo.setValue("lpattributevaluenp", var.getString("varbindingvalue"), 11L);
/*    */       }
/* 106 */       launchVarMbo.setValue("literaldatatype", var.getString("literaldatatype"), 2L);
/* 107 */       if (bindType.equalsIgnoreCase("ATTRIBUTE"))
/*    */       {
/* 109 */         launchVarMbo.setValue("overridden", true, 11L);
/* 110 */         launchVarMbo.setFieldFlag("overridden", 7L, true);
/* 111 */         launchVarMbo.setFieldFlag("varbindingvalue", 7L, false);
/*    */       }
/*    */       else
/*    */       {
/* 115 */         launchVarMbo.setValue("overridden", false, 11L);
/* 116 */         launchVarMbo.setFieldFlag("varbindingvalue", 7L, true);
/*    */       }
/*    */     }
/*    */   }
/*    */ }
