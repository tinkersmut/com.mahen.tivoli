/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.security.UserInfo;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXApplicationYesNoCancelException;
/*    */ import psdi.util.MXException;
/*    */ 





























/*    */ public class FldAutoScriptBinarySource extends MboValueAdapter
/*    */ {
/*    */   public FldAutoScriptBinarySource(MboValue mbv)
/*    */   {
/* 47 */     super(mbv);
/*    */   }

/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 53 */     getMboValue().getMbo().setValueNull("source", 2L);
/* 54 */     getMboValue().getMbo().setFieldFlag("source", 7L, true);
/*    */   }









/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 68 */     MboRemote thisMbo = getMboValue().getMbo();
/* 69 */     if ((thisMbo.toBeAdded()) || 

/* 71 */       (!(thisMbo.getUserInfo().isInteractive())))
/*    */       return;
/* 73 */     int userInput = MXApplicationYesNoCancelException.getUserInput("sourceoverwritewarning", MXServer.getMXServer(), thisMbo.getUserInfo());
/*    */ 
/* 75 */     switch (userInput)
/*    */     {
/*    */     case 8:
/* 78 */       break;
/*    */     case 16:
/* 80 */       throw new MXApplicationException("script", "sourcenotchanged");
/*    */     case -1:
/* 82 */       throw new MXApplicationYesNoCancelException("sourceoverwritewarning", "script", "sourcechangewarning");
/*    */     }
/*    */   }
/*    */ }
