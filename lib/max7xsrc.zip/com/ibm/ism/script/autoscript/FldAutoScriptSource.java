/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.security.UserInfo;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXApplicationYesNoCancelException;
/*    */ import psdi.util.MXException;
/*    */ 






























/*    */ public class FldAutoScriptSource extends MboValueAdapter
/*    */ {
/*    */   public FldAutoScriptSource(MboValue mbv)
/*    */   {
/* 47 */     super(mbv);
/*    */   }









/*    */   public void validate()
/*    */     throws MXException, RemoteException
/*    */   {
/* 61 */     MboRemote thisMbo = getMboValue().getMbo();
/* 62 */     if ((thisMbo.toBeAdded()) || 

/* 64 */       (!(thisMbo.getUserInfo().isInteractive())))
/*    */       return;
/* 66 */     int userInput = MXApplicationYesNoCancelException.getUserInput("sourceoverwritewarning", MXServer.getMXServer(), thisMbo.getUserInfo());
/*    */ 
/* 68 */     switch (userInput)
/*    */     {
/*    */     case 8:
/* 71 */       break;
/*    */     case 16:
/* 73 */       throw new MXApplicationException("script", "sourcenotchanged");
/*    */     case -1:
/* 75 */       throw new MXApplicationYesNoCancelException("sourceoverwritewarning", "script", "sourcechangewarning");
/*    */     }
/*    */   }
/*    */ }
