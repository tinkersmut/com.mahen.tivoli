/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 

























/*    */ public class FldAttributeValueNP extends MboValueAdapter
/*    */ {
/*    */   public FldAttributeValueNP(MboValue mbv)
/*    */     throws MXException
/*    */   {
/* 39 */     super(mbv);
/*    */   }






/*    */   public void initValue()
/*    */     throws MXException, RemoteException
/*    */   {
/* 50 */     super.initValue();
/* 51 */     MboValue value = getMboValue();
/* 52 */     MboRemote lpMbo = value.getMbo();
/* 53 */     String name = lpMbo.getName();
/*    */ 
/* 55 */     if (!(name.equalsIgnoreCase("LAUNCHPOINTVARS")))
/*    */       return;
/* 57 */     boolean isAttr = lpMbo.getString("varbindingtype").equalsIgnoreCase("ATTRIBUTE");
/* 58 */     if (!(isAttr))
/*    */       return;
/* 60 */     value.setValue(lpMbo.getString("varbindingvalue"), 11L);
/*    */   }







/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 72 */     MboRemote thisMbo = getMboValue().getMbo();
/*    */ 
/* 74 */     String name = thisMbo.getName();
/* 75 */     if (name.equalsIgnoreCase("AUTOSCRIPTVARS"))
/*    */     {
/* 77 */       thisMbo.setValue("lpvarbindval", getMboValue().getString(), 11L);
/*    */     }
/* 79 */     if (!(name.equalsIgnoreCase("LAUNCHPOINTVARS")))
/*    */       return;
/* 81 */     thisMbo.setValue("varbindingvalue", getMboValue().getString(), 11L);
/*    */   }
/*    */ }
