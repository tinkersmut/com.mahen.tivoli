/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 



























/*    */ public class AutoScriptStateSet extends MboSet
/*    */   implements AutoScriptStateSetRemote
/*    */ {
/*    */   public AutoScriptStateSet(MboServerInterface ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 43 */     super(ms);
/*    */   }



/*    */   public void init()
/*    */     throws MXException, RemoteException
/*    */   {
/* 51 */     setFlag(7L, true);
/*    */ 
/* 53 */     super.init();
/*    */   }





/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 63 */     return new AutoScriptState(ms);
/*    */   }







/*    */   public void canAdd()
/*    */     throws MXException
/*    */   {
/* 75 */     if (!(getOwner() instanceof AutoScript))
/* 76 */       throw new MXApplicationException("autoscr", "AutoScriptStateNoAdd");
/*    */   }
/*    */ }
