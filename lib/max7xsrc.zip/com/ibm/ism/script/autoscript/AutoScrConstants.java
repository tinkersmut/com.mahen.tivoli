package com.ibm.ism.script.autoscript;

public abstract interface AutoScrConstants
{
  public static final String VARTYPE_LITERAL = "LITERAL";
  public static final String VARTYPE_ATTRIBUTE = "ATTRIBUTE";
  public static final String VARTYPE_MAXVAR = "MAXVAR";
  public static final String VARTYPE_SYSPROP = "SYSPROP";
  public static final String ALN = "ALN";
  public static final String INTEGER = "INTEGER";
  public static final String SMALLINT = "SMALLINT";
  public static final String YORN = "YORN";
  public static final String FLOAT = "FLOAT";
  public static final String DECIMAL = "DECIMAL";
  public static final String DATETIME = "DATETIME";
  public static final String LNCH_PNT_TYPE_OBJECT = "OBJECT";
  public static final String LNCH_PNT_TYPE_ATTR = "ATTRIBUTE";
  public static final String LNCH_PNT_TYPE_ACTION = "ACTION";
  public static final String LNCH_PNT_TYPE_CUSTOMCONDITION = "CUSTOMCONDITION";
  public static final long INIT = 1L;
  public static final long ADD = 2L;
  public static final long UPDATE = 4L;
  public static final long DELETE = 8L;
  public static final String VARTYPE_IN = "IN";
  public static final String VARTYPE_OUT = "OUT";
  public static final String VARTYPE_INOUT = "INOUT";
}
