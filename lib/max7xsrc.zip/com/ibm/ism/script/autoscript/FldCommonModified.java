/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 














































/*    */ public class FldCommonModified extends MboValueAdapter
/*    */ {
/*    */   public FldCommonModified(MboValue mbv)
/*    */   {
/* 59 */     super(mbv);
/*    */   }






/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 70 */     getMboValue().getMbo().setModified(true);
/*    */   }
/*    */ }
