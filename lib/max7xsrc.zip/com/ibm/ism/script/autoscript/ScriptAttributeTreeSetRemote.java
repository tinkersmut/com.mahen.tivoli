package com.ibm.ism.script.autoscript;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.mbo.MboValueData;
import psdi.mbo.NonPersistentMboSetRemote;
import psdi.util.MXException;

public abstract interface ScriptAttributeTreeSetRemote extends NonPersistentMboSetRemote
{
  public abstract MboValueData[][] getTop(String[] paramArrayOfString, int paramInt)
    throws MXException, RemoteException;

  public abstract MboRemote findMbo(MboRemote paramMboRemote, String paramString)
    throws MXException, RemoteException;
}
