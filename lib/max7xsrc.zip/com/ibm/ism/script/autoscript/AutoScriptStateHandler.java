/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.StatefulMbo;
/*     */ import psdi.mbo.StatusHandler;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.security.ProfileRemote;
/*     */ import psdi.util.MXAccessException;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 






















/*     */ public class AutoScriptStateHandler extends StatusHandler
/*     */ {
/*  39 */   private static final Class CLASS = AutoScriptStateHandler.class;
/*     */ 
/*  41 */   private StatefulMbo parent = null;
/*     */ 
/*     */   public AutoScriptStateHandler(StatefulMbo sm)
/*     */   {
/*  47 */     super(sm);
/*     */ 
/*  49 */     this.parent = sm;
/*     */   }












/*     */   public void checkStatusChangeAuthorization(String desiredExternalState)
/*     */     throws MXException, RemoteException
/*     */   {
/*  66 */     String desiredMaxState = this.parent.getTranslator().toInternalString("AUTOSCRPHASE", desiredExternalState);


/*     */ 
/*  70 */     checkUserSecurity(desiredMaxState);
/*     */   }













/*     */   public void checkUserSecurity(String desiredMaxState)
/*     */     throws MXException, RemoteException
/*     */   {
/*  88 */     String application = this.parent.getThisMboSet().getApp();
/*  89 */     if ((application == null) || (application.equals("")))

/*     */     {
/*  92 */       return;
/*     */     }
/*     */ 
/*  95 */     ProfileRemote p = this.parent.getMboServer().getProfile(this.parent.getUserInfo());

/*     */ 
/*  98 */     if (!(p.getAppOptionAuth(application, " ", this.parent.getString("siteid"))))
/*  99 */       throw new MXAccessException("access", "notauthorized");
/*     */   }





























/*     */   public void changeStatus(String currentState, String desiredState, Date date, String memo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 133 */     MXLogger myLogger = MXLoggerFactory.getLogger("maximo.application.AUTOSCRIPT");
/*     */ 
/* 135 */     if ((this.parent.getDate("Statusdate") != null) && 


/* 138 */       (date.getTime() < this.parent.getDate("Statusdate").getTime())) {
/* 139 */       throw new MXApplicationException("autoscr", "Statusdate");


/*     */     }
/*     */ 
/* 144 */     String currentMaxState = this.parent.getTranslator().toInternalString("AUTOSCRPHASE", currentState);
/*     */ 
/* 146 */     String desiredMaxState = this.parent.getTranslator().toInternalString("AUTOSCRPHASE", desiredState);

/*     */ 
/* 149 */     if (myLogger.isDebugEnabled())
/*     */     {
/* 151 */       myLogger.debug("currentMaxState = " + currentMaxState + ", desiredMaxState = " + desiredMaxState);


/*     */     }
/*     */ 
/* 156 */     if (!(currentMaxState.equals(desiredMaxState))) {
/* 157 */       this.parent.setValue("Status", desiredState, 2L);
/* 158 */       this.parent.setValue("Statusdate", date, 2L);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void postStatusChange(String currentState, String State, Date asOfDate, String memo)
/*     */     throws MXException, RemoteException
/*     */   {
/*     */   }
/*     */ }
