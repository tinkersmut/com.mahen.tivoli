package com.ibm.ism.script.autoscript;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.util.MXException;

public abstract interface AutoScriptRemote extends MboRemote
{
  public abstract void componentAdded()
    throws MXException, RemoteException;

  public abstract boolean preCompileScript()
    throws RemoteException, MXException;
}
