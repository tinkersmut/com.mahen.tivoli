/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 



























/*    */ public class FldIsOverridden extends MboValueAdapter
/*    */ {
/*    */   public FldIsOverridden(MboValue mbv)
/*    */   {
/* 40 */     super(mbv);
/*    */   }







/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 52 */     MboRemote thisMbo = getMboValue().getMbo();
/* 53 */     if (getMboValue().getBoolean())
/*    */     {
/* 55 */       thisMbo.setFieldFlag("varbindingvalue", 7L, false);
/*    */     }
/*    */     else
/*    */     {
/* 59 */       thisMbo.setFieldFlag("varbindingvalue", 7L, true);
/*    */     }
/* 61 */     thisMbo.setModified(true);
/*    */   }
/*    */ }
