package com.ibm.ism.script.autoscript;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public abstract interface ScriptLaunchPointVarsSetRemote extends MboSetRemote
{
  public abstract void fillLaunchPointVars(MboRemote paramMboRemote)
    throws MXException, RemoteException;
}
