/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.ALNDomain;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 















































/*    */ public class FldLiteralDataType extends ALNDomain
/*    */ {
/*    */   public FldLiteralDataType(MboValue mbv)
/*    */   {
/* 60 */     super(mbv);
/* 61 */     setDomainId("MAXTYPE");
/* 62 */     setRelationship("ALNDOMAIN", "domainid = 'MAXTYPE' and value = :literaldatatype and value in ('ALN','INTEGER','SMALLINT','YORN','FLOAT','DECIMAL','DATETIME')");
/* 63 */     setListCriteria("domainid = 'MAXTYPE' and value in ('ALN','INTEGER','SMALLINT','YORN','FLOAT','DECIMAL','DATETIME')");
/*    */   }

/*    */   public void action() throws MXException, RemoteException
/*    */   {
/* 68 */     Mbo thisMbo = getMboValue().getMbo();
/* 69 */     thisMbo.setValueNull("varbindingvalue", 11L);
/*    */ 
/* 71 */     thisMbo.setValueNull("lpvarbindval", 11L);
/*    */ 
/* 73 */     thisMbo.setValueNull("attributevaluenp", 11L);
/*    */   }
/*    */ }
