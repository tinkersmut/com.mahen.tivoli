/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.BitFlag;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
























































/*     */ public class ScriptLaunchPoint extends Mbo
/*     */   implements ScriptLaunchPointRemote
/*     */ {
/*  73 */   private static Set<String> skipFieldCopy = new HashSet();
/*     */ 
/*     */   public ScriptLaunchPoint(MboSet ms)
/*     */     throws RemoteException
/*     */   {
/*  83 */     super(ms);
/*     */   }






/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  94 */     super.init();

/*     */     try
/*     */     {
/*  98 */       setFieldFlag("launchpointtype", 7L, true);
/*  99 */       setFieldFlag("objectname", 128L, true);
/* 100 */       if (!(toBeAdded()))
/*     */       {
/* 102 */         String[] readOnlyAfterSave = { "launchpointname", "objectname" };
/* 103 */         setFieldFlag(readOnlyAfterSave, 7L, true);
/* 104 */         String type = getString("launchpointtype");
/* 105 */         if (type.equalsIgnoreCase("ATTRIBUTE"))
/*     */         {
/* 107 */           setFieldFlag("attributename", 7L, false);
/* 108 */           setFieldFlag("attributename", 128L, true);
/*     */         }
/* 110 */         if (type.equalsIgnoreCase("OBJECT"))
/*     */         {
/* 112 */           setFieldFlag("attributename", 7L, true);
/* 113 */           setFieldFlag("attributename", 128L, false);
/* 114 */           setValue("init", isEventExist(getLong("objectevent"), 1L), 11L);
/* 115 */           setValue("add", isEventExist(getLong("objectevent"), 2L), 11L);
/* 116 */           setValue("update", isEventExist(getLong("objectevent"), 4L), 11L);
/* 117 */           setValue("delete", isEventExist(getLong("objectevent"), 8L), 11L);
/*     */         }
/* 119 */         if (type.equalsIgnoreCase("ACTION"))
/*     */         {
/* 121 */           setFieldFlag("attributename", 7L, true);
/* 122 */           setFieldFlag("attributename", 128L, false);
/* 123 */           setFieldFlag("objectname", 128L, false);
/* 124 */           MboSetRemote mboSet = MXServer.getMXServer().getMboSet("ACTION", getUserInfo());
/* 125 */           String paramValue = getString("autoscript") + "," + getString("launchpointname");
/* 126 */           mboSet.setWhere("value='com.ibm.tivoli.maximo.script.ScriptAction' and  parameter='" + paramValue + "'");
/* 127 */           MboRemote mbo = mboSet.getMbo(0);
/* 128 */           if (mbo != null)
/*     */           {
/* 130 */             setValue("actionname", mbo.getString("action"));
/* 131 */             setFieldFlag("actionname", 7L, true);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/* 138 */       getMboLogger().error(e.getMessage(), e);
/* 139 */       throw new MXApplicationException("script", "cannot_initialize_lnch_pnt");
/*     */     }
/* 141 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 143 */     getMboLogger().debug("Leaving ScriptLaunchPoint init");
/*     */   }
















/*     */   public void add()
/*     */     throws MXException, RemoteException
/*     */   {
/* 164 */     getMboLogger().debug("Entering AutoScript.add()");
/* 165 */     MboRemote owner = getOwner();
/* 166 */     if ((owner != null) && (owner.isBasedOn("AUTOSCRIPT")))
/*     */     {
/* 168 */       setValue("autoscript", owner.getString("autoscript"));
/*     */     }
/* 170 */     getMboLogger().debug("Leaving AutoScript.add()");
/*     */   }








/*     */   public void modify()
/*     */     throws MXException, RemoteException
/*     */   {
/* 183 */     if (getMboLogger().isDebugEnabled())
/*     */     {
/* 185 */       getMboLogger().debug("Entering ScriptLaunchPoint modify");
/*     */     }
/* 187 */     if (getOwner() != null)
/*     */     {
/* 189 */       ((Mbo)getOwner()).modify();
/*     */     }
/* 191 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 193 */     getMboLogger().debug("Leaving ScriptLaunchPoint modify");
/*     */   }









/*     */   public void delete(long accessModifier)
/*     */     throws MXException, RemoteException
/*     */   {
/* 207 */     super.delete(accessModifier);
/* 208 */     deleteAssociatedRecords();
/*     */   }






/*     */   private void deleteAssociatedRecords()
/*     */     throws MXException, RemoteException
/*     */   {
/* 219 */     getMboSet("LAUNCHPOINTVARS").deleteAll(2L);
/*     */   }





















/*     */   protected void loadSkipFieldCopyHashSet()
/*     */     throws MXException, RemoteException
/*     */   {
/* 245 */     skipFieldCopy.add("AUTOSCRIPT");
/* 246 */     skipFieldCopy.add("LAUNCHPOINTNAME");
/*     */   }










/*     */   protected boolean skipCopyField(MboValueInfo mvi)
/*     */     throws RemoteException, MXException
/*     */   {
/* 261 */     return (skipFieldCopy.contains(mvi.getName()));
/*     */   }


/*     */   protected void save()
/*     */     throws MXException, RemoteException
/*     */   {
/* 268 */     if ((!(isNull("actionname"))) && (toBeAdded()))
/*     */     {
/* 270 */       MboSet mboSet = (MboSet)getMboSet("$action", "ACTION", "action=:actionname");
/* 271 */       if (mboSet.count(16) == 0)
/*     */       {
/* 273 */         Mbo actionMbo = (Mbo)mboSet.add();
/* 274 */         actionMbo.setValue("action", getString("actionname"));
/* 275 */         actionMbo.setValue("description", getString("actiondesc"));
/* 276 */         Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
/*     */ 
/* 278 */         actionMbo.setValue("type", translate.toExternalDefaultValue("ACTIONTYPE", "CUSTOM", actionMbo));
/* 279 */         if (!(isNull("objectname")))
/*     */         {
/* 281 */           actionMbo.setValue("objectname", getString("objectname"));
/*     */         }
/*     */ 
/* 284 */         actionMbo.setValue("value", "com.ibm.tivoli.maximo.script.ScriptAction");
/* 285 */         actionMbo.setValue("parameter", getString("autoscript") + "," + getString("launchpointname") + "," + getString("actionname"));
/*     */       }
/*     */     }
/* 288 */     super.save();
/*     */   }








/*     */   private boolean isEventExist(long dbValue, long compValue)
/*     */     throws MXException, RemoteException
/*     */   {
/* 301 */     if ((!(isNull("objectevent"))) && (getLong("objectevent") > 0L))
/*     */     {
/* 303 */       BitFlag bitFlag = new BitFlag(dbValue);
/* 304 */       return bitFlag.isFlagSet(compValue);
/*     */     }
/* 306 */     return false;
/*     */   }






/*     */   public void appValidate()
/*     */     throws MXException, RemoteException
/*     */   {
/* 317 */     String type = getString("launchpointtype");
/* 318 */     if (type.equalsIgnoreCase("OBJECT"))
/*     */     {
/* 320 */       long flag = 0L;
/* 321 */       if (getBoolean("add"))
/*     */       {
/* 323 */         flag += 2L;
/*     */       }
/* 325 */       if (getBoolean("init"))
/*     */       {
/* 327 */         flag += 1L;
/*     */       }
/* 329 */       if (getBoolean("update"))
/*     */       {
/* 331 */         flag += 4L;
/*     */       }
/* 333 */       if (getBoolean("delete"))
/*     */       {
/* 335 */         flag += 8L;
/*     */       }
/* 337 */       setValue("objectevent", flag, 11L);
/*     */     }
/* 339 */     else if (getString("launchpointtype").equals("CUSTOMCONDITION"))
/*     */     {
/* 341 */       MboSetRemote autoSet = getMboSet("AUTOSCRIPT");
/* 342 */       MboRemote autoScriptMbo = autoSet.getMbo(0);
/* 343 */       if (autoScriptMbo != null)
/*     */       {
/* 345 */         MboSetRemote varsSet = autoScriptMbo.getMboSet("AUTOSCRIPTVARS");
/*     */ 
/* 347 */         MboRemote var = null;
/* 348 */         for (int i = 0; ; ++i)
/*     */         {
/* 350 */           var = varsSet.getMbo(i);
/* 351 */           if (var == null) {
/*     */             break;
/*     */           }
/*     */ 
/* 355 */           String varType = var.getString("vartype");
/* 356 */           if ((varType.equals("IN")) || (var.toBeDeleted()))
/*     */             continue;
/* 358 */           String[] params = { var.getString("varname") };
/* 359 */           throw new MXApplicationException("script", "onlyinallowed", params);

/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 367 */     super.appValidate();
/*     */   }
/*     */ }
