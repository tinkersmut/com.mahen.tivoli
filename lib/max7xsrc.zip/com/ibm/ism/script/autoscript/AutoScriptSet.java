/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import com.ibm.tivoli.maximo.script.ScriptCache;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.MXException;
/*    */ 


















/*    */ public class AutoScriptSet extends MboSet
/*    */   implements AutoScriptSetRemote
/*    */ {
/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 35 */     return new AutoScript(ms);
/*    */   }

/*    */   public AutoScriptSet(MboServerInterface ms) throws RemoteException {
/* 39 */     super(ms);
/*    */   }

/*    */   public void commit() throws MXException, RemoteException {
/* 43 */     super.commit();
/* 44 */     MXServer.getMXServer().reloadMaximoCache(ScriptCache.getInstance().getName(), true);
/*    */   }
/*    */ }
