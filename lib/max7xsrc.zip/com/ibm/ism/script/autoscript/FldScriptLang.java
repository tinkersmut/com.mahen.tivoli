/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.script.ScriptDriverFactory;
/*     */ import com.ibm.tivoli.maximo.script.ScriptEngineInfo;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboServerInterface;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 






















/*     */ public class FldScriptLang extends MAXTableDomain
/*     */ {
/*     */   public FldScriptLang(MboValue mbv)
/*     */   {
/*  44 */     super(mbv);
/*  45 */     setRelationship("SCRIPTENGINESNP", "");
/*  46 */     setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "engineshortname" });
/*     */   }






/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  57 */     if (getMboValue().isNull()) {
/*  58 */       return;
/*     */     }
/*  60 */     Map supportedEngines = ScriptDriverFactory.getInstance().getAllSupportedEngines();
/*     */ 
/*  62 */     if (!(supportedEngines.isEmpty()))











/*     */     {
/*  75 */       if (supportedEngines.containsKey(getMboValue().getString()))
/*     */         return;
/*  77 */       String[] params = { getMboValue().getString() };
/*  78 */       throw new MXApplicationException("script", "unsupported_scriptlang", params);


/*     */     }
/*     */ 
/*  83 */     throw new MXApplicationException("script", "noavailable_scriptlang");
/*     */   }





/*     */   public boolean hasList()
/*     */   {
/*  92 */     return true;
/*     */   }








/*     */   public MboSetRemote getList()
/*     */     throws MXException, RemoteException
/*     */   {
/* 105 */     MboServerInterface service = getMboValue().getMbo().getMboServer();
/* 106 */     MboSetRemote scrEngSet = service.getMboSet("SCRIPTENGINESNP", getMboValue().getMbo().getUserInfo());
/*     */ 
/* 108 */     Map supportedEngines = ScriptDriverFactory.getInstance().getAllSupportedEngines();
/* 109 */     if (supportedEngines.isEmpty())
/* 110 */       return scrEngSet;
/* 111 */     Iterator itr = supportedEngines.keySet().iterator();
/* 112 */     while (itr.hasNext())
/*     */     {
/* 114 */       ScriptEngineInfo seInfo = (ScriptEngineInfo)supportedEngines.get(itr.next());
/* 115 */       MboRemote seEngine = scrEngSet.add();
/* 116 */       seEngine.setValue("engineshortname", seInfo.getShortName());
/* 117 */       seEngine.setValue("enginename", seInfo.getEngineName());
/* 118 */       seEngine.setValue("engineversion", seInfo.getEngineVersion());
/* 119 */       seEngine.setValue("langname", seInfo.getLanguageName());
/* 120 */       seEngine.setValue("langversion", seInfo.getLanguageVersion());
/*     */     }
/*     */ 
/* 123 */     return scrEngSet;
/*     */   }
/*     */ }
