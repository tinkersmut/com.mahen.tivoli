package com.ibm.ism.script.autoscript;

import psdi.mbo.MboRemote;

public abstract interface AutoScriptStateRemote extends MboRemote
{
}
