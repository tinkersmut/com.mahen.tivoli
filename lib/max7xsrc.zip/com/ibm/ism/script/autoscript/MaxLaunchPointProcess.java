/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.iface.mic.StatefulMicSetIn;
/*    */ import psdi.iface.mic.StructureData;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ 



















































/*    */ public class MaxLaunchPointProcess extends StatefulMicSetIn
/*    */ {
/*    */   public void setAdditionalData(MboSetRemote mboSet, String tableName)
/*    */     throws MXException, RemoteException
/*    */   {
/* 66 */     if (!(tableName.equals("LAUNCHPOINTVARS")))
/*    */       return;
/* 68 */     if (this.mbo.toBeAdded())
/*    */     {
/* 70 */       this.mbo.setValue("overridden", true, 2L);


/*    */     }
/* 74 */     else if (!(this.struc.isCurrentDataNull("OVERRIDDEN")))
/*    */     {
/* 76 */       this.mbo.setValue("overridden", this.struc.getCurrentDataAsBoolean("OVERRIDDEN"), 2L);
/*    */     }
/*    */     else
/*    */     {
/* 80 */       this.mbo.setValue("overridden", true, 2L);
/*    */     }
/*    */   }
/*    */ }
