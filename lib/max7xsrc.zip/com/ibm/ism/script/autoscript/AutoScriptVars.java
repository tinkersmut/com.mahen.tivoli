/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSet;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.mbo.MboValueInfo;
/*     */ import psdi.txn.MXTransaction;
/*     */ import psdi.util.BitFlag;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 


































/*     */ public class AutoScriptVars extends Mbo
/*     */   implements MboRemote
/*     */ {
/*  50 */   protected static Set<String> skipFieldCopy = new HashSet();
/*     */ 
/*  57 */   protected static boolean isHashSetLoaded = false;
/*     */ 
/*     */   public AutoScriptVars(MboSet ms)
/*     */     throws RemoteException
/*     */   {
/*  62 */     super(ms);
/*     */   }



/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*  70 */     super.init();

/*     */     try
/*     */     {
/*  74 */       if (!(toBeAdded()))
/*     */       {
/*  76 */         String[] readOnlyAfterSave = { "autoscript", "varname", "varbindingtype", "literaldatatype", "allowoverride" };
/*  77 */         setFieldFlag(readOnlyAfterSave, 7L, true);
/*     */ 
/*  79 */         String maxvalue = getMboValue("varbindingtype").getString();
/*  80 */         boolean isLiteral = maxvalue.equalsIgnoreCase("LITERAL");
/*  81 */         if (isLiteral)
/*     */         {
/*  83 */           setFieldFlag("literaldatatype", 128L, true);
/*     */         }
/*     */         else
/*     */         {
/*  87 */           setFieldFlag("literaldatatype", 128L, false);
/*     */         }
/*  89 */         boolean isAttr = maxvalue.equalsIgnoreCase("ATTRIBUTE");
/*  90 */         if (isAttr)
/*     */         {
/*  92 */           setFieldFlag("varbindingvalue", 7L, true);
/*  93 */           setFieldFlag("varbindingvalue", 128L, false);

/*     */         }
/*     */         else
/*     */         {
/*  98 */           setFieldFlag("varbindingvalue", 7L, false);
/*  99 */           setFieldFlag("varbindingvalue", 128L, true);
/*     */         }
/*     */ 
/* 102 */         setValue("novalidation", isFlagExist(getLong("accessflag"), 1L), 11L);
/* 103 */         setValue("noaccesscheck", isFlagExist(getLong("accessflag"), 2L), 11L);
/* 104 */         setValue("noaction", isFlagExist(getLong("accessflag"), 8L), 11L);
/* 105 */         MboRemote owner = getOwner();
/* 106 */         if (!(owner.getName().equals("AUTOSCRIPT")))
/* 107 */           return;
/* 108 */         if (!(owner.getBoolean("userdefined")))
/*     */         {
/* 110 */           String[] readOnlySystemDefined = { "varbindingvalue", "vartype", "lpvarbindval", "noaccesscheck", "noaction", "novalidation", "accessflag" };
/* 111 */           setFieldFlag(readOnlySystemDefined, 7L, true);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 119 */       getMboLogger().error(e.getMessage(), e);
/* 120 */       throw new MXApplicationException("script", "cannot_initialize_vars");
/*     */     }
/* 122 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 124 */     getMboLogger().debug("Leaving AutoScriptVars init");
/*     */   }

/*     */   public void add()
/*     */     throws MXException, RemoteException
/*     */   {
/* 130 */     if (getMboLogger().isDebugEnabled())
/*     */     {
/* 132 */       getMboLogger().debug("Entering AutoScriptVars add()");
/*     */     }
/* 134 */     MboRemote owner = getOwner();
/* 135 */     if ((owner != null) && (owner.isBasedOn("AUTOSCRIPT")))
/*     */     {
/* 137 */       if ((!(owner.getBoolean("userdefined"))) && ((

/* 139 */         (getMXTransaction().getString("INTLEVEL") == null) || (!(getMXTransaction().getString("INTLEVEL").equals("1"))))))
/*     */       {
/* 141 */         throw new MXApplicationException("iface", "cannotadd_vars");
/*     */       }
/*     */ 
/* 144 */       setValue("autoscript", owner.getString("autoscript"));
/*     */     }
/* 146 */     setValue("vartype", "INOUT", 2L);
/* 147 */     setValue("varbindingtype", "ATTRIBUTE", 2L);
/*     */ 
/* 149 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 151 */     getMboLogger().debug("Leaving AutoScriptVars add()");
/*     */   }









/*     */   public void modify()
/*     */     throws MXException, RemoteException
/*     */   {
/* 165 */     if (getMboLogger().isDebugEnabled())
/*     */     {
/* 167 */       getMboLogger().debug("Entering AutoScriptVars modify");
/*     */     }
/* 169 */     if (getOwner() != null)
/*     */     {
/* 171 */       ((Mbo)getOwner()).modify();
/*     */     }
/* 173 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 175 */     getMboLogger().debug("Leaving AutoScriptVars modify");
/*     */   }




/*     */   public void delete(long accessModifier)
/*     */     throws MXException, RemoteException
/*     */   {
/* 184 */     canDelete();

/*     */ 
/* 187 */     super.delete(accessModifier);
/*     */   }







/*     */   public void canDelete()
/*     */     throws MXException, RemoteException
/*     */   {
/* 199 */     if (getMboLogger().isDebugEnabled())
/*     */     {
/* 201 */       getMboLogger().debug("Entering AutoScriptVars canDelete");
/*     */     }
/* 203 */     MboRemote autoScriptMbo = getOwner();
/* 204 */     if ((autoScriptMbo != null) && (!(autoScriptMbo.toBeDeleted())))
/*     */     {
/* 206 */       MboSetRemote lpSet = autoScriptMbo.getMboSet("SCRIPTLAUNCHPOINT");
/* 207 */       MboRemote lpMbo = lpSet.getMbo(0);
/* 208 */       if (lpMbo != null)
/*     */       {
/* 210 */         String[] params = { getString("varname") };
/* 211 */         throw new MXApplicationException("script", "cannotdeletereflp", params);
/*     */       }
/*     */     }
/*     */ 
/* 215 */     if ((getOwner() != null) && (getOwner().getName().equals("AUTOSCRIPT")) && (!(getOwner().getBoolean("userdefined"))) && ((


/* 218 */       (getMXTransaction().getString("INTLEVEL") == null) || (!(getMXTransaction().getString("INTLEVEL").equals("1"))))))
/*     */     {
/* 220 */       throw new MXApplicationException("iface", "cannotdelete_vars");
/*     */     }
/*     */ 
/* 223 */     if (!(getMboLogger().isDebugEnabled()))
/*     */       return;
/* 225 */     getMboLogger().debug("Leaving AutoScriptVars canDelete");
/*     */   }








































/*     */   protected void loadSkipFieldCopyHashSet()
/*     */     throws MXException, RemoteException
/*     */   {
/* 270 */     isHashSetLoaded = true;
/* 271 */     skipFieldCopy.add("AUTOSCRIPT");
/* 272 */     skipFieldCopy.add("VARNAME");
/*     */   }










/*     */   protected boolean skipCopyField(MboValueInfo mvi)
/*     */     throws RemoteException, MXException
/*     */   {
/* 287 */     return (skipFieldCopy.contains(mvi.getName()));
/*     */   }

/*     */   public boolean isFlagExist(long dbValue, long compValue)
/*     */     throws MXException, RemoteException
/*     */   {
/* 293 */     if ((!(isNull("accessflag"))) && (getLong("accessflag") > 0L))
/*     */     {
/* 295 */       BitFlag bitFlag = new BitFlag(dbValue);
/* 296 */       return bitFlag.isFlagSet(compValue);
/*     */     }
/* 298 */     return false;
/*     */   }







/*     */   public void appValidate()
/*     */     throws MXException, RemoteException
/*     */   {
/* 310 */     if ((isNull("autoscript")) && (getOwner() != null) && (getOwner().isBasedOn("AUTOSCRIPT")))
/*     */     {
/* 312 */       setValue("autoscript", getOwner().getString("autoscript"));
/*     */     }
/* 314 */     long flag = 0L;
/* 315 */     if (getBoolean("novalidation"))
/*     */     {
/* 317 */       flag += 1L;
/*     */     }
/* 319 */     if (getBoolean("noaccesscheck"))
/*     */     {
/* 321 */       flag += 2L;
/*     */     }
/* 323 */     if (getBoolean("noaction"))
/*     */     {
/* 325 */       flag += 8L;
/*     */     }
/* 327 */     setValue("accessflag", flag, 11L);
/*     */ 
/* 329 */     super.appValidate();
/*     */   }
/*     */ }
