/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 
































/*    */ public class FldLaunchPointName extends MboValueAdapter
/*    */ {
/*    */   public FldLaunchPointName(MboValue mbv)
/*    */   {
/* 46 */     super(mbv);
/*    */   }






/*    */   public void action()
/*    */     throws MXException, RemoteException
/*    */   {
/* 57 */     MboRemote mbo = getMboValue().getMbo();
/* 58 */     MboSetRemote lnchVarSet = mbo.getMboSet("LAUNCHPOINTVARS");
/* 59 */     if (getMboValue().isNull())
/*    */     {
/* 61 */       if (!(lnchVarSet.isEmpty()))
/*    */       {
/* 63 */         lnchVarSet.deleteAndRemoveAll();
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 68 */       lnchVarSet.setWhere("1=2");
/* 69 */       lnchVarSet.reset();
/* 70 */       MboRemote owner = mbo.getOwner();
/* 71 */       if ((owner != null) && (owner.isBasedOn("AUTOSCRIPT")))
/*    */       {
/* 73 */         ((ScriptLaunchPointVarsSet)lnchVarSet).fillLaunchPointVars(owner);
/*    */       }
/*    */     }
/*    */ 
/* 77 */     if ((mbo.isNull("launchpointtype")) || (!(mbo.isNull("actionname"))) || (!(mbo.getString("launchpointtype").equals("ACTION")))) {
/*    */       return;
/*    */     }
/* 80 */     mbo.setValue("actionname", getMboValue().getString());
/*    */   }
/*    */ }
