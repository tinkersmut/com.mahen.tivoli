/*     */ package com.ibm.ism.script.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.iface.mos.ConversionUtil;
/*     */ import psdi.mbo.MAXTableDomain;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.MboValue;
/*     */ import psdi.util.MXException;
/*     */ 
























/*     */ public class FldVarBindValue extends MAXTableDomain
/*     */ {
/*     */   public FldVarBindValue(MboValue mbv)
/*     */     throws MXException
/*     */   {
/*  40 */     super(mbv);
/*     */   }








/*     */   public MboSetRemote getList()
/*     */     throws MXException, RemoteException
/*     */   {
/*  53 */     Mbo thisMbo = getMboValue().getMbo();
/*  54 */     if (!(thisMbo.isNull("varbindingtype")))
/*     */     {
/*  56 */       setBindRelationship();
/*  57 */       return super.getList();
/*     */     }
/*  59 */     return null;
/*     */   }







/*     */   public void validate()
/*     */     throws MXException, RemoteException
/*     */   {
/*  71 */     String bindType = getVarBindType();
/*  72 */     if ((getMboValue().isNull()) || (bindType == null) || (bindType.equals("")))
/*     */       return;
/*  74 */     String data = getMboValue().getString();
/*  75 */     if (!(bindType.equalsIgnoreCase("LITERAL")))
/*     */       return;
/*  77 */     Mbo thismbo = getMboValue().getMbo();
/*  78 */     if (!(thismbo.isNull("literaldatatype")))
/*     */     {
/*  80 */       String ltrlDtType = thismbo.getString("literaldatatype");
/*  81 */       if (ltrlDtType.equalsIgnoreCase("DATETIME"))
/*     */       {
/*  83 */         ConversionUtil.stringToDate(data);
/*     */       }
/*  85 */       else if ((ltrlDtType.equalsIgnoreCase("DECIMAL")) || (ltrlDtType.equalsIgnoreCase("FLOAT")))

/*     */       {
/*  88 */         ConversionUtil.stringToDouble(data);
/*     */       }
/*  90 */       else if (ltrlDtType.equalsIgnoreCase("INTEGER"))
/*     */       {
/*  92 */         ConversionUtil.stringToLong(data);
/*     */       }
/*  94 */       else if (ltrlDtType.equalsIgnoreCase("SMALLINT"))
/*     */       {
/*  96 */         ConversionUtil.stringToInt(data);
/*     */       }
/*  98 */       else if (ltrlDtType.equalsIgnoreCase("YORN"))
/*     */       {
/* 100 */         ConversionUtil.stringToBoolean(data);
/*     */       }
/*     */     }
/* 103 */     return;
/*     */   }




/*     */   private void setBindRelationship()
/*     */     throws MXException, RemoteException
/*     */   {
/* 112 */     String bindType = getVarBindType();
/* 113 */     if ((bindType == null) || (bindType.equals("")))
/*     */       return;
/* 115 */     if (bindType.equalsIgnoreCase("SYSPROP"))
/*     */     {
/* 117 */       setRelationship("MAXPROP", "propname=:" + getMboValue().getName());
/* 118 */       setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "propname" });
/*     */ 
/* 120 */       setErrorMessage("propmaint", "invalidpropname");
/*     */     }
/* 122 */     if (bindType.equalsIgnoreCase("MAXVAR"))
/*     */     {
/* 124 */       setRelationship("MAXVARTYPE", "varname=:" + getMboValue().getName());
/* 125 */       setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "varname" });
/*     */ 
/* 127 */       setErrorMessage("propmaint", "invalidpropname");
/*     */     }
/* 129 */     if (!(bindType.equalsIgnoreCase("ATTRIBUTE")))
/*     */       return;
/* 131 */     setRelationship("MAXATTRIBUTE", "attributename=:" + getMboValue().getName());
/* 132 */     setLookupKeyMapInOrder(new String[] { getMboValue().getName() }, new String[] { "attributename" });
/*     */ 
/* 134 */     setErrorMessage("propmaint", "invalidpropname");
/*     */   }








/*     */   private String getVarBindType()
/*     */     throws MXException, RemoteException
/*     */   {
/* 147 */     return getMboValue().getMbo().getString("varbindingtype");
/*     */   }






/*     */   public MboSetRemote smartFill(String value, boolean exact)
/*     */     throws MXException, RemoteException
/*     */   {
/* 158 */     Mbo thisMbo = getMboValue().getMbo();
/* 159 */     if (!(thisMbo.isNull("varbindingtype")))
/*     */     {
/* 161 */       setBindRelationship();
/* 162 */       return super.smartFill(value, exact);

/*     */     }
/*     */ 
/* 166 */     return null;
/*     */   }







/*     */   public String getLookupName()
/*     */     throws MXException, RemoteException
/*     */   {
/* 178 */     String bindType = getVarBindType();
/* 179 */     if ((bindType != null) && (!(bindType.equals(""))))
/*     */     {
/* 181 */       if (bindType.equalsIgnoreCase("SYSPROP"))
/*     */       {
/* 183 */         return "maxprop";
/*     */       }
/* 185 */       if (bindType.equalsIgnoreCase("MAXVAR"))
/*     */       {
/* 187 */         return "maxvartype";
/*     */       }
/*     */     }
/* 190 */     return "";
/*     */   }
/*     */ }
