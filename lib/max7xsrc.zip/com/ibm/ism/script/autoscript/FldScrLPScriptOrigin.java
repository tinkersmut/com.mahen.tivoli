/*    */ package com.ibm.ism.script.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.mbo.MboValueAdapter;
/*    */ import psdi.util.MXException;
/*    */ 

















/*    */ public class FldScrLPScriptOrigin extends MboValueAdapter
/*    */ {
/*    */   public FldScrLPScriptOrigin(MboValue mbv)
/*    */   {
/* 30 */     super(mbv);
/*    */   }






/*    */   public void initValue()
/*    */     throws MXException, RemoteException
/*    */   {
/* 41 */     super.initValue();
/* 42 */     MboValue value = getMboValue();
/* 43 */     MboRemote lpMbo = value.getMbo();
/* 44 */     value.setValue("NEW", 11L);
/* 45 */     lpMbo.setFieldFlag("autoscriptnp", 7L, true);
/*    */   }

/*    */   public void action() throws MXException, RemoteException
/*    */   {
/* 50 */     MboValue value = getMboValue();
/* 51 */     MboRemote thisMbo = value.getMbo();
/*    */ 
/* 53 */     if (value.getString().equals("NEW"))
/*    */     {
/* 55 */       thisMbo.setValueNull("autoscriptnp", 2L);
/* 56 */       thisMbo.setFieldFlag("autoscriptnp", 7L, true);
/* 57 */       thisMbo.setFieldFlag("autoscriptnp", 128L, false);
/*    */     }
/*    */     else
/*    */     {
/* 61 */       thisMbo.setValueNull("autoscriptnp", 2L);
/* 62 */       thisMbo.setFieldFlag("autoscriptnp", 7L, false);
/* 63 */       thisMbo.setFieldFlag("autoscriptnp", 128L, true);
/*    */     }
/*    */   }
/*    */ }
