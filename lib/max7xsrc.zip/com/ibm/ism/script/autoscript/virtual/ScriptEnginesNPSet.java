/*    */ package com.ibm.ism.script.autoscript.virtual;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.NonPersistentMboSet;
/*    */ import psdi.util.MXException;
/*    */ 




















/*    */ public class ScriptEnginesNPSet extends NonPersistentMboSet
/*    */ {
/*    */   public ScriptEnginesNPSet(MboServerInterface ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 35 */     super(ms);
/*    */   }





/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 45 */     return new ScriptEnginesNPMbo(ms);
/*    */   }
/*    */ }
