/*    */ package com.ibm.ism.script.autoscript.virtual;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.NonPersistentMbo;
/*    */ import psdi.mbo.NonPersistentMboRemote;
/*    */ import psdi.util.MXException;
/*    */ 


























/*    */ public class AutoScriptChangeState extends NonPersistentMbo
/*    */   implements NonPersistentMboRemote
/*    */ {
/*    */   public AutoScriptChangeState(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 41 */     super(ms);
/*    */   }



/*    */   public void add()
/*    */     throws MXException, RemoteException
/*    */   {
/* 49 */     super.add();
/*    */   }
/*    */ }
