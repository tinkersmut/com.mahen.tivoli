/*    */ package com.ibm.ism.script.autoscript.virtual;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.app.common.virtual.ChangeStatusSet;
/*    */ import psdi.mbo.Mbo;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboServerInterface;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.mbo.NonPersistentMboSetRemote;
/*    */ import psdi.mbo.SqlFormat;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.logging.MXLogger;
/*    */ import psdi.util.logging.MXLoggerFactory;
/*    */ 




























/*    */ public class AutoScriptChangeStateSet extends ChangeStatusSet
/*    */   implements NonPersistentMboSetRemote
/*    */ {
/* 42 */   private static final Class CLASS = AutoScriptChangeStateSet.class;
/*    */ 
/*    */   public AutoScriptChangeStateSet(MboServerInterface ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 52 */     super(ms);
/*    */   }





/*    */   protected Mbo getMboInstance(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 62 */     return new AutoScriptChangeState(ms);
/*    */   }



/*    */   protected MboSetRemote getMboIntoSet(MboRemote mbo)
/*    */     throws MXException, RemoteException
/*    */   {
/* 70 */     MXLogger myLogger = MXLoggerFactory.getLogger("maximo.application.AUTOSCRIPT");
/* 71 */     myLogger.debug("Entered " + CLASS + ".getMboIntoSet()");
/*    */ 
/* 73 */     MboSetRemote changeAutoScriptSet = getMboServer().getMboSet("AUTOSCRIPT", getUserInfo());

/*    */ 
/* 76 */     SqlFormat sqf = new SqlFormat(mbo, "AUTOSCRIPT = :AUTOSCRIPT");
/* 77 */     changeAutoScriptSet.setWhere(sqf.format());
/* 78 */     return changeAutoScriptSet;
/*    */   }
/*    */ }
