/*    */ package com.ibm.ism.script.autoscript.virtual;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboSet;
/*    */ import psdi.mbo.NonPersistentMbo;
/*    */ import psdi.util.MXException;
/*    */ 






















/*    */ public class ScriptEnginesNPMbo extends NonPersistentMbo
/*    */ {
/*    */   public ScriptEnginesNPMbo(MboSet ms)
/*    */     throws MXException, RemoteException
/*    */   {
/* 35 */     super(ms);
/*    */   }
/*    */ }
