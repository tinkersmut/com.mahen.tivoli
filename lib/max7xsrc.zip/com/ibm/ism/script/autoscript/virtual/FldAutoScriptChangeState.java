/*    */ package com.ibm.ism.script.autoscript.virtual;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.app.common.FldChangeStatus;
/*    */ import psdi.mbo.MboValue;
/*    */ import psdi.util.MXException;
/*    */ 


























/*    */ public class FldAutoScriptChangeState extends FldChangeStatus
/*    */ {
/*    */   public FldAutoScriptChangeState(MboValue mbv)
/*    */     throws RemoteException, MXException
/*    */   {
/* 39 */     super(mbv);
/*    */   }
/*    */ }
