/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ 






















/*    */ public class ScriptConditionalBean extends DataBean
/*    */ {
/*    */   public boolean hasSigOptionAccess(int row, String sigOption)
/*    */     throws RemoteException, MXException
/*    */   {
/* 35 */     if (sigOption != null)
/*    */     {
/* 37 */       MboRemote mbo = getMbo(row);
/* 38 */       if ((sigOption.equalsIgnoreCase("HIDEBUT")) || (sigOption.equalsIgnoreCase("HIDEDEL")) || (sigOption.equalsIgnoreCase("HIDEIMP")))



/*    */       {
/* 43 */         return ((mbo == null) || (mbo.toBeAdded()));


/*    */       }
/*    */ 
/* 48 */       return super.hasSigOptionAccess(row, sigOption);
/*    */     }
/* 50 */     return false;
/*    */   }
/*    */ }
