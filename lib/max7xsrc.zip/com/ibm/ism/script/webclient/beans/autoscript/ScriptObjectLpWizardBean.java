/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 























/*    */ public class ScriptObjectLpWizardBean extends ScriptWizardBean
/*    */ {
/* 33 */   private static String[] allTabs = { "create_lp_object", "script_gen_object", "create_lp_vars_object" };
/*    */ 
/*    */   public void initialize()
/*    */     throws MXException, RemoteException
/*    */   {
/* 38 */     super.initialize();
/* 39 */     insert();
/* 40 */     fireStructureChangedEvent();
/*    */   }


/*    */   protected String[] getAllTabs()
/*    */   {
/* 46 */     return allTabs;
/*    */   }

/*    */   protected void validateMoveTab(int currentTabOrder) throws MXException, RemoteException
/*    */   {
/* 51 */     super.validateMoveTab(currentTabOrder);
/* 52 */     if (currentTabOrder != 0)
/*    */       return;
/* 54 */     if ((!(getMbo().getBoolean("add"))) && (!(getMbo().getBoolean("delete"))) && (!(getMbo().getBoolean("init"))) && (!(getMbo().getBoolean("update"))))

/*    */     {
/* 57 */       String[] params = { getMbo().getString("launchpointname") };
/* 58 */       throw new MXApplicationException("script", "missinglpevent", params);
/*    */     }
/* 60 */     if (!(getMbo().isNull("objectname")))
/*    */       return;
/* 62 */     String[] params = { getMbo().getString("launchpointname") };
/* 63 */     throw new MXApplicationException("script", "missinglpobjname", params);
/*    */   }




/*    */   protected void setDefaultValues(MboRemote wizMbo)
/*    */     throws MXException, RemoteException
/*    */   {
/* 72 */     setValue("launchpointtype", "OBJECT", 2L);
/*    */   }



/*    */   protected String getTabGroupName()
/*    */   {
/* 79 */     return "generate_tabs1";
/*    */   }
/*    */ }
