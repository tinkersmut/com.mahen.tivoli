/*     */ package com.ibm.ism.script.webclient.beans.autoscript;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Hashtable;
/*     */ import psdi.common.expbuilder.ExpressionBuilderFormat;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.webclient.beans.common.SQLExpressionBuilderBean;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.ControlInstance;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 















/*     */ public class ScrSQLExpressionBldrBean extends SQLExpressionBuilderBean
/*     */ {
/*     */   private static final String validateExp = "validateExpression";
/*     */ 
/*     */   protected void initialize()
/*     */     throws MXException, RemoteException
/*     */   {
/*  44 */     super.initialize();
/*     */   }







/*     */   public void expressionbuildereventinvalue()
/*     */     throws Throwable
/*     */   {
/*  56 */     WebClientEvent event = getCreator().getWebClientSession().getCurrentEvent();
/*     */ 
/*  58 */     String curevent = event.getValueString();
/*  59 */     if (curevent.equalsIgnoreCase("validateExpression"))
/*     */     {
/*  61 */       validateExp();
/*  62 */       return;
/*     */     }
/*  64 */     super.expressionbuildereventinvalue();
/*     */   }

/*     */   public void validateExp() throws RemoteException, MXException, SQLException
/*     */   {
/*  69 */     WebClientEvent event = getCreator().getWebClientSession().getCurrentEvent();
/*  70 */     String expression = getString("USERSQL");
/*  71 */     if (getBoolean("iscustomclass"))
/*     */     {
/*  73 */       validateCustomClass(expression);
/*  74 */       return;
/*     */     }
/*  76 */     String objName = "";
/*  77 */     objName = this.parent.getMbo().getString("objectname");
/*  78 */     if ((objName == null) || (objName.equals(""))) {
/*  79 */       throw new MXApplicationException("expbuilder", "TextExpNeedObjectName");
/*     */     }
/*  81 */     Mbo mr = (Mbo)MXServer.getMXServer().getMboSet(objName, getMbo().getUserInfo()).getZombie();
/*     */ 
/*  83 */     ExpressionBuilderFormat ebf = new ExpressionBuilderFormat(mr, objName);
/*  84 */     ebf.validate(expression);
/*  85 */     String[] parms = { "" };
/*  86 */     if (event.getValueString().equalsIgnoreCase("validateExpression"))
/*     */     {
/*  88 */       this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "escalation", "validationsuccess", parms);
/*     */     }
/*     */ 
/*  91 */     initialize();
/*  92 */     fireChildChangedEvent();
/*     */   }

/*     */   public void validateCustomClass(String customClass)
/*     */     throws MXSystemException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 100 */       Class actionCusCl = Class.forName("psdi.common.action.ActionCustomClass");
/* 101 */       if (!(actionCusCl.isAssignableFrom(Class.forName(customClass))))
/*     */       {
/* 103 */         Object[] params = { customClass };
/* 104 */         throw new MXSystemException("expbuilder", "badcustomclass", params);
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 109 */       Object[] params = { e.getMessage() };
/* 110 */       throw new MXSystemException("expbuilder", "invalidcustomclass", params);
/*     */     }
/*     */   }

/*     */   protected int selectCalendar(WebClientEvent event) throws MXException, RemoteException
/*     */   {
/* 116 */     Hashtable pinfo = new Hashtable();
/* 117 */     pinfo.put("c_attribute", "usersql");
/* 118 */     pinfo.put("c_datatype", "DATE_TIME");
/* 119 */     String beanid = this.clientSession.getCurrentEventHandler().getProperty("datasrc");
/* 120 */     pinfo.put("c_datasrc", beanid);
/* 121 */     WebClientRuntime.sendEvent(new WebClientEvent("datetimepopup", this.app.getCurrentPageId(), pinfo, this.clientSession));
/* 122 */     return 1;
/*     */   }
/*     */ }
