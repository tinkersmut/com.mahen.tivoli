/*     */ package com.ibm.ism.script.webclient.beans.autoscript;
/*     */ 
/*     */ import com.ibm.ism.script.autoscript.ScriptAttributeTreeSet;
/*     */ import com.ibm.ism.script.autoscript.ScriptAttributeTreeSetRemote;
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.iface.mic.MicUtil;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.webclient.beans.common.TreeControlBean;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 

















/*     */ public class AttributeTreeBean extends TreeControlBean
/*     */ {
/*  37 */   private static final MXLogger integrationLogger = MicUtil.INTEGRATIONLOGGER;
/*     */ 
/*     */   public void initialize() throws MXException, RemoteException
/*     */   {
/*  41 */     super.initialize();
/*  42 */     ScriptAttributeTreeSet attrTreeSet = (ScriptAttributeTreeSet)getMboSet();
/*  43 */     attrTreeSet.clear();
/*  44 */     MboRemote prntMbo = this.parent.getMbo();
/*  45 */     String name = prntMbo.getName();

/*     */ 
/*  48 */     if ((name.equalsIgnoreCase("AUTOSCRIPTVARS")) && 

/*  50 */       (prntMbo.getOwner() != null) && 

/*  52 */       (prntMbo.getOwner().getOwner() != null))
/*     */     {
/*  54 */       this.objectname = prntMbo.getOwner().getOwner().getString("objectname");

/*     */     }
/*     */ 
/*  58 */     if ((name.equalsIgnoreCase("LAUNCHPOINTVARS")) && 

/*  60 */       (prntMbo.getOwner() != null))
/*     */     {
/*  62 */       this.objectname = prntMbo.getOwner().getString("objectname");

/*     */     }
/*     */ 
/*  66 */     attrTreeSet.fill(this.objectname, null, null, true, 1);
/*     */   }






/*     */   public int selectnode() throws MXException, RemoteException
/*     */   {
/*  76 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/*     */     try
/*     */     {
/*  79 */       String uniqueIdSelected = this.clientSession.getCurrentEvent().getValueString();
/*  80 */       if (integrationLogger.isDebugEnabled())
/*     */       {
/*  82 */         integrationLogger.debug("Selected Unique id  " + uniqueIdSelected);
/*  83 */         integrationLogger.debug("Mbo is " + getMboSet().getMbo(0).getName());
/*     */       }
/*  85 */       MboRemote attrTree = ((ScriptAttributeTreeSetRemote)getMboSet()).findMbo(getMboSet().getMbo(0), uniqueIdSelected);
/*  86 */       String fullObjectName = null;
/*  87 */       fullObjectName = attrTree.getString("elementpath");
/*  88 */       if (integrationLogger.isDebugEnabled())
/*     */       {
/*  90 */         integrationLogger.debug("elementpath:" + fullObjectName);
/*     */       }
/*  92 */       int objTop = fullObjectName.indexOf(".");
/*  93 */       if (objTop > -1)
/*     */       {
/*  95 */         fullObjectName = fullObjectName.substring(objTop + 1, fullObjectName.length());
/*     */       }
/*  97 */       if (integrationLogger.isDebugEnabled())
/*     */       {
/*  99 */         integrationLogger.debug("Attribute value:" + fullObjectName);
/*     */       }
/* 101 */       MboRemote prntMbo = this.parent.getMbo();
/* 102 */       String name = prntMbo.getName();
/* 103 */       if (name.equalsIgnoreCase("AUTOSCRIPTVARS"))
/*     */       {
/* 105 */         prntMbo.setValue("lpvarbindval", fullObjectName);
/* 106 */         prntMbo.setValue("attributevaluenp", fullObjectName);
/*     */       }
/* 108 */       if (name.equalsIgnoreCase("LAUNCHPOINTVARS"))
/*     */       {
/* 110 */         prntMbo.setValue("varbindingvalue", fullObjectName);
/* 111 */         prntMbo.setValue("lpattributevaluenp", fullObjectName);
/*     */       }
/*     */     }
/*     */     catch (MXException e)
/*     */     {
/* 116 */       WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/* 117 */       this.clientSession.showMessageBox(event, e);
/*     */     }
/*     */     catch (RemoteException m)
/*     */     {
/* 121 */       WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/* 122 */       this.clientSession.showMessageBox(event, m);
/*     */     }
/* 124 */     WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/* 125 */     this.parent.fireDataChangedEvent();
/* 126 */     this.parent.fireStructureChangedEvent();
/* 127 */     return 1;
/*     */   }

/*     */   public synchronized void structureChangedEvent(DataBean speaker)
/*     */   {
/* 132 */     super.structureChangedEvent(speaker);
/* 133 */     setRefreshTree(true);
/*     */   }
/*     */ }
