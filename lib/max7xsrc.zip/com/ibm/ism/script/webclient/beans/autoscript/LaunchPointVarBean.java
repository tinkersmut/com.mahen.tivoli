/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import com.ibm.ism.script.autoscript.ScriptLaunchPointVarsSetRemote;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.MXSession;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.controller.ControlInstance;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 





















/*    */ public class LaunchPointVarBean extends DataBean
/*    */ {
/*    */   protected MboSetRemote getMboSetRemote(String id)
/*    */     throws MXException, RemoteException
/*    */   {
/* 40 */     MXSession s = getMXSession();
/* 41 */     DataBean lnchPointBean = this.clientSession.getDataBean(id);
/* 42 */     ControlInstance originalControl = this.creatingEvent.getSourceControlInstance();
/* 43 */     DataBean originalBean = this.clientSession.getDataBean(originalControl.getProperty("datasrc"));
/*    */ 
/* 45 */     MboRemote mm = originalBean.getParent().getMbo();
/* 46 */     if (s == null)
/*    */     {
/* 48 */       return null;
/*    */     }
/* 50 */     ScriptLaunchPointVarsSetRemote reg = (ScriptLaunchPointVarsSetRemote)lnchPointBean.getMbo().getMboSet("LAUNCHPOINTVARS");
/* 51 */     reg.fillLaunchPointVars(mm);
/*    */ 
/* 53 */     return reg;
/*    */   }
/*    */ }
