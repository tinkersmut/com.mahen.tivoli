/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ 






















/*    */ public class LaunchPointObjectVarBean extends LaunchPointVarBean
/*    */ {
/*    */   protected MboSetRemote getMboSetRemote()
/*    */     throws MXException, RemoteException
/*    */   {
/* 34 */     return getMboSetRemote("objectdetail");
/*    */   }
/*    */ }
