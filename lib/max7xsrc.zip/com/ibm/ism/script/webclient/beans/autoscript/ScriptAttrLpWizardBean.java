/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 























/*    */ public class ScriptAttrLpWizardBean extends ScriptWizardBean
/*    */ {
/* 33 */   private static String[] allTabs = { "create_lp_attr", "script_gen_attr", "create_lp_vars_attr" };
/*    */ 
/*    */   public void initialize()
/*    */     throws MXException, RemoteException
/*    */   {
/* 38 */     super.initialize();
/* 39 */     insert();
/* 40 */     fireStructureChangedEvent();
/*    */   }


/*    */   protected String[] getAllTabs()
/*    */   {
/* 46 */     return allTabs;
/*    */   }

/*    */   protected void validateMoveTab(int currentTabOrder) throws MXException, RemoteException
/*    */   {
/* 51 */     super.validateMoveTab(currentTabOrder);
/* 52 */     if (currentTabOrder != 0) {
/*    */       return;
/*    */     }
/* 55 */     if (getMbo().isNull("attributename"))
/*    */     {
/* 57 */       String[] params = { getMbo().getString("launchpointname") };
/* 58 */       throw new MXApplicationException("script", "missinglpattrname", params);
/*    */     }
/* 60 */     if (!(getMbo().isNull("objectname")))
/*    */       return;
/* 62 */     String[] params = { getMbo().getString("launchpointname") };
/* 63 */     throw new MXApplicationException("script", "missinglpobjname", params);
/*    */   }




/*    */   protected void setDefaultValues(MboRemote wizMbo)
/*    */     throws MXException, RemoteException
/*    */   {
/* 72 */     setValue("launchpointtype", "ATTRIBUTE", 2L);
/*    */   }




/*    */   protected String getTabGroupName()
/*    */   {
/* 80 */     return "generate_tabs2";
/*    */   }
/*    */ }
