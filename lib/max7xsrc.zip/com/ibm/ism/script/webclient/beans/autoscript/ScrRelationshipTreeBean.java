/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.beans.common.RelationshipTreeBean;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ 











































/*    */ public class ScrRelationshipTreeBean extends RelationshipTreeBean
/*    */ {
/*    */   public String getTreeControlObjectName()
/*    */     throws RemoteException, MXException
/*    */   {
/* 58 */     if ((this.mboSetRemote.getOwner() != null) && (this.mboSetRemote.getOwner().getOwner() != null))
/*    */     {
/* 60 */       return this.mboSetRemote.getOwner().getOwner().getString("OBJECTNAME");
/*    */     }
/* 62 */     return this.mboSetRemote.getOwner().getOwner().getName();
/*    */   }




/*    */   public void dataChangedEvent(DataBean speaker)
/*    */   {
/* 70 */     super.dataChangedEvent(speaker);
/*    */     try
/*    */     {
/* 73 */       reset();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 77 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }
