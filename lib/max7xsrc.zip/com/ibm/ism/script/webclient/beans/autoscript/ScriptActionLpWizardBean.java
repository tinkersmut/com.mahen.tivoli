/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 


























/*    */ public class ScriptActionLpWizardBean extends ScriptWizardBean
/*    */ {
/* 35 */   private static String[] allTabs = { "wcreate_lp_action", "wcreate_lp_vars_action", "wscript_gen_action" };
/*    */ 
/*    */   public void initialize()
/*    */     throws MXException, RemoteException
/*    */   {
/* 41 */     super.initialize();
/* 42 */     insert();
/* 43 */     fireStructureChangedEvent();
/*    */   }

/*    */   protected String[] getAllTabs()
/*    */   {
/* 48 */     return allTabs;
/*    */   }

/*    */   protected void validateMoveTab(int currentTabOrder) throws MXException, RemoteException
/*    */   {
/* 53 */     super.validateMoveTab(currentTabOrder);
/*    */ 
/* 55 */     if ((currentTabOrder != 0) || 

/* 57 */       (!(getMbo().isNull("actionname"))))
/*    */       return;
/* 59 */     throw new MXApplicationException("script", "missingactname");
/*    */   }


/*    */   protected void setDefaultValues(MboRemote wizMbo)
/*    */     throws MXException, RemoteException
/*    */   {
/* 66 */     setValue("launchpointtype", "ACTION", 2L);
/*    */   }


/*    */   protected String getTabGroupName()
/*    */   {
/* 72 */     return "wgenerate_tabs_action_2";
/*    */   }
/*    */ }
