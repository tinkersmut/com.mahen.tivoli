/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.AppBean;
/*    */ import psdi.webclient.system.beans.ResultsBean;
/*    */ import psdi.webclient.system.controller.AppInstance;
/*    */ import psdi.webclient.system.controller.UploadFile;
/*    */ import psdi.webclient.system.controller.WebClientEvent;
/*    */ import psdi.webclient.system.runtime.WebClientRuntime;
/*    */ import psdi.webclient.system.session.WebClientSession;
/*    */ 












/*    */ public class CreateScriptDialogBean extends AppBean
/*    */ {
/*    */   protected void initialize()
/*    */     throws RemoteException, MXException
/*    */   {
/* 33 */     super.initialize();
/* 34 */     insert();
/* 35 */     fireDataChangedEvent();
/*    */   }







/*    */   public int loadData()
/*    */     throws MXException, RemoteException
/*    */   {
/* 47 */     UploadFile file = (UploadFile)this.app.get("importfile");
/*    */ 
/* 49 */     if (file == null) {
/* 50 */       throw new MXApplicationException("designer", "noimportfile");
/*    */     }
/* 52 */     MboRemote autoScriptMbo = getMbo();
/*    */     try
/*    */     {
/* 55 */       if (autoScriptMbo != null)
/*    */       {
/* 57 */         autoScriptMbo.setValue("source", new String(file.getFileOutputStream().toByteArray(), "UTF-8"));

/*    */       }
/*    */     }
/*    */     catch (MXException mxe)
/*    */     {
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */       String[] params;
/* 67 */       throw new MXApplicationException("script", "invalidscript", params, e);
/*    */     }
/*    */     finally
/*    */     {
/* 71 */       this.app.remove("importfile");
/* 72 */       structureChangedEvent(this);
/*    */     }
/* 74 */     return 1;
/*    */   }






/*    */   public int complete()
/*    */     throws MXException, RemoteException
/*    */   {
/* 85 */     save();
/* 86 */     WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/* 87 */     String[] params = { "" };
/* 88 */     this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "script", "scrcomplete", params);
/* 89 */     reset();
/* 90 */     fireDataChangedEvent();
/* 91 */     structureChangedEvent(this);
/* 92 */     this.app.getResultsBean().recHasChanged();
/* 93 */     return 1;
/*    */   }
/*    */ }
