/*     */ package com.ibm.ism.script.webclient.beans.autoscript;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringWriter;
/*     */ import java.rmi.RemoteException;
/*     */ import org.python.util.PythonInterpreter;
/*     */ import psdi.mbo.Mbo;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.util.MXException;
/*     */ import psdi.webclient.system.beans.AppBean;
/*     */ import psdi.webclient.system.beans.ResultsBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.SessionContext;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 






















/*     */ public class AutoScriptAppBean extends AppBean
/*     */ {
/*     */   public static WebClientSession wcs;
/*  45 */   private static String AUTOSCRIPT_ACTION_PREFIX = "AUTOSCRIPT_";
/*  46 */   private static String AUTOSCRIPT_ACTION_CLASSNAME = "com.ibm.ism.script.action.AutoScriptDelegateAction";
/*     */ 
/*     */   public int EXECUTE() throws MXException, RemoteException {
/*  49 */     executeScript();
/*  50 */     fireStructureChangedEvent();
/*     */ 
/*  52 */     return 1;
/*     */   }

/*     */   public void executeScript()
/*     */     throws MXException, RemoteException
/*     */   {
/*  58 */     PythonInterpreter jython = new PythonInterpreter();
/*  59 */     StringWriter stdout = new StringWriter();
/*  60 */     StringWriter stderr = new StringWriter();
/*     */ 
/*  62 */     MboRemote scriptMbo = getMbo();

/*     */ 
/*  65 */     scriptMbo.setValue("STDOUT", "");
/*  66 */     scriptMbo.setValue("STDERR", "");
/*     */ 
/*  68 */     jython.setOut(stdout);
/*  69 */     jython.setErr(stderr);
/*     */ 
/*  71 */     String script = scriptMbo.getString("SOURCE");
/*  72 */     InputStream scriptStream = new ByteArrayInputStream(script.getBytes());
/*     */     try
/*     */     {
/*  75 */       jython.execfile(scriptStream);
/*     */     }
/*     */     catch (Exception e) {
/*  78 */       stderr.write(e.toString());
/*     */     }
/*     */ 
/*  81 */     if (!(stdout.toString().equals(""))) {
/*  82 */       scriptMbo.setValue("STDOUT", stdout.toString());
/*     */     }
/*     */ 
/*  85 */     if (!(stderr.toString().equals(""))) {
/*  86 */       scriptMbo.setValue("STDERR", stderr.toString());
/*     */     }
/*     */ 
/*  89 */     wcs = this.clientSession;
/*  90 */     wcs.loadDialog("scriptresults");
/*     */   }

/*     */   public int CREATEACT() throws MXException, RemoteException {
/*  94 */     createAction();
/*  95 */     fireDataChangedEvent();
/*  96 */     return 1;
/*     */   }

/*     */   public void createAction()
/*     */     throws MXException, RemoteException
/*     */   {
/* 102 */     Mbo scriptMbo = (Mbo)getMbo();


/*     */ 
/* 106 */     String scriptName = scriptMbo.getString("AUTOSCRIPT");
/* 107 */     String actionName = AUTOSCRIPT_ACTION_PREFIX + scriptName;

/*     */ 
/* 110 */     MboSetRemote actionSet = scriptMbo.getMboSet("$AUTOSCRACTION", "ACTION", "action='" + actionName + "'");

/*     */ 
/* 113 */     MboRemote actionMbo = null;
/* 114 */     if (actionSet.isEmpty()) {
/* 115 */       String actionType = scriptMbo.getTranslator().toExternalDefaultValue("ACTIONTYPE", "CUSTOM", scriptMbo);


/*     */ 
/* 119 */       actionMbo = actionSet.add(2L);
/* 120 */       actionMbo.setValue("ACTION", actionName);

/*     */ 
/* 123 */       actionMbo.setValue("TYPE", actionType, 11L);
/*     */ 
/* 125 */       actionMbo.setValue("DISPVALUE", AUTOSCRIPT_ACTION_CLASSNAME);
/*     */ 
/* 127 */       scriptMbo.setValue("ACTION", actionName, 9L);
/*     */     }
/*     */     else
/*     */     {
/* 131 */       if (actionSet.count() <= 0)
/*     */         return;
/* 133 */       actionMbo = actionSet.getMbo(0);
/* 134 */       if (scriptMbo.getString("ACTION").equals("")) {
/* 135 */         scriptMbo.setValue("ACTION", actionName, 1L);
/*     */       }
/*     */ 
/* 138 */       return;
/*     */     }
/*     */   }




/*     */   public int properties()
/*     */   {
/*     */     try
/*     */     {
/* 149 */       WebClientEvent event = this.clientSession.getCurrentEvent();
/* 150 */       int row = this.sessionContext.getCurrentEvent().getRow();
/*     */ 
/* 152 */       setCurrentRow(row);
/* 153 */       String type = getMbo().getString("launchpointtype");
/* 154 */       if (type != null) {
/* 155 */         type = type.toLowerCase();
/*     */       }
/*     */ 
/* 158 */       this.clientSession.queueEvent(new WebClientEvent(type + "detail", event.getTargetId(), "", this.clientSession));
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 162 */       ex.printStackTrace();
/*     */     }
/* 164 */     return 1;
/*     */   }

/*     */   public int addobjectlaunchevent() throws MXException, RemoteException
/*     */   {
/* 169 */     return addscriptevent("OBJECT");
/*     */   }

/*     */   public int addattributelaunchevent() throws MXException, RemoteException {
/* 173 */     return addscriptevent("ATTRIBUTE");
/*     */   }

/*     */   public int addactionlaunchevent() throws MXException, RemoteException {
/* 177 */     return addscriptevent("ACTION");
/*     */   }

/*     */   public int addcustomconditionlaunchevent() throws MXException, RemoteException
/*     */   {
/* 182 */     return addscriptevent("CUSTOMCONDITION");
/*     */   }

/*     */   public int addscriptevent(String intDomType)
/*     */     throws MXException, RemoteException
/*     */   {
/* 188 */     WebClientEvent event = this.clientSession.getCurrentEvent();

/*     */ 
/* 191 */     MboRemote mbo = getMbo();
/* 192 */     if (mbo != null)
/*     */     {
/* 194 */       mbo.sigOptionAccessAuthorized("INSERT");

/*     */     }
/*     */ 
/* 198 */     insert();
/* 199 */     if (mbo == null) {
/* 200 */       mbo = getZombie();
/*     */     }
/* 202 */     setValue("launchpointtype", intDomType.toUpperCase(), 2L);
/* 203 */     this.clientSession.queueEvent(new WebClientEvent(intDomType.toLowerCase() + "detail", event.getTargetId(), "", this.clientSession));
/*     */ 
/* 205 */     return 1;
/*     */   }




/*     */   public int cancelDialog()
/*     */     throws MXException, RemoteException
/*     */   {
/* 214 */     if (getMbo().toBeAdded())
/*     */     {
/* 216 */       deleteAndRemove();
/*     */     }
/* 218 */     return super.cancelDialog();
/*     */   }

/*     */   public synchronized void insert()
/*     */     throws MXException, RemoteException
/*     */   {
/* 224 */     insert(this.startrow);
/*     */   }


/*     */   public int STATUS()
/*     */     throws MXException, RemoteException
/*     */   {
/* 231 */     if ((this.app != null) && (this.app.onListTab())) {
/* 232 */       ResultsBean rb = this.app.getResultsBean();
/* 233 */       if (rb != null) {
/* 234 */         rb.hasRecordsForAction();
/*     */       }
/*     */     }
/* 237 */     return 2;
/*     */   }
/*     */ }
