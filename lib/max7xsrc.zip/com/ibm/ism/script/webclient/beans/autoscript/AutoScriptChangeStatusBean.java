/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.BitFlag;
/*    */ import psdi.util.MXException;
/*    */ import psdi.webclient.system.beans.DataBean;
/*    */ import psdi.webclient.system.beans.ResultsBean;
/*    */ import psdi.webclient.system.controller.AppInstance;
/*    */ import psdi.webclient.system.controller.SessionContext;
/*    */ 





















/*    */ public class AutoScriptChangeStatusBean extends DataBean
/*    */ {
/*    */   public int execute()
/*    */     throws MXException, RemoteException
/*    */   {
/* 38 */     MboRemote remy = null;
/*    */ 
/* 40 */     if (this.app.onListTab())
/*    */     {
/* 42 */       if (this.app.getResultsBean().getTableStateFlags().isFlagSet(32768L))




/*    */       {
/* 48 */         if (this.app.getResultsBean().hasRecordsForAction()) {
/* 49 */           remy = this.app.getResultsBean().getMbo(0);


/*    */ 
/* 53 */           save(remy);


/*    */         }
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/* 61 */         int i = 0;
/* 62 */         remy = this.app.getResultsBean().getMbo(i);
/* 63 */         while (remy != null) {
/* 64 */           remy.select();
/* 65 */           ++i;
/* 66 */           remy = this.app.getResultsBean().getMbo(i);

/*    */         }
/*    */ 
/* 70 */         if (this.app.getResultsBean().getMbo(0) != null) {
/* 71 */           save(this.app.getResultsBean().getMbo(0));
/*    */         }
/*    */       }
/*    */ 
/*    */     }
/*    */     else {
/* 77 */       save();

/*    */     }
/*    */ 
/* 81 */     this.sessionContext.queueRefreshEvent();
/*    */ 
/* 83 */     return 1;
/*    */   }
/*    */ }
