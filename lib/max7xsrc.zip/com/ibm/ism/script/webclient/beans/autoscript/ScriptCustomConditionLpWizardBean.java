/*    */ package com.ibm.ism.script.webclient.beans.autoscript;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ 



























/*    */ public class ScriptCustomConditionLpWizardBean extends ScriptWizardBean
/*    */ {
/* 37 */   private static String[] allTabs = { "wcreate_lp_cc", "wcreate_lp_vars_cc", "wscript_gen_cc" };
/*    */ 
/*    */   public void initialize()
/*    */     throws MXException, RemoteException
/*    */   {
/* 43 */     super.initialize();
/* 44 */     insert();
/* 45 */     fireStructureChangedEvent();
/*    */   }

/*    */   protected String[] getAllTabs()
/*    */   {
/* 50 */     return allTabs;
/*    */   }

/*    */   protected void validateMoveTab(int currentTabOrder) throws MXException, RemoteException
/*    */   {
/* 55 */     super.validateMoveTab(currentTabOrder);
/*    */ 
/* 57 */     if (currentTabOrder != 1)
/*    */       return;
/* 59 */     MboRemote lpMbo = getMbo();
/* 60 */     if ((lpMbo == null) || (!(lpMbo.getName().equals("SCRIPTLAUNCHPOINT"))))
/*    */       return;
/* 62 */     MboSetRemote lpVarSet = lpMbo.getMboSet("LAUNCHPOINTVARS");
/* 63 */     MboSetRemote autoSet = getMbo().getMboSet("AUTOSCRIPT");
/* 64 */     MboRemote autoScriptMbo = autoSet.getMbo(0);
/* 65 */     if (autoScriptMbo == null)
/*    */       return;
/* 67 */     MboSetRemote varsSet = autoScriptMbo.getMboSet("AUTOSCRIPTVARS");
/*    */ 
/* 69 */     MboRemote var = null;
/* 70 */     for (int i = 0; ; ++i)
/*    */     {
/* 72 */       var = varsSet.getMbo(i);
/* 73 */       if (var == null) {
/*    */         return;
/*    */       }
/*    */ 
/* 77 */       String varType = var.getString("vartype");
/* 78 */       if ((varType.equals("IN")) || (var.toBeDeleted()))
/*    */         continue;
/* 80 */       String[] params = { var.getString("varname") };
/* 81 */       throw new MXApplicationException("script", "onlyinallowed", params);
/*    */     }
/*    */   }




/*    */   protected void setDefaultValues(MboRemote wizMbo)
/*    */     throws MXException, RemoteException
/*    */   {
/* 91 */     setValue("launchpointtype", "CUSTOMCONDITION", 2L);
/*    */   }


/*    */   protected String getTabGroupName()
/*    */   {
/* 97 */     return "wgenerate11_tabs_cc_2";
/*    */   }
/*    */ }
