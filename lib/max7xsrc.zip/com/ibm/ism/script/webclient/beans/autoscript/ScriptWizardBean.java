/*     */ package com.ibm.ism.script.webclient.beans.autoscript;
/*     */ 
/*     */ import com.ibm.tivoli.maximo.script.ScriptDriver;
/*     */ import com.ibm.tivoli.maximo.script.ScriptDriverFactory;
/*     */ import com.ibm.tivoli.maximo.script.ScriptParamInfo;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXApplicationYesNoCancelException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ import psdi.webclient.system.beans.DataBean;
/*     */ import psdi.webclient.system.beans.ResultsBean;
/*     */ import psdi.webclient.system.controller.AppInstance;
/*     */ import psdi.webclient.system.controller.UploadFile;
/*     */ import psdi.webclient.system.controller.WebClientEvent;
/*     */ import psdi.webclient.system.runtime.WebClientRuntime;
/*     */ import psdi.webclient.system.session.WebClientSession;
/*     */ 




















/*     */ public abstract class ScriptWizardBean extends DataBean
/*     */ {
/*     */   private int processTabOrder;
/*     */ 
/*     */   public ScriptWizardBean()
/*     */   {
/*  52 */     this.processTabOrder = 0;
/*     */   }








/*     */   public int nexttab()
/*     */     throws MXException, RemoteException
/*     */   {
/*  65 */     int nextTabOrder = 0;
/*     */     try
/*     */     {
/*  68 */       nextTabOrder = getNextTabOrder(this.processTabOrder);

/*     */     }
/*     */     catch (MXException e)
/*     */     {
/*  73 */       this.clientSession.showMessageBox(e);
/*  74 */       WebClientEvent event = new WebClientEvent("changetab", getTabGroupName(), getAllTabs()[this.processTabOrder], this.clientSession);
/*  75 */       event.setSourceControl(this.app);
/*  76 */       this.clientSession.queueEvent(event);
/*  77 */       return 1;
/*     */     }
/*  79 */     fireDataChangedEvent();
/*  80 */     fireStructureChangedEvent();
/*  81 */     WebClientEvent event = new WebClientEvent("changetab", getTabGroupName(), getAllTabs()[nextTabOrder], this.clientSession);
/*  82 */     event.setSourceControl(this.app);
/*  83 */     this.clientSession.queueEvent(event);
/*  84 */     this.processTabOrder = nextTabOrder;
/*  85 */     return 1;
/*     */   }



/*     */   protected void validateMoveTab(int currentTabOrder) throws MXException, RemoteException
/*     */   {
/*  92 */     if (currentTabOrder == 0)
/*     */     {
/*  94 */       if (getMbo().isNull("launchpointname"))
/*     */       {
/*  96 */         throw new MXApplicationException("script", "missinglpname");
/*     */       }
/*  98 */       if ((getMbo().isNull("scriptorigin")) || (!(getMbo().getString("scriptorigin").equals("EXISTING"))) || (!(getMbo().isNull("autoscriptnp")))) {
/*     */         return;
/*     */       }
/* 101 */       throw new MXApplicationException("script", "missingscriptnp");
/*     */     }
/*     */ 
/* 104 */     if (currentTabOrder != 1)
/*     */     {
/*     */       return;
/*     */     }
/*     */ 
/* 109 */     MboRemote lpMbo = getMbo();
/* 110 */     if ((lpMbo == null) || (!(lpMbo.getName().equals("SCRIPTLAUNCHPOINT"))))
/*     */       return;
/* 112 */     MboSetRemote lpVarSet = lpMbo.getMboSet("LAUNCHPOINTVARS");
/* 113 */     MboSetRemote autoSet = getMbo().getMboSet("AUTOSCRIPT");
/* 114 */     MboRemote autoScriptMbo = autoSet.getMbo(0);
/* 115 */     if (autoScriptMbo == null)
/*     */       return;
/* 117 */     if (autoScriptMbo.isNull("autoscript"))
/*     */     {
/* 119 */       String[] params = { "  " };
/* 120 */       throw new MXApplicationException("script", "invalidscript", params);
/*     */     }
/*     */ 
/* 123 */     lpMbo.setValue("autoscript", autoScriptMbo.getString("autoscript"), 11L);
/*     */ 
/* 125 */     MboSetRemote varsSet = autoScriptMbo.getMboSet("AUTOSCRIPTVARS");
/*     */ 
/* 127 */     MboRemote var = null;
/* 128 */     for (int i = 0; ; ++i)
/*     */     {
/* 130 */       var = varsSet.getMbo(i);
/* 131 */       if (var == null) {
/*     */         break;
/*     */       }
/*     */ 
/* 135 */       if (var.toBeDeleted())
/*     */         continue;
/* 137 */       String bindType = var.getString("varbindingtype");
/* 138 */       if ((!(var.isNull("attributevaluenp"))) && (bindType.equalsIgnoreCase("ATTRIBUTE")))
/*     */       {
/* 140 */         var.setValue("lpvarbindval", var.getString("attributevaluenp"), 11L);
/*     */       }
/*     */ 
/* 143 */       if ((!(var.isNull("lpvarbindval"))) || (!(bindType.equalsIgnoreCase("ATTRIBUTE")))) {
/*     */         continue;
/*     */       }
/* 146 */       String[] params = { var.getString("varname") };
/* 147 */       throw new MXApplicationException("script", "missinglpbindvalue", params);

/*     */     }
/*     */ 
/* 151 */     int lpVarsCount = lpVarSet.count();
/* 152 */     Map mapOfLpVarsMbo = new HashMap();
/* 153 */     if (lpVarSet.count() > 0)
/*     */     {
/* 155 */       for (int i = 0; i < lpVarsCount; ++i)
/*     */       {
/* 157 */         mapOfLpVarsMbo.put(lpVarSet.getMbo(i).getString("varname"), lpVarSet.getMbo(i));
/*     */       }
/*     */     }
/* 160 */     for (int i = 0; ; ++i)
/*     */     {
/* 162 */       var = varsSet.getMbo(i);
/* 163 */       if (var == null) {
/*     */         return;
/*     */       }
/*     */ 
/* 167 */       if (var.toBeDeleted()) {
/*     */         continue;
/*     */       }
/* 170 */       if (var.isNull("lpvarbindval"))
/*     */         continue;
/* 172 */       MboRemote launchVarMbo = null;
/* 173 */       if (mapOfLpVarsMbo.containsKey(var.getString("varname")))
/*     */       {
/* 175 */         launchVarMbo = (MboRemote)mapOfLpVarsMbo.get(var.getString("varname"));
/*     */       }
/*     */       else
/*     */       {
/* 179 */         launchVarMbo = lpVarSet.addAtEnd();
/*     */       }
/* 181 */       launchVarMbo.setValue("varname", var.getString("varname"), 11L);
/*     */ 
/* 183 */       launchVarMbo.setValue("varbindingvalue", var.getString("lpvarbindval"), 2L);
/*     */ 
/* 185 */       launchVarMbo.setValue("overridden", true, 11L);
/*     */ 
/* 187 */       launchVarMbo.setValue("varbindingtype", var.getString("varbindingtype"), 2L);
/* 188 */       launchVarMbo.setValue("literaldatatype", var.getString("literaldatatype"), 2L);
/*     */     }
/*     */   }







/*     */   protected void actionMoveTab(int currentTabOrder)
/*     */     throws MXException, RemoteException
/*     */   {
/* 201 */     if (currentTabOrder != 0)
/*     */       return;
/* 203 */     MboSetRemote scriptSet = getMbo().getMboSet("AUTOSCRIPT");
/* 204 */     if (scriptSet.getApp() == null)
/*     */     {
/* 206 */       scriptSet.setApp("AUTOSCRIPT");
/*     */     }
/* 208 */     if (!(getMbo().isNull("autoscriptnp")))
/*     */     {
/* 210 */       MboRemote scriptMbo = null;
/* 211 */       if (scriptSet.count() == 1)
/*     */       {
/* 213 */         MboRemote scriptMbo2 = scriptSet.getMbo(0);
/* 214 */         if (scriptMbo2.getString("autoscript").equals(getMbo().getString("autoscriptnp")))
/*     */         {
/* 216 */           scriptMbo = scriptMbo2;
/*     */         }
/*     */         else
/*     */         {
/* 220 */           scriptSet.reset();
/*     */         }
/*     */       }
/* 223 */       if (scriptMbo == null)
/*     */       {
/* 225 */         scriptSet.setQbeExactMatch(true);
/* 226 */         scriptSet.setQbe("autoscript", getMbo().getString("autoscriptnp"));
/* 227 */         scriptSet.reset();
/*     */ 
/* 229 */         if (scriptSet.isEmpty())
/*     */         {
/* 231 */           String[] params = { getMbo().getString("autoscriptnp") };
/* 232 */           throw new MXApplicationException("script", "invalidscript", params);
/*     */         }
/* 234 */         scriptSet.getMbo();


/*     */       }
/*     */ 
/*     */     }
/* 240 */     else if (scriptSet.count() == 1)
/*     */     {
/* 242 */       MboRemote scriptMbo = scriptSet.getMbo(0);
/* 243 */       if (!(scriptMbo.toBeAdded()))
/*     */       {
/* 245 */         scriptSet.reset();
/* 246 */         scriptSet.add();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 251 */       scriptSet.add();
/*     */     }
/*     */   }














/*     */   private int getNextTabOrder(int currentTabOrder)
/*     */     throws MXException, RemoteException
/*     */   {
/* 271 */     validateMoveTab(currentTabOrder);
/* 272 */     actionMoveTab(currentTabOrder);
/* 273 */     return (currentTabOrder + 1);
/*     */   }





/*     */   public int prevtab()
/*     */     throws MXException, RemoteException
/*     */   {
/* 283 */     int prevTabOrder = getPreviousTabOrder(this.processTabOrder);
/* 284 */     fireDataChangedEvent();
/* 285 */     fireStructureChangedEvent();
/* 286 */     WebClientEvent event = new WebClientEvent("changetab", getTabGroupName(), getAllTabs()[prevTabOrder], this.clientSession);
/* 287 */     event.setSourceControl(this.app);
/* 288 */     this.clientSession.queueEvent(event);
/* 289 */     this.processTabOrder = prevTabOrder;
/* 290 */     return 1;
/*     */   }







/*     */   private int getPreviousTabOrder(int currentTabOrder)
/*     */     throws MXException, RemoteException
/*     */   {
/* 302 */     return (currentTabOrder - 1);
/*     */   }









/*     */   public synchronized void insert()
/*     */     throws MXException, RemoteException
/*     */   {
/* 316 */     super.insert();
/* 317 */     setDefaultValues(getMbo());
/*     */   }





/*     */   public int complete()
/*     */     throws MXException, RemoteException
/*     */   {
/* 327 */     save();
/* 328 */     WebClientRuntime.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.clientSession));
/* 329 */     String[] params = { "" };
/* 330 */     this.clientSession.showMessageBox(this.clientSession.getCurrentEvent(), "script", "lpcomplete", params);
/* 331 */     reset();
/* 332 */     fireDataChangedEvent();
/* 333 */     structureChangedEvent(this);
/*     */ 
/* 335 */     this.app.getResultsBean().recHasChanged();
/* 336 */     return 1;
/*     */   }








/*     */   public int cancelchanges()
/*     */     throws MXException, RemoteException
/*     */   {
/* 349 */     WebClientEvent event = this.clientSession.getCurrentEvent();
/* 350 */     int msgRet = event.getMessageReturn();
/*     */ 
/* 352 */     if (msgRet < 0)
/*     */     {
/* 354 */       throw new MXApplicationException("script", "cancelchanges");
/*     */     }
/* 356 */     if (msgRet == 8)
/*     */     {
/* 358 */       getMboSet().rollback();
/* 359 */       this.clientSession.getCurrentApp().put("forcereload", "true");
/* 360 */       this.clientSession.queueEvent(new WebClientEvent("changeapp", this.app.getId(), "autoscript", this.clientSession));
/*     */     } else {
/* 362 */       if (msgRet == 16) {
/* 363 */         return 1;
/*     */       }
/* 365 */       return 1;
/*     */     }
/* 367 */     return 1;
/*     */   }







/*     */   public int loadData()
/*     */     throws MXException, RemoteException
/*     */   {
/* 379 */     UploadFile file = (UploadFile)this.app.get("importfile");
/*     */ 
/* 381 */     if (file == null) {
/* 382 */       throw new MXApplicationException("designer", "noimportfile");
/*     */     }
/* 384 */     MboSetRemote autoSet = getMbo().getMboSet("AUTOSCRIPT");
/* 385 */     MboRemote autoScriptMbo = autoSet.getMbo(0);
/* 386 */     boolean bWarning = false;
/*     */     try
/*     */     {
/* 389 */       if (autoScriptMbo != null)
/*     */       {
/* 391 */         if (!(autoScriptMbo.toBeAdded()))
/*     */         {
/* 393 */           MboSetRemote lpSet = autoScriptMbo.getMboSet("SCRIPTLAUNCHPOINT");
/* 394 */           MboRemote lpMbo = lpSet.getMbo(0);
/* 395 */           if ((lpMbo != null) && (lpMbo.toBeAdded()))
/*     */           {
/* 397 */             this.app.remove("importfile");
/* 398 */             throw new MXApplicationException("script", "no_import_on_existing_script");
/*     */           }
/*     */         }
/*     */ 
/* 402 */         String scriptLang = autoScriptMbo.getString("scriptlanguage");
/* 403 */         ScriptDriver scriptDriver = ScriptDriverFactory.getInstance().getScriptDriverForLanguage(scriptLang);
/* 404 */         boolean binaryScript = scriptDriver.isBinaryScript();
/* 405 */         byte[] scriptBytes = file.getFileOutputStream().toByteArray();
/* 406 */         if (!(binaryScript))

/*     */         {
/* 409 */           autoScriptMbo.setValue("source", new String(scriptBytes, "UTF-8"), 2L);


/*     */         }
/*     */         else
/*     */         {
/* 415 */           autoScriptMbo.setValue("binaryscriptsource", scriptBytes, 2L);

/*     */         }
/*     */ 
/* 419 */         if (scriptDriver.supportsPublishedParams())
/*     */         {
/* 421 */           List listParams = scriptDriver.parseScriptForParams(scriptBytes);
/*     */           MboSetRemote varMboSet;/* 422 */           if (autoScriptMbo.toBeAdded())
/*     */           {
/* 424 */             autoScriptMbo.getMboSet("AUTOSCRIPTVARS").reset();
/* 425 */             varMboSet = autoScriptMbo.getMboSet("AUTOSCRIPTVARS");
/* 426 */             if ((listParams != null) && (listParams.size() > 0))
/*     */             {
/* 428 */               for (ScriptParamInfo param : listParams)
/*     */               {
/* 430 */                 if (scriptDriver.isVarNameMatchesKeyWord(param.getName()))
/*     */                 {
/* 432 */                   MXLoggerFactory.getLogger("maximo.script").info("skipped var " + param.getName() + " from the script definition as thats an implicit vaiable");
/*     */                 }
/*     */ 
/* 435 */                 MboRemote varMbo = varMboSet.add();
/* 436 */                 varMbo.setValue("varname", param.getName());
/* 437 */                 varMbo.setValue("vartype", param.getInoutType());
/* 438 */                 varMbo.setValue("allowoverride", true);
/*     */               }/*     */             }/*     */           }
/*     */           else
/*     */           {
/*     */             MboSetRemote varMboSet;
/*     */             Map mapMbos;
/* 444 */             if ((listParams != null) && (listParams.size() > 0))
/*     */             {
/* 446 */               varMboSet = autoScriptMbo.getMboSet("AUTOSCRIPTVARS");
/* 447 */               mapMbos = new HashMap();
/* 448 */               int pos = 0;
/* 449 */               while (varMboSet.getMbo(pos) != null)
/*     */               {
/* 451 */                 String varName = varMboSet.getMbo(pos).getString("varname");
/* 452 */                 boolean deleteVar = true;
/* 453 */                 for (ScriptParamInfo param : listParams)
/*     */                 {
/* 455 */                   if (param.getName().equals(varName))
/*     */                   {
/* 457 */                     deleteVar = false;
/*     */                   }
/*     */                 }
/* 460 */                 if (deleteVar)
/*     */                 {
/* 462 */                   varMboSet.getMbo(pos).delete();
/*     */                 }
/* 464 */                 mapMbos.put(varName, varMboSet.getMbo(pos));
/* 465 */                 ++pos;
/*     */               }
/* 467 */               for (ScriptParamInfo param : listParams)
/*     */               {
/* 469 */                 if (scriptDriver.isVarNameMatchesKeyWord(param.getName()))
/*     */                 {
/* 471 */                   MXLoggerFactory.getLogger("maximo.script").info("skipped var " + param.getName() + " from the script definition as thats an implicit vaiable");
/*     */                 }
/*     */ 
/* 474 */                 if (!(mapMbos.containsKey(param.getName())))
/*     */                 {
/* 476 */                   MboRemote varMbo = varMboSet.add();
/* 477 */                   varMbo.setValue("varname", param.getName());
/* 478 */                   varMbo.setValue("vartype", param.getInoutType());
/* 479 */                   varMbo.setValue("allowoverride", true);


/*     */                 }
/* 483 */                 else if (((MboRemote)mapMbos.get(param.getName())).toBeDeleted())
/*     */                 {
/* 485 */                   ((MboRemote)mapMbos.get(param.getName())).undelete();
/*     */                 }
/*     */ 
/*     */               }
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/* 493 */               autoScriptMbo.getMboSet("AUTOSCRIPTVARS").deleteAll();





/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (MXApplicationYesNoCancelException mxae)
/*     */     {
/*     */     }
/*     */     catch (MXException mxe)
/*     */     {
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       String[] params;
/* 513 */       throw new MXApplicationException("script", "invalidscript", params, e);
/*     */     }
/*     */     finally
/*     */     {
/* 517 */       if (!(bWarning))
/* 518 */         this.app.remove("importfile");
/* 519 */       structureChangedEvent(this);
/*     */     }
/* 521 */     return 1;
/*     */   }


/*     */   public boolean hasSigOptionAccess(int row, String sigOption)
/*     */     throws RemoteException, MXException
/*     */   {
/* 528 */     if (sigOption != null)

/*     */     {
/* 531 */       if (sigOption.equalsIgnoreCase("HIDEIMP"))
/*     */       {
/* 533 */         MboRemote mbo = getMbo(row);
/* 534 */         MboRemote scriptMbo = mbo.getMboSet("AUTOSCRIPT").getMbo();


/*     */ 
/* 538 */         return ((scriptMbo == null) || (scriptMbo.toBeAdded()));


/*     */       }
/*     */ 
/* 543 */       return super.hasSigOptionAccess(row, sigOption);
/*     */     }
/* 545 */     return false;
/*     */   }
/*     */ }
